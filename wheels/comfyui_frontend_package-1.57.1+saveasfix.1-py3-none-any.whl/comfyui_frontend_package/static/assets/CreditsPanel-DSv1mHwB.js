import { t as CreditsPanel_default } from "./CreditsPanel-CWOa2mzL.js";
export { CreditsPanel_default as default };
