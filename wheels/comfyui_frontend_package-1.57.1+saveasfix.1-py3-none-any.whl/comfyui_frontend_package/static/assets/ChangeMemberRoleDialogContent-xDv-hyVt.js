import "./rolldown-runtime-xtsTai4I.js";
import { t as useTeamWorkspaceStore } from "./teamWorkspaceStore-BNm5cZOK.js";
import { F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, I as createBlock, O as Fragment, P as computed, R as createElementBlock, U as createVNode, Yt as toDisplayString, ct as openBlock, ut as renderList, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as useToast } from "./toastStore-Dg65fRgL.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
import { t as AppDialogPanel_default } from "./AppDialogPanel-BklaJBTn.js";
//#region src/platform/workspace/components/dialogs/ChangeMemberRoleDialogContent.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "m-0" };
var _hoisted_2 = { class: "m-0 mt-1 list-disc ps-5" };
var _hoisted_3 = {
	key: 1,
	class: "m-0"
};
//#endregion
//#region src/platform/workspace/components/dialogs/ChangeMemberRoleDialogContent.vue
var ChangeMemberRoleDialogContent_default = /* @__PURE__ */ defineComponent({
	__name: "ChangeMemberRoleDialogContent",
	props: {
		memberId: {},
		memberName: {},
		targetRole: {}
	},
	setup(__props) {
		const dialogStore = useDialogStore();
		const workspaceStore = useTeamWorkspaceStore();
		const toast = useToast();
		const { t } = useI18n();
		const loading = ref(false);
		const isPromotion = computed(() => __props.targetRole === "owner");
		const promotePermissions = computed(() => [
			t("workspacePanel.changeRoleDialog.promotePermissionCredits"),
			t("workspacePanel.changeRoleDialog.promotePermissionManage"),
			t("workspacePanel.changeRoleDialog.promotePermissionRoles")
		]);
		function onCancel() {
			dialogStore.closeDialog({ key: "change-member-role" });
		}
		async function onConfirm() {
			loading.value = true;
			try {
				await workspaceStore.changeMemberRole(__props.memberId, __props.targetRole);
				toast.success(t("workspacePanel.changeRoleDialog.success"), { duration: 2e3 });
				dialogStore.closeDialog({ key: "change-member-role" });
			} catch {
				toast.error(t("workspacePanel.changeRoleDialog.error"));
			} finally {
				loading.value = false;
			}
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(AppDialogPanel_default, {
				size: "compact",
				"body-class": "text-sm text-muted-foreground",
				onClose: onCancel
			}, {
				title: withCtx(() => [createTextVNode(toDisplayString(isPromotion.value ? _ctx.$t("workspacePanel.changeRoleDialog.promoteTitle", { name: __props.memberName }) : _ctx.$t("workspacePanel.changeRoleDialog.demoteTitle", { name: __props.memberName })), 1)]),
				footer: withCtx(() => [createVNode(Button_default, {
					variant: "muted-textonly",
					onClick: onCancel
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("g.cancel")), 1)]),
					_: 1
				}), createVNode(Button_default, {
					variant: "secondary",
					size: "lg",
					loading: loading.value,
					onClick: onConfirm
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(isPromotion.value ? _ctx.$t("workspacePanel.changeRoleDialog.promoteConfirm") : _ctx.$t("workspacePanel.changeRoleDialog.demoteConfirm")), 1)]),
					_: 1
				}, 8, ["loading"])]),
				default: withCtx(() => [isPromotion.value ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [createBaseVNode("p", _hoisted_1, toDisplayString(_ctx.$t("workspacePanel.changeRoleDialog.promoteIntro")), 1), createBaseVNode("ul", _hoisted_2, [(openBlock(true), createElementBlock(Fragment, null, renderList(promotePermissions.value, (permission) => {
					return openBlock(), createElementBlock("li", { key: permission }, toDisplayString(permission), 1);
				}), 128))])], 64)) : (openBlock(), createElementBlock("p", _hoisted_3, toDisplayString(_ctx.$t("workspacePanel.changeRoleDialog.demoteMessage")), 1))]),
				_: 1
			});
		};
	}
});
//#endregion
export { ChangeMemberRoleDialogContent_default as default };
