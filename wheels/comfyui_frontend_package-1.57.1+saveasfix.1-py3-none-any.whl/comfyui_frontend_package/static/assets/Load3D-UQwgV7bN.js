import { t as Load3D_default } from "./Load3D-CfQgntdn.js";
export { Load3D_default as default };
