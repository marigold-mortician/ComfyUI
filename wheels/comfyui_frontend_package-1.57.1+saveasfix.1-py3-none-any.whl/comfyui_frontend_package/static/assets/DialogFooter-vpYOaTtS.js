import "./rolldown-runtime-xtsTai4I.js";
import { G as defineComponent, Kt as normalizeClass, R as createElementBlock, Wt as unref, ct as openBlock, dt as renderSlot } from "./vendor-vue-core-CuN1excl.js";
import { t as cn } from "./src-BHQtMnZc.js";
//#endregion
//#region src/components/ui/dialog/DialogFooter.vue
var DialogFooter_default = /* @__PURE__ */ defineComponent({
	__name: "DialogFooter",
	props: { class: {
		type: [
			Boolean,
			null,
			String,
			Object,
			Array
		],
		default: ""
	} },
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", { class: normalizeClass(unref(cn)("flex shrink-0 items-center justify-end gap-2 px-4 pt-2 pb-4", __props.class)) }, [renderSlot(_ctx.$slots, "default")], 2);
		};
	}
});
//#endregion
export { DialogFooter_default as t };
