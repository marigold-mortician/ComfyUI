const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./boundingBoxesDialog-CB9Jb3bQ.js","./rolldown-runtime-xtsTai4I.js","./vendor-vue-core-CuN1excl.js","./Button-CcqmlVQb.js","./vendor-reka-ui-NRTk7aIV.js","./src-BHQtMnZc.js","./dialogStore-Dm9z8_kv.js","./BoundingBoxesEditor-DG3cE7k7.js","./litegraph-CgrqhFEE.js","./noop-CsGmlYWz.js","./cloneDeep-BX7AjX4w.js","./globalThis-B6Vbq1EF.js","./isPlainObject-6prWdO5v.js","./get-Bk-Y8oEe.js","./isObject-BDwzDI3k.js","./colorUtil--RFe1UD6.js","./telemetry-IkzvF0TI.js","./vendor-zod-Del_rmdp.js","./i18n-BRluoVl-.js","./preload-helper-sJeoGctA.js","./vendor-i18n-pA_PV1p-.js","./formatUtil-DsZFGVbT.js","./commands-C9zyhK6Q.js","./main-BtaRoPyL.js","./nodeDefs-BUEI64H3.js","./settings-B3DInspu.js","./reportError-BHgDVvfb.js","./hostTelemetryEnabled-DM7ML37c.js","./remoteConfig-VmmsGxJZ.js","./vendor-sentry-zSXGkMPN.js","./errorUtil-DoQyAUQC.js","./rerouteId-1TDIYZkX.js","./graphTraversalUtil-BUK1cr2m.js","./globalEnums-BPoISudO.js","./assert--qJvwrYk.js","./vendor-markdown-CtxqRwKg.js","./widget-TCRFSGUe.js","./vendor-yjs-DzSvc5Ii.js","./iteratee-D-xtYlr8.js","./nodeOutputStore-DmbNgTmp.js","./litegraphUtil-B_WxWXjg.js","./map--HGZfCRO.js","./appInstance-CiT6CpGM.js","./inputSpecTree-B0INjagH.js","./api-BdJmXw98.js","./requestAuth-COoKVLz2.js","./zod.gen-DzuaBm8H.js","./vendor-axios-QnwcNXlY.js","./requestTimeout-DkmiEk-h.js","./vendor-firebase-B37L--zT.js","./toastStore-Dg65fRgL.js","./workflowStore-DP6mciq-.js","./treeUtil-4aExWhwq.js","./settingStore-DRRi2kOn.js","./delay-Cu8bS1zn.js","./dialogService-CqZr0BhP.js","./commandStore-XD_i1hej.js","./useErrorHandling-WrECc0C0.js","./DialogTitle-CWOHHLwH.js","./useCopyToClipboard-DUbSOtYA.js","./systemStatsStore-DAY0RqGT.js","./Input-12QxL1XI.js","./storageIO-CAjGLygi.js","./colorPaletteTheme-BLTbQMIT.js","./utils-DPLBHlcF.js","./downloadUtil-PDRccee-.js","./canvasStore-Dnz7OWvY.js","./agentPanelStore-DndzlR19.js","./clamp-C6J77Y5a.js","./useFeatureFlags-B3zg5FdZ.js","./PaletteSwatchRow-BDxyWNFq.js","./AppColorPicker-DF4cO9Dd.js","./SelectValue-Biyqru5w.js","./Textarea-Cj9Mt-4W.js","./widgetHistoryScope-DLmWjnnJ.js","./app-CSsV1u1T.js","./constants-CcZ5JemZ.js","./appModeStore-D8l_HeOH.js","./shuffle-CnBsCH60.js","./executionErrorStore-MSMBxScr.js","./debounce-CrddqoI1.js","./uniq-HSN5S90b.js","./deburr-BNFMXPzm.js","./queueSettingsStore-BzKxsLQU.js","./vendor-vueuse-ehQVlHrl.js","./sidebarTabStore-DSQyJJJG.js","./layerEditorDialogKey-j8nal3kA.js","./workflowFlattening-DY0Vs9rF.js","./executionStore-DSsREODN.js","./quick-lru-CwZ_Nev1.js","./modalUtil-Cmzr62_V.js","./useBillingContext-Cc-YANxo.js","./teamWorkspaceStore-BNm5cZOK.js","./ssoTelemetry-DZUrpShr.js","./telemetry-CRUTYyCh.js","./comfyApi-CXw0-V35.js","./desktopHostSession-B3KqJnXo.js","./ssoRequiredDialogKey-DRv9w9ql.js","./errors-Bls3VadO.js","./nodeDefStore-CF96GLZA.js","./authStore-D2cL6XhN.js","./types-t0xJOOCt.js","./cloudWebSessionStore-DQXLFlJm.js","./refreshRemoteConfig-CEuxp20e.js","./tierPricing-Dm5JzLf8.js","./creditsUtil-DxLnYjvD.js","./useAuthActions-CFn_-tF2.js","./workspaceStore-B8_lz1QF.js","./markdownRendererUtil-BJj2U6Nd.js","./extensionStore-CYnV6tYr.js","./useCurrentUser-DjJaVYwd.js","./useBillingCapabilities-x1h7nBmq.js","./Badge-BUm0jxSy.js","./types-Co7511Rq.js","./useBillingDialogs-Bc5B2YTn.js","./billingActionNames-DwcV6mOp.js","./billingDialogsAccess-BbNj81q5.js","./Card-lRVBegiG.js","./AppDialogPanel-BklaJBTn.js","./usePaymentRecoveryDialog-DeFBWQ7b.js","./FormNumberField-BP7-goH4.js","./NumberFieldInput-CUxTsNZT.js","./useExternalLink-Cd0Jpjd8.js","./envUtil-Cq1k2k7n.js","./useSubscriptionDialog-C4Ac2Pav.js","./subscriptionDialogAccess-Igw8sX_b.js","./useWorkspaceUI-CALMkHxF.js","./billingPlanTelemetry-CgeXQYDa.js","./pendingSubscriptionCheckout-CwZ4vFuG.js","./checkoutJourneyTelemetry-CznsrcWK.js","./getExecutionContext-aSfqv9_8.js","./categoryUtil-DZVfz29_.js","./usePartnerNodesRunGate-CDN3pb24.js","./useAuthDialogs-AEcL-pGe.js","./keybindingService-CtLOmFQk.js","./assetsStore-CNmOJwRQ.js","./assetMetadataUtils-IzKjxxiA.js","./cloudPreviewUtil-QoYZLRNr.js","./resultItemUrl-BV9Vi8QF.js","./hdrFormatUtil-rFvza1J0.js","./useChainCallback-Bm3zfHjO.js","./resolveWidgetValueAsset-lF2h5jqq.js","./usePopoverSizing-ux16dO36.js","./select.variants-BBeExFA3.js","./missingModelScan-R_tynz92.js","./imageUtil-D14xOjDk.js","./mathUtil-BWeg2vFD.js","./Load3dUtils-CF3OvEZx.js","./savedImageUrls-4ws0CCel.js","./DialogClose-dPzCXguP.js"])))=>i.map(i=>d[i]);
import "./rolldown-runtime-xtsTai4I.js";
import { t as __vitePreload } from "./preload-helper-sJeoGctA.js";
import { $ as mergeModels, G as defineComponent, I as createBlock, U as createVNode, _t as useModel, ct as openBlock, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as BoundingBoxesEditor_default } from "./BoundingBoxesEditor-DG3cE7k7.js";
//#endregion
//#region src/components/boundingBoxes/WidgetBoundingBoxes.vue
var WidgetBoundingBoxes_default = /* @__PURE__ */ defineComponent({
	__name: "WidgetBoundingBoxes",
	props: /*@__PURE__*/ mergeModels({
		nodeId: {},
		widget: {}
	}, {
		"modelValue": { default: () => [] },
		"modelModifiers": {}
	}),
	emits: ["update:modelValue"],
	setup(__props) {
		const modelValue = useModel(__props, "modelValue");
		async function openFullscreen() {
			const { openBoundingBoxesDialog } = await __vitePreload(async () => {
				const { openBoundingBoxesDialog } = await import("./boundingBoxesDialog-CB9Jb3bQ.js");
				return { openBoundingBoxesDialog };
			}, __vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149]), import.meta.url);
			openBoundingBoxesDialog(__props.nodeId, __props.widget);
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(BoundingBoxesEditor_default, {
				modelValue: modelValue.value,
				"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => modelValue.value = $event),
				"node-id": __props.nodeId,
				widget: __props.widget
			}, {
				"toolbar-end": withCtx(() => [createVNode(Button_default, {
					variant: "textonly",
					size: "icon",
					icon: "icon-[lucide--maximize-2]",
					"aria-label": _ctx.$t("boundingBoxes.openFullscreen"),
					tooltip: _ctx.$t("boundingBoxes.openFullscreen"),
					onClick: openFullscreen
				}, null, 8, ["aria-label", "tooltip"])]),
				_: 1
			}, 8, [
				"modelValue",
				"node-id",
				"widget"
			]);
		};
	}
});
//#endregion
export { WidgetBoundingBoxes_default as default };
