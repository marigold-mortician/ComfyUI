import "./rolldown-runtime-xtsTai4I.js";
import { t as useTeamWorkspaceStore } from "./teamWorkspaceStore-BNm5cZOK.js";
import { F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, I as createBlock, U as createVNode, Yt as toDisplayString, ct as openBlock, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as useToast } from "./toastStore-Dg65fRgL.js";
import { t as getErrorMessage } from "./errorUtil-DoQyAUQC.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
import { t as AppDialogPanel_default } from "./AppDialogPanel-BklaJBTn.js";
//#region src/platform/workspace/components/dialogs/DeleteWorkspaceDialogContent.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "m-0 text-sm text-muted-foreground" };
//#endregion
//#region src/platform/workspace/components/dialogs/DeleteWorkspaceDialogContent.vue
var DeleteWorkspaceDialogContent_default = /* @__PURE__ */ defineComponent({
	__name: "DeleteWorkspaceDialogContent",
	props: {
		workspaceId: {},
		workspaceName: {}
	},
	setup(__props) {
		const { t } = useI18n();
		const toast = useToast();
		const dialogStore = useDialogStore();
		const workspaceStore = useTeamWorkspaceStore();
		const loading = ref(false);
		function onCancel() {
			dialogStore.closeDialog({ key: "delete-workspace" });
		}
		async function onDelete() {
			loading.value = true;
			try {
				await workspaceStore.deleteWorkspace(__props.workspaceId);
				dialogStore.closeDialog({ key: "delete-workspace" });
				window.location.reload();
			} catch (error) {
				console.error("[DeleteWorkspaceDialog] Failed to delete workspace:", error);
				toast.error(t("workspacePanel.toast.failedToDeleteWorkspace"), { description: getErrorMessage(error) ?? t("g.unknownError") });
			} finally {
				loading.value = false;
			}
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(AppDialogPanel_default, {
				size: "compact",
				onClose: onCancel
			}, {
				title: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.deleteDialog.title")), 1)]),
				footer: withCtx(() => [createVNode(Button_default, {
					variant: "muted-textonly",
					onClick: onCancel
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("g.cancel")), 1)]),
					_: 1
				}), createVNode(Button_default, {
					variant: "destructive",
					size: "lg",
					loading: loading.value,
					onClick: onDelete
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("g.delete")), 1)]),
					_: 1
				}, 8, ["loading"])]),
				default: withCtx(() => [createBaseVNode("p", _hoisted_1, toDisplayString(__props.workspaceName ? _ctx.$t("workspacePanel.deleteDialog.messageWithName", { name: __props.workspaceName }) : _ctx.$t("workspacePanel.deleteDialog.message")), 1)]),
				_: 1
			});
		};
	}
});
//#endregion
export { DeleteWorkspaceDialogContent_default as default };
