const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./AgentPanelRoot-B-XQuFjq.js","./rolldown-runtime-xtsTai4I.js","./preload-helper-sJeoGctA.js","./appModeStore-D8l_HeOH.js","./litegraph-CgrqhFEE.js","./noop-CsGmlYWz.js","./cloneDeep-BX7AjX4w.js","./globalThis-B6Vbq1EF.js","./isPlainObject-6prWdO5v.js","./get-Bk-Y8oEe.js","./isObject-BDwzDI3k.js","./vendor-vue-core-CuN1excl.js","./vendor-reka-ui-NRTk7aIV.js","./colorUtil--RFe1UD6.js","./telemetry-IkzvF0TI.js","./vendor-zod-Del_rmdp.js","./i18n-BRluoVl-.js","./vendor-i18n-pA_PV1p-.js","./formatUtil-DsZFGVbT.js","./commands-C9zyhK6Q.js","./main-BtaRoPyL.js","./nodeDefs-BUEI64H3.js","./settings-B3DInspu.js","./reportError-BHgDVvfb.js","./hostTelemetryEnabled-DM7ML37c.js","./remoteConfig-VmmsGxJZ.js","./vendor-sentry-zSXGkMPN.js","./errorUtil-DoQyAUQC.js","./rerouteId-1TDIYZkX.js","./graphTraversalUtil-BUK1cr2m.js","./globalEnums-BPoISudO.js","./assert--qJvwrYk.js","./vendor-markdown-CtxqRwKg.js","./widget-TCRFSGUe.js","./vendor-yjs-DzSvc5Ii.js","./commandStore-XD_i1hej.js","./iteratee-D-xtYlr8.js","./useErrorHandling-WrECc0C0.js","./toastStore-Dg65fRgL.js","./litegraphUtil-B_WxWXjg.js","./map--HGZfCRO.js","./appInstance-CiT6CpGM.js","./inputSpecTree-B0INjagH.js","./shuffle-CnBsCH60.js","./treeUtil-4aExWhwq.js","./executionErrorStore-MSMBxScr.js","./settingStore-DRRi2kOn.js","./delay-Cu8bS1zn.js","./api-BdJmXw98.js","./requestAuth-COoKVLz2.js","./zod.gen-DzuaBm8H.js","./vendor-axios-QnwcNXlY.js","./requestTimeout-DkmiEk-h.js","./vendor-firebase-B37L--zT.js","./dialogService-CqZr0BhP.js","./Button-CcqmlVQb.js","./src-BHQtMnZc.js","./dialogStore-Dm9z8_kv.js","./DialogTitle-CWOHHLwH.js","./useCopyToClipboard-DUbSOtYA.js","./systemStatsStore-DAY0RqGT.js","./Input-12QxL1XI.js","./workflowStore-DP6mciq-.js","./storageIO-CAjGLygi.js","./colorPaletteTheme-BLTbQMIT.js","./canvasStore-Dnz7OWvY.js","./agentPanelStore-DndzlR19.js","./clamp-C6J77Y5a.js","./useFeatureFlags-B3zg5FdZ.js","./debounce-CrddqoI1.js","./nodeOutputStore-DmbNgTmp.js","./utils-DPLBHlcF.js","./downloadUtil-PDRccee-.js","./uniq-HSN5S90b.js","./deburr-BNFMXPzm.js","./queueSettingsStore-BzKxsLQU.js","./vendor-vueuse-ehQVlHrl.js","./sidebarTabStore-DSQyJJJG.js","./layerEditorDialogKey-j8nal3kA.js","./workflowFlattening-DY0Vs9rF.js","./executionStore-DSsREODN.js","./quick-lru-CwZ_Nev1.js","./modalUtil-Cmzr62_V.js","./TimeoutError-DBgma3uz.js","./useBillingContext-Cc-YANxo.js","./teamWorkspaceStore-BNm5cZOK.js","./ssoTelemetry-DZUrpShr.js","./telemetry-CRUTYyCh.js","./comfyApi-CXw0-V35.js","./desktopHostSession-B3KqJnXo.js","./ssoRequiredDialogKey-DRv9w9ql.js","./errors-Bls3VadO.js","./nodeDefStore-CF96GLZA.js","./authStore-D2cL6XhN.js","./types-t0xJOOCt.js","./cloudWebSessionStore-DQXLFlJm.js","./refreshRemoteConfig-CEuxp20e.js","./tierPricing-Dm5JzLf8.js","./creditsUtil-DxLnYjvD.js","./useAuthActions-CFn_-tF2.js","./workspaceStore-B8_lz1QF.js","./markdownRendererUtil-BJj2U6Nd.js","./extensionStore-CYnV6tYr.js","./useCurrentUser-DjJaVYwd.js","./useBillingCapabilities-x1h7nBmq.js","./floating-ui.vue-C9n4lp0q.js","./menuStyles-BC25qUwO.js","./app-CSsV1u1T.js","./constants-CcZ5JemZ.js","./Badge-BUm0jxSy.js","./types-Co7511Rq.js","./useBillingDialogs-Bc5B2YTn.js","./billingActionNames-DwcV6mOp.js","./billingDialogsAccess-BbNj81q5.js","./Card-lRVBegiG.js","./AppDialogPanel-BklaJBTn.js","./usePaymentRecoveryDialog-DeFBWQ7b.js","./FormNumberField-BP7-goH4.js","./NumberFieldInput-CUxTsNZT.js","./useExternalLink-Cd0Jpjd8.js","./envUtil-Cq1k2k7n.js","./useSubscriptionDialog-C4Ac2Pav.js","./subscriptionDialogAccess-Igw8sX_b.js","./useWorkspaceUI-CALMkHxF.js","./billingPlanTelemetry-CgeXQYDa.js","./pendingSubscriptionCheckout-CwZ4vFuG.js","./checkoutJourneyTelemetry-CznsrcWK.js","./getExecutionContext-aSfqv9_8.js","./categoryUtil-DZVfz29_.js","./usePartnerNodesRunGate-CDN3pb24.js","./useAuthDialogs-AEcL-pGe.js","./keybindingService-CtLOmFQk.js","./assetsStore-CNmOJwRQ.js","./assetMetadataUtils-IzKjxxiA.js","./cloudPreviewUtil-QoYZLRNr.js","./resultItemUrl-BV9Vi8QF.js","./hdrFormatUtil-rFvza1J0.js","./useChainCallback-Bm3zfHjO.js","./resolveWidgetValueAsset-lF2h5jqq.js","./usePopoverSizing-ux16dO36.js","./select.variants-BBeExFA3.js","./missingModelScan-R_tynz92.js","./imageUtil-D14xOjDk.js","./mathUtil-BWeg2vFD.js","./Load3dUtils-CF3OvEZx.js","./TagRemoveButton-DmMMh2ek.js","./Menu-iX8QWfwR.js","./Switch-CDfqeaPZ.js","./hostWhitelist-txsSSTbM.js","./Slider-Ba9vS1t0.js","./useWaveAudioPlayer-cIDEKkhR.js","./onboardingTourStore-CEYmTJQo.js","./workflowTabActivityStore-HmsDc5E8.js","./skillReferenceText-Dr3UZVuB.js","./types-CnYEnJ8O.js","./agentComposerStore-SD86Kbe6.js","./feedbackDialog-Ou8TLTOa.js","./TypeformEmbed-OFFtM2jP.js","./useTypeformEmbed-DHPmQvg5.js","./SanitizedHtml-kTDIrh6X.js","./Popover-Cjk42F0c.js","./PopoverContent-CJioRepA.js","./assetPreviewUtil-DBI8HYUU.js","./load3dViewerDialog-D35Ppx7u.js","./v4-B6IY9qUv.js","./Checkbox-CGtQ5Kkd.js","./RadioGroupItem-DF4cXT8y.js","./skillPacksStore-CvhjCUhU.js","./onboardingOverlayStore-bQGc_Pr0.js","./useAssetDownload-RlJRQus_.js","./vendor-tiptap-MlR23Fl9.js","./agentPanelRenderStore-B0tcH0mS.js","./agentApiSchema-BSP_VZP6.js","./opEnvelope-_VGDGUrC.js","./agentRunModeStore-BjKxXJD9.js","./AgentPanelRoot-Dueq4V7f.css"])))=>i.map(i=>d[i]);
import "./rolldown-runtime-xtsTai4I.js";
import { t as __vitePreload } from "./preload-helper-sJeoGctA.js";
import { F as createBaseVNode, Ft as ref, G as defineComponent, I as createBlock, J as h, Jt as normalizeStyle, Kt as normalizeClass, L as createCommentVNode, Mt as onScopeDispose, P as computed, R as createElementBlock, W as defineAsyncComponent, Wt as unref, ct as openBlock, it as onErrorCaptured, j as Teleport, p as storeToRefs, rt as onBeforeUnmount, xt as watchEffect } from "./vendor-vue-core-CuN1excl.js";
import { Mr as useWindowSize, ar as useEventListener } from "./vendor-reka-ui-NRTk7aIV.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { r as reportError } from "./reportError-BHgDVvfb.js";
import { t as useAgentPanelStore } from "./agentPanelStore-DndzlR19.js";
import { t as useAgentPanelRenderStore } from "./agentPanelRenderStore-B0tcH0mS.js";
import { t as useAgentRunModeStore } from "./agentRunModeStore-BjKxXJD9.js";
//#region src/composables/useWorkspaceInset.ts
/**
* Width consumed by docked surfaces on the right of the workspace.
*
* Body-portaled overlays center on the raw viewport, which diverges from the
* visible workspace once a docked surface takes layout width. They read this
* variable to offset themselves; docked surfaces declare it.
*/
var WORKSPACE_INSET_RIGHT = "--workspace-inset-right";
var insetPublishers = /* @__PURE__ */ new Map();
function publishCurrentInset() {
	const widths = [...insetPublishers.values()];
	if (widths.length === 0) {
		document.documentElement.style.removeProperty(WORKSPACE_INSET_RIGHT);
		return;
	}
	const width = Math.max(...widths);
	document.documentElement.style.setProperty(WORKSPACE_INSET_RIGHT, `${width}px`);
}
function useWorkspaceInsetRight(widthPx) {
	const publisher = Symbol();
	watchEffect(() => {
		insetPublishers.set(publisher, widthPx());
		publishCurrentInset();
	});
	onScopeDispose(() => {
		insetPublishers.delete(publisher);
		publishCurrentInset();
	});
}
//#endregion
//#region src/workbench/extensions/agent/components/agent/DockedAgentPanel.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = ["data-resizing"];
var _hoisted_2 = { class: "size-full overflow-hidden rounded-lg border" };
//#endregion
//#region src/workbench/extensions/agent/components/agent/DockedAgentPanel.vue
var DockedAgentPanel_default = /* @__PURE__ */ defineComponent({
	__name: "DockedAgentPanel",
	props: { hasOpaqueNeighbor: {
		type: Boolean,
		default: false
	} },
	setup(__props) {
		const AgentPanelLoadError = defineComponent({
			name: "AgentPanelLoadError",
			props: { onRetry: {
				type: Function,
				default: void 0
			} },
			setup(props) {
				const { t } = useI18n();
				return () => h("div", { class: "size-full bg-background p-3" }, [
					h("h2", {
						id: "agent-panel-title",
						class: "sr-only"
					}, t("agent.title")),
					h("p", { class: "text-sm text-foreground" }, t("agent.loadFailed")),
					props.onRetry && h(Button_default, {
						class: "mt-3",
						variant: "secondary",
						size: "sm",
						onClick: props.onRetry
					}, () => t("g.retry"))
				]);
			}
		});
		const agentPanelRenderStore = useAgentPanelRenderStore();
		agentPanelRenderStore.reach("root_unresolved");
		const AgentPanelRoot = defineAsyncComponent({
			loader: async () => {
				const panelRoot = await __vitePreload(() => import("./AgentPanelRoot-B-XQuFjq.js"), __vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167,168,169,170,171,172,173,174,175]), import.meta.url);
				agentPanelRenderStore.reach("root_resolved_not_mounted");
				return panelRoot;
			},
			errorComponent: AgentPanelLoadError,
			onError: (error, _retry, fail) => {
				reportError(error, {
					surface: "agent",
					errorType: "agent_panel_load_failure"
				});
				fail();
			}
		});
		const mountAttempt = ref(0);
		const mountFailed = ref(false);
		onErrorCaptured((error) => {
			if (agentPanelRenderStore.progress !== "root_resolved_not_mounted") return;
			reportError(error, {
				surface: "agent",
				errorType: "failure_mounting_agent_panel"
			});
			mountFailed.value = true;
			return false;
		});
		function retryMount() {
			mountFailed.value = false;
			mountAttempt.value++;
		}
		/** Set by the parent that lays out both this panel and its left neighbour. */
		const agentPanelStore = useAgentPanelStore();
		const { isVisible: docked, width, requestedWidth, isOverlay } = storeToRefs(agentPanelStore);
		const { width: viewportWidth } = useWindowSize();
		const panelWidth = computed(() => Math.min(isOverlay.value ? requestedWidth.value : width.value, viewportWidth.value));
		useWorkspaceInsetRight(() => docked.value && !isOverlay.value ? width.value : 0);
		useAgentRunModeStore().load().catch((error) => {
			reportError(error, {
				surface: "agent",
				errorType: "agent_run_mode_load_failure"
			});
		});
		const isResizing = ref(false);
		let resizeStartX = 0;
		let resizeStartWidth = 0;
		function onResizeStart(e) {
			isResizing.value = true;
			resizeStartX = e.clientX;
			resizeStartWidth = agentPanelStore.width;
			e.currentTarget.setPointerCapture(e.pointerId);
			e.preventDefault();
		}
		useEventListener(document, "pointermove", (e) => {
			if (!isResizing.value) return;
			agentPanelStore.setWidth(resizeStartWidth + (resizeStartX - e.clientX));
		});
		function stopResizing() {
			isResizing.value = false;
		}
		useEventListener(document, "pointerup", stopResizing);
		useEventListener(document, "pointercancel", stopResizing);
		onBeforeUnmount(stopResizing);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(Teleport, {
				to: "body",
				disabled: !unref(isOverlay)
			}, [unref(docked) ? (openBlock(), createElementBlock("div", {
				key: 0,
				"data-testid": "docked-agent-panel",
				role: "complementary",
				"aria-labelledby": "agent-panel-title",
				class: normalizeClass(unref(cn)("docked-agent-panel pointer-events-auto shrink-0 overflow-hidden [anchor-name:--docked-agent-panel]", unref(isOverlay) ? "fixed inset-y-0 right-0 z-1100 max-w-full bg-background shadow-lg" : "relative h-full")),
				style: normalizeStyle({ width: `${panelWidth.value}px` })
			}, [!unref(isOverlay) ? (openBlock(), createElementBlock("div", {
				key: 0,
				"data-testid": "agent-panel-resize-handle",
				class: "absolute top-0 left-0 z-10 h-full w-[5px] cursor-col-resize transition-colors delay-300 duration-200 hover:bg-primary data-[resizing=true]:bg-primary",
				"data-resizing": isResizing.value,
				onPointerdown: onResizeStart,
				onLostpointercapture: _cache[0] || (_cache[0] = ($event) => isResizing.value = false)
			}, null, 40, _hoisted_1)) : createCommentVNode("", true), createBaseVNode("div", {
				"data-testid": "docked-agent-panel-shell",
				class: normalizeClass(unref(cn)("size-full p-2", __props.hasOpaqueNeighbor && "border-l border-border bg-background"))
			}, [createBaseVNode("div", _hoisted_2, [mountFailed.value ? (openBlock(), createBlock(unref(AgentPanelLoadError), {
				key: 0,
				"on-retry": retryMount
			})) : (openBlock(), createBlock(unref(AgentPanelRoot), { key: mountAttempt.value }))])], 2)], 6)) : createCommentVNode("", true)], 8, ["disabled"]);
		};
	}
});
//#endregion
export { DockedAgentPanel_default as default };
