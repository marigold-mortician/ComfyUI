import "./rolldown-runtime-xtsTai4I.js";
import { G as defineComponent, I as createBlock, U as createVNode, Wt as unref, ct as openBlock, dt as renderSlot, et as mergeProps, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { J as RadioGroupItem_default$1, Mn as useForwardPropsEmits, Rr as reactiveOmit, Y as RadioGroupRoot_default, q as RadioGroupIndicator_default } from "./vendor-reka-ui-NRTk7aIV.js";
import { t as cn } from "./src-BHQtMnZc.js";
//#endregion
//#region src/components/ui/radio-group/RadioGroup.vue
var RadioGroup_default = /* @__PURE__ */ defineComponent({
	__name: "RadioGroup",
	props: {
		modelValue: {},
		defaultValue: {},
		disabled: { type: Boolean },
		orientation: {},
		dir: {},
		loop: { type: Boolean },
		asChild: { type: Boolean },
		as: {},
		name: {},
		required: { type: Boolean },
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	},
	emits: ["update:modelValue"],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emits = __emit;
		const forwarded = useForwardPropsEmits(reactiveOmit(props, "class"), emits);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(RadioGroupRoot_default), mergeProps(unref(forwarded), {
				"data-slot": "radio-group",
				class: unref(cn)("flex gap-2", props.class)
			}), {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
				_: 3
			}, 16, ["class"]);
		};
	}
});
//#endregion
//#region src/components/ui/radio-group/RadioGroupItem.vue
var RadioGroupItem_default = /* @__PURE__ */ defineComponent({
	__name: "RadioGroupItem",
	props: {
		id: {},
		value: {},
		disabled: { type: Boolean },
		asChild: { type: Boolean },
		as: {},
		name: {},
		required: { type: Boolean },
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	},
	emits: ["select"],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emits = __emit;
		const forwarded = useForwardPropsEmits(reactiveOmit(props, "class"), emits);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(RadioGroupItem_default$1), mergeProps(unref(forwarded), {
				"data-slot": "radio-group-item",
				class: unref(cn)("inline-flex size-4 shrink-0 cursor-pointer items-center justify-center rounded-full border bg-transparent outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:border-primary", props.class)
			}), {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default", {}, () => [createVNode(unref(RadioGroupIndicator_default), { class: "size-2 rounded-full bg-primary" })])]),
				_: 3
			}, 16, ["class"]);
		};
	}
});
//#endregion
export { RadioGroup_default as n, RadioGroupItem_default as t };
