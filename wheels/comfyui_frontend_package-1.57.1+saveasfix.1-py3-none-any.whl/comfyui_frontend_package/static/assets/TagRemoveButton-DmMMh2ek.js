import "./rolldown-runtime-xtsTai4I.js";
import { F as createBaseVNode, G as defineComponent, I as createBlock, Kt as normalizeClass, Wt as unref, ct as openBlock, dt as renderSlot, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { i as cva, t as Button_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
//#region packages/design-system/src/tag.variants.ts
var tagVariants = cva({
	base: "inline-flex h-6 max-w-full shrink-0 items-center justify-center gap-1 text-xs ring-offset-background backdrop-blur-sm data-[selected=true]:ring-2 data-[selected=true]:ring-foreground data-[selected=true]:ring-offset-1 data-[state=active]:ring-2 data-[state=active]:ring-foreground data-[state=active]:ring-offset-1 [&.ProseMirror-selectednode]:ring-2 [&.ProseMirror-selectednode]:ring-foreground [&.ProseMirror-selectednode]:ring-offset-1",
	variants: {
		shape: {
			square: "rounded-sm bg-muted",
			rounded: "rounded-full bg-secondary",
			overlay: "rounded-sm bg-zinc-500/40 text-white/90"
		},
		state: {
			default: "text-foreground",
			unselected: "text-muted-foreground opacity-70",
			selected: "text-foreground"
		},
		removable: {
			true: "py-1 pr-1 pl-2",
			false: "px-2 py-1"
		},
		interactive: {
			true: "cursor-pointer transition-colors focus-within:ring-2 focus-within:ring-ring focus-within:ring-offset-1 hover:bg-accent focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-1 focus-visible:outline-none aria-disabled:cursor-not-allowed aria-disabled:opacity-50",
			false: ""
		}
	},
	defaultVariants: {
		shape: "square",
		state: "default",
		removable: false,
		interactive: false
	}
});
var tagRemoveButtonVariants = cva({ base: "w-4 overflow-hidden transition-[opacity,width] duration-150 hover:bg-transparent hover:opacity-100 data-disabled:pointer-events-none data-disabled:w-0 data-disabled:opacity-0" });
//#endregion
//#region src/components/chip/TagRemoveButton.vue
var TagRemoveButton_default = /* @__PURE__ */ defineComponent({
	__name: "TagRemoveButton",
	props: {
		tooltip: {},
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	},
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createBlock(Button_default, {
				tooltip: __props.tooltip,
				type: "button",
				variant: "textonly",
				size: "icon-sm",
				class: normalizeClass(unref(cn)(unref(tagRemoveButtonVariants)(), "opacity-60", __props.class))
			}, {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default", {}, () => [_cache[0] || (_cache[0] = createBaseVNode("i", {
					class: "icon-[lucide--x] size-4",
					"aria-hidden": "true"
				}, null, -1))])]),
				_: 3
			}, 8, ["tooltip", "class"]);
		};
	}
});
//#endregion
export { tagRemoveButtonVariants as n, tagVariants as r, TagRemoveButton_default as t };
