import "./rolldown-runtime-xtsTai4I.js";
import { F as createBaseVNode, G as defineComponent, H as createTextVNode, I as createBlock, U as createVNode, Yt as toDisplayString, ct as openBlock, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
import { t as AppDialogPanel_default } from "./AppDialogPanel-BklaJBTn.js";
//#region src/platform/workspace/components/dialogs/InviteLinkInvalidDialogContent.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "m-0 text-sm text-muted-foreground" };
//#endregion
//#region src/platform/workspace/components/dialogs/InviteLinkInvalidDialogContent.vue
var InviteLinkInvalidDialogContent_default = /* @__PURE__ */ defineComponent({
	__name: "InviteLinkInvalidDialogContent",
	setup(__props) {
		const dialogStore = useDialogStore();
		function onDismiss() {
			dialogStore.closeDialog({ key: "invite-link-invalid" });
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(AppDialogPanel_default, { onClose: onDismiss }, {
				title: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.inviteLinks.invalidTitle")), 1)]),
				footer: withCtx(() => [createVNode(Button_default, {
					variant: "secondary",
					size: "lg",
					onClick: onDismiss
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.inviteLinks.invalidDismiss")), 1)]),
					_: 1
				})]),
				default: withCtx(() => [createBaseVNode("p", _hoisted_1, toDisplayString(_ctx.$t("workspacePanel.inviteLinks.invalidBody")), 1)]),
				_: 1
			});
		};
	}
});
//#endregion
export { InviteLinkInvalidDialogContent_default as default };
