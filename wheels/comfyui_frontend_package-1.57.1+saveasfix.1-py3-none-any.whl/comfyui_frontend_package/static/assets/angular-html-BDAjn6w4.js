import { t as angular_html_default } from "./angular-html-BO2YKhTr.js";
export { angular_html_default as default };
