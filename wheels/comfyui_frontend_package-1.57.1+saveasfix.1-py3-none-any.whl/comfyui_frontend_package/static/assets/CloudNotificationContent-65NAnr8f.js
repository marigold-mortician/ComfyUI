import "./rolldown-runtime-xtsTai4I.js";
import { F as createBaseVNode, G as defineComponent, H as createTextVNode, I as createBlock, O as Fragment, R as createElementBlock, U as createVNode, Wt as unref, Yt as toDisplayString, at as onMounted, ct as openBlock, ut as renderList, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { n as useTelemetry } from "./telemetry-IkzvF0TI.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
import { t as DialogTitle_default } from "./DialogTitle-CWOHHLwH.js";
import { t as Card_default } from "./Card-lRVBegiG.js";
import "./cloud-subscription-OUnxVHxA.js";
//#region src/platform/cloud/notification/components/CloudNotificationContent.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "col-span-3 flex flex-col justify-between p-8" };
var _hoisted_2 = { class: "flex flex-col gap-4 text-sm" };
var _hoisted_3 = { class: "m-0 text-muted-foreground" };
var _hoisted_4 = { class: "mt-6 flex flex-col items-start gap-0 self-stretch" };
var _hoisted_5 = { class: "text-sm" };
var _hoisted_6 = { class: "flex flex-col gap-2 pt-8" };
var _hoisted_7 = { class: "m-0 text-center text-xs text-muted-foreground" };
//#endregion
//#region src/platform/cloud/notification/components/CloudNotificationContent.vue
var CloudNotificationContent_default = /* @__PURE__ */ defineComponent({
	__name: "CloudNotificationContent",
	setup(__props) {
		const { t } = useI18n();
		onMounted(() => {
			useTelemetry()?.trackUiButtonClicked({
				button_id: "cloud_notification_modal_impression",
				element_group: "cloud_notification"
			});
		});
		function onDismiss() {
			useTelemetry()?.trackUiButtonClicked({
				button_id: "cloud_notification_continue_locally_clicked",
				element_group: "cloud_notification"
			});
			useDialogStore().closeDialog();
		}
		function onExplore() {
			useTelemetry()?.trackUiButtonClicked({
				button_id: "cloud_notification_explore_cloud_clicked",
				element_group: "cloud_notification"
			});
			const params = new URLSearchParams({
				utm_source: "desktop",
				utm_medium: "onload-modal",
				utm_campaign: "local-to-cloud-conversion",
				utm_id: "desktop-onload-modal",
				utm_source_platform: "mac-desktop"
			});
			window.open(`https://comfy.org/cloud/?${params}`, "_blank", "noopener,noreferrer");
			useDialogStore().closeDialog();
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(Card_default, {
				"data-testid": "cloud-notification-dialog",
				class: "relative grid h-full w-170 max-w-full grid-cols-5 shadow-lg"
			}, {
				default: withCtx(() => [
					createVNode(Button_default, {
						size: "unset",
						variant: "muted-textonly",
						class: "absolute top-2.5 right-2.5 z-10 size-8 rounded-full p-0 text-white hover:bg-white/20",
						"aria-label": unref(t)("g.close"),
						onClick: onDismiss
					}, {
						default: withCtx(() => [..._cache[0] || (_cache[0] = [createBaseVNode("i", { class: "pi pi-times" }, null, -1)])]),
						_: 1
					}, 8, ["aria-label"]),
					_cache[2] || (_cache[2] = createBaseVNode("div", { class: "relative col-span-2 flex items-center justify-center overflow-hidden rounded-sm" }, [createBaseVNode("video", {
						autoplay: "",
						loop: "",
						muted: "",
						playsinline: "",
						class: "ml-[-20%] h-full min-w-5/4 object-cover"
					}, [createBaseVNode("source", {
						src: "" + new URL("images/cloud-subscription.webm", import.meta.url).href,
						type: "video/webm"
					})])], -1)),
					createBaseVNode("div", _hoisted_1, [createBaseVNode("div", null, [createBaseVNode("div", _hoisted_2, [createVNode(DialogTitle_default, { class: "m-0 text-sm" }, {
						default: withCtx(() => [createTextVNode(toDisplayString(unref(t)("cloudNotification.title")), 1)]),
						_: 1
					}), createBaseVNode("p", _hoisted_3, toDisplayString(unref(t)("cloudNotification.message")), 1)]), createBaseVNode("div", _hoisted_4, [(openBlock(), createElementBlock(Fragment, null, renderList([
						2,
						3,
						4
					], (n) => {
						return createBaseVNode("div", {
							key: n,
							class: "flex items-center gap-2 py-2"
						}, [_cache[1] || (_cache[1] = createBaseVNode("i", { class: "pi pi-check text-xs" }, null, -1)), createBaseVNode("span", _hoisted_5, toDisplayString(unref(t)(`cloudNotification.feature${n}Title`)), 1)]);
					}), 64))])]), createBaseVNode("div", _hoisted_6, [
						createVNode(Button_default, {
							variant: "primary",
							size: "lg",
							class: "w-full font-bold",
							onClick: onExplore
						}, {
							default: withCtx(() => [createTextVNode(toDisplayString(unref(t)("cloudNotification.exploreCloud")), 1)]),
							_: 1
						}),
						createVNode(Button_default, {
							variant: "textonly",
							size: "sm",
							class: "w-full",
							onClick: onDismiss
						}, {
							default: withCtx(() => [createTextVNode(toDisplayString(unref(t)("cloudNotification.continueLocally")), 1)]),
							_: 1
						}),
						createBaseVNode("p", _hoisted_7, toDisplayString(unref(t)("cloudNotification.footer")), 1)
					])])
				]),
				_: 1
			});
		};
	}
});
//#endregion
export { CloudNotificationContent_default as default };
