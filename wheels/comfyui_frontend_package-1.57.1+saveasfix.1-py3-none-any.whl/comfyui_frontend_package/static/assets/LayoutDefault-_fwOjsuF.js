import { t as LayoutDefault_default } from "./LayoutDefault-BOlQyQBw.js";
export { LayoutDefault_default as default };
