const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./markdownEditor-BLiFIQ-V.js","./rolldown-runtime-xtsTai4I.js","./vendor-tiptap-MlR23Fl9.js","./missingModelMetadata-DQjewTyg.js","./missingModelMetadata-PzEamVTZ.js","./vendor-vue-core-CuN1excl.js","./formatUtil-DsZFGVbT.js","./reportError-BHgDVvfb.js","./hostTelemetryEnabled-DM7ML37c.js","./remoteConfig-VmmsGxJZ.js","./vendor-reka-ui-NRTk7aIV.js","./vendor-sentry-zSXGkMPN.js","./errorUtil-DoQyAUQC.js","./sidebarTabStore-DSQyJJJG.js","./commandStore-XD_i1hej.js","./iteratee-D-xtYlr8.js","./cloneDeep-BX7AjX4w.js","./globalThis-B6Vbq1EF.js","./get-Bk-Y8oEe.js","./isObject-BDwzDI3k.js","./useErrorHandling-WrECc0C0.js","./toastStore-Dg65fRgL.js","./i18n-BRluoVl-.js","./preload-helper-sJeoGctA.js","./vendor-i18n-pA_PV1p-.js","./commands-C9zyhK6Q.js","./main-BtaRoPyL.js","./nodeDefs-BUEI64H3.js","./settings-B3DInspu.js","./envUtil-Cq1k2k7n.js"])))=>i.map(i=>d[i]);
import { r as __name } from "./rolldown-runtime-xtsTai4I.js";
import { t as __vitePreload } from "./preload-helper-sJeoGctA.js";
import { s as SUPPORTED_MESH_EXTENSIONS } from "./constants-CcZ5JemZ.js";
import { T as keyBy, a as copyToClipspace, c as useSubgraphNavigationStore, d as useCanvasScheduler, f as toolkit, h as omit, i as clipspace, l as provideLitegraphService, m as pick, o as pasteFromClipspace, r as ChangeTracker, u as useLitegraphServiceAccess, y as zip } from "./appModeStore-C3kEWkI2.js";
import { $t as VueOnlyWidget, At as ensureNonZeroUuid, B as hasActivePromotedWidgetConsumer, Ct as useLinkStore, D as isMiddleButtonHeld, E as isMiddleButtonEvent, En as snapPoint, F as ExecutableNodeDTO, Gt as usePreviewExposureStore, H as resolveConcretePromotedWidget, In as remove, Jt as createMutationView, Kt as nextUniqueName, Ln as partition, N as reorderSubgraphInputs, Nt as graphScopeOf, O as isMiddlePointerInput, P as SubgraphNode, Pn as once, Q as getCnrIdFromProperties, Qt as defineDeprecatedProperty, Sn as measureViewportFromElement, Tn as createBounds, V as resolveActivePromotedWidgetConsumers, Vt as LayoutSource, Wt as getPreviewExposureHostLocator, Xt as toConcreteWidget, Y as LGraphNode, Yt as isComboWidget$1, Z as getCnrIdFromNode, Zt as LegacyWidget, an as SUBGRAPH_INPUT_ID, bt as replaceNodeInputs, dn as withGraphIntentSource, en as BaseWidget, fn as deriveWidgetSurfaces, ft as inputAsSerialisable, g as CANVAS_CLIPBOARD_KEY, h as CANVAS_CLIPBOARD_ID_KEY, ht as inputLink, it as NodeInputSlot, j as normalizeSubgraphDefinitionIds, k as LGraph, kn as clamp, ln as useWidgetValueStore, mt as captureInputLayout, n as LGraphCanvas, nt as Reroute, pt as outputAsSerialisable, q as selectedCanvasNodes, qt as wasWidgetRefused, rt as NodeOutputSlot, t as LiteGraph, tn as commonType, vn as widgetId, vt as outputLinkIds, w as useLayoutMutations, xn as applyViewport, z as buildPromotedWidgetExecutionSources } from "./litegraph-DsPnoImk.js";
import { n as useKeybindingStore, o as groupBy, r as KeybindingImpl, t as useCommandStore } from "./commandStore-XD_i1hej.js";
import { _ as migrateWidgetsValues, c as isAudioNode, d as isLGraphNode, h as isVideoOutput, l as isImageNode, m as isVideoNode, n as compressWidgetInputSlots, p as isSelectOnly, r as executeWidgetsCallback, s as isAnimatedOutput, t as addToComboValues, u as isLGraphGroup, v as resolveComboValues } from "./litegraphUtil-8EMdlR16.js";
import { s as uniq } from "./treeUtil-4aExWhwq.js";
import { a as updatePendingWarnings, c as useMissingModelStore, n as useMissingNodesErrorStore, o as useMissingMediaStore, t as useExecutionErrorStore } from "./executionErrorStore-DzGUJU_L.js";
import { M as useFreeTierQuota, t as useBillingContext } from "./useBillingContext-uo5ceiak.js";
import { n as useSettingStore } from "./settingStore-DRRi2kOn.js";
import { t as clamp$1 } from "./clamp-C6J77Y5a.js";
import { j as normalizePromptError, n as useDialogService } from "./dialogService-CqZr0BhP.js";
import { t as cloneDeep } from "./cloneDeep-BX7AjX4w.js";
import { n as createSharedObjectUrl, o as createAnnotatedPath, r as releaseSharedObjectUrl, s as parseAnnotatedPath, t as useNodeOutputStore } from "./nodeOutputStore-Dec5oA1b.js";
import { l as DEPLOYMENT_LISTING_NO_HINT_WAIT_MS, s as DEPLOYMENT_LISTING_BACKSTOP_MS, t as useTeamWorkspaceStore } from "./teamWorkspaceStore-BNm5cZOK.js";
import { t as isObject } from "./isObject-BDwzDI3k.js";
import { h as zNodePackMetadata, i as api, l as validateComfyWorkflow, n as PromptExecutionError, s as zResultItem, u as zClipboardItems } from "./api-BdJmXw98.js";
import { $ as mergeModels, B as createSlots, E as withModifiers, F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, I as createBlock, It as shallowReactive, Jt as normalizeStyle, Kt as normalizeClass, L as createCommentVNode, Nt as reactive, O as Fragment, P as computed, R as createElementBlock, Rt as shallowRef, U as createVNode, Wt as unref, Yt as toDisplayString, _t as useModel, bt as watch, ct as openBlock, d as defineStore, dt as renderSlot, et as mergeProps, ut as renderList, wt as withCtx, z as createPropsRestProxy, zt as toRaw } from "./vendor-vue-core-CuN1excl.js";
import { $t as ComboboxEmpty_default, Jt as ComboboxTrigger_default, Qt as ComboboxInput_default, Tr as useResizeObserver, Xr as whenever, Xt as ComboboxItemIndicator_default, Yt as ComboboxPortal_default, Zt as ComboboxItem_default, ar as useEventListener, en as ComboboxContent_default, nn as ComboboxRoot_default, qt as ComboboxViewport_default, rn as injectComboboxRootContext, tn as ComboboxAnchor_default, tr as useElementBounding, wn as FocusScope_default } from "./vendor-reka-ui-NRTk7aIV.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { n as useWorkflowStore, r as ComfyWorkflow, s as defaultGraph } from "./workflowStore-ChkUx7Si.js";
import { n as useApp, t as registerApp } from "./appInstance-CiT6CpGM.js";
import { n as useTelemetry } from "./telemetry-IkzvF0TI.js";
import { S as object, T as string, a as _enum, k as url, t as fromZodError, x as number } from "./vendor-zod-Del_rmdp.js";
import { r as axios } from "./vendor-axios-QnwcNXlY.js";
import { t as isHostTelemetryEnabled } from "./hostTelemetryEnabled-DM7ML37c.js";
import { t as useToast } from "./toastStore-Dg65fRgL.js";
import { a as resolveNodeDefSlotText, c as setBackendNodeText, d as t, l as st, o as resolveNodeDefText } from "./i18n-BRluoVl-.js";
import { T as normalizeI18nKey, f as generateUUID } from "./formatUtil-DsZFGVbT.js";
import { i as addBreadcrumb } from "./vendor-sentry-zSXGkMPN.js";
import { c as getDatadogRum, r as reportError } from "./reportError-BHgDVvfb.js";
import { t as getErrorMessage } from "./errorUtil-DoQyAUQC.js";
import { a as GET_CONFIG, r as toLinkId } from "./rerouteId-1TDIYZkX.js";
import { t as Badge_default } from "./Badge-BUm0jxSy.js";
import { t as useErrorHandling } from "./useErrorHandling-WrECc0C0.js";
import { $ as toNodeId, C as isMissingCandidateActive, E as mapUniqueNodes, G as isNodeLocatorId, J as tryNormalizeNodeExecutionId, L as isSubgraph, S as isExecutionPathActive, U as getAncestorExecutionIds, Y as UNASSIGNED_NODE_ID, Z as parseNodeId, _ as getNodeByLocatorId, b as isAncestorPathActive, g as getNodeByExecutionId, j as triggerCallbackOnAllNodes, l as forEachNode, n as collectFromNodes, p as getExecutionIdByNode, t as collectAllNodes, x as isCandidateScopeActive } from "./graphTraversalUtil-BUK1cr2m.js";
import { i as LGraphEventMode, l as RenderShape } from "./globalEnums-BPoISudO.js";
import { t as assert } from "./assert--qJvwrYk.js";
import { c as resolveNodeRootGraphId, i as findComboValueIndex, o as getWidgetIds } from "./widget-TCRFSGUe.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
import { i as visibleCanvasViewport, n as useCanvasStore, o as getWorkflowMode, t as providePromoteRecommendedWidgets } from "./canvasStore-siYzI5aT.js";
import { n as ServerFeatureFlag, t as useFeatureFlags } from "./useFeatureFlags-B3zg5FdZ.js";
import { C as zDynamicComboInputSpec, D as zMatchTypeOptions, c as transformInputSpecV2ToV1, d as getInputSpecType, m as isComboInputSpecV2, p as isComboInputSpecV1, s as transformInputSpecV1ToV2, v as zAutogrowOptions, w as zDynamicGroupInputSpec } from "./inputSpecTree-B0INjagH.js";
import { a as resolveDynamicInputSpec, g as isBlueprintType, h as BLUEPRINT_TYPE_PREFIX, i as useNodeDefStore, s as promotedInputSource, t as SYSTEM_NODE_DEFS, u as ComfyNodeDefImpl } from "./nodeDefStore-dfke_cvJ.js";
import { i as openFileInNewTab, n as downloadFile } from "./downloadUtil-PDRccee-.js";
import { o as $el, t as clone } from "./utils-DPLBHlcF.js";
import { n as useBottomPanelStore, t as useWorkspaceStore } from "./workspaceStore-CA_rc-fs.js";
import { d as partnerNodeTokens, f as useApiKeyAuthStore, r as useAuthStore } from "./authStore-D2cL6XhN.js";
import { a as isDesktopHostSignedIn, n as desktopHostUser, r as desktopHostWorkspaceToken } from "./desktopHostSession-B3KqJnXo.js";
import { a as useWorkflowService, o as useDomWidgetStore } from "./useAuthActions-_rhVfmiU.js";
import { t as useExtensionStore } from "./extensionStore-CYnV6tYr.js";
import { a as parseFlattenableSubgraphDefinitions, r as collectSubgraphDefinitions, t as buildSubgraphExecutionPaths } from "./workflowFlattening-DY0Vs9rF.js";
import { a as resolveAccountPrecondition, i as useJobPreviewStore, n as useExecutionStore } from "./executionStore-DrU24oQb.js";
import { t as useCurrentUser } from "./useCurrentUser-DjJaVYwd.js";
import { i as normalizeExecutionTriggerSource, r as TelemetryEvents } from "./types-Co7511Rq.js";
import { t as useBillingDialogs } from "./useBillingDialogs-CYngXWQg.js";
import { t as getExecutionContext } from "./getExecutionContext-D9Siyc8N.js";
import { t as partnerRunGateBlocksAutoQueue } from "./usePartnerNodesRunGate-Bl8OMNN4.js";
import { t as useAuthDialogs } from "./useAuthDialogs-C9YGTip0.js";
import { t as useKeybindingService } from "./keybindingService-CtLOmFQk.js";
import { E as useModelToNodeStore, M as readDeploymentHint, N as assetFilenameSchema, O as useDeploymentPickStore, P as assetItemSchema, T as assetService, g as provideExtensionService, j as hasDeploymentLink, t as useAssetsStore } from "./assetsStore-CzSfkgjN.js";
import { t as useChainCallback } from "./useChainCallback-Bm3zfHjO.js";
import { a as isUploadableVideo, c as isColorInputSpec, d as isGalleriaInputSpec, f as isIntInputSpec, h as isTextareaInputSpec, i as isExtensionlessVideo, l as isComboInputSpec, m as isStringInputSpec, n as ACCEPTED_IMAGE_TYPES, o as isBooleanInputSpec, p as isResolutionPreviewInputSpec, r as ACCEPTED_VIDEO_TYPES, s as isChartInputSpec, t as resolveWidgetValueAsset, u as isFloatInputSpec } from "./resolveWidgetValueAsset-CCylptbe.js";
import { n as useAttrsClass, r as useSelectSearch, t as usePopoverSizing } from "./usePopoverSizing-ux16dO36.js";
import { a as selectItemVariants, i as selectEmptyMessageClass, n as selectCountBadgeClass, o as selectTriggerVariants, r as selectDropdownClass, s as stopEscapeToDocument, t as selectContentClass } from "./select.variants-BBeExFA3.js";
import { d as registerComboWidgetInventory, i as scanAllModelCandidates, n as hasPendingVerification, o as verifyAssetSupportedCandidates, s as resolvePromotedWidgetSource, t as enrichWithEmbeddedMetadata } from "./missingModelScan-zIBS2S8n.js";
import { c as getAssetFilename } from "./assetMetadataUtils-IzKjxxiA.js";
import { a as isHdrImageFilename, n as getImageFileUrl, t as getHdrPreviewUrl } from "./hdrFormatUtil-rFvza1J0.js";
import { r as is_all_same_aspect_ratio, t as fitDimensionsToNodeWidth } from "./imageUtil-B67VHiUy.js";
import { t as anyItemOverlapsRect } from "./mathUtil-BWeg2vFD.js";
import { t as Load3dUtils } from "./Load3dUtils-CF3OvEZx.js";
//#region src/composables/element/useCanvasPositionConversion.ts
var sharedConverter = null;
/**
* Convert between canvas and client positions
* @param canvasElement - The canvas element
* @param lgCanvas - The litegraph canvas
* @returns The canvas position conversion functions
*/
var useCanvasPositionConversion = (canvasElement, lgCanvas) => {
	const { left, top, update } = useElementBounding(canvasElement);
	const clientPosToCanvasPos = (pos) => {
		const { offset, scale } = lgCanvas.ds;
		return [(pos[0] - left.value) / scale - offset[0], (pos[1] - top.value) / scale - offset[1]];
	};
	const canvasPosToClientPos = (pos) => {
		const { offset, scale } = lgCanvas.ds;
		return [(pos[0] + offset[0]) * scale + left.value, (pos[1] + offset[1]) * scale + top.value];
	};
	return {
		clientPosToCanvasPos,
		canvasPosToClientPos,
		update
	};
};
function useSharedCanvasPositionConversion() {
	if (sharedConverter) return sharedConverter;
	const lgCanvas = useCanvasStore().getCanvas();
	sharedConverter = useCanvasPositionConversion(lgCanvas.canvas, lgCanvas);
	return sharedConverter;
}
//#endregion
//#region src/renderer/core/canvas/cameraState.ts
var defaultScaleRange = {
	minScale: .1,
	maxScale: 10
};
function normalizeCameraState(value, { minScale, maxScale } = defaultScaleRange) {
	if (!value || typeof value !== "object" || !("offset" in value) || !("scale" in value) || typeof value.offset !== "object" || value.offset === null) return null;
	if ("0" in value.offset && "1" in value.offset && typeof value.offset[0] === "number" && Number.isFinite(value.offset[0]) && typeof value.offset[1] === "number" && Number.isFinite(value.offset[1]) && typeof value.scale === "number" && Number.isFinite(value.scale) && value.scale > 0) return {
		offset: [value.offset[0], value.offset[1]],
		scale: clamp$1(value.scale, minScale, maxScale)
	};
	return null;
}
//#endregion
//#region src/platform/telemetry/perf/perfMark.ts
/**
* Thin performance instrumentation primitives.
*
* The browser Performance API records the marks and measures for local
* inspection. Callers retain the returned measurements for structured reports.
* Sentry breadcrumbs are a secondary consumer so a startup error carries the
* phase timings that preceded it.
*/
var NOOP_PERF_SPAN = {
	startMs: 0,
	stop: () => 0
};
/**
* Begin a named performance span.
*
* Records a `performance.mark('<name>:start')`. Calling `stop()` records
* `performance.mark('<name>:end')` + `performance.measure('<name>', ...)`,
* adds a Sentry breadcrumb, and returns the elapsed milliseconds. Repeat
* `stop()` calls return the first measured duration without re-recording.
*
* @example
* const span = perfMark('bootstrap/object-info')
* await this.getNodeDefs()
* const ms = span.stop()
*/
function perfMark(name) {
	const startName = `${name}:start`;
	const endName = `${name}:end`;
	try {
		performance.mark(startName);
		const startMs = performance.now();
		let durationMs;
		return {
			startMs,
			stop() {
				if (durationMs !== void 0) return durationMs;
				try {
					performance.mark(endName);
					durationMs = _measure(name, startName, endName, startMs);
					_emitToSentry(name, durationMs);
					return durationMs;
				} catch {
					durationMs = 0;
					return 0;
				}
			}
		};
	} catch {
		return NOOP_PERF_SPAN;
	}
}
/**
* Mark a single point-in-time milestone (no duration).
*/
function perfPoint(name) {
	try {
		performance.mark(name);
		_emitToSentry(name, 0);
	} catch {
		return;
	}
}
/**
* Measure from the navigation time origin to now and return the elapsed ms.
*/
function perfMeasureSinceOrigin(name) {
	const durationMs = performance.now();
	try {
		performance.measure(name, {
			start: 0,
			end: durationMs
		});
	} catch {
		return durationMs;
	}
	_emitToSentry(name, durationMs);
	return durationMs;
}
function _measure(name, startName, endName, fallbackStart) {
	try {
		return performance.measure(name, startName, endName).duration;
	} catch {
		return performance.now() - fallbackStart;
	}
}
function _emitToSentry(name, durationMs) {
	try {
		addBreadcrumb({
			category: "perf",
			message: name,
			level: "info",
			data: { duration_ms: durationMs }
		});
	} catch {
		return;
	}
}
//#endregion
//#region src/platform/telemetry/perf/bootstrapTracer.ts
/**
* Structured performance tracing for the app startup/bootstrap sequence.
*
* Each phase maps to one of the known bottlenecks from profiling:
*
*   Phase                          | Typical range (cloud, Lighthouse)
*   ───────────────────────────────┼──────────────────────────────────
*   startup/entry-modules          | variable  (time origin → bootstrap(): HTML + static imports)
*   startup/remote-config          | ~0–0.5 s  (pre-Firebase, blocking)
*   startup/telemetry-init         | ~0–0.3 s
*   startup/local-auth             | non-cloud (local web or desktop host session)
*   startup/firebase-init          | ~0–0.1 s
*   startup/router                 | ~0 s      (route table; cloud routes import)
*   startup/sentry-init            | ~0–0.1 s
*   auth-gate/initialized          | variable  (Firebase session restore + timeout/retry)
*   auth-gate/user-store           | ~0–2.5 s  (GET /api/user/*)
*   auth-gate/needs-login          | ~0 s      (computed resolution)
*   bootstrap/settings             | ~0.2 s    (parallel, non-blocking)
*   bootstrap/workflows            | ~0.3 s    (parallel, non-blocking)
*   bootstrap/i18n                 | parallel  (custom node translations)
*   bootstrap/graph-view-chunk     | variable  (lazy GraphView route import)
*   bootstrap/new-user             | ~0 s      (new-user defaults)
*   bootstrap/extensions-load      | ~0.5 s    (fetch + import /extensions JS)
*     ├ extensions-load-core       | subset    (core entry-point import)
*     └ extensions-load-custom     | subset    (backend-provided extension imports)
*   bootstrap/deployment-pick      | cloud     (deployment lookup)
*   bootstrap/sync-workflows       | ~0 s      (workflow store sync)
*   bootstrap/extensions-init      | ~0.3 s    (extension.init() hooks)
*   bootstrap/object-info          | ~0.7 s    (GET /api/object_info)
*   bootstrap/extensions           | ~0.5 s    (addCustomNodeDefs + registerCustomNodes)
*   bootstrap/vue-node-defs        | ~0.1 s    (node def store update)
*   bootstrap/extensions-setup     | ~0.5 s    (extension.setup() hooks)
*   bootstrap/workflow-restore     | ~0.3 s    (initial workflow, tabs, URL template)
*
* The two `extensions-load-*` rows are nested inside `extensions-load` rather
* than replacing it: the aggregate stays intact for the existing monitors, and
* the residual (aggregate minus both children) is `api.getExtensions()` plus
* bookkeeping. So read the children and the residual against the aggregate —
* never sum rows across the flattened phase map, which would double-count
* extension load time.
*
* These children add two to `phase_count` when both run, so thresholds based
* on the old count must shift. Each duration is rounded independently, so the
* residual can be off by a millisecond or two in either direction and can read
* negative on a fast load. The phase map carries only the rounded values.
*
* Startup ends when the loading screen comes down, not when any one subsystem
* finishes. `complete()` is therefore called from the single place that owns
* that transition (`GraphCanvas`'s onMounted `finally`), so the trace covers
* the extension and object-info phases that run inside `ComfyApp.setup()` and
* so a startup that threw still reports. A startup that never gets there is
* reported by `armWatchdog()`, armed from `main.ts` before blocking startup
* work begins.
*
* Usage:
*   import { bootstrapTracer } from '@/platform/telemetry/perf/bootstrapTracer'
*
*   await bootstrapTracer.settle('bootstrap/object-info', () => this.getNodeDefs())
*/
/**
* Startup past this is abnormal by any reading — the slowest healthy cloud
* load profiled is ~5 s, and the reports that prompted this instrumentation
* were minutes.
*/
var BOOTSTRAP_WATCHDOG_MS = 3e4;
function toRumTimingName(name) {
	return name.replace(/\//g, ".");
}
function untracedMs(rows, totalMs) {
	let tracedMs = 0;
	let coveredUntil = 0;
	for (const { startMs, durationMs } of rows) {
		const endMs = Math.min(startMs + durationMs, totalMs);
		tracedMs += Math.max(0, endMs - Math.max(startMs, coveredUntil));
		coveredUntil = Math.max(coveredUntil, endMs);
	}
	return totalMs - tracedMs;
}
var BootstrapTracer = class {
	_spans = /* @__PURE__ */ new Map();
	_timings = [];
	_completed = false;
	_outcome;
	_timeoutReported = false;
	_watchdog;
	/**
	* Start timing a phase. Returns a handle; call `.stop()` when complete.
	* Calling startPhase for the same phase twice is safe (second call is a no-op
	* and returns the existing span's handle).
	*/
	startPhase(phase) {
		if (this._spans.has(phase)) return { stop: () => 0 };
		this._spans.set(phase, perfMark(phase));
		return { stop: () => this._stopPhase(phase) };
	}
	_stopPhase(phase) {
		const span = this._spans.get(phase);
		if (!span) return 0;
		this._spans.delete(phase);
		const durationMs = span.stop();
		this._publishRumTiming(phase);
		this._timings.push({
			name: phase,
			startMs: Math.round(span.startMs),
			durationMs: Math.round(durationMs)
		});
		return durationMs;
	}
	/**
	* Time `work` and record the phase whether it resolves or rejects, then
	* re-settle exactly as `work` did.
	*
	* A phase stopped only on the success path goes unrecorded precisely when
	* startup went wrong, so the surviving sessions are the fast ones and every
	* percentile reads better than reality.
	*/
	async settle(phase, work) {
		const span = this.startPhase(phase);
		try {
			return await work();
		} finally {
			span.stop();
		}
	}
	/**
	* Record a phase that began at the navigation time origin, such as the
	* static module graph evaluated before any startup code can run.
	*/
	recordSinceTimeOrigin(phase) {
		const durationMs = perfMeasureSinceOrigin(phase);
		this._publishRumTiming(phase);
		this._timings.push({
			name: phase,
			startMs: 0,
			durationMs: Math.round(durationMs)
		});
	}
	/**
	* Record a named milestone with no duration (e.g. "app shell mounted").
	*/
	milestone(name) {
		const milestoneName = `bootstrap/milestone/${name}`;
		perfPoint(milestoneName);
		this._publishRumTiming(milestoneName);
	}
	_publishRumTiming(name) {
		getDatadogRum()?.addTiming(toRumTimingName(name));
	}
	/**
	* Completed phases, in the order they started.
	*
	* Built from what this tracer measured rather than re-scanned out of
	* `performance.getEntriesByType('measure')`: that buffer is shared with
	* every other measure in the app and can be cleared by anyone.
	*/
	summary() {
		return [...this._timings].sort((a, b) => a.startMs - b.startMs);
	}
	get outcome() {
		return this._outcome ?? "pending";
	}
	/**
	* Close out startup: stop any phase still open, emit one aggregate event
	* carrying total wall-clock and the per-phase breakdown, and log the trace
	* locally. Idempotent — only the first call reports.
	*/
	complete(outcome = "completed") {
		if (this._completed) return;
		this._completed = true;
		this._outcome = outcome;
		clearTimeout(this._watchdog);
		for (const phase of Array.from(this._spans.keys())) this._stopPhase(phase);
		this._report(outcome);
	}
	/**
	* Report startup as still running if it has not completed by `deadlineMs`.
	*
	* A session that hangs never reaches `complete()`, so without this the loads
	* users actually report — the ones that spin for minutes — are the only ones
	* that produce no data at all. The watchdog row does not end the trace: the
	* terminal row still follows if startup eventually finishes.
	*/
	armWatchdog(deadlineMs = BOOTSTRAP_WATCHDOG_MS) {
		clearTimeout(this._watchdog);
		if (this._completed || this._timeoutReported) return;
		this._watchdog = setTimeout(() => {
			if (this._completed || this._timeoutReported) return;
			this._timeoutReported = true;
			this._report("timed_out", [...this._spans.keys()]);
		}, deadlineMs);
	}
	suspendWatchdog() {
		clearTimeout(this._watchdog);
		this._watchdog = void 0;
	}
	resumeWatchdog() {
		if (!this._completed && this._watchdog === void 0) this.armWatchdog();
	}
	_report(outcome, pending) {
		try {
			const totalMs = Math.round(performance.now());
			const rows = this.summary();
			const metadata = {
				total_ms: totalMs,
				outcome,
				phase_count: rows.length,
				untraced_ms: untracedMs(rows, totalMs),
				phases: Object.fromEntries(rows.map((r) => [r.name, r.durationMs])),
				...pending?.length ? { pending } : {}
			};
			getDatadogRum()?.addAction(TelemetryEvents.BOOTSTRAP_COMPLETE, metadata);
			useTelemetry()?.trackBootstrapComplete(metadata);
			if (outcome === "completed") getDatadogRum()?.setViewLoadingTime();
			this._logSummary(rows, totalMs);
		} catch {
			return;
		}
	}
	/**
	* Log the startup summary to the console in a compact table.
	* Only emits in dev or when DEBUG_PERF is set.
	*/
	_logSummary(rows, totalMs) {
		if (localStorage.getItem("DEBUG_PERF") !== "true") return;
		if (rows.length === 0) return;
		console.warn("[Bootstrap] Startup trace\n" + rows.map((r) => `  ${r.startMs}ms  ${r.name}: ${r.durationMs}ms`).join("\n") + `\n  Total wall-clock: ${totalMs}ms\n  Untraced: ${untracedMs(rows, totalMs)}ms`);
	}
};
/** Singleton tracer — import and use directly. */
var bootstrapTracer = new BootstrapTracer();
//#endregion
//#region src/platform/telemetry/nodeAdded/nodeAddSource.ts
var currentSource = "unknown";
function getCurrentNodeAddSource() {
	return currentSource;
}
/**
* Set the node-add source for the duration of `fn`. Synchronous only —
* the source is read by the synchronous LGraph.onNodeAdded callback that
* fires inside `graph.add()`. Nesting restores the previous value on exit.
*/
function withNodeAddSource(source, fn) {
	const previous = currentSource;
	currentSource = source;
	try {
		return fn();
	} finally {
		currentSource = previous;
	}
}
//#endregion
//#region src/platform/telemetry/nodeAdded/installNodeAddedTelemetry.ts
/**
* Wire `app:node_added_to_workflow` telemetry into a graph. Bulk additions
* during workflow load are skipped — `workflow_imported` already covers those.
*/
function installNodeAddedTelemetry(graph) {
	graph.events.addEventListener("node:added", ({ detail: { node } }) => {
		if (ChangeTracker.isLoadingGraph) return;
		useTelemetry()?.trackNodeAdded({
			node_type: node.type,
			source: getCurrentNodeAddSource()
		});
	});
}
//#endregion
//#region src/platform/telemetry/utils/groupMissingNodesByPack.ts
var UNKNOWN_PACK_ID = "unknown";
function groupMissingNodesByPack(missingNodes) {
	const byPack = /* @__PURE__ */ new Map();
	for (const node of missingNodes) {
		const type = typeof node === "string" ? node : node.type;
		const packId = typeof node === "string" ? UNKNOWN_PACK_ID : node.cnrId || UNKNOWN_PACK_ID;
		const existing = byPack.get(packId);
		if (existing) existing.add(type);
		else byPack.set(packId, /* @__PURE__ */ new Set([type]));
	}
	return Array.from(byPack, ([pack_id, types]) => ({
		pack_id,
		node_types: Array.from(types)
	}));
}
//#endregion
//#region src/platform/telemetry/utils/workflowExecutionContext.ts
function toWorkflowExecutionContext(executionContext, { executableNodeCount, executionScope, viewMode }) {
	return {
		workflow_type: executionContext.is_template ? "template" : "custom",
		view_mode: viewMode,
		execution_scope: executionScope,
		total_node_count: executionContext.total_node_count,
		executable_node_count: executableNodeCount,
		custom_node_count: executionContext.custom_node_count,
		api_node_count: executionContext.api_node_count,
		subgraph_count: executionContext.subgraph_count
	};
}
//#endregion
//#region src/platform/assets/schemas/mediaAssetSchema.ts
var zMediaKindSchema = _enum([
	"video",
	"audio",
	"image",
	"3D",
	"text",
	"other"
]);
var zDimensionsSchema = object({
	width: number().positive(),
	height: number().positive()
});
assetItemSchema.extend({
	kind: zMediaKindSchema,
	src: url(),
	duration: number().nonnegative().optional(),
	dimensions: zDimensionsSchema.optional()
});
object({
	type: _enum(["input", "output"]),
	outputCount: number().positive().optional()
});
var MediaAssetKey = Symbol("mediaAsset");
var MIME_ASSET_INFO = "application/x-comfy-asset-info";
var zDraggedAssetInfo = zResultItem.and(object({
	attachment_ref: string().min(1).optional(),
	media_kind: zMediaKindSchema.optional(),
	preview_url: url().optional(),
	media_url: url().optional()
}));
function parseAssetInfo(dataTransfer) {
	const assetString = dataTransfer.getData(MIME_ASSET_INFO);
	try {
		return zDraggedAssetInfo.safeParse(JSON.parse(assetString)).data;
	} catch {}
}
//#endregion
//#region src/platform/workflow/core/utils/restoreDynamicGroupInputs.ts
function restoreDynamicGroupInputs(node, inputs) {
	const definition = useNodeDefStore().fromLGraphNode(node);
	const names = /* @__PURE__ */ new Map();
	const restoredCombos = /* @__PURE__ */ new Set();
	const groups = [];
	function restore(specs, prefix = "") {
		for (const [key, spec] of Object.entries({
			...specs.required,
			...specs.optional
		})) {
			const name = `${prefix}${key}`;
			const controller = node.widgets?.find((widget) => widget.name === name);
			if (!controller) continue;
			const combo = zDynamicComboInputSpec.safeParse(spec).data;
			if (combo) {
				const selected = combo[1].options.find((option) => option.key === inputs[name]);
				if (selected) {
					controller.value = selected.key;
					controller.callback?.(selected.key);
					restoredCombos.add(name);
					restore(selected.inputs, `${name}.`);
				}
				continue;
			}
			const group = zDynamicGroupInputSpec.safeParse(spec).data;
			if (!group) continue;
			groups.push(name);
			restoreRows(name, {
				...group[1].template.required,
				...group[1].template.optional
			}, controller);
		}
	}
	function restoreRows(name, fields, controller) {
		const rows = /* @__PURE__ */ new Map();
		for (const input of Object.keys(inputs)) {
			if (!input.startsWith(`${name}.`)) continue;
			const suffix = input.slice(name.length + 1);
			const separator = suffix.indexOf(".");
			if (separator === -1) continue;
			const index = suffix.slice(0, separator);
			const field = suffix.slice(separator + 1);
			if (!/^(0|[1-9][0-9]*)$/.test(index) || !Object.hasOwn(fields, field)) continue;
			if (!rows.has(index)) rows.set(index, rows.size);
			names.set(input, `${name}.${rows.get(index)}.${field}`);
		}
		controller.value = rows.size;
	}
	if (definition) restore(definition.input);
	return Object.fromEntries(Object.entries(inputs).filter(([name]) => !restoredCombos.has(name) && (names.has(name) || !groups.some((group) => name === group || name.startsWith(`${group}.`)))).map(([name, value]) => [names.get(name) ?? name, value]));
}
//#endregion
//#region src/utils/linkFixer.ts
function isLiveGraph(graph) {
	return "getNodeById" in graph;
}
function getNodeById(graph, id) {
	if (isLiveGraph(graph)) {
		const parsedNodeId = parseNodeId(id);
		return parsedNodeId ? graph.getNodeById(parsedNodeId) : null;
	}
	return graph.nodes.find((node) => node.id == id);
}
function outputLinkIdsOf(node, slot) {
	const slotData = node.outputs?.[slot];
	if (!slotData) return void 0;
	if (!(slotData instanceof NodeOutputSlot)) return slotData.links ?? void 0;
	const { graph, id } = slotData.node;
	if (!graph) return void 0;
	const ids = outputLinkIds(graph, id, slot);
	return ids.length ? ids : void 0;
}
function extendLink(link) {
	return {
		link,
		id: link[0],
		origin_id: link[1],
		origin_slot: link[2],
		target_id: link[3],
		target_slot: link[4],
		type: link[5]
	};
}
/**
* Takes a ISerialisedGraph or live LGraph and inspects the links and nodes to ensure the linking
* makes logical sense. Can apply fixes when passed the `fix` argument as true.
*
* Note that fixes are a best-effort attempt. Seems to get it correct in most cases, but there is a
* chance it correct an anomaly that results in placing an incorrect link (say, if there were two
* links in the data). Users should take care to not overwrite work until manually checking the
* result.
*/
function fixBadLinks(graph, options = {}) {
	const { fix = false, silent = false, logger: _logger = console } = options;
	const logger = { log: (...args) => {
		if (!silent) _logger.log(...args);
	} };
	const patchedNodeSlots = {};
	const data = {
		patchedNodes: [],
		deletedLinks: []
	};
	/**
	* Internal patch node. We keep track of changes in patchedNodeSlots in case we're in a dry run.
	*/
	function patchNodeSlot(node, ioDir, slot, linkId, op) {
		const patchedNode = patchedNodeSlots[node.id] ?? {};
		patchedNodeSlots[node.id] = patchedNode;
		if (ioDir == 0) {
			patchedNode["inputs"] = patchedNode["inputs"] || {};
			if (patchedNode["inputs"][slot] !== void 0) {
				logger.log(` > Already set ${node.id}.inputs[${slot}] to ${patchedNode["inputs"][slot]} Skipping.`);
				return false;
			}
			const linkIdToSet = op === "REMOVE" ? null : linkId;
			const inputSlot = node.inputs?.[slot];
			if (fix && !inputSlot) {
				logger.log(` > Cannot patch ${node.id}.inputs[${slot}] because the input slot is missing.`);
				return false;
			}
			patchedNode["inputs"][slot] = linkIdToSet;
			if (fix && !(inputSlot instanceof NodeInputSlot)) {
				const writable = inputSlot;
				writable.link = linkIdToSet;
			}
		} else {
			patchedNode["outputs"] = patchedNode["outputs"] || {};
			patchedNode["outputs"][slot] = patchedNode["outputs"][slot] || {
				links: [...outputLinkIdsOf(node, slot) ?? []],
				changes: {}
			};
			if (patchedNode["outputs"][slot]["changes"][linkId] !== void 0) {
				logger.log(` > Already set ${node.id}.outputs[${slot}] to ${patchedNode["inputs"][slot]}! Skipping.`);
				return false;
			}
			patchedNode["outputs"][slot]["changes"][linkId] = op;
			if (op === "ADD") {
				if (patchedNode["outputs"][slot]["links"].indexOf(linkId) !== -1) {
					logger.log(` > Hmmm.. asked to add ${linkId} but it is already in list...`);
					return false;
				}
				patchedNode["outputs"][slot]["links"].push(linkId);
				if (fix && !(node.outputs?.[slot] instanceof NodeOutputSlot)) {
					node.outputs = node.outputs || [];
					const writable = node.outputs[slot] ??= {};
					writable.links = writable.links || [];
					writable.links.push(linkId);
				}
			} else {
				const linkIdIndex = patchedNode["outputs"][slot]["links"].indexOf(linkId);
				if (linkIdIndex === -1) {
					logger.log(` > Hmmm.. asked to remove ${linkId} but it doesn't exist...`);
					return false;
				}
				patchedNode["outputs"][slot]["links"].splice(linkIdIndex, 1);
				if (fix && !(node.outputs?.[slot] instanceof NodeOutputSlot)) (node.outputs?.[slot]).links?.splice(linkIdIndex, 1);
			}
		}
		data.patchedNodes.push(node);
		return true;
	}
	/**
	* Internal to check if a node (or patched data) has a linkId.
	*/
	function nodeHasLinkId(node, ioDir, slot, linkId) {
		let has;
		const patchedNode = patchedNodeSlots[node.id];
		if (ioDir === 0) {
			const nodeHasIt = node.inputs?.[slot]?.link === linkId;
			if (patchedNode?.inputs) {
				const patchedHasIt = patchedNode.inputs[slot] === linkId;
				if (fix && nodeHasIt !== patchedHasIt) throw Error("Error. Expected node to match patched data.");
				has = patchedHasIt;
			} else has = nodeHasIt;
		} else {
			const nodeHasIt = outputLinkIdsOf(node, slot)?.includes(toLinkId(linkId));
			const patchedOutput = patchedNode?.outputs?.[slot];
			if (patchedOutput?.changes[linkId]) {
				const patchedHasIt = patchedOutput.links.includes(linkId);
				if (fix && nodeHasIt !== patchedHasIt) throw Error("Error. Expected node to match patched data.");
				has = patchedHasIt;
			} else has = !!nodeHasIt;
		}
		return has;
	}
	/**
	* Internal to check if a node (or patched data) has a linkId.
	*/
	function nodeHasAnyLink(node, ioDir, slot) {
		let hasAny;
		const patchedNode = patchedNodeSlots[node.id];
		if (ioDir === 0) {
			const nodeHasAny = node.inputs?.[slot]?.link != null;
			if (patchedNode?.inputs) {
				const patchedHasAny = patchedNode.inputs[slot] != null;
				if (fix && nodeHasAny !== patchedHasAny) throw Error("Error. Expected node to match patched data.");
				hasAny = patchedHasAny;
			} else hasAny = nodeHasAny;
		} else {
			const nodeHasAny = outputLinkIdsOf(node, slot)?.length;
			const patchedOutput = patchedNode?.outputs?.[slot];
			if (patchedOutput?.changes) {
				const patchedHasAny = patchedOutput.links.length;
				if (fix && nodeHasAny !== patchedHasAny) throw Error("Error. Expected node to match patched data.");
				hasAny = !!patchedHasAny;
			} else hasAny = !!nodeHasAny;
		}
		return hasAny;
	}
	const linksReverse = [...isLiveGraph(graph) ? Array.from(graph.links.values()) : graph.links];
	linksReverse.reverse();
	for (const l of linksReverse) {
		if (!l) continue;
		const link = !Array.isArray(l) ? l : extendLink(l);
		const originNode = getNodeById(graph, link.origin_id);
		const originHasLink = () => nodeHasLinkId(originNode, 1, link.origin_slot, link.id);
		const patchOrigin = (op, id = link.id) => patchNodeSlot(originNode, 1, link.origin_slot, id, op);
		const targetNode = getNodeById(graph, link.target_id);
		const targetHasLink = () => nodeHasLinkId(targetNode, 0, link.target_slot, link.id);
		const targetHasAnyLink = () => nodeHasAnyLink(targetNode, 0, link.target_slot);
		const patchTarget = (op, id = link.id) => patchNodeSlot(targetNode, 0, link.target_slot, id, op);
		const originLog = `origin(${link.origin_id}).outputs[${link.origin_slot}].links`;
		const targetLog = `target(${link.target_id}).inputs[${link.target_slot}].link`;
		if (!originNode || !targetNode) {
			if (!originNode && !targetNode) logger.log(`Link ${link.id} is invalid, both origin ${link.origin_id} and target ${link.target_id} do not exist`);
			else if (!originNode) {
				logger.log(`Link ${link.id} is funky... origin ${link.origin_id} does not exist, but target ${link.target_id} does.`);
				if (targetHasLink()) {
					logger.log(` > [PATCH] ${targetLog} does have link, will remove the inputs' link first.`);
					patchTarget("REMOVE", -1);
				}
			} else if (!targetNode) {
				logger.log(`Link ${link.id} is funky... target ${link.target_id} does not exist, but origin ${link.origin_id} does.`);
				if (originHasLink()) {
					logger.log(` > [PATCH] Origin's links' has ${link.id}; will remove the link first.`);
					patchOrigin("REMOVE");
				}
			}
			continue;
		}
		if (targetHasLink() || originHasLink()) {
			if (!originHasLink()) {
				logger.log(`${link.id} is funky... ${originLog} does NOT contain it, but ${targetLog} does.`);
				logger.log(` > [PATCH] Attempt a fix by adding this ${link.id} to ${originLog}.`);
				patchOrigin("ADD");
			} else if (!targetHasLink()) {
				logger.log(`${link.id} is funky... ${targetLog} is NOT correct (is ${targetNode.inputs?.[link.target_slot]?.link}), but ${originLog} contains it`);
				if (!targetHasAnyLink()) {
					logger.log(` > [PATCH] ${targetLog} is not defined, will set to ${link.id}.`);
					if (!patchTarget("ADD")) {
						logger.log(` > [PATCH] Nvm, ${targetLog} already patched. Removing ${link.id} from ${originLog}.`);
						patchOrigin("REMOVE");
					}
				} else {
					logger.log(` > [PATCH] ${targetLog} is defined, removing ${link.id} from ${originLog}.`);
					patchOrigin("REMOVE");
				}
			}
		}
	}
	for (const l of linksReverse) {
		if (!l) continue;
		const link = !Array.isArray(l) ? l : extendLink(l);
		const originNode = getNodeById(graph, link.origin_id);
		const targetNode = getNodeById(graph, link.target_id);
		if ((!originNode || !nodeHasLinkId(originNode, 1, link.origin_slot, link.id)) && (!targetNode || !nodeHasLinkId(targetNode, 0, link.target_slot, link.id))) {
			logger.log(`${link.id} is def invalid; BOTH origin node ${link.origin_id} ${!originNode ? "is removed" : `doesn't have ${link.id}`} and ${link.origin_id} target node ${!targetNode ? "is removed" : `doesn't have ${link.id}`}.`);
			data.deletedLinks.push(link.id);
			continue;
		}
	}
	if (fix) {
		for (let i = data.deletedLinks.length - 1; i >= 0; i--) {
			logger.log(`Deleting link #${data.deletedLinks[i]}.`);
			if (isLiveGraph(graph)) graph._removeLink(toLinkId(data.deletedLinks[i]));
			else {
				const links = graph.links;
				const idx = links.findIndex((l) => l != null && (l[0] === data.deletedLinks[i] || "id" in l && l.id === data.deletedLinks[i]));
				if (idx === -1) logger.log(`INDEX NOT FOUND for #${data.deletedLinks[i]}`);
				logger.log(`splicing ${idx} from links`);
				links.splice(idx, 1);
			}
		}
		if (!isLiveGraph(graph)) graph.links = graph.links.filter((link) => link !== null);
	}
	if (!data.patchedNodes.length && !data.deletedLinks.length) return {
		hasBadLinks: false,
		fixed: false,
		graph,
		patched: data.patchedNodes.length,
		deleted: data.deletedLinks.length
	};
	logger.log(`${fix ? "Made" : "Would make"} ${data.patchedNodes.length || "no"} node link patches, and ${data.deletedLinks.length || "no"} stale link removals.`);
	const hasChanges = !!(data.patchedNodes.length || data.deletedLinks.length);
	let hasBadLinks = hasChanges;
	if (fix) hasBadLinks = fixBadLinks(graph, {
		fix: false,
		silent: true
	}).hasBadLinks;
	return {
		hasBadLinks,
		fixed: fix && hasChanges && !hasBadLinks,
		graph,
		patched: data.patchedNodes.length,
		deleted: data.deletedLinks.length
	};
}
//#endregion
//#region src/platform/workflow/validation/composables/useWorkflowValidation.ts
function useWorkflowValidation() {
	const toast = useToast();
	function tryFixLinks(graphData, options = {}) {
		const { silent = false } = options;
		const logs = [];
		const linkValidation = fixBadLinks(graphData, {
			fix: true,
			silent,
			logger: { log: (...args) => {
				logs.push(args.join(" "));
			} }
		});
		if (!silent && logs.length > 0) toast.warning(t("toastMessages.workflowValidationTitle"), { description: logs.join("\n") });
		if (linkValidation.fixed) {
			if (!silent) toast.success(t("toastMessages.workflowLinksFixedTitle"), { description: t("toastMessages.workflowLinksFixed", {
				patched: linkValidation.patched,
				deleted: linkValidation.deleted
			}) });
		}
		return linkValidation.graph;
	}
	/**
	* Validates a workflow, including link validation and schema validation
	*/
	async function validateWorkflow(graphData, options = {}) {
		const { silent = false } = options;
		let validatedData = null;
		const validatedGraphData = await validateComfyWorkflow(graphData, (err) => {
			if (!silent) toast.warning(err);
		});
		if (validatedGraphData) try {
			validatedData = tryFixLinks(validatedGraphData, { silent });
		} catch (err) {
			console.error(err);
		}
		return { graphData: validatedData };
	}
	return { validateWorkflow };
}
//#endregion
//#region src/scripts/domWidget.ts
function readDomWidgetValue(options) {
	const { getValue } = options;
	return (typeof getValue === "function" ? getValue.call(options) : null) ?? "";
}
function writeDomWidgetValue(options, value) {
	const { setValue } = options;
	if (typeof setValue === "function") setValue.call(options, value);
}
var isDOMWidget = (widget) => "element" in widget && !!widget.element;
var isComponentWidget = (widget) => "component" in widget && !!widget.component;
var BaseDOMWidgetImpl = class BaseDOMWidgetImpl extends LegacyWidget {
	static DEFAULT_MARGIN = 10;
	id;
	constructor(obj) {
		const { node, name, type, options } = obj;
		super({
			y: 0,
			name,
			type,
			options
		}, node);
		this.id = generateUUID();
	}
	get value() {
		return readDomWidgetValue(this.options);
	}
	set value(v) {
		writeDomWidgetValue(this.options, v);
		this.callback?.(this.value);
	}
	get margin() {
		return this.options.margin ?? BaseDOMWidgetImpl.DEFAULT_MARGIN;
	}
	isVisible() {
		return !this.hidden && !this.computedDisabled && this.node.isWidgetVisible(this);
	}
	draw(ctx, _node, widget_width, y, widget_height, lowQuality) {
		const isVisible = this.isVisible();
		if (this.options.hideOnZoom && lowQuality && isVisible) {
			const originalFillStyle = ctx.fillStyle;
			ctx.beginPath();
			ctx.fillStyle = LiteGraph.WIDGET_BGCOLOR;
			ctx.rect(this.margin, y + this.margin, widget_width - this.margin * 2, (this.computedHeight ?? widget_height) - 2 * this.margin);
			ctx.fill();
			ctx.fillStyle = originalFillStyle;
		} else if (!isVisible) {
			this.options.onDraw?.(this);
			return;
		}
		this.options.onDraw?.(this);
	}
	onRemove() {
		useDomWidgetStore().unregisterWidget(this.id);
	}
};
var DOMWidgetImpl = class extends BaseDOMWidgetImpl {
	element;
	constructor(obj) {
		super(obj);
		this.element = obj.element;
	}
	createCopyForNode(node) {
		const Widget = this.constructor;
		const cloned = new Widget({
			node,
			name: this.name,
			type: this.type,
			element: this.element,
			options: this.options
		});
		cloned.value = this.value;
		cloned.y = this.y;
		return cloned;
	}
	/** Extract DOM widget size info */
	computeLayoutSize() {
		if (this.type === "hidden") return {
			minHeight: 0,
			maxHeight: 0,
			minWidth: 0
		};
		const styles = getComputedStyle(this.element);
		let minHeight = this.options.getMinHeight?.() ?? parseInt(styles.getPropertyValue("--comfy-widget-min-height"));
		const maxHeight = this.options.getMaxHeight?.() ?? parseInt(styles.getPropertyValue("--comfy-widget-max-height"));
		const prefHeight = this.options.getHeight?.() ?? styles.getPropertyValue("--comfy-widget-height");
		if (!(typeof prefHeight === "string" && prefHeight.endsWith("%")) && isNaN(minHeight)) minHeight = typeof prefHeight === "number" ? prefHeight : parseInt(prefHeight);
		return {
			minHeight: isNaN(minHeight) ? 50 : minHeight,
			maxHeight: isNaN(maxHeight) ? void 0 : maxHeight,
			minWidth: 0
		};
	}
};
var ComponentWidgetImpl = class extends BaseDOMWidgetImpl {
	component;
	inputSpec;
	props;
	constructor(obj) {
		super({
			type: "custom",
			...obj
		});
		this.component = obj.component;
		this.inputSpec = obj.inputSpec;
		this.props = obj.props;
	}
	createCopyForNode(node) {
		const Widget = this.constructor;
		const cloned = new Widget({
			node,
			name: this.name,
			type: this.type,
			component: this.component,
			inputSpec: this.inputSpec,
			props: this.props,
			options: this.options
		});
		cloned.value = this.value;
		cloned.y = this.y;
		return cloned;
	}
	computeLayoutSize() {
		return {
			minHeight: this.options.getMinHeight?.() ?? 50,
			maxHeight: this.options.getMaxHeight?.(),
			minWidth: 0
		};
	}
	serializeValue() {
		return toRaw(this.value);
	}
};
var addWidget = (node, widget) => {
	node.addCustomWidget(widget);
	if (wasWidgetRefused(node, widget)) return;
	if (node.graph) useDomWidgetStore().registerWidget(widget);
	node.onAdded = useChainCallback(node.onAdded, () => {
		if (wasWidgetRefused(node, widget)) return;
		useDomWidgetStore().registerWidget(widget);
	});
	node.onRemoved = useChainCallback(node.onRemoved, () => {
		widget.onRemove?.();
	});
	node.onResize = useChainCallback(node.onResize, () => {
		widget.options.beforeResize?.call(widget, node);
		widget.options.afterResize?.call(widget, node);
	});
};
LGraphNode.prototype.addDOMWidget = function(name, type, element, options = {}) {
	const widget = new DOMWidgetImpl({
		node: this,
		name,
		type,
		element,
		options: {
			hideOnZoom: true,
			...options
		}
	});
	addWidget(this, widget);
	Object.defineProperty(widget, "value", {
		get() {
			return readDomWidgetValue(this.options);
		},
		set(v) {
			writeDomWidgetValue(this.options, v);
			this.callback?.(this.value);
		}
	});
	return widget;
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.domWidget = window.comfyAPI.domWidget || {};
window.comfyAPI.domWidget.isDOMWidget = isDOMWidget;
window.comfyAPI.domWidget.isComponentWidget = isComponentWidget;
window.comfyAPI.domWidget.DOMWidgetImpl = DOMWidgetImpl;
window.comfyAPI.domWidget.ComponentWidgetImpl = ComponentWidgetImpl;
window.comfyAPI.domWidget.addWidget = addWidget;
//#endregion
//#region src/platform/billing/subscription/composables/useAccountPreconditionDialog.ts
function useAccountPreconditionDialog() {
	const { showApiNodesSignInDialog } = useAuthDialogs();
	const { showSubscriptionRequiredDialog, showTopUpCreditsDialog } = useBillingDialogs();
	function open(precondition, context = {}) {
		switch (precondition) {
			case "sign_in":
				showApiNodesSignInDialog(context.nodeType ? [context.nodeType] : []);
				return;
			case "subscription":
				showSubscriptionRequiredDialog({ reason: context.source ?? "subscription_required" });
				return;
			case "credits": {
				const { fetchStatus, fetchBalance } = useBillingContext();
				Promise.allSettled([fetchStatus(), fetchBalance()]);
				showTopUpCreditsDialog({
					isInsufficientCredits: true,
					...context.source && { source: context.source }
				});
				return;
			}
		}
	}
	return { open };
}
//#endregion
//#region src/lib/litegraph/src/contextMenuCompat.ts
var LegacyMenuCompat = class {
	originalMethods = /* @__PURE__ */ new Map();
	hasWarned = /* @__PURE__ */ new Set();
	currentExtension = null;
	isExtracting = false;
	wrapperMethods = /* @__PURE__ */ new Map();
	preWrapperMethods = /* @__PURE__ */ new Map();
	wrapperInstalled = /* @__PURE__ */ new Map();
	/**
	* Set the name of the extension that is currently being set up.
	* This allows us to track which extension is monkey-patching.
	* @param extensionName The name of the extension
	*/
	setCurrentExtension(extensionName) {
		this.currentExtension = extensionName;
	}
	/**
	* Register a wrapper method that should NOT be treated as a legacy monkey-patch.
	* @param methodName The method name
	* @param wrapperFn The wrapper function
	* @param preWrapperFn The method that existed before the wrapper
	* @param prototype The prototype to verify wrapper installation
	*/
	registerWrapper(methodName, wrapperFn, preWrapperFn, prototype) {
		this.wrapperMethods.set(methodName, wrapperFn);
		this.preWrapperMethods.set(methodName, preWrapperFn);
		const isInstalled = prototype && prototype[methodName] === wrapperFn;
		this.wrapperInstalled.set(methodName, !!isInstalled);
	}
	/**
	* Install compatibility layer to detect monkey-patching
	* @param prototype The prototype to install on
	* @param methodName The method name to track
	*/
	install(prototype, methodName) {
		const originalMethod = prototype[methodName];
		this.originalMethods.set(methodName, originalMethod);
		let currentImpl = originalMethod;
		Object.defineProperty(prototype, methodName, {
			get() {
				return currentImpl;
			},
			set: (newImpl) => {
				if (!newImpl) return;
				const fnKey = `${methodName}:${newImpl.toString().slice(0, 100)}`;
				if (!this.hasWarned.has(fnKey) && this.currentExtension) {
					this.hasWarned.add(fnKey);
					console.warn(`%c[DEPRECATED]%c Monkey-patching ${methodName} is deprecated. (Extension: "${this.currentExtension}")\nPlease use the new context menu API instead.\n\nSee: https://docs.comfy.org/custom-nodes/js/context-menu-migration`, "color: orange; font-weight: bold", "color: inherit");
				}
				currentImpl = newImpl;
			}
		});
	}
	/**
	* Extract items that were added by legacy monkey patches.
	*
	* Uses set-based diffing by reference to reliably detect additions regardless
	* of item reordering or replacement. Items present in patchedItems but not in
	* originalItems (by reference equality) are considered additions.
	*
	* Note: If a monkey patch removes items (patchedItems has fewer unique items
	* than originalItems), a warning is logged but we still return any new items.
	*
	* @param methodName The method name that was monkey-patched
	* @param context The context to call methods with
	* @param args Arguments to pass to the methods
	* @returns Array of menu items added by monkey patches
	*/
	extractLegacyItems(methodName, context, ...args) {
		if (this.isExtracting) return [];
		const originalMethod = this.originalMethods.get(methodName);
		if (!originalMethod) return [];
		try {
			this.isExtracting = true;
			const originalItems = originalMethod.apply(context, args);
			if (!originalItems) return [];
			const currentMethod = context.constructor.prototype[methodName];
			if (!currentMethod || currentMethod === originalMethod) return [];
			const registeredWrapper = this.wrapperMethods.get(methodName);
			if (registeredWrapper && currentMethod === registeredWrapper) return [];
			const preWrapperMethod = this.preWrapperMethods.get(methodName);
			const wrapperWasInstalled = this.wrapperInstalled.get(methodName);
			const patchedItems = (preWrapperMethod && wrapperWasInstalled && currentMethod !== preWrapperMethod ? preWrapperMethod : currentMethod).apply(context, args);
			if (!patchedItems) return [];
			const createItemKey = (item) => {
				return [
					item.content ?? "",
					item.title ?? "",
					item.className ?? "",
					item.property ?? "",
					item.type ?? ""
				].join("|");
			};
			const originalKeys = new Set(originalItems.filter((item) => item !== null && typeof item === "object" && "content" in item).map(createItemKey));
			const addedItems = patchedItems.filter((item) => {
				if (item === null) return false;
				if (typeof item !== "object" || !("content" in item)) return false;
				return !originalKeys.has(createItemKey(item));
			});
			const patchedKeys = new Set(patchedItems.filter((item) => item !== null && typeof item === "object" && "content" in item).map(createItemKey));
			const removedCount = [...originalKeys].filter((key) => !patchedKeys.has(key)).length;
			if (removedCount > 0) console.warn(`[Context Menu Compat] Monkey patch for ${methodName} removed ${removedCount} original menu item(s). This may cause unexpected behavior.`);
			return addedItems;
		} catch (e) {
			console.error("[Context Menu Compat] Failed to extract legacy items:", e);
			return [];
		} finally {
			this.isExtracting = false;
		}
	}
};
var legacyMenuCompat = new LegacyMenuCompat();
//#endregion
//#region src/constants/coreMenuCommands.ts
var CORE_MENU_COMMANDS = [
	[[], ["Comfy.NewBlankWorkflow"]],
	[[], []],
	[["File"], ["Comfy.OpenWorkflow"]],
	[["File"], [
		"Comfy.SaveWorkflow",
		"Comfy.SaveWorkflowAs",
		"Comfy.ExportWorkflow",
		"Comfy.ExportWorkflowAPI"
	]],
	[["Edit"], ["Comfy.Undo", "Comfy.Redo"]],
	[["Edit"], [
		"Comfy.Canvas.CopySelected",
		"Comfy.Canvas.PasteFromClipboard",
		"Comfy.Canvas.SelectAll"
	]],
	[["Edit"], ["Comfy.ClearWorkflow"]],
	[["Edit"], ["Comfy.OpenClipspace"]],
	[["Edit"], ["Comfy.RefreshNodeDefinitions", ...["Comfy.Memory.UnloadModels", "Comfy.Memory.UnloadModelsAndExecutionCache"]]],
	[["View"], []],
	[["Help"], [
		"Comfy.Help.OpenComfyUIIssues",
		"Comfy.Help.OpenComfyUIDocs",
		"Comfy.Help.OpenComfyOrgDiscord",
		"Comfy.Help.OpenComfyUIForum"
	]],
	[["Help"], ["Comfy.Help.AboutComfyUI", "Comfy.ContactSupport"]]
];
//#endregion
//#region src/stores/menuItemStore.ts
var useMenuItemStore = defineStore("menuItem", () => {
	const canvasStore = useCanvasStore();
	const commandStore = useCommandStore();
	const menuItems = ref([]);
	const hasSeenLinear = ref(false);
	whenever(() => canvasStore.linearMode, () => hasSeenLinear.value = true, {
		immediate: true,
		once: true
	});
	const registerMenuGroup = (path, items) => {
		let currentLevel = menuItems.value;
		for (let i = 0; i < path.length; i++) {
			const segment = path[i];
			const foundIndex = currentLevel.findIndex((item) => item.label === segment);
			let found = currentLevel[foundIndex];
			if (foundIndex === -1) {
				found = {
					label: segment,
					key: segment,
					items: []
				};
				currentLevel.push(found);
			}
			if (!found.items) {
				const { checked, command, radioGroup, separator, ...metadata } = found;
				found = {
					...metadata,
					items: []
				};
				currentLevel[foundIndex] = found;
			}
			currentLevel = found.items;
		}
		if (currentLevel.length > 0) currentLevel.push({ separator: true });
		currentLevel.push(...items);
	};
	function commandIdToMenuItem(commandId) {
		const command = commandStore.getCommand(commandId);
		return {
			command: () => commandStore.execute(command.id),
			label: command.menubarLabel,
			icon: command.id === "Comfy.NewBlankWorkflow" ? void 0 : command.icon,
			tooltip: command.tooltip,
			commandId: command.id,
			checked: command.active,
			shortcut: () => command.keybinding?.combo.toString(),
			pressAndHoldInterval: command.id === "Comfy.Canvas.ZoomIn" || command.id === "Comfy.Canvas.ZoomOut" ? 50 : void 0,
			trailingIcon: command.id === "Comfy.NewBlankWorkflow" ? command.icon : void 0
		};
	}
	const registerCommands = (path, commandIds) => {
		const items = commandIds.map(commandIdToMenuItem);
		registerMenuGroup(path, items);
	};
	const loadExtensionMenuCommands = (extension) => {
		if (!extension.menuCommands) return;
		const extensionCommandIds = new Set(extension.commands?.map((command) => command.id) ?? []);
		extension.menuCommands.forEach((menuCommand) => {
			const commands = menuCommand.commands.filter((command) => extensionCommandIds.has(command));
			if (commands.length) registerCommands(menuCommand.path, commands);
		});
	};
	const registerCoreMenuCommands = () => {
		for (const [path, commands] of CORE_MENU_COMMANDS) registerCommands(path, commands);
	};
	return {
		menuItems,
		registerMenuGroup,
		registerCommands,
		loadExtensionMenuCommands,
		registerCoreMenuCommands,
		hasSeenLinear,
		commandIdToMenuItem
	};
});
//#endregion
//#region src/core/graph/widgets/dynamicGroupDiagnostics.ts
var controllers = /* @__PURE__ */ new WeakSet();
var reported = /* @__PURE__ */ new Set();
var remoteRowCountNode;
function markDynamicGroupController(widget) {
	controllers.add(widget);
}
/** True for the hidden widget whose value is a DynamicGroup's row count. */
function isDynamicGroupController(widget) {
	return controllers.has(widget);
}
/**
* Runs a remote row count write to `node`. A refusal on that node inside it is
* reported once, as the remote mismatch, not also as a local row change.
*/
function applyRemoteDynamicGroupRowCount(node, write) {
	const previous = remoteRowCountNode;
	remoteRowCountNode = node;
	try {
		write();
	} finally {
		remoteRowCountNode = previous;
	}
}
/** Whether a controller holds the row count its setter derives from `value`. */
function reachesDynamicGroupRowCount(widget, value) {
	if (typeof value !== "number" || !Number.isFinite(value)) return false;
	return widget.value === Math.max(widget.options.min ?? 0, Math.trunc(value));
}
function reportRowCount(node, operation, counts, report) {
	const key = `${report.errorType}:${node.type}:${operation}`;
	if (!isHostTelemetryEnabled() || reported.has(key)) return;
	reported.add(key);
	reportError(new Error(report.message), {
		errorType: report.errorType,
		surface: report.surface,
		level: report.level,
		tags: {
			...report.tags,
			node_type: node.type,
			operation,
			in_subgraph: isSubgraph(node.graph)
		},
		context: counts
	});
}
/** Reports a local DynamicGroup row change that left a different row count. */
function reportDynamicGroupRowRefusal(node, operation, requested, actual) {
	if (remoteRowCountNode === node) return;
	reportRowCount(node, operation, {
		requested,
		actual
	}, {
		message: "Refused a DynamicGroup row change",
		errorType: "failure_resizing_dynamic_group_rows",
		surface: "graph",
		level: "warning"
	});
}
/** Reports a remote DynamicGroup row count the live group did not reach. */
function reportRemoteDynamicGroupRowMismatch(node, requested, actual, tags) {
	reportRowCount(node, "remote_apply", {
		requested: typeof requested === "number" ? requested : null,
		actual
	}, {
		message: "Remote DynamicGroup row count did not apply",
		errorType: "agent_graph_dynamic_group_rows_mismatch",
		surface: "agent",
		tags
	});
}
//#endregion
//#region src/core/graph/widgets/dynamicGroupWidget.ts
function dynamicGroupWidget(node, inputName, inputData) {
	const { min, max, template, group_name = inputName } = zDynamicGroupInputSpec.parse(inputData)[1];
	const fields = {
		...template.required,
		...template.optional
	};
	const store = useWidgetValueStore();
	const { addNodeInput } = useLitegraphServiceAccess();
	const controller = node.addCustomWidget({
		name: inputName,
		type: "number",
		value: min,
		y: 0,
		hidden: true,
		options: {
			min,
			max,
			socketless: true,
			serialize: false
		}
	});
	markDynamicGroupController(controller);
	node.addCustomWidget(new DynamicGroupNoticeWidget({
		name: `${inputName}.$notice`,
		label: group_name,
		type: "dynamic_group_notice",
		value: void 0,
		y: 0,
		serialize: false,
		options: {
			socketless: true,
			serialize: false,
			surfaces: {
				canvas: "shown",
				vueNode: "never",
				panel: "never"
			}
		}
	}, node));
	const initialCount = controller.value;
	let rowCount = 0;
	const add = node.addCustomWidget({
		name: `${inputName}.$add`,
		label: t("dynamicGroup.add", { group: group_name }),
		type: "button",
		value: void 0,
		y: 0,
		serialize: false,
		options: {
			socketless: true,
			serialize: false,
			iconClass: "icon-[lucide--plus]",
			surfaces: {
				canvas: "never",
				vueNode: "shown",
				panel: "shown"
			}
		},
		callback: () => changeRows(() => {
			if (rows().length < max) controller.value = rows().length + 1;
		})
	});
	function rows() {
		return (node.widgets ?? []).filter((widget) => widget.type === "dynamic_group_row" && widget.name.startsWith(`${inputName}.`));
	}
	function publish() {
		const headers = rows();
		rowCount = headers.length;
		headers.forEach((header, index) => {
			header.label = t("dynamicGroup.row", {
				group: group_name,
				index: index + 1
			});
			header.options.disabled = headers.length <= min;
		});
		add.options.disabled = headers.length >= max;
		if (controller.widgetId) store.setValue(controller.widgetId, headers.length);
		const graphId = resolveNodeRootGraphId(node);
		if (graphId && node.widgets) store.setNodeWidgetOrder(graphId, node.id, getWidgetIds(node.widgets));
	}
	function changeRows(change) {
		const graph = node.graph;
		graph?.beforeChange();
		graph?.canvasAction((canvas) => canvas.emitBeforeChange());
		try {
			change();
			node.setSize([node.size[0], node.computeSize([...node.size])[1]]);
		} finally {
			graph?.afterChange();
			graph?.canvasAction((canvas) => canvas.emitAfterChange());
			node.setDirtyCanvas(true, true);
		}
	}
	function removeRow(index, hosts = createPromotionHostLookup()) {
		if (!node.widgets) return false;
		const prefix = `${inputName}.${index}`;
		const removed = node.widgets.filter((widget) => widget.name === prefix || widget.name.startsWith(`${prefix}.`));
		if (!removed.length) return false;
		if (!removeRowInputs(prefix, hosts)) return false;
		for (const widget of removed.reverse()) if (node.widgets.includes(widget)) node.removeWidget(widget);
		for (const header of rows()) {
			const oldPrefix = header.name;
			const row = Number(oldPrefix.slice(inputName.length + 1));
			if (row <= index) continue;
			renameRow(oldPrefix, `${inputName}.${row - 1}`, hosts);
		}
		return true;
	}
	function removeRowInputs(prefix, hosts) {
		const previous = captureInputLayout(node);
		const inputs = previous.inputs.filter((input) => !input.name.startsWith(`${prefix}.`));
		const graph = node.graph;
		const promotedInputs = new Set(previous.inputs.flatMap((input) => {
			const link = previous.links.get(input);
			return isSubgraph(graph) && !inputs.includes(input) && link?.origin_id === SUBGRAPH_INPUT_ID ? [graph.inputs[link.origin_slot]] : [];
		}));
		if (!replaceNodeInputs(node, previous, inputs, previous.links, true).ok) return false;
		for (const link of node.graph?.floatingLinks.values() ?? []) {
			if (link.target_id !== node.id) continue;
			const slot = inputs.indexOf(previous.inputs[link.target_slot]);
			if (slot === -1) node.graph?.removeFloatingLink(link);
			else link.target_slot = slot;
		}
		previous.inputs.forEach((input, slot) => {
			if (!inputs.includes(input)) node.onInputRemoved?.(slot, input);
		});
		if (isSubgraph(graph)) for (const input of promotedInputs) disconnectOrphanedPromotion(graph, graph.inputs.indexOf(input), hosts);
		return true;
	}
	function fieldLabel(index, field, row = t("dynamicGroup.row", {
		group: group_name,
		index: index + 1
	})) {
		return `${row} ${fields[field][1]?.display_name ?? field}`;
	}
	function renameRowLabels(oldIndex, newIndex, hosts, rowLabel) {
		for (const field of Object.keys(fields)) {
			const name = `${inputName}.${newIndex}.${field}`;
			const slot = node.findInputSlot(name);
			const input = slot === -1 ? void 0 : node.inputs[slot];
			const previous = input?.localized_name ?? fieldLabel(oldIndex, field, rowLabel);
			const next = fieldLabel(newIndex, field);
			const widget = node.widgets?.find((widget) => widget.name === name);
			if (widget?.label === previous) widget.label = next;
			if (!input) continue;
			if (input.label === previous) input.label = next;
			input.localized_name = next;
			renamePromotedInputLabel(node, slot, previous, next, hosts);
		}
	}
	function renameRowWidgets(oldPrefix, newPrefix) {
		for (const widget of node.widgets ?? []) {
			if (widget.name !== oldPrefix && !widget.name.startsWith(`${oldPrefix}.`)) continue;
			const name = newPrefix + widget.name.slice(oldPrefix.length);
			widget.name = name;
			if (widget.name === name && widget.serialize !== false && widget.type !== "button" && widget.widgetId) store.announceValue(widget.widgetId);
		}
	}
	function renameRow(oldPrefix, newPrefix, hosts) {
		const rowLabel = rows().find((row) => row.name === oldPrefix)?.label;
		renameRowWidgets(oldPrefix, newPrefix);
		for (const input of node.inputs) {
			if (!input.name.startsWith(`${oldPrefix}.`)) continue;
			input.name = newPrefix + input.name.slice(oldPrefix.length);
			if (input.widget) input.widget.name = input.name;
		}
		renameRowLabels(Number(oldPrefix.slice(inputName.length + 1)), Number(newPrefix.slice(inputName.length + 1)), hosts, rowLabel);
	}
	function addRow(index, hosts) {
		const previousSize = [...node.size];
		const start = node.widgets?.length ?? 0;
		const previous = captureInputLayout(node);
		const header = node.addCustomWidget({
			name: `${inputName}.${index}`,
			type: "dynamic_group_row",
			value: void 0,
			y: 0,
			serialize: false,
			options: {
				socketless: true,
				serialize: false,
				surfaces: {
					canvas: "never",
					vueNode: "shown",
					panel: "shown"
				}
			},
			callback: () => {
				if (rows().length <= min) return;
				changeRows(() => {
					const requested = rows().length - 1;
					if (!removeRow(Number(header.name.slice(inputName.length + 1)))) reportDynamicGroupRowRefusal(node, "remove_row", requested, rows().length);
					publish();
				});
			}
		});
		addRowFields(index, hosts);
		const addedInputs = node.inputs.splice(previous.inputs.length);
		const inputs = [...previous.inputs, ...addedInputs.filter((added) => !previous.inputs.some((input) => input.name === added.name))];
		if (!replaceNodeInputs(node, previous, inputs, previous.links).ok) {
			for (const widget of (node.widgets?.slice(start) ?? []).reverse()) node.removeWidget(widget);
			node.setSize(previousSize);
			return false;
		}
		for (const addedInput of addedInputs) {
			const existing = previous.inputs.find((input) => input.name === addedInput.name);
			if (existing) existing.widget = addedInput.widget;
		}
		const widgets = node.widgets;
		if (!widgets) return false;
		const added = widgets.splice(start);
		widgets.splice(widgets.indexOf(add), 0, ...added);
		return true;
	}
	function updateInputLabel(name, label, hosts) {
		const slot = node.findInputSlot(name);
		if (slot === -1) return;
		const input = node.inputs[slot];
		const previous = input.localized_name;
		if (!input.label || input.label === previous) input.label = label;
		input.localized_name = label;
		if (previous) renamePromotedInputLabel(node, slot, previous, label, hosts);
		return input;
	}
	function addRowFields(index, hosts) {
		for (const [fields, isOptional] of [[template.required, false], [template.optional, true]]) for (const [field, spec] of Object.entries(fields ?? {})) {
			const name = `${inputName}.${index}.${field}`;
			const refreshed = useNodeDefStore().getInputSpecForWidget(node, name);
			const fieldStart = node.widgets?.length ?? 0;
			addNodeInput(node, {
				...refreshed ?? transformInputSpecV1ToV2(spec, {
					name,
					isOptional
				}),
				display_name: fieldLabel(index, field)
			});
			const input = updateInputLabel(name, fieldLabel(index, field), hosts);
			let auxiliaryIndex = 0;
			node.widgets?.slice(fieldStart).forEach((widget) => {
				const options = widget.options;
				options.surfaces = {
					...deriveWidgetSurfaces(widget),
					canvas: "never"
				};
				widget.options = options;
				if (widget.name === name) {
					if (input?.label) widget.label = input.label;
					return;
				}
				widget.label ??= widget.name;
				widget.name = `${name}.${auxiliaryIndex++}`;
			});
		}
	}
	function announceAddedValues(existing) {
		for (const widget of node.widgets ?? []) if (!existing.has(widget) && widget.serialize !== false && widget.type !== "button" && widget.widgetId) store.announceValue(widget.widgetId);
	}
	function validateSavedRowCount(value, requested) {
		const graphId = resolveNodeRootGraphId(node);
		if (!graphId) return;
		const position = (node.widgets ?? []).filter((widget) => widget.serialize !== false).indexOf(controller);
		if (store.getRestoredWidgetValue(graphId, node.id, controller, position)?.value !== value) return;
		const savedValueCount = store.getRestoredWidgetValueCount(graphId, node.id);
		if (requested > Math.max(max, savedValueCount ?? 0)) throw new RangeError(`Invalid saved row count for DynamicGroup '${inputName}'`);
	}
	Object.defineProperty(controller, "value", {
		get: () => rowCount,
		set(value) {
			if (typeof value !== "number" || !Number.isFinite(value)) return;
			const requested = Math.max(0, Math.trunc(value));
			validateSavedRowCount(value, requested);
			const count = Math.max(min, requested);
			const hosts = createPromotionHostLookup();
			for (let index = rows().length - 1; index >= count; index--) if (!removeRow(index, hosts)) break;
			const existing = new Set(node.widgets);
			while (rows().length < count) if (!addRow(rows().length, hosts)) break;
			publish();
			announceAddedValues(existing);
			if (rowCount !== count) reportDynamicGroupRowRefusal(node, rowCount > count ? "remove_row" : "add_row", count, rowCount);
		}
	});
	controller.value = initialCount;
	return { widget: controller };
}
function createPromotionHostLookup() {
	let hosts;
	return (subgraph) => {
		if (!hosts) {
			hosts = /* @__PURE__ */ new Map();
			for (const host of mapUniqueNodes(subgraph.rootGraph, (node) => node.isSubgraphNode() ? node : void 0)) {
				const instances = hosts.get(host.subgraph) ?? [];
				instances.push(host);
				hosts.set(host.subgraph, instances);
			}
		}
		return hosts.get(subgraph) ?? [];
	};
}
function renamePromotedInputLabel(node, slot, previous, next, hosts) {
	const graph = node.graph;
	if (!isSubgraph(graph)) return;
	const link = inputLink(graph, node.id, slot);
	if (link?.origin_id !== SUBGRAPH_INPUT_ID) return;
	const promoted = graph.inputs[link.origin_slot];
	if (promoted.label !== previous) return;
	graph.renameInput(promoted, next);
	for (const host of hosts(graph)) renamePromotedInputLabel(host, link.origin_slot, previous, next, hosts);
}
function disconnectOrphanedPromotion(graph, slot, hosts) {
	if (!isSubgraph(graph) || graph.inputs[slot]?.linkIds.length !== 0) return;
	const input = graph.inputs[slot];
	for (const host of hosts(graph)) {
		removeFloatingHostLinks(host, slot);
		const link = host.graph && inputLink(host.graph, host.id, slot);
		if (!link) continue;
		host.disconnectInput(slot);
		if (link.origin_id === SUBGRAPH_INPUT_ID) disconnectOrphanedPromotion(host.graph, link.origin_slot, hosts);
	}
	graph.removeInput(input);
	if (!graph.inputs.includes(input)) removeFloatingLinksFrom(graph, slot);
}
function removeFloatingLinksFrom(graph, slot) {
	for (const link of graph.floatingLinks.values()) {
		if (link.origin_id !== SUBGRAPH_INPUT_ID) continue;
		if (link.origin_slot === slot) graph.removeFloatingLink(link);
		else if (link.origin_slot > slot) link.origin_slot--;
	}
}
function removeFloatingHostLinks(host, slot) {
	for (const link of host.graph?.floatingLinks.values() ?? []) if (link.target_id === host.id && link.target_slot === slot) host.graph?.removeFloatingLink(link);
}
var DynamicGroupNoticeWidget = class extends VueOnlyWidget {
	get vueOnlyLabel() {
		return this.label ?? this.name;
	}
};
//#endregion
//#region src/core/graph/widgets/dynamicWidgets.ts
function commitMutatedInputs(node, previous, assignments) {
	const finalInputs = [...node.inputs];
	node.inputs.splice(0, node.inputs.length, ...previous.inputs);
	return replaceNodeInputs(node, previous, finalInputs, assignments);
}
function syncNodeWidgetOrder(node) {
	const graphId = resolveNodeRootGraphId(node);
	if (!graphId || !node.widgets) return;
	useWidgetValueStore().setNodeWidgetOrder(graphId, node.id, getWidgetIds(node.widgets));
}
function ensureWidgetForInput(node, input) {
	node.widgets ??= [];
	const { widget } = input;
	if (widget && node.widgets.some((w) => w.name === widget.name)) return;
	node.widgets.push({
		draw(ctx, _n, _w, y) {
			ctx.save();
			ctx.fillStyle = LiteGraph.NODE_TEXT_COLOR;
			ctx.fillText(input.label ?? input.name, 20, y + 15);
			ctx.restore();
		},
		name: input.name,
		options: {},
		serialize: false,
		type: "shim",
		y: 0
	});
	input.alwaysVisible = true;
	input.widget = { name: input.name };
}
function dynamicComboWidget(node, inputName, untypedInputData, appArg, widgetName) {
	const { addNodeInput } = useLitegraphServiceAccess();
	const { deleteWidget } = useWidgetValueStore();
	const parseResult = zDynamicComboInputSpec.safeParse(untypedInputData);
	if (!parseResult.success) throw new Error("invalid DynamicCombo spec");
	const inputData = parseResult.data;
	const options = Object.fromEntries(inputData[1].options.map(({ key, inputs }) => [key, inputs]));
	const subSpec = [Object.keys(options), {}];
	const result = useApp().widgets.COMBO(node, inputName, subSpec, appArg, widgetName);
	assert(result && "widget" in result && result.widget, "COMBO widget constructor returned no widget");
	const { widget, minWidth, minHeight } = result;
	const removedWidgetValues = /* @__PURE__ */ new Map();
	let activeOption = widget.value;
	function isInGroup(e) {
		return e.name.startsWith(inputName + ".");
	}
	function restoreRemovedValues(value, widgetNames) {
		const widgets = node.widgets;
		if (!widgets) return;
		const graphId = resolveNodeRootGraphId(node);
		const removedValues = removedWidgetValues.get(value);
		const names = new Set(widgetNames);
		for (const name of removedValues?.keys() ?? []) names.add(name);
		for (const name of names) {
			const addedWidget = widgets.find((widget) => widget.name === name);
			if (!addedWidget) continue;
			const removed = removedValues?.get(name);
			const positionalIndex = widgets.filter((widget) => widget.serialize !== false).indexOf(addedWidget);
			if (!(graphId && positionalIndex >= 0 ? useWidgetValueStore().getRestoredWidgetValue(graphId, node.id, addedWidget, positionalIndex) : void 0) && removed?.type === addedWidget.type) addedWidget.value = removed.value;
		}
	}
	const updateWidgets = (value) => {
		if (!node.widgets) throw new Error("Not Reachable");
		const newSpec = value ? options[value] : void 0;
		const removedOption = activeOption;
		activeOption = value;
		const previous = captureInputLayout(node);
		const inputLinks = new Map(previous.links);
		const removedInputs = remove(node.inputs, isInGroup);
		for (const widget of remove(node.widgets, isInGroup)) {
			const optionValues = removedWidgetValues.get(removedOption) ?? /* @__PURE__ */ new Map();
			optionValues.set(widget.name, {
				type: widget.type,
				value: widget.value
			});
			removedWidgetValues.set(removedOption, optionValues);
			widget.onRemove?.();
			if (widget.widgetId) deleteWidget(widget.widgetId);
		}
		if (!newSpec) {
			if (!commitMutatedInputs(node, previous, inputLinks).ok) return;
			syncNodeWidgetOrder(node);
			return;
		}
		const insertionPoint = node.widgets.findIndex((w) => w === widget) + 1;
		const startingLength = node.widgets.length;
		const startingInputLength = node.inputs.length;
		if (insertionPoint === 0) throw new Error("Dynamic widget doesn't exist on node");
		[newSpec.required, newSpec.optional].forEach((inputType, idx) => {
			for (const key in inputType ?? {}) {
				const name = `${widget.name}.${key}`;
				const specToAdd = transformInputSpecV1ToV2(inputType[key], {
					name,
					isOptional: idx !== 0
				});
				specToAdd.display_name = key;
				addNodeInput(node, specToAdd);
			}
		});
		const inputInsertionPoint = node.inputs.findIndex((i) => i.name === widget.name) + 1;
		const addedWidgets = node.widgets.splice(startingLength);
		const addedWidgetNames = addedWidgets.map(({ name }) => name);
		node.widgets.splice(insertionPoint, 0, ...addedWidgets);
		syncNodeWidgetOrder(node);
		if (inputInsertionPoint === 0) {
			if (addedWidgets.length === 0 && node.inputs.length !== startingInputLength) throw new Error("Failed to find input socket for " + widget.name);
			if (!commitMutatedInputs(node, previous, inputLinks).ok) return;
			restoreRemovedValues(value, addedWidgetNames);
			return;
		}
		const addedInputs = node.inputs.splice(startingInputLength).map((addedInput) => {
			const existingInput = node.inputs.findIndex((existingInput) => addedInput.name === existingInput.name);
			return existingInput === -1 ? addedInput : node.inputs.splice(existingInput, 1)[0];
		});
		node.inputs.splice(inputInsertionPoint, 0, ...addedInputs);
		for (const input of removedInputs) {
			const replacement = node.inputs.find((item) => item.name === input.name);
			const link = inputLinks.get(input);
			if (replacement && link) inputLinks.set(replacement, link);
		}
		const result = commitMutatedInputs(node, previous, inputLinks);
		if (!result.ok) return;
		for (const { input, link } of result.replacements) {
			const slot = node.inputs.indexOf(input);
			if (slot === -1) continue;
			node.onConnectionsChange?.(LiteGraph.INPUT, slot, true, link, input);
		}
		restoreRemovedValues(value, addedWidgetNames);
		if (!node.graph) return;
		node._setConcreteSlots();
		node.arrange();
		node.graph.setDirtyCanvas(true, true);
	};
	widget.callback = useChainCallback(widget.callback, () => {
		node.size = [node.size[0], node.computeSize([...node.size])[1]];
		node.graph?.setDirtyCanvas(true, true);
	});
	let widgetValue = widget.value;
	const getState = () => {
		const graphId = resolveNodeRootGraphId(node);
		if (!graphId) return void 0;
		return useWidgetValueStore().getWidget(widgetId(graphId, node.id, widget.name));
	};
	Object.defineProperty(widget, "value", {
		get() {
			return getState()?.value ?? widgetValue;
		},
		set(value) {
			const state = getState();
			if (state) state.value = value;
			widgetValue = value;
			updateWidgets(value);
		}
	});
	widget.value = widgetValue;
	return {
		widget,
		minWidth,
		minHeight
	};
}
var dynamicWidgets = {
	COMFY_DYNAMICCOMBO_V3: dynamicComboWidget,
	COMFY_DYNAMICGROUP_V3: dynamicGroupWidget
};
var dynamicInputs = {
	COMFY_AUTOGROW_V3: applyAutogrow,
	COMFY_MATCHTYPE_V3: applyMatchType
};
function applyDynamicInputs(node, inputSpec) {
	if (!(inputSpec.type in dynamicInputs)) return false;
	dynamicInputs[inputSpec.type](node, inputSpec);
	return true;
}
function changeOutputType(node, slot, combinedType) {
	const output = node.outputs[slot];
	if (output.type === combinedType) return;
	output.type = combinedType;
	if (!node.graph) return;
	const topologies = useLinkStore().getOutputSlotLinks(graphScopeOf(node.graph), node.id, slot);
	for (const topology of topologies) {
		const link = node.graph.getLink(topology.id);
		if (!link) continue;
		const { input, inputNode, subgraphOutput } = link.resolve(node.graph);
		const inputType = (input ?? subgraphOutput)?.type;
		if (!inputType) continue;
		const keep = LiteGraph.isValidConnection(combinedType, inputType);
		if (!keep && subgraphOutput) subgraphOutput.disconnect();
		else if (!keep && inputNode) inputNode.disconnectInput(link.target_slot);
		if (input && inputNode?.onConnectionsChange) inputNode.onConnectionsChange(LiteGraph.INPUT, link.target_slot, keep, link, input);
	}
}
function withComfyMatchType(node) {
	if (node.comfyDynamic?.matchType) return;
	node.comfyDynamic ??= {};
	node.comfyDynamic.matchType = {};
	const outputGroups = node.constructor.nodeData?.output_matchtypes;
	node.onConnectionsChange = useChainCallback(node.onConnectionsChange, function(contype, slot, iscon, linf) {
		const input = this.inputs.at(slot);
		const { graph } = this;
		if (contype !== LiteGraph.INPUT || !graph || !input) return;
		if (useApp().configuringGraph) return;
		const [matchKey, matchGroup] = Object.entries(this.comfyDynamic.matchType).find(([, group]) => input.name in group) ?? ["", void 0];
		if (!matchGroup) return;
		if (iscon && linf) {
			const { output, subgraphInput } = linf.resolve(graph);
			const connectingType = (output ?? subgraphInput)?.type;
			if (connectingType) linf.type = connectingType;
		}
		const groupInputs = node.inputs.filter((inp) => inp.name in matchGroup);
		const connectedTypes = groupInputs.map((inp) => {
			const link = this.getInputLink(this.inputs.indexOf(inp));
			if (!link) return "*";
			const { output, subgraphInput } = link.resolve(graph);
			return (output ?? subgraphInput)?.type ?? "*";
		});
		groupInputs.forEach((input, idx) => {
			const otherConnected = [...connectedTypes.slice(0, idx), ...connectedTypes.slice(idx + 1)];
			const combinedType = commonType(...otherConnected, matchGroup[input.name]);
			if (!combinedType) throw new Error("invalid connection");
			input.type = combinedType;
		});
		const outputType = commonType(...connectedTypes);
		if (!outputType) throw new Error("invalid connection");
		this.outputs.forEach((_output, idx) => {
			if (!(outputGroups?.[idx] == matchKey)) return;
			changeOutputType(this, idx, outputType);
		});
		graph.setDirtyCanvas(true, true);
	});
}
function applyMatchType(node, inputSpec) {
	const { addNodeInput } = useLitegraphServiceAccess();
	const name = inputSpec.name;
	const parseResult = zMatchTypeOptions.safeParse(inputSpec);
	if (!parseResult.success) {
		console.warn(`Unparseable COMFY_MATCHTYPE_V3 spec for input "${name}"; falling back to a wildcard socket.`, parseResult.error.issues);
		addNodeInput(node, {
			...inputSpec,
			type: "*"
		});
		return;
	}
	const { allowed_types, template_id } = parseResult.data.template;
	addNodeInput(node, {
		...inputSpec,
		type: allowed_types
	});
	withComfyMatchType(node);
	node.comfyDynamic.matchType[template_id] ??= {};
	node.comfyDynamic.matchType[template_id][name] = allowed_types;
	const index = node.inputs.length - 1;
	requestAnimationFrame(() => {
		const input = node.inputs.at(index);
		if (!input || !node.graph) return;
		node.inputs[index] = shallowReactive(input);
		const existingLink = node.getInputLink(index);
		node.onConnectionsChange(LiteGraph.INPUT, index, !!existingLink, existingLink ?? void 0, input);
	});
}
function autogrowOrdinalToName(ordinal, key, groupName, node) {
	const { names, prefix = "", inputSpecs } = node.comfyDynamic.autogrow[groupName];
	const baseName = names ? names[ordinal] : (inputSpecs.length == 1 ? prefix : key) + ordinal;
	return {
		name: `${groupName}.${baseName}`,
		display_name: baseName
	};
}
function addAutogrowGroup(ordinal, groupName, node) {
	const { addNodeInput } = useLitegraphServiceAccess();
	const { max, min, inputSpecs } = node.comfyDynamic.autogrow[groupName];
	if (ordinal >= max) return;
	const previous = captureInputLayout(node);
	const inputLinks = new Map(previous.links);
	const newInputs = inputSpecs.map((input) => ({
		...input,
		isOptional: ordinal >= min || input.isOptional,
		...autogrowOrdinalToName(ordinal, input.name, groupName, node)
	})).map((namedSpec) => {
		addNodeInput(node, namedSpec);
		const input = node.inputs.splice(node.inputs.length - 1, 1)[0];
		if (inputSpecs.length !== 1) ensureWidgetForInput(node, input);
		return input;
	});
	for (const newInput of newInputs) for (const existingInput of remove(node.inputs, (inp) => inp.name === newInput.name)) {
		const link = inputLinks.get(existingInput);
		if (link && !inputLinks.has(newInput)) inputLinks.set(newInput, link);
		if (existingInput.label) newInput.label = existingInput.label;
	}
	const targetName = autogrowOrdinalToName(ordinal - 1, inputSpecs.at(-1).name, groupName, node).name;
	const lastIndex = node.inputs.findLastIndex((inp) => inp.name.startsWith(targetName));
	const insertionIndex = lastIndex === -1 ? node.inputs.length : lastIndex + 1;
	node.inputs.splice(insertionIndex, 0, ...newInputs);
	if (!commitMutatedInputs(node, previous, inputLinks).ok) return;
	node.graph?.setDirtyCanvas(true, true);
}
var ORDINAL_REGEX = /\d+$/;
function resolveAutogrowOrdinal(inputName, groupName, node) {
	const name = inputName.slice(groupName.length + 1);
	const { names } = node.comfyDynamic.autogrow[groupName];
	if (names) {
		const index = names.indexOf(name);
		return index === -1 ? void 0 : index;
	}
	const match = name.match(ORDINAL_REGEX);
	return match ? parseInt(match[0]) : void 0;
}
function autogrowInputConnected(index, node) {
	const input = node.inputs.at(index);
	if (!input) return;
	const groupName = input.name.slice(0, input.name.lastIndexOf("."));
	const lastInput = node.inputs.findLast((inp) => inp.name.startsWith(groupName + "."));
	const ordinal = resolveAutogrowOrdinal(input.name, groupName, node);
	if (!lastInput || ordinal == void 0 || ordinal !== resolveAutogrowOrdinal(lastInput.name, groupName, node) && !useApp().configuringGraph) return;
	addAutogrowGroup(ordinal + 1, groupName, node);
}
function hasAutogrowGroups(node) {
	return !!node.comfyDynamic?.autogrow;
}
/**
* The live autogrow group `name` belongs to, from the node's own
* `comfyDynamic.autogrow` registration -- real provenance from
* `applyAutogrow`/`addAutogrowGroup`, rather than inferred from the name's
* shape. Confirms membership with `resolveAutogrowOrdinal`, the same check
* growth and shrink use, so a name that merely starts with a group's prefix
* without resolving to one of its members doesn't false-match. Undefined
* when the node has no autogrow groups, or `name` isn't a member of any of
* them.
*/
function liveAutogrowGroupOf(node, name) {
	if (!hasAutogrowGroups(node)) return void 0;
	for (const groupName of Object.keys(node.comfyDynamic.autogrow)) {
		if (!name.startsWith(`${groupName}.`)) continue;
		if (resolveAutogrowOrdinal(name, groupName, node) !== void 0) return groupName;
	}
}
function highestAutogrowOrdinal(node, groupName) {
	let highest = -1;
	for (const input of node.inputs) {
		if (!input.name.startsWith(`${groupName}.`)) continue;
		const ordinal = resolveAutogrowOrdinal(input.name, groupName, node);
		if (ordinal !== void 0 && ordinal > highest) highest = ordinal;
	}
	return highest;
}
/**
* Grows the autogrow group `name` belongs to until the node holds an input by
* that name, and returns its live index. A local connect onto a slot the bound
* document has not seen mints a `grow` op (`docOpMinter.mintConnect`); this is
* the read leg of that exchange, for a slot the host grew whose live
* counterpart does not exist yet. Growth starts above the group's highest live
* ordinal, so the slots already carrying links are left alone. Undefined when
* `name` belongs to no autogrow group of this node, or the group's `max` stops
* short of it.
*/
function growAutogrowInput(node, name) {
	if (!hasAutogrowGroups(node)) return void 0;
	const groupName = liveAutogrowGroupOf(node, name);
	if (groupName === void 0) return void 0;
	const ordinal = resolveAutogrowOrdinal(name, groupName, node);
	if (ordinal === void 0) return void 0;
	for (let next = highestAutogrowOrdinal(node, groupName) + 1; next <= ordinal; next++) addAutogrowGroup(next, groupName, node);
	const index = node.inputs.findIndex((input) => input.name === name);
	return index === -1 ? void 0 : index;
}
function autogrowInputDisconnected(index, node) {
	const input = node.inputs.at(index);
	if (!input) return;
	if (node.getInputLink(index)) return;
	const groupName = input.name.slice(0, input.name.lastIndexOf("."));
	const autogrowGroup = Object.hasOwn(node.comfyDynamic.autogrow, groupName) ? node.comfyDynamic.autogrow[groupName] : void 0;
	if (!autogrowGroup) return;
	const { min, inputSpecs } = autogrowGroup;
	const ordinal = resolveAutogrowOrdinal(input.name, groupName, node);
	if (ordinal == void 0 || ordinal + 1 < min) return;
	const groupInputs = node.inputs.filter((inp) => inp.name.startsWith(groupName + ".") && inp.name.lastIndexOf(".") === groupName.length);
	const stride = inputSpecs.length;
	if (stride + index >= node.inputs.length) return;
	if (groupInputs.length % stride !== 0) {
		console.error("Failed to group multi-input autogrow inputs");
		return;
	}
	node.graph?.setDirtyCanvas(true, true);
	const previous = captureInputLayout(node);
	const inputLinks = new Map(previous.links);
	const transplants = [];
	for (let column = 0; column < stride; column++) for (let bubbleOrdinal = ordinal * stride + column; bubbleOrdinal + stride < groupInputs.length; bubbleOrdinal += stride) {
		const input = groupInputs[bubbleOrdinal];
		const donor = groupInputs[bubbleOrdinal + stride];
		const link = inputLinks.get(donor);
		inputLinks.delete(input);
		inputLinks.delete(donor);
		if (link) {
			inputLinks.set(input, link);
			transplants.push({
				input,
				link
			});
		}
	}
	const removalChecks = groupInputs.slice(min * stride);
	let i;
	for (i = removalChecks.length - stride; i >= 0; i -= stride) if (removalChecks.slice(i, i + stride).some((input) => inputLinks.has(input))) break;
	const toRemove = removalChecks.slice(i + stride * 2);
	const finalInputs = node.inputs.filter((input) => !toRemove.includes(input));
	if (!replaceNodeInputs(node, previous, finalInputs, inputLinks).ok) return;
	for (const { input, link } of transplants) {
		const slot = node.inputs.indexOf(input);
		if (slot === -1) continue;
		node.onConnectionsChange(LiteGraph.INPUT, slot, true, link, input);
	}
	for (const input of toRemove) {
		const widgetName = input.widget?.name;
		if (!widgetName) continue;
		for (const widget of remove(node.widgets, (w) => w.name === widgetName)) {
			widget.onRemove?.();
			if (widget.widgetId) useWidgetValueStore().deleteWidget(widget.widgetId);
		}
		syncNodeWidgetOrder(node);
	}
	node.size = [node.size[0], node.computeSize([...node.size])[1]];
}
function withComfyAutogrow(node) {
	if (node.comfyDynamic?.autogrow) return;
	node.comfyDynamic ??= {};
	node.comfyDynamic.autogrow = {};
	let pendingConnection;
	let pendingConnectionSeen = false;
	let swappingSlot;
	const originalOnConnectInput = node.onConnectInput;
	node.onConnectInput = function(slot, ...args) {
		pendingConnection = slot;
		pendingConnectionSeen = false;
		requestAnimationFrame(() => {
			pendingConnection = void 0;
			pendingConnectionSeen = false;
		});
		return originalOnConnectInput?.apply(this, [slot, ...args]) ?? true;
	};
	node.onConnectionsChange = useChainCallback(node.onConnectionsChange, function(contype, slot, iscon, linf) {
		const input = this.inputs.at(slot);
		if (contype !== LiteGraph.INPUT || !input) return;
		const key = input.name.slice(0, input.name.lastIndexOf("."));
		if (!(Object.hasOwn(this.comfyDynamic.autogrow, key) ? this.comfyDynamic.autogrow[key] : void 0)) return;
		if (useApp().configuringGraph && input.widget) ensureWidgetForInput(node, input);
		if (iscon) {
			if (pendingConnection === slot) pendingConnectionSeen = true;
			if (swappingSlot === slot) {
				swappingSlot = void 0;
				return;
			}
			if (!linf) return;
			autogrowInputConnected(slot, this);
		} else {
			if (pendingConnection === slot && !pendingConnectionSeen) {
				swappingSlot = slot;
				requestAnimationFrame(() => {
					if (swappingSlot === slot) swappingSlot = void 0;
				});
				return;
			}
			requestAnimationFrame(() => autogrowInputDisconnected(slot, this));
		}
	});
}
function applyAutogrow(node, inputSpecV2) {
	withComfyAutogrow(node);
	const parseResult = zAutogrowOptions.safeParse(inputSpecV2);
	if (!parseResult.success) throw new Error("invalid Autogrow spec");
	const { input, min = 1, names, prefix, max = 100 } = parseResult.data.template;
	const inputsV2 = [input.required, input.optional].flatMap((inputType, index) => Object.entries(inputType ?? {}).map(([name, v]) => transformInputSpecV1ToV2(v, {
		name,
		isOptional: index === 1
	})));
	node.comfyDynamic.autogrow[inputSpecV2.name] = {
		names,
		min,
		max: names?.length ?? max,
		prefix,
		inputSpecs: inputsV2
	};
	for (let i = 0; i === 0 || i < min + 1; i++) addAutogrowGroup(i, inputSpecV2.name, node);
}
//#endregion
//#region src/core/graph/widgets/controlWidgetMarker.ts
var IS_CONTROL_WIDGET = Symbol();
//#endregion
//#region src/types/simplifiedWidget.ts
var CONTROL_OPTIONS = [
	"fixed",
	"increment",
	"decrement",
	"randomize"
];
function isControlOption(value) {
	return CONTROL_OPTIONS.some((option) => option === value);
}
function normalizeControlOption(val) {
	if (isControlOption(val)) return val;
	return "randomize";
}
function getControlWidget(widget) {
	const controlWidget = widget.linkedWidgets?.find((w) => w[IS_CONTROL_WIDGET]);
	if (!controlWidget) return;
	return {
		value: normalizeControlOption(controlWidget.value),
		update: (value) => controlWidget.value = normalizeControlOption(value)
	};
}
//#endregion
//#region src/core/graph/widgets/valueControl.ts
function isValueControlMode(value) {
	return isControlOption(value) || value === "increment-wrap";
}
function nextValueForLinkedTarget(params) {
	const linked = params.linkedWidgets;
	if (!linked) return void 0;
	const controlWidget = linked.find(isValueControlWidget);
	if (!controlWidget) return void 0;
	const comboFilter = linked.find((w) => w !== controlWidget && w.type === "string");
	const filterValue = typeof comboFilter?.value === "string" ? comboFilter.value : void 0;
	const mode = controlWidget.value;
	return computeNextControlledValue(params.target, mode, {
		comboFilter: filterValue,
		nodeId: params.nodeId
	});
}
var SAFE_INTEGER_MAX = 0x4000000000000;
var SAFE_INTEGER_MIN = -0x4000000000000;
function isValueControlWidget(widget) {
	return widget[IS_CONTROL_WIDGET] === true && typeof widget.beforeQueued === "function" && typeof widget.afterQueued === "function";
}
function buildComboFilter(filter, nodeId) {
	if (!filter) return void 0;
	if (filter.startsWith("/") && filter.endsWith("/")) try {
		const regex = new RegExp(filter.substring(1, filter.length - 1));
		return (item) => regex.test(item);
	} catch (error) {
		console.error("Error constructing RegExp filter for node " + String(nodeId), filter, error);
	}
	const lower = filter.toLocaleLowerCase();
	return (item) => item.toLocaleLowerCase().includes(lower);
}
function computeNextControlledValue(target, mode, options = {}) {
	if (mode === "fixed") return void 0;
	if (isComboWidget$1(target)) return computeNextComboValue(target, mode, options);
	return computeNextNumberValue(target, mode);
}
function computeNextComboValue(target, mode, { comboFilter, nodeId }) {
	const rawValues = target.options.values;
	if (!Array.isArray(rawValues)) return void 0;
	const allValues = rawValues.filter((value) => typeof value === "string" || typeof value === "number");
	const check = buildComboFilter(comboFilter, nodeId);
	const values = check ? allValues.filter((value) => check(String(value))) : allValues;
	if (!values.length) {
		if (allValues.length) console.warn("Filter for node " + String(nodeId) + " has filtered out all items", comboFilter);
		return;
	}
	let currentIndex = findComboValueIndex(values, target.value);
	const length = values.length;
	switch (mode) {
		case "increment":
			currentIndex += 1;
			break;
		case "increment-wrap":
			currentIndex += 1;
			if (currentIndex >= length) currentIndex = 0;
			break;
		case "decrement":
			currentIndex -= 1;
			break;
		case "randomize": currentIndex = Math.floor(Math.random() * length);
	}
	currentIndex = Math.max(0, Math.min(length - 1, currentIndex));
	return values[currentIndex];
}
function computeNextNumberValue(target, mode) {
	if (typeof target.value !== "number") return void 0;
	const { min: rawMin = 0, max: rawMax = 1, step2 = 1 } = target.options;
	const max = Math.min(SAFE_INTEGER_MAX, rawMax);
	const min = Math.max(SAFE_INTEGER_MIN, rawMin);
	const range = (max - min) / step2;
	let next = target.value;
	switch (mode) {
		case "increment":
		case "increment-wrap":
			next += step2;
			break;
		case "decrement":
			next -= step2;
			break;
		case "randomize": next = Math.floor(Math.random() * range) * step2 + min;
	}
	return Math.min(Math.max(next, min), max);
}
//#endregion
//#region src/core/graph/widgets/valueControlWidgets.ts
function controlValueRunBefore$1() {
	return useSettingStore().get("Comfy.WidgetControlMode") === "before";
}
__name(controlValueRunBefore$1, "controlValueRunBefore");
function updateControlWidgetLabel$1(widget) {
	if (controlValueRunBefore$1()) widget.label = t("g.control_before_generate");
	else widget.label = t("g.control_after_generate");
}
__name(updateControlWidgetLabel$1, "updateControlWidgetLabel");
var HAS_EXECUTED = Symbol();
/**
* `control_after_generate` is either a group-node widget name override or a
* control mode that core's `io.ControlAfterGenerate` enum serialises into
* `object_info`. Only a non-blank string that is not a mode is a name.
*/
function controlAfterGenerateNameOverride(value) {
	if (typeof value !== "string" || value.trim() === "") return void 0;
	return isValueControlMode(value) ? void 0 : value;
}
function addValueControlWidget$1(node, targetWidget, defaultValue, _values, widgetName, inputData) {
	const name = controlAfterGenerateNameOverride(inputData?.[1]?.control_after_generate) ?? widgetName;
	return addValueControlWidgets$1(node, targetWidget, defaultValue ?? "randomize", {
		addFilterList: false,
		controlAfterGenerateName: name
	}, inputData)[0];
}
__name(addValueControlWidget$1, "addValueControlWidget");
function addValueControlWidgets$1(node, targetWidget, defaultValue, options = {}, inputData) {
	const specNameOverride = controlAfterGenerateNameOverride(inputData?.[1]?.control_after_generate);
	if (!defaultValue || defaultValue === specNameOverride) defaultValue = "randomize";
	const getName = (defaultName, optionName) => {
		const nameOverride = options[optionName];
		if (nameOverride) return nameOverride;
		const inputOptions = inputData?.[1];
		const specValue = inputOptions?.[defaultName];
		const defaultNameOverride = defaultName === "control_after_generate" ? controlAfterGenerateNameOverride(specValue) : typeof specValue === "string" ? specValue : void 0;
		if (defaultNameOverride !== void 0) return defaultNameOverride;
		if (inputOptions?.control_prefix) return inputOptions.control_prefix + " " + defaultName;
		return defaultName;
	};
	const valueControl = node.addWidget("combo", getName("control_after_generate", "controlAfterGenerateName"), defaultValue, function() {}, {
		values: [...CONTROL_OPTIONS],
		serialize: false,
		surfaces: {
			canvas: "shown",
			vueNode: "never",
			panel: "never"
		}
	});
	valueControl.tooltip = "Allows the linked widget to be changed automatically, for example randomizing the noise seed.";
	valueControl[IS_CONTROL_WIDGET] = true;
	updateControlWidgetLabel$1(valueControl);
	Object.defineProperty(valueControl, "disabled", { get: () => targetWidget.computedDisabled });
	const widgets = [valueControl];
	const isCombo = isComboWidget$1(targetWidget);
	let comboFilter;
	if (isCombo) {
		const values = valueControl.options.values;
		if (Array.isArray(values)) values.push("increment-wrap");
	}
	if (isCombo && options.addFilterList !== false) {
		comboFilter = node.addWidget("string", getName("control_filter_list", "controlFilterListName"), "", function() {}, { serialize: false });
		updateControlWidgetLabel$1(comboFilter);
		comboFilter.tooltip = "Allows for filtering the list of values when changing the value via the control generate mode. Allows for RegEx matches in the format /abc/ to only filter to values containing 'abc'.";
		Object.defineProperty(comboFilter, "disabled", { get: () => targetWidget.computedDisabled });
		widgets.push(comboFilter);
	}
	function applyWidgetControl() {
		if (node.inputs.some((input, index) => input.widget?.name === targetWidget.name && node.isInputConnected(index))) return;
		const next = nextValueForLinkedTarget({
			target: targetWidget,
			linkedWidgets: targetWidget.linkedWidgets,
			nodeId: node.id
		});
		if (next === void 0) return;
		targetWidget.value = next;
		targetWidget.callback?.(next);
	}
	valueControl.beforeQueued = () => {
		if (controlValueRunBefore$1()) {
			if (valueControl[HAS_EXECUTED]) applyWidgetControl();
		}
		valueControl[HAS_EXECUTED] = true;
	};
	valueControl.afterQueued = () => {
		if (!controlValueRunBefore$1()) applyWidgetControl();
	};
	return widgets;
}
__name(addValueControlWidgets$1, "addValueControlWidgets");
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/composables/useBooleanWidget.ts
var useBooleanWidget = () => {
	const widgetConstructor = (node, inputSpec) => {
		if (!isBooleanInputSpec(inputSpec)) throw new Error(`Invalid input data: ${inputSpec}`);
		const defaultVal = inputSpec.default ?? false;
		const options = {
			on: inputSpec.label_on,
			off: inputSpec.label_off
		};
		return node.addWidget("toggle", inputSpec.name, defaultVal, () => {}, options);
	};
	return widgetConstructor;
};
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/composables/useBoundingBoxWidget.ts
function isBoundingBoxLikeWidget(widget) {
	return widget.type === "boundingbox" || widget.type === "imagecrop";
}
function isNumericWidget(widget) {
	return widget.type === "number";
}
var useBoundingBoxWidget = () => {
	return (node, inputSpec) => {
		const spec = inputSpec;
		const { name, component } = spec;
		const defaultValue = spec.default ?? {
			x: 0,
			y: 0,
			width: 512,
			height: 512
		};
		const widgetType = component === "ImageCrop" ? "imagecrop" : "boundingbox";
		const fields = [
			"x",
			"y",
			"width",
			"height"
		];
		const subWidgets = [];
		const rawWidget = node.addWidget(widgetType, name, { ...defaultValue }, () => {
			for (let i = 0; i < fields.length; i++) {
				const field = fields[i];
				const subWidget = subWidgets.at(i);
				if (subWidget) subWidget.value = widget.value[field];
			}
		}, { hideInPanel: true });
		if (!isBoundingBoxLikeWidget(rawWidget)) throw new Error(`Unexpected widget type: ${rawWidget.type}`);
		const widget = rawWidget;
		for (const field of fields) {
			const subWidget = node.addWidget("number", field, defaultValue[field], function(v) {
				this.value = Math.round(v);
				widget.value[field] = this.value;
				widget.callback?.(widget.value);
			}, {
				min: field === "width" || field === "height" ? 1 : 0,
				max: 8192,
				step: 10,
				step2: 1,
				precision: 0,
				serialize: false,
				surfaces: {
					canvas: "shown",
					vueNode: "never",
					panel: "never"
				}
			});
			if (!isNumericWidget(subWidget)) throw new Error(`Unexpected widget type: ${subWidget.type}`);
			subWidgets.push(subWidget);
		}
		widget.linkedWidgets = subWidgets;
		return widget;
	};
};
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/composables/useCurveWidget.ts
var DEFAULT_CURVE_DATA = {
	points: [[0, 0], [1, 1]],
	interpolation: "monotone_cubic"
};
var useCurveWidget = () => {
	return (node, inputSpec) => {
		const spec = inputSpec;
		const defaultValue = spec.default ? {
			...spec.default,
			points: [...spec.default.points]
		} : {
			...DEFAULT_CURVE_DATA,
			points: [...DEFAULT_CURVE_DATA.points]
		};
		const rawWidget = node.addWidget("curve", spec.name, defaultValue, () => {}, { hideInPanel: true });
		if (rawWidget.type !== "curve") throw new Error(`Unexpected widget type: ${rawWidget.type}`);
		return rawWidget;
	};
};
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/composables/useChartWidget.ts
var useChartWidget = () => {
	return (node, inputSpec) => {
		if (!isChartInputSpec(inputSpec)) throw new Error("Invalid input spec for chart widget");
		const { name, options } = inputSpec;
		const chartType = inputSpec.chartType ?? options?.type ?? "line";
		const data = inputSpec.data ?? options?.data ?? {};
		const widgetOptions = {
			serialize: true,
			type: chartType
		};
		return node.addWidget("chart", name, data, () => {}, widgetOptions);
	};
};
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/composables/useColorWidget.ts
var useColorWidget = () => {
	return (node, inputSpec) => {
		if (!isColorInputSpec(inputSpec)) console.error("Invalid input spec for color widget");
		const colorSpec = inputSpec;
		const { name } = colorSpec;
		const defaultValue = colorSpec.default ?? colorSpec.options?.default ?? "#000000";
		const existing = node.widgets?.find((w) => w.name === name && w.type === "color");
		if (existing) return existing;
		return node.addWidget("color", name, defaultValue, () => {}, { serialize: true });
	};
};
//#endregion
//#region src/components/ui/multi-select/MultiSelectContent.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$2 = {
	key: 0,
	class: "px-2 pt-2 pb-0"
};
var _hoisted_2$2 = { class: "flex items-center gap-2 rounded-lg border px-3 py-1.5 text-sm" };
var _hoisted_3 = {
	key: 0,
	class: "px-1 text-sm text-muted-foreground"
};
var _hoisted_4 = { class: "flex size-4 shrink-0 items-center justify-center rounded-sm transition-all duration-200 group-data-[state=checked]:bg-primary group-data-[state=unchecked]:bg-secondary [&>span]:flex" };
var _hoisted_5 = {
	key: 0,
	class: "px-1 text-sm text-muted-foreground"
};
//#endregion
//#region src/components/ui/multi-select/MultiSelectContent.vue
var MultiSelectContent_default = /* @__PURE__ */ defineComponent({
	__name: "MultiSelectContent",
	props: /*@__PURE__*/ mergeModels({
		searchLabel: {},
		emptyText: {},
		clearAllLabel: {},
		formatSelectedCount: { type: Function },
		options: {},
		showSearchBox: { type: Boolean },
		showClearButton: { type: Boolean },
		actionsPlacement: {},
		searchPlaceholder: {},
		listMaxHeight: {},
		popoverStyle: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] },
		contentStyle: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	}, {
		"modelValue": { required: true },
		"modelModifiers": {},
		"searchQuery": { required: true },
		"searchQueryModifiers": {}
	}),
	emits: /*@__PURE__*/ mergeModels(["escape"], ["update:modelValue", "update:searchQuery"]),
	setup(__props, { emit: __emit }) {
		const { open } = injectComboboxRootContext();
		const emit = __emit;
		const selectedItems = useModel(__props, "modelValue");
		const searchQuery = useModel(__props, "searchQuery");
		const hasActions = computed(() => Boolean(__props.formatSelectedCount) || __props.showClearButton);
		const actionsClass = computed(() => cn("flex shrink-0 items-center justify-between", __props.actionsPlacement === "header" ? "mt-2 border-b px-2 pb-4" : "-mx-2 mt-2 border-t px-4 pt-3 pb-1"));
		const searchResults = useSelectSearch(searchQuery, () => __props.options);
		const filteredOptions = computed(() => {
			if (!searchQuery.value.trim()) return __props.options;
			return [...selectedItems.value.filter((item) => !searchResults.value.some(({ value }) => value === item.value)), ...searchResults.value];
		});
		function onKeydown(event) {
			if (event.key !== "Escape") return;
			stopEscapeToDocument(event);
			emit("escape");
		}
		function preventFocusDismiss(event) {
			event.preventDefault();
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(ComboboxPortal_default), { key: Number(unref(open)) }, {
				default: withCtx(() => [createVNode(unref(ComboboxContent_default), {
					position: "popper",
					"side-offset": 8,
					align: "start",
					style: normalizeStyle([__props.popoverStyle, __props.contentStyle]),
					class: normalizeClass(unref(cn)(unref(selectContentClass), "flex flex-col")),
					onKeydown,
					onFocusOutside: preventFocusDismiss
				}, {
					default: withCtx(() => [createVNode(unref(FocusScope_default), {
						class: "contents",
						onMountAutoFocus: _cache[3] || (_cache[3] = withModifiers(() => {}, ["prevent"]))
					}, {
						default: withCtx(() => [
							__props.showSearchBox ? (openBlock(), createElementBlock("div", _hoisted_1$2, [createBaseVNode("div", _hoisted_2$2, [_cache[4] || (_cache[4] = createBaseVNode("i", { class: "icon-[lucide--search] shrink-0 text-muted-foreground" }, null, -1)), createVNode(unref(ComboboxInput_default), {
								modelValue: searchQuery.value,
								"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => searchQuery.value = $event),
								placeholder: __props.searchPlaceholder,
								"aria-label": __props.searchLabel,
								class: "w-full border-none bg-transparent outline-none"
							}, null, 8, [
								"modelValue",
								"placeholder",
								"aria-label"
							])])])) : createCommentVNode("", true),
							hasActions.value && __props.actionsPlacement === "header" ? (openBlock(), createElementBlock("div", {
								key: 1,
								class: normalizeClass(actionsClass.value)
							}, [__props.formatSelectedCount ? (openBlock(), createElementBlock("span", _hoisted_3, toDisplayString(__props.formatSelectedCount(selectedItems.value.length)), 1)) : createCommentVNode("", true), __props.showClearButton ? (openBlock(), createBlock(Button_default, {
								key: 1,
								variant: "textonly",
								size: "md",
								onClick: _cache[1] || (_cache[1] = withModifiers(($event) => selectedItems.value = [], ["stop"]))
							}, {
								default: withCtx(() => [createTextVNode(toDisplayString(__props.clearAllLabel), 1)]),
								_: 1
							})) : createCommentVNode("", true)], 2)) : createCommentVNode("", true),
							createVNode(unref(ComboboxViewport_default), {
								class: normalizeClass(unref(cn)("flex flex-col gap-0 p-0 text-sm", "scrollbar-custom overflow-y-auto", "min-w-(--reka-combobox-trigger-width)")),
								style: normalizeStyle({ maxHeight: `min(${__props.listMaxHeight}, 50vh)` })
							}, {
								default: withCtx(() => [(openBlock(true), createElementBlock(Fragment, null, renderList(filteredOptions.value, (opt) => {
									return openBlock(), createBlock(unref(ComboboxItem_default), {
										key: opt.value,
										value: opt,
										class: normalizeClass(unref(cn)("group", unref(selectItemVariants)({ layout: "multi" })))
									}, {
										default: withCtx(() => [createBaseVNode("div", _hoisted_4, [createVNode(unref(ComboboxItemIndicator_default), null, {
											default: withCtx(() => [..._cache[5] || (_cache[5] = [createBaseVNode("i", { class: "icon-[lucide--check] text-xs font-bold text-foreground" }, null, -1)])]),
											_: 1
										})]), createBaseVNode("span", null, toDisplayString(opt.name), 1)]),
										_: 2
									}, 1032, ["value", "class"]);
								}), 128)), createVNode(unref(ComboboxEmpty_default), { class: normalizeClass(unref(selectEmptyMessageClass)) }, {
									default: withCtx(() => [createTextVNode(toDisplayString(__props.emptyText), 1)]),
									_: 1
								}, 8, ["class"])]),
								_: 1
							}, 8, ["class", "style"]),
							hasActions.value && __props.actionsPlacement === "footer" ? (openBlock(), createElementBlock("div", {
								key: 2,
								class: normalizeClass(actionsClass.value)
							}, [__props.formatSelectedCount ? (openBlock(), createElementBlock("span", _hoisted_5, toDisplayString(__props.formatSelectedCount(selectedItems.value.length)), 1)) : createCommentVNode("", true), __props.showClearButton ? (openBlock(), createBlock(Button_default, {
								key: 1,
								variant: "textonly",
								size: "md",
								onClick: _cache[2] || (_cache[2] = withModifiers(($event) => selectedItems.value = [], ["stop"]))
							}, {
								default: withCtx(() => [createTextVNode(toDisplayString(__props.clearAllLabel), 1)]),
								_: 1
							})) : createCommentVNode("", true)], 2)) : createCommentVNode("", true)
						]),
						_: 1
					})]),
					_: 1
				}, 8, ["style", "class"])]),
				_: 1
			});
		};
	}
});
//#endregion
//#region src/components/ui/multi-select/MultiSelectTrigger.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$1 = { class: "flex flex-1 items-center overflow-hidden py-2 pl-2 whitespace-nowrap" };
var _hoisted_2$1 = { class: "truncate text-sm" };
//#endregion
//#region src/components/ui/multi-select/MultiSelectTrigger.vue
var MultiSelectTrigger_default = /* @__PURE__ */ defineComponent({
	inheritAttrs: false,
	__name: "MultiSelectTrigger",
	props: {
		class: { type: [
			Array,
			Object,
			String,
			Number,
			null,
			Boolean
		] },
		label: {},
		accessibleLabel: {},
		selectedItems: {},
		size: {}
	},
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(ComboboxAnchor_default), { "as-child": "" }, {
				default: withCtx(() => [createVNode(unref(ComboboxTrigger_default), mergeProps(_ctx.$attrs, {
					"aria-label": __props.accessibleLabel,
					class: unref(cn)(unref(selectTriggerVariants)({
						size: __props.size,
						border: __props.selectedItems.length ? "active" : "none"
					}), __props.class)
				}), {
					default: withCtx(() => [createBaseVNode("div", _hoisted_1$1, [__props.selectedItems.length === 0 ? (openBlock(), createElementBlock("span", {
						key: 0,
						class: normalizeClass(__props.size === "md" ? "text-xs" : "text-sm")
					}, toDisplayString(__props.label), 3)) : renderSlot(_ctx.$slots, "default", { selected: __props.selectedItems }, () => [createBaseVNode("span", _hoisted_2$1, toDisplayString(__props.selectedItems.map(({ name }) => name).join(", ")), 1)], void 0, 1), __props.selectedItems.length ? (openBlock(), createElementBlock("span", {
						key: 2,
						class: normalizeClass(unref(cn)("pointer-events-none absolute -top-1.5 -right-1.5 z-10", unref(selectCountBadgeClass)))
					}, toDisplayString(__props.selectedItems.length), 3)) : createCommentVNode("", true)]), createBaseVNode("div", { class: normalizeClass(unref(selectDropdownClass)) }, [..._cache[0] || (_cache[0] = [createBaseVNode("i", { class: "icon-[lucide--chevron-down] text-muted-foreground" }, null, -1)])], 2)]),
					_: 3
				}, 16, ["aria-label", "class"])]),
				_: 3
			});
		};
	}
});
//#endregion
//#region src/components/ui/multi-select/MultiSelect.vue
var MultiSelect_default = /* @__PURE__ */ defineComponent({
	inheritAttrs: false,
	__name: "MultiSelect",
	props: /*@__PURE__*/ mergeModels({
		accessibleLabel: {},
		emptyText: {},
		label: {},
		options: { default: () => [] },
		size: { default: "lg" },
		disabled: {
			type: Boolean,
			default: false
		},
		actionsPlacement: { default: "header" },
		searchPlaceholder: {},
		listMaxHeight: { default: "28rem" },
		popoverMinWidth: {},
		popoverMaxWidth: {},
		contentStyle: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] },
		showSearchBox: {
			type: Boolean,
			default: false
		},
		searchLabel: {},
		showClearButton: {
			type: Boolean,
			default: false
		},
		clearAllLabel: {},
		showSelectedCount: {
			type: Boolean,
			default: false
		},
		formatSelectedCount: { type: Function }
	}, {
		"modelValue": { required: true },
		"modelModifiers": {},
		"searchQuery": { default: "" },
		"searchQueryModifiers": {}
	}),
	emits: ["update:modelValue", "update:searchQuery"],
	setup(__props) {
		const { attrsClass, attrsWithoutClass } = useAttrsClass();
		const selectedItems = useModel(__props, "modelValue");
		const searchQuery = useModel(__props, "searchQuery");
		const isOpen = ref(false);
		const popoverStyle = usePopoverSizing({
			minWidth: __props.popoverMinWidth,
			maxWidth: __props.popoverMaxWidth
		});
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(ComboboxRoot_default), {
				modelValue: selectedItems.value,
				"onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => selectedItems.value = $event),
				open: isOpen.value,
				"onUpdate:open": _cache[4] || (_cache[4] = ($event) => isOpen.value = $event),
				multiple: "",
				by: "value",
				disabled: __props.disabled,
				"ignore-filter": "",
				"reset-search-term-on-select": false
			}, {
				default: withCtx(() => [createVNode(MultiSelectTrigger_default, mergeProps(unref(attrsWithoutClass), {
					class: unref(attrsClass),
					label: __props.label,
					"accessible-label": __props.accessibleLabel,
					"selected-items": selectedItems.value,
					size: __props.size
				}), createSlots({ _: 2 }, [_ctx.$slots.value ? {
					name: "default",
					fn: withCtx(({ selected }) => [renderSlot(_ctx.$slots, "value", { selected })]),
					key: "0"
				} : void 0]), 1040, [
					"class",
					"label",
					"accessible-label",
					"selected-items",
					"size"
				]), createVNode(MultiSelectContent_default, {
					modelValue: selectedItems.value,
					"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => selectedItems.value = $event),
					"search-query": searchQuery.value,
					"onUpdate:searchQuery": _cache[1] || (_cache[1] = ($event) => searchQuery.value = $event),
					options: __props.options,
					"show-search-box": __props.showSearchBox,
					"show-clear-button": __props.showClearButton,
					"actions-placement": __props.actionsPlacement,
					"search-placeholder": __props.searchPlaceholder,
					"search-label": __props.searchLabel,
					"empty-text": __props.emptyText,
					"clear-all-label": __props.clearAllLabel,
					"format-selected-count": __props.showSelectedCount ? __props.formatSelectedCount : void 0,
					"list-max-height": __props.listMaxHeight,
					"popover-style": unref(popoverStyle),
					"content-style": __props.contentStyle,
					onEscape: _cache[2] || (_cache[2] = ($event) => isOpen.value = false)
				}, null, 8, [
					"modelValue",
					"search-query",
					"options",
					"show-search-box",
					"show-clear-button",
					"actions-placement",
					"search-placeholder",
					"search-label",
					"empty-text",
					"clear-all-label",
					"format-selected-count",
					"list-max-height",
					"popover-style",
					"content-style"
				])]),
				_: 3
			}, 8, [
				"modelValue",
				"open",
				"disabled"
			]);
		};
	}
});
//#endregion
//#region src/components/common/AppMultiSelect.vue
var AppMultiSelect_default = /* @__PURE__ */ defineComponent({
	__name: "AppMultiSelect",
	props: /*@__PURE__*/ mergeModels({
		label: {},
		options: {},
		size: {},
		disabled: { type: Boolean },
		actionsPlacement: {},
		searchPlaceholder: {},
		listMaxHeight: {},
		popoverMinWidth: {},
		popoverMaxWidth: {},
		contentStyle: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] },
		showSearchBox: { type: Boolean },
		showClearButton: { type: Boolean },
		showSelectedCount: { type: Boolean },
		accessibleLabel: {},
		searchLabel: {},
		emptyText: {},
		clearAllLabel: {},
		formatSelectedCount: { type: Function }
	}, {
		"modelValue": { required: true },
		"modelModifiers": {},
		"searchQuery": { default: "" },
		"searchQueryModifiers": {}
	}),
	emits: ["update:modelValue", "update:searchQuery"],
	setup(__props) {
		const restProps = createPropsRestProxy(__props, [
			"label",
			"accessibleLabel",
			"searchLabel",
			"searchPlaceholder",
			"emptyText",
			"clearAllLabel",
			"formatSelectedCount"
		]);
		const selectedItems = useModel(__props, "modelValue");
		const searchQuery = useModel(__props, "searchQuery");
		const { t } = useI18n();
		return (_ctx, _cache) => {
			return openBlock(), createBlock(MultiSelect_default, mergeProps(restProps, {
				modelValue: selectedItems.value,
				"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => selectedItems.value = $event),
				"search-query": searchQuery.value,
				"onUpdate:searchQuery": _cache[1] || (_cache[1] = ($event) => searchQuery.value = $event),
				label: __props.label,
				"accessible-label": __props.accessibleLabel ?? (__props.label || unref(t)("g.multiSelectDropdown")),
				"search-label": __props.searchLabel ?? unref(t)("g.search"),
				"search-placeholder": __props.searchPlaceholder ?? unref(t)("g.search"),
				"empty-text": __props.emptyText ?? unref(t)("g.noResultsFound"),
				"clear-all-label": __props.clearAllLabel ?? unref(t)("g.clearAll"),
				"format-selected-count": __props.formatSelectedCount ?? ((count) => unref(t)("g.itemsSelected", { count }))
			}), createSlots({ _: 2 }, [_ctx.$slots.value ? {
				name: "value",
				fn: withCtx(({ selected }) => [renderSlot(_ctx.$slots, "value", { selected })]),
				key: "0"
			} : void 0]), 1040, [
				"modelValue",
				"search-query",
				"label",
				"accessible-label",
				"search-label",
				"search-placeholder",
				"empty-text",
				"clear-all-label",
				"format-selected-count"
			]);
		};
	}
});
//#endregion
//#region src/components/graph/widgets/MultiSelectWidget.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "flex min-w-0 gap-1 overflow-hidden" };
var _hoisted_2 = { class: "truncate" };
//#endregion
//#region src/components/graph/widgets/MultiSelectWidget.vue
var MultiSelectWidget_default = /* @__PURE__ */ defineComponent({
	__name: "MultiSelectWidget",
	props: /*@__PURE__*/ mergeModels({ widget: {} }, {
		"modelValue": { required: true },
		"modelModifiers": {}
	}),
	emits: ["update:modelValue"],
	setup(__props) {
		const selectedItems = useModel(__props, "modelValue");
		const inputSpec = __props.widget.inputSpec;
		const options = computed(() => (inputSpec.options ?? []).map((value) => ({
			name: String(value),
			value: String(value)
		})));
		const selectedOptions = computed({
			get: () => options.value.filter(({ value }) => selectedItems.value.includes(String(value))),
			set: (value) => {
				selectedItems.value = value.map(({ value }) => String(value));
			}
		});
		const placeholder = inputSpec.multi_select?.placeholder ?? "Select items";
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", null, [createVNode(AppMultiSelect_default, {
				modelValue: selectedOptions.value,
				"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => selectedOptions.value = $event),
				options: options.value,
				"show-search-box": "",
				label: unref(placeholder),
				class: "w-full"
			}, createSlots({ _: 2 }, [unref(inputSpec).multi_select?.chip ? {
				name: "value",
				fn: withCtx(({ selected }) => [createBaseVNode("div", _hoisted_1, [(openBlock(true), createElementBlock(Fragment, null, renderList(selected, (item) => {
					return openBlock(), createBlock(Badge_default, {
						key: item.value,
						variant: "square",
						severity: "secondary",
						class: "min-w-0 shrink"
					}, {
						default: withCtx(() => [createBaseVNode("span", _hoisted_2, toDisplayString(item.name), 1)]),
						_: 2
					}, 1024);
				}), 128))])]),
				key: "0"
			} : void 0]), 1032, [
				"modelValue",
				"options",
				"label"
			])]);
		};
	}
});
//#endregion
//#region src/platform/assets/composables/useAssetBrowserDialog.ts
var DIALOG_KEY = "global-asset-browser";
var assetBrowserModalComponent;
function registerAssetBrowserModalComponent(component) {
	assetBrowserModalComponent = component;
}
var useAssetBrowserDialog = () => {
	const dialogService = useDialogService();
	const dialogStore = useDialogStore();
	function openModal(props) {
		if (!assetBrowserModalComponent) {
			reportError(/* @__PURE__ */ new Error("Asset browser modal component is not registered"), {
				errorType: "failure_opening_asset_browser_modal",
				surface: "assets"
			});
			return;
		}
		dialogService.showLayoutDialog({
			key: DIALOG_KEY,
			component: assetBrowserModalComponent,
			props
		});
	}
	function hide() {
		dialogStore.closeDialog({ key: DIALOG_KEY });
	}
	function show(props) {
		const handleAssetSelected = (asset) => {
			props.onAssetSelected?.(asset);
			hide();
		};
		openModal({
			nodeType: props.nodeType,
			onSelect: handleAssetSelected,
			onClose: hide
		});
	}
	function browse(options) {
		const handleAssetSelected = (asset) => {
			options.onAssetSelected?.(asset);
			hide();
		};
		openModal({
			showLeftPanel: true,
			assetType: options.assetType,
			title: options.title,
			onSelect: handleAssetSelected,
			onClose: hide
		});
	}
	return {
		show,
		browse
	};
};
//#endregion
//#region src/platform/assets/utils/createAssetWidget.ts
function hasOwnerNode(widget) {
	return "node" in widget && typeof widget.node === "object" && widget.node !== null;
}
function createAssetWidgetOptions({ widgetName, nodeTypeForBrowser, inputNameForBrowser }) {
	const inputName = inputNameForBrowser ?? widgetName;
	const assetBrowserDialog = useAssetBrowserDialog();
	async function openModal(widget) {
		const toast = useToast();
		await assetBrowserDialog.show({
			nodeType: nodeTypeForBrowser,
			inputName,
			currentValue: String(widget.value ?? ""),
			onAssetSelected: (asset) => {
				const validatedAsset = assetItemSchema.safeParse(asset);
				if (!validatedAsset.success) {
					console.error("Invalid asset item:", fromZodError(validatedAsset.error).message);
					toast.error(t("assetBrowser.invalidAsset"), { description: t("assetBrowser.invalidAssetDetail") });
					return;
				}
				const filename = getAssetFilename(validatedAsset.data);
				const validatedFilename = assetFilenameSchema.safeParse(filename);
				if (!validatedFilename.success) {
					console.error("Invalid asset filename:", validatedFilename.error.issues, "for asset:", validatedAsset.data.id);
					toast.error(t("assetBrowser.invalidFilename"), { description: t("assetBrowser.invalidFilenameDetail") });
					return;
				}
				const oldValue = widget.value;
				widget.value = validatedFilename.data;
				widget.callback?.(widget.value);
				if (hasOwnerNode(widget)) widget.node.onWidgetChanged?.(widget.name, validatedFilename.data, oldValue, widget);
				if (oldValue !== validatedFilename.data) useWorkflowStore().activeWorkflow?.changeTracker.captureCanvasState();
			}
		});
	}
	return {
		openModal,
		nodeType: nodeTypeForBrowser
	};
}
function createAssetWidget(params) {
	const { node, widgetName, nodeTypeForBrowser, inputNameForBrowser, defaultValue } = params;
	const displayLabel = defaultValue ?? t("widgets.selectModel");
	const options = createAssetWidgetOptions({
		widgetName,
		nodeTypeForBrowser,
		inputNameForBrowser
	});
	return node.addWidget("asset", widgetName, displayLabel, () => {}, options);
}
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/composables/useRemoteWidget.ts
var MAX_RETRIES$1 = 5;
var TIMEOUT = 4096;
async function getAuthHeaders() {
	return {};
}
var dataCache = shallowReactive(/* @__PURE__ */ new Map());
var createCacheKey = (config) => {
	const { route, query_params = {}, refresh = 0 } = config;
	const paramsKey = Object.entries(query_params).sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => `${k}=${v}`).join("&");
	return [
		route,
		`r=${refresh}`,
		paramsKey
	].join(";");
};
var getBackoff = (retryCount) => Math.min(1e3 * Math.pow(2, retryCount), 512);
var isInitialized = (entry) => entry?.data !== void 0 && entry.timestamp !== void 0 && entry.timestamp > 0;
var isStale = (entry, ttl) => entry?.timestamp && Date.now() - entry.timestamp >= ttl;
var isFetching = (entry) => entry?.fetchPromise !== void 0;
var isFailed = (entry) => entry?.failed === true;
var isBackingOff = (entry) => entry?.error && entry.lastErrorTime && Date.now() - entry.lastErrorTime < getBackoff(entry.retryCount || 0);
var RemoteWidgetRequestError = class extends Error {};
var isSameOrigin = (route) => new URL(route, location.href).origin === location.origin;
var withQuery = (route, params) => {
	const query = new URLSearchParams(params).toString();
	if (!query) return route;
	return `${route}${route.includes("?") ? "&" : "?"}${query}`;
};
var parseBody = (text) => {
	try {
		return JSON.parse(text);
	} catch {
		return text;
	}
};
var pickKey = (data, key) => {
	if (!key) return data;
	return typeof data === "object" && data !== null ? Reflect.get(data, key) : void 0;
};
var fetchOnSession = async (config, controller) => {
	const { route, query_params, timeout = TIMEOUT } = config;
	if (!isSameOrigin(route)) return void 0;
	const timeoutController = new AbortController();
	const timer = timeout > 0 ? setTimeout(() => timeoutController.abort(), timeout) : 0;
	try {
		const res = await api.fetchOnWebSession(withQuery(route, query_params), {
			method: "GET",
			signal: AbortSignal.any([controller.signal, timeoutController.signal])
		});
		if (!res) return void 0;
		if (!res.ok) throw new RemoteWidgetRequestError(`Request failed with status ${res.status}`);
		return { data: parseBody(await res.text()) };
	} finally {
		clearTimeout(timer);
	}
};
var fetchData = async (config, controller) => {
	const { route, response_key, query_params, timeout = TIMEOUT } = config;
	const sessionRes = await fetchOnSession(config, controller);
	if (sessionRes) return pickKey(sessionRes.data, response_key);
	const authHeaders = await getAuthHeaders();
	const res = await axios.get(route, {
		params: query_params,
		signal: controller.signal,
		timeout,
		...authHeaders
	});
	return response_key ? res.data[response_key] : res.data;
};
function useRemoteWidget(options) {
	const { remoteConfig, defaultValue, node, widget } = options;
	const { refresh = 0, max_retries = MAX_RETRIES$1 } = remoteConfig;
	const isPermanent = refresh <= 0;
	const cacheKey = createCacheKey(remoteConfig);
	let isLoaded = false;
	let refreshQueued = false;
	let removed = false;
	const setSuccess = (entry, data) => {
		entry.retryCount = 0;
		entry.lastErrorTime = 0;
		entry.error = null;
		entry.timestamp = Date.now();
		entry.data = data;
	};
	const setError = (entry, error) => {
		entry.retryCount = (entry.retryCount || 0) + 1;
		entry.lastErrorTime = Date.now();
		entry.error = error instanceof Error ? error : new Error(String(error));
		entry.fetchPromise = void 0;
		if (entry.retryCount >= max_retries) setFailed(entry);
	};
	const setFailed = (entry) => {
		dataCache.set(cacheKey, {
			data: entry.data,
			failed: true
		});
	};
	const isFirstLoad = () => {
		return !isLoaded && isInitialized(dataCache.get(cacheKey));
	};
	const onFirstLoad = (data) => {
		isLoaded = true;
		const nextValue = Array.isArray(data) ? data.find((value) => value === widget.value) ?? data[0] : void 0;
		widget.value = nextValue ?? (Array.isArray(data) ? defaultValue : data);
		widget.callback?.(widget.value);
		node.graph?.setDirtyCanvas(true);
	};
	const fetchValue = async () => {
		const entry = dataCache.get(cacheKey);
		if (isFailed(entry)) return entry.data;
		if (isInitialized(entry) && (isPermanent || !isStale(entry, refresh)) || isBackingOff(entry) || isFetching(entry)) return entry.data;
		const currentEntry = shallowReactive(entry || { data: defaultValue });
		dataCache.set(cacheKey, currentEntry);
		try {
			currentEntry.controller = new AbortController();
			currentEntry.fetchPromise = fetchData(remoteConfig, currentEntry.controller);
			const data = await currentEntry.fetchPromise;
			setSuccess(currentEntry, data);
			return currentEntry.data;
		} catch (err) {
			setError(currentEntry, err);
			return currentEntry.data;
		} finally {
			currentEntry.fetchPromise = void 0;
			currentEntry.controller = void 0;
		}
	};
	const onRefresh = () => {
		if (remoteConfig.control_after_refresh) {
			const data = getCachedValue();
			if (!Array.isArray(data)) return;
			switch (remoteConfig.control_after_refresh) {
				case "first":
					widget.value = data[0] ?? defaultValue;
					break;
				case "last": widget.value = data.at(-1) ?? defaultValue;
			}
			widget.callback?.(widget.value);
			node.graph?.setDirtyCanvas(true);
		}
	};
	/**
	* Clear the widget's cached value, forcing a refresh on next access (e.g., a new render)
	*/
	const clearCachedValue = () => {
		const entry = dataCache.get(cacheKey);
		if (!entry) return;
		if (entry.fetchPromise) entry.controller?.abort();
		dataCache.delete(cacheKey);
	};
	/**
	* Get the cached value of the widget without starting a new fetch.
	* @returns the most recently computed value of the widget.
	*/
	function getCachedValue() {
		return dataCache.get(cacheKey)?.data;
	}
	function getInventoryStatus() {
		const entry = dataCache.get(cacheKey);
		if (isInitialized(entry) && (isPermanent || !isStale(entry, refresh))) return isLoaded ? "ready" : "loading";
		if (isFetching(entry)) return "loading";
		if (isFailed(entry) || entry?.error) return "error";
		return "loading";
	}
	async function waitForInventory(signal) {
		while (!signal?.aborted) {
			const inFlight = dataCache.get(cacheKey)?.fetchPromise;
			if (inFlight) {
				await inFlight.catch(() => void 0);
				continue;
			}
			await new Promise((resolve) => getValue(resolve));
			if (!dataCache.get(cacheKey)?.fetchPromise) return;
		}
	}
	/**
	* Getter of the remote property of the widget (e.g., options.values, value, etc.).
	* Starts the fetch process then returns the cached value immediately.
	* @returns the most recent value of the widget.
	*/
	function getValue(onFulfilled) {
		fetchValue().then((data) => {
			if (removed) return;
			if (isFirstLoad()) onFirstLoad(data);
			if (refreshQueued && data !== defaultValue) {
				onRefresh();
				refreshQueued = false;
			}
		}).finally(() => onFulfilled?.()).catch((err) => {
			console.error(err);
		});
		return getCachedValue();
	}
	/**
	* Force the widget to refresh its value
	*/
	widget.refresh = function() {
		refreshQueued = true;
		clearCachedValue();
		getValue();
	};
	/**
	* Add a refresh button to the node that, when clicked, will force the widget to refresh
	*/
	function addRefreshButton() {
		node.addWidget("button", "refresh", "refresh", widget.refresh);
	}
	/**
	* Add auto-refresh toggle widget and execution success listener
	*/
	function addAutoRefreshToggle() {
		let autoRefreshEnabled = false;
		const handleExecutionSuccess = () => {
			if (autoRefreshEnabled && widget.refresh) widget.refresh();
		};
		const autoRefreshWidget = node.addWidget("toggle", "Auto-refresh after generation", false, (value) => {
			autoRefreshEnabled = value;
		}, { serialize: false });
		api.addEventListener("execution_success", handleExecutionSuccess);
		const cleanup = () => {
			api.removeEventListener("execution_success", handleExecutionSuccess);
		};
		widget.onRemove = useChainCallback(widget.onRemove, () => {
			removed = true;
			cleanup();
		});
		node.onRemoved = useChainCallback(node.onRemoved, cleanup);
		return autoRefreshWidget;
	}
	addAutoRefreshToggle();
	return {
		getCachedValue,
		getValue,
		refreshValue: widget.refresh,
		addRefreshButton,
		getCacheEntry: () => dataCache.get(cacheKey),
		getInventoryStatus,
		waitForInventory,
		cacheKey
	};
}
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/composables/useComboWidget.ts
var getDefaultValue = (inputSpec) => {
	if (inputSpec.default) return inputSpec.default;
	if (inputSpec.options?.length) return inputSpec.options[0];
	if (inputSpec.remote) return "Loading...";
};
var bindDynamicValuesOption = (widget, getValues) => {
	const options = widget.options;
	let fallbackValues = Array.isArray(options.values) ? options.values : [];
	Object.defineProperty(options, "values", {
		configurable: true,
		enumerable: true,
		get: () => {
			const values = getValues();
			if (values === void 0 || values === null) return fallbackValues;
			return values;
		},
		set: (values) => {
			fallbackValues = Array.isArray(values) ? values : fallbackValues;
		}
	});
};
var addMultiSelectWidget = (node, inputSpec) => {
	const widgetValue = ref([]);
	const widget = new ComponentWidgetImpl({
		node,
		name: inputSpec.name,
		component: MultiSelectWidget_default,
		inputSpec,
		options: {
			getValue: () => widgetValue.value,
			setValue: (value) => {
				widgetValue.value = value;
			}
		}
	});
	addWidget(node, widget);
	if (inputSpec.control_after_generate) widget.linkedWidgets = addValueControlWidgets$1(node, widget, typeof inputSpec.control_after_generate === "string" ? inputSpec.control_after_generate : "fixed", void 0, transformInputSpecV2ToV1(inputSpec));
	return widget;
};
var addComboWidget = (node, inputSpec) => {
	const defaultValue = getDefaultValue(inputSpec);
	const widget = node.addWidget("combo", inputSpec.name, defaultValue, () => {}, { values: inputSpec.options ?? [] });
	if (inputSpec.remote) {
		if (!isComboWidget$1(widget)) throw new Error(`Expected combo widget but received ${widget.type}`);
		const remoteWidget = useRemoteWidget({
			remoteConfig: inputSpec.remote,
			defaultValue,
			node,
			widget
		});
		if (inputSpec.remote.refresh_button) remoteWidget.addRefreshButton();
		registerComboWidgetInventory(widget, {
			getStatus: remoteWidget.getInventoryStatus,
			waitForSettled: remoteWidget.waitForInventory
		});
		bindDynamicValuesOption(widget, () => remoteWidget.getValue());
	}
	if (inputSpec.control_after_generate) {
		if (!isComboWidget$1(widget)) throw new Error(`Expected combo widget but received ${widget.type}`);
		widget.linkedWidgets = addValueControlWidgets$1(node, widget, typeof inputSpec.control_after_generate === "string" ? inputSpec.control_after_generate : "randomize", void 0, transformInputSpecV2ToV1(inputSpec));
	}
	return widget;
};
var useComboWidget = () => {
	const widgetConstructor = (node, inputSpec) => {
		if (!isComboInputSpec(inputSpec)) throw new Error(`Invalid input data: ${inputSpec}`);
		return inputSpec.multi_select ? addMultiSelectWidget(node, inputSpec) : addComboWidget(node, inputSpec);
	};
	return widgetConstructor;
};
//#endregion
//#region src/renderer/extensions/compositor/components/types.ts
function emptyCompositorWidgetValue() {
	return {};
}
function isCompositorWidgetValue(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/composables/useCompositorWidget.ts
var useCompositorWidget = () => {
	return (node, inputSpec) => {
		const defaultValue = isCompositorWidgetValue(inputSpec.default) ? inputSpec.default : emptyCompositorWidgetValue();
		const rawWidget = node.addWidget("compositor", inputSpec.name, defaultValue, null, { hideInPanel: true });
		if (rawWidget.type !== "compositor") throw new Error(`Unexpected widget type: ${rawWidget.type}`);
		return rawWidget;
	};
};
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/composables/useFloatWidget.ts
function onFloatValueChange(v) {
	const round = this.options.round;
	if (round) {
		const precision = this.options.precision ?? Math.max(0, -Math.floor(Math.log10(round)));
		const rounded = Math.round(v / round) * round;
		this.value = clamp(Number(rounded.toFixed(precision)), this.options.min ?? -Infinity, this.options.max ?? Infinity);
	} else this.value = v;
}
var useFloatWidget = () => {
	const widgetConstructor = (node, inputSpec) => {
		if (!isFloatInputSpec(inputSpec)) throw new Error(`Invalid input data: ${inputSpec}`);
		const settingStore = useSettingStore();
		const sliderEnabled = !settingStore.get("Comfy.DisableSliders");
		const display_type = inputSpec.display;
		const widgetType = display_type == "gradientslider" ? "gradientslider" : sliderEnabled && display_type == "slider" ? "slider" : display_type == "knob" ? "knob" : "number";
		const step = inputSpec.step ?? .5;
		const precision = settingStore.get("Comfy.FloatRoundingPrecision") || Math.max(0, -Math.floor(Math.log10(step)));
		const enableRounding = !settingStore.get("Comfy.DisableFloatRounding");
		/** Assertion {@link inputSpec.default} */
		const defaultValue = inputSpec.default ?? 0;
		const widget = node.addWidget(widgetType, inputSpec.name, defaultValue, onFloatValueChange, {
			min: inputSpec.min ?? 0,
			max: inputSpec.max ?? 2048,
			round: enableRounding && precision && !inputSpec.round ? Math.pow(10, -precision) : inputSpec.round,
			/** @deprecated Use step2 instead. The 10x value is a legacy implementation. */
			step: step * 10,
			step2: step,
			precision,
			...inputSpec.gradient_stops ? { gradient_stops: inputSpec.gradient_stops } : {}
		});
		if (inputSpec.control_after_generate) widget.linkedWidgets = [addValueControlWidget$1(node, widget, "fixed", void 0, void 0, transformInputSpecV2ToV1(inputSpec))];
		return widget;
	};
	return widgetConstructor;
};
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/composables/useGalleriaWidget.ts
var useGalleriaWidget = () => {
	return (node, inputSpec) => {
		if (!isGalleriaInputSpec(inputSpec)) console.error("Invalid input spec for galleria widget");
		const galleriaSpec = inputSpec;
		const { name } = galleriaSpec;
		const images = galleriaSpec.images ?? galleriaSpec.options?.images ?? [];
		return node.addWidget("galleria", name, images, () => {}, { serialize: true });
	};
};
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/composables/useBoundingBoxesWidget.ts
var useBoundingBoxesWidget = () => {
	return (node, inputSpec) => {
		const spec = inputSpec;
		const defaultValue = spec.default?.map((box) => ({
			...box,
			metadata: {
				...box.metadata,
				palette: [...box.metadata.palette]
			}
		})) ?? [];
		return node.addWidget("boundingboxes", spec.name, defaultValue, null, {
			serialize: true,
			hideInPanel: true
		});
	};
};
//#endregion
//#region packages/viewport3d/src/lightInfo/types.ts
var LIGHT_TYPES = [
	"directional",
	"point",
	"spot"
];
var LIGHT_TYPE_LABEL_KEYS = {
	directional: "lightInfo.directional",
	point: "lightInfo.point",
	spot: "lightInfo.spot"
};
function createDefaultLight(type) {
	if (type === "point") return {
		type,
		color: "#ffffff",
		intensity: 25,
		position: {
			x: 1.2,
			y: 2,
			z: 1.2
		},
		radius: .1
	};
	if (type === "spot") return {
		type,
		color: "#ffffff",
		intensity: 25,
		position: {
			x: 1.2,
			y: 2,
			z: 1.2
		},
		target: {
			x: 0,
			y: 0,
			z: 0
		},
		innerConeAngle: 30,
		outerConeAngle: 45,
		radius: .1
	};
	return {
		type: "directional",
		color: "#ffffff",
		intensity: 1.5,
		position: {
			x: 0,
			y: 1.8,
			z: 1.8
		},
		target: {
			x: 0,
			y: 0,
			z: 0
		},
		radius: .5
	};
}
function cloneLight(light) {
	return {
		...light,
		position: { ...light.position },
		...light.target ? { target: { ...light.target } } : {}
	};
}
function cloneLights(lights) {
	return lights.map(cloneLight);
}
function lightTarget(light) {
	return light.target ?? {
		x: 0,
		y: 0,
		z: 0
	};
}
//#endregion
//#region packages/viewport3d/src/lightInfo/lightsValue.ts
var MIN_OUTER_CONE_ANGLE = 1;
var MAX_CONE_ANGLE = 90;
function isLightType(value) {
	return typeof value === "string" && LIGHT_TYPES.includes(value);
}
function toVec3(value, fallback) {
	const v = value;
	const num = (n, d) => typeof n === "number" && Number.isFinite(n) ? n : d;
	return {
		x: num(v?.x, fallback.x),
		y: num(v?.y, fallback.y),
		z: num(v?.z, fallback.z)
	};
}
function toFinite(value, fallback) {
	return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}
var HEX_COLOR = /^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;
function toColor(value, fallback) {
	return typeof value === "string" && HEX_COLOR.test(value) ? value : fallback;
}
function coneAngles(raw, defaults) {
	const outer = clamp$1(toFinite(raw.outerConeAngle, defaults.outerConeAngle ?? 45), MIN_OUTER_CONE_ANGLE, MAX_CONE_ANGLE);
	return {
		innerConeAngle: clamp$1(toFinite(raw.innerConeAngle, defaults.innerConeAngle ?? 30), 0, outer),
		outerConeAngle: outer
	};
}
function typeSpecificFields(raw, defaults) {
	const range = toFinite(raw.range, 0);
	return {
		...defaults.type !== "point" && { target: toVec3(raw.target, defaults.target ?? {
			x: 0,
			y: 0,
			z: 0
		}) },
		...defaults.type !== "directional" && range > 0 && { range },
		...defaults.type === "spot" && coneAngles(raw, defaults)
	};
}
function normalizeLight(value) {
	if (typeof value !== "object" || value === null) return null;
	const raw = value;
	if (!isLightType(raw.type)) return null;
	const defaults = createDefaultLight(raw.type);
	return {
		type: raw.type,
		color: toColor(raw.color, defaults.color),
		intensity: Math.max(0, toFinite(raw.intensity, defaults.intensity)),
		position: toVec3(raw.position, defaults.position),
		...typeSpecificFields(raw, defaults),
		radius: Math.max(0, toFinite(raw.radius, defaults.radius ?? 0)),
		...raw.castShadow === false && { castShadow: false }
	};
}
function normalizeLightsValue(value) {
	if (!Array.isArray(value)) return [];
	return value.map(normalizeLight).filter((light) => light !== null);
}
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/composables/useLightInfoWidget.ts
var useLightInfoWidget = () => {
	return (node, inputSpec) => {
		return node.addWidget("lightinfo", inputSpec.name, normalizeLightsValue(inputSpec.default), null, {
			serialize: true,
			hideInPanel: true
		});
	};
};
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/composables/useColorsWidget.ts
var useColorsWidget = () => {
	return (node, inputSpec) => {
		const spec = inputSpec;
		const defaultValue = spec.default ? [...spec.default] : [];
		return node.addWidget("colors", spec.name, defaultValue, null, { hideInPanel: true });
	};
};
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/composables/useImageCompareWidget.ts
var useImageCompareWidget = () => {
	return (node, inputSpec) => {
		const { name, options = {} } = inputSpec;
		const widget = node.addWidget("imagecompare", name, ["", ""], () => {}, {
			serialize: true,
			...options,
			hideInPanel: true
		});
		widget.serialize = false;
		return widget;
	};
};
//#endregion
//#region src/base/wheelGestures.ts
/**
* Wheel events whose browser default would break the editing experience.
* On macOS trackpads:
*   - `ctrl/meta + wheel` (pinch-zoom) triggers page-level zoom, which
*     pushes fixed-position UI (e.g. ComfyActionbar) off-screen with no
*     recovery short of a page reload.
*   - Horizontal-dominant wheel (two-finger horizontal swipe) triggers
*     back/forward navigation, which leaves the workflow.
*
* Equal `|deltaX| == |deltaY|` (including idle 0/0 frames between meaningful
* trackpad samples) intentionally falls on the false branch so native
* vertical scroll wins on a tie.
*
* Components that intercept wheel events should suppress the default for
* these gestures even when they otherwise let the browser scroll natively.
*/
var isCanvasGestureWheel = (event) => event.ctrlKey || event.metaKey || Math.abs(event.deltaX) > Math.abs(event.deltaY);
//#endregion
//#region src/renderer/core/canvas/useCanvasInteractions.ts
/**
* Composable for handling canvas interactions from Vue components.
* This provides a unified way to forward events to the LiteGraph canvas.
*/
function useCanvasInteractions() {
	const settingStore = useSettingStore();
	const canvasStore = useCanvasStore();
	const isStandardNavMode = computed(() => settingStore.get("Comfy.Canvas.NavigationMode") === "standard");
	/**
	* Whether Vue node components should handle pointer events.
	* Returns false when canvas is in read-only/panning mode (e.g., space key held for panning).
	*/
	const shouldHandleNodePointerEvents = computed(() => !canvasStore.isReadOnly);
	/**
	* Returns true if the wheel event target is inside an element that should
	* capture wheel events AND that element (or a descendant) currently has focus.
	*
	* This allows two-finger panning to continue over inputs until the user has
	* actively focused the widget, at which point the widget can consume scroll.
	*/
	const wheelCapturedByFocusedElement = (event) => {
		const captureElement = event.target?.closest("[data-capture-wheel=\"true\"]");
		const active = document.activeElement;
		return !!(captureElement && active && captureElement.contains(active));
	};
	/**
	* Forward to canvas when the event is not consumed by a focused widget,
	* or when it is a canvas gesture (which must override widget consumption
	* to prevent destructive browser defaults).
	*/
	const shouldForwardWheelEvent = (event) => !wheelCapturedByFocusedElement(event) || isCanvasGestureWheel(event);
	/**
	* Handles wheel events from UI components that should be forwarded to canvas
	* when appropriate (e.g., Ctrl+wheel for zoom, two-finger pan in standard
	* mode; all wheel events in legacy mode).
	*/
	const handleWheel = (event) => {
		if (!shouldForwardWheelEvent(event)) return;
		if (isStandardNavMode.value) {
			if (isCanvasGestureWheel(event)) forwardEventToCanvas(event);
			return;
		}
		forwardEventToCanvas(event);
	};
	/**
	* Handles pointer events from media elements that should potentially
	* be forwarded to canvas (e.g., space+drag for panning)
	*/
	const forwardMiddlePointerIfNeeded = (event, isMiddleInput) => {
		if (isMiddleInput(event)) {
			forwardEventToCanvas(event);
			return true;
		}
		return false;
	};
	const handleLeftButtonReadOnlyPointer = (event) => {
		if (canvasStore.canvas?.read_only && event.buttons === 1) {
			event.preventDefault();
			event.stopPropagation();
			forwardEventToCanvas(event);
		}
	};
	const handlePointerDown = (event) => {
		if (forwardMiddlePointerIfNeeded(event, isMiddlePointerInput)) return;
		handleLeftButtonReadOnlyPointer(event);
	};
	const handlePointerMove = (event) => {
		if (forwardMiddlePointerIfNeeded(event, isMiddleButtonHeld)) return;
		handleLeftButtonReadOnlyPointer(event);
	};
	const handlePointerUp = (event) => {
		if (forwardMiddlePointerIfNeeded(event, isMiddleButtonEvent)) return;
		handleLeftButtonReadOnlyPointer(event);
	};
	/**
	* Forwards an event to the LiteGraph canvas
	*/
	const forwardEventToCanvas = (event) => {
		if (event instanceof WheelEvent && !shouldForwardWheelEvent(event)) return;
		const canvasEl = canvasStore.canvas?.canvas;
		if (!canvasEl) return;
		event.preventDefault();
		event.stopPropagation();
		if (event instanceof WheelEvent) {
			const { clientX, clientY, deltaX, deltaY, ctrlKey, metaKey, shiftKey } = event;
			canvasEl.dispatchEvent(new WheelEvent("wheel", {
				clientX,
				clientY,
				deltaX,
				deltaY,
				ctrlKey,
				metaKey,
				shiftKey
			}));
			return;
		}
		if (event instanceof PointerEvent) {
			canvasEl.dispatchEvent(new PointerEvent(event.type, event));
			return;
		}
		canvasEl.dispatchEvent(new MouseEvent(event.type, event));
	};
	return {
		handleWheel,
		handlePointerDown,
		handlePointerMove,
		handlePointerUp,
		forwardEventToCanvas,
		shouldHandleNodePointerEvents
	};
}
//#endregion
//#region src/platform/telemetry/imageFailureDiagnostics.ts
/**
* An `<img>` `error` event carries no status, no headers and no body — the
* browser tells you it failed and nothing else. That is why FE-1595 needed the
* reporting artist's Network tab: `app:image_load_failed` fired on every broken
* preview but could not say whether the cause was an expired session cookie
* (401), a missing output (404), or a dropped connection.
*
* So we re-request the same URL once, only after a failure, and report the
* status the browser would not give us. The probe is deliberately cheap and
* deliberately incapable of making things worse:
*
* - `Range: bytes=0-0` asks for a single byte, so a probe of a 20MB output does
*   not re-download it. Servers that ignore `Range` answer 200 with the body,
*   which is why the response is never read.
* - `credentials: 'include'` mirrors how the browser sent the original `<img>`
*   request. Probing without it would send no cookie and manufacture the very
*   401 we are trying to measure.
* - Failures resolve to `probe_failed`/`probe_blocked` rather than throwing. A
*   diagnostic must never become the second error in the report.
*/
/** Probes are capped per page so a node retrying a missing file in a loop cannot amplify. */
var MAX_PROBES_PER_PAGE = 20;
/**
* A probe that outlives this is worth less than the request it occupies. Kept
* short because the report is emitted after it: a long budget turns every
* failed image into a window where a page unload loses the event entirely.
*/
var PROBE_TIMEOUT_MS = 2e3;
var probesIssued = 0;
/**
* `type` in an `/api/view` URL distinguishes a generated output from a user
* upload. A 404 on `output` means the result expired or was swept; a 404 on
* `input` means the upload never landed. They are different bugs and the
* current event cannot tell them apart.
*/
function resourceKind(url) {
	const type = url.searchParams.get("type");
	if (type === "output" || type === "input" || type === "temp") return type;
	return url.searchParams.has("filename") ? "unspecified" : "not_api_view";
}
/**
* The filename shape separates "a generation we produced" from "a template
* asset we ship". Template thumbnails 404ing is a packaging bug on our side;
* a hashed output 404ing is a retention/lifecycle bug. Reporting the shape
* rather than the name keeps user-authored filenames out of telemetry.
*/
function filenameKind(url) {
	const filename = url.searchParams.get("filename");
	if (!filename) return "none";
	if (filename.startsWith("template-")) return "template";
	if (/^[0-9a-f]{64}\./i.test(filename)) return "content_hash";
	return "named";
}
/**
* Resolves if the page starts going away, so a pending probe cannot hold the
* report hostage. Never resolves otherwise — it only ever loses the race.
*
* The caller aborts `signal` once the race settles. Without that the listener
* outlives every probe that wins, and this runs on *every* failed image —
* including those past the probe cap, where a node retrying a missing file can
* produce hundreds in one session.
*/
function abandonOnUnload(signal) {
	return new Promise((resolve) => {
		window.addEventListener("pagehide", () => resolve({ probe_outcome: "probe_abandoned" }), {
			once: true,
			signal
		});
	});
}
async function probeStatus(src) {
	if (probesIssued >= MAX_PROBES_PER_PAGE) return { probe_outcome: "probe_capped" };
	probesIssued += 1;
	try {
		const response = await fetch(src, {
			method: "GET",
			credentials: "include",
			headers: { Range: "bytes=0-0" },
			redirect: "manual",
			signal: AbortSignal.timeout(PROBE_TIMEOUT_MS)
		});
		if (response.type === "opaqueredirect") return { probe_outcome: "probe_redirected" };
		response.body?.cancel().catch(() => {});
		return {
			status: response.status,
			probe_outcome: "probed"
		};
	} catch (error) {
		return { probe_outcome: error instanceof DOMException && error.name === "TimeoutError" ? "probe_timeout" : "probe_failed" };
	}
}
/**
* Builds the metadata for one failed preview. Never throws and never rejects.
*
* `page_age_ms` is the field that would have identified FE-1595 on its own: the
* session-cookie bug could only strike a page open longer than the cookie's
* 2-hour life, so an auth-caused failure population skews old while a 404
* population does not. It is page age, not session age — a reload mints a fresh
* cookie, which is exactly the boundary that matters.
*/
async function describeImageLoadFailure(src) {
	const base = {
		source: "node_image_preview",
		page_age_ms: Math.round(performance.now()),
		online: navigator.onLine,
		resource_kind: "not_api_view",
		filename_kind: "none",
		probe_outcome: "probe_blocked"
	};
	if (!src.trim()) return {
		...base,
		probe_outcome: "invalid_src"
	};
	let url;
	try {
		url = new URL(src, window.location.href);
	} catch {
		return {
			...base,
			probe_outcome: "invalid_src"
		};
	}
	const shape = {
		...base,
		resource_kind: resourceKind(url),
		filename_kind: filenameKind(url),
		same_origin: url.origin === window.location.origin
	};
	if (!shape.same_origin) return shape;
	const settled = new AbortController();
	try {
		return {
			...shape,
			...await Promise.race([probeStatus(src), abandonOnUnload(settled.signal)])
		};
	} finally {
		settled.abort();
	}
}
//#endregion
//#region src/composables/node/useNodeImage.ts
var VIDEO_WIDGET_NAME = "video-preview";
var VIDEO_DEFAULT_OPTIONS = {
	playsInline: true,
	controls: true,
	loop: true
};
var MEDIA_LOAD_TIMEOUT = 8192;
var MAX_RETRIES = 1;
var DEFAULT_VIDEO_SIZE = 256;
var createContainer = () => {
	const container = document.createElement("div");
	container.classList.add("comfy-img-preview");
	return container;
};
var createTimeout = (ms) => new Promise((resolve) => setTimeout(() => resolve(null), ms));
/** Distinguishes "the load stalled" from "the load was rejected"; both otherwise yield `null`. */
var MEDIA_LOAD_TIMED_OUT = Symbol("media-load-timed-out");
var useNodePreview = (node, options) => {
	const { loadElement, onLoaded, onFailedLoading, telemetrySource } = options;
	const nodeOutputStore = useNodeOutputStore();
	const loadElementWithTimeout = async (url, retryCount = 0) => {
		const raced = await Promise.race([loadElement(url), createTimeout(MEDIA_LOAD_TIMEOUT).then(() => MEDIA_LOAD_TIMED_OUT)]);
		const timedOut = raced === MEDIA_LOAD_TIMED_OUT;
		const result = timedOut ? null : raced;
		if (result === null && retryCount < MAX_RETRIES) return loadElementWithTimeout(url, retryCount + 1);
		if (result === null) describeImageLoadFailure(url).then((diagnostics) => {
			useTelemetry()?.trackImageLoadFailed({
				...diagnostics,
				source: telemetrySource,
				attempts: retryCount + 1,
				timed_out: timedOut
			});
		});
		return result;
	};
	const loadElements = async (urls) => Promise.all(urls.map((url) => loadElementWithTimeout(url)));
	/**
	* Displays media element(s) on the node.
	*/
	function showPreview(options = {}) {
		if (node.isLoading) return;
		const outputUrls = nodeOutputStore.getNodeImageUrls(node);
		if (!outputUrls?.length) return;
		if (options.block) node.isLoading = true;
		loadElements(outputUrls).then((elements) => {
			const validElements = elements.filter((el) => el !== null);
			if (validElements.length) {
				onLoaded?.(validElements);
				node.graph?.setDirtyCanvas(true);
			}
		}).catch(() => {
			onFailedLoading?.();
		}).finally(() => {
			node.isLoading = false;
		});
	}
	return { showPreview };
};
/**
* Attaches a preview image to a node.
*/
var useNodeImage = (node, callback) => {
	node.previewMediaType = "image";
	const loadElement = (url) => new Promise((resolve) => {
		const img = new Image();
		img.onload = () => resolve(img);
		img.onerror = () => resolve(null);
		const previewUrl = getHdrPreviewUrl(url);
		if (previewUrl) img.dataset.fileUrl = url;
		img.src = previewUrl ?? url;
	});
	const onLoaded = (elements) => {
		node.imageIndex = null;
		node.imgs = elements;
		callback?.();
	};
	return useNodePreview(node, {
		loadElement,
		onLoaded,
		telemetrySource: "canvas_node_image",
		onFailedLoading: () => {
			node.imgs = void 0;
		}
	});
};
/**
* Attaches a preview video to a node.
*/
var useNodeVideo = (node, callback) => {
	node.previewMediaType = "video";
	let minHeight = DEFAULT_VIDEO_SIZE;
	let minWidth = DEFAULT_VIDEO_SIZE;
	const { handleWheel, handlePointerDown, handlePointerMove } = useCanvasInteractions();
	const setMinDimensions = (video) => {
		const { minHeight: calculatedHeight, minWidth: calculatedWidth } = fitDimensionsToNodeWidth(video.videoWidth, video.videoHeight, node.size[0] || DEFAULT_VIDEO_SIZE);
		minWidth = calculatedWidth;
		minHeight = calculatedHeight;
	};
	const loadElement = (url) => new Promise((resolve) => {
		const video = document.createElement("video");
		Object.assign(video, VIDEO_DEFAULT_OPTIONS);
		video.onloadeddata = () => {
			setMinDimensions(video);
			resolve(video);
		};
		video.onerror = () => resolve(null);
		video.src = url;
	});
	const addVideoDomWidget = (container) => {
		if (!node.widgets?.some((w) => w.name === VIDEO_WIDGET_NAME)) {
			const widget = node.addDOMWidget(VIDEO_WIDGET_NAME, "video", container, {
				surfaces: {
					canvas: "shown",
					vueNode: "never",
					panel: "never"
				},
				hideOnZoom: false
			});
			widget.serialize = false;
			widget.computeLayoutSize = () => ({
				minHeight,
				minWidth
			});
			const controller = new AbortController();
			const { signal } = controller;
			container.addEventListener("wheel", handleWheel, { signal });
			container.addEventListener("pointermove", handlePointerMove, { signal });
			container.addEventListener("pointerdown", handlePointerDown, { signal });
			widget.onRemove = useChainCallback(widget.onRemove, () => {
				controller.abort();
			});
		}
	};
	const onLoaded = (videoElements) => {
		const videoElement = videoElements[0];
		if (!node.videoContainer) {
			node.videoContainer = createContainer();
			addVideoDomWidget(node.videoContainer);
		}
		node.videoContainer.replaceChildren(videoElement);
		callback?.();
	};
	return useNodePreview(node, {
		loadElement,
		onLoaded,
		telemetrySource: "canvas_node_video",
		onFailedLoading: () => {
			node.videoContainer = void 0;
		}
	});
};
//#endregion
//#region src/utils/eventUtils.ts
function getDroppedAsset(dataTransfer) {
	const asset = parseAssetInfo(dataTransfer);
	const name = asset?.display_name ?? asset?.filename;
	const validTypes = ["text/uri-list", "text/x-moz-url"];
	const match = [...dataTransfer.types].find((type) => validTypes.includes(type));
	const uri = match && dataTransfer.getData(match).split("\n")[0];
	const ref = asset?.attachment_ref;
	return uri || ref ? {
		name: name ?? ref ?? uri,
		uri,
		ref,
		kind: asset?.media_kind,
		previewUrl: asset?.preview_url,
		mediaUrl: asset?.media_url
	} : void 0;
}
function decodedBasename(pathname) {
	const segment = pathname.split("/").pop() || "";
	try {
		return decodeURIComponent(segment);
	} catch {
		return segment;
	}
}
function sourceFileName({ name, ref }, uri, responseUrl) {
	const resolvedUrl = new URL(responseUrl || uri, "http://localhost");
	return [
		resolvedUrl.searchParams.get("filename"),
		ref,
		decodedBasename(resolvedUrl.pathname),
		name
	].find((candidate) => candidate && /\.[a-z0-9]{1,8}$/i.test(candidate)) || name;
}
async function fetchDroppedAsset(asset, { signal, nameFromSource = false } = {}) {
	const { name, uri } = asset;
	if (!uri) return void 0;
	try {
		const response = await fetch(uri, { signal });
		if (!response.ok) return void 0;
		const blob = await response.blob();
		const fileName = nameFromSource ? sourceFileName(asset, uri, response.url) : name;
		return new File([blob], fileName, { type: blob.type });
	} catch {
		return;
	}
}
async function extractFilesFromDragEvent(event) {
	if (!event.dataTransfer) return [];
	const files = Array.from(event.dataTransfer.files).filter((file) => file.type !== "image/bmp").map(withHdrImageType);
	if (files.length > 0) return files;
	const asset = getDroppedAsset(event.dataTransfer);
	if (!asset) return [];
	const file = await fetchDroppedAsset(asset);
	return file ? [file] : [];
}
function withHdrImageType(file) {
	if (file.type || !isHdrImageFilename(file.name)) return file;
	const type = file.name.toLowerCase().endsWith(".hdr") ? "image/vnd.radiance" : "image/x-exr";
	return new File([file], file.name, {
		type,
		lastModified: file.lastModified
	});
}
function hasImageType({ type }) {
	return type.startsWith("image");
}
function hasAudioType({ type }) {
	return type.startsWith("audio");
}
function hasVideoType({ type }) {
	return type.startsWith("video");
}
function isMediaFile(file) {
	return hasImageType(file) || hasAudioType(file) || hasVideoType(file);
}
//#endregion
//#region src/composables/node/useNodeDragAndDrop.ts
/**
* Adds drag and drop file handling to a node
* Will also resolve 'text/uri-list' to a file before passing
*/
var useNodeDragAndDrop = (node, options) => {
	const { onDragOver, onDrop, fileFilter = () => true } = options;
	const hasFiles = (items) => !!Array.from(items).find((f) => f.kind === "file");
	const filterFiles = (files) => Array.from(files).filter(fileFilter);
	function handleRejectedFiles(files) {
		return files.length > 0 && (options.onReject?.(files) ?? false);
	}
	const isDraggingFiles = (e) => {
		if (!e?.dataTransfer?.items) return false;
		return onDragOver?.(e) ?? (hasFiles(e.dataTransfer.items) || e.dataTransfer.types.includes("text/uri-list"));
	};
	const installedDragOver = isDraggingFiles;
	node.onDragOver = installedDragOver;
	const installedDragDrop = async function(e) {
		const { dataTransfer } = e;
		if (!dataTransfer) return false;
		const droppedFiles = Array.from(dataTransfer.files, withHdrImageType);
		const [files, rejectedFiles] = partition(droppedFiles, fileFilter);
		const rejectedFilesClaimed = handleRejectedFiles(rejectedFiles);
		if (files.length) {
			await onDrop(files);
			return true;
		}
		if (dataTransfer.files.length) return rejectedFilesClaimed;
		const asset = parseAssetInfo(dataTransfer);
		if (asset?.filename && options.onResultItemDrop) {
			await options.onResultItemDrop(asset);
			return true;
		}
		const baseUri = dataTransfer.getData("text/uri-list");
		if (!baseUri) return false;
		const uri = URL.parse(baseUri, location.href);
		if (!uri || uri.origin !== location.origin) return false;
		try {
			const resp = await fetch(uri);
			const fileName = asset?.filename ?? uri.searchParams.get("filename") ?? baseUri.split("/").at(-1);
			if (!fileName || !resp.ok) return false;
			const blob = await resp.blob();
			const file = new File([blob], fileName, { type: blob.type });
			const uriFiles = filterFiles([file]);
			if (!uriFiles.length) return handleRejectedFiles([file]);
			await onDrop(uriFiles);
		} catch {
			return false;
		}
		return true;
	};
	node.onDragDrop = installedDragDrop;
	node.onRemoved = useChainCallback(node.onRemoved, () => {
		if (node.onDragOver === installedDragOver) node.onDragOver = void 0;
		if (node.onDragDrop === installedDragDrop) node.onDragDrop = void 0;
	});
};
//#endregion
//#region src/composables/node/useNodeFileInput.ts
/**
* Creates a file input for a node.
*/
function useNodeFileInput(node, options) {
	const { accept, allow_batch = false, fileFilter = () => true, onSelect } = options;
	let fileInput = document.createElement("input");
	fileInput.type = "file";
	fileInput.accept = accept ?? "*";
	fileInput.multiple = allow_batch;
	fileInput.onchange = () => {
		const selectedFiles = fileInput?.files?.length ? Array.from(fileInput.files) : [];
		const [files, rejectedFiles] = partition(selectedFiles, fileFilter);
		if (fileInput) fileInput.value = "";
		if (rejectedFiles.length) options.onReject?.(rejectedFiles);
		if (files.length) onSelect(files);
	};
	node.onRemoved = useChainCallback(node.onRemoved, () => {
		if (fileInput) {
			fileInput.onchange = null;
			fileInput = null;
		}
	});
	return { openFileSelection: () => fileInput?.click() };
}
//#endregion
//#region src/composables/node/useNodePaste.ts
/**
* Adds paste handling to a node
*/
var useNodePaste = (node, options) => {
	const { onPaste, fileFilter = () => true, allow_batch = false } = options;
	const installedPasteFiles = function(files) {
		const [filteredFiles, rejectedFiles] = partition(files, fileFilter);
		if (rejectedFiles.length) options.onReject?.(rejectedFiles);
		if (!filteredFiles.length) return;
		const paste = allow_batch ? filteredFiles : filteredFiles.slice(0, 1);
		onPaste(paste);
	};
	node.pasteFiles = installedPasteFiles;
	node.onRemoved = useChainCallback(node.onRemoved, () => {
		if (node.pasteFiles === installedPasteFiles) node.pasteFiles = void 0;
	});
};
//#endregion
//#region src/composables/node/useNodeImageUpload.ts
var UPLOAD_TIMEOUT_MS = 12e4;
var BYTES_PER_MB = 1048576;
function buildUploadErrorMessage(resp) {
	if (resp.status === 413) {
		const maxUploadSize = api.getServerFeature(ServerFeatureFlag.MAX_UPLOAD_SIZE);
		return typeof maxUploadSize === "number" && maxUploadSize > 0 ? t("g.uploadFileTooLargeWithLimit", { limit: Math.round(maxUploadSize / BYTES_PER_MB) }) : t("g.uploadFileTooLarge");
	}
	return t("g.uploadFailed", { reason: resp.statusText || `HTTP ${resp.status}` });
}
var uploadFile = async (file, formFields = {}) => {
	const body = new FormData();
	body.append("image", file);
	if (formFields.type) body.append("type", formFields.type);
	const resp = await api.fetchApi("/upload/image", {
		method: "POST",
		body,
		timeoutMs: UPLOAD_TIMEOUT_MS
	});
	if (resp.status !== 200) {
		useToast().warning(buildUploadErrorMessage(resp));
		return;
	}
	const data = await resp.json();
	if (formFields.type === "input" || !formFields.type) await useAssetsStore().inputAssets.invalidate();
	return data.subfolder ? `${data.subfolder}/${data.name}` : data.name;
};
/**
* Adds image upload to a node via drag & drop, paste, and file input.
*/
var useNodeImageUpload = (node, options) => {
	const { fileFilter, onUploadComplete, allow_batch, accept } = options;
	const handleUpload = async (file) => {
		try {
			const path = await uploadFile(file, { type: options.folder });
			if (!path) return;
			return path;
		} catch (error) {
			if (error instanceof DOMException && error.name === "TimeoutError") useToast().warning(t("g.uploadTimedOut"));
			else useToast().warning(t("g.uploadFailed", { reason: getErrorMessage(error) ?? t("g.unknownError") }));
		}
	};
	const handleUploadBatch = async (files) => {
		if (node.isUploading) {
			useToast().warning(t("g.uploadAlreadyInProgress"));
			return [];
		}
		node.isUploading = true;
		try {
			node.imgs = void 0;
			node.graph?.setDirtyCanvas(true);
			options.onUploadStart?.(files);
			const validPaths = (await Promise.all(files.map(handleUpload))).filter((p) => !!p);
			if (validPaths.length) onUploadComplete(validPaths);
			else options.onUploadError?.();
			return validPaths;
		} finally {
			node.isUploading = false;
			node.graph?.setDirtyCanvas(true);
		}
	};
	useNodeDragAndDrop(node, {
		fileFilter,
		onReject: options.onReject,
		onDrop: handleUploadBatch,
		onResultItemDrop: (item) => onUploadComplete([item])
	});
	useNodePaste(node, {
		fileFilter,
		onReject: options.onReject,
		allow_batch,
		onPaste: handleUploadBatch
	});
	const { openFileSelection } = useNodeFileInput(node, {
		fileFilter,
		onReject: options.onReject,
		allow_batch,
		accept,
		onSelect: handleUploadBatch
	});
	return {
		openFileSelection,
		handleUpload
	};
};
//#endregion
//#region src/types/nodeDefAugmentation.ts
/**
* Type guard to check if an InputSpec has image upload augmentations.
* Narrows from base InputSpec to augmented type.
*/
function isImageUploadInput(inputData) {
	const options = inputData[1];
	return options !== void 0 && typeof options === "object" && "imageInputName" in options && typeof options.imageInputName === "string";
}
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/composables/useImageUploadWidget.ts
function isImageFile(file) {
	return file.type.startsWith("image/");
}
var findFileComboWidget = (node, inputName) => node.widgets?.find((w) => w.name === inputName);
var useImageUploadWidget = () => {
	const widgetConstructor = (node, inputName, inputData) => {
		if (!isImageUploadInput(inputData)) throw new Error("Image upload widget requires imageInputName augmentation");
		const inputOptions = inputData[1];
		const { imageInputName, allow_batch, image_folder = "input" } = inputOptions;
		const folder = image_folder;
		const nodeOutputStore = useNodeOutputStore();
		const isAnimated = !!inputOptions.animated_image_upload;
		const isVideo = !!inputOptions.video_upload;
		const accept = isVideo ? ACCEPTED_VIDEO_TYPES : ACCEPTED_IMAGE_TYPES;
		const { showPreview } = isVideo ? useNodeVideo(node) : useNodeImage(node);
		const fileFilter = isVideo ? isUploadableVideo : isImageFile;
		function alertExtensionlessVideo(files) {
			if (!files.some(isExtensionlessVideo)) return false;
			useToast().warning(t("g.videoFilenameExtensionRequired"));
			return true;
		}
		const fileComboWidget = findFileComboWidget(node, imageInputName);
		if (!fileComboWidget) throw new Error(`Widget "${imageInputName}" not found on node`);
		function formatPath(value) {
			return typeof value === "string" ? createAnnotatedPath(value, { rootFolder: image_folder }) : createAnnotatedPath(value);
		}
		let rollback;
		const { openFileSelection } = useNodeImageUpload(node, {
			allow_batch,
			fileFilter,
			accept,
			folder,
			onReject: isVideo ? alertExtensionlessVideo : void 0,
			onUploadStart: (files) => {
				if (files.length > 0) {
					const prev = fileComboWidget.value;
					fileComboWidget.value = files[0].name;
					rollback = () => {
						fileComboWidget.value = prev;
					};
				}
			},
			onUploadError: () => {
				rollback?.();
				rollback = void 0;
			},
			onUploadComplete: (output) => {
				rollback = void 0;
				const annotated = output.map(formatPath);
				annotated.forEach((path) => {
					addToComboValues(fileComboWidget, path);
				});
				const newValue = allow_batch ? annotated : annotated[0];
				const oldValue = fileComboWidget.value;
				fileComboWidget.value = newValue;
				fileComboWidget.callback?.(newValue);
				node.onWidgetChanged?.(fileComboWidget.name, newValue, oldValue, fileComboWidget);
				useWorkflowStore().activeWorkflow?.changeTracker.captureCanvasState();
			}
		});
		const uploadWidget = node.addWidget("button", inputName, "image", () => openFileSelection(), {
			serialize: false,
			surfaces: {
				canvas: "shown",
				vueNode: "never",
				panel: "never"
			}
		});
		uploadWidget.label = t("g.choose_file_to_upload");
		fileComboWidget.callback = function() {
			node.imgs = void 0;
			nodeOutputStore.setNodeOutputs(node, String(fileComboWidget.value), { isAnimated });
			showPreview({ block: false });
			node.graph?.setDirtyCanvas(true);
		};
		requestAnimationFrame(() => {
			const fileValue = fileComboWidget.value;
			if (fileValue != null) nodeOutputStore.setNodeOutputs(node, String(fileValue), { isAnimated });
			showPreview({ block: false });
		});
		return { widget: uploadWidget };
	};
	return widgetConstructor;
};
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/composables/useIntWidget.ts
function onValueChange(v) {
	const step = this.options.step2 || 1;
	if (step === 1) this.value = Math.round(v);
	else {
		const offset = (this.options.min ?? 0) % step;
		this.value = Math.round((v - offset) / step) * step + offset;
	}
}
var useIntWidget = () => {
	const widgetConstructor = (node, inputSpec) => {
		if (!isIntInputSpec(inputSpec)) throw new Error(`Invalid input data: ${inputSpec}`);
		const sliderEnabled = !useSettingStore().get("Comfy.DisableSliders");
		const display_type = inputSpec.display;
		const widgetType = display_type == "color" ? "color" : sliderEnabled && display_type == "slider" ? "slider" : display_type == "knob" ? "knob" : "number";
		const step = inputSpec.step ?? 1;
		/** Assertion {@link inputSpec.default} */
		const defaultValue = inputSpec.default ?? 0;
		const options = {
			min: inputSpec.min ?? 0,
			max: inputSpec.max ?? 2048,
			/** @deprecated Use step2 instead. The 10x value is a legacy implementation. */
			step: step * 10,
			step2: step,
			precision: 0
		};
		if (display_type == "color") options.format = "int";
		const widget = node.addWidget(widgetType, inputSpec.name, defaultValue, onValueChange, options);
		if (inputSpec.control_after_generate ?? ["seed", "noise_seed"].includes(inputSpec.name)) widget.linkedWidgets = [addValueControlWidget$1(node, widget, typeof inputSpec.control_after_generate === "string" ? inputSpec.control_after_generate : "randomize", void 0, void 0, transformInputSpecV2ToV1(inputSpec))];
		return widget;
	};
	return widgetConstructor;
};
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/utils/forwardMiddleButtonToCanvas.ts
function forwardMiddleButtonToCanvas(inputEl, signal) {
	inputEl.addEventListener("pointerdown", (event) => {
		if (isMiddlePointerInput(event)) useApp().canvas.processMouseDown(event);
	}, { signal });
	inputEl.addEventListener("pointermove", (event) => {
		if (isMiddleButtonHeld(event)) useApp().canvas.processMouseMove(event);
	}, { signal });
	inputEl.addEventListener("pointerup", (event) => {
		if (isMiddleButtonEvent(event)) useApp().canvas.processMouseUp(event);
	}, { signal });
}
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/composables/useMarkdownWidget.ts
function addMarkdownWidget(node, name, opts) {
	const widgetStore = useWidgetValueStore();
	const inputEl = document.createElement("div");
	inputEl.classList.add("comfy-markdown");
	const textarea = document.createElement("textarea");
	inputEl.append(textarea);
	let editor;
	let markdown = opts.defaultVal;
	function render(value) {
		markdown = value;
		editor?.commands.setContent(value);
	}
	const widget = node.addDOMWidget(name, "MARKDOWN", inputEl, {
		getValue() {
			const graphId = resolveNodeRootGraphId(node, useApp().rootGraph.id);
			const storedValue = widgetStore.getWidget(widgetId(graphId, node.id, name))?.value;
			return typeof storedValue === "string" ? storedValue : textarea.value;
		},
		setValue(v) {
			textarea.value = v;
			render(v);
			const graphId = resolveNodeRootGraphId(node, useApp().rootGraph.id);
			const widgetState = widgetStore.getWidget(widgetId(graphId, node.id, name));
			if (widgetState) widgetState.value = v;
		}
	});
	widget.element = inputEl;
	widget.options.minNodeSize = [400, 200];
	const controller = new AbortController();
	const { signal } = controller;
	inputEl.addEventListener("input", (event) => {
		if (event.target instanceof HTMLTextAreaElement) widget.value = event.target.value;
		widget.callback?.(widget.value);
	}, { signal });
	inputEl.addEventListener("dblclick", () => {
		inputEl.classList.add("editing");
		setTimeout(() => textarea.focus(), 0);
	}, { signal });
	textarea.addEventListener("blur", () => inputEl.classList.remove("editing"), { signal });
	textarea.addEventListener("change", () => {
		render(textarea.value);
		widget.callback?.(widget.value);
	}, { signal });
	inputEl.addEventListener("keydown", (event) => event.stopPropagation(), { signal });
	forwardMiddleButtonToCanvas(inputEl, signal);
	widget.onRemove = useChainCallback(widget.onRemove, () => {
		controller.abort();
		if (editor && !editor.isDestroyed) editor.destroy();
	});
	__vitePreload(async () => {
		const { createMarkdownEditor } = await import("./markdownEditor-BLiFIQ-V.js");
		return { createMarkdownEditor };
	}, __vite__mapDeps([0,1,2]), import.meta.url).then(({ createMarkdownEditor }) => {
		if (signal.aborted) return;
		editor = createMarkdownEditor(inputEl, markdown);
	}).catch((error) => reportError(error, {
		errorType: "error_loading_markdown_editor",
		surface: "platform"
	}));
	return widget;
}
var useMarkdownWidget = () => {
	const widgetConstructor = (node, inputSpec) => {
		return addMarkdownWidget(node, inputSpec.name, { defaultVal: inputSpec.default ?? "" });
	};
	return widgetConstructor;
};
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/composables/usePainterWidget.ts
var usePainterWidget = () => {
	return (node, inputSpec) => {
		return node.addWidget("painter", inputSpec.name, inputSpec.default, null, { hideInPanel: true });
	};
};
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/composables/useRangeWidget.ts
var useRangeWidget = () => {
	return (node, inputSpec) => {
		const spec = inputSpec;
		const defaultValue = spec.default ?? {
			min: 0,
			max: 1
		};
		const options = {
			display: spec.display,
			gradient_stops: spec.gradient_stops,
			show_midpoint: spec.show_midpoint,
			midpoint_scale: spec.midpoint_scale,
			value_min: spec.value_min,
			value_max: spec.value_max,
			hideInPanel: true
		};
		const rawWidget = node.addWidget("range", spec.name, { ...defaultValue }, () => {}, options);
		if (rawWidget.type !== "range") throw new Error(`Unexpected widget type: ${rawWidget.type}`);
		return rawWidget;
	};
};
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/composables/useResolutionPreviewWidget.ts
var useResolutionPreviewWidget = () => {
	return (node, inputSpec) => {
		const spec = isResolutionPreviewInputSpec(inputSpec) ? inputSpec : void 0;
		const options = {
			serialize: false,
			canvasOnly: false,
			hideInPanel: true,
			ratio_widget: spec?.ratio_widget,
			megapixels_widget: spec?.megapixels_widget,
			multiple_widget: spec?.multiple_widget
		};
		const rawWidget = node.addWidget("resolutionpreview", inputSpec.name, null, () => {}, options);
		rawWidget.serialize = false;
		return rawWidget;
	};
};
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/utils/multilineTextarea.ts
var TRACKPAD_DETECTION_THRESHOLD = 50;
/** Creates the `<textarea>` element backing a `customtext` multiline widget. */
function createMultilineInputElement(value, placeholder) {
	const element = document.createElement("textarea");
	element.className = "comfy-multiline-input";
	element.dataset.testid = "dom-widget-textarea";
	element.value = value;
	element.placeholder = placeholder;
	element.spellcheck = useSettingStore().get("Comfy.TextareaWidget.Spellcheck");
	return element;
}
/**
* Wires textarea value propagation, trackpad gestures, and middle-button canvas
* panning onto a `customtext` DOM widget, torn down via the widget's `onRemove`.
*/
function bindMultilineTextareaWidget(widget, element) {
	const controller = new AbortController();
	const { signal } = controller;
	element.addEventListener("input", () => {
		widget.value = element.value;
		widget.callback?.(widget.value);
	}, { signal });
	forwardMiddleButtonToCanvas(element, signal);
	element.addEventListener("wheel", (event) => {
		const gesturesEnabled = useSettingStore().get("LiteGraph.Pointer.TrackpadGestures");
		const deltaX = event.deltaX;
		const deltaY = event.deltaY;
		const canScrollY = element.scrollHeight > element.clientHeight;
		const isHorizontal = Math.abs(deltaX) > Math.abs(deltaY);
		if (event.ctrlKey) {
			event.preventDefault();
			event.stopPropagation();
			useApp().canvas.processMouseWheel(event);
			return;
		}
		if (gesturesEnabled && (Math.abs(deltaX) > 0 || Math.abs(deltaY) < TRACKPAD_DETECTION_THRESHOLD)) {
			event.preventDefault();
			event.stopPropagation();
			useApp().canvas.processMouseWheel(event);
			return;
		}
		if (isHorizontal) {
			event.preventDefault();
			event.stopPropagation();
			useApp().canvas.processMouseWheel(event);
			return;
		}
		if (canScrollY) {
			event.stopPropagation();
			return;
		}
		event.preventDefault();
		useApp().canvas.processMouseWheel(event);
	}, { signal });
	widget.onRemove = useChainCallback(widget.onRemove, () => {
		controller.abort();
	});
}
/**
* Builds the promoted textarea as a host-owned DOM widget, registered directly
* with the DOM widget store since `SubgraphNode.widgets` is a projected getter.
* Returns undefined to fall back to the store-backed projection.
*/
function createPromotedMultilineWidget(context) {
	const { subgraphNode, input, widgetId, sourceWidget } = context;
	const graph = subgraphNode.graph;
	if (!graph || graph.getNodeById(subgraphNode.id) !== subgraphNode) return void 0;
	if (!isDOMWidget(sourceWidget)) return void 0;
	if (!(sourceWidget.element instanceof HTMLTextAreaElement)) return void 0;
	const widgetStore = useWidgetValueStore();
	const readValue = () => {
		const value = widgetStore.getWidget(widgetId)?.value;
		return typeof value === "string" ? value : "";
	};
	const element = createMultilineInputElement(readValue(), input.label ?? input.name);
	const widget = new DOMWidgetImpl({
		node: subgraphNode,
		name: input.name,
		type: "customtext",
		element,
		options: {
			hideOnZoom: true,
			minNodeSize: [400, 200],
			getValue: readValue,
			setValue: (value) => {
				element.value = value;
				widgetStore.setValue(widgetId, value);
			}
		}
	});
	bindMultilineTextareaWidget(widget, element);
	useDomWidgetStore().registerWidget(widget);
	return widget;
}
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/composables/useStringWidget.ts
function addMultilineWidget(node, name, opts) {
	const widgetStore = useWidgetValueStore();
	const inputEl = createMultilineInputElement(opts.defaultVal, opts.placeholder || name);
	let owner;
	let ownState;
	/**
	* Resolves the store entry under the widget's current name and adopts it as
	* its own, or returns undefined once the widget has left its node and the
	* entry belongs to another widget. The widget is found by its element
	* because `addDOMWidget` can invoke `setValue` synchronously, while restoring
	* a saved value, before the `widget` binding it returns is initialized.
	*/
	function adoptOwnEntry() {
		owner ??= node.widgets?.find((widget) => isDOMWidget(widget) && widget.element === inputEl);
		const graphId = resolveNodeRootGraphId(node, useApp().rootGraph.id);
		const id = widgetId(graphId, node.id, owner?.name ?? name);
		const state = widgetStore.getWidget(id);
		if (!(owner !== void 0 && node.widgets?.includes(owner) === true) && ownState !== void 0 && state !== ownState) return void 0;
		ownState = state;
		return {
			id,
			state
		};
	}
	const widgetOptions = {
		getValue() {
			const value = adoptOwnEntry()?.state?.value;
			return typeof value === "string" ? value : inputEl.value;
		},
		setValue(v) {
			inputEl.value = v;
			const entry = adoptOwnEntry();
			if (entry === void 0) return;
			if (entry.state) {
				entry.state.value = v;
				return;
			}
			ownState = widgetStore.registerWidget(entry.id, {
				type: "customtext",
				value: v,
				options: widgetOptions
			});
		}
	};
	const widget = node.addDOMWidget(name, "customtext", inputEl, widgetOptions);
	widget.element = inputEl;
	/** @deprecated Use {@link widget.element} instead (renamed in PR #8594). */
	defineDeprecatedProperty(widget, "inputEl", "element", "widget.inputEl is deprecated. Use widget.element instead.");
	widget.options.minNodeSize = [400, 200];
	bindMultilineTextareaWidget(widget, inputEl);
	return widget;
}
var useStringWidget = () => {
	const widgetConstructor = (node, inputSpec) => {
		if (!isStringInputSpec(inputSpec)) throw new Error(`Invalid input data: ${inputSpec}`);
		const defaultVal = inputSpec.default ?? "";
		const widget = inputSpec.multiline ? addMultilineWidget(node, inputSpec.name, {
			defaultVal,
			placeholder: inputSpec.placeholder
		}) : node.addWidget("text", inputSpec.name, defaultVal, () => {}, {});
		if (typeof inputSpec.dynamicPrompts === "boolean") widget.dynamicPrompts = inputSpec.dynamicPrompts;
		return widget;
	};
	return widgetConstructor;
};
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/composables/useTextareaWidget.ts
var useTextareaWidget = () => {
	return (node, inputSpec) => {
		if (!isTextareaInputSpec(inputSpec)) console.error("Invalid input spec for textarea widget");
		const textareaSpec = inputSpec;
		const { name, options } = textareaSpec;
		const defaultValue = textareaSpec.default ?? options?.default ?? "";
		const widgetOptions = {
			rows: textareaSpec.rows ?? options?.rows ?? 5,
			cols: textareaSpec.cols ?? options?.cols ?? 50
		};
		return node.addWidget("textarea", name, defaultValue, () => {}, {
			serialize: true,
			...widgetOptions
		});
	};
};
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/composables/useVideoEditWidget.ts
var useVideoEditWidget = () => {
	return (node, inputSpec) => {
		const spec = inputSpec;
		const features = spec.features ?? ["trim", "crop"];
		const defaultValue = spec.default ?? {
			...features.includes("trim") && { trim: {
				start_time: 0,
				duration: 0
			} },
			...features.includes("crop") && { crop: {
				x: 0,
				y: 0,
				width: 0,
				height: 0
			} }
		};
		const options = {
			features,
			serialize: true,
			hideInPanel: true
		};
		const rawWidget = node.addWidget("videoedit", spec.name, structuredClone(defaultValue), () => {}, options);
		if (rawWidget.type !== "videoedit") throw new Error(`Unexpected widget type: ${rawWidget.type}`);
		return rawWidget;
	};
};
//#endregion
//#region src/scripts/widgets.ts
/**
* Transforms a V2 widget constructor to a V1 widget constructor.
* @param widgetConstructorV2 The V2 widget constructor to transform.
* @returns The transformed V1 widget constructor.
*/
var transformWidgetConstructorV2ToV1 = (widgetConstructorV2) => {
	return (node, inputName, inputData) => {
		const widget = widgetConstructorV2(node, transformInputSpecV1ToV2(inputData, { name: inputName }));
		return {
			widget,
			minWidth: widget.options.minNodeSize?.[0],
			minHeight: widget.options.minNodeSize?.[1]
		};
	};
};
var ComfyWidgets = {
	INT: transformWidgetConstructorV2ToV1(useIntWidget()),
	FLOAT: transformWidgetConstructorV2ToV1(useFloatWidget()),
	BOOLEAN: transformWidgetConstructorV2ToV1(useBooleanWidget()),
	STRING: transformWidgetConstructorV2ToV1(useStringWidget()),
	MARKDOWN: transformWidgetConstructorV2ToV1(useMarkdownWidget()),
	COMBO: transformWidgetConstructorV2ToV1(useComboWidget()),
	IMAGEUPLOAD: useImageUploadWidget(),
	COLOR: transformWidgetConstructorV2ToV1(useColorWidget()),
	IMAGECOMPARE: transformWidgetConstructorV2ToV1(useImageCompareWidget()),
	BOUNDING_BOX: transformWidgetConstructorV2ToV1(useBoundingBoxWidget()),
	CHART: transformWidgetConstructorV2ToV1(useChartWidget()),
	GALLERIA: transformWidgetConstructorV2ToV1(useGalleriaWidget()),
	PAINTER: transformWidgetConstructorV2ToV1(usePainterWidget()),
	COMPOSITOR: transformWidgetConstructorV2ToV1(useCompositorWidget()),
	TEXTAREA: transformWidgetConstructorV2ToV1(useTextareaWidget()),
	CURVE: transformWidgetConstructorV2ToV1(useCurveWidget()),
	RANGE: transformWidgetConstructorV2ToV1(useRangeWidget()),
	VIDEO_EDIT: transformWidgetConstructorV2ToV1(useVideoEditWidget()),
	RESOLUTION_PREVIEW: transformWidgetConstructorV2ToV1(useResolutionPreviewWidget()),
	BOUNDING_BOXES: transformWidgetConstructorV2ToV1(useBoundingBoxesWidget()),
	LIGHT_INFO_PREVIEW: transformWidgetConstructorV2ToV1(useLightInfoWidget()),
	COLORS: transformWidgetConstructorV2ToV1(useColorsWidget()),
	...dynamicWidgets
};
function isValidWidgetType(key) {
	return typeof key === "string" && Object.hasOwn(ComfyWidgets, key);
}
var addValueControlWidget = addValueControlWidget$1;
var addValueControlWidgets = addValueControlWidgets$1;
var updateControlWidgetLabel = updateControlWidgetLabel$1;
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.widgets = window.comfyAPI.widgets || {};
window.comfyAPI.widgets.ComfyWidgets = ComfyWidgets;
window.comfyAPI.widgets.isValidWidgetType = isValidWidgetType;
window.comfyAPI.widgets.addValueControlWidget = addValueControlWidget;
window.comfyAPI.widgets.addValueControlWidgets = addValueControlWidgets;
window.comfyAPI.widgets.updateControlWidgetLabel = updateControlWidgetLabel;
//#endregion
//#region src/stores/widgetStore.ts
var useWidgetStore = defineStore("widget", () => {
	const coreWidgets = ComfyWidgets;
	const customWidgets = ref(/* @__PURE__ */ new Map());
	const widgets = computed(() => new Map([...customWidgets.value, ...Object.entries(coreWidgets)]));
	function inputIsWidget(spec) {
		const type = Array.isArray(spec) ? getInputSpecType(spec) : spec.type;
		return widgets.value.has(type);
	}
	function registerCustomWidgets(newWidgets) {
		if (!newWidgets) return;
		for (const [type, widget] of Object.entries(newWidgets)) customWidgets.value.set(type, widget);
	}
	return {
		coreWidgets,
		widgets,
		inputIsWidget,
		registerCustomWidgets
	};
});
//#endregion
//#region src/services/extensionService.ts
function isPromiseLike(value) {
	return value instanceof Promise || typeof value === "object" && value !== null && typeof value.then === "function";
}
var graphLoadLifecycleHooks = /* @__PURE__ */ new Set([
	"beforeLoadGraph",
	"beforeConfigureGraph",
	"afterConfigureGraph",
	"afterLoadGraph",
	"onGraphLoadError"
]);
var graphLoadEntrypoints = /* @__PURE__ */ new Set([
	"loadGraphData",
	"loadApiJson",
	"handleFile"
]);
function rejectNestedGraphLoad() {
	return Promise.reject(/* @__PURE__ */ new Error("A graph-load lifecycle hook cannot start a nested graph load"));
}
function createGraphLoadHookApp(app) {
	let dispatching = true;
	return {
		hookApp: new Proxy(app, { get(target, property) {
			if (dispatching && graphLoadEntrypoints.has(property)) return rejectNestedGraphLoad;
			const value = Reflect.get(target, property, target);
			return typeof value === "function" ? value.bind(target) : value;
		} }),
		endDispatch: () => {
			dispatching = false;
		}
	};
}
var useExtensionService = () => {
	const extensionStore = useExtensionStore();
	const settingStore = useSettingStore();
	const keybindingStore = useKeybindingStore();
	const { wrapWithErrorHandling, wrapWithErrorHandlingAsync, toastErrorHandler } = useErrorHandling();
	/**
	* Register an extension with the app.
	* @returns A disposer that stops the extension's auth hooks and unregisters it.
	*/
	const registerExtension = (extension) => {
		if (extensionStore.isHoldingExtensions) {
			extensionStore.holdExtension(extension);
			return once(() => extensionStore.releaseHeldExtension(extension));
		}
		return registerExtensionNow(extension);
	};
	/** Registers an extension even while new ones are held. */
	const registerExtensionNow = (extension) => {
		extensionStore.registerExtension(extension);
		const addKeybinding = wrapWithErrorHandling(keybindingStore.addDefaultKeybinding);
		const addSetting = wrapWithErrorHandling(settingStore.addSetting);
		extension.keybindings?.forEach((keybinding) => {
			addKeybinding(new KeybindingImpl(keybinding));
		});
		useCommandStore().loadExtensionCommands(extension);
		useMenuItemStore().loadExtensionMenuCommands(extension);
		extension.settings?.forEach(addSetting);
		useBottomPanelStore().registerExtensionBottomPanelTabs(extension);
		if (extension.getCustomWidgets) (async () => {
			if (extension.getCustomWidgets) {
				const widgets = await extension.getCustomWidgets(useApp());
				useWidgetStore().registerCustomWidgets(widgets);
			}
		})();
		const authHookHandles = [];
		if (extension.onAuthUserResolved) {
			const { onUserResolved } = useCurrentUser();
			const handleUserResolved = wrapWithErrorHandlingAsync((user) => extension.onAuthUserResolved?.(user, useApp()), (error) => {
				console.error("[Extension Auth Hook Error]", {
					extension: extension.name,
					hook: "onAuthUserResolved",
					error
				});
				toastErrorHandler(error);
			});
			authHookHandles.push(onUserResolved((user) => {
				handleUserResolved(user);
			}));
		}
		if (extension.onAuthTokenRefreshed) {
			const { onTokenRefreshed } = useCurrentUser();
			const handleTokenRefreshed = wrapWithErrorHandlingAsync(() => extension.onAuthTokenRefreshed?.(), (error) => {
				console.error("[Extension Auth Hook Error]", {
					extension: extension.name,
					hook: "onAuthTokenRefreshed",
					error
				});
				toastErrorHandler(error);
			});
			authHookHandles.push(onTokenRefreshed(() => {
				handleTokenRefreshed();
			}));
		}
		if (extension.onAuthUserLogout) {
			const { onUserLogout } = useCurrentUser();
			const handleUserLogout = wrapWithErrorHandlingAsync(() => extension.onAuthUserLogout?.(), (error) => {
				console.error("[Extension Auth Hook Error]", {
					extension: extension.name,
					hook: "onAuthUserLogout",
					error
				});
				toastErrorHandler(error);
			});
			authHookHandles.push(onUserLogout(() => {
				handleUserLogout();
			}));
		}
		return once(() => {
			authHookHandles.forEach((stop) => stop());
			extensionStore.unregisterExtension(extension.name);
		});
	};
	/**
	* Invoke an extension callback
	* @param {keyof ComfyExtension} method The extension callback to execute
	* @param  {unknown[]} args Any arguments to pass to the callback
	* @returns
	*/
	const invokeExtensions = (method, ...args) => {
		const results = [];
		for (const ext of extensionStore.enabledExtensions) if (method in ext) try {
			const fn = ext[method];
			if (typeof fn === "function") results.push(fn.call(ext, ...args, useApp()));
		} catch (error) {
			console.error(`Error calling extension '${ext.name}' method '${method}'`, { error }, { extension: ext }, { args });
		}
		return results;
	};
	/**
	* Invoke an async extension callback
	* Each callback will be invoked concurrently, in extension order. Only
	* extensions that define the callback do any work, and only promises that
	* callbacks actually return are awaited (callbacks that return
	* synchronously are never wrapped in a promise). The resolved array holds
	* the results of the callbacks that ran, so it is not index-aligned with
	* the extensions.
	* @param {string} method The extension callback to execute
	* @param  {...unknown} args Any arguments to pass to the callback
	* @returns
	*/
	const invokeExtensionsAsync = async (method, ...args) => {
		const graphLoadHook = graphLoadLifecycleHooks.has(method) ? createGraphLoadHookApp(useApp()) : void 0;
		const app = graphLoadHook?.hookApp ?? useApp();
		const logError = (ext, error) => console.error(`Error calling extension '${ext.name}' method '${method}'`, { error }, { extension: ext }, { args });
		const pending = [];
		for (const ext of extensionStore.enabledExtensions) try {
			const fn = ext[method];
			if (typeof fn !== "function") continue;
			if (method === "setup") {
				pending.push((async () => {
					legacyMenuCompat.setCurrentExtension(ext.name);
					try {
						return await fn.call(ext, ...args, app);
					} finally {
						legacyMenuCompat.setCurrentExtension(null);
					}
				})().catch((error) => logError(ext, error)));
				continue;
			}
			const result = fn.call(ext, ...args, app);
			pending.push(isPromiseLike(result) ? Promise.resolve(result).catch((error) => logError(ext, error)) : result);
		} catch (error) {
			logError(ext, error);
		}
		try {
			return await Promise.all(pending);
		} finally {
			graphLoadHook?.endDispatch();
		}
	};
	/** Runs one startup step on the given extensions only, in order; returns the ones that threw. */
	const invokeStartupHook = async (extensions, method, ...args) => {
		const failures = [];
		for (const extension of extensions) {
			if (!extensionStore.isExtensionEnabled(extension.name)) continue;
			try {
				const fn = extension[method];
				if (typeof fn !== "function") continue;
				if (method === "setup") legacyMenuCompat.setCurrentExtension(extension.name);
				await fn.call(extension, ...args, useApp());
			} catch (error) {
				failures.push({
					extension,
					method,
					error
				});
			} finally {
				if (method === "setup") legacyMenuCompat.setCurrentExtension(null);
			}
		}
		return failures;
	};
	return {
		registerExtension,
		registerExtensionNow,
		invokeExtensions,
		invokeExtensionsAsync,
		invokeStartupHook
	};
};
provideExtensionService(useExtensionService);
//#endregion
//#region src/composables/canvas/useSelectedLiteGraphItems.ts
/**
* Composable for handling selected LiteGraph items filtering and operations.
* This provides utilities for working with selected items on the canvas,
* including filtering out items that should not be included in selection operations.
*/
function useSelectedLiteGraphItems() {
	const canvasStore = useCanvasStore();
	/**
	* Items that should not show in the selection overlay are ignored.
	* @param item - The item to check.
	* @returns True if the item should be ignored, false otherwise.
	*/
	const isIgnoredItem = (item) => {
		return item instanceof Reroute;
	};
	/**
	* Filter out items that should not show in the selection overlay.
	* @param items - The Set of items to filter.
	* @returns The filtered Set of items.
	*/
	const filterSelectableItems = (items) => {
		const result = /* @__PURE__ */ new Set();
		for (const item of items) if (!isIgnoredItem(item)) result.add(item);
		return result;
	};
	/**
	* Get the filtered selected items from the canvas.
	* @returns The filtered Set of selected items.
	*/
	const getSelectableItems = () => {
		const { selectedItems } = canvasStore.getCanvas();
		return filterSelectableItems(selectedItems);
	};
	/**
	* Check if there are any selectable items.
	* @returns True if there are selectable items, false otherwise.
	*/
	const hasSelectableItems = () => {
		return getSelectableItems().size > 0;
	};
	/**
	* Check if there are multiple selectable items.
	* @returns True if there are multiple selectable items, false otherwise.
	*/
	const hasMultipleSelectableItems = () => {
		return getSelectableItems().size > 1;
	};
	/**
	* The top-level selected nodes from the canonical selection set.
	* Shallow — does NOT expand subgraph children, unlike {@link getSelectedNodes}.
	* Mode toggles use this so they apply to the selected subgraph node, not its
	* descendants. Returns `[]` when the canvas is not yet available, preserving
	* the prior null-tolerance for callers wired to early-firing commands.
	*/
	const getSelectedNodesShallow = () => uniq([...canvasStore.canvas?.selectedItems ?? []].flatMap((item) => {
		if (isLGraphNode(item)) return [item];
		if (isLGraphGroup(item)) return [...item.children].filter(isLGraphNode);
		return [];
	}));
	/**
	* Get only the selected nodes (LGraphNode instances) from the canvas.
	* This filters out other types of selected items like groups or reroutes.
	* If a selected node is a subgraph, this also includes all nodes within it.
	* @returns Array of selected LGraphNode instances and their descendants.
	*/
	const getSelectedNodes = () => {
		const nodeArray = getSelectedNodesShallow();
		if (!nodeArray.some((node) => node.isSubgraphNode() && node.subgraph)) return nodeArray;
		return collectFromNodes(nodeArray);
	};
	/**
	* True iff every selected node is in `mode`. Mirrors the predicate used by
	* {@link toggleSelectedNodesMode} so labels match the toggle's effect.
	* An empty selection returns `false` (no node is in the mode).
	*/
	const areAllSelectedNodesInMode = (mode) => {
		const selectedNodeArray = getSelectedNodesShallow();
		return selectedNodeArray.length > 0 && selectedNodeArray.every((node) => node.mode === mode);
	};
	/**
	* Toggle the execution mode of all selected nodes
	*
	* - If any nodes are not already the specified node mode → all are set to specified mode
	* - Otherwise → set all nodes to ALWAYS
	*
	* @param mode - The LGraphEventMode to toggle to (e.g., NEVER for mute, BYPASS for bypass)
	*/
	const toggleSelectedNodesMode = (mode) => {
		const selectedNodeArray = getSelectedNodesShallow();
		const newModeForSelectedNode = areAllSelectedNodesInMode(mode) ? LGraphEventMode.ALWAYS : mode;
		for (const selectedNode of selectedNodeArray) selectedNode.mode = newModeForSelectedNode;
	};
	return {
		isIgnoredItem,
		filterSelectableItems,
		getSelectableItems,
		hasSelectableItems,
		hasMultipleSelectableItems,
		getSelectedNodes,
		areAllSelectedNodesInMode,
		toggleSelectedNodesMode
	};
}
//#endregion
//#region src/platform/workflow/templates/types/template.ts
var TemplateIncludeOnDistributionEnum = /* @__PURE__ */ function(TemplateIncludeOnDistributionEnum) {
	TemplateIncludeOnDistributionEnum["Cloud"] = "cloud";
	TemplateIncludeOnDistributionEnum["Local"] = "local";
	TemplateIncludeOnDistributionEnum["Desktop"] = "desktop";
	TemplateIncludeOnDistributionEnum["Mac"] = "mac";
	TemplateIncludeOnDistributionEnum["Windows"] = "windows";
	return TemplateIncludeOnDistributionEnum;
}({});
//#endregion
//#region src/stores/subgraphStore.ts
async function confirmOverwrite(name) {
	return await useDialogService().confirm({
		title: t("subgraphStore.overwriteBlueprintTitle"),
		type: "overwriteBlueprint",
		message: t("subgraphStore.overwriteBlueprint"),
		itemList: [name]
	});
}
var useSubgraphStore = defineStore("subgraph", () => {
	class SubgraphBlueprint extends ComfyWorkflow {
		static basePath = "subgraphs/";
		tintCanvasBg = "#22227740";
		hasPromptedSave = false;
		constructor(options, confirmFirstSave = false) {
			super(options);
			this.hasPromptedSave = !confirmFirstSave;
		}
		validateSubgraph() {
			if (!this.activeState?.definitions) throw new Error("The root graph of a subgraph blueprint must consist of only a single subgraph node");
			const { subgraphs } = this.activeState.definitions;
			const { nodes } = this.activeState;
			function isSubgraphNode(node) {
				return subgraphs.some((s) => s.id === node.type);
			}
			if (nodes.length == 1 && isSubgraphNode(nodes[0])) return;
			const errors = {};
			let firstSubgraphFound = false;
			for (let i = 0; i < nodes.length; i++) {
				if (!firstSubgraphFound && isSubgraphNode(nodes[i])) {
					firstSubgraphFound = true;
					continue;
				}
				errors[nodes[i].id] = {
					errors: [],
					class_type: nodes[i].type,
					dependent_outputs: []
				};
			}
			useExecutionErrorStore().recordNodeErrors(errors);
			useCanvasStore().getCanvas().draw(true, true);
			throw new Error("The root graph of a subgraph blueprint must consist of only a single subgraph node");
		}
		async save() {
			this.validateSubgraph();
			if (!this.hasPromptedSave && useSettingStore().get("Comfy.Workflow.WarnBlueprintOverwrite")) {
				if (!await confirmOverwrite(this.filename)) return this;
				this.hasPromptedSave = true;
			}
			this.extractMetadataToWorkflowExtra();
			const ret = await super.save();
			registerNodeDef(await this.load({ force: true }), { category: "Subgraph Blueprints/User" });
			return ret;
		}
		/**
		* Moves all properties (except workflowRendererVersion) from subgraph.extra
		* to workflow.extra, then removes from subgraph.extra to avoid duplication.
		*/
		extractMetadataToWorkflowExtra() {
			if (!this.activeState) return;
			const subgraph = this.activeState.definitions?.subgraphs[0];
			if (!subgraph?.extra) return;
			const sgExtra = subgraph.extra;
			const workflowExtra = this.activeState.extra ??= {};
			for (const key of Object.keys(sgExtra)) {
				if (key === "workflowRendererVersion") continue;
				workflowExtra[key] = sgExtra[key];
				delete sgExtra[key];
			}
		}
		async saveAs(path) {
			this.validateSubgraph();
			this.hasPromptedSave = true;
			this.extractMetadataToWorkflowExtra();
			const ret = await super.saveAs(path);
			registerNodeDef(await this.load({ force: true }), { category: "Subgraph Blueprints/User" });
			return ret;
		}
		async load({ force = false } = {}) {
			if (!force && this.isLoaded) return await super.load({ force });
			const loaded = await super.load({ force });
			const st = loaded.activeState;
			const sg = (st.definitions?.subgraphs ?? []).find((sg) => sg.id == st.nodes[0].type);
			if (!sg) throw new Error("Loaded subgraph blueprint does not contain valid subgraph");
			sg.name = st.nodes[0].title = this.filename;
			if (st.extra) {
				const sgExtra = sg.extra ??= {};
				for (const [key, value] of Object.entries(st.extra)) {
					if (key === "workflowRendererVersion") continue;
					sgExtra[key] = value;
				}
			}
			return loaded;
		}
		saveNamePrompt = {
			title: "subgraphStore.saveBlueprint",
			message: "subgraphStore.blueprintNamePrompt"
		};
		unload() {}
	}
	const subgraphCache = {};
	const nodeDefStore = useNodeDefStore();
	const canvasStore = useCanvasStore();
	async function fetchSubgraphs() {
		async function loadBlueprint(options) {
			options.path = SubgraphBlueprint.basePath + options.path;
			const bp = await new SubgraphBlueprint(options, true).load();
			useWorkflowStore().attachWorkflow(bp);
			registerNodeDef(bp, { category: "Subgraph Blueprints/User" });
		}
		async function loadInstalledBlueprints() {
			async function loadGlobalBlueprint([k, v]) {
				const data = await v.data;
				if (typeof data !== "string" || data.trim().length === 0) throw new Error(`Global blueprint '${v.name}' (${k}) returned empty content`);
				const path = SubgraphBlueprint.basePath + v.name + ".json";
				const blueprint = new SubgraphBlueprint({
					path,
					modified: Date.now(),
					size: -1
				});
				blueprint.originalContent = blueprint.content = data;
				blueprint.filename = v.name;
				useWorkflowStore().attachWorkflow(blueprint);
				const loaded = await blueprint.load();
				const category = v.info.category ? `Subgraph Blueprints/${v.info.category}` : void 0;
				registerNodeDef(loaded, {
					display_name: v.name,
					...category && { category },
					...v.essentials_category && { essentials_category: v.essentials_category },
					search_aliases: v.info.search_aliases,
					isGlobal: true
				}, k);
			}
			const subgraphs = await api.getGlobalSubgraphs();
			const currentDistribution = TemplateIncludeOnDistributionEnum.Local;
			const filteredEntries = Object.entries(subgraphs).filter(([, v]) => {
				if ((v.info.requiresCustomNodes?.length ?? 0) > 0) return false;
				if ((v.info.includeOnDistributions?.length ?? 0) > 0 && !v.info.includeOnDistributions.includes(currentDistribution)) return false;
				return true;
			});
			return Promise.allSettled(filteredEntries.map(loadGlobalBlueprint));
		}
		const userSubs = (await api.listUserDataFullInfo(SubgraphBlueprint.basePath)).filter((f) => f.path.endsWith(".json"));
		const [globalResult, ...userResults] = await Promise.allSettled([loadInstalledBlueprints(), ...userSubs.map(loadBlueprint)]);
		const errors = [...globalResult.status === "fulfilled" ? globalResult.value : [], ...userResults].filter((i) => "reason" in i).map((i) => i.reason);
		errors.forEach((e) => console.error("Failed to load subgraph blueprint", e));
		if (errors.length > 0) useToast().error(t("subgraphStore.loadFailure"), { description: errors.length > 3 ? `x${errors.length}` : errors.map((e) => getErrorMessage(e) ?? t("g.unknownError")).join(", ") });
	}
	function registerNodeDef(workflow, overrides = {}, name = workflow.filename) {
		const subgraphNode = workflow.changeTracker.initialState.nodes[0];
		subgraphNode.inputs ??= [];
		subgraphNode.outputs ??= [];
		const inputs = Object.fromEntries(subgraphNode.inputs.map((i) => [i.name, [`${i.type}`, void 0]]));
		const workflowExtra = workflow.initialState.extra;
		const description = workflowExtra?.BlueprintDescription ?? workflow.initialState.definitions?.subgraphs[0].description ?? "User generated subgraph blueprint";
		const search_aliases = workflowExtra?.BlueprintSearchAliases;
		const subgraphDefCategory = workflow.initialState.definitions?.subgraphs[0]?.category;
		const subgraphDefEssentialsCategory = workflow.initialState.definitions?.subgraphs[0]?.essentials_category;
		const category = subgraphDefCategory ? `Subgraph Blueprints/${subgraphDefCategory}` : "Subgraph Blueprints";
		const nodedefv1 = {
			input: { required: inputs },
			output: subgraphNode.outputs.map((o) => `${o.type}`),
			output_name: subgraphNode.outputs.map((o) => o.name),
			name: BLUEPRINT_TYPE_PREFIX + name,
			display_name: name,
			description,
			category,
			output_node: false,
			python_module: "blueprint",
			search_aliases,
			essentials_category: subgraphDefEssentialsCategory,
			...overrides
		};
		nodeDefStore.registerBlueprintNodeDef(new ComfyNodeDefImpl(nodedefv1));
		subgraphCache[name] = workflow;
	}
	async function publishSubgraph(providedName) {
		const canvas = canvasStore.getCanvas();
		const subgraphNode = [...canvas.selectedItems][0];
		if (canvas.selectedItems.size !== 1 || !(subgraphNode instanceof SubgraphNode)) throw new TypeError("Must have single SubgraphNode selected to publish");
		const { nodes = [], subgraphs = [] } = canvas._serializeItems([subgraphNode]);
		if (nodes.length != 1) throw new TypeError("Must have single SubgraphNode selected to publish");
		const workflowData = {
			revision: 0,
			last_node_id: subgraphNode.id,
			last_link_id: 0,
			nodes,
			links: [],
			version: .4,
			definitions: { subgraphs }
		};
		const name = providedName ?? await useDialogService().prompt({
			title: t("subgraphStore.saveBlueprint"),
			message: t("subgraphStore.blueprintNamePrompt"),
			defaultValue: subgraphNode.title
		});
		if (!name) return;
		if (nodeDefStore.blueprintNodeDefsByName.has("SubgraphBlueprint." + name) && !await confirmOverwrite(name)) return;
		const path = SubgraphBlueprint.basePath + name + ".json";
		const workflow = new SubgraphBlueprint({
			path,
			size: -1,
			modified: Date.now()
		});
		workflow.originalContent = JSON.stringify(workflowData);
		const loadedWorkflow = await workflow.load();
		workflow.size = 1;
		await workflow.save();
		useWorkflowStore().attachWorkflow(loadedWorkflow);
		useToast().success(t("subgraphStore.publishSuccess"), {
			description: t("subgraphStore.publishSuccessMessage"),
			duration: 4e3
		});
	}
	async function editBlueprint(nodeType) {
		const name = nodeType.slice(BLUEPRINT_TYPE_PREFIX.length);
		if (!(name in subgraphCache)) throw new Error("not yet loaded");
		useWorkflowStore().attachWorkflow(subgraphCache[name]);
		await useWorkflowService().openWorkflow(subgraphCache[name]);
		const canvas = useCanvasStore().getCanvas();
		if (canvas.graph && "subgraph" in canvas.graph.nodes[0]) canvas.setGraph(canvas.graph.nodes[0].subgraph);
	}
	function getBlueprint(nodeType) {
		const name = nodeType.slice(BLUEPRINT_TYPE_PREFIX.length);
		if (!(name in subgraphCache)) throw new Error("not yet loaded");
		return structuredClone(subgraphCache[name].changeTracker.initialState);
	}
	async function deleteBlueprint(nodeType) {
		const name = nodeType.slice(BLUEPRINT_TYPE_PREFIX.length);
		if (!(name in subgraphCache)) throw new Error("not yet loaded");
		if (isGlobalBlueprint(name)) {
			useToast().warning(t("subgraphStore.cannotDeleteGlobal"), { duration: 4e3 });
			return;
		}
		if (!await useDialogService().confirm({
			title: t("subgraphStore.confirmDeleteTitle"),
			type: "delete",
			message: t("subgraphStore.confirmDelete"),
			itemList: [name]
		})) return;
		await subgraphCache[name].delete();
		delete subgraphCache[name];
		nodeDefStore.removeBlueprintNodeDef(nodeType);
	}
	function isSubgraphBlueprint(workflow) {
		return workflow instanceof SubgraphBlueprint;
	}
	function isGlobalBlueprint(name) {
		const nodeDef = nodeDefStore.blueprintNodeDefsByName.get(BLUEPRINT_TYPE_PREFIX + name);
		return nodeDef !== void 0 && nodeDef.isGlobal === true;
	}
	function isUserBlueprint(nodeType) {
		if (!nodeType?.startsWith("SubgraphBlueprint.")) return false;
		const name = nodeType.slice(BLUEPRINT_TYPE_PREFIX.length);
		return name in subgraphCache && !isGlobalBlueprint(name);
	}
	return {
		deleteBlueprint,
		editBlueprint,
		fetchSubgraphs,
		getBlueprint,
		isGlobalBlueprint,
		isSubgraphBlueprint,
		isUserBlueprint,
		publishSubgraph
	};
});
//#endregion
//#region src/composables/graph/useSubgraphOperations.ts
/**
* Composable for handling subgraph-related operations
*/
function useSubgraphOperations() {
	const { getSelectedNodes } = useSelectedLiteGraphItems();
	const canvasStore = useCanvasStore();
	const workflowStore = useWorkflowStore();
	const nodeOutputStore = useNodeOutputStore();
	const subgraphStore = useSubgraphStore();
	const toast = useToast();
	const convertToSubgraph = () => {
		const canvas = canvasStore.getCanvas();
		const graph = canvas.subgraph ?? canvas.graph;
		if (!graph) return null;
		const { node } = graph.convertToSubgraph(canvas.selectedItems);
		canvas.select(node);
		workflowStore.activeWorkflow?.changeTracker.captureCanvasState();
	};
	const doUnpack = (subgraphNodes, skipMissingNodes) => {
		const canvas = canvasStore.getCanvas();
		const graph = canvas.subgraph ?? canvas.graph;
		if (!graph) return;
		let changed = false;
		let refused = false;
		for (const subgraphNode of subgraphNodes) {
			if (!graph.unpackSubgraph(subgraphNode, { skipMissingNodes })) {
				refused = true;
				continue;
			}
			nodeOutputStore.revokeSubgraphPreviews(subgraphNode, graph);
			changed = true;
		}
		if (refused) toast.error(t("g.error"), { description: t("g.subgraphUnpackFailed") });
		if (changed) workflowStore.activeWorkflow?.changeTracker.captureCanvasState();
	};
	const unpackSubgraph = () => {
		const canvas = canvasStore.getCanvas();
		if (!(canvas.subgraph ?? canvas.graph)) return;
		const subgraphNodes = Array.from(canvas.selectedItems).filter((item) => item instanceof SubgraphNode);
		if (subgraphNodes.length === 0) return;
		doUnpack(subgraphNodes, true);
	};
	const addSubgraphToLibrary = async () => {
		if (Array.from(canvasStore.selectedItems).filter((item) => item instanceof SubgraphNode).length !== 1) return;
		await subgraphStore.publishSubgraph();
	};
	const isSubgraphSelected = () => {
		return Array.from(canvasStore.selectedItems).some((item) => item instanceof SubgraphNode);
	};
	const hasSelectableNodes = () => {
		return getSelectedNodes().length > 0;
	};
	return {
		convertToSubgraph,
		unpackSubgraph,
		addSubgraphToLibrary,
		isSubgraphSelected,
		hasSelectableNodes
	};
}
//#endregion
//#region src/composables/node/useNodeAnimatedImage.ts
var ANIM_PREVIEW_WIDGET = "$$comfy_animation_preview";
/**
* Composable for handling animated image previews in nodes
*/
function useNodeAnimatedImage() {
	/**
	* Shows animated image preview for a node
	* @param node The graph node to show the preview for
	*/
	function showAnimatedPreview(node) {
		if (!node.imgs?.length) return;
		if (!node.widgets) return;
		const widgetIdx = node.widgets.findIndex((w) => w.name === ANIM_PREVIEW_WIDGET);
		node.imgs[0].classList.value = "block size-full object-contain";
		if (widgetIdx > -1) {
			const widget = node.widgets[widgetIdx];
			if (!isDOMWidget(widget)) return;
			widget.element.replaceChildren(node.imgs[0]);
		} else {
			const element = document.createElement("div");
			element.appendChild(node.imgs[0]);
			const widget = node.addDOMWidget(ANIM_PREVIEW_WIDGET, "img", element, {
				hideOnZoom: false,
				surfaces: {
					canvas: "shown",
					vueNode: "never",
					panel: "never"
				}
			});
			node.overIndex = 0;
			const { handleWheel, handlePointerDown, handlePointerMove, handlePointerUp, forwardEventToCanvas } = useCanvasInteractions();
			node.imgs[0].style.pointerEvents = "none";
			const controller = new AbortController();
			const { signal } = controller;
			element.addEventListener("wheel", handleWheel, { signal });
			element.addEventListener("pointermove", handlePointerMove, { signal });
			element.addEventListener("pointerup", handlePointerUp, { signal });
			element.addEventListener("pointerdown", (e) => e.button !== 2 ? handlePointerDown(e) : forwardEventToCanvas(e), {
				capture: true,
				signal
			});
			widget.onRemove = useChainCallback(widget.onRemove, () => {
				controller.abort();
			});
			widget.serialize = false;
			widget.serializeValue = () => void 0;
		}
	}
	/**
	* Removes animated image preview from a node
	* @param node The graph node to remove the preview from
	*/
	function removeAnimatedPreview(node) {
		if (!node.widgets) return;
		const widgetIdx = node.widgets.findIndex((w) => w.name === ANIM_PREVIEW_WIDGET);
		if (widgetIdx > -1) {
			node.widgets[widgetIdx].onRemove?.();
			node.widgets.splice(widgetIdx, 1);
		}
	}
	return {
		showAnimatedPreview,
		removeAnimatedPreview
	};
}
//#endregion
//#region src/scripts/ui/imagePreview.ts
function calculateImageGrid(imgs, dw, dh) {
	let best = 0;
	const w = imgs[0].naturalWidth;
	const h = imgs[0].naturalHeight;
	const numImages = imgs.length;
	let cellWidth = 0;
	let cellHeight = 0;
	let cols = 0;
	let rows = 0;
	let shiftX = 0;
	for (let c = 1; c <= numImages; c++) {
		const r = Math.ceil(numImages / c);
		const cW = dw / c;
		const cH = dh / r;
		const scaleX = cW / w;
		const scaleY = cH / h;
		const scale = Math.min(scaleX, scaleY, 1);
		const imageW = w * scale;
		const imageH = h * scale;
		const area = imageW * imageH * numImages;
		if (area > best) {
			best = area;
			cellWidth = imageW;
			cellHeight = imageH;
			cols = c;
			rows = r;
			shiftX = c * ((cW - imageW) / 2);
		}
	}
	return {
		cellWidth,
		cellHeight,
		cols,
		rows,
		shiftX
	};
}
/** @knipIgnoreUnusedButUsedByCustomNodes */
function createImageHost(node) {
	const el = $el("div.comfy-img-preview");
	let currentImgs;
	let first = true;
	function updateSize() {
		if (currentImgs) {
			let elH = el.clientHeight;
			if (first) {
				first = false;
				if (elH < 190) elH = 190;
				el.style.setProperty("--comfy-widget-min-height", elH.toString());
			} else el.style.setProperty("--comfy-widget-min-height", null);
			const nw = node.size[0];
			const { cellWidth, cellHeight } = calculateImageGrid(currentImgs, nw - 20, elH);
			el.style.setProperty("--comfy-img-preview-width", `${cellWidth}px`);
			el.style.setProperty("--comfy-img-preview-height", `${cellHeight}px`);
		}
	}
	return {
		el,
		getCurrentImage() {
			return currentImgs?.[0];
		},
		updateImages(imgs) {
			if (imgs !== currentImgs) {
				if (currentImgs == null) requestAnimationFrame(() => {
					updateSize();
				});
				el.replaceChildren(...imgs);
				currentImgs = imgs;
				node.onResize?.(node.size);
				node.graph?.setDirtyCanvas(true, true);
			}
		},
		getHeight() {
			updateSize();
		},
		onDraw() {
			el.style.pointerEvents = "all";
			const over = document.elementFromPoint(useApp().canvas.mouse[0], useApp().canvas.mouse[1]);
			el.style.pointerEvents = "none";
			if (!over) return;
			node.overIndex = over instanceof HTMLImageElement ? currentImgs?.indexOf(over) ?? -1 : -1;
		}
	};
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.imagePreview = window.comfyAPI.imagePreview || {};
window.comfyAPI.imagePreview.calculateImageGrid = calculateImageGrid;
window.comfyAPI.imagePreview.createImageHost = createImageHost;
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/composables/useImagePreviewWidget.ts
/**
* Workaround for Chrome GPU bug:
* When Chrome is maximized with GPU acceleration and high DPR, calling
* drawImage(canvas) + drawImage(img) in the same frame causes severe
* performance degradation (FPS drops to 2-10, memory spikes ~18GB).
*
* Solution: Defer image rendering using queueMicrotask to separate
* the two drawImage calls into different tasks.
*
* Note: As tested, requestAnimationFrame delays rendering to the next frame,
* causing visible image flickering. queueMicrotask executes within the same
* frame, avoiding flicker while still separating the drawImage calls.
*/
var deferredImageRenders = [];
var deferredRenderScheduled = false;
function scheduleDeferredImageRender() {
	if (deferredRenderScheduled) return;
	deferredRenderScheduled = true;
	queueMicrotask(() => {
		const renders = deferredImageRenders;
		deferredImageRenders = [];
		deferredRenderScheduled = false;
		for (const render of renders) render();
	});
}
var TWO_PI = Math.PI * 2;
var SPINNER_ARC_LENGTH = Math.PI * 1.5;
function renderUploadSpinner(ctx, node, shiftY, computedHeight) {
	const dw = node.size[0];
	const dh = computedHeight ?? 220;
	const centerX = dw / 2;
	const centerY = shiftY + dh / 2;
	const radius = 16;
	const angle = Date.now() % 1e3 / 1e3 * TWO_PI;
	ctx.save();
	ctx.strokeStyle = LiteGraph.NODE_TEXT_COLOR;
	ctx.lineWidth = 3;
	ctx.lineCap = "round";
	ctx.beginPath();
	ctx.arc(centerX, centerY, radius, angle, angle + SPINNER_ARC_LENGTH);
	ctx.stroke();
	ctx.restore();
	node.graph?.setDirtyCanvas(true);
}
var renderPreview = (ctx, node, shiftY, computedHeight, imgs, width) => {
	if (node.isUploading) {
		renderUploadSpinner(ctx, node, shiftY, computedHeight);
		return;
	}
	const canvas = useCanvasStore().getCanvas();
	const mouse = canvas.graph_mouse;
	if (!canvas.pointer_is_down && node.pointerDown) {
		if (mouse[0] === node.pointerDown.pos[0] && mouse[1] === node.pointerDown.pos[1]) node.imageIndex = node.pointerDown.index;
		node.pointerDown = null;
	}
	if (imgs.length === 0) return;
	let { imageIndex } = node;
	const numImages = imgs.length;
	if (numImages === 1 && !imageIndex) node.imageIndex = imageIndex = 0;
	const allowImageSizeDraw = useSettingStore().get("Comfy.Node.AllowImageSizeDraw");
	const IMAGE_TEXT_SIZE_TEXT_HEIGHT = allowImageSizeDraw ? 15 : 0;
	const dw = width;
	const dh = computedHeight ? computedHeight - IMAGE_TEXT_SIZE_TEXT_HEIGHT : 0;
	if (imageIndex == null) {
		let cellWidth;
		let cellHeight;
		let shiftX;
		let cell_padding;
		let cols;
		const compact_mode = is_all_same_aspect_ratio(imgs);
		if (!compact_mode) {
			cell_padding = 2;
			const largestDimension = imgs.reduce((acc, current) => Math.max(acc, current.naturalWidth, current.naturalHeight), 0);
			const fakeImgs = [];
			fakeImgs.length = imgs.length;
			fakeImgs[0] = {
				naturalWidth: largestDimension,
				naturalHeight: largestDimension
			};
			({cellWidth, cellHeight, cols, shiftX} = calculateImageGrid(fakeImgs, dw, dh));
		} else {
			cell_padding = 0;
			({cellWidth, cellHeight, cols, shiftX} = calculateImageGrid(imgs, dw, dh));
		}
		let anyHovered = false;
		node.imageRects = [];
		for (let i = 0; i < numImages; i++) {
			const img = imgs[i];
			const row = Math.floor(i / cols);
			const col = i % cols;
			const x = col * cellWidth + shiftX;
			const y = row * cellHeight + shiftY;
			if (!anyHovered) {
				anyHovered = LiteGraph.isInsideRectangle(mouse[0], mouse[1], x + node.pos[0], y + node.pos[1], cellWidth, cellHeight);
				if (anyHovered) {
					node.overIndex = i;
					let value = 110;
					if (canvas.pointer_is_down) {
						if (!node.pointerDown || node.pointerDown.index !== i) node.pointerDown = {
							index: i,
							pos: [...mouse]
						};
						value = 125;
					}
					ctx.filter = `contrast(${value}%) brightness(${value}%)`;
					canvas.canvas.style.cursor = "pointer";
				}
			}
			node.imageRects.push([
				x,
				y,
				cellWidth,
				cellHeight
			]);
			const wratio = cellWidth / img.width;
			const hratio = cellHeight / img.height;
			const ratio = Math.min(wratio, hratio);
			const imgHeight = ratio * img.height;
			const imgY = row * cellHeight + shiftY + (cellHeight - imgHeight) / 2;
			const imgWidth = ratio * img.width;
			const imgX = col * cellWidth + shiftX + (cellWidth - imgWidth) / 2;
			const transform = ctx.getTransform();
			const filter = ctx.filter;
			const drawParams = {
				img,
				x: imgX + cell_padding,
				y: imgY + cell_padding,
				w: imgWidth - cell_padding * 2,
				h: imgHeight - cell_padding * 2
			};
			deferredImageRenders.push(() => {
				if (!drawParams.img.naturalWidth || !drawParams.img.naturalHeight) return;
				ctx.save();
				ctx.setTransform(transform);
				ctx.filter = filter;
				ctx.drawImage(drawParams.img, drawParams.x, drawParams.y, drawParams.w, drawParams.h);
				ctx.restore();
			});
			scheduleDeferredImageRender();
			if (!compact_mode) {
				ctx.strokeStyle = "#8F8F8F";
				ctx.lineWidth = 1;
				ctx.strokeRect(x + cell_padding, y + cell_padding, cellWidth - cell_padding * 2, cellHeight - cell_padding * 2);
			}
			ctx.filter = "none";
		}
		if (!anyHovered) {
			node.pointerDown = null;
			node.overIndex = null;
		}
		return;
	}
	const img = imgs.at(imageIndex);
	if (!img) return;
	let w = img.naturalWidth;
	let h = img.naturalHeight;
	const scaleX = dw / w;
	const scaleY = dh / h;
	const scale = Math.min(scaleX, scaleY, 1);
	w *= scale;
	h *= scale;
	const x = (dw - w) / 2;
	const y = (dh - h) / 2 + shiftY;
	const transform = ctx.getTransform();
	deferredImageRenders.push(() => {
		if (!img.naturalWidth || !img.naturalHeight) return;
		ctx.save();
		ctx.setTransform(transform);
		ctx.drawImage(img, x, y, w, h);
		ctx.restore();
	});
	scheduleDeferredImageRender();
	if (allowImageSizeDraw) {
		ctx.fillStyle = LiteGraph.NODE_TEXT_COLOR;
		ctx.textAlign = "center";
		ctx.font = "10px sans-serif";
		const sizeText = `${Math.round(img.naturalWidth)} × ${Math.round(img.naturalHeight)}`;
		const textY = y + h + 10;
		ctx.fillText(sizeText, x + w / 2, textY);
	}
	const drawButton = (x, y, sz, text) => {
		const hovered = LiteGraph.isInsideRectangle(mouse[0], mouse[1], x + node.pos[0], y + node.pos[1], sz, sz);
		let fill = "#333";
		let textFill = "#fff";
		let isClicking = false;
		if (hovered) {
			canvas.canvas.style.cursor = "pointer";
			if (canvas.pointer_is_down) {
				fill = "#1e90ff";
				isClicking = true;
			} else {
				fill = "#eee";
				textFill = "#000";
			}
		}
		deferredImageRenders.push(() => {
			ctx.save();
			ctx.setTransform(transform);
			ctx.fillStyle = fill;
			ctx.beginPath();
			ctx.roundRect(x, y, sz, sz, [4]);
			ctx.fill();
			ctx.fillStyle = textFill;
			ctx.font = "12px Inter, sans-serif";
			ctx.textAlign = "center";
			ctx.fillText(text, x + 15, y + 20);
			ctx.restore();
		});
		return isClicking;
	};
	if (!(numImages > 1)) return;
	const imageNum = (node.imageIndex ?? 0) + 1;
	if (drawButton(dw - 40, dh + shiftY - 40, 30, `${imageNum}/${numImages}`)) {
		const i = imageNum >= numImages ? 0 : imageNum;
		if (!node.pointerDown || node.pointerDown.index !== i) node.pointerDown = {
			index: i,
			pos: [...mouse]
		};
	}
	if (drawButton(dw - 40, shiftY + 10, 30, `x`)) {
		if (!node.pointerDown || node.pointerDown.index !== null) node.pointerDown = {
			index: null,
			pos: [...mouse]
		};
	}
};
var ImagePreviewWidget = class ImagePreviewWidget extends BaseWidget {
	constructor(node, name, options) {
		super({
			name,
			options,
			type: "custom",
			/** Dummy value to satisfy type requirements. */
			value: "",
			y: 0
		}, node);
		this.serialize = false;
	}
	drawWidget(ctx, options) {
		const imgs = options.previewImages ?? this.node.imgs ?? [];
		renderPreview(ctx, this.node, this.y, this.computedHeight, imgs, options.width);
	}
	createCopyForNode(node) {
		const copy = new ImagePreviewWidget(node, this.name, this.options);
		copy.value = this.value;
		return copy;
	}
	onPointerDown(pointer, node) {
		pointer.onDragStart = () => {
			const { canvas } = useApp();
			const { graph } = canvas;
			canvas.emitBeforeChange();
			graph?.beforeChange();
			pointer.finally = () => {
				canvas.isDragging = false;
				graph?.afterChange();
				canvas.emitAfterChange();
			};
			canvas.processSelect(node, pointer.eDown);
			canvas.isDragging = true;
		};
		pointer.onDragEnd = (e) => {
			const { canvas } = useApp();
			if (e.shiftKey || LiteGraph.alwaysSnapToGrid) canvas.graph?.snapToGrid(canvas.selectedItems);
			canvas.setDirty(true, true);
		};
		return true;
	}
	onClick() {}
	computeLayoutSize() {
		return {
			minHeight: 220,
			minWidth: 1
		};
	}
};
var useImagePreviewWidget = () => {
	const widgetConstructor = (node, inputSpec) => {
		return node.addCustomWidget(new ImagePreviewWidget(node, inputSpec.name, {
			serialize: false,
			surfaces: {
				canvas: "shown",
				vueNode: "never",
				panel: "never"
			}
		}));
	};
	return widgetConstructor;
};
//#endregion
//#region src/composables/node/canvasImagePreviewTypes.ts
var CANVAS_IMAGE_PREVIEW_WIDGET = "$$canvas-image-preview";
var CANVAS_IMAGE_PREVIEW_NODE_TYPES = /* @__PURE__ */ new Set([
	"KSampler",
	"KSamplerAdvanced",
	"PreviewImage",
	"SaveImage",
	"GLSLShader"
]);
function supportsVirtualCanvasImagePreview(node) {
	return CANVAS_IMAGE_PREVIEW_NODE_TYPES.has(node.type);
}
//#endregion
//#region src/composables/node/useNodeCanvasImagePreview.ts
/**
* Composable for handling canvas image previews in nodes
*/
function useNodeCanvasImagePreview() {
	const imagePreviewWidget = useImagePreviewWidget();
	/**
	* Shows canvas image preview for a node
	* @param node The graph node to show the preview for
	*/
	function showCanvasImagePreview(node) {
		if (!node.imgs?.length) return;
		if (node.isSubgraphNode()) return;
		if (!node.widgets?.find((w) => w.name === "$$canvas-image-preview")) imagePreviewWidget(node, {
			type: "IMAGE_PREVIEW",
			name: CANVAS_IMAGE_PREVIEW_WIDGET
		});
	}
	/**
	* Removes canvas image preview from a node
	* @param node The graph node to remove the preview from
	*/
	function removeCanvasImagePreview(node) {
		if (!node.widgets) return;
		const widgetIdx = node.widgets.findIndex((w) => w.name === CANVAS_IMAGE_PREVIEW_WIDGET);
		if (widgetIdx > -1) {
			node.widgets[widgetIdx].onRemove?.();
			node.widgets.splice(widgetIdx, 1);
		}
	}
	return {
		showCanvasImagePreview,
		removeCanvasImagePreview
	};
}
//#endregion
//#region src/core/graph/subgraph/promotionUtils.ts
function isLinkedPromotion(subgraphNode, sourceNodeId, sourceWidgetName) {
	return findHostInputForPromotion(subgraphNode, sourceNodeId, sourceWidgetName) !== void 0;
}
function findHostInputForPromotion(subgraphNode, rawSourceNodeId, sourceWidgetName) {
	const sourceNodeId = toNodeId(rawSourceNodeId);
	return subgraphNode.inputs.find((input) => {
		const source = input._subgraphSlot ? resolvePromotionSource(subgraphNode, input._subgraphSlot) : void 0;
		return source?.sourceNodeId === sourceNodeId && source.sourceWidgetName === sourceWidgetName;
	});
}
/**
* Host-first resolver for promoted widget value keys.
*
* Anchors on the host `SubgraphNode.inputs` (which own the promoted `widgetId`
* per ADR-SUBGRAPH-PROMOTION-0009) and walks host -> interior only to key each host widget by the
* interior source it projects. Consumers that discover an interior source can
* then look up the host value key without a per-source reverse walk.
*/
function createPromotedHostWidgetIdLookup(subgraphNode) {
	const key = (nodeId, name) => `${toNodeId(nodeId)}\u0000${name}`;
	const hostWidgetIdBySource = /* @__PURE__ */ new Map();
	for (const input of subgraphNode.inputs) {
		const hostWidgetId = input.widgetId;
		const subgraphSlot = input._subgraphSlot;
		if (!hostWidgetId || !subgraphSlot) continue;
		const source = resolvePromotionSource(subgraphNode, subgraphSlot);
		if (!source) continue;
		hostWidgetIdBySource.set(key(source.sourceNodeId, source.sourceWidgetName), hostWidgetId);
	}
	return (sourceNodeId, sourceWidgetName) => hostWidgetIdBySource.get(key(sourceNodeId, sourceWidgetName));
}
function resolvePromotionSource(subgraphNode, subgraphInput) {
	for (const linkId of subgraphInput.linkIds) {
		const link = subgraphNode.subgraph.getLink(linkId);
		if (!link) continue;
		const { inputNode, input: targetInput } = link.resolve(subgraphNode.subgraph);
		if (!inputNode || !targetInput) continue;
		if (inputNode.isSubgraphNode()) return {
			sourceNodeId: inputNode.id,
			sourceWidgetName: targetInput.name
		};
		const targetWidget = inputNode.getWidgetFromSlot(targetInput);
		if (!targetWidget) continue;
		return {
			sourceNodeId: inputNode.id,
			sourceWidgetName: targetWidget.name
		};
	}
}
function reorderSubgraphInputsByWidgetOrder(subgraphNode, orderedWidgets) {
	const remainingIndices = new Set(subgraphNode.inputs.keys());
	const orderedIndices = orderedWidgets.flatMap((orderedWidget) => {
		for (const index of remainingIndices) if (isSamePromotedInput(subgraphNode, index, orderedWidget)) {
			remainingIndices.delete(index);
			return [index];
		}
		return [];
	});
	for (const index of remainingIndices) orderedIndices.push(index);
	applySubgraphInputOrder(subgraphNode, orderedIndices);
}
function applySubgraphInputOrder(subgraphNode, orderedIndices) {
	const widgetValues = subgraphNode.inputs.map((input) => {
		const id = input.widgetId;
		if (!id) return void 0;
		return useWidgetValueStore().getWidget(id)?.value;
	});
	reorderSubgraphInputs(subgraphNode, orderedIndices);
	useWidgetValueStore().setNodeWidgetOrder(subgraphNode.rootGraph.id, subgraphNode.id, subgraphNode.inputs.flatMap((input) => input.widgetId ? [input.widgetId] : []));
	for (const [newIndex, oldIndex] of orderedIndices.entries()) {
		const value = widgetValues[oldIndex];
		const id = subgraphNode.inputs[newIndex]?.widgetId;
		if (value === void 0 || !id) continue;
		useWidgetValueStore().setValue(id, value);
	}
}
function isSamePromotedInput(subgraphNode, inputIndex, orderedWidget) {
	const input = subgraphNode.inputs.at(inputIndex);
	const linkedInput = input?._subgraphSlot;
	if (!input || !linkedInput) return false;
	for (const linkId of linkedInput.linkIds) {
		const link = subgraphNode.subgraph.getLink(linkId);
		if (!link) continue;
		const { inputNode, input: targetInput } = link.resolve(subgraphNode.subgraph);
		if (!inputNode || !targetInput) continue;
		if (inputNode.getWidgetFromSlot(targetInput) === orderedWidget) return true;
		if (input.widgetId && input.widgetId === orderedWidget.widgetId) return true;
	}
	return false;
}
function isPreviewExposed(subgraphNode, source) {
	const hostLocator = getPreviewExposureHostLocator(subgraphNode);
	if (!hostLocator) return false;
	return usePreviewExposureStore().getExposures(subgraphNode.rootGraph.id, hostLocator).some((exposure) => exposure.sourceNodeId === source.sourceNodeId && exposure.sourcePreviewName === source.sourceWidgetName);
}
function isWidgetPromotedOnSubgraphNode(subgraphNode, source, widget) {
	if (widget && isPreviewPseudoWidget(widget)) return isPreviewExposed(subgraphNode, source);
	return isLinkedPromotion(subgraphNode, source.sourceNodeId, source.sourceWidgetName) || isPreviewExposed(subgraphNode, source);
}
function toPromotionSource(node, widget) {
	return {
		sourceNodeId: node.id,
		sourceWidgetName: widget.name
	};
}
function refreshPromotedWidgetRendering(parents) {
	for (const parent of parents) {
		parent.expandToFitContent();
		parent.setDirtyCanvas(true, true);
	}
	useCanvasStore().canvas?.setDirty(true, true);
}
function promoteValueWidgetViaSubgraphInput(subgraphNode, sourceNode, sourceWidget) {
	const sourceWidgetName = sourceWidget.name;
	if (isLinkedPromotion(subgraphNode, sourceNode.id, sourceWidgetName)) return { ok: true };
	const sourceSlot = sourceNode.getSlotFromWidget(sourceWidget);
	if (!sourceSlot) return {
		ok: false,
		reason: "missingSourceSlot"
	};
	const existingNames = subgraphNode.subgraph.inputs.map((input) => input.name);
	const inputName = nextUniqueName(sourceWidgetName, existingNames);
	const subgraphInput = subgraphNode.subgraph.addInput(inputName, String(sourceSlot.type ?? "*"));
	subgraphInput.label = sourceSlot.label;
	if (!subgraphInput.connect(sourceSlot, sourceNode)) {
		subgraphNode.subgraph.removeInput(subgraphInput);
		return {
			ok: false,
			reason: "connectFailed"
		};
	}
	const hostInput = subgraphNode.inputs.find((input) => input._subgraphSlot === subgraphInput);
	if (hostInput) {
		hostInput.label = sourceSlot.label;
		if (hostInput.widgetId && sourceSlot.label) useWidgetValueStore().setLabel(hostInput.widgetId, sourceSlot.label);
	}
	seedNestedPromotedInputState(subgraphNode, subgraphInput.name, sourceSlot);
	return { ok: true };
}
function seedNestedPromotedInputState(subgraphNode, inputName, sourceSlot) {
	if (!sourceSlot.widgetId) return;
	if (subgraphNode.id === UNASSIGNED_NODE_ID) return;
	const hostInput = subgraphNode.inputs.find((input) => input._subgraphSlot?.name === inputName);
	if (!hostInput || hostInput.widgetId) return;
	const store = useWidgetValueStore();
	const sourceState = store.getWidget(sourceSlot.widgetId);
	const sourceVisibility = store.getWidgetVisibility(sourceSlot.widgetId);
	if (!sourceState || !sourceVisibility) return;
	const visibility = cloneDeep(sourceVisibility);
	visibility.suppression.byConnection = false;
	const id = widgetId(subgraphNode.rootGraph.id, subgraphNode.id, inputName);
	hostInput.widget ??= { name: inputName };
	hostInput.widget.name = inputName;
	if (!store.registerWidget(id, {
		type: sourceState.type,
		value: sourceState.value,
		options: cloneDeep(sourceState.options),
		label: hostInput.label ?? sourceSlot.label ?? inputName,
		serialize: sourceState.serialize,
		disabled: sourceState.disabled
	}, store.getWidgetRenderState(sourceSlot.widgetId) ?? {}, visibility)) {
		delete hostInput.widget;
		delete hostInput.widgetId;
		hostInput._widget = void 0;
		return;
	}
	hostInput.widgetId = id;
}
function promotePreviewViaExposure(subgraphNode, sourceNode, sourcePreviewName) {
	const store = usePreviewExposureStore();
	const rootGraphId = subgraphNode.rootGraph.id;
	const hostLocator = getPreviewExposureHostLocator(subgraphNode);
	if (!hostLocator) return;
	if (store.getExposures(rootGraphId, hostLocator).some((exposure) => exposure.sourceNodeId === String(sourceNode.id) && exposure.sourcePreviewName === sourcePreviewName)) return;
	store.addExposure(rootGraphId, hostLocator, {
		sourceNodeId: sourceNode.id,
		sourcePreviewName
	});
}
var PREVIEW_WIDGET_TYPES = /* @__PURE__ */ new Set([
	"preview",
	"video",
	"audioUI"
]);
function isPreviewPseudoWidget(widget) {
	if (widget.name.startsWith("$$")) return true;
	if (widget.serialize !== false && widget.options?.serialize !== false) return false;
	if (typeof widget.type === "string" && PREVIEW_WIDGET_TYPES.has(widget.type)) return true;
	return false;
}
function promoteWidget(node, widget, parents) {
	const source = toPromotionSource(node, widget);
	if (!(node instanceof LGraphNode)) return;
	for (const parent of parents) {
		if (isPreviewPseudoWidget(widget)) {
			promotePreviewViaExposure(parent, node, source.sourceWidgetName);
			continue;
		}
		const result = promoteValueWidgetViaSubgraphInput(parent, node, widget);
		if (!result.ok) addBreadcrumb({
			category: "subgraph",
			level: "warning",
			message: `Failed to promote widget "${source.sourceWidgetName}" on node ${node.id}: ${result.reason}`
		});
	}
	refreshPromotedWidgetRendering(parents);
	addBreadcrumb({
		category: "subgraph",
		message: `Promoted widget "${source.sourceWidgetName}" on node ${node.id}`,
		level: "info"
	});
}
/**
* Removes the host input projecting a linked promotion identified by source.
* Returns true when an input was found and demoted.
*/
function demotePromotedInput(subgraphNode, source) {
	const hostInput = findHostInputForPromotion(subgraphNode, source.sourceNodeId, source.sourceWidgetName);
	const linkedInput = hostInput?._subgraphSlot;
	if (!linkedInput) return false;
	const hostWidgetId = hostInput.widgetId;
	if (subgraphNode.isInputConnected(subgraphNode.inputs.indexOf(hostInput))) linkedInput.disconnect();
	else subgraphNode.subgraph.removeInput(linkedInput);
	if (hostWidgetId) useWidgetValueStore().deleteWidget(hostWidgetId);
	return true;
}
function demoteWidget(node, widget, parents) {
	const source = toPromotionSource(node, widget);
	for (const parent of parents) {
		if (demotePromotedInput(parent, source)) continue;
		if (isPreviewPseudoWidget(widget)) {
			const previewStore = usePreviewExposureStore();
			const hostLocator = getPreviewExposureHostLocator(parent);
			if (!hostLocator) continue;
			const exposure = previewStore.getExposures(parent.rootGraph.id, hostLocator).find((entry) => entry.sourceNodeId === source.sourceNodeId && entry.sourcePreviewName === source.sourceWidgetName);
			if (exposure) {
				previewStore.removeExposure(parent.rootGraph.id, hostLocator, exposure.name);
				continue;
			}
		}
	}
	refreshPromotedWidgetRendering(parents);
	addBreadcrumb({
		category: "subgraph",
		message: `Demoted widget "${source.sourceWidgetName}" on node ${node.id}`,
		level: "info"
	});
}
function getParentNodes() {
	const { navigationStack } = useSubgraphNavigationStore();
	const subgraph = navigationStack.at(-1);
	if (!subgraph) {
		useToast().error(t("g.error"), { description: t("subgraphStore.promoteOutsideSubgraph") });
		return [];
	}
	return (navigationStack.at(-2) ?? subgraph.rootGraph).nodes.filter((node) => node.type === subgraph.id && node.isSubgraphNode());
}
function addWidgetPromotionOptions(options, widget, node) {
	const parents = getParentNodes();
	const source = toPromotionSource(node, widget);
	const promotableParents = parents.filter((parent) => !isWidgetPromotedOnSubgraphNode(parent, source, widget));
	if (promotableParents.length > 0) options.unshift({
		content: t("subgraphStore.promoteWidget", { name: widget.label ?? widget.name }),
		callback: () => {
			promoteWidget(node, widget, promotableParents);
			widget.callback?.(widget.value);
		}
	});
	else options.unshift({
		content: t("subgraphStore.unpromoteWidget", { name: widget.label ?? widget.name }),
		callback: () => {
			demoteWidget(node, widget, parents);
			widget.callback?.(widget.value);
		}
	});
}
function tryToggleWidgetPromotion() {
	const canvas = useCanvasStore().getCanvas();
	const [x, y] = canvas.graph_mouse;
	const node = canvas.graph?.getNodeOnPos(x, y, canvas.visible_nodes);
	if (!node) return;
	const widget = node.getWidgetOnPos(x, y, true);
	const parents = getParentNodes();
	if (!parents.length || !widget) return;
	const source = toPromotionSource(node, widget);
	const promotableParents = parents.filter((parent) => !isWidgetPromotedOnSubgraphNode(parent, source, widget));
	if (promotableParents.length > 0) promoteWidget(node, widget, promotableParents);
	else demoteWidget(node, widget, parents);
}
var recommendedNodes = [
	"CLIPTextEncode",
	"LoadImage",
	"SaveImage",
	"PreviewImage"
];
var recommendedWidgetNames = ["seed"];
function isRecommendedWidget([node, widget]) {
	return !widget.computedDisabled && (recommendedNodes.includes(node.type) || recommendedWidgetNames.includes(widget.name));
}
function supportsVirtualPreviewWidget(node) {
	return supportsVirtualCanvasImagePreview(node);
}
function createVirtualCanvasImagePreviewWidget() {
	return {
		name: CANVAS_IMAGE_PREVIEW_WIDGET,
		type: "IMAGE_PREVIEW",
		options: { serialize: false },
		serialize: false,
		y: 0,
		computedDisabled: false
	};
}
function getPromotableWidgets(node) {
	const widgets = [...node.widgets ?? []];
	const hasCanvasPreviewWidget = widgets.some((widget) => widget.name === CANVAS_IMAGE_PREVIEW_WIDGET);
	const supportsVirtualPreview = supportsVirtualPreviewWidget(node);
	if (!hasCanvasPreviewWidget && supportsVirtualPreview) widgets.push(createVirtualCanvasImagePreviewWidget());
	return widgets;
}
function nodeWidgets(n) {
	return getPromotableWidgets(n).map((w) => [n, w]);
}
function autoExposeKnownPreviewNodes(subgraphNode) {
	if (subgraphNode.properties.previewExposures !== void 0) return;
	const { updatePreviews } = useLitegraphServiceAccess();
	const interiorNodes = subgraphNode.subgraph.nodes;
	for (const node of interiorNodes) {
		node.updateComputedDisabled();
		const hasPreviewWidget = () => node.widgets?.some(isPreviewPseudoWidget) ?? false;
		function promotePreviewWidget() {
			const widget = node.widgets?.find(isPreviewPseudoWidget);
			if (!widget) return;
			promotePreviewViaExposure(subgraphNode, node, widget.name);
		}
		promotePreviewWidget();
		if (hasPreviewWidget()) continue;
		if (supportsVirtualCanvasImagePreview(node)) {
			promotePreviewViaExposure(subgraphNode, node, CANVAS_IMAGE_PREVIEW_WIDGET);
			continue;
		}
		requestAnimationFrame(() => updatePreviews(node, promotePreviewWidget));
	}
}
function promoteRecommendedWidgets(subgraphNode) {
	autoExposeKnownPreviewNodes(subgraphNode);
	const filteredWidgets = subgraphNode.subgraph.nodes.flatMap(nodeWidgets).filter(isRecommendedWidget).filter(([, widget]) => !isPreviewPseudoWidget(widget));
	for (const [n, w] of filteredWidgets) {
		const result = promoteValueWidgetViaSubgraphInput(subgraphNode, n, w);
		if (!result.ok) addBreadcrumb({
			category: "subgraph",
			level: "warning",
			message: `Failed to promote widget "${w.name}" on node ${n.id}: ${result.reason}`
		});
	}
	subgraphNode.expandToFitContent();
}
function pruneDisconnected(subgraphNode) {
	const subgraph = subgraphNode.subgraph;
	const removedEntries = [];
	const staleInputs = subgraph.inputs.filter((input) => {
		if (resolvePromotionSource(subgraphNode, input)) return false;
		const hostInput = subgraphNode.inputs.find((entry) => entry._subgraphSlot === input);
		if (!hostInput?.widgetId && !hostInput?._widget) return false;
		removedEntries.push({
			sourceNodeId: subgraphNode.id,
			sourceWidgetName: input.name
		});
		return true;
	});
	for (const input of staleInputs) subgraph.removeInput(input);
	if (removedEntries.length > 0 && false);
	refreshPromotedWidgetRendering([subgraphNode]);
	addBreadcrumb({
		category: "subgraph",
		message: `Pruned ${removedEntries.length} disconnected promoted widget input(s) from subgraph node ${subgraphNode.id}`,
		level: "info"
	});
}
function hasUnpromotedWidgets(subgraphNode) {
	if (subgraphNode.isDetached) return false;
	const { subgraph } = subgraphNode;
	return subgraph.nodes.some((interiorNode) => getPromotableWidgets(interiorNode).some((widget) => !widget.computedDisabled && !isWidgetPromotedOnSubgraphNode(subgraphNode, {
		sourceNodeId: interiorNode.id,
		sourceWidgetName: widget.name
	}, widget)));
}
providePromoteRecommendedWidgets(promoteRecommendedWidgets);
//#endregion
//#region src/services/subgraphPseudoWidgetCache.ts
function isPseudoPromotion(widgetName, widgets, isPreviewPseudoWidget) {
	const widget = widgets?.find((candidate) => candidate.name === widgetName);
	if (widget) return isPreviewPseudoWidget(widget);
	return widgetName.startsWith("$$");
}
function isCacheStillValid(cache, getNodeById, isPreviewPseudoWidget) {
	return cache.entries.every((entry) => {
		const currentNode = getNodeById(entry.sourceNodeId);
		if (!currentNode || currentNode !== entry.node) return false;
		return isPseudoPromotion(entry.sourceWidgetName, currentNode.widgets, isPreviewPseudoWidget);
	});
}
function resolveSubgraphPseudoWidgetCache(args) {
	const { cache, promotions, getNodeById, isPreviewPseudoWidget } = args;
	if (cache && cache.promotions === promotions && isCacheStillValid(cache, getNodeById, isPreviewPseudoWidget)) return {
		cache,
		nodes: cache.nodes
	};
	const entries = promotions.flatMap((promotion) => {
		const node = getNodeById(promotion.sourceNodeId);
		if (!node) return [];
		if (!isPseudoPromotion(promotion.sourceWidgetName, node.widgets, isPreviewPseudoWidget)) return [];
		return [{
			...promotion,
			node
		}];
	});
	const nextCache = {
		promotions,
		entries,
		nodes: entries.map((entry) => entry.node)
	};
	return {
		cache: nextCache,
		nodes: nextCache.nodes
	};
}
//#endregion
//#region src/utils/nodeTitleUtil.ts
function resolveNodeDisplayName(node, options) {
	if (!node) return options.emptyLabel;
	const title = (node.title ?? "").toString().trim();
	if (title.length > 0) return title;
	const nodeType = (node.type ?? "").toString().trim() || options.untitledLabel;
	return resolveNodeDefText("display_name", nodeType);
}
//#endregion
//#region src/stores/workspace/favoritedWidgetsStore.ts
/**
* Store for managing favorited/starred widgets.
*
* Favorited widgets can be accessed and edited from the right side panel
* without needing to select the corresponding node. This store manages:
* - Persisting favorited widget IDs per workflow
* - Resolving widget IDs to actual widget instances
* - Handling cases where nodes/widgets are deleted
*
* Design decisions:
* - Scope: Per-workflow (not global user preference)
* - Identifier: node locator ID + widget.name
* - Persistence: Stored in workflow.extra.favoritedWidgets (serialized with workflow)
* - Future: Can be extended for Linear Mode
*/
var useFavoritedWidgetsStore = defineStore("favoritedWidgets", () => {
	const workflowStore = useWorkflowStore();
	const canvasStore = useCanvasStore();
	/** In-memory array of favorited widget IDs, ordered for display */
	const favoritedIds = ref([]);
	/**
	* Generate a unique string key for a favorited widget ID.
	*/
	function getFavoriteKey(id) {
		return JSON.stringify([id.nodeLocatorId, id.widgetName]);
	}
	/**
	* Parse a favorite key back into a FavoritedWidgetId.
	*/
	function parseFavoriteKey(key) {
		try {
			const [nodeLocatorId, widgetName] = JSON.parse(key);
			if (!isNodeLocatorId(nodeLocatorId) || !widgetName) return null;
			return {
				nodeLocatorId,
				widgetName
			};
		} catch {
			const separatorIndex = key.indexOf(":");
			if (separatorIndex === -1) return null;
			const nodeLocatorId = key.slice(0, separatorIndex);
			const widgetName = key.slice(separatorIndex + 1);
			if (!isNodeLocatorId(nodeLocatorId) || !widgetName) return null;
			return {
				nodeLocatorId,
				widgetName
			};
		}
	}
	function normalizeFavoritedId(id) {
		if (!id || !id.widgetName) return null;
		if ("nodeLocatorId" in id && id.nodeLocatorId) {
			if (!isNodeLocatorId(id.nodeLocatorId)) return null;
			return {
				nodeLocatorId: id.nodeLocatorId,
				widgetName: id.widgetName
			};
		}
		if ("nodeId" in id && id.nodeId !== void 0) {
			const parsedNodeId = parseNodeId(id.nodeId);
			if (!parsedNodeId) return null;
			return {
				nodeLocatorId: workflowStore.nodeIdToNodeLocatorId(parsedNodeId),
				widgetName: String(id.widgetName)
			};
		}
		return null;
	}
	function createFavoriteId(node, widgetName) {
		return {
			nodeLocatorId: workflowStore.nodeToNodeLocatorId(node),
			widgetName
		};
	}
	/**
	* Load favorited widgets from the current workflow's extra data.
	*/
	function loadFromWorkflow() {
		const graph = useApp().rootGraphOrUndefined;
		if (!graph) return;
		try {
			const storedData = graph.extra.favoritedWidgets;
			if (storedData?.favorites) {
				const normalized = storedData.favorites.map((fav) => normalizeFavoritedId(fav)).filter((fav) => fav !== null);
				favoritedIds.value = normalized.map(getFavoriteKey);
			} else favoritedIds.value = [];
		} catch (error) {
			console.error("Failed to load favorited widgets from workflow:", error);
			favoritedIds.value = [];
		}
	}
	/**
	* Save favorited widgets to the current workflow's extra data.
	* Marks the workflow as modified.
	*/
	function saveToWorkflow() {
		const graph = useApp().rootGraphOrUndefined;
		if (!graph) return;
		try {
			const data = { favorites: favoritedIds.value.map(parseFavoriteKey).filter((id) => id !== null) };
			graph.extra.favoritedWidgets = data;
			canvasStore.canvas?.setDirty(true, true);
		} catch (error) {
			console.error("Failed to save favorited widgets to workflow:", error);
		}
	}
	/**
	* Resolve a favorited widget ID to its actual widget instance.
	* Returns null if the node or widget no longer exists.
	*/
	function resolveWidget(id) {
		const graph = useApp().rootGraphOrUndefined;
		if (!graph) return {
			...id,
			node: null,
			widget: null,
			label: id.widgetName
		};
		const node = getNodeByLocatorId(graph, id.nodeLocatorId);
		if (!node) return {
			...id,
			node: null,
			widget: null,
			label: `${id.widgetName} (node deleted)`
		};
		const widget = node.widgets?.find((w) => w.name === id.widgetName);
		if (!widget) return {
			...id,
			node,
			widget: null,
			label: `${id.widgetName} (widget not found)`
		};
		const fallbackNodeTitle = st("rightSidePanel.fallbackNodeTitle", "Node");
		const nodeTitle = resolveNodeDisplayName(node, {
			emptyLabel: fallbackNodeTitle,
			untitledLabel: fallbackNodeTitle
		});
		const widgetLabel = widget.label || widget.name;
		return {
			...id,
			node,
			widget,
			label: `${nodeTitle} / ${widgetLabel}`
		};
	}
	/**
	* Get all favorited widgets with their resolved instances.
	* Widgets that no longer exist will have null node/widget properties.
	*/
	const favoritedWidgets = computed(() => {
		return favoritedIds.value.map(parseFavoriteKey).filter((id) => id !== null).map(resolveWidget);
	});
	/**
	* Get only the valid favorited widgets (where both node and widget exist).
	*/
	const validFavoritedWidgets = computed(() => {
		return favoritedWidgets.value.filter((fw) => fw.node !== null && fw.widget !== null);
	});
	/**
	* Check if a widget is favorited.
	*/
	function isFavorited(node, widgetName) {
		return favoritedIds.value.includes(getFavoriteKey(createFavoriteId(node, widgetName)));
	}
	/**
	* Add a widget to favorites.
	*/
	function addFavorite(node, widgetName) {
		const key = getFavoriteKey(createFavoriteId(node, widgetName));
		if (favoritedIds.value.includes(key)) return;
		favoritedIds.value.push(key);
		saveToWorkflow();
	}
	/**
	* Remove a widget from favorites.
	*/
	function removeFavorite(node, widgetName) {
		const key = getFavoriteKey(createFavoriteId(node, widgetName));
		const index = favoritedIds.value.indexOf(key);
		if (index === -1) return;
		favoritedIds.value.splice(index, 1);
		saveToWorkflow();
	}
	/**
	* Toggle a widget's favorite status.
	*/
	function toggleFavorite(node, widgetName) {
		if (isFavorited(node, widgetName)) removeFavorite(node, widgetName);
		else addFavorite(node, widgetName);
	}
	/**
	* Clear all favorites for the current workflow.
	*/
	function clearFavorites() {
		favoritedIds.value = [];
		saveToWorkflow();
	}
	/**
	* Remove invalid favorites (where node or widget no longer exists).
	* Useful for cleanup after loading a workflow.
	*/
	function pruneInvalidFavorites() {
		const validKeys = validFavoritedWidgets.value.map((fw) => getFavoriteKey({
			nodeLocatorId: fw.nodeLocatorId,
			widgetName: fw.widgetName
		}));
		const validSet = new Set(validKeys);
		const filteredIds = favoritedIds.value.filter((key) => validSet.has(key));
		if (filteredIds.length !== favoritedIds.value.length) {
			favoritedIds.value = filteredIds;
			saveToWorkflow();
		}
	}
	/**
	* Reorder favorites based on the provided array of widgets.
	* Used when dragging and dropping favorites to reorder them.
	*/
	function reorderFavorites(reorderedWidgets) {
		favoritedIds.value = reorderedWidgets.map((fw) => getFavoriteKey({
			nodeLocatorId: fw.nodeLocatorId,
			widgetName: fw.widgetName
		}));
		saveToWorkflow();
	}
	watch(() => workflowStore.activeWorkflow?.path, () => {
		loadFromWorkflow();
	}, { immediate: true });
	return {
		favoritedWidgets,
		validFavoritedWidgets,
		isFavorited,
		addFavorite,
		removeFavorite,
		toggleFavorite,
		clearFavorites,
		pruneInvalidFavorites,
		reorderFavorites
	};
});
//#endregion
//#region src/stores/workspace/rightSidePanelStore.ts
/**
* Store for managing the right side panel state.
* This panel displays properties and settings for selected nodes.
*/
var useRightSidePanelStore = defineStore("rightSidePanel", () => {
	const settingStore = useSettingStore();
	const isLegacyMenu = computed(() => settingStore.get("Comfy.UseNewMenu") === "Disabled");
	const isOpen = computed({
		get: () => !isLegacyMenu.value && settingStore.get("Comfy.RightSidePanel.IsOpen"),
		set: (value) => settingStore.set("Comfy.RightSidePanel.IsOpen", value)
	});
	const activeTab = ref("parameters");
	const isEditingSubgraph = computed(() => activeTab.value === "subgraph");
	const focusedSection = ref(null);
	/**
	* Graph node ID to focus in the errors tab.
	* Set by SectionWidgets when the user clicks "See Error", consumed and
	* cleared by TabErrors after expanding the relevant error group.
	*/
	const focusedErrorNodeId = ref(null);
	watch(isLegacyMenu, (legacy) => {
		if (legacy) settingStore.set("Comfy.RightSidePanel.IsOpen", false);
	});
	function openPanel(tab) {
		if (isLegacyMenu.value) return;
		isOpen.value = true;
		if (tab) activeTab.value = tab;
	}
	function closePanel() {
		isOpen.value = false;
	}
	function togglePanel() {
		isOpen.value = !isOpen.value;
	}
	/**
	* Focus on a specific section in the right side panel.
	* This will open the panel, switch to the parameters tab, and signal
	* the component to expand and scroll to the section.
	*/
	function focusSection(section) {
		openPanel("parameters");
		focusedSection.value = section;
	}
	/**
	* Clear the focused section after it has been handled.
	*/
	function clearFocusedSection() {
		focusedSection.value = null;
	}
	return {
		isOpen,
		activeTab,
		isEditingSubgraph,
		focusedSection,
		focusedErrorNodeId,
		openPanel,
		closePanel,
		togglePanel,
		focusSection,
		clearFocusedSection
	};
});
//#endregion
//#region src/utils/coreMediaMenuActionUtils.ts
var coreMediaMenuActionKinds = /* @__PURE__ */ new WeakMap();
function markCoreMediaMenuCallback(callback, kind) {
	coreMediaMenuActionKinds.set(callback, kind);
	return callback;
}
function filterUnavailableCoreMediaMenuActions(options, unavailableKinds) {
	return options.filter((option) => {
		if (!option || typeof option !== "object" || !("callback" in option)) return true;
		const { callback } = option;
		if (typeof callback !== "function") return true;
		const kind = coreMediaMenuActionKinds.get(callback);
		return !kind || !unavailableKinds.has(kind);
	});
}
//#endregion
//#region src/workbench/utils/nodeDefOrderingUtil.ts
/**
* Gets an ordered array of InputSpec objects based on input_order.
* This is designed to work with V2 format used by litegraphService.
*
* @param nodeDefImpl - The ComfyNodeDefImpl containing both V1 and V2 formats
* @param inputs - The V2 format inputs (flat Record<string, InputSpec>)
* @returns Array of InputSpec objects in the correct order
*/
function getOrderedInputSpecs(nodeDefImpl, inputs) {
	const orderedInputSpecs = [];
	if (!nodeDefImpl.input_order) return Object.values(inputs).filter((input) => input !== void 0);
	const requiredOrder = Object.hasOwn(nodeDefImpl.input_order, "required") ? nodeDefImpl.input_order.required : [];
	for (const name of requiredOrder) {
		const inputSpec = inputs[name];
		if (inputSpec && !inputSpec.isOptional) orderedInputSpecs.push(inputSpec);
	}
	const optionalOrder = Object.hasOwn(nodeDefImpl.input_order, "optional") ? nodeDefImpl.input_order.optional : [];
	for (const name of optionalOrder) {
		const inputSpec = inputs[name];
		if (inputSpec?.isOptional) orderedInputSpecs.push(inputSpec);
	}
	const processedNames = new Set(orderedInputSpecs.map((spec) => spec.name));
	for (const inputSpec of Object.values(inputs)) if (inputSpec && !processedNames.has(inputSpec.name)) orderedInputSpecs.push(inputSpec);
	return orderedInputSpecs;
}
//#endregion
//#region src/services/litegraphService.ts
async function reencodeAsPngBlob(blob, width, height) {
	const canvas = $el("canvas", {
		width,
		height
	});
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Could not get canvas context");
	let image;
	if (typeof window.createImageBitmap === "undefined") {
		const img = new Image();
		const loaded = new Promise((resolve, reject) => {
			img.onload = () => resolve();
			img.onerror = () => reject(/* @__PURE__ */ new Error("Image load failed"));
		});
		img.src = URL.createObjectURL(blob);
		try {
			await loaded;
		} finally {
			URL.revokeObjectURL(img.src);
		}
		image = img;
	} else image = await createImageBitmap(blob);
	try {
		ctx.drawImage(image, 0, 0);
	} finally {
		if ("close" in image && typeof image.close === "function") image.close();
	}
	return new Promise((resolve, reject) => {
		canvas.toBlob((result) => {
			if (result) resolve(result);
			else reject(/* @__PURE__ */ new Error("PNG conversion failed"));
		}, "image/png");
	});
}
function getExtraOptionsForWidget(node, widget) {
	const options = [];
	const input = node.inputs.find((inp) => inp.widget?.name === widget.name);
	if (input) options.unshift({
		content: `${t("contextMenu.RenameWidget")}: ${widget.label ?? widget.name}`,
		callback: async () => {
			const newLabel = await useDialogService().prompt({
				title: t("g.rename"),
				message: t("g.enterNewNamePrompt"),
				defaultValue: widget.label,
				placeholder: widget.name
			});
			if (newLabel === null) return;
			widget.label = newLabel || void 0;
			input.label = newLabel || void 0;
			widget.callback?.(widget.value);
			useCanvasStore().canvas?.setDirty(true);
		}
	});
	const favoritedWidgetsStore = useFavoritedWidgetsStore();
	const isFavorited = favoritedWidgetsStore.isFavorited(node, widget.name);
	options.unshift({
		content: isFavorited ? `${t("contextMenu.UnfavoriteWidget")}: ${widget.label ?? widget.name}` : `${t("contextMenu.FavoriteWidget")}: ${widget.label ?? widget.name}`,
		callback: () => {
			favoritedWidgetsStore.toggleFavorite(node, widget.name);
		}
	});
	if (node.graph && !node.graph.isRootGraph) addWidgetPromotionOptions(options, widget, node);
	return options;
}
function getMinSize(node) {
	node._initialMinSize ??= {
		width: 1,
		height: 1
	};
	return node._initialMinSize;
}
/**
* Service that augments litegraph with ComfyUI specific functionality.
*/
var useLitegraphService = () => {
	const extensionService = useExtensionService();
	const toast = useToast();
	const widgetStore = useWidgetStore();
	const canvasStore = useCanvasStore();
	const { toggleSelectedNodesMode } = useSelectedLiteGraphItems();
	const subgraphPseudoWidgetCache = /* @__PURE__ */ new WeakMap();
	function invalidateSubgraphPseudoWidgetCache(node) {
		subgraphPseudoWidgetCache.delete(node);
	}
	function getPseudoWidgetPreviewTargets(node) {
		const hostLocator = getPreviewExposureHostLocator(node);
		if (!hostLocator) return [];
		const promotions = usePreviewExposureStore().getExposuresAsPromotionShape(node.rootGraph.id, hostLocator);
		const resolved = resolveSubgraphPseudoWidgetCache({
			cache: subgraphPseudoWidgetCache.get(node) ?? null,
			promotions,
			getNodeById: (nodeId) => node.subgraph.getNodeById(nodeId) ?? void 0,
			isPreviewPseudoWidget
		});
		subgraphPseudoWidgetCache.set(node, resolved.cache);
		return resolved.nodes;
	}
	/**
	* @internal The node definition name used to resolve the node's i18n text.
	*/
	function nodeDefName(node) {
		return node.constructor.nodeData?.name ?? "";
	}
	/**
	* @internal Add input sockets to the node. (No widget)
	*/
	function addInputSocket(node, inputSpec) {
		const inputName = inputSpec.name;
		if (widgetStore.widgets.get(inputSpec.widgetType ?? inputSpec.type) && !inputSpec.forceInput || applyDynamicInputs(node, inputSpec)) return;
		node.addInput(inputName, inputSpec.type, {
			shape: inputSpec.isOptional ? RenderShape.HollowCircle : void 0,
			localized_name: resolveNodeDefSlotText("name", nodeDefName(node), inputName, inputSpec.display_name, inputName)
		});
	}
	/**
	* @internal Setup stroke styles for the node under various conditions.
	*/
	function setupStrokeStyles(node) {
		node.strokeStyles["running"] = function() {
			const nodeLocatorId = useWorkflowStore().nodeIdToNodeLocatorId(this.id);
			if (useExecutionStore().nodeLocationProgressStates[nodeLocatorId]?.state === "running") return {
				color: "#0f0",
				lineWidth: 3
			};
		};
		node.strokeStyles["dragOver"] = function() {
			if (useApp().dragOverNode?.id == this.id) return { color: "dodgerblue" };
		};
		node.strokeStyles["executionError"] = function() {
			if (useApp().lastExecutionError?.node_id == this.id) return {
				color: LiteGraph.NODE_ERROR_COLOUR,
				lineWidth: 3
			};
		};
	}
	/**
	* Utility function. Implemented for use with dynamic widgets
	*/
	function addNodeInput(node, inputSpec) {
		addInputSocket(node, inputSpec);
		addInputWidget(node, inputSpec, { dynamic: true });
	}
	function validateDynamicGroupWidgets(inputData, name) {
		const { template } = zDynamicGroupInputSpec.parse(inputData)[1];
		const fields = {
			...template.required,
			...template.optional
		};
		for (const [field, spec] of Object.entries(fields)) if (!widgetStore.widgets.has(spec[1]?.widgetType ?? getInputSpecType(spec))) throw new TypeError(`DynamicGroup field '${name}.${field}' requires a registered widget`);
	}
	/**
	* @internal Add a widget to the node. For both primitive types and custom widgets
	* (unless `socketless`), an input socket is also added.
	*/
	function addInputWidget(node, inputSpec, { dynamic } = {}) {
		const widgetInputSpec = { ...inputSpec };
		if (inputSpec.widgetType) widgetInputSpec.type = inputSpec.widgetType;
		const inputName = inputSpec.name;
		const resolveLabel = (fallback) => resolveNodeDefSlotText("name", nodeDefName(node), inputName, widgetInputSpec.display_name, fallback);
		const widgetConstructor = widgetStore.widgets.get(widgetInputSpec.type);
		if (!widgetConstructor || inputSpec.forceInput) return;
		const inputData = transformInputSpecV2ToV1(widgetInputSpec);
		if (widgetInputSpec.type === "COMFY_DYNAMICGROUP_V3") validateDynamicGroupWidgets(inputData, inputName);
		const widgetsBefore = new Set(node.widgets ?? []);
		const result = widgetConstructor(node, inputName, inputData, useApp());
		const { minWidth = 1, minHeight = 1 } = (result && !("type" in result) ? result : void 0) ?? {};
		const returnedWidget = result && "type" in result ? result : result?.widget;
		if (returnedWidget) returnedWidget.options ??= {};
		const widget = (node.widgets ?? []).find((candidate) => candidate === returnedWidget || !widgetsBefore.has(candidate) && (!returnedWidget || candidate.name === returnedWidget.name)) ?? (returnedWidget ? toConcreteWidget(returnedWidget, node) : void 0);
		if (!widget) return;
		widget.label = resolveLabel(widget.label ?? widgetInputSpec.display_name ?? inputName);
		Object.assign(widget.options, { advanced: inputSpec.advanced });
		if (inputSpec.hidden !== void 0) widget.hidden = inputSpec.hidden;
		if (dynamic) widget.tooltip = inputSpec.tooltip;
		if (!widget.options.socketless) {
			const inputSpecV1 = transformInputSpecV2ToV1(widgetInputSpec);
			node.addInput(inputName, inputSpec.type, {
				shape: inputSpec.isOptional ? RenderShape.HollowCircle : void 0,
				localized_name: resolveLabel(inputName),
				widget: {
					name: inputName,
					[GET_CONFIG]: () => inputSpecV1
				}
			});
		}
		const minSize = getMinSize(node);
		minSize.width = Math.max(minSize.width, minWidth);
		minSize.height = Math.max(minSize.height, minHeight);
	}
	/**
	* @internal Add inputs to the node.
	*/
	function addInputs(node, inputs) {
		const orderedInputSpecs = getOrderedInputSpecs(node.constructor.nodeData ?? {}, inputs);
		for (const inputSpec of orderedInputSpecs) addInputSocket(node, inputSpec);
		for (const inputSpec of orderedInputSpecs) addInputWidget(node, inputSpec);
	}
	/**
	* @internal Add outputs to the node.
	*/
	function addOutputs(node, outputs) {
		for (const output of outputs) {
			const { name, is_list } = output;
			const type = output.type === "COMFY_MATCHTYPE_V3" ? "*" : output.type;
			const shapeOptions = is_list ? { shape: LiteGraph.GRID_SHAPE } : {};
			const typeKey = `dataTypes.${normalizeI18nKey(type)}`;
			const outputOptions = {
				...shapeOptions,
				localized_name: type !== name ? resolveNodeDefSlotText("name", nodeDefName(node), output.index, name) : st(typeKey, name)
			};
			node.addOutput(name, type, outputOptions);
		}
	}
	/**
	* @internal Set the initial size of the node.
	*/
	function setInitialSize(node) {
		const s = node.computeSize();
		const pad = node.widgets?.length && !useSettingStore().get("LiteGraph.Node.DefaultPadding");
		const minSize = getMinSize(node);
		s[0] = Math.max(minSize.width, s[0] + (pad ? 60 : 0));
		s[1] = Math.max(minSize.height, s[1]);
		node.setSize(s);
	}
	function registerSubgraphNodeDef(nodeDefV1, subgraph, instanceData) {
		const node = class ComfyNode extends SubgraphNode {
			static comfyClass;
			static title;
			static category;
			static nodeData;
			constructor() {
				super(useApp().rootGraph, subgraph, instanceData);
				subgraph.events.addEventListener("widget-promoted", () => {
					invalidateSubgraphPseudoWidgetCache(this);
				});
				subgraph.events.addEventListener("widget-demoted", () => {
					invalidateSubgraphPseudoWidgetCache(this);
				});
				setupStrokeStyles(this);
				addInputs(this, ComfyNode.nodeData.inputs);
				addOutputs(this, ComfyNode.nodeData.outputs);
				setInitialSize(this);
				this.serialize_widgets = true;
				extensionService.invokeExtensionsAsync("nodeCreated", this);
			}
			createPromotedHostWidget(input, widgetId, sourceWidget) {
				return createPromotedMultilineWidget({
					subgraphNode: this,
					input,
					widgetId,
					sourceWidget
				});
			}
			/**
			* Configure the node from a serialised node. Keep 'name', 'type', 'shape',
			* and 'localized_name' information from the original node definition.
			*/
			configure(data) {
				const RESERVED_KEYS = [
					"name",
					"type",
					"shape",
					"localized_name"
				];
				const inputByName = new Map(data.inputs?.map((input) => [input.name, input]) ?? []);
				const definedInputNames = new Set(this.inputs.map((input) => input.name));
				const definedInputs = this.inputs.map((input) => {
					const inputData = inputByName.get(input.name);
					return inputData ? {
						...inputData,
						...pick(input, RESERVED_KEYS.concat("widget"))
					} : input;
				});
				const extraInputs = data.inputs?.filter((input) => !definedInputNames.has(input.name));
				data.inputs = [...definedInputs, ...extraInputs ?? []];
				data.outputs = zip(this.outputs, data.outputs ?? []).map(([output, outputData], index) => {
					if (!output) return outputData;
					return outputData ? {
						...outputData,
						...pick(output, RESERVED_KEYS)
					} : outputAsSerialisable(output, this, index);
				});
				data.widgets_values = migrateWidgetsValues(ComfyNode.nodeData.inputs, this.widgets, data.widgets_values ?? []);
				super.configure(data);
			}
		};
		addNodeContextMenuHandler(node);
		addDrawBackgroundHandler(node);
		addNodeKeyHandler(node);
		node.prototype.comfyClass = nodeDefV1.name;
		node.comfyClass = nodeDefV1.name;
		const nodeDef = new ComfyNodeDefImpl(nodeDefV1);
		node.nodeData = nodeDef;
		LiteGraph.registerNodeType(subgraph.id, node);
		node.category = nodeDef.category;
		node.skip_list = true;
		node.title = nodeDef.display_name || nodeDef.name;
	}
	async function registerNodeDef(nodeId, nodeDefV1) {
		const node = class ComfyNode extends LGraphNode {
			static comfyClass;
			static title;
			static category;
			static nodeData;
			constructor(title) {
				super(title);
				setupStrokeStyles(this);
				addInputs(this, ComfyNode.nodeData.inputs);
				addOutputs(this, ComfyNode.nodeData.outputs);
				setInitialSize(this);
				this.serialize_widgets = true;
				if (ComfyNode.nodeData.api_node) {
					this.color = LGraphCanvas.node_colors.yellow.color;
					this.bgcolor = LGraphCanvas.node_colors.yellow.bgcolor;
				}
				extensionService.invokeExtensionsAsync("nodeCreated", this);
			}
			/**
			* Configure the node from a serialised node. Keep 'name', 'type', 'shape',
			* and 'localized_name' information from the original node definition.
			*/
			configure(data) {
				const RESERVED_KEYS = [
					"name",
					"type",
					"shape",
					"localized_name"
				];
				const inputByName = new Map(data.inputs?.map((input) => [input.name, input]) ?? []);
				const definedInputNames = new Set(this.inputs.map((input) => input.name));
				const definedInputs = this.inputs.map((input) => {
					const inputData = inputByName.get(input.name);
					return inputData ? {
						...inputData,
						...pick(input, RESERVED_KEYS.concat("widget"))
					} : input;
				});
				const extraInputs = data.inputs?.filter((input) => !definedInputNames.has(input.name));
				data.inputs = [...definedInputs, ...extraInputs ?? []];
				data.outputs = zip(this.outputs, data.outputs ?? []).map(([output, outputData], index) => {
					if (!output) return outputData;
					return outputData ? {
						...outputData,
						...pick(output, RESERVED_KEYS)
					} : outputAsSerialisable(output, this, index);
				});
				data.widgets_values = migrateWidgetsValues(ComfyNode.nodeData.inputs, this.widgets ?? [], data.widgets_values ?? []);
				super.configure(data);
			}
		};
		addNodeContextMenuHandler(node);
		addDrawBackgroundHandler(node);
		addNodeKeyHandler(node);
		node.prototype.comfyClass = nodeDefV1.name;
		node.comfyClass = nodeDefV1.name;
		await extensionService.invokeExtensionsAsync("beforeRegisterNodeDef", node, nodeDefV1);
		const nodeDef = new ComfyNodeDefImpl(nodeDefV1);
		node.nodeData = nodeDef;
		LiteGraph.registerNodeType(nodeId, node);
		node.category = nodeDef.category;
		node.title = nodeDef.display_name || nodeDef.name;
		if (nodeDef.dev_only) node.skip_list = !useSettingStore().get("Comfy.DevMode");
	}
	/**
	* Adds special context menu handling for nodes
	* e.g. this adds Open Image functionality for nodes that show images
	* @param {*} node The node to add the menu handler
	*/
	function addNodeContextMenuHandler(node) {
		function getCopyImageOption(img) {
			if (typeof window.ClipboardItem === "undefined") return [];
			return [{
				content: "Copy Image",
				callback: markCoreMediaMenuCallback(async () => {
					const url = new URL(img.src);
					url.searchParams.delete("preview");
					try {
						const blob = await (await fetch(url)).blob();
						try {
							await navigator.clipboard.write([new ClipboardItem({ [blob.type]: blob })]);
						} catch (error) {
							if (blob.type !== "image/png") {
								const pngBlob = await reencodeAsPngBlob(blob, img.naturalWidth, img.naturalHeight);
								await navigator.clipboard.write([new ClipboardItem({ "image/png": pngBlob })]);
								return;
							}
							throw error;
						}
					} catch (error) {
						toast.warning(t("toastMessages.errorCopyImage", { error: getErrorMessage(error) ?? t("g.unknownError") }));
					}
				}, "preview")
			}];
		}
		node.prototype.getExtraMenuOptions = function(canvas, options) {
			if (this.imgs) {
				let img;
				if (this.imageIndex != null) img = this.imgs[this.imageIndex];
				else if (this.overIndex != null) img = this.imgs[this.overIndex];
				if (img) options.unshift({
					content: "Open Image",
					callback: markCoreMediaMenuCallback(() => {
						const url = getImageFileUrl(img);
						openFileInNewTab(url.toString());
					}, "preview")
				}, ...getCopyImageOption(img), {
					content: "Save Image",
					callback: markCoreMediaMenuCallback(() => {
						const url = getImageFileUrl(img);
						const filename = new URLSearchParams(url.search).get("filename");
						downloadFile(url.toString(), filename ?? void 0);
					}, "preview")
				});
			}
			options.push({
				content: "Bypass",
				callback: () => {
					toggleSelectedNodesMode(LGraphEventMode.BYPASS);
					canvas.setDirty(true, true);
				}
			});
			if (!clipspace.returnNode) {
				options.push({
					content: "Copy (Clipspace)",
					callback: () => {
						copyToClipspace(this);
					}
				});
				if (clipspace.current != null) options.push({
					content: "Paste (Clipspace)",
					callback: markCoreMediaMenuCallback(() => {
						pasteFromClipspace(this);
					}, "input")
				});
			}
			if (this instanceof SubgraphNode) options.unshift({
				content: "Edit Subgraph Widgets",
				callback: () => {
					useRightSidePanelStore().openPanel("subgraph");
				}
			}, {
				content: "Unpack Subgraph",
				callback: () => {
					const { unpackSubgraph } = useSubgraphOperations();
					unpackSubgraph();
				}
			});
			const [x, y] = canvas.graph_mouse;
			const overWidget = this.getWidgetOnPos(x, y, true);
			if (overWidget) options.unshift(...getExtraOptionsForWidget(this, overWidget));
			return [];
		};
	}
	function updatePreviews(node, callback) {
		try {
			unsafeUpdatePreviews.call(node, callback);
		} catch (error) {
			console.error("Error drawing node background", error);
		}
	}
	function unsafeUpdatePreviews(callback) {
		if (this.flags.collapsed) return;
		const nodeOutputStore = useNodeOutputStore();
		const { showAnimatedPreview, removeAnimatedPreview } = useNodeAnimatedImage();
		const { showCanvasImagePreview, removeCanvasImagePreview } = useNodeCanvasImagePreview();
		const output = nodeOutputStore.getNodeOutputs(this);
		const preview = nodeOutputStore.getNodePreviews(this);
		const isNewOutput = output && this.images !== output.images;
		const isNewPreview = preview && this.preview !== preview;
		if (isNewPreview) this.preview = preview;
		if (isNewOutput) this.images = output.images;
		if (isNewOutput || isNewPreview) {
			this.animatedImages = isAnimatedOutput(output);
			if (isVideoOutput(output) || isVideoNode(this)) useNodeVideo(this, callback).showPreview();
			else useNodeImage(this, callback).showPreview();
		}
		if (!this.imgs?.length) return;
		if (this.animatedImages) {
			removeCanvasImagePreview(this);
			showAnimatedPreview(this);
		} else {
			removeAnimatedPreview(this);
			showCanvasImagePreview(this);
		}
	}
	/**
	* Adds Custom drawing logic for nodes
	* e.g. Draws images and handles thumbnail navigation on nodes that output images
	* @param {*} node The node to add the draw handler
	*/
	function addDrawBackgroundHandler(node) {
		/**
		* @deprecated No longer needed as we use {@link useImagePreviewWidget}
		*/
		node.prototype.setSizeForImage = function() {
			console.warn("node.setSizeForImage is deprecated. Now it has no effect. Please remove the call to it.");
		};
		node.prototype.onDrawBackground = function() {
			updatePreviews(this);
			if (this instanceof SubgraphNode) {
				const parentGraph = this.graph;
				for (const interiorNode of getPseudoWidgetPreviewTargets(this)) updatePreviews(interiorNode, () => {
					parentGraph?.setDirtyCanvas(true);
				});
			}
		};
	}
	function addNodeKeyHandler(node) {
		const origNodeOnKeyDown = node.prototype.onKeyDown;
		node.prototype.onKeyDown = function(e) {
			if (origNodeOnKeyDown?.call(this, e) === false) return false;
			if (this.flags.collapsed || !this.imgs || this.imageIndex === null) return;
			let handled = false;
			if (e.key === "ArrowLeft" || e.key === "ArrowRight") {
				const imageIndex = this.imageIndex;
				if (imageIndex === void 0) return;
				if (e.key === "ArrowLeft") this.imageIndex = imageIndex - 1;
				else this.imageIndex = imageIndex + 1;
				this.imageIndex %= this.imgs.length;
				if (this.imageIndex < 0) this.imageIndex = this.imgs.length + this.imageIndex;
				handled = true;
			} else if (e.key === "Escape") {
				this.imageIndex = null;
				handled = true;
			}
			if (handled) {
				e.preventDefault();
				e.stopImmediatePropagation();
				return false;
			}
		};
	}
	function addNodeOnGraph(nodeDef, options = {}, addOptions) {
		options.pos ??= getCanvasCenter();
		if (isBlueprintType(nodeDef.name)) {
			const canvas = canvasStore.getCanvas();
			const bp = useSubgraphStore().getBlueprint(nodeDef.name);
			const items = {
				nodes: bp.nodes,
				subgraphs: bp.definitions?.subgraphs
			};
			const results = canvas._deserializeItems(items, { position: options.pos });
			if (!results) throw new Error("Failed to add subgraph blueprint");
			const node = results.nodes.values().next().value;
			if (!node) throw new Error("Subgraph blueprint was added, but failed to resolve a subgraph Node");
			if (addOptions?.ghost) {
				node.flags.ghost = true;
				canvas.graph?.trigger("node:property:changed", {
					nodeId: node.id,
					property: "flags.ghost",
					oldValue: false,
					newValue: true
				});
				canvas.startGhostPlacement(node, addOptions.dragEvent);
			}
			return node;
		}
		const node = LiteGraph.createNode(nodeDef.name, nodeDef.display_name, options);
		const graph = useWorkflowStore().activeSubgraph ?? useApp().graph;
		if (!node) return null;
		graph.add(node, addOptions);
		return node;
	}
	function getCanvasCenter() {
		if (!useApp().isGraphReady) return [0, 0];
		const [x, y, w, h] = useApp().canvas.ds.visible_area;
		return [x + w / 2, y + h / 2];
	}
	function goToNode(nodeId) {
		const parsedNodeId = parseNodeId(nodeId);
		if (!parsedNodeId) return;
		const graphNode = useApp().canvas.graph?.getNodeById(parsedNodeId);
		if (!graphNode) return;
		useApp().canvas.animateToBounds(graphNode.boundingRect);
	}
	function ensureBounds(nodes) {
		for (const node of nodes) {
			if (!node.boundingRect.every((i) => i === 0)) continue;
			node.updateArea();
		}
	}
	/**
	* Resets the canvas view to the default
	*/
	function resetView() {
		const canvas = canvasStore.canvas;
		if (!canvas) return;
		canvas.ds.scale = 1;
		canvas.ds.offset = [0, 0];
		canvas.setDirty(true, true);
	}
	function fitView() {
		const canvas = canvasStore.getCanvas();
		const nodes = canvas.graph?.nodes;
		if (!nodes) return;
		ensureBounds(nodes);
		const bounds = createBounds(nodes);
		if (!bounds) return;
		canvas.ds.fitToBounds(bounds, { viewport: visibleCanvasViewport(canvas) });
		canvas.setDirty(true, true);
	}
	return {
		registerNodeDef,
		registerSubgraphNodeDef,
		addNodeOnGraph,
		addNodeInput,
		getCanvasCenter,
		getExtraOptionsForWidget,
		goToNode,
		resetView,
		fitView,
		updatePreviews
	};
};
provideLitegraphService(useLitegraphService);
//#endregion
//#region src/services/subgraphService.ts
var useSubgraphService = () => {
	const nodeDefStore = useNodeDefStore();
	/** Loads a single subgraph definition and registers it with the node def store */
	function registerLitegraphNode(nodeDef, subgraph, exportedSubgraph) {
		const instanceData = {
			id: -1,
			type: exportedSubgraph.id,
			pos: [0, 0],
			size: [100, 100],
			inputs: [],
			outputs: [],
			flags: {},
			order: 0,
			mode: 0
		};
		useLitegraphService().registerSubgraphNodeDef(nodeDef, subgraph, instanceData);
	}
	function createNodeDef(exportedSubgraph) {
		const { id, name } = exportedSubgraph;
		const nodeDef = {
			input: { required: {} },
			output: [],
			output_is_list: [],
			output_name: [],
			output_tooltips: [],
			name: id,
			display_name: name,
			description: exportedSubgraph.description || `Subgraph node for ${name}`,
			category: "subgraph",
			output_node: false,
			python_module: "nodes"
		};
		nodeDefStore.addNodeDef(nodeDef);
		return nodeDef;
	}
	/** Loads all exported subgraph definitions from workflow */
	function loadSubgraphs(graphData) {
		const subgraphs = graphData.definitions?.subgraphs;
		if (!subgraphs) return;
		const normalized = normalizeSubgraphDefinitionIds(subgraphs, graphData.nodes);
		graphData.definitions.subgraphs = normalized.subgraphs;
		if (normalized.rootNodes) graphData.nodes = normalized.rootNodes;
		const exportedSubgraphs = normalized.subgraphs;
		const missingSubgraphs = exportedSubgraphs.filter(({ id }) => !useApp().rootGraph.subgraphs.has(id));
		const createdSubgraphs = useApp().rootGraph.createSubgraphs(missingSubgraphs);
		const loadedSubgraphs = new Map(useApp().rootGraph.subgraphs);
		for (const [index, data] of missingSubgraphs.entries()) loadedSubgraphs.set(data.id, createdSubgraphs[index]);
		for (const subgraphData of exportedSubgraphs) {
			const subgraph = loadedSubgraphs.get(subgraphData.id);
			if (!subgraph) continue;
			registerNewSubgraph(subgraph, subgraphData);
		}
	}
	/** Registers a new subgraph (e.g. user converted from nodes) */
	function registerNewSubgraph(subgraph, exportedSubgraph) {
		registerLitegraphNode(createNodeDef(exportedSubgraph), subgraph, exportedSubgraph);
	}
	return {
		loadSubgraphs,
		registerNewSubgraph
	};
};
//#endregion
//#region src/platform/auth/partnerNode/partnerNodeQueueToken.ts
/**
* Who mints for `workspaceId`: a signed-in host session with its OAuth access
* token for that workspace, else the Firebase user with its ID token.
*/
function mintTarget(workspaceId) {
	const hostUser = desktopHostUser.value;
	if (hostUser) return {
		ownerUid: hostUser.id,
		workspaceId,
		credential: () => desktopHostWorkspaceToken(workspaceId)
	};
	const authStore = useAuthStore();
	const ownerUid = authStore.currentUser?.uid;
	if (!ownerUid) return void 0;
	return {
		ownerUid,
		workspaceId,
		credential: () => authStore.getIdToken()
	};
}
/**
* The credential a Local prompt carries in `auth_token_comfy_org`: a
* partner-node token for the workspace when the flag is on and the mint
* succeeds, otherwise the workspace token unchanged.
*/
async function queueAuthToken(workspaceToken, workspaceId) {
	if (!workspaceToken || !workspaceId || false) return workspaceToken;
	if (!useFeatureFlags().flags.partnerNodeTokenEnabled) return workspaceToken;
	const target = mintTarget(workspaceId);
	if (!target) return workspaceToken;
	return await partnerNodeTokens.tokenFor(target) ?? workspaceToken;
}
//#endregion
//#region src/renderer/core/canvas/interaction/canvasInteractionMode.ts
function createCanvasInteractionMode() {
	const canvasStore = useCanvasStore();
	return { isSelectOnly: () => canvasStore.isPickingNodes };
}
//#endregion
//#region src/platform/workflowErrors/nodeReplacement/nodeReplacementService.ts
async function fetchNodeReplacements() {
	const response = await api.fetchApi("/node_replacements");
	if (!response.ok) throw new Error(`Failed to fetch node replacements: ${response.status} ${response.statusText}`);
	return response.json();
}
//#endregion
//#region src/platform/workflowErrors/nodeReplacement/nodeReplacementStore.ts
var useNodeReplacementStore = defineStore("nodeReplacement", () => {
	const settingStore = useSettingStore();
	const replacements = ref({});
	const isLoaded = ref(false);
	const isEnabled = computed(() => settingStore.get("Comfy.NodeReplacement.Enabled"));
	async function load() {
		if (!isEnabled.value || isLoaded.value) return;
		if (!hasNodeReplacementFeature()) return;
		try {
			replacements.value = await fetchNodeReplacements();
			isLoaded.value = true;
		} catch (error) {
			console.error("Failed to load node replacements:", error);
		}
	}
	function hasNodeReplacementFeature() {
		return api.getServerFeature(ServerFeatureFlag.NODE_REPLACEMENTS, false);
	}
	function getReplacementFor(nodeType) {
		if (!isEnabled.value) return null;
		return replacements.value[nodeType]?.[0] ?? null;
	}
	function hasReplacement(nodeType) {
		if (!isEnabled.value) return false;
		return !!replacements.value[nodeType]?.length;
	}
	return {
		replacements,
		isLoaded,
		isEnabled,
		load,
		getReplacementFor,
		hasReplacement
	};
});
//#endregion
//#region src/utils/executionUtil.ts
function isExportedWidgetValueWrapper(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value) && "__value__" in value;
}
/**
* Inverse of the wrapping applied during Export (API). Curve values carry a
* type marker and may be objects; untyped wrappers are reserved for arrays so
* ordinary objects containing a `__value__` property pass through unchanged.
*/
function unwrapExportedWidgetValue(value) {
	if (isExportedWidgetValueWrapper(value) && (value.__type__ === "CURVE" || Array.isArray(value.__value__))) return value.__value__;
	return value;
}
/**
* Converts the current graph workflow for sending to the API.
* @note Node widgets are updated before serialization to prepare queueing.
*
* @param graph The graph to convert.
* @param options The options for the conversion.
*  - `sortNodes`: Whether to sort the nodes by execution order.
* @returns The workflow and node links
*/
var graphToPrompt = async (graph, options = {}) => {
	const { sortNodes = false } = options;
	for (const node of graph.computeExecutionOrder(false)) {
		const innerNodes = node.getInnerNodes ? node.getInnerNodes(/* @__PURE__ */ new Map()) : [node];
		for (const innerNode of innerNodes) if (innerNode.isVirtualNode) innerNode.applyToGraph?.();
	}
	const workflow = graph.serialize({ sortNodes });
	for (const node of workflow.nodes) {
		for (const slot of node.inputs ?? []) delete slot.localized_name;
		for (const slot of node.outputs ?? []) delete slot.localized_name;
	}
	compressWidgetInputSlots(workflow);
	workflow.extra ??= {};
	workflow.extra.frontendVersion = "1.59.1";
	const nodeDtoMap = /* @__PURE__ */ new Map();
	for (const node of graph.computeExecutionOrder(false)) {
		const dto = new ExecutableNodeDTO(node, [], nodeDtoMap);
		nodeDtoMap.set(dto.id, dto);
		if (node.mode === LGraphEventMode.NEVER || node.mode === LGraphEventMode.BYPASS) continue;
		for (const innerNode of dto.getInnerNodes()) nodeDtoMap.set(innerNode.id, innerNode);
	}
	const output = {};
	for (const node of nodeDtoMap.values()) {
		if (node.isVirtualNode || node.mode === LGraphEventMode.NEVER || node.mode === LGraphEventMode.BYPASS) continue;
		const inputs = {};
		const { widgets } = node;
		if (widgets) for (const [i, widget] of widgets.entries()) {
			if (!widget.name || widget.options.serialize === false) continue;
			const widgetValue = widget.serializeValue ? await widget.serializeValue(node, i) : widget.value;
			inputs[widget.name] = widget.type === "curve" && widgetValue != null ? {
				__type__: "CURVE",
				__value__: widgetValue
			} : Array.isArray(widgetValue) ? { __value__: widgetValue } : widgetValue;
		}
		for (const [i, input] of node.inputs.entries()) {
			const resolvedInput = node.resolveInput(i);
			if (!resolvedInput) continue;
			if (resolvedInput.widgetInfo) {
				const { value } = resolvedInput.widgetInfo;
				inputs[input.name] = Array.isArray(value) ? { __value__: value } : value;
				continue;
			}
			inputs[input.name] = [resolvedInput.origin_id, resolvedInput.origin_slot];
		}
		const cnrId = zNodePackMetadata.shape.cnr_id.safeParse(node.properties.cnr_id).data;
		const auxId = zNodePackMetadata.shape.aux_id.safeParse(node.properties.aux_id).data;
		const packVersion = zNodePackMetadata.shape.ver.safeParse(node.properties.ver).data;
		output[node.id] = {
			inputs,
			class_type: node.comfyClass,
			_meta: {
				title: node.title,
				...cnrId && { cnr_id: cnrId },
				...auxId && { aux_id: auxId },
				...packVersion && { ver: packVersion }
			}
		};
	}
	for (const { inputs } of Object.values(output)) for (const [i, input] of Object.entries(inputs)) if (Array.isArray(input) && input.length === 2 && !Object.hasOwn(output, input[0])) delete inputs[i];
	return {
		workflow,
		output
	};
};
//#endregion
//#region src/utils/jsonUtil.ts
/**
* Parse JSON that may contain bare `NaN`/`Infinity`/`-Infinity` tokens
* (which Python's `json.dumps` emits) by replacing them with `null` on
* fallback. Coercion is lossy; a one-time warning is logged when it fires.
*/
function parseJsonWithNonFinite(text) {
	try {
		return JSON.parse(text);
	} catch {
		return JSON.parse(replaceNonFiniteTokens(text));
	}
}
var NON_FINITE_TOKEN = /"(?:\\.|[^"\\])*"|(?<![\w.-])(-?Infinity|NaN)(?![\w.])/g;
function replaceNonFiniteTokens(text) {
	let hasWarned = false;
	return text.replace(NON_FINITE_TOKEN, (match, token) => {
		if (token) {
			if (!hasWarned) {
				console.warn("JSON contained non-finite numeric tokens (NaN/Infinity); they were replaced with null.");
				hasWarned = true;
			}
			return "null";
		}
		return match;
	});
}
//#endregion
//#region src/platform/workflowErrors/nodeReplacement/missingNodeScan.ts
/** Scan the live graph for unregistered node types and build a full MissingNodeType list. */
function scanMissingNodes(rootGraph) {
	const nodeReplacementStore = useNodeReplacementStore();
	const missingNodeTypes = [];
	const allNodes = collectAllNodes(rootGraph);
	for (const node of allNodes) {
		if (node.mode === LGraphEventMode.NEVER || node.mode === LGraphEventMode.BYPASS) continue;
		const originalType = node.last_serialization?.type ?? node.type;
		if (originalType in LiteGraph.registered_node_types) continue;
		const cnrId = getCnrIdFromNode(node);
		const replacement = nodeReplacementStore.getReplacementFor(originalType);
		const executionId = getExecutionIdByNode(rootGraph, node);
		missingNodeTypes.push({
			type: originalType,
			nodeId: executionId ?? String(node.id),
			cnrId,
			isReplaceable: replacement !== null,
			replacement: replacement ?? void 0
		});
	}
	return missingNodeTypes;
}
/** Re-scan the graph for missing nodes and update the error store. */
function rescanAndSurfaceMissingNodes(rootGraph) {
	const types = scanMissingNodes(rootGraph);
	if (useMissingNodesErrorStore().surfaceMissingNodes(types)) useExecutionErrorStore().showErrorOverlay();
}
//#endregion
//#region src/platform/workspace/composables/waitForDeploymentPick.ts
function bootHint() {
	if (hasDeploymentLink()) return "deployment";
	return readDeploymentHint(useTeamWorkspaceStore().workspaceId);
}
/** Whether this page may boot on a deployment: the boot listing's answer, else false only for a confirmed Comfy Cloud hint. */
function couldBootOnDeployment() {
	const { bootDeployment } = useDeploymentPickStore();
	if (bootDeployment !== void 0) return bootDeployment !== null;
	return bootHint() !== "cloud";
}
function listingWaitMs(hint) {
	if (hint === "deployment") return DEPLOYMENT_LISTING_BACKSTOP_MS;
	if (hint === "unconfirmed") return 0;
	return DEPLOYMENT_LISTING_NO_HINT_WAIT_MS;
}
/** Waits for the boot listing to say where this page runs; `onLateDeployment` runs if a late listing names a deployment. */
async function waitForDeploymentPick(onLateDeployment = () => {}) {
	const store = useDeploymentPickStore();
	const hint = bootHint();
	if (!couldBootOnDeployment()) {
		store.bootOnComfyCloud();
		return true;
	}
	const listing = store.loadOnce();
	let timeout;
	try {
		if (await Promise.race([listing.then(() => store.bootDeployment !== void 0), new Promise((resolve) => {
			timeout = setTimeout(() => resolve(false), listingWaitMs(hint));
		})])) return true;
		store.bootOnComfyCloud();
		if (hint === "deployment") return false;
		listing.then(() => {
			if (store.pickedDeployment !== null) onLateDeployment();
		});
		return true;
	} finally {
		clearTimeout(timeout);
	}
}
/**
* `releaseModelOptions` on Comfy Cloud unless this page is known to boot on
* Comfy Cloud's own models (`couldBootOnDeployment`), undefined elsewhere
* so a scan never waits on the listing.
*/
function cloudReleaseModelOptions() {}
//#endregion
//#region src/platform/workflowErrors/missingModel/missingModelPipeline.ts
function cacheModelCandidates(wf, confirmed) {
	if (!wf) return;
	updatePendingWarnings(wf, { missingModelCandidates: confirmed });
}
function clearMissingModels(wf, silent) {
	useExecutionErrorStore().surfaceMissingModels([], { silent });
	cacheModelCandidates(wf, []);
}
function hasDownloadMetadata(candidate) {
	return !!candidate.url && !!candidate.directory;
}
function toModelFile(candidate) {
	return {
		name: candidate.name,
		url: candidate.url,
		directory: candidate.directory,
		hash: candidate.hash,
		hash_type: candidate.hashType
	};
}
function getCurrentMissingModelMetadata(missingModelStore) {
	return missingModelStore.missingModelCandidates?.filter(hasDownloadMetadata).map(toModelFile) ?? [];
}
async function runMissingModelPipeline({ graph, graphData, missingModelStore, missingNodeTypes, silent = false, onVerified }) {
	const controller = missingModelStore.createVerificationAbortController();
	const getDirectory = (nodeType) => useModelToNodeStore().getCategoryForNodeType(nodeType);
	const isAssetBrowserWidget = assetService.shouldUseWidgetAssetPicker;
	const candidates = scanAllModelCandidates(graph, isAssetBrowserWidget, getDirectory, void 0);
	const enrichedCandidates = enrichWithEmbeddedMetadata(candidates, graphData).filter((c) => isCandidateScopeActive(graph, c));
	const confirmedCandidates = enrichedCandidates.filter((c) => c.isMissing === true);
	const hasDeferredCandidates = enrichedCandidates.some(hasPendingVerification);
	const missingModels = confirmedCandidates.filter(hasDownloadMetadata).map(toModelFile);
	const activeWf = useWorkspaceStore().workflow.activeWorkflow;
	updatePendingWarnings(activeWf, {
		...missingNodeTypes ? { missingNodeTypes } : {},
		missingModelCandidates: confirmedCandidates
	});
	if (!enrichedCandidates.length) {
		clearMissingModels(activeWf, silent);
		onVerified?.([]);
		return {
			missingModels,
			confirmedCandidates
		};
	}
	const isStillSelected = (candidate) => {
		if (candidate.nodeId == null) return true;
		return (getNodeByExecutionId(graph, String(candidate.nodeId))?.widgets?.find((w) => w.name === candidate.widgetName))?.value === candidate.name;
	};
	const surfaceActiveCandidates = () => {
		const confirmed = enrichedCandidates.filter((c) => isMissingCandidateActive(graph, c) && isStillSelected(c));
		useExecutionErrorStore().surfaceMissingModels(confirmed, { silent });
		cacheModelCandidates(activeWf, confirmed);
		onVerified?.(enrichedCandidates.filter((c) => isCandidateScopeActive(graph, c) && isStillSelected(c)));
	};
	const reportVerificationFailure = (err) => {
		if (controller.signal.aborted) return;
		console.warn("[Missing Model Pipeline] Missing model verification failed:", err);
		reportError(err, {
			surface: "assets",
			errorType: "missing_model_verification_failed"
		});
		useToast().warning(st("toastMessages.missingModelVerificationFailed", "Failed to verify missing models. Some models may not be shown in the Issues tab."), { duration: 5e3 });
	};
	if (!confirmedCandidates.length && !hasDeferredCandidates) {
		surfaceActiveCandidates();
		return {
			missingModels,
			confirmedCandidates
		};
	}
	(hasDeferredCandidates ? verifyAssetSupportedCandidates(enrichedCandidates, controller.signal) : Promise.resolve()).then(async () => {
		if (controller.signal.aborted) return;
		if (!enrichedCandidates.some((c) => isMissingCandidateActive(graph, c))) {
			surfaceActiveCandidates();
			return;
		}
		const verifiedDownloadableCandidates = enrichedCandidates.filter((c) => c.isMissing === true).filter(hasDownloadMetadata);
		const missingModelMetadata = __vitePreload(() => import("./missingModelMetadata-DQjewTyg.js"), __vite__mapDeps([3,4,1,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29]), import.meta.url);
		Promise.allSettled(verifiedDownloadableCandidates.map(async (c) => {
			const { fetchAndStoreModelMetadata } = await missingModelMetadata;
			await fetchAndStoreModelMetadata(c.url, missingModelStore, controller.signal);
		}));
		await api.getFolderPaths().then((paths) => {
			if (controller.signal.aborted) return;
			missingModelStore.setFolderPaths(paths);
		}).catch((err) => {
			console.warn("[Missing Model Pipeline] Failed to fetch folder paths:", err);
		}).finally(() => {
			if (controller.signal.aborted) return;
			surfaceActiveCandidates();
		});
	}).catch(reportVerificationFailure);
	return {
		missingModels,
		confirmedCandidates
	};
}
async function refreshMissingModelPipeline({ graph, reloadNodeDefs, missingModelStore, silent = true }) {
	await reloadNodeDefs?.();
	const graphData = graph.serialize();
	const activeWorkflowState = useWorkspaceStore().workflow.activeWorkflow?.activeState;
	const currentModelMetadata = getCurrentMissingModelMetadata(missingModelStore);
	const models = activeWorkflowState?.models?.length ? activeWorkflowState.models : currentModelMetadata;
	return runMissingModelPipeline({
		graph,
		graphData: models.length ? {
			...graphData,
			models
		} : graphData,
		missingModelStore,
		silent
	});
}
//#endregion
//#region src/platform/workflowErrors/missingMedia/missingMediaScan.ts
function isComboWidget(widget) {
	return widget.type === "combo";
}
/** The widget a user can actually edit. */
function isEditableValueOwner(node, widget) {
	const input = node.getSlotFromWidget(widget);
	if (input?.link != null) return false;
	if (!node.isSubgraphNode()) return true;
	return !!input?.widgetId && hasActivePromotedWidgetConsumer(node, input.name);
}
function mediaTypeFromSpec(spec) {
	if (!spec || !isComboInputSpec(spec)) return void 0;
	if (spec.video_upload) return "video";
	if (spec.image_upload || spec.animated_image_upload) return "image";
	if (spec.audio_upload) return "audio";
}
/**
* Scan combo widgets on media nodes for file values that may be missing.
*
* With the asset API enabled, `isMissing` is left `undefined` so
* `verifyMediaCandidates` resolves it against the asset listing on every
* backend. Without it, `isMissing` is resolved immediately from widget
* options unless an output annotation needs generated-history verification.
*/
function scanAllMediaCandidates(rootGraph) {
	const allNodes = collectAllNodes(rootGraph);
	const candidates = [];
	for (const node of allNodes) {
		if (!node.widgets?.length) continue;
		if (node.mode === LGraphEventMode.NEVER || node.mode === LGraphEventMode.BYPASS) continue;
		candidates.push(...scanNodeMediaCandidates(rootGraph, node));
	}
	return candidates;
}
function resolveMediaMissingState(widget, value) {
	if (useFeatureFlags().flags.assetsEnabled) return void 0;
	const options = resolveComboValues(widget);
	const { filepath, rootFolder } = parseAnnotatedPath(value);
	if (rootFolder !== "input") return options.includes(value) ? false : void 0;
	return !options.includes(value) && !options.includes(filepath);
}
/** Scan media; includeTemp is only for known deletions, not verification. */
function scanNodeMediaCandidates(rootGraph, node, { includeTemp = false } = {}) {
	if (!node.widgets?.length) return [];
	const executionId = getExecutionIdByNode(rootGraph, node);
	if (!executionId) return [];
	if (node.isUploading) return [];
	const nodeDefStore = useNodeDefStore();
	const candidates = [];
	for (const widget of node.widgets) {
		if (!isComboWidget(widget)) continue;
		const mediaType = mediaTypeFromSpec(nodeDefStore.getInputSpecForWidget(node, widget.name));
		if (!mediaType) continue;
		if (!isEditableValueOwner(node, widget)) continue;
		const value = widget.value;
		if (typeof value !== "string" || !value.trim()) continue;
		if (!includeTemp && parseAnnotatedPath(value).rootFolder === "temp") continue;
		const isMissing = resolveMediaMissingState(widget, value);
		const candidate = {
			nodeId: executionId,
			nodeType: (resolvePromotedWidgetSource(rootGraph, node, widget)?.sourceNode ?? node).type,
			widgetName: widget.name,
			mediaType,
			name: value,
			isMissing
		};
		if (node.isSubgraphNode()) {
			const consumers = resolveActivePromotedWidgetConsumers(node, widget.name);
			candidate.promotedSources = buildPromotedWidgetExecutionSources(executionId, consumers);
		}
		candidates.push(candidate);
	}
	return candidates;
}
function isMissingMediaCandidateScopeActive(rootGraph, candidate) {
	if (!rootGraph) return false;
	const executionId = String(candidate.nodeId);
	if (!isExecutionPathActive(rootGraph, executionId)) return false;
	const node = getNodeByExecutionId(rootGraph, executionId);
	if (!node) return false;
	const widget = node.widgets?.find((candidateWidget) => candidateWidget.name === candidate.widgetName);
	if (!widget) return false;
	return widget.value === candidate.name && isEditableValueOwner(node, widget);
}
function isMissingMediaCandidateActive(rootGraph, candidate) {
	return candidate.isMissing === true && isMissingMediaCandidateScopeActive(rootGraph, candidate);
}
/** Resolve pending candidates against the asset store, then a remote hash lookup when assets are enabled. */
async function verifyMediaCandidates(candidates, { signal } = {}) {
	if (signal?.aborted) return;
	const pending = candidates.filter((c) => c.isMissing === void 0);
	const firstRejection = (await Promise.allSettled(Object.entries(groupBy(pending, (p) => p.name)).map(async ([name, candidates]) => {
		const asset = await resolveWidgetValueAsset(name, { signal });
		const isMissing = asset === void 0 ? void 0 : asset === null;
		for (const candidate of candidates) candidate.isMissing = isMissing;
	}))).find((r) => r.status === "rejected");
	if (firstRejection && !signal?.aborted) throw firstRejection.reason;
}
/** Group confirmed-missing candidates by file name into view models. */
function groupCandidatesByName(candidates) {
	const map = /* @__PURE__ */ new Map();
	for (const c of candidates) {
		const existing = map.get(c.name);
		if (existing) existing.referencingNodes.push({
			nodeId: c.nodeId,
			nodeType: c.nodeType,
			widgetName: c.widgetName
		});
		else map.set(c.name, {
			name: c.name,
			mediaType: c.mediaType,
			representative: c,
			referencingNodes: [{
				nodeId: c.nodeId,
				nodeType: c.nodeType,
				widgetName: c.widgetName
			}]
		});
	}
	return Array.from(map.values());
}
/** Group confirmed-missing candidates by media type. */
function groupCandidatesByMediaType(candidates) {
	const grouped = groupBy(candidates, (c) => c.mediaType);
	return [
		"image",
		"video",
		"audio"
	].filter((t) => t in grouped).map((mediaType) => ({
		mediaType,
		items: groupCandidatesByName(grouped[mediaType])
	}));
}
//#endregion
//#region src/platform/workflowErrors/missingMedia/missingMediaPipeline.ts
function cacheMediaCandidates(wf, confirmed) {
	if (!wf) return;
	updatePendingWarnings(wf, { missingMediaCandidates: confirmed });
}
async function runMissingMediaPipeline({ rootGraph, silent = false, onVerified }) {
	const missingMediaStore = useMissingMediaStore();
	const activeWf = useWorkspaceStore().workflow.activeWorkflow;
	const candidates = scanAllMediaCandidates(rootGraph).filter((candidate) => isMissingMediaCandidateScopeActive(rootGraph, candidate));
	if (!candidates.length) {
		cacheMediaCandidates(activeWf, []);
		onVerified?.([]);
		return;
	}
	if (candidates.some((c) => c.isMissing === void 0)) {
		const controller = missingMediaStore.createVerificationAbortController();
		verifyMediaCandidates(candidates, { signal: controller.signal }).then(() => {
			if (controller.signal.aborted) return;
			const confirmed = candidates.filter((candidate) => isMissingMediaCandidateActive(rootGraph, candidate));
			if (confirmed.length) useExecutionErrorStore().surfaceMissingMedia(confirmed, { silent });
			cacheMediaCandidates(activeWf, confirmed);
			onVerified?.(candidates.filter((candidate) => isMissingMediaCandidateScopeActive(rootGraph, candidate)));
		}).catch((err) => {
			console.warn("[Missing Media Pipeline] Asset verification failed:", err);
			useToast().warning(st("toastMessages.missingMediaVerificationFailed", "Failed to verify missing media. Some inputs may not be shown in the Issues tab."), { duration: 5e3 });
		});
	} else {
		const confirmed = candidates.filter((c) => c.isMissing === true);
		useExecutionErrorStore().surfaceMissingMedia(confirmed, { silent });
		cacheMediaCandidates(activeWf, confirmed);
		onVerified?.(candidates);
	}
}
//#endregion
//#region src/renderer/extensions/vueNodes/composables/useNodeZIndex.ts
function useNodeZIndex() {
	const layoutMutations = useLayoutMutations(LayoutSource.Vue);
	const canvasStore = useCanvasStore();
	function bringNodeToFront(nodeId) {
		const { currentGraph } = canvasStore;
		if (!currentGraph) return;
		layoutMutations.setNodeOrder(currentGraph, nodeId, "front");
	}
	return { bringNodeToFront };
}
//#endregion
//#region src/utils/createNode.ts
/**
* Extract & Promisify Litegraph.createNode to allow for positioning
* @param canvas
* @param name
*/
async function createNode(canvas, name) {
	if (!name) return null;
	if (isSelectOnly(canvas)) return null;
	const { graph, graph_mouse: [posX, posY] } = canvas;
	const newNode = LiteGraph.createNode(name);
	await new Promise((r) => setTimeout(r, 0));
	if (newNode && graph) {
		newNode.pos = [posX, posY];
		const addedNode = graph.add(newNode) ?? null;
		if (addedNode) {
			useNodeZIndex().bringNodeToFront(addedNode.id);
			graph.change();
		}
		return addedNode;
	} else {
		useToast().warning(t("assetBrowser.failedToCreateNode"));
		return null;
	}
}
//#endregion
//#region src/utils/migration/migrateReroute.ts
/**
* Identifies all legacy Reroute nodes in a workflow
*/
function findLegacyRerouteNodes(workflow) {
	return workflow.nodes.filter((node) => node.type === "Reroute");
}
/**
* Checks if the workflow has no native reroutes
*/
function noNativeReroutes(workflow) {
	return !workflow.extra?.reroutes?.length && !workflow.extra?.linkExtensions?.length;
}
/**
* Gets the center position of a node
*/
function getNodeCenter(node) {
	return [node.pos[0] + node.size[0] / 2, node.pos[1] + node.size[1] / 2];
}
var ConversionContext = class {
	workflow;
	nodeById;
	linkById;
	rerouteById;
	rerouteByNodeId;
	linkExtensions;
	/** Reroutes that has at least a valid link pass through it */
	validReroutes;
	_rerouteIdCounter = 0;
	constructor(workflow) {
		this.workflow = workflow;
		this.nodeById = keyBy(workflow.nodes.map(cloneDeep), "id");
		this.linkById = keyBy(workflow.links.map((l) => ({
			id: l[0],
			origin_id: l[1],
			origin_slot: l[2],
			target_id: l[3],
			target_slot: l[4],
			type: l[5]
		})), "id");
		const reroutes = findLegacyRerouteNodes(workflow).map((node, index) => ({
			nodeId: node.id,
			id: index + 1,
			pos: getNodeCenter(node),
			linkIds: []
		}));
		this._rerouteIdCounter = reroutes.length + 1;
		this.rerouteByNodeId = keyBy(reroutes, "nodeId");
		this.rerouteById = keyBy(reroutes, "id");
		this.linkExtensions = [];
		this.validReroutes = /* @__PURE__ */ new Set();
	}
	/**
	* Gets the chain of reroute nodes leading to the given node
	*/
	_getRerouteChain(node) {
		const nodes = [];
		let currentNode = node;
		while (currentNode?.type === "Reroute") {
			nodes.push(currentNode);
			const linkId = currentNode.inputs?.[0]?.link ?? 0;
			const inputLink = Object.hasOwn(this.linkById, linkId) ? this.linkById[linkId] : void 0;
			if (!inputLink) break;
			currentNode = this.nodeById[inputLink.origin_id];
		}
		return nodes;
	}
	_connectRerouteChain(rerouteNodes) {
		const reroutes = rerouteNodes.map((node) => this.rerouteByNodeId[node.id]);
		for (const reroute of reroutes) this.validReroutes.add(reroute);
		for (let i = 0; i < rerouteNodes.length - 1; i++) {
			const to = reroutes[i];
			to.parentId = reroutes[i + 1].id;
		}
		return reroutes;
	}
	_createNewLink(startingLink, endingLink, rerouteNodes) {
		if (rerouteNodes.length === 0) throw new Error("No reroute nodes found");
		const reroute = this.rerouteByNodeId[rerouteNodes[0].id];
		this.linkExtensions.push({
			id: endingLink.id,
			parentId: reroute.id
		});
		const reroutes = this._connectRerouteChain(rerouteNodes);
		for (const reroute of reroutes) {
			reroute.linkIds ??= [];
			reroute.linkIds.push(endingLink.id);
			delete reroute.floating;
		}
		return {
			id: endingLink.id,
			origin_id: startingLink.origin_id,
			origin_slot: startingLink.origin_slot,
			target_id: endingLink.target_id,
			target_slot: endingLink.target_slot,
			type: endingLink.type
		};
	}
	_createNewInputFloatingLink(endingLink, rerouteNodes) {
		const reroutes = this._connectRerouteChain(rerouteNodes);
		for (const reroute of reroutes) if (!reroute.linkIds?.length) reroute.floating = { slotType: "input" };
		return {
			id: this._rerouteIdCounter++,
			origin_id: -1,
			origin_slot: -1,
			target_id: endingLink.target_id,
			target_slot: endingLink.target_slot,
			type: endingLink.type,
			parentId: reroutes[0].id
		};
	}
	_createNewOutputFloatingLink(startingLink, rerouteNodes) {
		const reroutes = this._connectRerouteChain(rerouteNodes);
		for (const reroute of reroutes) if (!reroute.linkIds?.length) reroute.floating = { slotType: "output" };
		return {
			id: this._rerouteIdCounter++,
			origin_id: startingLink.origin_id,
			origin_slot: startingLink.origin_slot,
			target_id: -1,
			target_slot: -1,
			type: startingLink.type,
			parentId: reroutes[0].id
		};
	}
	_reconnectLinks(nodes, links) {
		for (const node of nodes) {
			for (const input of node.inputs ?? []) input.link = null;
			for (const output of node.outputs ?? []) output.links = [];
		}
		const nodesById = keyBy(nodes, "id");
		for (const link of links) {
			nodesById[link.origin_id].outputs[link.origin_slot].links.push(link.id);
			const targetNode = nodesById[link.target_id];
			targetNode.inputs[link.target_slot].link = link.id;
		}
	}
	migrateReroutes() {
		const links = [];
		const floatingLinks = [];
		const endingLinks = [];
		for (const link of Object.values(this.linkById)) {
			const sourceIsReroute = Boolean(this.rerouteByNodeId[link.origin_id]);
			const targetIsReroute = Boolean(this.rerouteByNodeId[link.target_id]);
			if (!sourceIsReroute && !targetIsReroute) links.push(link);
			else if (sourceIsReroute && !targetIsReroute) endingLinks.push(link);
		}
		for (const endingLink of endingLinks) {
			const endingRerouteNode = this.nodeById[endingLink.origin_id];
			const rerouteNodes = this._getRerouteChain(endingRerouteNode);
			const startingLinkId = rerouteNodes[rerouteNodes.length - 1]?.inputs?.[0]?.link ?? -1;
			if (Object.hasOwn(this.linkById, startingLinkId)) {
				const startingLink = this.linkById[startingLinkId];
				links.push(this._createNewLink(startingLink, endingLink, rerouteNodes));
			} else floatingLinks.push(this._createNewInputFloatingLink(endingLink, rerouteNodes));
		}
		const floatingEndingRerouteNodes = Object.keys(this.rerouteByNodeId).map((nodeId) => this.nodeById[nodeId]).filter((rerouteNode) => {
			const output = rerouteNode.outputs?.[0];
			if (!output) return false;
			return !output.links?.length;
		});
		for (const rerouteNode of floatingEndingRerouteNodes) {
			const rerouteNodes = this._getRerouteChain(rerouteNode);
			const startingLinkId = rerouteNodes[rerouteNodes.length - 1]?.inputs?.[0]?.link ?? -1;
			if (Object.hasOwn(this.linkById, startingLinkId)) {
				const startingLink = this.linkById[startingLinkId];
				floatingLinks.push(this._createNewOutputFloatingLink(startingLink, rerouteNodes));
			}
		}
		const nodes = Object.values(this.nodeById).filter((node) => node.type !== "Reroute");
		this._reconnectLinks(nodes, links);
		return {
			...this.workflow,
			nodes,
			links: links.map((link) => [
				link.id,
				link.origin_id,
				link.origin_slot,
				link.target_id,
				link.target_slot,
				link.type
			]),
			floatingLinks: floatingLinks.length > 0 ? floatingLinks : void 0,
			extra: {
				...this.workflow.extra,
				reroutes: Array.from(this.validReroutes).map((reroute) => omit(reroute, "nodeId")),
				linkExtensions: this.linkExtensions
			}
		};
	}
};
/**
* Main function to migrate legacy reroute nodes to native reroute points
*/
var migrateLegacyRerouteNodes = (workflow) => {
	if (findLegacyRerouteNodes(workflow).length === 0) return workflow;
	const newWorkflow = JSON.parse(JSON.stringify(workflow));
	if (!newWorkflow.extra) newWorkflow.extra = {};
	return new ConversionContext(newWorkflow).migrateReroutes();
};
//#endregion
//#region src/utils/vintageClipboard.ts
/**
* Deserialises nodes and links using a modified version of the old Litegraph (copy &) paste function
* @param data The serialised nodes and links to create
* @param canvas The canvas to create the serialised items in
*/
function deserialiseAndCreate(data, canvas) {
	if (!data) return;
	const { graph, graph_mouse } = canvas;
	if (!graph) return;
	canvas.emitBeforeChange();
	try {
		graph.beforeChange();
		const deserialised = JSON.parse(data);
		const topLeft = [Infinity, Infinity];
		for (const { pos } of deserialised.nodes) {
			if (topLeft[0] > pos[0]) topLeft[0] = pos[0];
			if (topLeft[1] > pos[1]) topLeft[1] = pos[1];
		}
		if (!Number.isFinite(topLeft[0]) || !Number.isFinite(topLeft[1])) {
			topLeft[0] = graph_mouse[0];
			topLeft[1] = graph_mouse[1];
		}
		const nodes = [];
		for (const info of deserialised.nodes) {
			const node = LiteGraph.createNode(info.type);
			if (!node) continue;
			node.configure(info);
			node.pos = [node.pos[0] + graph_mouse[0] - topLeft[0], node.pos[1] + graph_mouse[1] - topLeft[1]];
			withNodeAddSource("paste", () => graph.add(node, true));
			nodes.push(node);
		}
		for (const info of deserialised.links) {
			const relativeId = info[0];
			const outNode = relativeId != null ? nodes[relativeId] : void 0;
			const inNode = nodes[info[2]];
			if (outNode) outNode.connect(info[1], inNode, info[3]);
			else console.warn("Warning, nodes missing on pasting");
		}
		canvas.selectNodes(nodes);
		graph.afterChange();
	} finally {
		canvas.emitAfterChange();
	}
}
//#endregion
//#region src/types/metadataTypes.ts
/**
* Tag names used in ComfyUI metadata
*/
var ComfyMetadataTags = /* @__PURE__ */ function(ComfyMetadataTags) {
	ComfyMetadataTags["PROMPT"] = "PROMPT";
	ComfyMetadataTags["WORKFLOW"] = "WORKFLOW";
	return ComfyMetadataTags;
}({});
var ASCII$1 = /* @__PURE__ */ function(ASCII) {
	ASCII[ASCII["GLTF"] = 1179937895] = "GLTF";
	ASCII[ASCII["JSON"] = 1313821514] = "JSON";
	ASCII[ASCII["OPEN_BRACE"] = 123] = "OPEN_BRACE";
	return ASCII;
}({});
var GltfSizeBytes = /* @__PURE__ */ function(GltfSizeBytes) {
	GltfSizeBytes[GltfSizeBytes["HEADER"] = 12] = "HEADER";
	GltfSizeBytes[GltfSizeBytes["CHUNK_HEADER"] = 8] = "CHUNK_HEADER";
	return GltfSizeBytes;
}({});
//#endregion
//#region src/utils/fileUtil.ts
/**
* Reads a file (optionally capped to its first `maxBytes`) into an ArrayBuffer.
* Resolves `null` when the read errors, aborts, or yields no result, so callers
* can guard with a single truthiness check before parsing. The underlying
* `FileReader` error reason is intentionally not surfaced; callers treat any
* failure as "no metadata" rather than distinguishing causes.
* @param file - The file to read.
* @param maxBytes - Optional cap; when set, only the first `maxBytes` are read.
*/
function readFileAsArrayBuffer(file, maxBytes) {
	return new Promise((resolve) => {
		const reader = new FileReader();
		reader.onload = () => {
			resolve(reader.result instanceof ArrayBuffer ? reader.result : null);
		};
		reader.onerror = () => resolve(null);
		reader.onabort = () => resolve(null);
		const blob = maxBytes === void 0 ? file : file.slice(0, maxBytes);
		reader.readAsArrayBuffer(blob);
	});
}
//#endregion
//#region src/scripts/metadata/avif.ts
var readNullTerminatedString = (dataView, start, end) => {
	let length = 0;
	while (start + length < end && dataView.getUint8(start + length) !== 0) length++;
	return {
		str: new TextDecoder("utf-8").decode(new Uint8Array(dataView.buffer, dataView.byteOffset + start, length)),
		length: length + 1
	};
};
var parseInfeBox = (dataView, start) => {
	const version = dataView.getUint8(start);
	const flags = dataView.getUint32(start) & 16777215;
	let offset = start + 4;
	let item_ID;
	let item_protection_index;
	let item_type;
	if (version >= 2) {
		if (version === 2) {
			item_ID = dataView.getUint16(offset);
			offset += 2;
		} else {
			item_ID = dataView.getUint32(offset);
			offset += 4;
		}
		item_protection_index = dataView.getUint16(offset);
		offset += 2;
		item_type = String.fromCharCode(...new Uint8Array(dataView.buffer, dataView.byteOffset + offset, 4));
		offset += 4;
		const { str: item_name, length: name_len } = readNullTerminatedString(dataView, offset, dataView.byteLength);
		offset += name_len;
		const content_type = readNullTerminatedString(dataView, offset, dataView.byteLength).str;
		return {
			box_header: {
				size: 0,
				type: "infe"
			},
			version,
			flags,
			item_ID,
			item_protection_index,
			item_type,
			item_name,
			content_type
		};
	}
	throw new Error(`Unsupported infe box version: ${version}`);
};
var parseIinfBox = (dataView, range) => {
	if (!range) throw new Error("iinf box not found");
	const version = dataView.getUint8(range.start);
	const flags = dataView.getUint32(range.start) & 16777215;
	let offset = range.start + 4;
	const entry_count = version === 0 ? dataView.getUint16(offset) : dataView.getUint32(offset);
	offset += version === 0 ? 2 : 4;
	const entries = [];
	for (let i = 0; i < entry_count; i++) {
		const boxSize = dataView.getUint32(offset);
		if (String.fromCharCode(...new Uint8Array(dataView.buffer, dataView.byteOffset + offset + 4, 4)) === "infe") {
			const infe = parseInfeBox(dataView, offset + 8);
			infe.box_header.size = boxSize;
			entries.push(infe);
		}
		offset += boxSize;
	}
	return {
		box_header: {
			size: range.end - range.start + 8,
			type: "iinf"
		},
		version,
		flags,
		entry_count,
		entries
	};
};
var parseIlocBox = (dataView, range) => {
	if (!range) throw new Error("iloc box not found");
	const version = dataView.getUint8(range.start);
	const flags = dataView.getUint32(range.start) & 16777215;
	let offset = range.start + 4;
	const sizes = dataView.getUint8(offset++);
	const offset_size = sizes >> 4 & 15;
	const length_size = sizes & 15;
	const base_offset_size = dataView.getUint8(offset) >> 4 & 15;
	const index_size = version === 1 || version === 2 ? dataView.getUint8(offset) & 15 : 0;
	offset++;
	const item_count = version < 2 ? dataView.getUint16(offset) : dataView.getUint32(offset);
	offset += version < 2 ? 2 : 4;
	const items = [];
	for (let i = 0; i < item_count; i++) {
		const item_ID = version < 2 ? dataView.getUint16(offset) : dataView.getUint32(offset);
		offset += version < 2 ? 2 : 4;
		if (version === 1 || version === 2) offset += 2;
		const data_reference_index = dataView.getUint16(offset);
		offset += 2;
		const base_offset = base_offset_size > 0 ? dataView.getUint32(offset) : 0;
		offset += base_offset_size;
		const extent_count = dataView.getUint16(offset);
		offset += 2;
		const extents = [];
		for (let j = 0; j < extent_count; j++) {
			if ((version === 1 || version === 2) && index_size > 0) offset += index_size;
			const extent_offset = dataView.getUint32(offset);
			offset += offset_size;
			const extent_length = dataView.getUint32(offset);
			offset += length_size;
			extents.push({
				extent_offset,
				extent_length
			});
		}
		items.push({
			item_ID,
			data_reference_index,
			base_offset,
			extent_count,
			extents
		});
	}
	return {
		box_header: {
			size: range.end - range.start + 8,
			type: "iloc"
		},
		version,
		flags,
		offset_size,
		length_size,
		base_offset_size,
		index_size,
		item_count,
		items
	};
};
function findBox(dataView, start, end, type) {
	let offset = start;
	while (offset < end) {
		if (offset + 8 > end) break;
		const boxLength = dataView.getUint32(offset);
		const boxType = String.fromCharCode(...new Uint8Array(dataView.buffer, dataView.byteOffset + offset + 4, 4));
		if (boxLength === 0) break;
		if (boxType === type) return {
			start: offset + 8,
			end: offset + boxLength
		};
		if (offset + boxLength > end) break;
		offset += boxLength;
	}
	return null;
}
function parseAvifMetadata(buffer) {
	const metadata = {};
	const dataView = new DataView(buffer);
	if (dataView.getUint32(4) !== 1718909296 || dataView.getUint32(8) !== 1635150182) {
		console.error("Not a valid AVIF file");
		return {};
	}
	const metaBox = findBox(dataView, 0, dataView.byteLength, "meta");
	if (!metaBox) return {};
	const metaBoxContentStart = metaBox.start + 4;
	const exifInfe = parseIinfBox(dataView, findBox(dataView, metaBoxContentStart, metaBox.end, "iinf")).entries.find((e) => e.item_type === "Exif");
	if (!exifInfe) return {};
	const exifIloc = parseIlocBox(dataView, findBox(dataView, metaBoxContentStart, metaBox.end, "iloc")).items.find((i) => i.item_ID === exifInfe.item_ID);
	if (!exifIloc || exifIloc.extents.length === 0) return {};
	const exifExtent = exifIloc.extents[0];
	const itemData = new Uint8Array(buffer, exifExtent.extent_offset, exifExtent.extent_length);
	let tiffHeaderOffset = -1;
	for (let i = 0; i < itemData.length - 4; i++) if (itemData[i] === 77 && itemData[i + 1] === 77 && itemData[i + 2] === 0 && itemData[i + 3] === 42 || itemData[i] === 73 && itemData[i + 1] === 73 && itemData[i + 2] === 42 && itemData[i + 3] === 0) {
		tiffHeaderOffset = i;
		break;
	}
	if (tiffHeaderOffset !== -1) {
		const data = parseExifData$1(itemData.subarray(tiffHeaderOffset));
		for (const key in data) {
			const value = data[key];
			if (typeof value === "string") {
				if (key === "usercomment") try {
					const metadataJson = parseJsonWithNonFinite(value);
					if (metadataJson.prompt) metadata[ComfyMetadataTags.PROMPT] = metadataJson.prompt;
					if (metadataJson.workflow) metadata[ComfyMetadataTags.WORKFLOW] = metadataJson.workflow;
				} catch (e) {
					console.error("Failed to parse usercomment JSON", e);
				}
				else {
					const [metadataKey, ...metadataValueParts] = value.split(":");
					const metadataValue = metadataValueParts.join(":").trim();
					if (metadataKey.toLowerCase() === ComfyMetadataTags.PROMPT.toLowerCase() || metadataKey.toLowerCase() === ComfyMetadataTags.WORKFLOW.toLowerCase()) try {
						const jsonValue = parseJsonWithNonFinite(metadataValue);
						metadata[metadataKey.toLowerCase()] = jsonValue;
					} catch (e) {
						console.error(`Failed to parse JSON for ${metadataKey}`, e);
					}
				}
			}
		}
	} else console.warn("TIFF header not found in EXIF data.");
	return metadata;
}
function parseExifData$1(exifData) {
	const isLittleEndian = String.fromCharCode(...exifData.slice(0, 2)) === "II";
	function readInt(offset, isLittleEndian, length) {
		const arr = exifData.slice(offset, offset + length);
		if (length === 2) return new DataView(arr.buffer, arr.byteOffset, arr.byteLength).getUint16(0, isLittleEndian);
		return new DataView(arr.buffer, arr.byteOffset, arr.byteLength).getUint32(0, isLittleEndian);
	}
	const ifdOffset = readInt(4, isLittleEndian, 4);
	function parseIFD(offset) {
		const numEntries = readInt(offset, isLittleEndian, 2);
		const result = {};
		for (let i = 0; i < numEntries; i++) {
			const entryOffset = offset + 2 + i * 12;
			const tag = readInt(entryOffset, isLittleEndian, 2);
			const type = readInt(entryOffset + 2, isLittleEndian, 2);
			const numValues = readInt(entryOffset + 4, isLittleEndian, 4);
			const valueOffset = readInt(entryOffset + 8, isLittleEndian, 4);
			let value;
			if (type === 2) value = new TextDecoder("utf-8").decode(exifData.subarray(valueOffset, valueOffset + numValues - 1));
			result[tag] = value;
		}
		return result;
	}
	return parseIFD(ifdOffset);
}
__name(parseExifData$1, "parseExifData");
async function getFromAvifFile(file) {
	const buffer = await readFileAsArrayBuffer(file);
	if (!buffer) return {};
	try {
		const comfyMetadata = parseAvifMetadata(buffer);
		const result = {};
		if (comfyMetadata.prompt) result.prompt = JSON.stringify(comfyMetadata.prompt);
		if (comfyMetadata.workflow) result.workflow = JSON.stringify(comfyMetadata.workflow);
		return result;
	} catch (e) {
		console.error("Parser: Error parsing AVIF metadata:", e);
		return {};
	}
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.avif = window.comfyAPI.avif || {};
window.comfyAPI.avif.getFromAvifFile = getFromAvifFile;
//#endregion
//#region src/scripts/metadata/flac.ts
function getFromFlacBuffer(buffer) {
	const dataView = new DataView(buffer);
	if (String.fromCharCode(...new Uint8Array(buffer, 0, 4)) !== "fLaC") {
		console.error("Not a valid FLAC file");
		return {};
	}
	let offset = 4;
	let vorbisComment = null;
	while (offset < dataView.byteLength) {
		const isLastBlock = dataView.getUint8(offset) & 128;
		const blockType = dataView.getUint8(offset) & 127;
		const blockSize = dataView.getUint32(offset, false) & 16777215;
		offset += 4;
		if (blockType === 4) vorbisComment = parseVorbisComment(new DataView(buffer, offset, blockSize));
		offset += blockSize;
		if (isLastBlock) break;
	}
	return vorbisComment ?? {};
}
async function getFromFlacFile(file) {
	const buffer = await readFileAsArrayBuffer(file);
	if (!buffer) return {};
	try {
		return getFromFlacBuffer(buffer);
	} catch (e) {
		console.error("Parser: Error parsing FLAC metadata:", e);
		return {};
	}
}
function parseVorbisComment(dataView) {
	let offset = 0;
	const vendorLength = dataView.getUint32(offset, true);
	offset += 4 + vendorLength;
	const userCommentListLength = dataView.getUint32(offset, true);
	offset += 4;
	const comments = {};
	for (let i = 0; i < userCommentListLength; i++) {
		const commentLength = dataView.getUint32(offset, true);
		offset += 4;
		const comment = getString(dataView, offset, commentLength);
		offset += commentLength;
		const ind = comment.indexOf("=");
		const key = comment.substring(0, ind);
		comments[key] = comment.substring(ind + 1);
	}
	return comments;
}
function getString(dataView, offset, length) {
	let string = "";
	for (let i = 0; i < length; i++) string += String.fromCharCode(dataView.getUint8(offset + i));
	return string;
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.flac = window.comfyAPI.flac || {};
window.comfyAPI.flac.getFromFlacBuffer = getFromFlacBuffer;
window.comfyAPI.flac.getFromFlacFile = getFromFlacFile;
//#endregion
//#region src/scripts/metadata/latent.ts
function getFromLatentFile(file) {
	return new Promise((r) => {
		const reader = new FileReader();
		reader.onload = (event) => {
			try {
				const safetensorsData = new Uint8Array(event.target?.result);
				const headerSize = new DataView(safetensorsData.buffer).getUint32(0, true);
				const offset = 8;
				r(JSON.parse(new TextDecoder().decode(safetensorsData.slice(offset, offset + headerSize))).__metadata__);
			} catch {
				r(void 0);
			}
		};
		reader.onerror = () => r(void 0);
		reader.onabort = () => r(void 0);
		const slice = file.slice(0, 4194304);
		reader.readAsArrayBuffer(slice);
	});
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.latent = window.comfyAPI.latent || {};
window.comfyAPI.latent.getFromLatentFile = getFromLatentFile;
//#endregion
//#region src/scripts/metadata/png.ts
async function decompressZlib(data) {
	const stream = new DecompressionStream("deflate");
	const writer = stream.writable.getWriter();
	try {
		await writer.write(data);
		await writer.close();
	} finally {
		writer.releaseLock();
	}
	const reader = stream.readable.getReader();
	const chunks = [];
	let totalLength = 0;
	try {
		for (;;) {
			const { done, value } = await reader.read();
			if (done) break;
			chunks.push(value);
			totalLength += value.length;
		}
	} finally {
		reader.releaseLock();
	}
	const result = new Uint8Array(totalLength);
	let offset = 0;
	for (const chunk of chunks) {
		result.set(chunk, offset);
		offset += chunk.length;
	}
	return result;
}
async function getFromPngBuffer(buffer) {
	const pngData = new Uint8Array(buffer);
	const dataView = new DataView(pngData.buffer);
	if (dataView.getUint32(0) !== 2303741511) {
		console.error("Not a valid PNG file");
		return {};
	}
	let offset = 8;
	const txt_chunks = {};
	while (offset < pngData.length) {
		const length = dataView.getUint32(offset);
		const type = String.fromCharCode(...pngData.slice(offset + 4, offset + 8));
		if (type === "tEXt" || type === "comf" || type === "iTXt") {
			let keyword_end = offset + 8;
			while (pngData[keyword_end] !== 0) keyword_end++;
			const keyword = String.fromCharCode(...pngData.slice(offset + 8, keyword_end));
			let textStart = keyword_end + 1;
			let isCompressed = false;
			let compressionMethod = 0;
			if (type === "iTXt") {
				const chunkEnd = offset + 8 + length;
				isCompressed = pngData[textStart] === 1;
				compressionMethod = pngData[textStart + 1];
				textStart += 2;
				while (pngData[textStart] !== 0 && textStart < chunkEnd) textStart++;
				if (textStart < chunkEnd) textStart++;
				while (pngData[textStart] !== 0 && textStart < chunkEnd) textStart++;
				if (textStart < chunkEnd) textStart++;
			}
			let contentArraySegment = pngData.slice(textStart, offset + 8 + length);
			if (isCompressed) {
				if (compressionMethod === 0) try {
					contentArraySegment = await decompressZlib(contentArraySegment);
				} catch (e) {
					console.error(`Failed to decompress iTXt chunk "${keyword}":`, e);
					offset += 12 + length;
					continue;
				}
				else {
					console.warn(`Unsupported compression method ${compressionMethod} for iTXt chunk "${keyword}"`);
					offset += 12 + length;
					continue;
				}
			}
			txt_chunks[keyword] = new TextDecoder("utf-8").decode(contentArraySegment);
		}
		offset += 12 + length;
	}
	return txt_chunks;
}
async function getFromPngFile(file) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = async (event) => {
			const buffer = event.target?.result;
			if (!(buffer instanceof ArrayBuffer)) {
				reject(/* @__PURE__ */ new Error("Failed to read file as ArrayBuffer"));
				return;
			}
			resolve(await getFromPngBuffer(buffer));
		};
		reader.onerror = () => reject(reader.error);
		reader.onabort = () => reject(/* @__PURE__ */ new Error("FileReader aborted"));
		reader.readAsArrayBuffer(file);
	});
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.png = window.comfyAPI.png || {};
window.comfyAPI.png.getFromPngBuffer = getFromPngBuffer;
window.comfyAPI.png.getFromPngFile = getFromPngFile;
//#endregion
//#region src/scripts/metadata/webp.ts
function parseExifData(exifData) {
	const isLittleEndian = String.fromCharCode(...exifData.slice(0, 2)) === "II";
	function readInt(offset, isLittleEndian, length) {
		const arr = exifData.slice(offset, offset + length);
		const view = new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
		return length === 2 ? view.getUint16(0, isLittleEndian) : view.getUint32(0, isLittleEndian);
	}
	const ifdOffset = readInt(4, isLittleEndian, 4);
	function parseIFD(offset) {
		const numEntries = readInt(offset, isLittleEndian, 2);
		const result = {};
		for (let i = 0; i < numEntries; i++) {
			const entryOffset = offset + 2 + i * 12;
			const tag = readInt(entryOffset, isLittleEndian, 2);
			const type = readInt(entryOffset + 2, isLittleEndian, 2);
			const numValues = readInt(entryOffset + 4, isLittleEndian, 4);
			const valueOffset = readInt(entryOffset + 8, isLittleEndian, 4);
			let value;
			if (type === 2) value = new TextDecoder("utf-8").decode(exifData.subarray(valueOffset, valueOffset + numValues - 1));
			result[tag] = value;
		}
		return result;
	}
	return parseIFD(ifdOffset);
}
function getFromWebpFile(file) {
	return file.arrayBuffer().then((buffer) => {
		const webp = new Uint8Array(buffer);
		const dataView = new DataView(webp.buffer);
		if (dataView.getUint32(0) !== 1380533830 || dataView.getUint32(8) !== 1464156752) {
			console.error("Not a valid WEBP file");
			return {};
		}
		let offset = 12;
		const txt_chunks = {};
		while (offset < webp.length) {
			const chunk_length = dataView.getUint32(offset + 4, true);
			if (String.fromCharCode(...webp.slice(offset, offset + 4)) === "EXIF") {
				let exifOffset = offset + 8;
				let exifLength = chunk_length;
				if (String.fromCharCode(...webp.slice(exifOffset, exifOffset + 6)) == "Exif\0\0") {
					exifOffset += 6;
					exifLength -= 6;
				}
				const data = parseExifData(webp.slice(exifOffset, exifOffset + exifLength));
				for (const key in data) {
					const value = data[Number(key)];
					if (typeof value === "string") {
						const index = value.indexOf(":");
						txt_chunks[value.slice(0, index)] = value.slice(index + 1);
					}
				}
				break;
			}
			offset += 8 + chunk_length + chunk_length % 2;
		}
		return txt_chunks;
	}).catch(() => ({}));
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.webp = window.comfyAPI.webp || {};
window.comfyAPI.webp.getFromWebpFile = getFromWebpFile;
//#endregion
//#region src/scripts/pnginfo.ts
var getAvifMetadata = getFromAvifFile;
var getFlacMetadata = getFromFlacFile;
var getLatentMetadata = getFromLatentFile;
var getPngMetadata = getFromPngFile;
var getWebpMetadata = getFromWebpFile;
var A1111_NEGATIVE_PROMPT_PREFIX = "\nNegative prompt:";
function normalizeA1111Parameters(parameters) {
	const stepsIndex = parameters.lastIndexOf("\nSteps:");
	if (stepsIndex === -1 || parameters.lastIndexOf(A1111_NEGATIVE_PROMPT_PREFIX, stepsIndex) > -1) return parameters;
	return `${parameters.slice(0, stepsIndex)}${A1111_NEGATIVE_PROMPT_PREFIX}${parameters.slice(stepsIndex)}`;
}
async function importA1111(graph, parameters, beforeGraphClear) {
	const normalizedParameters = normalizeA1111Parameters(parameters);
	const p = normalizedParameters.lastIndexOf("\nSteps:");
	if (p > -1) {
		const matchResult = normalizedParameters.substr(p).split("\n")[1].match(/* @__PURE__ */ new RegExp("\\s*([^:]+:\\s*([^\"\\{].*?|\".*?\"|\\{.*?\\}))\\s*(,|$)", "g"));
		if (!matchResult) return "not-a1111";
		const opts = matchResult.reduce((acc, n) => {
			const s = n.split(":");
			if (s[1].endsWith(",")) s[1] = s[1].substr(0, s[1].length - 1);
			acc[s[0].trim().toLowerCase()] = s[1].trim();
			return acc;
		}, {});
		const p2 = normalizedParameters.lastIndexOf(A1111_NEGATIVE_PROMPT_PREFIX, p);
		if (p2 > -1) {
			let positive = normalizedParameters.substr(0, p2).trim();
			let negative = normalizedParameters.substring(p2 + 17, p).trim();
			const ckptNode = LiteGraph.createNode("CheckpointLoaderSimple");
			const clipSkipNode = LiteGraph.createNode("CLIPSetLastLayer");
			const positiveNode = LiteGraph.createNode("CLIPTextEncode");
			const negativeNode = LiteGraph.createNode("CLIPTextEncode");
			const samplerNode = LiteGraph.createNode("KSampler");
			const imageNode = LiteGraph.createNode("EmptyLatentImage");
			const vaeNode = LiteGraph.createNode("VAEDecode");
			const saveNode = LiteGraph.createNode("SaveImage");
			if (!ckptNode || !clipSkipNode || !positiveNode || !negativeNode || !samplerNode || !imageNode || !vaeNode || !saveNode) {
				console.error("Failed to create required nodes for A1111 import");
				return "core-nodes-unavailable";
			}
			const hires = { samplerNode: null };
			const ceil64 = (v) => Math.ceil(v / 64) * 64;
			function getWidget(node, name) {
				return node?.widgets?.find((w) => w.name === name);
			}
			function setWidgetValue(node, name, value, isOptionPrefix) {
				const w = getWidget(node, name);
				if (!w) return;
				if (isOptionPrefix) {
					const o = w.options.values?.find((v) => v.startsWith(String(value)));
					if (o) w.value = o;
					else {
						console.warn(`Unknown value '${value}' for widget '${name}'`, node);
						w.value = value;
					}
				} else w.value = value;
			}
			function createLoraNodes(clipNode, text, prevClip, prevModel, targetSamplerNode) {
				const loras = [];
				text = text.replace(/<lora:([^:]+:[^>]+)>/g, (_m, c) => {
					const s = c.split(":");
					const weight = parseFloat(s[1]);
					if (isNaN(weight)) console.warn("Invalid LORA", _m);
					else loras.push({
						name: s[0],
						weight
					});
					return "";
				});
				for (const l of loras) {
					const loraNode = LiteGraph.createNode("LoraLoader");
					if (!loraNode) continue;
					graph.add(loraNode);
					setWidgetValue(loraNode, "lora_name", l.name, true);
					setWidgetValue(loraNode, "strength_model", l.weight);
					setWidgetValue(loraNode, "strength_clip", l.weight);
					prevModel.node.connect(prevModel.index, loraNode, 0);
					prevClip.node.connect(prevClip.index, loraNode, 1);
					prevModel = {
						node: loraNode,
						index: 0
					};
					prevClip = {
						node: loraNode,
						index: 1
					};
				}
				prevClip.node.connect(1, clipNode, 0);
				prevModel.node.connect(0, targetSamplerNode, 0);
				if (hires.samplerNode) prevModel.node.connect(0, hires.samplerNode, 0);
				return {
					text,
					prevModel,
					prevClip
				};
			}
			function replaceEmbeddings(text) {
				if (!embeddings.length) return text;
				return text.replaceAll(new RegExp("\\b(" + embeddings.map((e) => e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("\\b|\\b") + ")\\b", "ig"), "embedding:$1");
			}
			function popOpt(name) {
				const v = opts[name];
				delete opts[name];
				return v;
			}
			const { embeddings, embeddingsLoaded } = await api.getEmbeddings().then((embeddings) => ({
				embeddings,
				embeddingsLoaded: true
			})).catch((error) => {
				console.error("Failed to load embeddings for A1111 import:", error);
				return {
					embeddings: [],
					embeddingsLoaded: false
				};
			});
			await beforeGraphClear?.();
			withGraphIntentSource("load", () => {
				graph.clear();
				graph.add(ckptNode);
				graph.add(clipSkipNode);
				graph.add(positiveNode);
				graph.add(negativeNode);
				graph.add(samplerNode);
				graph.add(imageNode);
				graph.add(vaeNode);
				graph.add(saveNode);
				ckptNode.connect(1, clipSkipNode, 0);
				clipSkipNode.connect(0, positiveNode, 0);
				clipSkipNode.connect(0, negativeNode, 0);
				ckptNode.connect(0, samplerNode, 0);
				positiveNode.connect(0, samplerNode, 1);
				negativeNode.connect(0, samplerNode, 2);
				imageNode.connect(0, samplerNode, 3);
				vaeNode.connect(0, saveNode, 0);
				samplerNode.connect(0, vaeNode, 0);
				ckptNode.connect(2, vaeNode, 1);
				const handlers = {
					model(v) {
						setWidgetValue(ckptNode, "ckpt_name", v, true);
					},
					vae() {},
					"cfg scale"(v) {
						setWidgetValue(samplerNode, "cfg", +v);
					},
					"clip skip"(v) {
						setWidgetValue(clipSkipNode, "stop_at_clip_layer", -Number(v));
					},
					sampler(v) {
						let name = v.toLowerCase().replace("++", "pp").replaceAll(" ", "_");
						if (name.includes("karras")) {
							name = name.replace("karras", "").replace(/_+$/, "");
							setWidgetValue(samplerNode, "scheduler", "karras");
						} else setWidgetValue(samplerNode, "scheduler", "normal");
						const o = (getWidget(samplerNode, "sampler_name")?.options.values)?.find((v) => v === name || v === "sample_" + name);
						if (o) setWidgetValue(samplerNode, "sampler_name", o);
					},
					size(v) {
						const wxh = v.split("x");
						const w = ceil64(+wxh[0]);
						const h = ceil64(+wxh[1]);
						const hrUp = popOpt("hires upscale");
						const hrSz = popOpt("hires resize");
						hires.steps = popOpt("hires steps");
						let hrMethod = popOpt("hires upscaler");
						setWidgetValue(imageNode, "width", w);
						setWidgetValue(imageNode, "height", h);
						if (hrUp || hrSz) {
							let uw;
							let uh;
							if (hrUp) {
								uw = w * Number(hrUp);
								uh = h * Number(hrUp);
							} else if (hrSz) {
								const s = hrSz.split("x");
								uw = +s[0];
								uh = +s[1];
							} else return;
							let upscaleNode;
							let latentNode;
							if (hrMethod?.startsWith("Latent")) {
								latentNode = upscaleNode = LiteGraph.createNode("LatentUpscale");
								if (!upscaleNode) return;
								graph.add(upscaleNode);
								samplerNode.connect(0, upscaleNode, 0);
								switch (hrMethod) {
									case "Latent (nearest-exact)": hrMethod = "nearest-exact";
								}
								setWidgetValue(upscaleNode, "upscale_method", hrMethod, true);
							} else {
								const decode = LiteGraph.createNode("VAEDecodeTiled");
								if (!decode) return;
								graph.add(decode);
								samplerNode.connect(0, decode, 0);
								ckptNode.connect(2, decode, 1);
								const upscaleLoaderNode = LiteGraph.createNode("UpscaleModelLoader");
								if (!upscaleLoaderNode) return;
								graph.add(upscaleLoaderNode);
								setWidgetValue(upscaleLoaderNode, "model_name", hrMethod ?? "", true);
								const modelUpscaleNode = LiteGraph.createNode("ImageUpscaleWithModel");
								if (!modelUpscaleNode) return;
								graph.add(modelUpscaleNode);
								decode.connect(0, modelUpscaleNode, 1);
								upscaleLoaderNode.connect(0, modelUpscaleNode, 0);
								upscaleNode = LiteGraph.createNode("ImageScale");
								if (!upscaleNode) return;
								graph.add(upscaleNode);
								modelUpscaleNode.connect(0, upscaleNode, 0);
								const vaeEncodeNode = LiteGraph.createNode("VAEEncodeTiled");
								if (!vaeEncodeNode) return;
								latentNode = vaeEncodeNode;
								graph.add(vaeEncodeNode);
								upscaleNode.connect(0, vaeEncodeNode, 0);
								ckptNode.connect(2, vaeEncodeNode, 1);
							}
							setWidgetValue(upscaleNode, "width", ceil64(uw));
							setWidgetValue(upscaleNode, "height", ceil64(uh));
							const hrSamplerNode = LiteGraph.createNode("KSampler");
							if (!hrSamplerNode || !latentNode) return;
							hires.samplerNode = hrSamplerNode;
							graph.add(hrSamplerNode);
							ckptNode.connect(0, hrSamplerNode, 0);
							positiveNode.connect(0, hrSamplerNode, 1);
							negativeNode.connect(0, hrSamplerNode, 2);
							latentNode.connect(0, hrSamplerNode, 3);
							hrSamplerNode.connect(0, vaeNode, 0);
						}
					},
					steps(v) {
						setWidgetValue(samplerNode, "steps", +v);
					},
					seed(v) {
						setWidgetValue(samplerNode, "seed", +v);
					}
				};
				for (const opt in opts) {
					const handler = handlers[opt];
					if (handler) {
						const value = popOpt(opt);
						if (value !== void 0) handler(value);
					}
				}
				const { samplerNode: hrSamplerNode, steps: hrSteps } = hires;
				if (hrSamplerNode) {
					setWidgetValue(hrSamplerNode, "steps", hrSteps ? +hrSteps : getWidget(samplerNode, "steps")?.value);
					setWidgetValue(hrSamplerNode, "cfg", getWidget(samplerNode, "cfg")?.value);
					setWidgetValue(hrSamplerNode, "scheduler", getWidget(samplerNode, "scheduler")?.value);
					setWidgetValue(hrSamplerNode, "sampler_name", getWidget(samplerNode, "sampler_name")?.value);
					setWidgetValue(hrSamplerNode, "denoise", +(popOpt("denoising strength") ?? "1"));
				}
				let n = createLoraNodes(positiveNode, positive, {
					node: clipSkipNode,
					index: 0
				}, {
					node: ckptNode,
					index: 0
				}, samplerNode);
				positive = n.text;
				n = createLoraNodes(negativeNode, negative, n.prevClip, n.prevModel, samplerNode);
				negative = n.text;
				setWidgetValue(positiveNode, "text", replaceEmbeddings(positive));
				setWidgetValue(negativeNode, "text", replaceEmbeddings(negative));
				graph.arrange();
			});
			for (const opt of [
				"model hash",
				"ensd",
				"version",
				"vae hash",
				"ti hashes",
				"lora hashes",
				"hashes"
			]) delete opts[opt];
			if (Object.keys(opts).length) console.warn("Unhandled parameters:", opts);
			return embeddingsLoaded ? "imported" : "imported-without-embeddings";
		}
	}
	return "not-a1111";
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.pnginfo = window.comfyAPI.pnginfo || {};
window.comfyAPI.pnginfo.getAvifMetadata = getAvifMetadata;
window.comfyAPI.pnginfo.getFlacMetadata = getFlacMetadata;
window.comfyAPI.pnginfo.getLatentMetadata = getLatentMetadata;
window.comfyAPI.pnginfo.getPngMetadata = getPngMetadata;
window.comfyAPI.pnginfo.getWebpMetadata = getWebpMetadata;
window.comfyAPI.pnginfo.importA1111 = importA1111;
//#endregion
//#region src/core/graph/subgraph/promotedWidgetControl.ts
function collectPromotedControlTargets(node) {
	if (!node.isSubgraphNode()) return [];
	const targets = [];
	for (const [index, input] of node.inputs.entries()) {
		if (!input.widgetId) continue;
		if (node.isInputConnected(index)) continue;
		const source = promotedInputSource(node, input);
		if (!source) continue;
		const resolution = resolveConcretePromotedWidget(node, source.nodeId, source.widgetName);
		if (resolution.status !== "resolved") continue;
		const { linkedWidgets } = resolution.resolved.widget;
		if (!linkedWidgets?.some(isValueControlWidget)) continue;
		const hostWidget = node.getWidgetFromSlot(input);
		if (!hostWidget) continue;
		targets.push({
			hostWidget,
			linkedWidgets
		});
	}
	return targets;
}
function applyTarget(target, nodeId) {
	const next = nextValueForLinkedTarget({
		target: target.hostWidget,
		linkedWidgets: target.linkedWidgets,
		nodeId
	});
	if (next === void 0) return;
	target.hostWidget.value = next;
	target.hostWidget.callback?.(next);
}
function controlValueRunBefore() {
	return useSettingStore().get("Comfy.WidgetControlMode") === "before";
}
/**
* Host widgets that have run control at least once, so `before` mode can skip
* the first execution (mirroring the interior control widget's HAS_EXECUTED).
*
* Keyed by the widget instance so entries are released when the graph is
* cleared and its widgets are recreated, avoiding stale state across reloads.
*/
var executedWidgets = /* @__PURE__ */ new WeakSet();
/**
* Applies `control_after_generate` to a subgraph host node's promoted widgets.
*
* The interior control widget short-circuits for promoted inputs because the
* interior widget is link-fed by the subgraph boundary, so its value is dead.
* The authoritative value lives on the host node (store-backed), and this
* applies the next controlled value there.
*/
function applyPromotedWidgetControl(node, phase) {
	const runBefore = controlValueRunBefore();
	if (phase === "beforeQueued" && !runBefore) return;
	if (phase === "afterQueued" && runBefore) return;
	for (const target of collectPromotedControlTargets(node)) {
		if (phase === "afterQueued") {
			applyTarget(target, node.id);
			continue;
		}
		if (executedWidgets.has(target.hostWidget)) applyTarget(target, node.id);
		executedWidgets.add(target.hostWidget);
	}
}
//#endregion
//#region src/renderer/core/layout/transform/graphRenderTransform.ts
var RENDER_SCALE_FACTOR = 1.2;
var anchorCache = /* @__PURE__ */ new WeakMap();
/**
* Returns a render anchor for a graph.
*
* @remarks
* The anchor is computed once per graph instance and cached for that graph's
* lifetime. This is intended for one-shot normalization passes.
*/
function getGraphRenderAnchor(graph) {
	const cached = anchorCache.get(graph);
	if (cached) return cached;
	const bounds = graph.nodes.length ? createBounds(graph.nodes) : void 0;
	const anchor = bounds ? {
		x: bounds[0],
		y: bounds[1]
	} : {
		x: 0,
		y: 0
	};
	anchorCache.set(graph, anchor);
	return anchor;
}
function unprojectPoint(point, anchor, scale) {
	if (scale === 1) return point;
	return {
		x: anchor.x + (point.x - anchor.x) / scale,
		y: anchor.y + (point.y - anchor.y) / scale
	};
}
function unprojectBounds(bounds, anchor, scale) {
	const topLeft = unprojectPoint({
		x: bounds.x,
		y: bounds.y
	}, anchor, scale);
	return {
		x: topLeft.x,
		y: topLeft.y,
		width: bounds.width / scale,
		height: bounds.height / scale
	};
}
//#endregion
//#region src/renderer/extensions/vueNodes/layout/ensureCorrectLayoutScale.ts
/**
* One-time legacy normalizer for workflows saved with Vue-scaled coordinates.
*
* Detects workflows saved in the old Vue coordinate space (where positions
* were mutated by 1.2x at runtime) and normalizes them back to canonical
* LiteGraph coordinates. Runs once per graph, then marks it as normalized.
*
* After normalization, rendering applies the 1.2x scale visually via CSS
* transforms rather than mutating persisted geometry.
*
* @param rendererVersion - Override for the renderer version check. When
*   graph metadata is missing, this value is used as a fallback.
* @param targetGraph - The graph to normalize.
*/
function ensureCorrectLayoutScale(rendererVersion, graph) {
	const currentRenderer = graph.extra.workflowRendererVersion;
	if (currentRenderer === "Vue-corrected") return false;
	if ((currentRenderer ?? rendererVersion) !== "Vue") return false;
	const anchor = getGraphRenderAnchor(graph);
	function applySnap(pos, method = "round") {
		if (LiteGraph.alwaysSnapToGrid) {
			const snapTo = graph.getSnapToGridSize();
			if (snapTo) snapPoint(pos, snapTo, method);
		}
	}
	function normalizedBounds(item) {
		const c = unprojectBounds({
			x: item.pos[0],
			y: item.pos[1],
			width: item.size[0],
			height: item.size[1]
		}, anchor, RENDER_SCALE_FACTOR);
		const pos = [c.x, c.y];
		const size = [c.width, c.height];
		applySnap(pos);
		applySnap(size, "ceil");
		return [
			pos[0],
			pos[1],
			size[0],
			size[1]
		];
	}
	function normalize(item) {
		const [x, y, width, height] = normalizedBounds(item);
		item.pos = [x, y];
		item.size = [width, height];
	}
	for (const node of graph.nodes) normalize(node);
	for (const reroute of graph.reroutes.values()) {
		const p = unprojectPoint({
			x: reroute.pos[0],
			y: reroute.pos[1]
		}, anchor, RENDER_SCALE_FACTOR);
		const pos = [p.x, p.y];
		applySnap(pos);
		reroute.pos = pos;
	}
	for (const group of graph.groups) group.boundingRect.set(normalizedBounds(group));
	if ("inputNode" in graph && "outputNode" in graph) {
		for (const ioNode of [graph.inputNode, graph.outputNode]) if (ioNode) normalize(ioNode);
	}
	graph.extra.workflowRendererVersion = "Vue-corrected";
	return true;
}
//#endregion
//#region src/scripts/metadata/ebml.ts
var WEBM_SIGNATURE = [
	26,
	69,
	223,
	163
];
var MAX_READ_BYTES$2 = 2097152;
var EBML_ID = {
	SIMPLE_TAG: new Uint8Array([103, 200]),
	TAG_NAME: new Uint8Array([69, 163]),
	TAG_VALUE: new Uint8Array([68, 135])
};
var ASCII = {
	OPEN_BRACE: 123,
	NULL: 0,
	PRINTABLE_MIN: 32,
	PRINTABLE_MAX: 126
};
var MASK = {
	MSB: 128,
	ALL_BITS_SET: -1
};
var hasWebmSignature = (data) => WEBM_SIGNATURE.every((byte, index) => data[index] === byte);
var readVint = (data, pos) => {
	if (pos >= data.length) return null;
	const byte = data[pos];
	if ((byte & MASK.MSB) === MASK.MSB) return {
		value: byte & ~MASK.MSB,
		length: 1
	};
	const length = findFirstSetBitPosition(byte);
	if (length === 0 || pos + length > data.length) return null;
	return {
		value: calculateVintValue(data, pos, length),
		length
	};
};
var calculateVintValue = (data, pos, length) => {
	let value = data[pos] & 255 >> length;
	for (let i = 1; i < length; i++) value = value << 8 | data[pos + i];
	const allBitsSet = Math.pow(2, 7 * length) - 1;
	return value === allBitsSet ? MASK.ALL_BITS_SET : value;
};
var findFirstSetBitPosition = (byte) => {
	for (let mask = MASK.MSB, position = 1; mask !== 0; mask >>= 1, position++) if ((byte & mask) !== 0) return position;
	return 0;
};
var matchesId = (data, pos, id) => {
	if (pos + id.length > data.length) return false;
	for (let i = 0; i < id.length; i++) if (data[pos + i] !== id[i]) return false;
	return true;
};
var findNextTag = (data, pos) => {
	if (!matchesId(data, pos, EBML_ID.SIMPLE_TAG)) return null;
	const tagSize = readVint(data, pos + 2);
	if (!tagSize || tagSize.value <= 0) return null;
	const tagEnd = pos + 2 + tagSize.length + tagSize.value;
	if (tagEnd > data.length) return null;
	return {
		tagEnd,
		contents: extractTagContents(data, pos + 2 + tagSize.length, tagEnd)
	};
};
var extractTagContents = (data, start, end) => {
	const nameInfo = findElementsInTag(data, start, end, EBML_ID.TAG_NAME);
	const valueInfo = findElementsInTag(data, start, end, EBML_ID.TAG_VALUE);
	if (!nameInfo || !valueInfo) return null;
	return {
		name: nameInfo,
		value: valueInfo
	};
};
var findElementsInTag = (data, start, end, id) => {
	for (let pos = start; pos < end - 1;) {
		if (matchesId(data, pos, id)) {
			const size = readVint(data, pos + 2);
			if (size && size.value > 0) return {
				pos: pos + 2 + size.length,
				len: size.value
			};
		}
		pos++;
	}
	return null;
};
var processTagContents = (data, contents, meta) => {
	try {
		const name = extractEbmlTagName(data, contents.name.pos, contents.name.len);
		if (!name) return;
		const value = extractEbmlTagValue(data, name, contents.value.pos, contents.value.len);
		if (value !== null) meta[name.toLowerCase()] = value;
	} catch {}
};
var extractEbmlTagValue = (data, name, pos, len) => {
	if (name === ComfyMetadataTags.PROMPT || name === ComfyMetadataTags.WORKFLOW) return readJson(data, pos, len);
	return ebmlToString(data, pos, len);
};
var extractEbmlTagName = (data, start, length) => {
	if (length <= 0) return null;
	const textRange = findReadableTextRange(data, start, length);
	if (!textRange) return null;
	return new TextDecoder().decode(data.subarray(textRange.start, textRange.end)).trim();
};
var findReadableTextRange = (data, start, length) => {
	const isPrintableAscii = (byte) => byte >= ASCII.PRINTABLE_MIN && byte <= ASCII.PRINTABLE_MAX;
	let textStart = start;
	while (textStart < start + length && !isPrintableAscii(data[textStart])) textStart++;
	if (textStart >= start + length) return null;
	let textEnd = textStart;
	while (textEnd < start + length && data[textEnd] !== ASCII.NULL) textEnd++;
	return {
		start: textStart,
		end: textEnd
	};
};
var readJson = (data, start, length) => {
	if (length <= 0) return null;
	const nullTerminatorPos = findNullTerminator(data, start, length);
	const jsonStartPos = findJsonStart(data, start, nullTerminatorPos - start);
	if (jsonStartPos === null) return null;
	return parseJsonText(decodeJsonText(data, jsonStartPos, nullTerminatorPos));
};
var decodeJsonText = (data, start, end) => {
	return new TextDecoder().decode(data.subarray(start, end));
};
var parseJsonText = (jsonText) => {
	const jsonEndPos = findJsonEnd(jsonText);
	if (jsonEndPos === null) return null;
	try {
		return parseJsonWithNonFinite(jsonText.substring(0, jsonEndPos));
	} catch {
		return null;
	}
};
var findNullTerminator = (data, start, maxLength) => {
	const end = Math.min(start + maxLength, data.length);
	for (let pos = start; pos < end; pos++) if (data[pos] === ASCII.NULL) return pos;
	return end;
};
var findJsonStart = (data, start, length) => {
	for (let pos = start; pos < start + length; pos++) if (data[pos] === ASCII.OPEN_BRACE) return pos;
	return null;
};
var findJsonEnd = (text) => {
	let braceCount = 1;
	let pos = 1;
	while (braceCount > 0 && pos < text.length) {
		if (text[pos] === "{") braceCount++;
		if (text[pos] === "}") braceCount--;
		pos++;
	}
	return braceCount === 0 ? pos : null;
};
var ebmlToString = (data, start, length) => {
	if (length <= 0) return "";
	const endPos = findNullTerminator(data, start, length);
	return new TextDecoder().decode(data.subarray(start, endPos)).trim();
};
var parseMetadata = (data) => {
	const meta = {};
	for (let pos = 0; pos < data.length - 2;) {
		const tagInfo = findNextTag(data, pos);
		if (!tagInfo) {
			pos++;
			continue;
		}
		const { tagEnd, contents } = tagInfo;
		if (contents) processTagContents(data, contents, meta);
		pos = tagEnd;
	}
	return meta;
};
var parseWebmBuffer = (buffer) => {
	try {
		const data = new Uint8Array(buffer);
		if (data.length < 4 || !hasWebmSignature(data)) return {};
		return parseMetadata(data);
	} catch {
		return {};
	}
};
/**
* Extracts ComfyUI Workflow metadata from a WebM file
* @param file - The WebM file to extract metadata from
*/
async function getFromWebmFile(file) {
	const buffer = await readFileAsArrayBuffer(file, MAX_READ_BYTES$2);
	if (!buffer) return {};
	return parseWebmBuffer(buffer);
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.ebml = window.comfyAPI.ebml || {};
window.comfyAPI.ebml.getFromWebmFile = getFromWebmFile;
//#endregion
//#region src/scripts/metadata/gltf.ts
var MAX_READ_BYTES$1 = 1 << 20;
var isJsonChunk = (chunk) => !!chunk && chunk.chunkTypeIdentifier === ASCII$1.JSON;
var isValidChunkRange = (start, length, bufferSize) => start + length <= bufferSize;
var byteArrayToString = (bytes) => new TextDecoder().decode(bytes);
var parseGltfBinaryHeader = (dataView) => {
	if (dataView.byteLength < GltfSizeBytes.HEADER) return null;
	const magicNumber = dataView.getUint32(0, true);
	if (magicNumber !== ASCII$1.GLTF) return null;
	return {
		magicNumber,
		gltfFormatVersion: dataView.getUint32(4, true),
		totalLengthBytes: dataView.getUint32(8, true)
	};
};
var parseChunkHeaderAtOffset = (dataView, offset) => {
	if (offset + GltfSizeBytes.CHUNK_HEADER > dataView.byteLength) return null;
	return {
		chunkLengthBytes: dataView.getUint32(offset, true),
		chunkTypeIdentifier: dataView.getUint32(offset + 4, true)
	};
};
var extractJsonChunk = (buffer) => {
	const dataView = new DataView(buffer);
	if (!parseGltfBinaryHeader(dataView)) return null;
	const chunkOffset = GltfSizeBytes.HEADER;
	const firstChunk = parseChunkHeaderAtOffset(dataView, chunkOffset);
	if (!firstChunk || !isJsonChunk(firstChunk)) return null;
	const jsonStart = chunkOffset + GltfSizeBytes.CHUNK_HEADER;
	if (!isValidChunkRange(jsonStart, firstChunk.chunkLengthBytes, dataView.byteLength)) return null;
	return {
		start: jsonStart,
		length: firstChunk.chunkLengthBytes
	};
};
var extractJsonChunkData = (buffer) => {
	const chunkLocation = extractJsonChunk(buffer);
	if (!chunkLocation) return null;
	return new Uint8Array(buffer, chunkLocation.start, chunkLocation.length);
};
var parseJson = (text) => {
	try {
		return parseJsonWithNonFinite(text);
	} catch {
		return null;
	}
};
var isJsonObject = (value) => typeof value === "object" && value !== null;
var parseMetadataValue = (value) => {
	const parsed = typeof value === "string" ? parseJson(value) : value;
	return isJsonObject(parsed) ? parsed : void 0;
};
var extractComfyMetadata = (jsonData) => {
	const metadata = {};
	const { asset } = jsonData;
	if (!isJsonObject(asset) || !isJsonObject(asset.extras)) return metadata;
	const { extras } = asset;
	if (extras.workflow) {
		const parsedValue = parseMetadataValue(extras.workflow);
		if (parsedValue) metadata[ComfyMetadataTags.WORKFLOW.toLowerCase()] = parsedValue;
	}
	if (extras.prompt) {
		const parsedValue = parseMetadataValue(extras.prompt);
		if (parsedValue) metadata[ComfyMetadataTags.PROMPT.toLowerCase()] = parsedValue;
	}
	return metadata;
};
var processGltfFileBuffer = (buffer) => {
	const jsonChunk = extractJsonChunkData(buffer);
	if (!jsonChunk) return {};
	const parsedJson = parseJson(byteArrayToString(jsonChunk));
	if (!isJsonObject(parsedJson)) return {};
	return extractComfyMetadata(parsedJson);
};
/**
* Extract ComfyUI metadata from a GLTF binary file (GLB)
*/
async function getGltfBinaryMetadata(file) {
	const buffer = await readFileAsArrayBuffer(file, MAX_READ_BYTES$1);
	if (!buffer) return {};
	try {
		return processGltfFileBuffer(buffer);
	} catch {
		return {};
	}
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.gltf = window.comfyAPI.gltf || {};
window.comfyAPI.gltf.getGltfBinaryMetadata = getGltfBinaryMetadata;
//#endregion
//#region src/scripts/metadata/isobmff.ts
var MAX_READ_BYTES = 67108864;
var BOX_TYPES = {
	USER_DATA: [
		117,
		100,
		116,
		97
	],
	META_DATA: [
		109,
		101,
		116,
		97
	],
	ITEM_LIST: [
		105,
		108,
		115,
		116
	],
	KEYS: [
		107,
		101,
		121,
		115
	],
	DATA: [
		100,
		97,
		116,
		97
	],
	MOVIE: [
		109,
		111,
		111,
		118
	]
};
var SIZES = {
	HEADER: 8,
	VERSION: 4,
	LOCALE: 4,
	ITEM_MIN: 8
};
var bufferMatchesBoxType = (data, pos, boxType) => {
	if (pos + 4 > data.length) return false;
	for (let i = 0; i < 4; i++) if (data[pos + i] !== boxType[i]) return false;
	return true;
};
var readUint32 = (data, pos) => {
	if (pos + 4 > data.length) return 0;
	return data[pos] << 24 | data[pos + 1] << 16 | data[pos + 2] << 8 | data[pos + 3];
};
var findIsobmffBoxByType = (data, startPos, endPos, boxType) => {
	for (let pos = startPos; pos < endPos - 8; pos++) {
		const size = readUint32(data, pos);
		if (size < SIZES.ITEM_MIN) continue;
		if (bufferMatchesBoxType(data, pos + 4, boxType)) return {
			start: pos + SIZES.HEADER,
			end: pos + size
		};
		if (pos + size > endPos) return null;
		pos += size - 1;
	}
	return null;
};
var extractJson = (data, start, end) => {
	let jsonStart = start;
	while (jsonStart < end && data[jsonStart] !== ASCII$1.OPEN_BRACE) jsonStart++;
	if (jsonStart >= end) return null;
	try {
		return parseJsonWithNonFinite(new TextDecoder().decode(data.slice(jsonStart, end)));
	} catch {
		return null;
	}
};
var readUtf8String = (data, start, end) => new TextDecoder().decode(data.slice(start, end));
var parseKeysBox = (data, keysBoxStart, keysBoxEnd) => {
	const keysMap = /* @__PURE__ */ new Map();
	let pos = keysBoxStart + 4;
	if (pos + 4 > keysBoxEnd) return keysMap;
	const entryCount = readUint32(data, pos);
	pos += 4;
	for (let i = 1; i <= entryCount; i++) {
		if (pos + SIZES.HEADER > keysBoxEnd) break;
		const keySize = readUint32(data, pos);
		pos += SIZES.HEADER;
		const keyNameEnd = pos + keySize - SIZES.HEADER;
		if (keySize < SIZES.ITEM_MIN || keyNameEnd > keysBoxEnd) break;
		const keyName = readUtf8String(data, pos, keyNameEnd);
		keysMap.set(i, keyName);
		pos = keyNameEnd;
	}
	return keysMap;
};
var extractMetadataValueFromDataBox = (data, dataBoxStart, dataBoxEnd, keyName) => {
	const valueStart = dataBoxStart + SIZES.VERSION + SIZES.LOCALE;
	if (valueStart >= dataBoxEnd) return null;
	const lowerKeyName = keyName.toLowerCase();
	if (lowerKeyName === ComfyMetadataTags.PROMPT.toLowerCase() || lowerKeyName === ComfyMetadataTags.WORKFLOW.toLowerCase()) return extractJson(data, valueStart, dataBoxEnd);
	return null;
};
var parseIlstItem = (data, itemStart, itemEnd, keysMap, metadata) => {
	if (itemStart + SIZES.HEADER > itemEnd) return;
	const itemIndex = readUint32(data, itemStart + 4);
	const keyName = keysMap.get(itemIndex);
	if (!keyName) return;
	const dataBox = findIsobmffBoxByType(data, itemStart + SIZES.HEADER, itemEnd, BOX_TYPES.DATA);
	if (dataBox) {
		const value = extractMetadataValueFromDataBox(data, dataBox.start, dataBox.end, keyName);
		if (value !== null) metadata[keyName.toLowerCase()] = value;
	}
};
var parseIlstBox = (data, ilstStart, ilstEnd, keysMap, metadata) => {
	let pos = ilstStart;
	while (pos < ilstEnd - SIZES.HEADER) {
		const itemSize = readUint32(data, pos);
		if (itemSize <= SIZES.HEADER || pos + itemSize > ilstEnd) break;
		parseIlstItem(data, pos, pos + itemSize, keysMap, metadata);
		pos += itemSize;
	}
};
var findUserDataBox = (data) => {
	const topLevelBox = findIsobmffBoxByType(data, 0, data.length, BOX_TYPES.USER_DATA);
	if (topLevelBox) return topLevelBox;
	const moovBox = findIsobmffBoxByType(data, 0, data.length, BOX_TYPES.MOVIE);
	if (!moovBox) return null;
	return findIsobmffBoxByType(data, moovBox.start, moovBox.end, BOX_TYPES.USER_DATA);
};
var parseIsobmffMetadata = (data) => {
	const metadata = {};
	const userDataBox = findUserDataBox(data);
	if (!userDataBox) return metadata;
	const metaBox = findIsobmffBoxByType(data, userDataBox.start, userDataBox.end, BOX_TYPES.META_DATA);
	if (!metaBox) return metadata;
	const metaContentStart = metaBox.start + SIZES.VERSION;
	const keysBox = findIsobmffBoxByType(data, metaContentStart, metaBox.end, BOX_TYPES.KEYS);
	if (!keysBox) return metadata;
	const keysMap = parseKeysBox(data, keysBox.start, keysBox.end);
	if (keysMap.size === 0) return metadata;
	const ilstBox = findIsobmffBoxByType(data, metaContentStart, metaBox.end, BOX_TYPES.ITEM_LIST);
	if (!ilstBox) return metadata;
	parseIlstBox(data, ilstBox.start, ilstBox.end, keysMap, metadata);
	return metadata;
};
/**
* Extracts ComfyUI Workflow metadata from an ISO Base Media File Format (ISOBMFF) file
* (e.g., MP4, MOV) by parsing the `udta.meta.keys` and `udta.meta.ilst` boxes.
* @param file - The file to extract metadata from.
*/
async function getFromIsobmffFile(file) {
	const buffer = await readFileAsArrayBuffer(file, MAX_READ_BYTES);
	if (!buffer) return {};
	try {
		return parseIsobmffMetadata(new Uint8Array(buffer));
	} catch (e) {
		console.error("Parser: Error parsing ISOBMFF metadata:", e);
		return {};
	}
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.isobmff = window.comfyAPI.isobmff || {};
window.comfyAPI.isobmff.getFromIsobmffFile = getFromIsobmffFile;
//#endregion
//#region src/scripts/metadata/json.ts
function getDataFromJSON(file) {
	return new Promise((resolve) => {
		const reader = new FileReader();
		reader.onload = async () => {
			try {
				if (typeof reader.result !== "string") {
					resolve(void 0);
					return;
				}
				const jsonContent = parseJsonWithNonFinite(reader.result);
				if (jsonContent.templates) {
					resolve({ templates: jsonContent.templates });
					return;
				}
				if (isApiJson(jsonContent)) {
					resolve({ prompt: jsonContent });
					return;
				}
				resolve({ workflow: jsonContent });
			} catch {
				resolve(void 0);
			}
		};
		reader.onerror = () => resolve(void 0);
		reader.onabort = () => resolve(void 0);
		reader.readAsText(file);
	});
}
function isApiJson(data) {
	return isObject(data) && Object.values(data).every((v) => v.class_type);
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.json = window.comfyAPI.json || {};
window.comfyAPI.json.getDataFromJSON = getDataFromJSON;
//#endregion
//#region src/scripts/metadata/mp3.ts
var NULL$1 = "\0";
/** Extracts the JSON text from an `<key>\0{...}\0` ID3 text frame. */
function readNullTerminatedJson(header, key) {
	const frameStart = header.indexOf(`${key}${NULL$1}{`);
	if (frameStart === -1) return void 0;
	const jsonStart = frameStart + key.length + 1;
	const jsonEnd = header.indexOf(`}${NULL$1}`, jsonStart);
	if (jsonEnd === -1) return void 0;
	return header.slice(jsonStart, jsonEnd + 1);
}
async function getMp3Metadata(file) {
	const arrayBuffer = await readFileAsArrayBuffer(file);
	if (!arrayBuffer) return {
		prompt: void 0,
		workflow: void 0
	};
	const sig_bytes = new Uint8Array(arrayBuffer, 0, 3);
	if ((sig_bytes[0] != 255 || sig_bytes[1] != 251) && (sig_bytes[0] != 73 || sig_bytes[1] != 68 || sig_bytes[2] != 51)) console.error("Invalid file signature.");
	let header = "";
	while (header.length < arrayBuffer.byteLength) {
		const page = String.fromCharCode(...new Uint8Array(arrayBuffer, header.length, Math.min(4096, arrayBuffer.byteLength - header.length)));
		header += page;
		if (page.match("ÿû")) break;
	}
	let workflow;
	let prompt;
	const prompt_s = readNullTerminatedJson(header, "prompt");
	if (prompt_s) try {
		prompt = parseJsonWithNonFinite(prompt_s);
	} catch (e) {
		console.error("Failed to parse MP3 prompt metadata", e);
	}
	const workflow_s = readNullTerminatedJson(header, "workflow");
	if (workflow_s) try {
		workflow = parseJsonWithNonFinite(workflow_s);
	} catch (e) {
		console.error("Failed to parse MP3 workflow metadata", e);
	}
	return {
		prompt,
		workflow
	};
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.mp3 = window.comfyAPI.mp3 || {};
window.comfyAPI.mp3.getMp3Metadata = getMp3Metadata;
//#endregion
//#region src/scripts/metadata/ogg.ts
var NULL = "\0";
/** Extracts the JSON text from a `<key>={...}` Vorbis comment ending at a null byte. */
function readVorbisCommentJson(header, key) {
	const commentStart = header.indexOf(`${key}={`);
	if (commentStart === -1) return void 0;
	const jsonStart = commentStart + key.length + 1;
	const firstClose = header.indexOf("}", jsonStart);
	if (firstClose === -1) return void 0;
	const commentEnd = header.indexOf(NULL, firstClose);
	if (commentEnd === -1) return void 0;
	return header.slice(jsonStart, commentEnd).match(/\{.*\}/)?.[0];
}
async function getOggMetadata(file) {
	const arrayBuffer = await readFileAsArrayBuffer(file);
	if (!arrayBuffer) return {
		prompt: void 0,
		workflow: void 0
	};
	if (String.fromCharCode(...new Uint8Array(arrayBuffer, 0, 4)) !== "OggS") console.error("Invalid file signature.");
	let oggs = 0;
	let header = "";
	while (header.length < arrayBuffer.byteLength) {
		const page = String.fromCharCode(...new Uint8Array(arrayBuffer, header.length, Math.min(4096, arrayBuffer.byteLength - header.length)));
		if (page.match("OggS\0")) oggs++;
		header += page;
		if (oggs > 1) break;
	}
	let workflow;
	let prompt;
	const prompt_s = readVorbisCommentJson(header, "prompt");
	if (prompt_s) try {
		prompt = parseJsonWithNonFinite(prompt_s);
	} catch (e) {
		console.error("Failed to parse Ogg prompt metadata", e);
	}
	const workflow_s = readVorbisCommentJson(header, "workflow");
	if (workflow_s) try {
		workflow = parseJsonWithNonFinite(workflow_s);
	} catch (e) {
		console.error("Failed to parse Ogg workflow metadata", e);
	}
	return {
		prompt,
		workflow
	};
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.ogg = window.comfyAPI.ogg || {};
window.comfyAPI.ogg.getOggMetadata = getOggMetadata;
//#endregion
//#region src/scripts/metadata/svg.ts
async function getSvgMetadata(file) {
	const text = await file.text();
	const metadataMatch = /<metadata>\s*<!\[CDATA\[([\s\S]*?)\]\]>\s*<\/metadata>/i.exec(text);
	if (metadataMatch && metadataMatch[1]) try {
		return parseJsonWithNonFinite(metadataMatch[1].trim());
	} catch (error) {
		console.error("Error parsing SVG metadata:", error);
		return {};
	}
	return {};
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.svg = window.comfyAPI.svg || {};
window.comfyAPI.svg.getSvgMetadata = getSvgMetadata;
//#endregion
//#region src/scripts/metadata/parser.ts
async function getWorkflowDataFromFile(file) {
	if (file.type === "image/png") return await getFromPngFile(file);
	if (file.type === "image/avif") return await getFromAvifFile(file);
	if (file.type === "image/webp") {
		const pngInfo = await getFromWebpFile(file);
		return {
			workflow: pngInfo.workflow || pngInfo.Workflow,
			prompt: pngInfo.prompt || pngInfo.Prompt
		};
	}
	if (file.type === "audio/mpeg") return await getMp3Metadata(file);
	if (file.type === "audio/ogg") return await getOggMetadata(file);
	if (file.type === "audio/flac" || file.type === "audio/x-flac") {
		const pngInfo = await getFromFlacFile(file);
		return {
			workflow: pngInfo.workflow || pngInfo.Workflow,
			prompt: pngInfo.prompt || pngInfo.Prompt
		};
	}
	if (file.type === "video/webm") return await getFromWebmFile(file);
	if (file.name.endsWith(".mp4") || file.name.endsWith(".mov") || file.name.endsWith(".m4v") || file.type === "video/mp4" || file.type === "video/quicktime" || file.type === "video/x-m4v") return await getFromIsobmffFile(file);
	if (file.type === "image/svg+xml" || file.name.endsWith(".svg")) return await getSvgMetadata(file);
	if (file.type === "model/gltf-binary" || file.name.endsWith(".glb")) return await getGltfBinaryMetadata(file);
	if (file.name.endsWith(".latent") || file.name.endsWith(".safetensors")) return await getFromLatentFile(file);
	if (file.type === "application/json" || file.name.endsWith(".json")) return getDataFromJSON(file);
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.parser = window.comfyAPI.parser || {};
window.comfyAPI.parser.getWorkflowDataFromFile = getWorkflowDataFromFile;
//#endregion
//#region src/workbench/eventHelpers.ts
/**
* Utility functions for handling workbench events
*/
function activeTextSelection() {
	const selection = window.getSelection();
	return selection !== null && !selection.isCollapsed ? selection : null;
}
function hasTextSelection(target) {
	if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) {
		if (target.selectionStart !== null && target.selectionEnd !== null && target.selectionStart !== target.selectionEnd) return true;
	}
	return activeTextSelection() !== null;
}
function rangesOf(selection) {
	return Array.from({ length: selection.rangeCount }, (_, i) => selection.getRangeAt(i));
}
/**
* Collapse a text selection unless every range lies wholly inside
* `container`, the way a plain mousedown would before the canvas called
* `preventDefault()` on it. A copy or paste that follows a click on the graph
* then reaches the graph instead of the stale selection.
*/
function collapseTextSelectionOutside(container) {
	const selection = activeTextSelection();
	if (selection && rangesOf(selection).some((range) => !container.contains(range.startContainer) || !container.contains(range.endContainer))) selection.removeAllRanges();
}
function collapseOutsideSelectionOnPrimaryPointerDown(event) {
	if (event.button === 0 && event.target instanceof Element) collapseTextSelectionOutside(event.target);
}
/**
* Used by clipboard handlers to determine if copy/paste events should be
* intercepted for graph operations vs. allowing default browser behavior
* for text inputs and other UI elements.
*
* @param target - The event target to check
* @returns true if copy paste events will be handled by target
*/
function shouldIgnoreCopyPaste(target) {
	return target instanceof HTMLTextAreaElement || target instanceof HTMLElement && target.isContentEditable || target instanceof HTMLInputElement && ![
		"button",
		"checkbox",
		"file",
		"hidden",
		"image",
		"radio",
		"range",
		"reset",
		"submit"
	].includes(target.type) || useCanvasStore().linearMode || activeTextSelection() !== null;
}
//#endregion
//#region src/composables/useCopy.ts
var metadataHtmlPrefix = "<meta charset=\"utf-8\"><div><span data-comfy-metadata=\"";
var legacyMetadataHtmlPrefix = "<meta charset=\"utf-8\"><div><span data-metadata=\"";
var metadataHtmlSuffix = "\"></span></div><span style=\"white-space:pre-wrap;\">Text</span>";
var chromiumHtmlWrappers = [
	{
		before: "",
		after: ""
	},
	{
		before: "<meta charset='utf-8'>",
		after: ""
	},
	{
		before: "<html>\r\n<body>\r\n<!--StartFragment-->",
		after: "<!--EndFragment-->\r\n</body>\r\n</html>"
	}
];
function clipboardHtml(base64Data) {
	return `${metadataHtmlPrefix}${base64Data}${metadataHtmlSuffix}`;
}
function between(text, before, after) {
	if (!text.startsWith(before) || !text.endsWith(after)) return void 0;
	return text.slice(before.length, text.length - after.length);
}
function readMetadata(html) {
	return chromiumHtmlWrappers.flatMap(({ before, after }) => [metadataHtmlPrefix, legacyMetadataHtmlPrefix].map((prefix) => between(html, before + prefix, metadataHtmlSuffix + after))).find((base64Data) => base64Data !== void 0);
}
var clipboardByteChunkSize = 32768;
function bytesToBinaryString(bytes) {
	const chunks = [];
	for (let offset = 0; offset < bytes.length; offset += clipboardByteChunkSize) chunks.push(String.fromCharCode(...bytes.subarray(offset, offset + clipboardByteChunkSize)));
	return chunks.join("");
}
function encodeClipboardData(data) {
	return btoa(bytesToBinaryString(new TextEncoder().encode(data)));
}
function parseClipboardHtml(html) {
	const base64Data = readMetadata(html);
	if (!base64Data) return { status: "absent" };
	try {
		const bytes = Uint8Array.from(atob(base64Data), (c) => c.charCodeAt(0));
		const text = new TextDecoder().decode(bytes);
		return {
			status: "read",
			text,
			payload: JSON.parse(text)
		};
	} catch (cause) {
		return {
			status: "unreadable",
			cause
		};
	}
}
/**
* Adds a handler on copy that serializes selected nodes to JSON
*/
var useCopy = () => {
	const canvasStore = useCanvasStore();
	let keyboardCopyId = null;
	useEventListener(document, "copy", (e) => {
		if (shouldIgnoreCopyPaste(e.target)) {
			if (keyboardCopyId !== null && hasTextSelection(e.target) && localStorage.getItem("litegrapheditor_clipboard_id") === keyboardCopyId) {
				localStorage.removeItem(CANVAS_CLIPBOARD_KEY);
				localStorage.removeItem(CANVAS_CLIPBOARD_ID_KEY);
				keyboardCopyId = null;
			}
			return;
		}
		const canvas = canvasStore.canvas;
		if (canvas?.selectedItems) {
			const serializedData = canvas.copyToClipboard();
			keyboardCopyId = localStorage.getItem(CANVAS_CLIPBOARD_ID_KEY);
			try {
				const base64Data = encodeClipboardData(serializedData);
				e.clipboardData?.setData("text/html", clipboardHtml(base64Data));
			} catch (error) {
				reportError(error, {
					errorType: "error_writing_clipboard_metadata",
					surface: "graph"
				});
			}
			e.preventDefault();
			e.stopImmediatePropagation();
			return false;
		}
	});
};
//#endregion
//#region src/composables/usePaste.ts
function cloneDataTransfer(original) {
	const persistent = new DataTransfer();
	for (const type of original.types) {
		const data = original.getData(type);
		if (data) persistent.setData(type, data);
	}
	for (const item of original.items) if (item.kind === "file") {
		const file = item.getAsFile();
		if (file) persistent.items.add(file);
	}
	persistent.dropEffect = original.dropEffect;
	persistent.effectAllowed = original.effectAllowed;
	return persistent;
}
function pasteClipboardItems(data) {
	const parsed = parseClipboardHtml(data.getData("text/html"));
	if (parsed.status === "absent") return false;
	if (parsed.status === "unreadable") {
		useErrorHandling().toastErrorHandler(parsed.cause);
		return true;
	}
	const clipboardItems = zClipboardItems.safeParse(parsed.payload);
	if (!clipboardItems.success) {
		useErrorHandling().toastErrorHandler(clipboardItems.error);
		return true;
	}
	try {
		useCanvasStore().getCanvas()._deserializeItems(clipboardItems.data, {});
	} catch (err) {
		useErrorHandling().toastErrorHandler(err);
	}
	return true;
}
function holdsLatestCanvasCopy(html) {
	const parsed = parseClipboardHtml(html);
	if (parsed.status !== "read") return false;
	try {
		return parsed.text === localStorage.getItem(CANVAS_CLIPBOARD_KEY);
	} catch {
		return false;
	}
}
function isWorkflow(value) {
	return typeof value === "object" && value !== null && "version" in value && (typeof value.version === "number" || typeof value.version === "string") && "nodes" in value && Array.isArray(value.nodes) && "extra" in value && typeof value.extra === "object" && value.extra !== null && !Array.isArray(value.extra);
}
function pasteItemsOnNode(items, node, contentType) {
	if (!node) return;
	const filteredItems = Array.from(items).filter((item) => item.type.startsWith(contentType));
	const blob = filteredItems[0]?.getAsFile();
	if (!blob) return;
	node.pasteFile?.(blob);
	node.pasteFiles?.(Array.from(filteredItems).map((i) => i.getAsFile()).filter((f) => f !== null));
}
async function pasteImageNode(canvas, items, imageNode = null) {
	if (!imageNode) imageNode = await createNode(canvas, "LoadImage");
	pasteItemsOnNode(items, imageNode, "image");
	return imageNode;
}
async function pasteImageNodes(canvas, fileList) {
	const nodes = [];
	for (const file of fileList) {
		const transfer = new DataTransfer();
		transfer.items.add(file);
		const imageNode = await pasteImageNode(canvas, transfer.items);
		if (imageNode) nodes.push(imageNode);
	}
	return nodes;
}
async function pasteAudioNode(canvas, items, audioNode = null) {
	if (!audioNode) audioNode = await createNode(canvas, "LoadAudio");
	pasteItemsOnNode(items, audioNode, "audio");
	return audioNode;
}
async function pasteAudioNodes(canvas, fileList) {
	const nodes = [];
	for (const file of fileList) {
		const transfer = new DataTransfer();
		transfer.items.add(file);
		const node = await pasteAudioNode(canvas, transfer.items);
		if (node) nodes.push(node);
	}
	return nodes;
}
async function pasteVideoNode(canvas, items, videoNode = null) {
	if (!videoNode) videoNode = await createNode(canvas, "LoadVideo");
	pasteItemsOnNode(items, videoNode, "video");
	return videoNode;
}
async function pasteVideoNodes(canvas, fileList) {
	const nodes = [];
	for (const file of fileList) {
		const transfer = new DataTransfer();
		transfer.items.add(file);
		const node = await pasteVideoNode(canvas, transfer.items);
		if (node) nodes.push(node);
	}
	return nodes;
}
/**
* Adds a handler on paste that extracts and loads images or workflows from pasted JSON data
*/
var usePaste = () => {
	const workspaceStore = useWorkspaceStore();
	const canvasStore = useCanvasStore();
	useEventListener(document, "paste", async (e) => {
		if (e.defaultPrevented) return;
		if (shouldIgnoreCopyPaste(e.target)) return;
		if (workspaceStore.shiftDown) return;
		const { canvas } = canvasStore;
		if (!canvas || isSelectOnly(canvas)) return;
		let data = e.clipboardData;
		if (!data) {
			console.error("No clipboard data on clipboard event");
			return;
		}
		data = cloneDataTransfer(data);
		const { items } = data;
		const currentNode = canvas.current_node;
		const isNodeSelected = currentNode?.is_selected;
		const isImageNodeSelected = isNodeSelected && isImageNode(currentNode);
		const isVideoNodeSelected = isNodeSelected && isVideoNode(currentNode);
		const isAudioNodeSelected = isNodeSelected && isAudioNode(currentNode);
		const audioNode = isAudioNodeSelected ? currentNode : null;
		const imageNode = isImageNodeSelected ? currentNode : null;
		const videoNode = isVideoNodeSelected ? currentNode : null;
		for (const item of items) if (item.type.startsWith("image/")) {
			await pasteImageNode(canvas, items, imageNode);
			return;
		} else if (item.type.startsWith("video/")) {
			await pasteVideoNode(canvas, items, videoNode);
			return;
		} else if (item.type.startsWith("audio/")) {
			await pasteAudioNode(canvas, items, audioNode);
			return;
		}
		const isMediaNodeSelected = isImageNodeSelected || isVideoNodeSelected || isAudioNodeSelected;
		if (!isMediaNodeSelected && pasteClipboardItems(data)) return;
		const html = data.getData("text/html");
		data = data.getData("text/plain");
		let workflow;
		try {
			data = data.slice(data.indexOf("{"));
			workflow = JSON.parse(data);
		} catch {
			try {
				data = data.slice(data.indexOf("workflow\n"));
				data = data.slice(data.indexOf("{"));
				workflow = JSON.parse(data);
			} catch {
				workflow = null;
			}
		}
		if (isWorkflow(workflow)) await useApp().loadGraphData(workflow);
		else {
			if (e.target instanceof HTMLTextAreaElement && e.target.type === "textarea" || e.target instanceof HTMLInputElement && e.target.type === "text") return;
			if (!isMediaNodeSelected || holdsLatestCanvasCopy(html)) canvas.pasteFromClipboard();
			else useToast().info(t("toastMessages.nothingToPasteIntoNode"), { duration: 3e3 });
		}
	});
};
//#endregion
//#region src/scripts/app.ts
function isMeshModelFile(file) {
	const name = file.name.toLowerCase();
	return SUPPORTED_MESH_EXTENSIONS.has(name.slice(name.lastIndexOf(".")));
}
function sanitizeNodeName(string) {
	const entityMap = {
		"&": "",
		"<": "",
		">": "",
		"\"": "",
		"'": "",
		"`": "",
		"=": ""
	};
	return string.replace(/[&<>"'`=]/g, function fromEntityMap(s) {
		return entityMap[s];
	});
}
function syncPromotedComboHostOptions(rootGraph) {
	const widgetValueStore = useWidgetValueStore();
	forEachNode(rootGraph, (node) => {
		if (!node.isSubgraphNode()) return;
		for (const input of node.inputs) {
			if (!input.widgetId) continue;
			const source = promotedInputSource(node, input);
			if (!source) continue;
			const resolution = resolveConcretePromotedWidget(node, source.nodeId, source.widgetName);
			if (resolution.status !== "resolved") continue;
			const sourceWidget = resolution.resolved.widget;
			if (sourceWidget.type !== "combo") continue;
			const state = widgetValueStore.getWidget(input.widgetId);
			if (!state) continue;
			state.options = { ...sourceWidget.options };
		}
	});
}
function createNodeOutputsMutationView(outputs, commit) {
	const views = /* @__PURE__ */ new WeakMap();
	const wrapNestedValue = (id, value) => {
		if (value === null || typeof value !== "object") return value;
		const existing = views.get(value)?.get(id);
		if (existing) return existing;
		const view = createMutationView(value, {
			commit: () => commit(id, outputs[id]),
			mapValue: (_property, nestedValue) => wrapNestedValue(id, nestedValue)
		});
		const viewsById = views.get(value) ?? /* @__PURE__ */ new Map();
		viewsById.set(id, view);
		views.set(value, viewsById);
		return view;
	};
	return new Proxy(outputs, {
		get(target, property) {
			const value = Reflect.get(target, property, target);
			if (typeof value === "function") return value.bind(target);
			return wrapNestedValue(String(property), value);
		},
		set(target, property, value) {
			const previous = Reflect.get(target, property, target);
			const updated = Reflect.set(target, property, value, target);
			if (updated && previous !== value) commit(String(property), value);
			return updated;
		},
		deleteProperty(target, property) {
			const existed = Reflect.has(target, property);
			const deleted = Reflect.deleteProperty(target, property);
			if (deleted && existed) commit(String(property), void 0);
			return deleted;
		}
	});
}
function toNodeDefs(response) {
	const translateNodeDef = (def) => {
		return {
			...def,
			category: (typeof def.category === "string" ? def.category : "").split("/").map((category) => st(`nodeCategories.${normalizeI18nKey(category)}`, category)).join("/")
		};
	};
	const isNodeDef = (value) => typeof value === "object" && value !== null && typeof value.name === "string";
	const entries = typeof response === "object" && response !== null && !Array.isArray(response) ? Object.entries(response) : [];
	const defs = Object.fromEntries(entries.filter((entry) => isNodeDef(entry[1])));
	setBackendNodeText(Object.values(defs));
	return toolkit.mapValues(defs, (def) => translateNodeDef(def));
}
var ComfyApp = class ComfyApp {
	/**
	* List of entries to queue
	*/
	queueItems = [];
	nextQueueRequestId = 1;
	/**
	* If the queue is currently being processed
	*/
	processingQueue = false;
	/**
	* Content Clipboard, kept as statics for custom-node compatibility.
	* State lives in `@/scripts/clipspace`.
	*/
	static get clipspace() {
		return clipspace.current;
	}
	static set clipspace(value) {
		clipspace.current = value;
	}
	static get clipspace_invalidate_handler() {
		return clipspace.invalidateHandler;
	}
	static set clipspace_invalidate_handler(value) {
		clipspace.invalidateHandler = value;
	}
	static get clipspace_return_node() {
		return clipspace.returnNode;
	}
	static set clipspace_return_node(value) {
		clipspace.returnNode = value;
	}
	static open_maskeditor = null;
	static get maskeditor_is_opended() {
		return clipspace.maskEditorIsOpened;
	}
	static set maskeditor_is_opended(value) {
		clipspace.maskEditorIsOpened = value;
	}
	static copyToClipspace = copyToClipspace;
	static pasteFromClipspace = pasteFromClipspace;
	vueAppReady;
	api;
	ui;
	extensionManager;
	nodeOutputsData = {};
	_nodeOutputs = createNodeOutputsMutationView(this.nodeOutputsData, (id, output) => {
		if (!this.vueAppReady) return;
		const store = useNodeOutputStore();
		if (output === void 0) store.removeOutputFromLegacy(id);
		else store.setOutputFromLegacy(id, output);
	});
	nodePreviewImages;
	rootGraphRef = shallowRef(void 0);
	get rootGraphInternal() {
		return this.rootGraphRef.value;
	}
	set rootGraphInternal(graph) {
		this.rootGraphRef.value = graph;
	}
	/** @deprecated Use {@link rootGraph} instead */
	get graph() {
		return this.rootGraphInternal;
	}
	get rootGraph() {
		if (!this.rootGraphInternal) console.error("ComfyApp graph accessed before initialization");
		return this.rootGraphInternal;
	}
	get rootGraphOrUndefined() {
		return this.rootGraphInternal;
	}
	/**
	* Whether the root graph has been initialized. Safe to check without
	* triggering error logs, and reactive, so it can be watched.
	*/
	get isGraphReady() {
		return !!this.rootGraphInternal;
	}
	canvasInternal;
	/** The canvas, once {@link setup} has created it. Accessing it earlier is a bug. */
	get canvas() {
		return this.canvasInternal;
	}
	set canvas(value) {
		this.canvasInternal = value;
	}
	/** Same as {@link canvas}, but `undefined` before {@link setup} creates it. */
	get canvasOrUndefined() {
		return this.canvasInternal;
	}
	dragOverNode = null;
	canvasElRef = shallowRef();
	get canvasEl() {
		return unref(this.canvasElRef);
	}
	configuringGraphLevel = 0;
	graphLoadSequence = 0;
	graphLoadQueue = Promise.resolve();
	pendingCamera;
	get configuringGraph() {
		return this.configuringGraphLevel > 0;
	}
	ctx;
	bodyTop;
	bodyLeft;
	bodyRight;
	bodyBottom;
	canvasContainer;
	menu;
	openClipspace = () => {};
	positionConversion;
	/**
	* The node errors from the previous execution.
	* @deprecated Use app.extensionManager.lastNodeErrors instead
	*/
	get lastNodeErrors() {
		return useExecutionErrorStore().lastNodeErrors;
	}
	/**
	* The error from the previous execution.
	* @deprecated Use app.extensionManager.lastExecutionError instead
	*/
	get lastExecutionError() {
		return useExecutionErrorStore().lastExecutionError;
	}
	/**
	* @deprecated Use useExecutionStore().executingNodeId instead
	* TODO: Update to support multiple executing nodes. This getter returns only the first executing node.
	* Consider updating consumers to handle multiple nodes or use executingNodeIds array.
	*/
	get runningNodeId() {
		return useExecutionStore().executingNodeId;
	}
	/**
	* @deprecated Use useWorkspaceStore().shiftDown instead
	*/
	get shiftDown() {
		return useWorkspaceStore().shiftDown;
	}
	/**
	* @deprecated Use useWidgetStore().widgets instead
	*/
	get widgets() {
		const widgetStore = useWidgetStore();
		return Object.assign(Object.fromEntries(widgetStore.widgets.entries()), widgetStore.coreWidgets);
	}
	/**
	* @deprecated storageLocation is always 'server' since
	* https://github.com/comfyanonymous/ComfyUI/commit/53c8a99e6c00b5e20425100f6680cd9ea2652218
	*/
	get storageLocation() {
		return "server";
	}
	/**
	* @deprecated storage migration is no longer needed.
	*/
	get isNewUserSession() {
		return false;
	}
	/**
	* @deprecated Use useExtensionStore().extensions instead
	*/
	get extensions() {
		return useExtensionStore().extensions;
	}
	/**
	* The progress on the current executing node, if the node reports any.
	* @deprecated Use useExecutionStore().executingNodeProgress instead
	*/
	get progress() {
		return useExecutionStore()._executingNodeProgress;
	}
	/**
	* @deprecated Use {@link isImageNode} from @/utils/litegraphUtil instead
	*/
	static isImageNode(node) {
		return isImageNode(node);
	}
	/**
	* Resets the canvas view to the default
	* @deprecated Use {@link useLitegraphService().resetView} instead
	*/
	resetView() {
		useLitegraphService().resetView();
	}
	constructor() {
		this.vueAppReady = false;
		this.api = api;
		this.nodeOutputs = {};
		this.nodePreviewImages = {};
	}
	get nodeOutputs() {
		return this._nodeOutputs;
	}
	set nodeOutputs(value) {
		if (value !== this._nodeOutputs) {
			for (const key of Object.keys(this.nodeOutputsData)) delete this.nodeOutputsData[key];
			Object.assign(this.nodeOutputsData, value);
		}
		if (this.vueAppReady) {
			useNodeOutputStore().replaceOutputsFromLegacy(this.nodeOutputsData);
			useExtensionService().invokeExtensions("onNodeOutputsUpdated", value);
		}
	}
	/**
	* If the user has specified a preferred format to receive preview images in,
	* this function will return that format as a url query param.
	* If the node's outputs are not images, this param should not be used, as it will
	* force the server to load the output file as an image.
	*/
	getPreviewFormatParam() {
		const preview_format = useSettingStore().get("Comfy.PreviewFormat");
		if (preview_format) return `&preview=${preview_format}`;
		else return "";
	}
	getRandParam() {
		return "&rand=" + Math.random();
	}
	static onClipspaceEditorSave() {
		if (clipspace.returnNode) ComfyApp.pasteFromClipspace(clipspace.returnNode);
	}
	static onClipspaceEditorClosed() {
		clipspace.returnNode = null;
	}
	/**
	* Adds a handler allowing drag+drop of files onto the window to load workflows
	*/
	addDropHandler() {
		useEventListener(document, "drop", async (event) => {
			try {
				if (event.defaultPrevented) return;
				event.preventDefault();
				event.stopPropagation();
				const canvas = this.canvas;
				canvas.adjustMouseEvent(event);
				canvas.graph_mouse[0] = event.canvasX;
				canvas.graph_mouse[1] = event.canvasY;
				const n = this.dragOverNode;
				this.dragOverNode = null;
				if (isSelectOnly(canvas)) return;
				if (await n?.onDragDrop?.(event)) return;
				const files = await extractFilesFromDragEvent(event);
				if (files.length === 0) {
					if (event.dataTransfer?.types.includes("application/x-comfy-asset-info")) {
						reportError(/* @__PURE__ */ new Error("Dropped asset card yielded no file"), {
							surface: "graph",
							errorType: "asset_drop_load_failure"
						});
						useToast().warning(t("toastMessages.assetDropFailed"));
					}
					return;
				}
				const workspace = useWorkspaceStore();
				try {
					workspace.spinner = true;
					const imageFiles = files.filter(hasImageType);
					const audioFiles = files.filter(hasAudioType);
					const videoFiles = files.filter(hasVideoType);
					const hasMultipleMedia = imageFiles.length + audioFiles.length + videoFiles.length > 1;
					const createdNodes = [];
					const handleFileOptions = {
						deferWarnings: true,
						onNodeCreated: (node) => createdNodes.push(node)
					};
					if (hasMultipleMedia) {
						if (imageFiles.length > 0) await this.handleFileList(imageFiles);
						if (audioFiles.length > 0) await this.handleAudioFileList(audioFiles);
						if (videoFiles.length > 0) await this.handleVideoFileList(videoFiles);
						for (const file of files.filter((f) => !isMediaFile(f))) await this.handleFile(file, "file_drop", handleFileOptions);
					} else for (const file of files) await this.handleFile(file, "file_drop", handleFileOptions);
					this.positionNodes(createdNodes);
				} finally {
					workspace.spinner = false;
				}
				useWorkflowService().showPendingWarnings();
			} catch (error) {
				useToast().warning(t("toastMessages.dropFileError", { error: getErrorMessage(error) ?? t("g.unknownError") }));
			}
		});
		useEventListener(this.canvasElRef, "dragleave", async () => {
			if (!this.dragOverNode) return;
			this.dragOverNode = null;
			this.canvas.setDirty(false, true);
		});
		useEventListener(this.canvasElRef, "dragover", (event) => {
			const canvas = this.canvas;
			canvas.adjustMouseEvent(event);
			const node = canvas.graph?.getNodeOnPos(event.canvasX, event.canvasY);
			if (!node?.onDragOver?.(event)) {
				this.dragOverNode = null;
				return;
			}
			this.dragOverNode = node;
			requestAnimationFrame(() => {
				this.canvas.setDirty(false, true);
			});
		}, false);
	}
	/**
	* Handle keypress
	*/
	addProcessKeyHandler() {
		const origProcessKey = LGraphCanvas.prototype.processKey;
		LGraphCanvas.prototype.processKey = function(e) {
			if (!this.graph) return;
			if (e.target instanceof Element && e.target.localName == "input") return;
			if (useKeybindingService().executeCanvasKeybinding(e)) {
				this.graph.change();
				return;
			}
			return origProcessKey.apply(this, [e]);
		};
	}
	/**
	* Handles updates from the API socket
	*/
	addApiUpdateHandlers() {
		api.addEventListener("status", ({ detail }) => {
			this.ui.setStatus(detail);
		});
		api.addEventListener("progress", () => {
			this.canvas.setDirty(true, false);
		});
		api.addEventListener("executing", () => {
			this.canvas.setDirty(true, false);
		});
		api.addEventListener("executed", ({ detail }) => {
			if (!useExecutionStore().belongsToActiveWorkflow(detail.prompt_id)) return;
			const nodeOutputStore = useNodeOutputStore();
			const executionId = tryNormalizeNodeExecutionId(detail.display_node || detail.node);
			if (!executionId) return;
			nodeOutputStore.setNodeOutputsByExecutionId(executionId, detail.output, { merge: detail.merge });
			const node = getNodeByExecutionId(this.rootGraph, executionId);
			if (node && node.onExecuted) node.onExecuted(detail.output);
		});
		api.addEventListener("execution_start", () => {
			triggerCallbackOnAllNodes(this.rootGraph, "onExecutionStart");
		});
		api.addEventListener("execution_error", ({ detail }) => {
			const precondition = resolveAccountPrecondition({
				exceptionType: detail.exception_type,
				exceptionMessage: detail.exception_message
			});
			if (precondition) useAccountPreconditionDialog().open(precondition, { nodeType: detail.node_type });
			this.canvas.draw(true, true);
		});
		api.addEventListener("b_preview_with_metadata", ({ detail }) => {
			const { blob, displayNodeId, jobId } = detail;
			const { setNodePreviewsByExecutionId, revokePreviewsByExecutionId } = useNodeOutputStore();
			const displayNodeExecutionId = tryNormalizeNodeExecutionId(displayNodeId);
			if (!displayNodeExecutionId) return;
			const blobUrl = createSharedObjectUrl(blob);
			useJobPreviewStore().setPreviewUrl(jobId, blobUrl, displayNodeId);
			if (!useExecutionStore().belongsToActiveWorkflow(jobId)) {
				releaseSharedObjectUrl(blobUrl);
				return;
			}
			revokePreviewsByExecutionId(displayNodeExecutionId);
			for (const executionId of getAncestorExecutionIds(displayNodeExecutionId)) setNodePreviewsByExecutionId(executionId, [blobUrl]);
			releaseSharedObjectUrl(blobUrl);
		});
		api.addEventListener("feature_flags", () => {
			useNodeReplacementStore().load();
		});
		api.init();
	}
	/** Flag that the graph is configuring to prevent nodes from running checks while its still loading */
	addConfigureHandler() {
		const configure = LGraph.prototype.configure;
		const trackConfiguring = (run) => {
			this.configuringGraphLevel++;
			try {
				return run();
			} finally {
				this.configuringGraphLevel--;
			}
		};
		LGraph.prototype.configure = function(...args) {
			return trackConfiguring(() => configure.apply(this, args));
		};
	}
	addAfterConfigureHandler(graph) {
		const { onConfigure } = graph;
		graph.onConfigure = function(...args) {
			triggerCallbackOnAllNodes(this, "onGraphConfigured");
			const r = onConfigure?.apply(this, args);
			triggerCallbackOnAllNodes(this, "onAfterGraphConfigured");
			return r;
		};
	}
	/**
	* Set up the app on the page
	*/
	async setup(canvasEl) {
		this.bodyTop = document.getElementById("comfyui-body-top");
		this.bodyLeft = document.getElementById("comfyui-body-left");
		this.bodyRight = document.getElementById("comfyui-body-right");
		this.bodyBottom = document.getElementById("comfyui-body-bottom");
		this.canvasContainer = document.getElementById("graph-canvas-container");
		this.canvasElRef.value = canvasEl;
		await bootstrapTracer.settle("bootstrap/sync-workflows", () => useWorkspaceStore().workflow.syncWorkflows());
		useSubgraphStore().fetchSubgraphs();
		this.addProcessKeyHandler();
		this.addConfigureHandler();
		this.addApiUpdateHandlers();
		const graph = new LGraph();
		graph.events.addEventListener("subgraph-created", (e) => {
			try {
				const { subgraph, data } = e.detail;
				useSubgraphService().registerNewSubgraph(subgraph, data);
			} catch (err) {
				console.error("Failed to register subgraph", err);
				useToast().error(t("toastMessages.failedToRegisterSubgraph"), { description: getErrorMessage(err) ?? t("g.unknownError") });
			}
		});
		this.addAfterConfigureHandler(graph);
		this.rootGraphInternal = graph;
		installNodeAddedTelemetry(graph);
		const interactionMode = createCanvasInteractionMode();
		this.canvas = new LGraphCanvas(canvasEl, graph, { interactionMode });
		useCommandStore().setInteractionMode(interactionMode);
		this.canvas.state = reactive(this.canvas.state);
		this.ctx = canvasEl.getContext("2d");
		LiteGraph.alt_drag_do_clone_nodes = true;
		LiteGraph.macGesturesRequireMac = false;
		this.canvas.canvas.addEventListener("litegraph:set-graph", (e) => {
			const { newGraph } = e.detail;
			const widgetStore = useDomWidgetStore();
			const activeWidgets = Object.fromEntries(newGraph.nodes.flatMap((node) => node.widgets ?? []).filter((w) => w instanceof DOMWidgetImpl || w instanceof ComponentWidgetImpl).map((w) => [w.id, w]));
			for (const [widgetId, widgetState] of widgetStore.widgetStates.entries()) if (widgetId in activeWidgets) {
				widgetState.active = true;
				widgetState.widget = activeWidgets[widgetId];
			} else widgetState.active = false;
		});
		this.canvas.canvas.addEventListener("litegraph:set-graph", (e) => {
			const { newGraph, oldGraph } = e.detail;
			if (oldGraph) ensureCorrectLayoutScale(newGraph.extra.workflowRendererVersion, newGraph);
		});
		this.rootGraph.start();
		useResizeObserver(this.canvasElRef, ([canvasEl]) => {
			if (canvasEl.target instanceof HTMLCanvasElement) this.resizeCanvas(canvasEl.target);
		});
		await bootstrapTracer.settle("bootstrap/extensions-init", () => useExtensionService().invokeExtensionsAsync("init"));
		await this.registerNodes();
		this.addDropHandler();
		await bootstrapTracer.settle("bootstrap/extensions-setup", () => useExtensionService().invokeExtensionsAsync("setup"));
		this.positionConversion = useCanvasPositionConversion(this.canvasContainer, this.canvas);
	}
	resizeCanvas(canvas) {
		const viewport = measureViewportFromElement(canvas);
		applyViewport(viewport, canvas, this.canvas.bgcanvas, this.canvas);
		useCanvasScheduler().flush();
		this.canvas.draw(true, true);
	}
	updateVueAppNodeDefs(defs) {
		const frontendOnlyDefs = {};
		for (const [name, node] of Object.entries(LiteGraph.registered_node_types)) {
			if (name in defs || name in SYSTEM_NODE_DEFS || node.skip_list) continue;
			frontendOnlyDefs[name] = {
				name,
				display_name: name,
				category: node.category || "__frontend_only__",
				input: {
					required: {},
					optional: {}
				},
				output: [],
				output_name: [],
				output_is_list: [],
				output_node: false,
				python_module: "custom_nodes.frontend_only",
				description: node.description ?? `Frontend only node for ${name}`
			};
		}
		const allNodeDefs = {
			...frontendOnlyDefs,
			...defs,
			...SYSTEM_NODE_DEFS
		};
		const nodeDefStore = useNodeDefStore();
		const nodeDefArray = Object.values(allNodeDefs);
		useExtensionService().invokeExtensions("beforeRegisterVueAppNodeDefs", nodeDefArray);
		nodeDefStore.updateNodeDefs(nodeDefArray);
	}
	async getNodeDefs() {
		return toNodeDefs(await api.getNodeDefs());
	}
	/** Fetches the node definitions, or the HTTP status when the server refused, instead of reading the refusal as definitions. */
	async fetchNodeDefs() {
		const response = await api.fetchNodeDefs();
		if (!response.ok) return {
			ok: false,
			status: response.status
		};
		return {
			ok: true,
			defs: toNodeDefs(await response.json())
		};
	}
	/**
	* Registers nodes with the graph
	*/
	async registerNodes() {
		const defs = await bootstrapTracer.settle("bootstrap/object-info", () => this.getNodeDefs());
		await bootstrapTracer.settle("bootstrap/extensions", async () => {
			await this.registerNodesFromDefs(defs);
			await useExtensionService().invokeExtensionsAsync("registerCustomNodes");
		});
		if (this.vueAppReady) {
			const phase = bootstrapTracer.startPhase("bootstrap/vue-node-defs");
			try {
				this.updateVueAppNodeDefs(defs);
			} finally {
				phase.stop();
			}
		}
	}
	async registerNodeDef(nodeId, nodeDef) {
		return await useLitegraphService().registerNodeDef(nodeId, nodeDef);
	}
	async registerNodesFromDefs(defs) {
		await useExtensionService().invokeExtensionsAsync("addCustomNodeDefs", defs);
		await Promise.all(Object.keys(defs).map((nodeId) => this.registerNodeDef(nodeId, defs[nodeId])));
	}
	loadTemplateData(templateData) {
		if (!templateData.templates) return;
		const old = localStorage.getItem("litegrapheditor_clipboard");
		for (const template of templateData.templates) {
			if (!template.data) continue;
			if (!parseJsonWithNonFinite(template.data).reroutes) deserialiseAndCreate(template.data, app.canvas);
			else {
				localStorage.setItem("litegrapheditor_clipboard", template.data);
				app.canvas.pasteFromClipboard();
			}
			let maxY;
			for (const node of selectedCanvasNodes(app.canvas)) {
				const nodeBottom = node.pos[1] + node.size[1];
				if (maxY === void 0 || nodeBottom > maxY) maxY = nodeBottom;
			}
			if (maxY !== void 0) app.canvas.graph_mouse[1] = maxY + 50;
		}
		if (old !== null) localStorage.setItem("litegrapheditor_clipboard", old);
	}
	showMissingNodesError(missingNodeTypes, options) {
		const activeWorkflow = useWorkspaceStore().workflow.activeWorkflow;
		updatePendingWarnings(activeWorkflow, { missingNodeTypes });
		if (!options?.deferWarnings) useWorkflowService().showPendingWarnings(activeWorkflow);
	}
	/**
	* Shared failure reporting for a graph load that cannot proceed: shows the
	* load-error dialog, logs it, and notifies `onGraphLoadError` so any
	* loading-state a `beforeLoadGraph` listener opened for this same load is
	* closed out, exactly as if `rootGraph.configure` itself had thrown.
	* Callers still decide what to return/rethrow.
	*/
	async reportGraphLoadFailure(error) {
		useDialogService().showErrorDialog(error, {
			title: t("errorDialog.loadWorkflowTitle"),
			reportType: "loadWorkflowError"
		});
		console.error(error);
		await useExtensionService().invokeExtensionsAsync("onGraphLoadError", error);
	}
	enqueueGraphLoad(operation) {
		const result = this.graphLoadQueue.then(operation);
		this.graphLoadQueue = result.then(() => void 0, () => void 0);
		return result;
	}
	async loadGraphData(graphData, clean = true, restore_view = true, workflow = null, options = {}) {
		return this.enqueueGraphLoad(() => this.loadGraphDataNow(graphData, clean, restore_view, workflow, options));
	}
	async loadGraphDataNow(graphData, clean, restore_view, workflow, options) {
		const canvasScheduler = useCanvasScheduler();
		const loadId = ++this.graphLoadSequence;
		const { checkForRerouteMigration = false, openSource, shareId, deferWarnings = false, skipAssetScans = false, silentAssetErrors = false, workflowNavigationId } = options;
		useWorkflowService().beforeLoadNewGraph(clean);
		await useExtensionService().invokeExtensionsAsync("beforeLoadGraph");
		ChangeTracker.isLoadingGraph = true;
		let reset_invalid_values = false;
		const missingNodeTypes = [];
		try {
			useExecutionErrorStore().setActiveGraph(null);
			if (skipAssetScans) {
				useMissingModelStore().createVerificationAbortController().abort();
				useMissingMediaStore().createVerificationAbortController().abort();
				useMissingModelStore().setMissingModels([]);
				useMissingMediaStore().setMissingMedia([]);
			} else {
				useMissingModelStore().clearMissingModels();
				useMissingMediaStore().clearMissingMedia();
			}
			if (clean) {
				this.canvas.setGraph(this.rootGraph);
				withGraphIntentSource("load", () => this.clean());
			}
			if (!graphData || typeof graphData !== "object" || Array.isArray(graphData)) {
				graphData = defaultGraph;
				reset_invalid_values = true;
			}
			graphData = clone(graphData);
			if (useSettingStore().get("Comfy.Validation.Workflows")) {
				const { graphData: validatedGraphData } = await useWorkflowValidation().validateWorkflow(graphData);
				graphData = validatedGraphData ?? graphData;
			}
			if (checkForRerouteMigration && graphData.version === .4 && findLegacyRerouteNodes(graphData).length && noNativeReroutes(graphData)) {
				const toast = useToast();
				const migrationToastId = toast.warning(t("toastMessages.migrateToLitegraphReroute"), { action: {
					label: t("g.migrate"),
					onClick: async () => {
						await this.loadGraphData(migrateLegacyRerouteNodes(this.rootGraph.serialize()), false, false, useWorkflowStore().activeWorkflow);
						toast.dismiss(migrationToastId);
					}
				} });
			}
			useSubgraphService().loadSubgraphs(graphData);
			await useExtensionService().invokeExtensionsAsync("beforeConfigureGraph", graphData, missingNodeTypes);
			const nodeReplacementStore = useNodeReplacementStore();
			await nodeReplacementStore.load();
			const collectMissingNodes = (nodes, pathPrefix = "", displayName = "") => {
				if (!Array.isArray(nodes)) {
					console.warn("Workflow nodes data is missing or invalid, skipping node processing", {
						nodes,
						pathPrefix
					});
					return;
				}
				for (const n of nodes) if (!(n.type in LiteGraph.registered_node_types)) {
					if (!(n.mode === LGraphEventMode.NEVER || n.mode === LGraphEventMode.BYPASS)) {
						const replacement = nodeReplacementStore.getReplacementFor(n.type);
						const cnrId = getCnrIdFromProperties(n.properties);
						const executionId = pathPrefix ? `${pathPrefix}:${n.id}` : String(n.id);
						missingNodeTypes.push({
							type: n.type,
							nodeId: executionId,
							cnrId,
							...displayName && { hint: t("g.inSubgraph", { name: displayName }) },
							isReplaceable: replacement !== null,
							replacement: replacement ?? void 0
						});
					}
					n.type = sanitizeNodeName(n.type);
				}
			};
			collectMissingNodes(graphData.nodes);
			const subgraphDefs = collectSubgraphDefinitions(parseFlattenableSubgraphDefinitions(graphData.definitions?.subgraphs ?? []));
			const subgraphContainerIdMap = buildSubgraphExecutionPaths(graphData.nodes, subgraphDefs);
			for (const subgraph of subgraphDefs) {
				const paths = subgraphContainerIdMap.get(subgraph.id) ?? [];
				for (const pathPrefix of paths) collectMissingNodes(subgraph.nodes, pathPrefix, subgraph.name || subgraph.id);
			}
		} catch (error) {
			try {
				await this.reportGraphLoadFailure(error);
			} finally {
				ChangeTracker.isLoadingGraph = false;
			}
			useSubgraphNavigationStore().updateHash("workflow-load", workflowNavigationId);
			return false;
		}
		const fitView = () => {
			const savedCameraState = normalizeCameraState(graphData.extra?.ds, {
				minScale: this.canvas.ds.min_scale,
				maxScale: this.canvas.ds.max_scale
			});
			if (restore_view && useSettingStore().get("Comfy.EnableWorkflowViewRestore")) {
				if (openSource === "template") useLitegraphService().fitView();
				else if (savedCameraState) {
					this.canvas.ds.offset = savedCameraState.offset;
					this.canvas.ds.scale = savedCameraState.scale;
					this.canvas.ds.computeVisibleArea(this.canvas.viewport);
					if (this.canvas.visible_area.width && this.canvas.visible_area.height && !anyItemOverlapsRect(this.rootGraph._nodes, this.canvas.visible_area)) useLitegraphService().fitView();
				} else useLitegraphService().fitView();
			}
		};
		let activatedWorkflow;
		let reconcileResourceErrors;
		let resourceScanLoadCompleted = false;
		try {
			try {
				this.rootGraph.configure(graphData);
				const originalMainGraphRenderer = this.rootGraph.extra.workflowRendererVersion;
				ensureCorrectLayoutScale(originalMainGraphRenderer, this.rootGraph);
				for (const subgraph of this.rootGraph.subgraphs.values()) ensureCorrectLayoutScale(subgraph.extra.workflowRendererVersion || originalMainGraphRenderer, subgraph);
				if (!(!restore_view && workflow !== null && workflow === this.pendingCamera?.workflow)) {
					canvasScheduler.cancel("graph-load-camera");
					this.pendingCamera = restore_view ? {
						id: loadId,
						workflow
					} : void 0;
					if (restore_view) canvasScheduler.schedule({
						key: "graph-load-camera",
						element: this.canvasEl,
						isCurrent: () => this.pendingCamera?.id === loadId,
						run: () => {
							const viewport = measureViewportFromElement(this.canvasEl);
							applyViewport(viewport, this.canvasEl, this.canvas.bgcanvas, this.canvas);
							fitView();
							this.canvas.draw(true, true);
							if (this.pendingCamera?.id === loadId) this.pendingCamera = void 0;
						}
					});
				}
			} catch (error) {
				await this.reportGraphLoadFailure(error);
				return false;
			}
			const configuredGraphState = this.rootGraph.state;
			const isCurrentGraphLoad = () => configuredGraphState === this.rootGraph.state;
			const cancelReplacedLoad = () => useExtensionService().invokeExtensionsAsync("onGraphLoadError", new DOMException("Workflow load was replaced", "AbortError"));
			const snapTo = LiteGraph.alwaysSnapToGrid ? this.rootGraph.getSnapToGridSize() : 0;
			withGraphIntentSource("load", () => forEachNode(this.rootGraph, (node) => {
				const size = node.computeSize();
				size[0] = Math.max(node.size[0], size[0]);
				size[1] = Math.max(node.size[1], size[1]);
				snapPoint(size, snapTo, "ceil");
				node.setSize(size);
				if (node.widgets) for (const widget of node.widgets) {
					if (node.type == "KSampler" || node.type == "KSamplerAdvanced") {
						if (widget.name == "sampler_name") {
							if (typeof widget.value === "string" && widget.value.startsWith("sample_")) widget.value = widget.value.slice(7);
						}
					}
					if (node.type == "KSampler" || node.type == "KSamplerAdvanced" || node.type == "PrimitiveNode") {
						if (widget.name == "control_after_generate") {
							if (widget.value === true) widget.value = "randomize";
							else if (widget.value === false) widget.value = "fixed";
						}
					}
					if (widget.type == "combo") {
						const values = widget.options.values;
						if (values && values.length > 0 && (widget.value == null || reset_invalid_values && !values.includes(widget.value))) widget.value = values[0];
					}
				}
				useExtensionService().invokeExtensions("loadedGraphNode", node);
			}));
			await useExtensionService().invokeExtensionsAsync("afterConfigureGraph", missingNodeTypes);
			if (!isCurrentGraphLoad()) {
				await cancelReplacedLoad();
				return;
			}
			const effectiveShareId = shareId ?? (workflow instanceof ComfyWorkflow ? workflow.shareId : void 0);
			const telemetryPayload = {
				missing_node_count: missingNodeTypes.length,
				missing_node_types: missingNodeTypes.map((node) => typeof node === "string" ? node : node.type),
				missing_node_packs: groupMissingNodesByPack(missingNodeTypes),
				open_source: openSource ?? "unknown",
				...effectiveShareId ? { share_id: effectiveShareId } : {}
			};
			useTelemetry()?.trackWorkflowOpened(telemetryPayload);
			useTelemetry()?.trackWorkflowImported(telemetryPayload);
			try {
				await useWorkflowService().afterLoadNewGraph(workflow, this.rootGraph.serialize(), effectiveShareId);
			} catch (error) {
				if (isCurrentGraphLoad()) throw error;
			}
			if (!isCurrentGraphLoad()) {
				await cancelReplacedLoad();
				return;
			}
			await useExtensionService().invokeExtensionsAsync("afterLoadGraph");
			if (!isCurrentGraphLoad()) {
				await cancelReplacedLoad();
				return;
			}
			ChangeTracker.isLoadingGraph = false;
			activatedWorkflow = useWorkflowStore().activeWorkflow ?? void 0;
			const activeMissingNodeTypes = missingNodeTypes.filter((n) => typeof n === "string" || n.nodeId == null || isAncestorPathActive(this.rootGraph, String(n.nodeId)));
			if (!skipAssetScans) {
				const errorStore = useExecutionErrorStore();
				const resourceScanKey = errorStore.captureRunErrorKey();
				let models;
				let media;
				const reconcile = () => {
					if (!resourceScanLoadCompleted || !models && !media) return;
					errorStore.retireResolvedMissingResourceErrors({
						models,
						media
					}, resourceScanKey);
				};
				reconcileResourceErrors = reconcile;
				await runMissingModelPipeline({
					graph: this.rootGraph,
					graphData,
					missingModelStore: useMissingModelStore(),
					missingNodeTypes: activeMissingNodeTypes,
					silent: silentAssetErrors,
					onVerified: (candidates) => {
						models = candidates;
						reconcile();
					}
				});
				await runMissingMediaPipeline({
					rootGraph: this.rootGraph,
					silent: silentAssetErrors,
					onVerified: (candidates) => {
						media = candidates;
						reconcile();
					}
				});
			}
			if (!deferWarnings) useWorkflowService().showPendingWarnings(void 0, { silent: silentAssetErrors });
			resourceScanLoadCompleted = true;
			requestAnimationFrame(() => {
				this.canvas.setDirty(true, true);
			});
			return activatedWorkflow ?? true;
		} finally {
			useSubgraphNavigationStore().updateHash("workflow-load", workflowNavigationId);
			ChangeTracker.isLoadingGraph = false;
			useExecutionErrorStore().retireResolvedMissingNodePromptError();
			reconcileResourceErrors?.();
		}
	}
	async refreshMissingModels(options = {}) {
		return refreshMissingModelPipeline({
			graph: this.rootGraph,
			reloadNodeDefs: options.reloadDefs === false ? void 0 : async () => {
				await this.reloadNodeDefs();
			},
			missingModelStore: useMissingModelStore(),
			silent: options.silent ?? true
		});
	}
	async graphToPrompt(graph = this.rootGraph) {
		return graphToPrompt(graph, { sortNodes: useSettingStore().get("Comfy.Workflow.SortNodeIdOnSave") });
	}
	async queuePrompt(number, batchCount = 1, optionsOrQueueNodeIds = {}) {
		const { queueNodeIds, intent } = Array.isArray(optionsOrQueueNodeIds) ? { queueNodeIds: optionsOrQueueNodeIds } : optionsOrQueueNodeIds;
		if (intent?.trigger_source === "auto_queue" && partnerRunGateBlocksAutoQueue()) return false;
		const requestId = this.nextQueueRequestId++;
		this.queueItems.push({
			number,
			batchCount,
			queueNodeIds,
			requestId,
			workflowQueueIntent: intent
		});
		api.dispatchCustomEvent("promptQueueing", {
			requestId,
			batchCount
		});
		if (this.processingQueue) return false;
		this.processingQueue = true;
		const executionStore = useExecutionStore();
		const executionErrorStore = useExecutionErrorStore();
		const telemetry = useTelemetry();
		executionErrorStore.clearRunErrors();
		let queueResultOverride = null;
		const teamWorkspaceStore = useTeamWorkspaceStore();
		try {
			await teamWorkspaceStore.waitForWorkspaceSwitch();
		} catch (error) {
			useDialogService().showErrorDialog(error, {
				title: t("errorDialog.promptExecutionError"),
				reportType: "promptExecutionError"
			});
			this.queueItems.length = 0;
			this.processingQueue = false;
			return false;
		}
		const workspaceIdBeforeAuthentication = teamWorkspaceStore.activeWorkspaceId;
		const workspaceGenerationBeforeAuthentication = teamWorkspaceStore.workspaceTransitionGeneration;
		const workspaceAuthToken = await useAuthStore().getWorkspaceAuthToken();
		const executionWorkspaceId = teamWorkspaceStore.activeWorkspaceId;
		const executionWorkspaceGeneration = teamWorkspaceStore.workspaceTransitionGeneration;
		const comfyOrgAuthToken = await queueAuthToken(workspaceAuthToken, executionWorkspaceId);
		const workspaceChangedWhileAuthenticating = (workspaceIdBeforeAuthentication !== executionWorkspaceId || workspaceGenerationBeforeAuthentication !== executionWorkspaceGeneration) && workspaceIdBeforeAuthentication !== null;
		const desktopHostAuth = isDesktopHostSignedIn();
		const comfyOrgApiKey = desktopHostAuth ? null : useApiKeyAuthStore().getApiKey();
		const isApiKeySessionExecution = !desktopHostAuth && !useAuthStore().currentUser && !useAuthStore().sessionOnlyUser && useApiKeyAuthStore().isAuthenticated;
		if (executionWorkspaceId && !comfyOrgAuthToken && !isApiKeySessionExecution) {
			useDialogService().showErrorDialog(new Error(t("toastMessages.userNotAuthenticated")), {
				title: t("errorDialog.promptExecutionError"),
				reportType: "promptExecutionError"
			});
			this.queueItems.length = 0;
			this.processingQueue = false;
			return false;
		}
		try {
			while (this.queueItems.length) {
				const { number, batchCount, queueNodeIds, requestId, workflowQueueIntent } = this.queueItems.pop();
				let queuedCount = 0;
				const workflowExecutionIntent = { trigger_source: normalizeExecutionTriggerSource(workflowQueueIntent?.trigger_source) };
				const previewMethod = useSettingStore().get("Comfy.Execution.PreviewMethod");
				const isPartialExecution = !!queueNodeIds?.length;
				for (let i = 0; i < batchCount; i++) {
					let executionContext;
					if (telemetry) try {
						executionContext = getExecutionContext();
					} catch (error) {
						console.error("[Telemetry] Workflow context collection failed", error);
					}
					forEachNode(this.rootGraph, (node) => {
						for (const widget of node.widgets ?? []) widget.beforeQueued?.({ isPartialExecution });
						applyPromotedWidgetControl(node, "beforeQueued");
					});
					const queuedWorkflow = useWorkspaceStore().workflow.activeWorkflow;
					const queuedRunErrorKey = executionErrorStore.captureRunErrorKey();
					const queuedMode = getWorkflowMode(queuedWorkflow);
					const startTime = performance.now();
					const p = await this.graphToPrompt(this.rootGraph).catch((error) => {
						telemetry?.trackExecutionOutcome({
							startTime,
							endTime: performance.now(),
							success: false,
							failureReason: "prompt_build_failed",
							...workflowExecutionIntent
						});
						throw error;
					});
					const queuedNodes = collectAllNodes(this.rootGraph);
					let workflowContext;
					if (executionContext) workflowContext = toWorkflowExecutionContext(executionContext, {
						executableNodeCount: Object.keys(p.output).length,
						executionScope: isPartialExecution ? "partial" : "full",
						viewMode: queuedMode
					});
					if (workspaceChangedWhileAuthenticating || executionWorkspaceId !== teamWorkspaceStore.activeWorkspaceId || executionWorkspaceGeneration !== teamWorkspaceStore.workspaceTransitionGeneration) {
						useDialogService().showErrorDialog(new Error(t("errorDialog.workspaceChangedDuringExecution")), {
							title: t("errorDialog.promptExecutionError"),
							reportType: "promptExecutionError"
						});
						queueResultOverride = false;
						break;
					}
					try {
						api.authToken = comfyOrgAuthToken;
						api.apiKey = comfyOrgApiKey ?? void 0;
						const res = await api.queuePrompt(number, p, {
							partialExecutionTargets: queueNodeIds,
							previewMethod
						});
						const responseReceivedAt = performance.now();
						delete api.authToken;
						delete api.apiKey;
						if (!res.prompt_id) telemetry?.trackExecutionOutcome({
							startTime,
							endTime: responseReceivedAt,
							success: false,
							failureReason: "submission_rejected",
							...workflowExecutionIntent,
							...workflowContext && { workflowContext }
						});
						executionErrorStore.recordNodeErrors(res.node_errors ?? null, queuedRunErrorKey);
						queueResultOverride = null;
						try {
							if (res.prompt_id) executionStore.storeJob({
								id: res.prompt_id,
								nodes: Object.keys(p.output),
								promptOutput: p.output,
								startTime,
								submissionAcceptedAt: responseReceivedAt,
								workflow: queuedWorkflow,
								mode: queuedMode,
								workflowContext,
								workflowExecutionIntent
							});
						} catch (error) {
							console.warn("Failed to store queued job metadata", {
								promptId: res.prompt_id,
								error
							});
						}
						if (executionErrorStore.hasNodeError) {
							if (useSettingStore().get("Comfy.RightSidePanel.ShowErrorsTab")) executionErrorStore.showErrorOverlay();
							this.canvas.draw(true, true);
						}
					} catch (error) {
						telemetry?.trackExecutionOutcome({
							startTime,
							endTime: performance.now(),
							success: false,
							failureReason: error instanceof PromptExecutionError ? "submission_rejected" : "submission_failed",
							...workflowExecutionIntent,
							...workflowContext && { workflowContext }
						});
						const hasPromptNodeErrors = error instanceof PromptExecutionError && Object.keys(error.response.node_errors ?? {}).length > 0;
						const promptError = error instanceof PromptExecutionError ? normalizePromptError(error.response.error) : null;
						const promptPrecondition = promptError ? resolveAccountPrecondition({
							exceptionType: promptError.type,
							exceptionMessage: promptError.message
						}) : void 0;
						if (promptPrecondition) {
							useAccountPreconditionDialog().open(promptPrecondition);
							console.error(error);
							break;
						}
						if (error instanceof PromptExecutionError && promptError?.type === "missing_node_type") rescanAndSurfaceMissingNodes(this.rootGraph);
						else if (error instanceof PromptExecutionError && error.status === 403 && !hasPromptNodeErrors) {
							const raw = error.response;
							const rawError = raw.error && typeof raw.error === "object" ? raw.error : void 0;
							const detail = typeof raw.message === "string" ? raw.message : typeof rawError?.message === "string" ? rawError.message : typeof raw.error === "string" ? raw.error : t("errorDialog.accessRestrictedMessage");
							useDialogService().showErrorDialog(new Error(detail), {
								title: t("errorDialog.accessRestrictedTitle"),
								reportType: "accessRestrictedError"
							});
						} else if (!useSettingStore().get("Comfy.RightSidePanel.ShowErrorsTab") || !(error instanceof PromptExecutionError)) useDialogService().showErrorDialog(error, {
							title: t("errorDialog.promptExecutionError"),
							reportType: "promptExecutionError"
						});
						console.error(error);
						if (error instanceof PromptExecutionError) {
							const nodeErrors = error.response.node_errors;
							queueResultOverride = !nodeErrors;
							executionErrorStore.recordNodeErrors(nodeErrors ?? null, queuedRunErrorKey);
							if ((!nodeErrors || Object.keys(nodeErrors).length === 0) && promptError) executionErrorStore.recordPromptError(promptError, queuedRunErrorKey);
							if (useSettingStore().get("Comfy.RightSidePanel.ShowErrorsTab")) executionErrorStore.showErrorOverlay();
							this.canvas.draw(true, true);
						}
						break;
					}
					queuedCount++;
					executeWidgetsCallback(queuedNodes, "afterQueued", { isPartialExecution });
					for (const node of queuedNodes) applyPromotedWidgetControl(node, "afterQueued");
					useFreeTierQuota().trackRun();
					this.canvas.draw(true, true);
					await this.ui.queue.update();
				}
				if (queuedCount > 0) api.dispatchCustomEvent("promptQueued", {
					number,
					batchCount: queuedCount,
					requestId
				});
			}
		} finally {
			this.processingQueue = false;
		}
		return queueResultOverride ?? !executionErrorStore.lastNodeErrors;
	}
	showErrorOnFileLoad(file) {
		useToast().warning(t("toastMessages.fileLoadError", { fileName: file.name }));
	}
	/**
	* Loads workflow data from the specified file
	* @param {File} file
	*/
	async handleFile(file, openSource, options) {
		const fileName = file.name.replace(/\.\w+$/, "");
		const { workflow, prompt, parameters, templates } = await getWorkflowDataFromFile(file) ?? {};
		if (!(workflow || prompt || parameters || templates)) {
			const mediaNodeTypes = {
				image: ["LoadImage", pasteImageNode],
				audio: ["LoadAudio", pasteAudioNode],
				video: ["LoadVideo", pasteVideoNode]
			};
			const mediaType = Object.keys(mediaNodeTypes).find((t) => file.type.startsWith(t));
			if (mediaType) {
				const [nodeType, pasteFn] = mediaNodeTypes[mediaType];
				const transfer = new DataTransfer();
				transfer.items.add(file);
				const node = await createNode(this.canvas, nodeType);
				await pasteFn(this.canvas, transfer.items, node);
				if (node) options?.onNodeCreated?.(node);
				return;
			}
			if (isMeshModelFile(file)) {
				const node = await this.handleMeshFile(file);
				if (node) options?.onNodeCreated?.(node);
				return;
			}
			this.showErrorOnFileLoad(file);
			return;
		}
		if (templates && typeof templates === "object" && Array.isArray(templates)) this.loadTemplateData({ templates });
		if (workflow) try {
			const workflowObj = typeof workflow === "string" ? parseJsonWithNonFinite(workflow) : workflow;
			if (workflowObj && typeof workflowObj === "object" && !Array.isArray(workflowObj)) {
				const graphData = workflowObj;
				await this.loadGraphData(graphData, true, true, fileName, {
					openSource,
					deferWarnings: options?.deferWarnings
				});
				return;
			} else console.error("Invalid workflow structure, trying parameters fallback");
		} catch (err) {
			console.error("Failed to parse workflow:", err);
		}
		if (prompt) try {
			const promptObj = typeof prompt === "string" ? parseJsonWithNonFinite(prompt) : prompt;
			if (this.isApiJson(promptObj)) {
				try {
					await this.loadApiJson(promptObj, fileName, { deferWarnings: options?.deferWarnings });
				} catch (err) {
					console.error("Failed to load API prompt:", err);
					reportError(err, {
						surface: "graph",
						errorType: "api_prompt_load_failure"
					});
					this.showErrorOnFileLoad(file);
				}
				return;
			}
		} catch (err) {
			console.error("Failed to parse prompt:", err);
		}
		if (parameters && typeof parameters === "string") return await this.enqueueGraphLoad(async () => {
			const outcome = await importA1111(this.rootGraph, parameters, async () => {
				try {
					useWorkflowService().beforeLoadNewGraph(false);
					await useExtensionService().invokeExtensionsAsync("beforeLoadGraph");
				} finally {
					useMissingNodesErrorStore().setMissingNodeTypes([]);
				}
				this.canvas.setGraph(this.rootGraph);
			});
			switch (outcome) {
				case "core-nodes-unavailable":
					useToast().warning(t("toastMessages.a1111CoreNodesUnavailable"));
					return;
				case "not-a1111":
					this.showErrorOnFileLoad(file);
					return;
				case "imported-without-embeddings":
					useToast().warning(t("g.warning"), { description: t("toastMessages.a1111EmbeddingsUnavailable") });
					break;
				case "imported": break;
				default: throw new Error(`Unhandled A1111 import outcome: ${outcome}`);
			}
			await useExtensionService().invokeExtensionsAsync("afterConfigureGraph", []);
			await useWorkflowService().afterLoadNewGraph(fileName, this.rootGraph.serialize());
			await useExtensionService().invokeExtensionsAsync("afterLoadGraph");
		});
		this.showErrorOnFileLoad(file);
	}
	/**
	* Uploads a mesh model file and creates a Load3DAdvanced node displaying it
	* @param {File} file
	*/
	async handleMeshFile(file) {
		const uploadedPath = await Load3dUtils.uploadFile(file, "3d");
		if (!uploadedPath) return null;
		const node = await createNode(this.canvas, "Load3DAdvanced");
		if (!node) return null;
		const modelWidget = node.widgets?.find((w) => w.name === "model_file");
		if (!modelWidget) return node;
		const values = modelWidget.options?.values;
		if (values && !values.includes(uploadedPath)) values.push(uploadedPath);
		modelWidget.value = uploadedPath;
		return node;
	}
	/**
	* Loads multiple files, connects to a batch node, and selects them
	* @param {FileList} fileList
	*/
	async handleFileList(fileList) {
		if (fileList.length === 0) return;
		if (!fileList[0].type.startsWith("image")) return;
		const imageNodes = await pasteImageNodes(this.canvas, fileList);
		if (imageNodes.length === 0) return;
		if (imageNodes.length > 1) {
			const batchImagesNode = await createNode(this.canvas, "BatchImagesNode");
			if (!batchImagesNode) return;
			this.positionBatchNodes(imageNodes, batchImagesNode);
			this.canvas.selectItems([...imageNodes, batchImagesNode]);
			imageNodes.forEach((imageNode, index) => {
				imageNode.connect(0, batchImagesNode, index);
			});
		} else this.canvas.selectItems(imageNodes);
	}
	async handleAudioFileList(fileList) {
		const audioNodes = await pasteAudioNodes(this.canvas, fileList);
		if (audioNodes.length === 0) return;
		this.positionNodes(audioNodes);
		this.canvas.selectItems(audioNodes);
	}
	async handleVideoFileList(fileList) {
		const videoNodes = await pasteVideoNodes(this.canvas, fileList);
		if (videoNodes.length === 0) return;
		this.positionNodes(videoNodes);
		this.canvas.selectItems(videoNodes);
	}
	/**
	* Positions batched nodes in drag and drop
	* @param nodes
	* @param batchNode
	*/
	positionNodes(nodes) {
		if (nodes.length <= 1) return;
		const [x, y] = nodes[0].getBounding();
		const nodeHeight = 150;
		nodes.forEach((node, index) => {
			if (index > 0) node.pos = [x, y + nodeHeight * index + 25 * (index + 1)];
		});
		this.canvas.graph?.change();
	}
	positionBatchNodes(nodes, batchNode) {
		const [x, y, width] = nodes[0].getBounding();
		batchNode.pos = [x + width + 100, y + 30];
		let height = 0;
		if (nodes[0].type === "LoadImage") height = 344;
		nodes.forEach((node, index) => {
			if (index > 0) node.pos = [x, y + height * index + 25 * (index + 1)];
		});
		this.canvas.graph?.change();
	}
	isApiJson(data) {
		if (!toolkit.isObject(data) || Array.isArray(data)) return false;
		if (Object.keys(data).length === 0) return false;
		return Object.values(data).every((node) => {
			if (!node || typeof node !== "object" || Array.isArray(node)) return false;
			const { class_type: classType, inputs } = node;
			const inputsIsRecord = toolkit.isObject(inputs) && !Array.isArray(inputs);
			return typeof classType === "string" && inputsIsRecord;
		});
	}
	async loadApiJson(apiData, fileName, options = {}) {
		return this.enqueueGraphLoad(() => this.loadApiJsonNow(apiData, fileName, options));
	}
	async loadApiJsonNow(apiData, fileName, options) {
		useWorkflowService().beforeLoadNewGraph(false);
		await useExtensionService().invokeExtensionsAsync("beforeLoadGraph");
		this.canvas.setGraph(this.rootGraph);
		withGraphIntentSource("load", () => this.clean());
		const ids = Object.keys(apiData);
		const importedNodeIds = /* @__PURE__ */ new Map();
		{
			const taken = new Set(ids.filter((id) => !id.includes(":")));
			for (const id of ids) {
				if (!id.includes(":")) {
					importedNodeIds.set(id, toNodeId(isNaN(+id) ? id : +id));
					continue;
				}
				let candidate = id.replaceAll(":", "_");
				while (taken.has(candidate)) candidate = `${candidate}_`;
				taken.add(candidate);
				importedNodeIds.set(id, toNodeId(candidate));
			}
		}
		const missingNodeTypes = [];
		const nodeReplacementStore = useNodeReplacementStore();
		await nodeReplacementStore.load();
		withGraphIntentSource("load", () => {
			for (const id of ids) {
				const data = apiData[id];
				const nodeId = importedNodeIds.get(id) ?? toNodeId(id);
				let node = LiteGraph.createNode(data.class_type);
				let placeholderEntry;
				if (!node) {
					const cnrId = zNodePackMetadata.shape.cnr_id.safeParse(data._meta?.cnr_id).data;
					const auxId = zNodePackMetadata.shape.aux_id.safeParse(data._meta?.aux_id).data;
					const packVersion = zNodePackMetadata.shape.ver.safeParse(data._meta?.ver).data;
					const missingNode = new LGraphNode(data._meta?.title ?? data.class_type, sanitizeNodeName(data.class_type));
					node = missingNode;
					node.has_errors = true;
					const widgetValues = [];
					const widgetValuesNamed = Object.create(null);
					for (const [input, value] of Object.entries(data.inputs)) if (value instanceof Array) node.addInput(input, "*");
					else {
						const widgetValue = unwrapExportedWidgetValue(value);
						widgetValues.push(widgetValue);
						widgetValuesNamed[input] = widgetValue;
					}
					if (cnrId) node.properties.cnr_id = cnrId;
					if (auxId) node.properties.aux_id = auxId;
					if (packVersion) node.properties.ver = packVersion;
					node.last_serialization = {
						id: nodeId,
						type: data.class_type,
						pos: [node.pos[0], node.pos[1]],
						size: [node.size[0], node.size[1]],
						flags: {},
						order: 0,
						mode: node.mode,
						title: data._meta?.title ?? data.class_type,
						inputs: node.inputs.map((input, i) => inputAsSerialisable(input, missingNode, i)),
						properties: { ...node.properties },
						widgets_values: widgetValues,
						widgets_values_named: widgetValuesNamed
					};
					const replacement = nodeReplacementStore.getReplacementFor(data.class_type);
					placeholderEntry = {
						type: data.class_type,
						cnrId: getCnrIdFromProperties(node.properties),
						isReplaceable: replacement !== null,
						replacement: replacement ?? void 0
					};
					missingNodeTypes.push(placeholderEntry);
				}
				node.id = nodeId;
				node.title = data._meta?.title ?? node.title;
				app.rootGraph.add(node);
				if (placeholderEntry && node.last_serialization) {
					node.last_serialization.id = node.id;
					placeholderEntry.nodeId = String(node.id);
				}
			}
			const unresolvedInputs = [];
			const processNodeInputs = (id) => {
				const data = apiData[id];
				const currentNodeId = importedNodeIds.get(id) ?? toNodeId(id);
				const node = app.rootGraph.getNodeById(currentNodeId);
				if (!node) return;
				const targetNode = node;
				const inputs = restoreDynamicGroupInputs(node, data.inputs);
				for (const input in inputs) {
					const value = inputs[input];
					if (value instanceof Array) {
						function connectInput() {
							const [fromId, fromSlot] = value;
							const fromNode = app.rootGraph.getNodeById(importedNodeIds.get(String(fromId)) ?? toNodeId(fromId));
							if (!fromNode?.outputs[fromSlot]) return false;
							let toSlot = targetNode.inputs.findIndex((inp) => inp.name === input);
							if (toSlot === -1) try {
								const widget = targetNode.widgets?.find((w) => w.name === input);
								const convertFn = targetNode.convertWidgetToInput;
								if (widget && convertFn?.(widget)) toSlot = targetNode.inputs.findIndex((inp) => inp.name === input);
							} catch (_error) {}
							if (toSlot === -1) return false;
							fromNode.connect(fromSlot, targetNode, toSlot);
							return true;
						}
						if (!connectInput()) unresolvedInputs.push(connectInput);
					} else {
						function applyWidgetValue() {
							const widget = targetNode.widgets?.find((w) => w.name === input);
							if (!widget) return false;
							const widgetValue = unwrapExportedWidgetValue(value);
							widget.value = widgetValue;
							try {
								widget.callback?.(widgetValue);
							} catch (error) {
								reportError(error, {
									surface: "graph",
									errorType: "failure_invoking_api_workflow_widget_callback",
									tags: {
										node_type: targetNode.type,
										widget_name: input
									},
									context: { fileName }
								});
							}
							return true;
						}
						if (!applyWidgetValue()) unresolvedInputs.push(applyWidgetValue);
					}
				}
			};
			for (const id of ids) processNodeInputs(id);
			let pendingInputs = unresolvedInputs;
			while (pendingInputs.length > 0) {
				const remainingInputs = pendingInputs.filter((applyInput) => !applyInput());
				if (remainingInputs.length === pendingInputs.length) break;
				pendingInputs = remainingInputs;
			}
			for (const node of app.rootGraph.nodes) {
				if (!node.last_serialization) continue;
				node.last_serialization.inputs = node.inputs.map((input, i) => inputAsSerialisable(input, node, i));
			}
			app.rootGraph.arrange();
		});
		await useExtensionService().invokeExtensionsAsync("afterConfigureGraph", missingNodeTypes);
		await useWorkflowService().afterLoadNewGraph(fileName, this.rootGraph.serialize());
		await useExtensionService().invokeExtensionsAsync("afterLoadGraph");
		if (missingNodeTypes.length) this.showMissingNodesError(missingNodeTypes, options);
	}
	/**
	* Registers a Comfy web extension with the app
	* @param {ComfyExtension} extension
	*/
	registerExtension(extension) {
		useExtensionService().registerExtension(extension);
	}
	/**
	* Collects context menu items from all extensions for canvas menus
	* @param canvas The canvas instance
	* @returns Array of context menu items from all extensions
	*/
	collectCanvasMenuItems(canvas) {
		return useExtensionService().invokeExtensions("getCanvasMenuItems", canvas).flat();
	}
	/**
	* Collects context menu items from all extensions for node menus
	* @param node The node being right-clicked
	* @returns Array of context menu items from all extensions
	*/
	collectNodeMenuItems(node) {
		return useExtensionService().invokeExtensions("getNodeMenuItems", node).flat();
	}
	/**
	* Reload node definitions, or register `given` ones, and refresh combo lists on all nodes; definitions owed to `addCustomNodeDefs` go through it first.
	* Resolves false, changing nothing, when the server refuses the definitions while they are owed.
	*/
	async reloadNodeDefs(given) {
		const defs = given ?? await this.fetchReloadedNodeDefs();
		if (!defs) return false;
		if (useExtensionStore().takeOwedNodeDefHooks()) await useExtensionService().invokeExtensionsAsync("addCustomNodeDefs", defs);
		for (const nodeId in defs) await this.registerNodeDef(nodeId, defs[nodeId]);
		const nodeOutputStore = useNodeOutputStore();
		forEachNode(this.rootGraph, (node) => {
			const def = defs[node.type];
			node.refreshComboInNode?.(defs);
			if (!def?.input) return;
			if (node.widgets) {
				const nodeInputs = def.input;
				for (const widget of node.widgets) if (widget.type === "combo") {
					const inputSpec = resolveDynamicInputSpec(nodeInputs, widget.name, (name) => node.widgets?.find((item) => item.name === name)?.value)?.spec;
					if (inputSpec && isComboInputSpecV2(inputSpec)) widget.options.values = inputSpec[1]?.options;
					else if (inputSpec && isComboInputSpecV1(inputSpec)) widget.options.values = inputSpec[0];
				}
			}
			if (isImageNode(node) || isVideoNode(node)) nodeOutputStore.refreshNodeOutputs(node);
		});
		await useExtensionService().invokeExtensionsAsync("refreshComboInNodes", defs);
		syncPromotedComboHostOptions(this.rootGraph);
		if (this.vueAppReady) this.updateVueAppNodeDefs(defs);
		return true;
	}
	async fetchReloadedNodeDefs() {
		if (!useExtensionStore().areNodeDefHooksOwed()) return await this.getNodeDefs();
		const fetched = await this.fetchNodeDefs();
		if (fetched.ok) return fetched.defs;
		reportError(/* @__PURE__ */ new Error(`GET /object_info answered ${fetched.status}`), {
			errorType: "late_extension_failed",
			surface: "platform",
			level: "warning",
			tags: { step: "reloadNodeDefs" }
		});
	}
	/**
	* Refresh combo list on whole nodes
	*/
	async refreshComboInNodes() {
		const requestToastId = this.vueAppReady ? useToast().info(t("g.update"), { description: t("toastMessages.updateRequested") }) : void 0;
		try {
			const reloaded = await this.reloadNodeDefs();
			if (this.vueAppReady && reloaded) useToast().success(t("g.updated"), {
				description: t("toastMessages.nodeDefinitionsUpdated"),
				duration: 1e3
			});
			else if (this.vueAppReady) useToast().error(t("g.error"), { description: t("toastMessages.nodeDefinitionsUpdateFailed") });
		} catch (error) {
			if (this.vueAppReady) useToast().error(t("g.error"), { description: t("toastMessages.nodeDefinitionsUpdateFailed") });
			throw error;
		} finally {
			if (requestToastId !== void 0) useToast().dismiss(requestToastId);
		}
	}
	/**
	* Clean current state
	*/
	clean() {
		useNodeOutputStore().resetAllOutputsAndPreviews();
		const executionErrorStore = useExecutionErrorStore();
		executionErrorStore.setActiveGraph(null);
		useMissingNodesErrorStore().setMissingNodeTypes([]);
		useDomWidgetStore().clear();
		if (!this.canvas.subgraph) {
			this.rootGraph.clear();
			ensureNonZeroUuid(this.rootGraph);
		}
		executionErrorStore.setActiveGraph(this.rootGraph.id);
	}
	clientPosToCanvasPos(pos) {
		if (!this.positionConversion) throw new Error("clientPosToCanvasPos called before setup");
		return this.positionConversion.clientPosToCanvasPos(pos);
	}
	canvasPosToClientPos(pos) {
		if (!this.positionConversion) throw new Error("canvasPosToClientPos called before setup");
		return this.positionConversion.canvasPosToClientPos(pos);
	}
};
var app = new ComfyApp();
registerApp(app);
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.app = window.comfyAPI.app || {};
window.comfyAPI.app.sanitizeNodeName = sanitizeNodeName;
window.comfyAPI.app.ComfyApp = ComfyApp;
window.comfyAPI.app.app = app;
//#endregion
export { useNodePaste as $, autoExposeKnownPreviewNodes as A, isDynamicGroupController as At, pruneDisconnected as B, isDOMWidget as Bt, getExtraOptionsForWidget as C, addValueControlWidgets$1 as Ct, useRightSidePanelStore as D, growAutogrowInput as Dt, markCoreMediaMenuCallback as E, IS_CONTROL_WIDGET as Et, hasUnpromotedWidgets as F, useAccountPreconditionDialog as Ft, useSubgraphStore as G, bootstrapTracer as Gt, reorderSubgraphInputsByWidgetOrder as H, MediaAssetKey as Ht, isPreviewPseudoWidget as I, ComponentWidgetImpl as It, useExtensionService as J, TemplateIncludeOnDistributionEnum as K, useCanvasPositionConversion as Kt, isRecommendedWidget as L, DOMWidgetImpl as Lt, demoteWidget as M, reportRemoteDynamicGroupRowMismatch as Mt, findHostInputForPromotion as N, useMenuItemStore as Nt, useFavoritedWidgetsStore as O, liveAutogrowGroupOf as Ot, getPromotableWidgets as P, legacyMenuCompat as Pt, useStringWidget as Q, isWidgetPromotedOnSubgraphNode as R, addWidget as Rt, useNodeReplacementStore as S, useBooleanWidget as St, filterUnavailableCoreMediaMenuActions as T, getControlWidget as Tt, tryToggleWidgetPromotion as U, zMediaKindSchema as Ut, refreshPromotedWidgetRendering as V, MIME_ASSET_INFO as Vt, useSubgraphOperations as W, withNodeAddSource as Wt, ComfyWidgets as X, useWidgetStore as Y, isValidWidgetType as Z, verifyMediaCandidates as _, isCompositorWidgetValue as _t, useCopy as a, hasImageType as at, waitForDeploymentPick as b, useAssetBrowserDialog as bt, getWorkflowDataFromFile as c, useCanvasInteractions as ct, runMissingMediaPipeline as d, LIGHT_TYPE_LABEL_KEYS as dt, useNodeFileInput as et, groupCandidatesByMediaType as f, cloneLights as ft, scanNodeMediaCandidates as g, emptyCompositorWidgetValue as gt, scanAllMediaCandidates as h, useFloatWidget as ht, usePaste as i, hasAudioType as it, createPromotedHostWidgetIdLookup as j, reachesDynamicGroupRowCount as jt, resolveNodeDisplayName as k, applyRemoteDynamicGroupRowCount as kt, deserialiseAndCreate as l, normalizeLightsValue as lt, isMissingMediaCandidateScopeActive as m, lightTarget as mt, app as n, fetchDroppedAsset as nt, collapseOutsideSelectionOnPrimaryPointerDown as o, hasVideoType as ot, isMissingMediaCandidateActive as p, createDefaultLight as pt, useSelectedLiteGraphItems as q, useSharedCanvasPositionConversion as qt, sanitizeNodeName as r, getDroppedAsset as rt, shouldIgnoreCopyPaste as s, describeImageLoadFailure as st, ComfyApp as t, useNodeDragAndDrop as tt, useNodeZIndex as u, LIGHT_TYPES as ut, cloudReleaseModelOptions as v, createAssetWidget as vt, useLitegraphService as w, updateControlWidgetLabel$1 as wt, parseJsonWithNonFinite as x, AppMultiSelect_default as xt, couldBootOnDeployment as y, registerAssetBrowserModalComponent as yt, promoteWidget as z, isComponentWidget as zt };
