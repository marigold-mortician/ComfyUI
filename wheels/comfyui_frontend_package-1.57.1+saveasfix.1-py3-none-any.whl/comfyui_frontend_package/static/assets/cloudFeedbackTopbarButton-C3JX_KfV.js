import "./rolldown-runtime-xtsTai4I.js";
import { n as useSettingStore } from "./settingStore-DRRi2kOn.js";
import { d as t } from "./i18n-BRluoVl-.js";
import { t as openFeedbackDialog } from "./feedbackDialog-Ou8TLTOa.js";
//#region src/extensions/core/cloudFeedbackTopbarButton.ts
function feedbackButton() {
	return {
		icon: "icon-[lucide--megaphone] size-4",
		label: t("actionbar.feedback"),
		tooltip: t("actionbar.feedbackTooltip"),
		onClick: () => openFeedbackDialog("action-bar")
	};
}
var feedbackButtonExtension = {
	name: "Comfy.FeedbackButton",
	get actionBarButtons() {
		return useSettingStore().get("Comfy.UI.TabBarLayout") === "Legacy" ? [feedbackButton()] : [];
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.cloudFeedbackTopbarButton = window.comfyAPI.cloudFeedbackTopbarButton || {};
window.comfyAPI.cloudFeedbackTopbarButton.feedbackButtonExtension = feedbackButtonExtension;
//#endregion
export { feedbackButtonExtension };
