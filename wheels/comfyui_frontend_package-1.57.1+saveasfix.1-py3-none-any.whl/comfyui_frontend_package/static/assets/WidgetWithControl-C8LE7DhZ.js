const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./ValueControlPopover-LiMQjTQK.js","./rolldown-runtime-xtsTai4I.js","./settingStore-DRRi2kOn.js","./delay-Cu8bS1zn.js","./globalThis-B6Vbq1EF.js","./cloneDeep-BX7AjX4w.js","./api-BdJmXw98.js","./requestAuth-COoKVLz2.js","./get-Bk-Y8oEe.js","./vendor-vue-core-CuN1excl.js","./telemetry-IkzvF0TI.js","./vendor-zod-Del_rmdp.js","./zod.gen-DzuaBm8H.js","./vendor-axios-QnwcNXlY.js","./requestTimeout-DkmiEk-h.js","./hostTelemetryEnabled-DM7ML37c.js","./remoteConfig-VmmsGxJZ.js","./vendor-reka-ui-NRTk7aIV.js","./vendor-firebase-B37L--zT.js","./toastStore-Dg65fRgL.js","./i18n-BRluoVl-.js","./preload-helper-sJeoGctA.js","./vendor-i18n-pA_PV1p-.js","./formatUtil-DsZFGVbT.js","./commands-C9zyhK6Q.js","./main-BtaRoPyL.js","./nodeDefs-BUEI64H3.js","./settings-B3DInspu.js","./vendor-sentry-zSXGkMPN.js","./reportError-BHgDVvfb.js","./errorUtil-DoQyAUQC.js","./rerouteId-1TDIYZkX.js","./RadioGroupItem-DF4cXT8y.js","./src-BHQtMnZc.js"])))=>i.map(i=>d[i]);
import "./rolldown-runtime-xtsTai4I.js";
import { t as __vitePreload } from "./preload-helper-sJeoGctA.js";
import { $ as mergeModels, Ft as ref, G as defineComponent, I as createBlock, Kt as normalizeClass, L as createCommentVNode, R as createElementBlock, U as createVNode, W as defineAsyncComponent, Wt as unref, Yt as toDisplayString, _t as useModel, bt as watch, ct as openBlock, et as mergeProps, pt as resolveDynamicComponent, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { t as Popover_default } from "./Popover-Bo3qn5Dm.js";
//#region src/renderer/extensions/vueNodes/widgets/components/ValueControlButton.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$1 = ["aria-label"];
var _hoisted_2 = {
	key: 1,
	class: "text-xs font-normal text-primary"
};
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/components/ValueControlButton.vue
var ValueControlButton_default = /* @__PURE__ */ defineComponent({
	__name: "ValueControlButton",
	props: {
		mode: {},
		variant: { default: "badge" }
	},
	setup(__props) {
		const { t } = useI18n();
		const iconMap = {
			fixed: "icon-[lucide--pencil-off]",
			randomize: "icon-[lucide--shuffle]",
			increment: null,
			decrement: null
		};
		const textMap = {
			increment: "+1",
			decrement: "-1",
			fixed: null,
			randomize: null
		};
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("button", {
				"data-testid": "value-control",
				type: "button",
				"aria-label": unref(t)("widgets.valueControl." + __props.mode),
				class: normalizeClass(unref(cn)("flex shrink-0 cursor-pointer items-center justify-center border-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-1 focus-visible:outline-none", __props.variant === "badge" ? "h-4.5 w-8 rounded-full" : "size-6 rounded-sm", __props.mode !== "fixed" ? "bg-primary/30 hover:bg-primary/27" : "bg-transparent"))
			}, [iconMap[__props.mode] ? (openBlock(), createElementBlock("i", {
				key: 0,
				"aria-hidden": "true",
				class: normalizeClass(unref(cn)(iconMap[__props.mode] ?? "", "text-xs", __props.mode === "fixed" ? "text-muted-foreground" : "text-primary"))
			}, null, 2)) : textMap[__props.mode] ? (openBlock(), createElementBlock("span", _hoisted_2, toDisplayString(textMap[__props.mode]), 1)) : createCommentVNode("", true)], 10, _hoisted_1$1);
		};
	}
});
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/components/WidgetWithControl.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "relative grid grid-cols-subgrid" };
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/components/WidgetWithControl.vue
var WidgetWithControl_default = /* @__PURE__ */ defineComponent({
	__name: "WidgetWithControl",
	props: /*@__PURE__*/ mergeModels({
		widget: {},
		component: {}
	}, {
		"modelValue": {},
		"modelModifiers": {}
	}),
	emits: ["update:modelValue"],
	setup(__props) {
		const ValueControlPopover = defineAsyncComponent(() => __vitePreload(() => import("./ValueControlPopover-LiMQjTQK.js"), __vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33]), import.meta.url));
		const props = __props;
		const modelValue = useModel(__props, "modelValue");
		const controlModel = ref(props.widget.controlWidget.value);
		watch(controlModel, props.widget.controlWidget.update);
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1, [(openBlock(), createBlock(resolveDynamicComponent(__props.component), mergeProps(_ctx.$attrs, {
				modelValue: modelValue.value,
				"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => modelValue.value = $event),
				widget: __props.widget
			}), {
				default: withCtx(() => [createVNode(Popover_default, null, {
					button: withCtx(() => [createVNode(ValueControlButton_default, {
						mode: controlModel.value,
						class: "mr-1 self-center"
					}, null, 8, ["mode"])]),
					default: withCtx(() => [createVNode(unref(ValueControlPopover), {
						modelValue: controlModel.value,
						"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => controlModel.value = $event)
					}, null, 8, ["modelValue"])]),
					_: 1
				})]),
				_: 1
			}, 16, ["modelValue", "widget"]))]);
		};
	}
});
//#endregion
export { WidgetWithControl_default as t };
