import "./rolldown-runtime-xtsTai4I.js";
import { t as useNodeOutputStore } from "./nodeOutputStore-DmbNgTmp.js";
import { i as api } from "./api-BdJmXw98.js";
import { F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, R as createElementBlock, U as createVNode, Wt as unref, Yt as toDisplayString, ct as openBlock, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { n as useApp } from "./appInstance-CiT6CpGM.js";
import { F as isResultItemType } from "./graphTraversalUtil-BUK1cr2m.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
import { t as useMaskEditorStore } from "./maskEditorStore-7e3TTopr.js";
import { t as useCanvasTransform } from "./useCanvasTransform-CeVr70gB.js";
import { n as writeImageWidgetValue, r as useMaskEditorDataStore } from "./imageWidgetAdapter-C6XLrz7d.js";
import { t as useCanvasTools } from "./useCanvasTools-D8c8K9NZ.js";
//#region src/utils/pngEncodeUtil.ts
var PNG_SIGNATURE = new Uint8Array([
	137,
	80,
	78,
	71,
	13,
	10,
	26,
	10
]);
var CRC_TABLE = /* @__PURE__ */ new Uint32Array(256);
for (let n = 0; n < 256; n++) {
	let c = n;
	for (let k = 0; k < 8; k++) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
	CRC_TABLE[n] = c;
}
function crc32(...parts) {
	let crc = 4294967295;
	for (const part of parts) for (const byte of part) crc = CRC_TABLE[(crc ^ byte) & 255] ^ crc >>> 8;
	return (crc ^ 4294967295) >>> 0;
}
function u32be(value) {
	return new Uint8Array([
		value >>> 24 & 255,
		value >>> 16 & 255,
		value >>> 8 & 255,
		value & 255
	]);
}
function pngChunk(type, data) {
	const typeBytes = new TextEncoder().encode(type);
	return [
		u32be(data.length),
		typeBytes,
		data,
		u32be(crc32(typeBytes, data))
	];
}
async function zlibDeflate(bytes) {
	const compressor = new CompressionStream("deflate");
	const writer = compressor.writable.getWriter();
	const writeDone = writer.write(bytes).then(() => writer.close());
	const chunks = [];
	const reader = compressor.readable.getReader();
	for (;;) {
		const { done, value } = await reader.read();
		if (done) break;
		chunks.push(value);
	}
	await writeDone;
	const total = chunks.reduce((sum, chunk) => sum + chunk.length, 0);
	const out = new Uint8Array(total);
	let offset = 0;
	for (const chunk of chunks) {
		out.set(chunk, offset);
		offset += chunk.length;
	}
	return out;
}
/**
* Encodes RGBA pixels as a PNG blob without going through a canvas.
*
* Canvas 2D output bitmaps use premultiplied alpha: fully transparent pixels
* lose their RGB the moment they are written to the canvas, and
* `canvas.toBlob()` serializes that loss. PNG stores straight
* (non-premultiplied) alpha, so encoding the pixel buffer directly preserves
* color data under transparent regions.
*/
async function encodeRgbaAsPng(image) {
	const { width, height, data } = image;
	const bytesPerRow = width * 4;
	const raw = new Uint8Array(height * (bytesPerRow + 1));
	for (let y = 0; y < height; y++) {
		const rowStart = y * (bytesPerRow + 1);
		raw[rowStart] = 0;
		raw.set(data.subarray(y * bytesPerRow, (y + 1) * bytesPerRow), rowStart + 1);
	}
	const ihdr = /* @__PURE__ */ new Uint8Array(13);
	ihdr.set(u32be(width), 0);
	ihdr.set(u32be(height), 4);
	ihdr[8] = 8;
	ihdr[9] = 6;
	const idat = await zlibDeflate(raw);
	return new Blob([
		PNG_SIGNATURE,
		...pngChunk("IHDR", ihdr),
		...pngChunk("IDAT", idat),
		...pngChunk("IEND", /* @__PURE__ */ new Uint8Array(0))
	], { type: "image/png" });
}
//#endregion
//#region src/renderer/extensions/maskEditor/composables/useMaskEditorSaver.ts
function imageLayerFilenamesByTimestamp(timestamp) {
	return {
		maskedImage: `clipspace-mask-${timestamp}.png`,
		paint: `clipspace-paint-${timestamp}.png`,
		paintedImage: `clipspace-painted-${timestamp}.png`,
		paintedMaskedImage: `clipspace-painted-masked-${timestamp}.png`
	};
}
function useMaskEditorSaver() {
	const dataStore = useMaskEditorDataStore();
	const editorStore = useMaskEditorStore();
	const nodeOutputStore = useNodeOutputStore();
	const save = async () => {
		const sourceNode = dataStore.sourceNode;
		if (!sourceNode || !dataStore.inputData) throw new Error("No source node or input data");
		try {
			const outputData = await prepareOutputData();
			dataStore.outputData = outputData;
			await updateNodePreview(sourceNode, outputData);
			await uploadAllLayers(outputData);
			updateNodeWithServerReferences(sourceNode, outputData);
			useApp().canvas.setDirty(true);
		} catch (error) {
			console.error("[MaskEditorSaver] Save failed:", error);
			throw error;
		}
	};
	async function prepareOutputData() {
		const maskCanvas = editorStore.maskCanvas;
		const paintCanvas = editorStore.rgbCanvas;
		const imgCanvas = editorStore.imgCanvas;
		if (!maskCanvas || !paintCanvas || !imgCanvas) throw new Error("Canvas not initialized");
		const filenames = imageLayerFilenamesByTimestamp(Date.now());
		const [maskedImage, paintLayer, paintedImage, paintedMaskedImage] = await Promise.all([
			createMaskedImage(imgCanvas, maskCanvas, filenames.maskedImage),
			createPaintLayer(paintCanvas, filenames.paint),
			createPaintedImage(imgCanvas, paintCanvas, filenames.paintedImage),
			createPaintedMaskedImage(imgCanvas, paintCanvas, maskCanvas, filenames.paintedMaskedImage)
		]);
		return {
			maskedImage,
			paintLayer,
			paintedImage,
			paintedMaskedImage
		};
	}
	/**
	* Writes the inverted mask into the alpha channel and returns the pixel
	* buffer whose RGB was captured while the canvas was still fully opaque.
	* Encode that buffer (not the canvas): once transparent pixels are written
	* to the premultiplied canvas bitmap their RGB is lost, so blobs derived
	* from the canvas serialize black under the mask.
	*/
	function applyMaskAsAlpha(ctx, maskCanvas) {
		const maskData = maskCanvas.getContext("2d").getImageData(0, 0, maskCanvas.width, maskCanvas.height);
		const imageData = ctx.getImageData(0, 0, ctx.canvas.width, ctx.canvas.height);
		for (let i = 0; i < imageData.data.length; i += 4) imageData.data[i + 3] = 255 - maskData.data[i + 3];
		ctx.putImageData(imageData, 0, 0);
		return imageData;
	}
	async function createMaskedImage(imgCanvas, maskCanvas, filename) {
		const canvas = document.createElement("canvas");
		canvas.width = imgCanvas.width;
		canvas.height = imgCanvas.height;
		const ctx = canvas.getContext("2d");
		ctx.drawImage(imgCanvas, 0, 0);
		return {
			canvas,
			blob: await encodeRgbaAsPng(applyMaskAsAlpha(ctx, maskCanvas)),
			ref: createFileRef(filename)
		};
	}
	async function createPaintLayer(paintCanvas, filename) {
		const canvas = cloneCanvas(paintCanvas);
		return {
			canvas,
			blob: await canvasToBlob(canvas),
			ref: createFileRef(filename)
		};
	}
	async function createPaintedImage(imgCanvas, paintCanvas, filename) {
		const canvas = document.createElement("canvas");
		canvas.width = imgCanvas.width;
		canvas.height = imgCanvas.height;
		const ctx = canvas.getContext("2d");
		ctx.drawImage(imgCanvas, 0, 0);
		ctx.globalCompositeOperation = "source-over";
		ctx.drawImage(paintCanvas, 0, 0);
		return {
			canvas,
			blob: await canvasToBlob(canvas),
			ref: createFileRef(filename)
		};
	}
	async function createPaintedMaskedImage(imgCanvas, paintCanvas, maskCanvas, filename) {
		const canvas = document.createElement("canvas");
		canvas.width = imgCanvas.width;
		canvas.height = imgCanvas.height;
		const ctx = canvas.getContext("2d");
		ctx.drawImage(imgCanvas, 0, 0);
		ctx.globalCompositeOperation = "source-over";
		ctx.drawImage(paintCanvas, 0, 0);
		return {
			canvas,
			blob: await encodeRgbaAsPng(applyMaskAsAlpha(ctx, maskCanvas)),
			ref: createFileRef(filename)
		};
	}
	async function uploadAllLayers(outputData) {
		const actualMaskedRef = await uploadLayer(outputData.maskedImage);
		const actualPaintRef = await uploadLayer(outputData.paintLayer);
		const actualPaintedRef = await uploadLayer(outputData.paintedImage);
		const actualPaintedMaskedRef = await uploadLayer(outputData.paintedMaskedImage);
		outputData.maskedImage.ref = actualMaskedRef;
		outputData.paintLayer.ref = actualPaintRef;
		outputData.paintedImage.ref = actualPaintedRef;
		outputData.paintedMaskedImage.ref = actualPaintedMaskedRef;
	}
	async function uploadLayer(layer) {
		const formData = new FormData();
		formData.append("image", layer.blob, layer.ref.filename);
		formData.append("type", "input");
		const response = await api.fetchApi("/upload/image", {
			method: "POST",
			body: formData
		});
		if (!response.ok) {
			const body = await response.text().catch(() => "");
			throw new Error(`Failed to upload ${layer.ref.filename} (${response.status}${body ? `: ${body}` : ""})`);
		}
		let data;
		try {
			data = await response.json();
		} catch (error) {
			throw new Error(`Invalid upload response for ${layer.ref.filename}: ${error instanceof Error ? error.message : String(error)}`, { cause: error });
		}
		if (!data.name) throw new Error(`Upload response missing 'name' for ${layer.ref.filename}`);
		return {
			filename: data.name,
			subfolder: data.subfolder || "",
			type: data.type || "input"
		};
	}
	async function updateNodePreview(node, outputData) {
		node.imgs = [await loadImageFromUrl(outputData.paintedMaskedImage.canvas.toDataURL("image/png"))];
		useApp().canvas.setDirty(true);
	}
	function updateNodeWithServerReferences(node, outputData) {
		if (!node.graph) return;
		const mainRef = outputData.paintedMaskedImage.ref;
		writeImageWidgetValue(node, mainRef.filename + (mainRef.type ? ` [${mainRef.type}]` : ""));
		node.imgs = void 0;
		nodeOutputStore.replaceNodeOutputImages(node, [{
			filename: mainRef.filename,
			subfolder: mainRef.subfolder,
			type: isResultItemType(mainRef.type) ? mainRef.type : "input"
		}]);
		node.graph.setDirtyCanvas(true);
	}
	function loadImageFromUrl(url) {
		return new Promise((resolve, reject) => {
			const img = new Image();
			img.crossOrigin = "anonymous";
			img.onload = () => resolve(img);
			img.onerror = (error) => {
				console.error("[MaskEditorSaver] Failed to load image:", url, error);
				reject(/* @__PURE__ */ new Error(`Failed to load image: ${url}`));
			};
			img.src = url;
		});
	}
	function cloneCanvas(source) {
		const canvas = document.createElement("canvas");
		canvas.width = source.width;
		canvas.height = source.height;
		canvas.getContext("2d").drawImage(source, 0, 0);
		return canvas;
	}
	function canvasToBlob(canvas) {
		return new Promise((resolve, reject) => {
			canvas.toBlob((blob) => {
				if (blob) resolve(blob);
				else reject(/* @__PURE__ */ new Error("Failed to create blob from canvas"));
			}, "image/png");
		});
	}
	function createFileRef(filename) {
		return {
			filename,
			subfolder: "clipspace",
			type: "input"
		};
	}
	return { save };
}
//#endregion
//#region src/renderer/extensions/maskEditor/components/dialog/TopBarHeader.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "flex w-full items-center justify-between gap-3 p-2" };
var _hoisted_2 = { class: "flex items-center gap-3" };
var _hoisted_3 = { class: "m-0 text-lg font-semibold" };
var _hoisted_4 = { class: "flex items-center gap-4" };
var _hoisted_5 = { class: "flex gap-3" };
//#endregion
//#region src/renderer/extensions/maskEditor/components/dialog/TopBarHeader.vue
var TopBarHeader_default = /* @__PURE__ */ defineComponent({
	__name: "TopBarHeader",
	setup(__props) {
		const { t } = useI18n();
		const store = useMaskEditorStore();
		const dialogStore = useDialogStore();
		const canvasTools = useCanvasTools();
		const canvasTransform = useCanvasTransform();
		const saver = useMaskEditorSaver();
		const saveButtonText = ref(t("g.save"));
		const saveEnabled = ref(true);
		const onUndo = () => {
			store.canvasHistory.undo();
		};
		const onRedo = () => {
			store.canvasHistory.redo();
		};
		const onRotateLeft = async () => {
			try {
				await canvasTransform.rotateCounterclockwise();
			} catch (error) {
				console.error("[TopBarHeader] Rotate left failed:", error);
			}
		};
		const onRotateRight = async () => {
			try {
				await canvasTransform.rotateClockwise();
			} catch (error) {
				console.error("[TopBarHeader] Rotate right failed:", error);
			}
		};
		const onMirrorHorizontal = async () => {
			try {
				await canvasTransform.mirrorHorizontal();
			} catch (error) {
				console.error("[TopBarHeader] Mirror horizontal failed:", error);
			}
		};
		const onMirrorVertical = async () => {
			try {
				await canvasTransform.mirrorVertical();
			} catch (error) {
				console.error("[TopBarHeader] Mirror vertical failed:", error);
			}
		};
		const onInvert = () => {
			canvasTools.invertMask();
		};
		const onClear = () => {
			canvasTools.clearMask();
			store.triggerClear();
		};
		const handleSave = async () => {
			saveButtonText.value = t("g.saving");
			saveEnabled.value = false;
			try {
				store.brushVisible = false;
				await saver.save();
				dialogStore.closeDialog();
			} catch (error) {
				console.error("[TopBarHeader] Save failed:", error);
				store.brushVisible = true;
				saveButtonText.value = t("g.save");
				saveEnabled.value = true;
			}
		};
		const handleCancel = () => {
			dialogStore.closeDialog({ key: "global-mask-editor" });
		};
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1, [createBaseVNode("div", _hoisted_2, [createBaseVNode("h3", _hoisted_3, toDisplayString(unref(t)("maskEditor.title")), 1), createBaseVNode("div", _hoisted_4, [
				createVNode(Button_default, {
					variant: "outline",
					size: "unset",
					class: "pointer-events-auto h-7.5 w-12.5 rounded-[10px] bg-background",
					title: unref(t)("maskEditor.undo"),
					onClick: onUndo
				}, {
					default: withCtx(() => [..._cache[0] || (_cache[0] = [createBaseVNode("svg", {
						viewBox: "0 0 15 15",
						class: "pointer-events-none size-6.25 fill-current"
					}, [createBaseVNode("path", { d: "M8.77,12.18c-.25,0-.46-.2-.46-.46s.2-.46.46-.46c1.47,0,2.67-1.2,2.67-2.67,0-1.57-1.34-2.67-3.26-2.67h-3.98l1.43,1.43c.18.18.18.47,0,.64-.18.18-.47.18-.64,0l-2.21-2.21c-.18-.18-.18-.47,0-.64l2.21-2.21c.18-.18.47-.18.64,0,.18.18.18.47,0,.64l-1.43,1.43h3.98c2.45,0,4.17,1.47,4.17,3.58,0,1.97-1.61,3.58-3.58,3.58Z" })], -1)])]),
					_: 1
				}, 8, ["title"]),
				createVNode(Button_default, {
					variant: "outline",
					size: "unset",
					class: "pointer-events-auto h-7.5 w-12.5 rounded-[10px] bg-background",
					title: unref(t)("maskEditor.redo"),
					onClick: onRedo
				}, {
					default: withCtx(() => [..._cache[1] || (_cache[1] = [createBaseVNode("svg", {
						viewBox: "0 0 15 15",
						class: "pointer-events-none size-6.25 fill-foreground"
					}, [createBaseVNode("path", {
						class: "cls-1",
						d: "M6.23,12.18c-1.97,0-3.58-1.61-3.58-3.58,0-2.11,1.71-3.58,4.17-3.58h3.98l-1.43-1.43c-.18-.18-.18-.47,0-.64.18-.18.46-.18.64,0l2.21,2.21c.09.09.13.2.13.32s-.05.24-.13.32l-2.21,2.21c-.18.18-.47.18-.64,0-.18-.18-.18-.47,0-.64l1.43-1.43h-3.98c-1.92,0-3.26,1.1-3.26,2.67,0,1.47,1.2,2.67,2.67,2.67.25,0,.46.2.46.46s-.2.46-.46.46Z"
					})], -1)])]),
					_: 1
				}, 8, ["title"]),
				_cache[6] || (_cache[6] = createBaseVNode("div", { class: "h-5 border-l" }, null, -1)),
				createVNode(Button_default, {
					variant: "outline",
					size: "unset",
					class: "pointer-events-auto h-7.5 w-12.5 rounded-[10px] bg-background",
					title: unref(t)("maskEditor.rotateLeft"),
					onClick: onRotateLeft
				}, {
					default: withCtx(() => [..._cache[2] || (_cache[2] = [createBaseVNode("svg", {
						viewBox: "-6 -7 15 15",
						class: "pointer-events-none size-6.25 fill-foreground"
					}, [createBaseVNode("path", { d: "m2.25-2.625c.3452 0 .625.2798.625.625v5c0 .3452-.2798.625-.625.625h-5c-.3452 0-.625-.2798-.625-.625v-5c0-.3452.2798-.625.625-.625h5zm1.25.625v5c0 .6904-.5596 1.25-1.25 1.25h-5c-.6904 0-1.25-.5596-1.25-1.25v-5c0-.6904.5596-1.25 1.25-1.25h5c.6904 0 1.25.5596 1.25 1.25zm-.1673-2.3757-.4419.4419-1.5246-1.5246 1.5416-1.5417.442.4419-.7871.7872h.9373c1.3807 0 2.5 1.1193 2.5 2.5h-.625c0-1.0355-.8395-1.875-1.875-1.875h-.9375l.7702.7702z" })], -1)])]),
					_: 1
				}, 8, ["title"]),
				createVNode(Button_default, {
					variant: "outline",
					size: "unset",
					class: "pointer-events-auto h-7.5 w-12.5 rounded-[10px] bg-background",
					title: unref(t)("maskEditor.rotateRight"),
					onClick: onRotateRight
				}, {
					default: withCtx(() => [..._cache[3] || (_cache[3] = [createBaseVNode("svg", {
						viewBox: "-9 -7 15 15",
						class: "pointer-events-none size-6.25 fill-foreground"
					}, [createBaseVNode("g", { transform: "scale(-1, 1)" }, [createBaseVNode("path", { d: "m2.25-2.625c.3452 0 .625.2798.625.625v5c0 .3452-.2798.625-.625.625h-5c-.3452 0-.625-.2798-.625-.625v-5c0-.3452.2798-.625.625-.625h5zm1.25.625v5c0 .6904-.5596 1.25-1.25 1.25h-5c-.6904 0-1.25-.5596-1.25-1.25v-5c0-.6904.5596-1.25 1.25-1.25h5c.6904 0 1.25.5596 1.25 1.25zm-.1673-2.3757-.4419.4419-1.5246-1.5246 1.5416-1.5417.442.4419-.7871.7872h.9373c1.3807 0 2.5 1.1193 2.5 2.5h-.625c0-1.0355-.8395-1.875-1.875-1.875h-.9375l.7702.7702z" })])], -1)])]),
					_: 1
				}, 8, ["title"]),
				createVNode(Button_default, {
					variant: "outline",
					size: "unset",
					class: "pointer-events-auto h-7.5 w-12.5 rounded-[10px] bg-background",
					title: unref(t)("maskEditor.mirrorHorizontal"),
					onClick: onMirrorHorizontal
				}, {
					default: withCtx(() => [..._cache[4] || (_cache[4] = [createBaseVNode("svg", {
						viewBox: "0 0 15 15",
						class: "pointer-events-none size-6.25 fill-foreground"
					}, [createBaseVNode("path", { d: "M7.5,1.5c-.28,0-.5.22-.5.5v11c0,.28.22.5.5.5s.5-.22.5-.5v-11c0-.28-.22-.5-.5-.5Z" }), createBaseVNode("path", { d: "M3.5,4.5l-2,3,2,3v-6ZM11.5,4.5v6l2-3-2-3Z" })], -1)])]),
					_: 1
				}, 8, ["title"]),
				createVNode(Button_default, {
					variant: "outline",
					size: "unset",
					class: "pointer-events-auto h-7.5 w-12.5 rounded-[10px] bg-background",
					title: unref(t)("maskEditor.mirrorVertical"),
					onClick: onMirrorVertical
				}, {
					default: withCtx(() => [..._cache[5] || (_cache[5] = [createBaseVNode("svg", {
						viewBox: "0 0 15 15",
						class: "pointer-events-none size-6.25 fill-foreground"
					}, [createBaseVNode("path", { d: "M2,7.5c0-.28.22-.5.5-.5h11c.28,0,.5.22.5.5s-.22.5-.5.5h-11c-.28,0-.5-.22-.5-.5Z" }), createBaseVNode("path", { d: "M4.5,4.5l3-2,3,2h-6ZM4.5,10.5h6l-3,2-3-2Z" })], -1)])]),
					_: 1
				}, 8, ["title"]),
				_cache[7] || (_cache[7] = createBaseVNode("div", { class: "h-5 w-px bg-border" }, null, -1)),
				createVNode(Button_default, {
					variant: "outline",
					size: "unset",
					class: "pointer-events-auto h-7.5 w-15 rounded-[10px] bg-background",
					onClick: onInvert
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(unref(t)("maskEditor.invert")), 1)]),
					_: 1
				}),
				createVNode(Button_default, {
					variant: "outline",
					size: "unset",
					class: "pointer-events-auto h-7.5 w-15 rounded-[10px] bg-background",
					onClick: onClear
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(unref(t)("maskEditor.clear")), 1)]),
					_: 1
				})
			])]), createBaseVNode("div", _hoisted_5, [createVNode(Button_default, {
				variant: "primary",
				disabled: !saveEnabled.value,
				onClick: handleSave
			}, {
				default: withCtx(() => [_cache[8] || (_cache[8] = createBaseVNode("i", { class: "pi pi-check" }, null, -1)), createTextVNode(" " + toDisplayString(saveButtonText.value), 1)]),
				_: 1
			}, 8, ["disabled"]), createVNode(Button_default, {
				variant: "secondary",
				onClick: handleCancel
			}, {
				default: withCtx(() => [_cache[9] || (_cache[9] = createBaseVNode("i", { class: "pi pi-times" }, null, -1)), createTextVNode(" " + toDisplayString(unref(t)("g.cancel")), 1)]),
				_: 1
			})])]);
		};
	}
});
//#endregion
export { TopBarHeader_default as default };
