import "./rolldown-runtime-xtsTai4I.js";
import { G as defineComponent, I as createBlock, Wt as unref, ct as openBlock, dt as renderSlot, q as guardReactiveProps, qt as normalizeProps, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { Mn as useForwardPropsEmits, jt as PopoverRoot_default } from "./vendor-reka-ui-NRTk7aIV.js";
//#endregion
//#region src/components/ui/popover/Popover.vue
var Popover_default = /* @__PURE__ */ defineComponent({
	__name: "Popover",
	props: {
		defaultOpen: { type: Boolean },
		open: { type: Boolean },
		modal: { type: Boolean }
	},
	emits: ["update:open"],
	setup(__props, { emit: __emit }) {
		const forwarded = useForwardPropsEmits(__props, __emit);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(PopoverRoot_default), normalizeProps(guardReactiveProps(unref(forwarded))), {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
				_: 3
			}, 16);
		};
	}
});
//#endregion
export { Popover_default as t };
