import "./rolldown-runtime-xtsTai4I.js";
import { Lt as layoutStore, U as resolveSubgraphInputTarget, t as LiteGraph } from "./litegraph-DsPnoImk.js";
import { t as useCommandStore } from "./commandStore-XD_i1hej.js";
import { y as resolveNode } from "./litegraphUtil-8EMdlR16.js";
import { t as useExecutionErrorStore } from "./executionErrorStore-DzGUJU_L.js";
import { t as delay } from "./delay-Cu8bS1zn.js";
import { t as useBillingContext } from "./useBillingContext-uo5ceiak.js";
import { n as useSettingStore } from "./settingStore-DRRi2kOn.js";
import { i as api } from "./api-BdJmXw98.js";
import { Ft as ref, Ot as effectScope, P as computed, Pt as readonly, Rt as shallowRef, bt as watch } from "./vendor-vue-core-CuN1excl.js";
import { Fr as createSharedComposable, Jn as useBreakpoints, Ur as until, ar as useEventListener, tr as useElementBounding, zn as breakpointsTailwind } from "./vendor-reka-ui-NRTk7aIV.js";
import { n as useWorkflowStore } from "./workflowStore-ChkUx7Si.js";
import { r as reportError } from "./reportError-BHgDVvfb.js";
import { S as isExecutionPathActive, p as getExecutionIdByNode, t as collectAllNodes, y as getRootParentNode } from "./graphTraversalUtil-BUK1cr2m.js";
import { n as useCanvasStore } from "./canvasStore-siYzI5aT.js";
import "./useFeatureFlags-B3zg5FdZ.js";
import { a as consumeFirstRunReplayRequest, r as useAuthStore, s as isFirstRunReplayRequested } from "./authStore-D2cL6XhN.js";
import { n as useExecutionStore } from "./executionStore-DrU24oQb.js";
import { n as app } from "./app-C-5f0uvA.js";
import { a as registerTour, l as registerCoachmark, r as FIRST_RUN_COACH_IDS, t as useOnboardingTourStore, u as unregisterCoachmark } from "./onboardingTourStore-DL-TBMHb.js";
import { f as topSafeInset } from "./workflowTabActivityStore-BwZie-5b.js";
import { t as filterOutputNodes } from "./nodeFilterUtil-CDjk3WM3.js";
import { t as useTransformState } from "./useTransformState-D8y5m-4I.js";
//#region src/services/useNewUserService.ts
function hasV2DraftHistory(raw) {
	if (!raw) return false;
	let parsed;
	try {
		parsed = JSON.parse(raw);
	} catch {
		reportError(/* @__PURE__ */ new Error("Workflow draft index is not valid JSON"), {
			surface: "graph",
			errorType: "error_parsing_workflow_draft_index",
			level: "warning",
			context: { length: raw.length }
		});
		return false;
	}
	if (!parsed || typeof parsed !== "object") return false;
	const { order, entries } = parsed;
	const orderLength = Array.isArray(order) ? order.length : 0;
	const entriesCount = entries && typeof entries === "object" ? Object.keys(entries).length : 0;
	return orderLength > 0 || entriesCount > 0;
}
function _useNewUserService() {
	const settingStore = useSettingStore();
	const pendingCallbacks = shallowRef([]);
	const isNewUserDetermined = ref(false);
	const isNewUserCached = ref(null);
	function reset() {
		pendingCallbacks.value = [];
		isNewUserDetermined.value = false;
		isNewUserCached.value = null;
	}
	function checkIsNewUser() {
		const isNewUserSettings = Object.keys(settingStore.settingValues).length === 0 || !settingStore.get("Comfy.TutorialCompleted");
		const hasNoLegacyWorkflow = !localStorage.getItem("workflow") && !localStorage.getItem("Comfy.PreviousWorkflow");
		const hasNoV1Drafts = !localStorage.getItem("Comfy.Workflow.Drafts") && !localStorage.getItem("Comfy.Workflow.DraftOrder");
		const hasNoV2DraftIndex = !hasV2DraftHistory(localStorage.getItem("Comfy.Workflow.DraftIndex.v2:personal"));
		return isNewUserSettings && hasNoLegacyWorkflow && hasNoV1Drafts && hasNoV2DraftIndex;
	}
	async function registerInitCallback(callback) {
		if (isNewUserDetermined.value) {
			if (isNewUserCached.value) try {
				await callback();
			} catch (error) {
				console.error("New user initialization callback failed:", error);
			}
		} else pendingCallbacks.value = [...pendingCallbacks.value, callback];
	}
	async function initializeIfNewUser() {
		if (isNewUserDetermined.value) return;
		isNewUserCached.value = checkIsNewUser();
		isNewUserDetermined.value = true;
		if (!isNewUserCached.value) {
			pendingCallbacks.value = [];
			return;
		}
		await settingStore.set("Comfy.InstalledVersion", "1.59.1");
		for (const callback of pendingCallbacks.value) try {
			await callback();
		} catch (error) {
			console.error("New user initialization callback failed:", error);
		}
		pendingCallbacks.value = [];
	}
	function isNewUser() {
		return isNewUserDetermined.value ? isNewUserCached.value : null;
	}
	return {
		registerInitCallback,
		initializeIfNewUser,
		isNewUser,
		reset
	};
}
var useNewUserService = createSharedComposable(_useNewUserService);
//#endregion
//#region src/renderer/extensions/firstRunTour/roles/tourRolePins.ts
/**
* The kind a sink node type produces, so the drift guard can hold the two in
* step. Video sinks are listed because they are fed IMAGE frames, so the slot
* type alone would call their output an image.
*/
var MEDIA_KIND_BY_SINK_TYPE = {
	SaveImage: "image",
	SaveImageAdvanced: "image",
	SaveVideo: "video",
	SaveAnimatedWEBP: "video",
	SaveAnimatedPNG: "video",
	SaveWEBM: "video",
	VHS_VideoCombine: "video"
};
/**
* The templates the tour supports, pinned by hand. A prompt pinned inside a
* subgraph is spotlit through the root-graph node hosting it.
*/
var TOUR_ROLE_PINS = {
	image_krea2_turbo_t2i: {
		prompt: {
			id: 19,
			type: "PrimitiveStringMultiline"
		},
		sink: {
			id: 29,
			type: "SaveImage"
		},
		mediaKind: "image"
	},
	image_z_image_turbo: {
		prompt: {
			id: 27,
			type: "CLIPTextEncode"
		},
		sink: {
			id: 9,
			type: "SaveImage"
		},
		mediaKind: "image"
	},
	video_ltx2_3_i2v: {
		source: {
			id: 269,
			type: "LoadImage"
		},
		prompt: {
			id: 319,
			type: "PrimitiveStringMultiline"
		},
		sink: {
			id: 75,
			type: "SaveVideo"
		},
		mediaKind: "video"
	},
	video_wan2_2_14B_i2v: {
		source: {
			id: 97,
			type: "LoadImage"
		},
		prompt: {
			id: 93,
			type: "CLIPTextEncode"
		},
		sink: {
			id: 108,
			type: "SaveVideo"
		},
		mediaKind: "video"
	},
	"templates-image_to_real": {
		source: {
			id: 14,
			type: "LoadImage"
		},
		sink: {
			id: 18,
			type: "SaveImage"
		},
		mediaKind: "image"
	},
	image_qwen_image_edit_2509: {
		source: {
			id: 78,
			type: "LoadImage"
		},
		prompt: {
			id: 111,
			type: "TextEncodeQwenImageEditPlus"
		},
		sink: {
			id: 469,
			type: "SaveImageAdvanced"
		},
		mediaKind: "image"
	},
	flux_fill_inpaint_example: {
		source: {
			id: 17,
			type: "LoadImage"
		},
		prompt: {
			id: 23,
			type: "CLIPTextEncode"
		},
		sink: {
			id: 9,
			type: "SaveImage"
		},
		mediaKind: "image"
	},
	video_ltx2_i2v_distilled: {
		source: {
			id: 98,
			type: "LoadImage"
		},
		prompt: {
			id: 3,
			type: "CLIPTextEncode"
		},
		sink: {
			id: 75,
			type: "SaveVideo"
		},
		mediaKind: "video"
	}
};
//#endregion
//#region src/renderer/extensions/firstRunTour/roles/heuristicRoles.ts
var MEDIA_KIND_BY_SLOT_TYPE = {
	IMAGE: "image",
	VIDEO: "video"
};
/** `neg` alone is the abbreviation; anything longer must be `negative*`, or
* `negate`, `negligible` and Spanish `negro` disqualify a real prompt. */
var DISQUALIFYING = [
	"negative",
	"neg",
	"system",
	"undesired",
	"avoid"
];
/** `anti` names the negative box only next to the noun — `Anti-prompt`,
* `AntiPrompt`, `ANTIPROMPT` — since `anti_aliasing` and `antique` are ordinary
* words a real prompt carries. Read off the normalised label, not its words, so
* the pair survives the separator and camelCase spellings alike. */
var ANTI_PROMPT = /\banti ?prompts?\b/;
function disqualified(word) {
	return DISQUALIFYING.includes(word) || word.startsWith("negative");
}
function readsAsAntiPrompt(label) {
	return ANTI_PROMPT.test(labelWords(label).join(" "));
}
/** Real templates ship nodes with no title and widgets with no name. */
function labelWords(label) {
	return (label ?? "").replace(/([a-z0-9])([A-Z])/g, "$1 $2").toLowerCase().replace(/[^a-z0-9]+/g, " ").split(" ").filter(Boolean);
}
function slotType(slot) {
	return String(slot.type ?? "").toUpperCase();
}
/** Multiline is what separates a prompt box from a seed or a filename. */
function promptWidgets(node) {
	return (node.widgets ?? []).filter((widget) => widget.type === "customtext" || widget.options.multiline);
}
function consumerInputNames(nodes) {
	const names = /* @__PURE__ */ new Map();
	for (const consumer of nodes) {
		if (consumer.isVirtualNode) continue;
		consumer.inputs.forEach((input, slot) => {
			const producer = consumer.getInputNode(slot);
			if (producer) names.set(producer, [...names.get(producer) ?? [], input.name]);
		});
	}
	return names;
}
/** A text node inside a subgraph is titled nothing useful; its port is not. */
function exposedInputNames(nodes) {
	const names = /* @__PURE__ */ new Map();
	for (const host of nodes) {
		if (!host.isSubgraphNode()) continue;
		for (const input of host.inputs) {
			const target = resolveSubgraphInputTarget(host, input.name);
			const inner = target && host.subgraph.getNodeById(target.nodeId);
			if (inner) names.set(inner, [...names.get(inner) ?? [], input.name]);
		}
	}
	return names;
}
/**
* Ranks a text node on its title, its widget's name, any subgraph port wired to
* it, and the input name it feeds one hop on, normalised for case and
* separators. Anything reading as a negative prompt disqualifies.
*/
function promptScore(labels, fedInputNames) {
	const words = labels.flatMap(labelWords);
	const fed = fedInputNames.flatMap(labelWords);
	if ([...words, ...fed].some(disqualified)) return -1;
	if ([...labels, ...fedInputNames].some(readsAsAntiPrompt)) return -1;
	if (fed.includes("positive")) return 3;
	if (words.includes("positive")) return 2;
	if (words.includes("prompt")) return 1;
	return 0;
}
/**
* Each node scores on its best prompt widget, so one carrying both a positive
* and a negative box is not disqualified by widget order. A tie at the top
* resolves to nothing; a lone text box wins by being alone. Virtual nodes are
* skipped: a note never runs, and a subgraph host's promoted widgets mirror an
* interior node that host-maps back to it, tying a prompt against itself.
*/
function findPrompt(nodes) {
	const consumers = consumerInputNames(nodes);
	const exposed = exposedInputNames(nodes);
	const ranked = nodes.flatMap((node) => {
		if (node.isVirtualNode) return [];
		const widgets = promptWidgets(node);
		if (!widgets.length) return [];
		const fed = consumers.get(node) ?? [];
		const shared = [node.title, ...exposed.get(node) ?? []];
		const scores = widgets.map((w) => promptScore([...shared, w.name], fed));
		return [{
			node,
			score: Math.max(...scores)
		}];
	}).sort((a, b) => b.score - a.score);
	const best = ranked.at(0);
	const runnerUp = ranked.at(1);
	if (!best || best.score < 0) return null;
	return !runnerUp || best.score > runnerUp.score ? best.node : null;
}
/** Produces an image and consumes nothing. Two of them is a coin flip. */
function findSource(nodes) {
	const sources = nodes.filter((node) => !node.isVirtualNode && !node.inputs.some((input) => input.link != null) && node.outputs.some((output) => slotType(output) === "IMAGE"));
	return sources.length === 1 ? sources[0] : null;
}
/** Any output node fed media can show the result; disagreeing kinds cannot. */
function findSink(nodes) {
	const sinks = filterOutputNodes(nodes).flatMap((node) => {
		for (const input of node.inputs) {
			const slotKind = MEDIA_KIND_BY_SLOT_TYPE[slotType(input)];
			if (input.link == null || !slotKind) continue;
			return [{
				node,
				slotKind,
				mediaKind: MEDIA_KIND_BY_SINK_TYPE[node.type] ?? slotKind
			}];
		}
		return [];
	});
	const first = sinks.at(0);
	if (!first) return null;
	if (!sinks.every(({ slotKind }) => slotKind === first.slotKind)) return null;
	return sinks.find(({ mediaKind }) => mediaKind === "video") ?? first;
}
/** Roles for a shared workflow or an unpinned template. No sink, no tour. */
function heuristicRoles(graph) {
	const active = collectAllNodes(graph).filter((node) => {
		const executionId = getExecutionIdByNode(graph, node);
		return executionId ? isExecutionPathActive(graph, executionId) : false;
	});
	const sink = findSink(active);
	if (!sink) return null;
	return {
		source: findSource(active),
		prompt: findPrompt(active),
		sink: sink.node,
		mediaKind: sink.mediaKind
	};
}
//#endregion
//#region src/renderer/extensions/firstRunTour/roles/resolveTourRoles.ts
/** The root-graph node a role is spotlit through: itself, or the subgraph node holding it. */
function rootHost(node, root) {
	if (!node) return null;
	if (node.graph === root) return node.id;
	const executionId = getExecutionIdByNode(root, node);
	return executionId ? getRootParentNode(root, executionId)?.id ?? null : null;
}
/** The pinned type is the guard: an id alone matches any graph that has it. */
function resolvePin(pin, root) {
	if (!pin) return null;
	const node = resolveNode(pin.id, root);
	return node?.type === pin.type ? rootHost(node, root) : null;
}
/** Read off the graph itself, then host-mapped the same way pins are. */
function resolveFromGraph(graph) {
	const roles = heuristicRoles(graph);
	if (!roles) return null;
	return {
		source: rootHost(roles.source, graph),
		promptHost: rootHost(roles.prompt, graph),
		sink: rootHost(roles.sink, graph),
		mediaKind: roles.mediaKind
	};
}
/**
* Validates a template's pins against the live graph, falling back to reading
* the roles off the graph for anything unpinned — a shared workflow, or a
* template URL nobody curated. A pin the graph no longer contains degrades to
* null so its step is omitted rather than spotlighting a node that is gone.
*/
function resolveTourRoles(graph, templateId) {
	if (templateId === void 0 || !Object.hasOwn(TOUR_ROLE_PINS, templateId)) return resolveFromGraph(graph);
	const pins = TOUR_ROLE_PINS[templateId];
	return {
		source: resolvePin(pins.source, graph),
		promptHost: resolvePin(pins.prompt, graph),
		sink: resolvePin(pins.sink, graph),
		mediaKind: pins.mediaKind
	};
}
//#endregion
//#region src/renderer/extensions/firstRunTour/roles/tourSequence.ts
/** A role that did not resolve omits its step; Run targets the toolbar, not the graph. */
function sequenceBuilder({ source, promptHost, sink, mediaKind }) {
	return [
		...source ? [{
			kind: "upload",
			nodeId: source
		}] : [],
		...promptHost ? [{
			kind: "prompt",
			nodeId: promptHost
		}] : [],
		{ kind: "run" },
		...sink ? [{
			kind: "result",
			nodeId: sink,
			mediaKind
		}] : []
	];
}
//#endregion
//#region src/renderer/extensions/firstRunTour/tour/cameraFraming.ts
var FOCUS_DURATION_MS = 450;
/** Never magnify past this: the aim is a node that reads, not one that dominates. */
var MAX_FOCUS_SCALE = .65;
var CARD_COLUMN = 380;
/**
* Fill fraction that frames `bounds` beside the card. The fit centres the node
* and so splits the free space evenly, hence room for a card column on each
* side, and for the top bar on each end — the canvas runs the full height of
* the window, underneath that bar, so a node fitted to the whole of it hides
* its own title behind the workflow tabs. Inverts litegraph's fit, which
* solves each axis as `(fill * side) / max(bound, 300)` and takes the smaller,
* so the binding axis has to be handed the larger fill.
*/
function focusFill(bounds, viewport) {
	const [, , width, height] = bounds;
	const sideRoom = viewport.width - CARD_COLUMN * 2;
	const usableWidth = sideRoom > 0 ? sideRoom : viewport.width;
	const endRoom = viewport.height - topSafeInset() * 2;
	const usableHeight = endRoom > 0 ? endRoom : viewport.height;
	const scale = Math.min(usableWidth / Math.max(width, 1), usableHeight / Math.max(height, 1), MAX_FOCUS_SCALE);
	return Math.max(scale * Math.max(width, 300) / viewport.width, scale * Math.max(height, 300) / viewport.height);
}
function prefersReducedMotion() {
	return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}
/** Re-solves the fill each time: it is a fraction of a viewport that can resize. */
function fitInstantly(bounds) {
	const canvas = useCanvasStore().canvas;
	const viewport = canvas?.canvas.getBoundingClientRect();
	if (!canvas || !viewport?.width || !viewport.height) return;
	canvas.ds.fitToBounds(bounds, { zoom: focusFill(bounds, viewport) });
	canvas.setDirty(true, true);
}
var SETTLED_PX = 8;
var SETTLED_SCALE = .01;
/** The scale litegraph's fit lands on: it takes whichever axis binds first. */
function framedScale(bounds, viewport) {
	const zoom = focusFill(bounds, viewport);
	return Math.min(zoom * viewport.width / Math.max(bounds[2], 300), zoom * viewport.height / Math.max(bounds[3], 300));
}
/** Back onto a step already framed would otherwise animate 0px for 750ms. */
function alreadyFramed(bounds, ds, viewport) {
	const centreX = (bounds[0] + bounds[2] / 2 + ds.offset[0]) * ds.scale;
	const centreY = (bounds[1] + bounds[3] / 2 + ds.offset[1]) * ds.scale;
	return Math.abs(ds.scale - framedScale(bounds, viewport)) <= SETTLED_SCALE && Math.abs(centreX - viewport.width / 2) < SETTLED_PX && Math.abs(centreY - viewport.height / 2) < SETTLED_PX;
}
/**
* Brings a node into view for the step that spotlights it. Resolves once the
* camera has landed, so an opening tour reveals its card on a still view.
*
* @param glide Wait out the card's travel to this step first, so only one thing
* moves at a time. The tour's first card has nowhere to travel from.
*/
async function frameNode(nodeId, signal, { glide = true } = {}) {
	const canvas = useCanvasStore().canvas;
	const node = canvas?.graph?.getNodeById(nodeId);
	const viewport = canvas?.canvas.getBoundingClientRect();
	if (!canvas || !node || !viewport?.width || !viewport.height) return;
	const bounds = node.boundingRect;
	window.addEventListener("resize", () => fitInstantly(bounds), { signal });
	if (prefersReducedMotion()) return fitInstantly(bounds);
	if (alreadyFramed(bounds, canvas.ds, viewport)) return;
	if (glide) await delay(300, { signal });
	canvas.animateToBounds(bounds, {
		zoom: focusFill(bounds, viewport),
		duration: FOCUS_DURATION_MS
	});
	await delay(FOCUS_DURATION_MS, { signal });
}
//#endregion
//#region src/renderer/extensions/firstRunTour/tour/canvasCoachTarget.ts
/** A canvas node as a coachmark target, derived from its layout and the camera. */
function canvasNodeTarget(nodeId) {
	const { camera } = useTransformState();
	const canvasStore = useCanvasStore();
	const resolvedGraph = canvasStore.currentGraph;
	const scope = effectScope(true);
	const layout = resolvedGraph ? scope.run(() => layoutStore.getNodeLayoutRef(resolvedGraph.rootGraph.id, nodeId)) : null;
	const canvasBounds = scope.run(() => useElementBounding(() => canvasStore.canvas?.canvas));
	return {
		getRect: () => {
			if (canvasStore.currentGraph !== resolvedGraph) return null;
			if (canvasStore.currentGraph?.getNodeById(nodeId)?.collapsed) return null;
			const bounds = layout?.value?.bounds;
			if (!bounds) return null;
			const title = LiteGraph.NODE_TITLE_HEIGHT || 0;
			const { x, y, z } = camera;
			return new DOMRect((bounds.x + x) * z + canvasBounds.left.value, (bounds.y - title + y) * z + canvasBounds.top.value, bounds.width * z, (bounds.height + title) * z);
		},
		onMove: (notify) => {
			const stopWatch = watch(() => [
				camera.x,
				camera.y,
				camera.z,
				layout?.value
			], notify, { flush: "post" });
			const stopResize = useEventListener(window, "resize", notify);
			return () => {
				stopWatch();
				stopResize();
			};
		},
		dispose: () => scope.stop()
	};
}
//#endregion
//#region src/renderer/extensions/firstRunTour/tour/firstRunTourDefinition.ts
var COACH_ID = {
	upload: FIRST_RUN_COACH_IDS.source,
	prompt: FIRST_RUN_COACH_IDS.prompt,
	run: FIRST_RUN_COACH_IDS.runButton,
	result: FIRST_RUN_COACH_IDS.sink
};
/** Undoes the last registration; the tour holds one target set at a time. */
var releaseRegistered = () => {};
/** Drops the canvas targets a finished tour registered. */
function releaseFirstRunTargets() {
	releaseRegistered();
	releaseRegistered = () => {};
}
function registerCanvasTargets(sequence) {
	const registered = [];
	for (const step of sequence) {
		if (step.kind === "run") continue;
		const id = COACH_ID[step.kind];
		const target = canvasNodeTarget(step.nodeId);
		registerCoachmark(id, target);
		registered.push([id, target]);
	}
	releaseRegistered = () => {
		for (const [id, target] of registered) {
			unregisterCoachmark(id, target);
			target.dispose?.();
		}
	};
}
function tourShape({ source, promptHost, sink, mediaKind }) {
	if (!promptHost || !sink) return "other";
	if (!source) return "t2i";
	return mediaKind === "video" ? "i2v" : "image-edit";
}
/**
* A step's variant is part of its name, so the engine resolves the copy from
* `onboardingCoachmarks.firstRun.<name>` without knowing what a template is.
*/
function toCoachStep(step, index, { shape, runState }) {
	const common = {
		kind: "spotlight",
		coachId: COACH_ID[step.kind],
		deferTarget: true,
		cursor: true,
		interactive: step.kind !== "result"
	};
	if (step.kind === "run") return {
		...common,
		name: "run",
		placement: "bottom",
		selfAdvancing: true
	};
	const framed = {
		...common,
		placement: "auto",
		onEnter: (signal) => frameNode(step.nodeId, signal, { glide: index > 0 })
	};
	if (step.kind === "result") return {
		...framed,
		get name() {
			if (runState.value === "generating") return "result.generating";
			if (runState.value === "failed") return "result.failed";
			return `result.${step.mediaKind}`;
		}
	};
	return {
		...framed,
		name: `${step.kind}.${shape}`
	};
}
/**
* Builds the first-run tour for a template, or for whatever is on the canvas
* when no template id came with it. A graph the roles cannot be read off
* leaves nothing worth guiding anyone through — "click Run" alone is not a
* tour — so it yields no steps and the engine reports that it did not start.
*/
async function firstRunTourSteps(templateId, runState) {
	releaseFirstRunTargets();
	const graph = app.rootGraphOrUndefined;
	if (!graph) return {
		steps: [],
		reason: "no_roles"
	};
	const roles = resolveTourRoles(graph, templateId);
	if (!roles) return {
		steps: [],
		reason: "no_roles"
	};
	const sequence = sequenceBuilder(roles);
	if (sequence.every((step) => step.kind === "run")) return {
		steps: [],
		reason: "run_only"
	};
	registerCanvasTargets(sequence);
	const context = {
		shape: tourShape(roles),
		runState
	};
	return { steps: sequence.map((step, index) => toCoachStep(step, index, context)) };
}
//#endregion
//#region src/renderer/extensions/firstRunTour/tour/useFirstRunTourController.ts
var RUN_BUTTON_SELECTOR = "[data-testid=\"queue-button\"], [data-testid=\"subscribe-to-run-button\"]";
/** An undimmed look at the workflow the user chose, before the tour dims it. */
var INTRO_PREVIEW_MS = 500;
var OFFLINE_GRACE_MS = 2e4;
/** How long a submitted run has to be accepted before the card stops promising. */
var ACCEPT_DEADLINE_MS = 15e3;
function useFirstRunTourControllerInternal() {
	const engine = useOnboardingTourStore();
	const billing = useBillingContext();
	const executionStore = useExecutionStore();
	const executionErrorStore = useExecutionErrorStore();
	const workflowStore = useWorkflowStore();
	const canvasStore = useCanvasStore();
	const settingStore = useSettingStore();
	const desktopLayout = useBreakpoints(breakpointsTailwind).greaterOrEqual("md");
	const tourWorkflow = shallowRef(null);
	const nudgeArmed = ref(false);
	let tourStart = { phase: "idle" };
	/** Only a tour walked to the end made a first result to be congratulated for. */
	const tourWasCompleted = ref(false);
	/**
	* The half of the tour's context that exists before the tour does: a canvas
	* the steps can point at. Linear mode `display:none`s it entirely, and below
	* the desktop layout the spotlights are placed against a screen that isn't
	* there. Split out so it can also serve as the precondition for opening one.
	*/
	const canvasContextHolds = computed(() => desktopLayout.value && !canvasStore.linearMode);
	const tourContextHolds = computed(() => canvasContextHolds.value && workflowStore.activeWorkflow === tourWorkflow.value);
	const onRunStep = computed(() => engine.activeTour === "firstRun" && engine.step?.kind === "spotlight" && engine.step.selfAdvancing === true);
	/** Recorded, not derived: the queue clears a status as soon as it turns terminal. */
	const runState = ref("idle");
	watch(() => [executionStore.getWorkflowStatus(tourWorkflow.value), executionErrorStore.hasNodeError || executionErrorStore.hasPromptError], ([status, refused], previous) => {
		if (status !== void 0) stopAcceptDeadline();
		if (status === "running" && previous[0] !== "running") runState.value = "generating";
		else if (status === "completed") runState.value = "succeeded";
		else if (status === "failed") runState.value = "failed";
		else if (refused && runState.value === "generating") runState.value = "failed";
		else if (status === void 0 && previous[0] === "running") runState.value = "failed";
	});
	/**
	* The queue stores a job the moment it accepts a submission, so a job
	* carrying this tour's workflow is proof of acceptance. A refused submission
	* never gets one.
	*
	* Deliberately *not* the workflow status: that is only written by
	* `handleExecutionStart`, and a cloud job sits accepted in
	* `initializingJobIds` — "Waiting for a machine" — with no status at all
	* while a worker is allocated. Allocation routinely outlasts any deadline
	* short enough to be useful, so keying on status would fail healthy runs.
	*/
	const tourRunAccepted = computed(() => Object.values(executionStore.queuedJobs).some((job) => job.workflow === tourWorkflow.value));
	/**
	* A submission the backend refuses never gets a prompt_id, so no status ever
	* appears and none of the branches above can fire. Account preconditions —
	* sign-in, subscription, credits — are deliberately kept out of the error
	* stores by `ComfyApp.queuePrompt`, so the refusal is invisible there too.
	*
	* Give *acceptance* a deadline, not the run. Acceptance arrives on the
	* queuePrompt response rather than the socket, so this cannot pre-empt the
	* longer offline grace: a run accepted at all disarms this immediately and
	* leaves the connection question to `OFFLINE_GRACE_MS`.
	*
	* Acceptance is not the only disarm. `resetExecutionState` drops a job from
	* `queuedJobs` without clearing its status, so a run can report a status
	* while this reads false. A refusal produces neither signal.
	*
	* Losing acceptance is itself a signal, not a re-armed deadline. Two paths
	* drop the job without ever writing an outcome:
	*
	* - an accepted job that disappears with **no status written at all** — the
	*   cloud "waiting for a machine" job that is cancelled or reconciled away
	* - `handleServiceLevelError` ("Job has stagnated"), which drops the job and
	*   records a prompt error but never touches `workflowStatus`, so the
	*   `running` written by `handleExecutionStart` outlives the run
	*
	* Not the mid-run credits path: #15161 made
	* `handleAccountPreconditionError` clear the status, so that one already
	* ends via the `undefined`-after-`running` branch above.
	*
	* A finished run leaves the queue too, but reports a terminal status in the
	* same flush, and the terminal branches above overwrite unconditionally — so
	* the outcome wins whichever watcher runs first.
	*/
	watch(tourRunAccepted, (accepted) => {
		if (accepted) stopAcceptDeadline();
		else if (runState.value === "generating") runState.value = "failed";
	});
	let acceptTimer;
	function stopAcceptDeadline() {
		clearTimeout(acceptTimer);
		acceptTimer = void 0;
	}
	function startAcceptDeadline() {
		stopAcceptDeadline();
		if (tourRunAccepted.value) return;
		acceptTimer = setTimeout(() => {
			stopAcceptDeadline();
			if (runState.value === "generating") runState.value = "failed";
		}, ACCEPT_DEADLINE_MS);
	}
	let offlineTimer;
	function stopOfflineGrace() {
		clearTimeout(offlineTimer);
		offlineTimer = void 0;
	}
	useEventListener(api, "reconnecting", () => {
		if (runState.value !== "generating" || offlineTimer) return;
		offlineTimer = setTimeout(() => {
			stopOfflineGrace();
			if (runState.value === "generating") runState.value = "failed";
		}, OFFLINE_GRACE_MS);
	});
	useEventListener(api, "reconnected", stopOfflineGrace);
	/**
	* A run outlives the step that starts it, so the click moves the tour on. One
	* the paywall will refuse never queues, so the tour parks and leaves the
	* subscribe button to open its own dialog.
	*/
	useEventListener(document, "click", (event) => {
		if (!onRunStep.value) return;
		if (!(event.target instanceof Element)) return;
		if (!event.target.closest(RUN_BUTTON_SELECTOR)) return;
		if (!billing.canRunWorkflows.value) {
			engine.postpone();
			return;
		}
		runState.value = "generating";
		startAcceptDeadline();
		engine.next();
	}, { capture: true });
	watch(() => engine.activeTour === "firstRun", (active) => {
		if (active) return;
		const ending = engine.lastEnding;
		tourWasCompleted.value = ending?.tour === "firstRun" && ending.outcome === "completed";
		nudgeArmed.value = true;
		stopOfflineGrace();
		stopAcceptDeadline();
		releaseFirstRunTargets();
		tourWorkflow.value = null;
		runState.value = "idle";
	});
	function dismissNudge() {
		nudgeArmed.value = false;
	}
	function ownsTourStart(ownership) {
		return tourStart.phase !== "idle" && tourStart.ownership === ownership;
	}
	function releaseTourStart(ownership) {
		if (ownsTourStart(ownership)) tourStart = { phase: "idle" };
	}
	async function writeRenderer(ownership, enabled, restoreRenderer) {
		const write = settingStore.set("Comfy.VueNodes.Enabled", enabled);
		const writingState = {
			phase: "writingRenderer",
			ownership,
			restoreRenderer,
			write
		};
		tourStart = writingState;
		try {
			await write;
		} finally {
			if (tourStart === writingState) tourStart = {
				phase: "claimed",
				ownership,
				restoreRenderer
			};
		}
	}
	async function cleanUpFailedTourStart(ownership, shouldCancel) {
		const currentStart = tourStart;
		if (currentStart.phase === "idle" || currentStart.ownership !== ownership) return;
		releaseFirstRunTargets();
		tourWorkflow.value = null;
		const { restoreRenderer } = currentStart;
		if (restoreRenderer && shouldCancel()) return;
		if (restoreRenderer) await writeRenderer(ownership, false, restoreRenderer);
		releaseTourStart(ownership);
	}
	function canBeginTour(shouldCancel) {
		return !shouldCancel() && !engine.activeTour && canvasContextHolds.value;
	}
	async function claimTourStart(ownership) {
		const previousStart = tourStart;
		const restoreRenderer = previousStart.phase === "idle" ? !settingStore.get("Comfy.VueNodes.Enabled") : previousStart.restoreRenderer;
		if (previousStart.phase === "writingRenderer") {
			tourStart = {
				...previousStart,
				ownership
			};
			await previousStart.write.catch(() => void 0);
			if (ownsTourStart(ownership)) tourStart = {
				phase: "claimed",
				ownership,
				restoreRenderer
			};
		} else tourStart = {
			phase: "claimed",
			ownership,
			restoreRenderer
		};
		return restoreRenderer;
	}
	async function claimRendererForTour(ownership) {
		const restoreRenderer = await claimTourStart(ownership);
		if (!ownsTourStart(ownership)) return restoreRenderer;
		if (restoreRenderer && !settingStore.get("Comfy.VueNodes.Enabled")) await writeRenderer(ownership, true, restoreRenderer);
		return restoreRenderer;
	}
	async function cancelPendingStart() {
		if (tourStart.phase === "idle") return;
		const ownership = Symbol("cancelled-first-run-tour-start");
		try {
			const restoreRenderer = await claimTourStart(ownership);
			if (ownsTourStart(ownership) && restoreRenderer && settingStore.get("Comfy.VueNodes.Enabled")) await writeRenderer(ownership, false, restoreRenderer);
		} finally {
			releaseTourStart(ownership);
		}
	}
	/** False when there is no tour to give; any renderer switch is undone. */
	async function beginTour(templateId, shouldCancel = () => false) {
		const ownership = Symbol("first-run-tour-start");
		if (!canBeginTour(shouldCancel)) return false;
		const restoreRenderer = await claimRendererForTour(ownership);
		if (!ownsTourStart(ownership) || shouldCancel()) return false;
		tourStart = {
			phase: "previewing",
			ownership,
			restoreRenderer
		};
		tourWorkflow.value = workflowStore.activeWorkflow ?? null;
		runState.value = "idle";
		nudgeArmed.value = false;
		registerTour("firstRun", () => firstRunTourSteps(templateId, runState), tourContextHolds);
		await delay(INTRO_PREVIEW_MS);
		const contextStillHolds = () => canvasContextHolds.value;
		const started = ownsTourStart(ownership) && contextStillHolds() && !shouldCancel() && await engine.startTour("firstRun");
		if (!started) await cleanUpFailedTourStart(ownership, shouldCancel);
		else releaseTourStart(ownership);
		return started;
	}
	return {
		beginTour,
		cancelPendingStart,
		nudgeArmed: readonly(nudgeArmed),
		tourWasCompleted: readonly(tourWasCompleted),
		dismissNudge
	};
}
var useFirstRunTourController = createSharedComposable(useFirstRunTourControllerInternal);
//#endregion
//#region src/renderer/extensions/firstRunTour/gettingStarted/firstRunEntry.ts
var STARTUP_DECISION_TIMEOUT_MS = 6e4;
function finishFirstRunHandoff(state, ownership) {
	if (state.phase !== "handoff" || !state.handoffs.has(ownership)) return state;
	const handoffs = new Set(state.handoffs);
	handoffs.delete(ownership);
	return handoffs.size === 0 ? { phase: "released" } : {
		phase: "handoff",
		handoffs
	};
}
function transitionFirstRunScreen(state, event) {
	switch (event.type) {
		case "shown": return { phase: "visible" };
		case "dismissed": return state.phase === "visible" ? { phase: "released" } : state;
		case "released": return { phase: "released" };
		case "handoffStarted": return {
			phase: "handoff",
			handoffs: /* @__PURE__ */ new Set([...state.phase === "handoff" ? state.handoffs : [], event.ownership])
		};
		case "handoffFinished": return finishFirstRunHandoff(state, event.ownership);
	}
}
var useFirstRunEntry = createSharedComposable(() => {
	const authStore = useAuthStore();
	const settingStore = useSettingStore();
	const firstRunScreen = ref({ phase: "released" });
	const startupDecided = ref(false);
	let authGeneration = 0;
	useBreakpoints(breakpointsTailwind).greaterOrEqual("md");
	const gettingStartedVisible = computed(() => firstRunScreen.value.phase === "visible");
	const firstRunHoldsScreen = computed(() => firstRunScreen.value.phase !== "released");
	function dispatchFirstRunScreen(event) {
		firstRunScreen.value = transitionFirstRunScreen(firstRunScreen.value, event);
	}
	watch(() => authStore.userId, (userId, previousUserId) => {
		if (previousUserId === void 0 || userId === previousUserId) return;
		authGeneration++;
		dispatchFirstRunScreen({ type: "released" });
		useFirstRunTourController().cancelPendingStart().catch((error) => reportError(error, {
			surface: "platform",
			errorType: "failure_restoring_first_run_renderer_setting",
			level: "warning"
		}));
		const tourStore = useOnboardingTourStore();
		if (tourStore.activeTour === "firstRun") tourStore.postpone();
	}, { flush: "sync" });
	function decideFirstRun() {
		return "complete";
	}
	function isFirstRunCandidate() {
		return decideFirstRun() === "getting-started";
	}
	async function handleStartupOutcome(outcome) {
		try {
			await showFirstRunScreen(outcome);
		} finally {
			if (outcome !== "url-intent") startupDecided.value = true;
		}
	}
	async function showFirstRunScreen(outcome) {
		const decision = decideFirstRun();
		if (!(isFirstRunReplayRequested(authStore.userId) && decision === "getting-started")) {
			if (outcome === "restored") return;
			if (settingStore.get("Comfy.TutorialCompleted")) return;
		}
		if (outcome === "url-intent") {
			if (decision === "complete") await markTutorialCompleted();
			return;
		}
		if (decision === "getting-started") {
			dispatchFirstRunScreen({ type: "shown" });
			consumeFirstRunReplayRequest(authStore.userId);
			return;
		}
		if (decision === "complete") await markTutorialCompleted();
		await useCommandStore().execute("Comfy.BrowseTemplates");
	}
	async function handleUrlWorkflow(outcome, templateId, sharedStatus) {
		try {
			if (!isTourableUrlWorkflow(outcome, templateId, sharedStatus)) return;
			const shareLoaded = isSharedWorkflowLoaded(sharedStatus);
			const ownerId = authStore.userId;
			if (!await useFirstRunTourController().beginTour(shareLoaded ? void 0 : templateId, () => authStore.userId !== ownerId)) return;
			consumeFirstRunReplayRequest(ownerId);
			await markTutorialCompleted();
		} finally {
			startupDecided.value = true;
		}
	}
	function isTourableUrlWorkflow(outcome, templateId, sharedStatus) {
		if (outcome !== "url-intent" || !isFirstRunCandidate()) return false;
		return templateId !== void 0 || isSharedWorkflowLoaded(sharedStatus);
	}
	function isSharedWorkflowLoaded(status) {
		return status === "loaded" || status === "loaded-without-assets";
	}
	let startupDecision;
	function whenStartupDecided() {
		if (startupDecided.value) return Promise.resolve(true);
		startupDecision ??= until(startupDecided).toBe(true, {
			timeout: STARTUP_DECISION_TIMEOUT_MS,
			throwOnTimeout: false
		});
		return startupDecision;
	}
	async function markTutorialCompleted() {
		try {
			await settingStore.set("Comfy.TutorialCompleted", true);
		} catch (error) {
			reportError(error, {
				surface: "platform",
				errorType: "failure_writing_tutorial_completed_setting",
				level: "warning"
			});
		}
	}
	async function dismissGettingStarted() {
		dispatchFirstRunScreen({ type: "dismissed" });
		await markTutorialCompleted();
	}
	async function dismissIntoFirstRunTour(templateId) {
		const ownerId = authStore.userId;
		const ownerGeneration = authGeneration;
		const ownership = Symbol("first-run-tour-handoff");
		dispatchFirstRunScreen({
			type: "handoffStarted",
			ownership
		});
		try {
			await dismissGettingStarted();
			if (authStore.userId !== ownerId || authGeneration !== ownerGeneration) return;
			await useFirstRunTourController().beginTour(templateId, () => authStore.userId !== ownerId || authGeneration !== ownerGeneration);
		} finally {
			dispatchFirstRunScreen({
				type: "handoffFinished",
				ownership
			});
		}
	}
	return {
		gettingStartedVisible,
		firstRunHoldsScreen,
		whenStartupDecided,
		handleStartupOutcome,
		handleUrlWorkflow,
		dismissGettingStarted,
		dismissIntoFirstRunTour
	};
});
//#endregion
export { useFirstRunTourController as n, useNewUserService as r, useFirstRunEntry as t };
