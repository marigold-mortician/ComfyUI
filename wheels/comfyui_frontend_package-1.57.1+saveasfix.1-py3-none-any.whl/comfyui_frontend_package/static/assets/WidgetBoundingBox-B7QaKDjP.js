import { t as WidgetBoundingBox_default } from "./WidgetBoundingBox-CFAssMwI.js";
export { WidgetBoundingBox_default as default };
