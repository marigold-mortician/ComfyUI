import { r as __name } from "./rolldown-runtime-xtsTai4I.js";
import { d as identity, t as iteratee } from "./iteratee-D-xtYlr8.js";
import { n as isArrayLike } from "./isObject-BDwzDI3k.js";
import { Ft as ref, P as computed, Rt as shallowRef, d as defineStore, zt as toRaw } from "./vendor-vue-core-CuN1excl.js";
import { t as useErrorHandling } from "./useErrorHandling-WrECc0C0.js";
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/groupBy.mjs
/**
* Groups the elements of an array based on a provided key-generating function.
*
* This function takes an array and a function that generates a key from each element. It returns
* an object where the keys are the generated keys and the values are arrays of elements that share
* the same key.
*
* @template T - The type of elements in the array.
* @template K - The type of keys.
* @param arr - The array to group.
* @param getKeyFromItem - A function that generates a key from an element, its index, and the array.
* @returns An object where each key is associated with an array of elements that
* share that key.
*
* @example
* const array = [
*   { category: 'fruit', name: 'apple' },
*   { category: 'fruit', name: 'banana' },
*   { category: 'vegetable', name: 'carrot' }
* ];
* const result = groupBy(array, item => item.category);
* // result will be:
* // {
* //   fruit: [
* //     { category: 'fruit', name: 'apple' },
* //     { category: 'fruit', name: 'banana' }
* //   ],
* //   vegetable: [
* //     { category: 'vegetable', name: 'carrot' }
* //   ]
* // }
*
* @example
* // Using index parameter
* const items = ['a', 'b', 'c', 'd'];
* const result = groupBy(items, (item, index) => index % 2 === 0 ? 'even' : 'odd');
* // result will be: { even: ['a', 'c'], odd: ['b', 'd'] }
*/
function groupBy$1(arr, getKeyFromItem) {
	const result = {};
	for (let i = 0; i < arr.length; i++) {
		const item = arr[i];
		const key = getKeyFromItem(item, i, arr);
		if (!Object.hasOwn(result, key)) result[key] = [];
		result[key].push(item);
	}
	return result;
}
__name(groupBy$1, "groupBy");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/groupBy.mjs
/**
* Groups the elements of an array or object based on a provided key-generating function.
*
* This function takes an array or object and a function that generates a key from each element or value.
* It returns an object where the keys are the generated keys and the values are arrays of elements that
* share the same key.
*
* @template T - The type of elements in the array or values in the object.
* @template K - The type of keys.
* @param source - The collection to group.
* @param [_getKeyFromItem] - The iteratee to transform keys.
*   - If a function is provided, it's invoked for each element in the collection.
*   - If a property name (string) is provided, that property of each element is used as the key.
*   - If a property-value pair (array) is provided, elements with matching property values are used.
*   - If a partial object is provided, elements with matching properties are used.
* @returns An object where each key is associated with an array of elements that
* share that key.
*
* @example
* // Using an array
* const array = [6.1, 4.2, 6.3];
* const result = groupBy(array, Math.floor);
* // => { 4: [4.2], 6: [6.1, 6.3] }
*
* @example
* // Using a property name
* const array = ['one', 'two', 'three'];
* const result = groupBy(array, 'length');
* // => { 3: ['one', 'two'], 5: ['three'] }
*/
function groupBy(source, _getKeyFromItem) {
	if (source == null) return {};
	return groupBy$1(isArrayLike(source) ? Array.from(source) : Object.values(source), iteratee(_getKeyFromItem ?? identity));
}
//#endregion
//#region src/lib/litegraph/src/canvas/CanvasInteractionMode.ts
var EDITABLE_INTERACTION_MODE = { isSelectOnly: () => false };
//#endregion
//#region src/platform/keybindings/reserved.ts
var RESERVED_BY_BROWSER = /* @__PURE__ */ new Set([
	"Ctrl + t",
	"Ctrl + w",
	"Ctrl + n",
	"Ctrl + Shift + n",
	"Ctrl + Tab",
	"Ctrl + Shift + Tab",
	"Ctrl + Shift + Delete",
	"Ctrl + h",
	"Ctrl + j",
	"Ctrl + d",
	"Ctrl + Shift + b",
	"Ctrl + Shift + o",
	"Ctrl + Shift + i",
	"Ctrl + Shift + j",
	"F5",
	"Ctrl + F5",
	"Ctrl + r",
	"Ctrl + Shift + r",
	"F7",
	"F11",
	"F12",
	"Alt + F4"
]);
var RESERVED_BY_TEXT_INPUT = /* @__PURE__ */ new Set([
	"Ctrl + a",
	"Ctrl + c",
	"Ctrl + v",
	"Ctrl + x",
	"Ctrl + z",
	"Ctrl + y",
	"Ctrl + p",
	"Enter",
	"Shift + Enter",
	"Ctrl + Backspace",
	"Ctrl + Delete",
	"Home",
	"Ctrl + Home",
	"Ctrl + Shift + Home",
	"End",
	"Ctrl + End",
	"Ctrl + Shift + End",
	"PageUp",
	"PageDown",
	"Shift + PageUp",
	"Shift + PageDown",
	"ArrowLeft",
	"Ctrl + ArrowLeft",
	"Shift + ArrowLeft",
	"Ctrl + Shift + ArrowLeft",
	"ArrowRight",
	"Ctrl + ArrowRight",
	"Shift + ArrowRight",
	"Ctrl + Shift + ArrowRight",
	"ArrowUp",
	"Shift + ArrowUp",
	"ArrowDown",
	"Shift + ArrowDown"
]);
//#endregion
//#region src/platform/keybindings/keyCombo.ts
var MODIFIER_KEY_LABELS = {
	Control: "Ctrl",
	Meta: "Ctrl",
	Alt: "Alt",
	Shift: "Shift"
};
var KeyComboImpl = class KeyComboImpl {
	key;
	ctrl;
	alt;
	shift;
	constructor(obj) {
		this.key = obj.key;
		this.ctrl = obj.ctrl ?? false;
		this.alt = obj.alt ?? false;
		this.shift = obj.shift ?? false;
	}
	static fromEvent(event) {
		return new KeyComboImpl({
			key: event.key,
			ctrl: event.ctrlKey || event.metaKey,
			alt: event.altKey,
			shift: event.shiftKey
		});
	}
	equals(other) {
		const raw = toRaw(other);
		return raw instanceof KeyComboImpl ? this.key.toUpperCase() === raw.key.toUpperCase() && this.ctrl === raw.ctrl && this.alt === raw.alt && this.shift === raw.shift : false;
	}
	serialize() {
		return `${this.key.toUpperCase()}:${this.ctrl}:${this.alt}:${this.shift}`;
	}
	toString() {
		return this.getKeySequences().join(" + ");
	}
	get hasModifier() {
		return this.ctrl || this.alt || this.shift;
	}
	get isModifier() {
		return this.key in MODIFIER_KEY_LABELS;
	}
	get modifierCount() {
		return [
			this.ctrl,
			this.alt,
			this.shift
		].reduce((acc, cur) => acc + Number(cur), 0);
	}
	get isShiftOnly() {
		return this.shift && this.modifierCount === 1;
	}
	get isBrowserReserved() {
		return RESERVED_BY_BROWSER.has(toNormalizedString(this));
	}
	get isReservedByTextInput() {
		return !this.hasModifier || this.isShiftOnly || RESERVED_BY_TEXT_INPUT.has(toNormalizedString(this));
	}
	getKeySequences() {
		const sequences = getModifierSequences(this);
		if (!this.isModifier || sequences.length === 0) sequences.push(getKeyLabel(this.key));
		return sequences;
	}
};
function toNormalizedString(combo) {
	const sequences = getModifierSequences(combo);
	if (!combo.isModifier || sequences.length === 0) sequences.push(getKeyLabel(combo.key, true));
	return sequences.join(" + ");
}
function getModifierSequences(combo) {
	const sequences = [];
	if (combo.ctrl) sequences.push("Ctrl");
	if (combo.alt) sequences.push("Alt");
	if (combo.shift) sequences.push("Shift");
	return sequences;
}
function getKeyLabel(key, normalizeSingleCharacter = false) {
	const label = MODIFIER_KEY_LABELS[key] ?? key;
	return normalizeSingleCharacter && label.length === 1 ? label.toLowerCase() : label;
}
//#endregion
//#region src/platform/keybindings/keybinding.ts
var KeybindingImpl = class KeybindingImpl {
	commandId;
	combo;
	targetElementId;
	constructor(obj) {
		this.commandId = obj.commandId;
		this.combo = new KeyComboImpl(obj.combo);
		this.targetElementId = obj.targetElementId;
	}
	equals(other) {
		const raw = toRaw(other);
		return raw instanceof KeybindingImpl ? this.commandId === raw.commandId && this.combo.equals(raw.combo) && this.targetElementId === raw.targetElementId : false;
	}
};
//#endregion
//#region src/platform/keybindings/keybindingStore.ts
function keybindingValues(keybindings) {
	return Object.values(keybindings).filter((keybinding) => keybinding !== void 0);
}
var useKeybindingStore = defineStore("keybinding", () => {
	const defaultKeybindings = shallowRef({});
	const userKeybindings = shallowRef({});
	const userUnsetKeybindings = shallowRef({});
	const currentPresetName = ref("default");
	const savedPresetData = ref(null);
	const serializeBinding = (b) => `${b.commandId}:${b.combo.serialize()}:${b.targetElementId ?? ""}`;
	const savedPresetSerialized = computed(() => {
		if (!savedPresetData.value) return null;
		return {
			savedNew: savedPresetData.value.newBindings.map((b) => serializeBinding(new KeybindingImpl(b))).sort().join("|"),
			savedUnset: savedPresetData.value.unsetBindings.map((b) => serializeBinding(new KeybindingImpl(b))).sort().join("|")
		};
	});
	const isCurrentPresetModified = computed(() => {
		const newBindings = keybindingValues(userKeybindings.value);
		const unsetBindings = keybindingValues(userUnsetKeybindings.value);
		if (currentPresetName.value === "default") return newBindings.length > 0 || unsetBindings.length > 0;
		if (!savedPresetSerialized.value) return false;
		const currentNew = newBindings.map(serializeBinding).sort().join("|");
		const currentUnset = unsetBindings.map(serializeBinding).sort().join("|");
		return currentNew !== savedPresetSerialized.value.savedNew || currentUnset !== savedPresetSerialized.value.savedUnset;
	});
	function getUserKeybindings() {
		return userKeybindings.value;
	}
	function getUserKeybindingValues() {
		return keybindingValues(userKeybindings.value);
	}
	function getUserUnsetKeybindings() {
		return userUnsetKeybindings.value;
	}
	function getUserUnsetKeybindingValues() {
		return keybindingValues(userUnsetKeybindings.value);
	}
	const keybindingByKeyCombo = computed(() => {
		const result = { ...defaultKeybindings.value };
		for (const keybinding of keybindingValues(userUnsetKeybindings.value)) {
			const serializedCombo = keybinding.combo.serialize();
			if (result[serializedCombo]?.equals(keybinding)) delete result[serializedCombo];
		}
		return {
			...result,
			...userKeybindings.value
		};
	});
	const keybindings = computed(() => keybindingValues(keybindingByKeyCombo.value));
	function getKeybinding(combo) {
		return keybindingByKeyCombo.value[combo.serialize()];
	}
	const keybindingsByCommandId = computed(() => {
		return groupBy(keybindings.value, "commandId");
	});
	function getKeybindingsByCommandId(commandId) {
		return keybindingsByCommandId.value[commandId] ?? [];
	}
	const defaultKeybindingsByCommandId = computed(() => groupBy(keybindingValues(defaultKeybindings.value), "commandId"));
	function getKeybindingByCommandId(commandId) {
		return getKeybindingsByCommandId(commandId).at(0);
	}
	function addKeybinding(target, keybinding, { existOk }) {
		const existing = target.value[keybinding.combo.serialize()];
		if (!existOk && existing) throw new Error(`Keybinding on ${keybinding.combo} already exists on ${existing.commandId}`);
		target.value = {
			...target.value,
			[keybinding.combo.serialize()]: keybinding
		};
	}
	function addDefaultKeybinding(keybinding) {
		addKeybinding(defaultKeybindings, keybinding, { existOk: false });
	}
	function addUserKeybinding(keybinding) {
		const serializedCombo = keybinding.combo.serialize();
		const defaultKeybinding = defaultKeybindings.value[serializedCombo];
		const userUnsetKeybinding = userUnsetKeybindings.value[serializedCombo];
		if (keybinding.equals(defaultKeybinding) && keybinding.equals(userUnsetKeybinding)) {
			const updated = { ...userUnsetKeybindings.value };
			delete updated[keybinding.combo.serialize()];
			userUnsetKeybindings.value = updated;
			return;
		}
		if (defaultKeybinding && !defaultKeybinding.equals(userUnsetKeybinding)) unsetKeybinding(defaultKeybinding);
		addKeybinding(userKeybindings, keybinding, { existOk: true });
	}
	function unsetKeybinding(keybinding) {
		const serializedCombo = keybinding.combo.serialize();
		if (!(serializedCombo in keybindingByKeyCombo.value)) {
			console.warn(`Trying to unset non-exist keybinding: ${JSON.stringify(keybinding)}`);
			return;
		}
		if (userKeybindings.value[serializedCombo]?.equals(keybinding)) {
			const updated = { ...userKeybindings.value };
			delete updated[serializedCombo];
			userKeybindings.value = updated;
			return;
		}
		if (defaultKeybindings.value[serializedCombo]?.equals(keybinding)) {
			addKeybinding(userUnsetKeybindings, keybinding, { existOk: false });
			return;
		}
		console.warn(`Unset unknown keybinding: ${JSON.stringify(keybinding)}`);
	}
	function updateKeybindingOnCommand(keybinding) {
		const currentKeybinding = getKeybindingByCommandId(keybinding.commandId);
		if (currentKeybinding?.equals(keybinding)) return false;
		if (currentKeybinding) unsetKeybinding(currentKeybinding);
		addUserKeybinding(keybinding);
		return true;
	}
	function resetAllKeybindings() {
		userKeybindings.value = {};
		userUnsetKeybindings.value = {};
	}
	function removeAllKeybindingsForCommand(commandId) {
		const currentBindings = getKeybindingsByCommandId(commandId);
		if (currentBindings.length === 0) return false;
		for (const binding of currentBindings) unsetKeybinding(binding);
		return true;
	}
	function updateSpecificKeybinding(oldBinding, newBinding) {
		unsetKeybinding(oldBinding);
		addUserKeybinding(newBinding);
	}
	function resetKeybindingForCommand(commandId) {
		const currentBindings = getKeybindingsByCommandId(commandId);
		const defaultBindings = defaultKeybindingsByCommandId.value[commandId] ?? [];
		if (defaultBindings.length === 0) {
			if (currentBindings.length > 0) {
				for (const binding of currentBindings) unsetKeybinding(binding);
				return true;
			}
			return false;
		}
		if (!isCommandKeybindingModified(commandId)) return false;
		for (const binding of currentBindings) unsetKeybinding(binding);
		const updatedUnset = { ...userUnsetKeybindings.value };
		for (const defaultBinding of defaultBindings) {
			const serializedCombo = defaultBinding.combo.serialize();
			if (updatedUnset[serializedCombo]?.equals(defaultBinding)) delete updatedUnset[serializedCombo];
		}
		userUnsetKeybindings.value = updatedUnset;
		return true;
	}
	const modifiedCommandIds = computed(() => {
		const result = /* @__PURE__ */ new Set();
		const allCommandIds = /* @__PURE__ */ new Set([...Object.keys(keybindingsByCommandId.value), ...Object.keys(defaultKeybindingsByCommandId.value)]);
		for (const commandId of allCommandIds) {
			const currentBindings = keybindingsByCommandId.value[commandId] ?? [];
			const defaultBindings = defaultKeybindingsByCommandId.value[commandId] ?? [];
			if (currentBindings.length !== defaultBindings.length) {
				result.add(commandId);
				continue;
			}
			if (currentBindings.length === 0) continue;
			const sortedCurrent = [...currentBindings].map((b) => b.combo.serialize()).sort();
			const sortedDefault = [...defaultBindings].map((b) => b.combo.serialize()).sort();
			if (sortedCurrent.some((combo, i) => combo !== sortedDefault[i])) result.add(commandId);
		}
		return result;
	});
	function isCommandKeybindingModified(commandId) {
		return modifiedCommandIds.value.has(commandId);
	}
	return {
		keybindings,
		getUserKeybindings,
		getUserKeybindingValues,
		getUserUnsetKeybindings,
		getUserUnsetKeybindingValues,
		getKeybinding,
		getKeybindingsByCommandId,
		getKeybindingByCommandId,
		addDefaultKeybinding,
		addUserKeybinding,
		unsetKeybinding,
		updateKeybindingOnCommand,
		resetAllKeybindings,
		resetKeybindingForCommand,
		isCommandKeybindingModified,
		currentPresetName,
		savedPresetData,
		isCurrentPresetModified,
		removeAllKeybindingsForCommand,
		updateSpecificKeybinding
	};
});
//#endregion
//#region src/stores/commandStore.ts
function mutatesGraph(command) {
	return typeof command.mutatesGraph === "function" ? command.mutatesGraph() : command.mutatesGraph === true;
}
var ComfyCommandImpl = class {
	id;
	function;
	_label;
	_icon;
	_tooltip;
	_menubarLabel;
	versionAdded;
	confirmation;
	source;
	active;
	category;
	mutatesGraph;
	constructor(command) {
		this.id = command.id;
		this.function = command.function;
		this._label = command.label;
		this._icon = command.icon;
		this._tooltip = command.tooltip;
		this._menubarLabel = command.menubarLabel ?? command.label;
		this.versionAdded = command.versionAdded;
		this.confirmation = command.confirmation;
		this.source = command.source;
		this.active = command.active;
		this.category = command.category;
		this.mutatesGraph = command.mutatesGraph;
	}
	get label() {
		return typeof this._label === "function" ? this._label() : this._label;
	}
	get icon() {
		return typeof this._icon === "function" ? this._icon() : this._icon;
	}
	get tooltip() {
		return typeof this._tooltip === "function" ? this._tooltip() : this._tooltip;
	}
	get menubarLabel() {
		return typeof this._menubarLabel === "function" ? this._menubarLabel() : this._menubarLabel;
	}
	get keybinding() {
		return useKeybindingStore().getKeybindingByCommandId(this.id) ?? null;
	}
};
var useCommandStore = defineStore("command", () => {
	const commandsById = ref({});
	const commands = computed(() => Object.values(commandsById.value));
	const registerCommand = (command) => {
		if (command.id in commandsById.value) console.warn(`Command ${command.id} already registered`);
		commandsById.value[command.id] = new ComfyCommandImpl(command);
	};
	const registerCommands = (commands) => {
		for (const command of commands) registerCommand(command);
	};
	const getCommand = (command) => {
		return commandsById.value[command];
	};
	let interactionMode = EDITABLE_INTERACTION_MODE;
	const setInteractionMode = (mode) => {
		interactionMode = mode;
	};
	const { wrapWithErrorHandlingAsync } = useErrorHandling();
	const execute = async (commandId, options) => {
		if (!(commandId in commandsById.value)) throw new Error(`Command ${commandId} not found`);
		const command = getCommand(commandId);
		if (interactionMode.isSelectOnly() && mutatesGraph(command)) return;
		await wrapWithErrorHandlingAsync(() => command.function(options?.metadata), options?.errorHandler)();
	};
	const isRegistered = (command) => {
		return !!commandsById.value[command];
	};
	const loadExtensionCommands = (extension) => {
		if (extension.commands) for (const command of extension.commands) registerCommand({
			...command,
			source: extension.name
		});
	};
	const formatKeySequence = (command) => {
		return (command.keybinding?.combo.getKeySequences() || []).map((seq) => seq.replace(/Control/g, "Ctrl").replace(/Shift/g, "Shift")).join(" + ");
	};
	return {
		commands,
		execute,
		getCommand,
		registerCommand,
		registerCommands,
		isRegistered,
		setInteractionMode,
		loadExtensionCommands,
		formatKeySequence
	};
});
//#endregion
export { groupBy as a, KeyComboImpl as i, useKeybindingStore as n, groupBy$1 as o, KeybindingImpl as r, useCommandStore as t };
