//#region src/locales/ko/commands.json
var Comfy_3DViewer_Open3DViewer = { "label": "선택한 노드의 3D 뷰어(베타) 열기" };
var Comfy_BrowseModelAssets = { "label": "실험적: 모델 에셋 탐색" };
var Comfy_BrowseTemplates = { "label": "템플릿 탐색" };
var Comfy_Canvas_CopySelected = { "label": "복사" };
var Comfy_Canvas_DeleteSelectedItems = { "label": "선택한 항목 삭제" };
var Comfy_Canvas_DeleteSelectedLinks = { "label": "선택한 링크 삭제" };
var Comfy_Canvas_FitView = { "label": "선택한 노드에 뷰 맞추기" };
var Comfy_Canvas_HideSelectedLinks = { "label": "선택한 링크 숨기기" };
var Comfy_Canvas_Lock = { "label": "캔버스 잠금" };
var Comfy_Canvas_MoveSelectedNodes_Down = { "label": "선택한 노드 아래로 이동" };
var Comfy_Canvas_MoveSelectedNodes_Left = { "label": "선택한 노드 왼쪽으로 이동" };
var Comfy_Canvas_MoveSelectedNodes_Right = { "label": "선택한 노드 오른쪽으로 이동" };
var Comfy_Canvas_MoveSelectedNodes_Up = { "label": "선택한 노드 위로 이동" };
var Comfy_Canvas_PasteFromClipboard = { "label": "붙여넣기" };
var Comfy_Canvas_PasteFromClipboardWithConnect = { "label": "연결하여 붙여넣기" };
var Comfy_Canvas_ResetView = { "label": "뷰 재설정" };
var Comfy_Canvas_Resize = { "label": "선택된 노드 크기 조정" };
var Comfy_Canvas_SelectAll = { "label": "모두 선택" };
var Comfy_Canvas_ShowSelectedLinks = { "label": "선택한 링크 표시" };
var Comfy_Canvas_ToggleLinkVisibility = { "label": "캔버스 링크 가시성 토글" };
var Comfy_Canvas_ToggleLock = { "label": "캔버스 잠금 토글" };
var Comfy_Canvas_ToggleMinimap = { "label": "캔버스 미니맵 전환" };
var Comfy_Canvas_ToggleSelectedNodes_Bypass = { "label": "선택한 노드 우회/우회 해제" };
var Comfy_Canvas_ToggleSelectedNodes_Collapse = { "label": "선택한 노드 축소/확장" };
var Comfy_Canvas_ToggleSelectedNodes_Mute = { "label": "선택한 노드 음소거/음소거 해제" };
var Comfy_Canvas_ToggleSelectedNodes_Pin = { "label": "선택한 노드 고정/고정 해제" };
var Comfy_Canvas_ToggleSelected_Pin = { "label": "선택한 항목 고정/고정 해제" };
var Comfy_Canvas_Unlock = { "label": "캔버스 잠금 해제" };
var Comfy_Canvas_ZoomIn = { "label": "확대" };
var Comfy_Canvas_ZoomOut = { "label": "축소" };
var Comfy_ClearPendingTasks = { "label": "보류 중인 작업 지우기" };
var Comfy_ClearWorkflow = { "label": "워크플로 내용 지우기" };
var Comfy_ContactSupport = { "label": "지원팀에 문의하기" };
var Comfy_Dev_ShowModelSelector = { "label": "모델 선택기 표시 (개발자용)" };
var Comfy_DuplicateWorkflow = { "label": "현재 워크플로 복제" };
var Comfy_ExportWorkflow = { "label": "워크플로 내보내기" };
var Comfy_ExportWorkflowAPI = { "label": "워크플로 내보내기 (API 형식)" };
var Comfy_Graph_ConvertToSubgraph = { "label": "선택 영역을 서브그래프로 변환" };
var Comfy_Graph_EditSubgraphWidgets = { "label": "서브그래프 위젯 편집" };
var Comfy_Graph_ExitSubgraph = { "label": "서브그래프 나가기" };
var Comfy_Graph_FitGroupToContents = { "label": "그룹을 내용에 맞게 맞추기" };
var Comfy_Graph_GroupSelectedNodes = { "label": "선택한 노드 그룹화" };
var Comfy_Graph_ToggleWidgetPromotion = { "label": "호버링된 위젯 프로모션 전환" };
var Comfy_Graph_UnpackSubgraph = { "label": "선택한 서브그래프 묶음 풀기" };
var Comfy_Help_AboutComfyUI = { "label": "ComfyUI 정보 열기" };
var Comfy_Help_OpenComfyOrgDiscord = { "label": "Comfy-Org 디스코드 열기" };
var Comfy_Help_OpenComfyUIDocs = { "label": "ComfyUI 문서 열기" };
var Comfy_Help_OpenComfyUIForum = { "label": "Comfy-Org 포럼 열기" };
var Comfy_Help_OpenComfyUIIssues = { "label": "ComfyUI 문제 열기" };
var Comfy_Interrupt = { "label": "중단" };
var Comfy_LayerEditor_OpenLayerEditor = { "label": "선택한 노드의 레이어 에디터 열기" };
var Comfy_LoadDefaultWorkflow = { "label": "기본 워크플로 로드" };
var Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu = { "label": "커스텀 노드 (베타)" };
var Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu = { "label": "커스텀 노드 (구버전)" };
var Comfy_Manager_ShowLegacyManagerMenu = { "label": "매니저 메뉴 (구버전)" };
var Comfy_Manager_ShowMissingPacks = { "label": "누락된 팩 설치" };
var Comfy_Manager_ShowUpdateAvailablePacks = { "label": "업데이트 확인" };
var Comfy_MaskEditor_BrushSize_Decrease = { "label": "마스크 편집기에서 브러시 크기 줄이기" };
var Comfy_MaskEditor_BrushSize_Increase = { "label": "마스크 편집기에서 브러시 크기 늘리기" };
var Comfy_MaskEditor_ColorPicker = { "label": "MaskEditor에서 색상 선택기 열기" };
var Comfy_MaskEditor_Mirror_Horizontal = { "label": "마스크 에디터에서 수평 반전" };
var Comfy_MaskEditor_Mirror_Vertical = { "label": "마스크 에디터에서 수직 반전" };
var Comfy_MaskEditor_OpenMaskEditor = { "label": "선택한 노드 마스크 편집기 열기" };
var Comfy_MaskEditor_Rotate_Left = { "label": "마스크 에디터에서 왼쪽으로 회전" };
var Comfy_MaskEditor_Rotate_Right = { "label": "마스크 에디터에서 오른쪽으로 회전" };
var Comfy_Memory_UnloadModels = { "label": "모델 언로드" };
var Comfy_Memory_UnloadModelsAndExecutionCache = { "label": "모델 및 실행 캐시 언로드" };
var Comfy_NewBlankWorkflow = { "label": "새로운 빈 워크플로" };
var Comfy_Onboarding_Replay = { "label": "온보딩 다시 보기" };
var Comfy_OpenClipspace = { "label": "클립스페이스" };
var Comfy_OpenManagerDialog = { "label": "매니저" };
var Comfy_OpenWorkflow = { "label": "워크플로 열기" };
var Comfy_PublishSubgraph = { "label": "서브그래프 게시" };
var Comfy_QueuePrompt = { "label": "실행 큐에 프롬프트 추가" };
var Comfy_QueuePromptFront = { "label": "실행 큐 맨 앞에 프롬프트 추가" };
var Comfy_QueueSelectedOutputNodes = { "label": "선택한 출력 노드 대기열에 추가" };
var Comfy_Queue_ToggleOverlay = { "label": "작업 기록 토글" };
var Comfy_Redo = { "label": "다시 실행" };
var Comfy_RefreshNodeDefinitions = { "label": "노드 정의 새로 고침" };
var Comfy_RenameWorkflow = { "label": "워크플로우 이름 변경" };
var Comfy_SaveWorkflow = { "label": "워크플로 저장" };
var Comfy_SaveWorkflowAs = { "label": "다른 이름으로 워크플로 저장" };
var Comfy_ShowSettingsDialog = { "label": "설정 대화상자 보기" };
var Comfy_Subgraph_SetDescription = { "label": "서브그래프 설명 설정" };
var Comfy_Subgraph_SetSearchAliases = { "label": "서브그래프 검색 별칭 설정" };
var Comfy_ToggleCanvasInfo = { "label": "캔버스 성능" };
var Comfy_ToggleHelpCenter = { "label": "도움말 센터" };
var Comfy_ToggleLinear = { "label": "선형 모드 토글" };
var Comfy_ToggleQPOV2 = { "label": "Queue Panel V2 토글" };
var Comfy_ToggleTheme = { "label": "밝기 테마 전환 (어두운/밝은)" };
var Comfy_Undo = { "label": "실행 취소" };
var Comfy_User_OpenSignInDialog = { "label": "로그인 대화상자 열기" };
var Comfy_User_SignOut = { "label": "로그아웃" };
var Experimental_ToggleVueNodes = { "label": "실험적: Vue 노드 활성화" };
var Workspace_CloseWorkflow = { "label": "현재 워크플로 닫기" };
var Workspace_NextOpenedWorkflow = { "label": "다음 열린 워크플로" };
var Workspace_PreviousOpenedWorkflow = { "label": "이전 열린 워크플로" };
var Workspace_SearchBox_Toggle = { "label": "검색 상자 토글" };
var Workspace_ToggleBottomPanel = { "label": "하단 패널 토글" };
var Workspace_ToggleBottomPanel_Shortcuts = { "label": "키 바인딩 대화상자 표시" };
var Workspace_ToggleFocusMode = { "label": "포커스 모드 토글" };
var Workspace_ToggleSidebarTab_apps = {
	"label": "앱 사이드바 전환",
	"tooltip": "앱"
};
var Workspace_ToggleSidebarTab_assets = {
	"label": "에셋 사이드바 전환",
	"tooltip": "에셋"
};
var Workspace_ToggleSidebarTab_workflows = {
	"label": "워크플로 사이드바 토글",
	"tooltip": "워크플로"
};
var commands_default = {
	"Comfy-Desktop_CheckForUpdates": { "label": "업데이트 확인" },
	"Comfy-Desktop_Folders_OpenCustomNodesFolder": { "label": "커스텀 노드 폴더 열기" },
	"Comfy-Desktop_Folders_OpenInputsFolder": { "label": "입력 폴더 열기" },
	"Comfy-Desktop_Folders_OpenLogsFolder": { "label": "로그 폴더 열기" },
	"Comfy-Desktop_Folders_OpenModelConfig": { "label": "extra_model_paths.yaml 열기" },
	"Comfy-Desktop_Folders_OpenModelsFolder": { "label": "모델 폴더 열기" },
	"Comfy-Desktop_Folders_OpenOutputsFolder": { "label": "출력 폴더 열기" },
	"Comfy-Desktop_OpenDevTools": { "label": "개발자 도구 열기" },
	"Comfy-Desktop_OpenUserGuide": { "label": "데스크톱 사용자 가이드" },
	"Comfy-Desktop_Quit": { "label": "종료" },
	"Comfy-Desktop_Reinstall": { "label": "재설치" },
	"Comfy-Desktop_Restart": { "label": "재시작" },
	Comfy_3DViewer_Open3DViewer,
	Comfy_BrowseModelAssets,
	Comfy_BrowseTemplates,
	Comfy_Canvas_CopySelected,
	Comfy_Canvas_DeleteSelectedItems,
	Comfy_Canvas_DeleteSelectedLinks,
	Comfy_Canvas_FitView,
	Comfy_Canvas_HideSelectedLinks,
	Comfy_Canvas_Lock,
	Comfy_Canvas_MoveSelectedNodes_Down,
	Comfy_Canvas_MoveSelectedNodes_Left,
	Comfy_Canvas_MoveSelectedNodes_Right,
	Comfy_Canvas_MoveSelectedNodes_Up,
	Comfy_Canvas_PasteFromClipboard,
	Comfy_Canvas_PasteFromClipboardWithConnect,
	Comfy_Canvas_ResetView,
	Comfy_Canvas_Resize,
	Comfy_Canvas_SelectAll,
	Comfy_Canvas_ShowSelectedLinks,
	Comfy_Canvas_ToggleLinkVisibility,
	Comfy_Canvas_ToggleLock,
	Comfy_Canvas_ToggleMinimap,
	Comfy_Canvas_ToggleSelectedNodes_Bypass,
	Comfy_Canvas_ToggleSelectedNodes_Collapse,
	Comfy_Canvas_ToggleSelectedNodes_Mute,
	Comfy_Canvas_ToggleSelectedNodes_Pin,
	Comfy_Canvas_ToggleSelected_Pin,
	Comfy_Canvas_Unlock,
	Comfy_Canvas_ZoomIn,
	Comfy_Canvas_ZoomOut,
	Comfy_ClearPendingTasks,
	Comfy_ClearWorkflow,
	Comfy_ContactSupport,
	Comfy_Dev_ShowModelSelector,
	Comfy_DuplicateWorkflow,
	Comfy_ExportWorkflow,
	Comfy_ExportWorkflowAPI,
	Comfy_Graph_ConvertToSubgraph,
	Comfy_Graph_EditSubgraphWidgets,
	Comfy_Graph_ExitSubgraph,
	Comfy_Graph_FitGroupToContents,
	Comfy_Graph_GroupSelectedNodes,
	Comfy_Graph_ToggleWidgetPromotion,
	Comfy_Graph_UnpackSubgraph,
	Comfy_Help_AboutComfyUI,
	Comfy_Help_OpenComfyOrgDiscord,
	Comfy_Help_OpenComfyUIDocs,
	Comfy_Help_OpenComfyUIForum,
	Comfy_Help_OpenComfyUIIssues,
	Comfy_Interrupt,
	Comfy_LayerEditor_OpenLayerEditor,
	Comfy_LoadDefaultWorkflow,
	Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu,
	Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu,
	Comfy_Manager_ShowLegacyManagerMenu,
	Comfy_Manager_ShowMissingPacks,
	Comfy_Manager_ShowUpdateAvailablePacks,
	Comfy_MaskEditor_BrushSize_Decrease,
	Comfy_MaskEditor_BrushSize_Increase,
	Comfy_MaskEditor_ColorPicker,
	Comfy_MaskEditor_Mirror_Horizontal,
	Comfy_MaskEditor_Mirror_Vertical,
	Comfy_MaskEditor_OpenMaskEditor,
	Comfy_MaskEditor_Rotate_Left,
	Comfy_MaskEditor_Rotate_Right,
	Comfy_Memory_UnloadModels,
	Comfy_Memory_UnloadModelsAndExecutionCache,
	Comfy_NewBlankWorkflow,
	Comfy_Onboarding_Replay,
	Comfy_OpenClipspace,
	Comfy_OpenManagerDialog,
	Comfy_OpenWorkflow,
	Comfy_PublishSubgraph,
	Comfy_QueuePrompt,
	Comfy_QueuePromptFront,
	Comfy_QueueSelectedOutputNodes,
	Comfy_Queue_ToggleOverlay,
	Comfy_Redo,
	Comfy_RefreshNodeDefinitions,
	Comfy_RenameWorkflow,
	Comfy_SaveWorkflow,
	Comfy_SaveWorkflowAs,
	Comfy_ShowSettingsDialog,
	Comfy_Subgraph_SetDescription,
	Comfy_Subgraph_SetSearchAliases,
	Comfy_ToggleCanvasInfo,
	Comfy_ToggleHelpCenter,
	Comfy_ToggleLinear,
	Comfy_ToggleQPOV2,
	Comfy_ToggleTheme,
	Comfy_Undo,
	Comfy_User_OpenSignInDialog,
	Comfy_User_SignOut,
	Experimental_ToggleVueNodes,
	Workspace_CloseWorkflow,
	Workspace_NextOpenedWorkflow,
	Workspace_PreviousOpenedWorkflow,
	Workspace_SearchBox_Toggle,
	Workspace_ToggleBottomPanel,
	"Workspace_ToggleBottomPanelTab_command-terminal": { "label": "터미널 하단 패널 전환" },
	"Workspace_ToggleBottomPanelTab_logs-terminal": { "label": "로그 하단 패널 전환" },
	"Workspace_ToggleBottomPanelTab_shortcuts-essentials": { "label": "필수 하단 패널 전환" },
	"Workspace_ToggleBottomPanelTab_shortcuts-view-controls": { "label": "뷰 컨트롤 하단 패널 전환" },
	Workspace_ToggleBottomPanel_Shortcuts,
	Workspace_ToggleFocusMode,
	Workspace_ToggleSidebarTab_apps,
	Workspace_ToggleSidebarTab_assets,
	"Workspace_ToggleSidebarTab_model-library": {
		"label": "모델 라이브러리 사이드바 토글",
		"tooltip": "모델 라이브러리"
	},
	"Workspace_ToggleSidebarTab_node-library": {
		"label": "노드 라이브러리 사이드바 토글",
		"tooltip": "노드 라이브러리"
	},
	Workspace_ToggleSidebarTab_workflows
};
//#endregion
export { Comfy_3DViewer_Open3DViewer, Comfy_BrowseModelAssets, Comfy_BrowseTemplates, Comfy_Canvas_CopySelected, Comfy_Canvas_DeleteSelectedItems, Comfy_Canvas_DeleteSelectedLinks, Comfy_Canvas_FitView, Comfy_Canvas_HideSelectedLinks, Comfy_Canvas_Lock, Comfy_Canvas_MoveSelectedNodes_Down, Comfy_Canvas_MoveSelectedNodes_Left, Comfy_Canvas_MoveSelectedNodes_Right, Comfy_Canvas_MoveSelectedNodes_Up, Comfy_Canvas_PasteFromClipboard, Comfy_Canvas_PasteFromClipboardWithConnect, Comfy_Canvas_ResetView, Comfy_Canvas_Resize, Comfy_Canvas_SelectAll, Comfy_Canvas_ShowSelectedLinks, Comfy_Canvas_ToggleLinkVisibility, Comfy_Canvas_ToggleLock, Comfy_Canvas_ToggleMinimap, Comfy_Canvas_ToggleSelectedNodes_Bypass, Comfy_Canvas_ToggleSelectedNodes_Collapse, Comfy_Canvas_ToggleSelectedNodes_Mute, Comfy_Canvas_ToggleSelectedNodes_Pin, Comfy_Canvas_ToggleSelected_Pin, Comfy_Canvas_Unlock, Comfy_Canvas_ZoomIn, Comfy_Canvas_ZoomOut, Comfy_ClearPendingTasks, Comfy_ClearWorkflow, Comfy_ContactSupport, Comfy_Dev_ShowModelSelector, Comfy_DuplicateWorkflow, Comfy_ExportWorkflow, Comfy_ExportWorkflowAPI, Comfy_Graph_ConvertToSubgraph, Comfy_Graph_EditSubgraphWidgets, Comfy_Graph_ExitSubgraph, Comfy_Graph_FitGroupToContents, Comfy_Graph_GroupSelectedNodes, Comfy_Graph_ToggleWidgetPromotion, Comfy_Graph_UnpackSubgraph, Comfy_Help_AboutComfyUI, Comfy_Help_OpenComfyOrgDiscord, Comfy_Help_OpenComfyUIDocs, Comfy_Help_OpenComfyUIForum, Comfy_Help_OpenComfyUIIssues, Comfy_Interrupt, Comfy_LayerEditor_OpenLayerEditor, Comfy_LoadDefaultWorkflow, Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu, Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu, Comfy_Manager_ShowLegacyManagerMenu, Comfy_Manager_ShowMissingPacks, Comfy_Manager_ShowUpdateAvailablePacks, Comfy_MaskEditor_BrushSize_Decrease, Comfy_MaskEditor_BrushSize_Increase, Comfy_MaskEditor_ColorPicker, Comfy_MaskEditor_Mirror_Horizontal, Comfy_MaskEditor_Mirror_Vertical, Comfy_MaskEditor_OpenMaskEditor, Comfy_MaskEditor_Rotate_Left, Comfy_MaskEditor_Rotate_Right, Comfy_Memory_UnloadModels, Comfy_Memory_UnloadModelsAndExecutionCache, Comfy_NewBlankWorkflow, Comfy_Onboarding_Replay, Comfy_OpenClipspace, Comfy_OpenManagerDialog, Comfy_OpenWorkflow, Comfy_PublishSubgraph, Comfy_QueuePrompt, Comfy_QueuePromptFront, Comfy_QueueSelectedOutputNodes, Comfy_Queue_ToggleOverlay, Comfy_Redo, Comfy_RefreshNodeDefinitions, Comfy_RenameWorkflow, Comfy_SaveWorkflow, Comfy_SaveWorkflowAs, Comfy_ShowSettingsDialog, Comfy_Subgraph_SetDescription, Comfy_Subgraph_SetSearchAliases, Comfy_ToggleCanvasInfo, Comfy_ToggleHelpCenter, Comfy_ToggleLinear, Comfy_ToggleQPOV2, Comfy_ToggleTheme, Comfy_Undo, Comfy_User_OpenSignInDialog, Comfy_User_SignOut, Experimental_ToggleVueNodes, Workspace_CloseWorkflow, Workspace_NextOpenedWorkflow, Workspace_PreviousOpenedWorkflow, Workspace_SearchBox_Toggle, Workspace_ToggleBottomPanel, Workspace_ToggleBottomPanel_Shortcuts, Workspace_ToggleFocusMode, Workspace_ToggleSidebarTab_apps, Workspace_ToggleSidebarTab_assets, Workspace_ToggleSidebarTab_workflows, commands_default as default };
