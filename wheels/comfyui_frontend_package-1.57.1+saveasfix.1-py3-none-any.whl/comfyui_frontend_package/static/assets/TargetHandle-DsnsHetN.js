import "./rolldown-runtime-xtsTai4I.js";
import { m as TransformControls, mt as Object3D } from "./vendor-three-B-UiePqj.js";
//#region packages/viewport3d/src/cameraInfo/handles/TargetHandle.ts
var TargetHandle = class {
	onDraggingChange;
	onChange;
	proxy;
	controls;
	helper;
	suppressEcho = false;
	scene = null;
	disposed = false;
	constructor(camera, domElement, onDraggingChange, onChange, name = "CameraInfoTarget") {
		this.onDraggingChange = onDraggingChange;
		this.onChange = onChange;
		this.proxy = new Object3D();
		this.proxy.name = `${name}Proxy`;
		this.controls = new TransformControls(camera, domElement);
		this.controls.setMode("translate");
		this.controls.setSize(.8);
		this.controls.attach(this.proxy);
		this.helper = this.controls.getHelper();
		this.helper.name = `${name}Handle`;
		this.helper.visible = false;
		this.controls.enabled = false;
		this.controls.addEventListener("dragging-changed", this.onDragging);
		this.controls.addEventListener("objectChange", this.onObjectChange);
	}
	attach(scene) {
		this.scene = scene;
		scene.add(this.proxy);
		scene.add(this.helper);
	}
	detach() {
		if (!this.scene) return;
		this.scene.remove(this.proxy);
		this.scene.remove(this.helper);
		this.scene = null;
	}
	setVisible(visible) {
		this.helper.visible = visible;
		this.controls.enabled = visible;
	}
	isVisible() {
		return this.helper.visible;
	}
	setTarget(target) {
		if (this.proxy.position.x === target.x && this.proxy.position.y === target.y && this.proxy.position.z === target.z) return;
		this.suppressEcho = true;
		try {
			this.proxy.position.set(target.x, target.y, target.z);
			this.proxy.updateMatrixWorld(true);
		} finally {
			this.suppressEcho = false;
		}
	}
	dispose() {
		if (this.disposed) return;
		this.disposed = true;
		this.controls.removeEventListener("dragging-changed", this.onDragging);
		this.controls.removeEventListener("objectChange", this.onObjectChange);
		this.controls.detach();
		this.detach();
		this.controls.dispose();
	}
	onDragging = (event) => {
		this.onDraggingChange(event.value === true);
	};
	onObjectChange = () => {
		if (this.suppressEcho) return;
		this.onChange({
			x: this.proxy.position.x,
			y: this.proxy.position.y,
			z: this.proxy.position.z
		});
	};
};
//#endregion
export { TargetHandle as t };
