import "./rolldown-runtime-xtsTai4I.js";
//#region packages/account-ui/src/billing/checkout/checkoutQuote.ts
function isAnnualDuration(duration) {
	return duration === "ANNUAL";
}
/**
* The preview's resolved plan duration wins; absent a preview (fresh subscribe
* with no proration) it falls back to the user's selected billing cycle.
*/
function isYearlyCheckout(planDuration, billingCycle) {
	return planDuration !== void 0 ? isAnnualDuration(planDuration) : billingCycle === "yearly";
}
var LEGACY_QUOTE_CURRENCY = "usd";
function formatQuoteMoney(cents, currency, locale) {
	if (!currency) return "";
	return new Intl.NumberFormat(locale, {
		style: "currency",
		currency: currency.toUpperCase()
	}).format(cents / 100);
}
/** Locale-grouped number, as the host's i18n `n()` prints one. */
function formatNumber(value, locale) {
	return new Intl.NumberFormat(locale).format(value);
}
/** Two-decimal display without a currency symbol; the template adds `$`. */
function formatUsdFromCents(cents, locale) {
	return new Intl.NumberFormat(locale, {
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	}).format(cents / 100);
}
function resolveQuoteMoney(exactCents, exactCurrency, legacyCents) {
	return exactCents === void 0 ? {
		cents: legacyCents,
		currency: LEGACY_QUOTE_CURRENCY
	} : {
		cents: exactCents,
		currency: exactCurrency
	};
}
function resolveAmountDueToday(preview) {
	return resolveQuoteMoney(preview.amount_due_cents, preview.currency, preview.cost_today_cents);
}
function amountDueTodayChanged(installed, refreshed) {
	const before = resolveAmountDueToday(installed);
	const after = resolveAmountDueToday(refreshed);
	return before.cents !== after.cents || before.currency !== after.currency;
}
function formatAmountDueToday(preview, locale) {
	const { cents, currency } = resolveAmountDueToday(preview);
	return formatQuoteMoney(cents, currency, locale);
}
function formatRenewalAmount(preview, locale) {
	const { cents, currency } = resolveQuoteMoney(preview.renewal_amount_cents, preview.currency, preview.cost_next_period_cents);
	return formatQuoteMoney(cents, currency, locale);
}
function resolveRenewalDate(preview) {
	return preview.renewal_at ?? preview.new_plan.period_end;
}
//#endregion
export { formatRenewalAmount as a, isYearlyCheckout as c, formatQuoteMoney as i, resolveRenewalDate as l, formatAmountDueToday as n, formatUsdFromCents as o, formatNumber as r, isAnnualDuration as s, amountDueTodayChanged as t };
