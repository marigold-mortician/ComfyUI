import "./rolldown-runtime-xtsTai4I.js";
import { n as useSettingStore } from "./settingStore-DRRi2kOn.js";
import { E as withModifiers, F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, I as createBlock, Jt as normalizeStyle, Kt as normalizeClass, L as createCommentVNode, O as Fragment, P as computed, R as createElementBlock, U as createVNode, Wt as unref, Yt as toDisplayString, bt as watch, ct as openBlock, j as Teleport, k as KeepAlive, tt as nextTick, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { t as useExtensionStore } from "./extensionStore-CYnV6tYr.js";
import { a as resultItemVhsAdvancedPreviewUrl, c as isAudioResult, d as isVideoResult, f as resultItemHtmlVideoType, l as isImageResult, r as resultItemUrl, u as isTextResult } from "./resultItemUrl-BV9Vi8QF.js";
import { t as useImageQuiet } from "./useImageQuiet-Cn5yvS20.js";
import { t as WaveAudioPlayer_default } from "./WaveAudioPlayer-Dn6-iFHj.js";
import { t as useTextFileContent } from "./useTextFileContent-CQkdXCAG.js";
//#region src/components/common/ComfyImage.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$4 = [
	"src",
	"data-test",
	"alt"
];
var _hoisted_2$3 = ["src", "alt"];
var _hoisted_3 = {
	key: 1,
	class: "m-8 flex size-full flex-col items-center justify-center"
};
//#endregion
//#region src/components/common/ComfyImage.vue
var ComfyImage_default = /* @__PURE__ */ defineComponent({
	__name: "ComfyImage",
	props: {
		src: {},
		class: {},
		contain: {
			type: Boolean,
			default: false
		},
		alt: { default: "Image content" }
	},
	setup(__props) {
		const { error } = useImageQuiet(computed(() => ({
			src: __props.src,
			alt: __props.alt
		})));
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock(Fragment, null, [!unref(error) ? (openBlock(), createElementBlock("span", {
				key: 0,
				class: normalizeClass(unref(cn)("contents", __props.contain && "relative"))
			}, [__props.contain ? (openBlock(), createElementBlock("img", {
				key: 0,
				src: __props.src,
				"data-test": __props.src,
				class: "absolute inset-0 object-cover",
				style: normalizeStyle({ "background-image": `url(${__props.src})` }),
				alt: __props.alt
			}, null, 12, _hoisted_1$4)) : createCommentVNode("", true), createBaseVNode("img", {
				src: __props.src,
				class: normalizeClass(unref(cn)("z-1 size-full object-cover object-center", __props.contain && "absolute object-contain backdrop-blur-[10px]", __props.class)),
				alt: __props.alt
			}, null, 10, _hoisted_2$3)], 2)) : createCommentVNode("", true), unref(error) ? (openBlock(), createElementBlock("div", _hoisted_3, [_cache[0] || (_cache[0] = createBaseVNode("i", { class: "pi pi-image mb-2 text-5xl" }, null, -1)), createBaseVNode("span", null, toDisplayString(_ctx.$t("g.imageFailedToLoad")), 1)])) : createCommentVNode("", true)], 64);
		};
	}
});
//#endregion
//#region src/components/sidebar/tabs/queue/ResultAudio.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$3 = { class: "m-auto w-[min(90vw,42rem)] rounded-2xl bg-background/80 p-8 backdrop-blur-sm" };
//#endregion
//#region src/components/sidebar/tabs/queue/ResultAudio.vue
var ResultAudio_default = /* @__PURE__ */ defineComponent({
	__name: "ResultAudio",
	props: { result: {} },
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$3, [createVNode(WaveAudioPlayer_default, {
				src: unref(resultItemUrl)(__props.result),
				variant: "expanded",
				height: 120,
				"bar-count": 80
			}, null, 8, ["src"])]);
		};
	}
});
//#endregion
//#region src/components/sidebar/tabs/queue/ResultText.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$2 = { class: "m-auto max-h-[80vh] w-[min(90vw,42rem)] scroll-shadows-secondary overflow-y-auto rounded-lg bg-secondary p-4 whitespace-pre-wrap" };
var _hoisted_2$2 = {
	key: 0,
	class: "text-muted-foreground"
};
//#endregion
//#region src/components/sidebar/tabs/queue/ResultText.vue
var ResultText_default = /* @__PURE__ */ defineComponent({
	__name: "ResultText",
	props: { result: {} },
	setup(__props) {
		const { textContent, hasError } = useTextFileContent(() => ({
			content: __props.result.content,
			url: resultItemUrl(__props.result)
		}));
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("article", _hoisted_1$2, [unref(hasError) ? (openBlock(), createElementBlock("span", _hoisted_2$2, toDisplayString(_ctx.$t("g.textFailedToLoad")), 1)) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [createTextVNode(toDisplayString(unref(textContent)), 1)], 64))]);
		};
	}
});
//#endregion
//#region src/components/sidebar/tabs/queue/ResultVideo.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$1 = {
	controls: "",
	class: "max-h-[90vh] max-w-[90vw]"
};
var _hoisted_2$1 = ["src", "type"];
//#endregion
//#region src/components/sidebar/tabs/queue/ResultVideo.vue
var ResultVideo_default = /* @__PURE__ */ defineComponent({
	name: "ResultVideo",
	__name: "ResultVideo",
	props: { result: {} },
	setup(__props) {
		const props = __props;
		const settingStore = useSettingStore();
		const { isExtensionInstalled, isExtensionEnabled } = useExtensionStore();
		const vhsAdvancedPreviews = computed(() => {
			return isExtensionInstalled("VideoHelperSuite.Core") && isExtensionEnabled("VideoHelperSuite.Core") && settingStore.get("VHS.AdvancedPreviews") && settingStore.get("VHS.AdvancedPreviews") !== "Never";
		});
		const url = computed(() => vhsAdvancedPreviews.value ? resultItemVhsAdvancedPreviewUrl(props.result) : resultItemUrl(props.result));
		const htmlVideoType = computed(() => vhsAdvancedPreviews.value ? "video/webm" : resultItemHtmlVideoType(props.result));
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("video", _hoisted_1$1, [createBaseVNode("source", {
				src: url.value,
				type: htmlVideoType.value
			}, null, 8, _hoisted_2$1), createTextVNode(" " + toDisplayString(_ctx.$t("g.videoFailedToLoad")), 1)]);
		};
	}
});
//#endregion
//#region src/components/sidebar/tabs/queue/MediaLightbox.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = ["aria-label"];
var _hoisted_2 = { class: "flex max-h-full max-w-full items-center justify-center" };
var RETAINED_VIDEO_COUNT = 3;
//#endregion
//#region src/components/sidebar/tabs/queue/MediaLightbox.vue
var MediaLightbox_default = /* @__PURE__ */ defineComponent({
	__name: "MediaLightbox",
	props: {
		allGalleryItems: {},
		activeIndex: {}
	},
	emits: ["update:activeIndex"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const props = __props;
		const galleryVisible = ref(false);
		const dialogRef = ref();
		let previouslyFocusedElement = null;
		const hasMultiple = computed(() => props.allGalleryItems.length > 1);
		const activeItem = computed(() => props.allGalleryItems[props.activeIndex]);
		watch(() => props.activeIndex, (index) => {
			galleryVisible.value = index !== -1;
			if (index !== -1) {
				previouslyFocusedElement = document.activeElement;
				nextTick(() => dialogRef.value?.focus());
			}
		}, { immediate: true });
		function close() {
			galleryVisible.value = false;
			emit("update:activeIndex", -1);
			previouslyFocusedElement?.focus();
			previouslyFocusedElement = null;
		}
		function navigateImage(direction) {
			const newIndex = (props.activeIndex + direction + props.allGalleryItems.length) % props.allGalleryItems.length;
			emit("update:activeIndex", newIndex);
		}
		let maskMouseDownTarget = null;
		function onMaskMouseDown(event) {
			maskMouseDownTarget = event.target;
		}
		function onMaskMouseUp(event) {
			if (maskMouseDownTarget === event.target && event.target?.hasAttribute("data-mask")) close();
		}
		function handleKeyDown(event) {
			const action = {
				ArrowLeft: () => navigateImage(-1),
				ArrowRight: () => navigateImage(1),
				Escape: () => close()
			}[event.key];
			if (action) {
				event.preventDefault();
				action();
			}
		}
		return (_ctx, _cache) => {
			return galleryVisible.value ? (openBlock(), createBlock(Teleport, {
				key: 0,
				to: "body"
			}, [createBaseVNode("div", {
				ref_key: "dialogRef",
				ref: dialogRef,
				role: "dialog",
				"aria-modal": "true",
				"aria-label": _ctx.$t("g.gallery"),
				tabindex: "-1",
				class: "fixed inset-0 z-overlay flex items-center justify-center bg-black/90 outline-none",
				"data-mask": "",
				onMousedown: onMaskMouseDown,
				onMouseup: onMaskMouseUp,
				onKeydown: withModifiers(handleKeyDown, ["stop"])
			}, [
				createVNode(Button_default, {
					variant: "secondary",
					size: "icon-lg",
					class: "absolute top-4 right-4 z-10 rounded-full",
					"aria-label": _ctx.$t("g.close"),
					onClick: close
				}, {
					default: withCtx(() => [..._cache[2] || (_cache[2] = [createBaseVNode("i", { class: "icon-[lucide--x] size-5" }, null, -1)])]),
					_: 1
				}, 8, ["aria-label"]),
				hasMultiple.value ? (openBlock(), createBlock(Button_default, {
					key: 0,
					variant: "secondary",
					size: "icon-lg",
					class: "fixed top-1/2 left-4 z-10 -translate-y-1/2 rounded-full",
					"aria-label": _ctx.$t("g.previous"),
					onClick: _cache[0] || (_cache[0] = ($event) => navigateImage(-1))
				}, {
					default: withCtx(() => [..._cache[3] || (_cache[3] = [createBaseVNode("i", { class: "icon-[lucide--chevron-left] size-6" }, null, -1)])]),
					_: 1
				}, 8, ["aria-label"])) : createCommentVNode("", true),
				createBaseVNode("div", _hoisted_2, [activeItem.value ? (openBlock(), createBlock(KeepAlive, {
					key: 0,
					max: RETAINED_VIDEO_COUNT,
					include: "ResultVideo"
				}, [unref(isImageResult)(activeItem.value) ? (openBlock(), createBlock(ComfyImage_default, {
					key: unref(resultItemUrl)(activeItem.value),
					src: unref(resultItemUrl)(activeItem.value),
					contain: false,
					alt: activeItem.value.filename,
					class: "size-auto max-h-[90vh] max-w-[90vw] object-contain"
				}, null, 8, ["src", "alt"])) : unref(isVideoResult)(activeItem.value) ? (openBlock(), createBlock(ResultVideo_default, {
					key: unref(resultItemUrl)(activeItem.value),
					result: activeItem.value
				}, null, 8, ["result"])) : unref(isAudioResult)(activeItem.value) ? (openBlock(), createBlock(ResultAudio_default, {
					key: 2,
					result: activeItem.value
				}, null, 8, ["result"])) : unref(isTextResult)(activeItem.value) ? (openBlock(), createBlock(ResultText_default, {
					key: 3,
					result: activeItem.value
				}, null, 8, ["result"])) : createCommentVNode("", true)], 1024)) : createCommentVNode("", true)]),
				hasMultiple.value ? (openBlock(), createBlock(Button_default, {
					key: 1,
					variant: "secondary",
					size: "icon-lg",
					class: "fixed top-1/2 right-4 z-10 -translate-y-1/2 rounded-full",
					"aria-label": _ctx.$t("g.next"),
					onClick: _cache[1] || (_cache[1] = ($event) => navigateImage(1))
				}, {
					default: withCtx(() => [..._cache[4] || (_cache[4] = [createBaseVNode("i", { class: "icon-[lucide--chevron-right] size-6" }, null, -1)])]),
					_: 1
				}, 8, ["aria-label"])) : createCommentVNode("", true)
			], 40, _hoisted_1)])) : createCommentVNode("", true);
		};
	}
});
//#endregion
export { MediaLightbox_default as t };
