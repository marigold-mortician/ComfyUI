import "./rolldown-runtime-xtsTai4I.js";
import { t as useNodeOutputStore } from "./nodeOutputStore-Dec5oA1b.js";
import { t as useTeamWorkspaceStore } from "./teamWorkspaceStore-BNm5cZOK.js";
import { i as api } from "./api-BdJmXw98.js";
import { C as vModelText, F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, Kt as normalizeClass, L as createCommentVNode, O as Fragment, P as computed, R as createElementBlock, Rt as shallowRef, S as vModelSelect, Tt as withDirectives, Wt as unref, Yt as toDisplayString, at as onMounted, bt as watch, ct as openBlock, rt as onBeforeUnmount, tt as nextTick, ut as renderList, yt as useTemplateRef } from "./vendor-vue-core-CuN1excl.js";
import { Yn as useClipboard, ar as useEventListener } from "./vendor-reka-ui-NRTk7aIV.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { n as useWorkflowStore } from "./workflowStore-ChkUx7Si.js";
import { t as DISTRIBUTION } from "./types-t0xJOOCt.js";
import { l as resolveDeployEnv, r as reportError } from "./reportError-BHgDVvfb.js";
import { t as collectAllNodes } from "./graphTraversalUtil-BUK1cr2m.js";
import { l as encodeStateAsUpdate, n as Doc, s as applyUpdate } from "./vendor-yjs-DzSvc5Ii.js";
import { t as useExtensionStore } from "./extensionStore-CYnV6tYr.js";
import { n as useExecutionStore } from "./executionStore-DrU24oQb.js";
import { t as useCurrentUser } from "./useCurrentUser-DjJaVYwd.js";
import { Bt as isDOMWidget, n as app } from "./app-C-5f0uvA.js";
import { s as useQueueStore } from "./assetsStore-CzSfkgjN.js";
import { T as setCrdtLogLevel, b as crdtLogLevel, f as DEV_EVENT_KINDS, h as devEvents, m as devEventReplacer, p as clearDevEvents, v as stringifyDevEvents, y as CRDT_LOG_LEVELS } from "./skillReferenceText-CIcnFnck.js";
import { _ as stampKey, a as hasAppliedOp, b as useAgentConversationStore, d as mint, l as readStamps, o as hasNode, r as mintWireOps, s as readGraph, u as applyOps, v as stampTargetKey, y as writeTarget } from "./opEnvelope-eXHTW5mx.js";
//#region src/workbench/extensions/agent/crdt/crdtDebugReport.ts
/**
* The one-click bug report.
*
* The frontend used to ship a `ReportIssuePanel` that gathered system stats,
* server logs, settings and the workflow behind opt-in checkboxes and posted
* the bundle to Sentry; it was deleted when support moved to Zendesk (#5259),
* and with it went the only path from "something is wrong" to "here is
* everything an engineer needs". The panel's `Copy JSON` replacement carried
* the CRDT event log and nothing else — no versions, no logs, no custom
* nodes — so every CRDT report arrived needing a follow-up round trip.
*
* This restores the deleted collector and folds the CRDT state into the same
* artifact: one clipboard paste that answers "what build", "what machine",
* "what nodes", "what did the document do", and "what did the tester expect
* instead".
*
* Collection is per-source fault-tolerant on purpose. A backend that is down
* is exactly when a report matters most, and a failed `getLogs()` must
* degrade to a note in the log section rather than abort the whole bundle.
*/
/** Server logs beyond this are tail-trimmed; a paste has to stay pasteable. */
var MAX_LOG_CHARS = 4e4;
var MAX_WORKFLOW_CHARS = 2e5;
/** The event log and the stamp ledger both grow without bound with session length. */
var MAX_SECTION_CHARS = 6e4;
var MAX_REPORT_CHARS = 256e3;
var MAX_TOOL_CALLS = 50;
var MAX_REDACTION_DEPTH = 12;
var DEPTH_LIMIT_REDACTED = "[redacted at depth limit]";
var SOURCE_TIMEOUT_MS = 5e3;
/**
* Setting keys whose VALUE is replaced before the report leaves the browser.
*
* `addSetting` is public extension API, so the settings dictionary is an open
* set: any installed node pack can persist whatever it likes there, including
* service credentials. An allow-list is impossible for the same reason, so
* this redacts by key shape and the report says so out loud.
*/
var SECRET_KEY_PATTERN = /(token|secret|password|passwd|credential|api[-_]?key|apikey|auth|bearer|session|cookie|private)/i;
var REDACTED = "[redacted by the debug report]";
var SHARING_WARNING = "Review before sharing: this section can contain values you did not choose to publish.";
/**
* Redaction must RECURSE. A single top-level pass reads as sufficient and is
* not: `Comfy.Server.LaunchArgs` is a `Record<string, string>` of the flags
* the server was started with, and its own key matches nothing, so a
* one-level walk emits `{'--api-token': '…'}` whole. Settings values are
* arbitrary JSON from a public `addSetting` API, so every key at every depth
* has to be tested.
*/
function redactSecrets(value, depth = 0) {
	if (depth > MAX_REDACTION_DEPTH) return DEPTH_LIMIT_REDACTED;
	if (typeof value === "string") return redactPrivateValue(value);
	if (value === null || typeof value !== "object") return value;
	if (Array.isArray(value)) return value.map((item) => redactSecrets(item, depth + 1));
	return Object.fromEntries(Object.entries(value).map(([key, nested]) => [key, SECRET_KEY_PATTERN.test(key) ? REDACTED : redactSecrets(nested, depth + 1)]));
}
var DEFAULT_REPORT_SOURCES = {
	serverLogs: true,
	settings: true,
	workflow: true
};
/** Every field unknown — the fallback when a caller has none to report. */
var EMPTY_REPORT_IDENTIFIERS = {
	userId: null,
	organizationId: null,
	workspaceId: null,
	agentThreadId: null,
	activeAgentTurnId: null,
	recentAgentTurnIds: [],
	tabId: null,
	activeJobId: null,
	recentJobIds: [],
	workflowPath: null,
	workflowId: null,
	graphId: null,
	docId: null,
	crdtSequence: null,
	crdtLamport: null,
	clientId: null,
	deployEnv: null,
	backendUrl: "unknown"
};
async function attempt(label, load) {
	let timeout;
	try {
		return {
			label,
			ok: true,
			value: await Promise.race([load(), new Promise((_, reject) => {
				timeout = setTimeout(() => reject(/* @__PURE__ */ new Error(`${label} timed out`)), SOURCE_TIMEOUT_MS);
			})])
		};
	} catch (error) {
		reportError(error, {
			surface: "agent",
			errorType: "agent_crdt_debug_report_source_failed",
			tags: { source: label },
			level: "warning"
		});
		return {
			label,
			ok: false,
			error: String(error)
		};
	} finally {
		clearTimeout(timeout);
	}
}
function fence(language, body) {
	const longestRun = [...body.matchAll(/`+/g)].reduce((max, match) => Math.max(max, match[0].length), 0);
	const delimiter = "`".repeat(Math.max(3, longestRun + 1));
	return [
		delimiter + language,
		body,
		delimiter
	].join("\n");
}
function json(value) {
	try {
		return JSON.stringify(value, devEventReplacer(), 2);
	} catch (error) {
		return `<unserializable: ${String(error)}>`;
	}
}
function fitMediaDiagnostics(diagnostics) {
	const retained = [];
	let serializedLength = 4;
	for (const diagnostic of diagnostics) {
		const diagnosticJson = json(diagnostic);
		const indentedLength = diagnosticJson.length + diagnosticJson.split("\n").length * 2;
		const separatorLength = retained.length > 0 ? 2 : 0;
		if (serializedLength + separatorLength + indentedLength > MAX_SECTION_CHARS) break;
		retained.push(diagnostic);
		serializedLength += separatorLength + indentedLength;
	}
	return retained;
}
function redactEventPayloads(value) {
	if (Array.isArray(value)) return value.map(redactEventPayloads);
	if (!isRecord(value)) return value;
	return Object.fromEntries(Object.entries(value).map(([key, nested]) => [key, key === "value" || key === "widgets_values" || key === "node" ? REDACTED : redactEventPayloads(nested)]));
}
function truncate(text, max) {
	if (text.length <= max) return text;
	const start = text.length - max;
	const safeStart = text.charCodeAt(start) >= 56320 && text.charCodeAt(start) <= 57343 ? start + 1 : start;
	return `…(${safeStart} earlier characters trimmed)…\n${text.slice(safeStart)}`;
}
function truncateReport(text) {
	if (text.length <= MAX_REPORT_CHARS) return text;
	const marker = `\n\n[report truncated to ${MAX_REPORT_CHARS} characters]\n\n`;
	const available = MAX_REPORT_CHARS - marker.length;
	const headLength = Math.floor(available * .75);
	const tailStart = text.length - (available - headLength);
	const safeHeadLength = text.charCodeAt(headLength - 1) >= 55296 && text.charCodeAt(headLength - 1) <= 56319 ? headLength - 1 : headLength;
	const safeTailStart = text.charCodeAt(tailStart) >= 56320 && text.charCodeAt(tailStart) <= 57343 ? tailStart + 1 : tailStart;
	return `${text.slice(0, safeHeadLength)}${marker}${text.slice(safeTailStart)}`;
}
/**
* A value is anything not starting with `-`; only a leading dash makes a token
* a flag. Pattern-testing every token instead treated `/home/me/private/x` as
* a flag — leaking it and blanking the harmless argument after it.
*
* Two rules: a credential-shaped FLAG blanks its value, and a value that looks
* like an absolute path or a URL is blanked whatever names it, because
* `--output-directory` and `--extra-model-paths-config` carry private paths
* under a flag no credential pattern matches.
*/
var PRIVATE_VALUE_PATTERN = /(^|=)(\/|~|[A-Za-z]:[\\/]|\\\\|\.{1,2}[\\/])|:\/\//;
var BEARER_VALUE_PATTERN = /^(\s*bearer\s+)\S+\s*$/i;
var SECRET_VALUE_PATTERN = /((?:["']?)(?:token|secret|password|passwd|credential|api[-_]?key|apikey|authorization|auth|bearer|session|cookie|private)(?:["']?)\s*[:=]\s*)(?:bearer\s+)?(?:(['"])(?:\\[\s\S]|(?!\2)[\s\S])*\2|[^\s,;]+)/gi;
function redactPrivateValue(value) {
	if (PRIVATE_VALUE_PATTERN.test(value)) return REDACTED;
	return value.replace(BEARER_VALUE_PATTERN, `$1${REDACTED}`).replace(SECRET_VALUE_PATTERN, (_match, prefix, quote) => `${prefix}${quote ?? ""}${REDACTED}${quote ?? ""}`);
}
function redactArgv(argv) {
	const parts = [];
	let flagWantsSecretValue = false;
	for (const arg of argv) {
		if (flagWantsSecretValue) {
			parts.push(REDACTED);
			flagWantsSecretValue = false;
			continue;
		}
		flagWantsSecretValue = false;
		if (!arg.startsWith("-")) {
			parts.push(redactPrivateValue(arg));
			continue;
		}
		const eq = arg.indexOf("=");
		const flag = eq === -1 ? arg : arg.slice(0, eq);
		const inlineValue = eq === -1 ? void 0 : arg.slice(eq + 1);
		if (inlineValue !== void 0) {
			const secret = SECRET_KEY_PATTERN.test(flag) || PRIVATE_VALUE_PATTERN.test(inlineValue);
			parts.push(secret ? `${flag}=${REDACTED}` : arg);
			flagWantsSecretValue = false;
			continue;
		}
		parts.push(arg);
		flagWantsSecretValue = SECRET_KEY_PATTERN.test(flag);
	}
	return parts.join(" ");
}
function isRecord(value) {
	return typeof value === "object" && value !== null;
}
function systemSection(stats) {
	const payload = isRecord(stats) ? stats : {};
	const system = isRecord(payload.system) ? payload.system : {};
	const argv = Array.isArray(system.argv) ? system.argv.map(String) : [];
	const devices = Array.isArray(payload.devices) ? payload.devices : [];
	const lines = [
		`- **ComfyUI version:** ${system.comfyui_version ?? "?"}`,
		`- **OS:** ${system.os ?? "?"}`,
		`- **Python:** ${system.python_version ?? "?"}`,
		`- **Embedded Python:** ${system.embedded_python ?? "?"}`,
		`- **PyTorch:** ${system.pytorch_version ?? "?"}`,
		`- **Arguments:** ${redactArgv(argv)}`,
		`- **RAM:** ${system.ram_free ?? "?"} free / ${system.ram_total ?? "?"} total`
	];
	if (system.cloud_version) lines.push(`- **Cloud version:** ${system.cloud_version}`);
	if (system.comfyui_frontend_version) lines.push(`- **Frontend (reported by backend):** ${system.comfyui_frontend_version}`);
	for (const device of devices) {
		if (!isRecord(device)) {
			lines.push("- **Device ?:** unavailable");
			continue;
		}
		lines.push(`- **Device ${device.index ?? "?"}:** ${device.name} (${device.type}) — VRAM ${device.vram_free} free / ${device.vram_total} total, torch ${device.torch_vram_free} / ${device.torch_vram_total}`);
	}
	return lines.join("\n");
}
/**
* Every value here is a search key, not a secret — a backend engineer greps
* Datadog by exactly these fields, so `none`/`unknown` is written out loud
* rather than omitting the row: a missing bullet reads as "not collected",
* an explicit `none` reads as "collected, and there isn't one".
*/
function identifiersSection(identifiers) {
	return [
		`- **User id:** ${identifiers.userId ?? "none (not logged in)"}`,
		`- **Organization id:** ${identifiers.organizationId ?? "none (not exposed separately)"}`,
		`- **Workspace id:** ${identifiers.workspaceId ?? "none"}`,
		`- **Agent session/thread id:** ${identifiers.agentThreadId ?? "none"}`,
		`- **Active agent request/turn id:** ${identifiers.activeAgentTurnId ?? "none"}`,
		`- **Recent agent request/turn ids:** ${identifiers.recentAgentTurnIds.length ? identifiers.recentAgentTurnIds.join(", ") : "none"}`,
		`- **Client id:** ${identifiers.clientId ?? "unknown"}`,
		`- **Tab/session id:** ${identifiers.tabId ?? "unknown"}`,
		`- **Active job/prompt id:** ${identifiers.activeJobId ?? "none"}`,
		`- **Recent job/prompt ids:** ${identifiers.recentJobIds.length ? identifiers.recentJobIds.join(", ") : "none"}`,
		`- **Workflow path:** ${identifiers.workflowPath ?? "none"}`,
		`- **Workflow id:** ${identifiers.workflowId ?? "none"}`,
		`- **Document/graph id:** ${identifiers.graphId ?? "none"}`,
		`- **CRDT doc id:** ${identifiers.docId ?? "none"}`,
		`- **CRDT room id:** ${identifiers.docId ?? "none"}`,
		`- **CRDT sequence/clock:** ${identifiers.crdtSequence ?? "none"}`,
		`- **CRDT Lamport counter:** ${identifiers.crdtLamport ?? "none"}`,
		`- **Backend URL:** ${identifiers.backendUrl}`,
		`- **Deploy env:** ${identifiers.deployEnv ?? "unknown"}`,
		`- **Frontend commit:** 1a2e6b01c114f0cd905ad8372286653ebff58e92`,
		`- **Frontend version:** 1.59.1`,
		`- **Distribution:** ${DISTRIBUTION}`,
		`- **Timestamp (UTC):** ${(/* @__PURE__ */ new Date()).toISOString()}`,
		`- **User agent:** ${navigator.userAgent}`
	].join("\n");
}
function crdtSection(crdt) {
	return [
		`- **Schema version:** ${crdt.meta.schema_version ?? "unknown"}`,
		`- **Enabled:** ${crdt.status.enabled}`,
		`- **Connected:** ${crdt.status.connected}`,
		`- **Canvas may be stale:** ${crdt.status.canvasMayBeStale}`,
		`- **Doc id:** ${crdt.status.workflowId ?? "none"}`,
		`- **Updates applied:** ${crdt.status.updatesApplied}`,
		`- **Last frame:** ${crdt.status.lastFrameType ?? "none"}`,
		`- **Tab id:** ${crdt.tabId ?? "unknown"}`,
		`- **Last seq:** ${crdt.lastSeq ?? "none"}`,
		`- **Schema error:** ${crdt.schemaError ?? "none"}`,
		`- **Doc nodes (${crdt.nodeIds.length}):** ${crdt.nodeIds.join(", ") || "none"}`,
		`- **Doc links (${crdt.linkIds.length}):** ${crdt.linkIds.join(", ") || "none"}`,
		`- **Applied op ids:** ${crdt.appliedOpIds.length}`
	].join("\n");
}
function mergeSection(entries) {
	return entries.map((entry) => `${entry.index + 1}. \`${entry.kind}\` by ${entry.actor} on ${entry.registerLabel} → **${entry.verdict.kind}**\n   ${entry.explanation}`).join("\n");
}
function serializeWorkflow(input) {
	if (!(input.sources ?? DEFAULT_REPORT_SOURCES).workflow) return { status: "turned off" };
	if (input.workflowError !== void 0) return {
		status: "failed (see source section)",
		section: fence("text", truncate(String(redactSecrets(input.workflowError)), MAX_SECTION_CHARS))
	};
	if (input.workflow === void 0) return { status: "unavailable" };
	let serialized;
	try {
		serialized = JSON.stringify(input.workflow, devEventReplacer(), 2);
	} catch (error) {
		return {
			status: "failed (see source section)",
			section: fence("text", truncate(String(redactSecrets(String(error))), MAX_SECTION_CHARS))
		};
	}
	if (serialized.length > MAX_WORKFLOW_CHARS) return {
		status: `omitted (over ${MAX_WORKFLOW_CHARS} characters)`,
		section: fence("json", `<workflow omitted: ${serialized.length} characters — attach the .json file instead>`)
	};
	return {
		status: "collected",
		section: fence("json", serialized)
	};
}
function fitToolCalls(calls, context) {
	let start = 0;
	let body = json(redactSecrets(calls));
	let section = [context, fence("json", body)].join("\n\n");
	while (section.length > MAX_SECTION_CHARS) {
		start++;
		body = json(redactSecrets(calls.slice(start)));
		section = [context, fence("json", body)].join("\n\n");
	}
	return {
		section,
		retained: calls.length - start
	};
}
function collectAgentToolCalls(messages) {
	const calls = [];
	let total = 0;
	for (const message of [...messages].reverse()) for (const part of [...message.parts].reverse()) {
		if (part.type !== "tool") continue;
		total++;
		if (calls.length === MAX_TOOL_CALLS) continue;
		calls.push({
			turnId: message.id,
			callId: part.callId,
			name: part.name,
			state: part.state,
			ok: part.ok,
			durationMs: part.durationMs
		});
	}
	return {
		calls: calls.reverse(),
		total
	};
}
function agentToolSection(messages) {
	const context = "Current conversation metadata retained in this tab only. Restored history may omit tool calls. Durations are backend-reported; missing ok or durationMs means no outcome or timing was observed. State is the retained UI state, not proof a request is still running. No arguments, responses, prompts or reasoning are included.";
	if (messages === void 0) return {
		section: context,
		status: "unavailable"
	};
	const { calls, total } = collectAgentToolCalls(messages);
	const fitted = fitToolCalls(calls, context);
	return {
		section: fitted.section,
		status: total === 0 ? "no retained calls" : `${total > fitted.retained ? "truncated" : "collected"} (${fitted.retained}/${total} retained calls)`
	};
}
function formatSource(result, warning, renderValue) {
	if (result === null) return {
		section: "_Not included. Turned off by the tester._",
		status: "turned off"
	};
	if (!result.ok) return {
		section: [warning, `_${result.label} unavailable: ${result.error}_`].join("\n\n"),
		status: "failed (see source section)"
	};
	return {
		section: [warning, renderValue(result.value)].join("\n\n"),
		status: "collected"
	};
}
/**
* Build the full markdown report.
*
* Ordered for the reader, not for the collector: the tester's own words come
* first, then CRDT state, then the environment, then the raw transcripts. An
* engineer reading it top-down should be able to stop as soon as they have
* enough.
*/
async function collectCrdtDebugReport(input) {
	const extensionNames = (() => {
		try {
			return useExtensionStore().extensions.map((extension) => extension.name);
		} catch (error) {
			return [`<unavailable: ${String(error)}>`];
		}
	})();
	const sources = input.sources ?? DEFAULT_REPORT_SOURCES;
	const agentTools = agentToolSection(input.agentMessages);
	const [stats, logs, settings] = await Promise.all([
		attempt("System stats", () => api.getSystemStats()),
		sources.serverLogs ? attempt("Server logs", () => api.getLogs()) : null,
		sources.settings ? attempt("Settings", () => api.getSettings()) : null
	]);
	const systemReport = formatSource(stats, `${SHARING_WARNING} System details can identify your hardware, software versions and launch configuration.`, systemSection);
	const logsReport = formatSource(logs, `${SHARING_WARNING} Backend logs can echo prompts, file paths and tokens.`, (value) => fence("text", truncate(value, MAX_LOG_CHARS)));
	const settingsReport = formatSource(settings, `${SHARING_WARNING} Values under keys that look like credentials are replaced with \`${REDACTED}\`, at every depth — but a custom node may name a secret anything.`, (value) => fence("json", truncate(json(redactSecrets(value)), MAX_SECTION_CHARS)));
	const workflow = serializeWorkflow(input);
	const mediaUiDiagnostics = input.mediaUiDiagnostics === void 0 ? void 0 : fitMediaDiagnostics(input.mediaUiDiagnostics);
	const mediaUiStatus = mediaUiDiagnostics === void 0 ? "unavailable" : mediaUiDiagnostics.length === input.mediaUiDiagnostics?.length ? `collected (${mediaUiDiagnostics.length} nodes)` : `collected (${mediaUiDiagnostics.length} of ${input.mediaUiDiagnostics?.length} nodes; section limit)`;
	const collectionStatus = [
		["System stats", systemReport],
		["Server logs", logsReport],
		["Settings", settingsReport],
		["Agent tool calls", agentTools]
	].map(([label, result]) => `- ${label}: ${result.status}`);
	const sections = [
		"# ComfyUI Agent — CRDT debug report",
		`Generated ${(/* @__PURE__ */ new Date()).toISOString()}`,
		`Report format version: 2 · Document schema version: ${input.crdt.meta.schema_version ?? "unknown"} · Redaction marker: ${REDACTED}`,
		"## Identifiers",
		"Paste this block into a bug report or search Datadog/logs by any of these fields.",
		identifiersSection(input.identifiers ?? EMPTY_REPORT_IDENTIFIERS),
		"## Collection status",
		[
			...collectionStatus,
			`- Media UI diagnostics: ${mediaUiStatus}`,
			`- Workflow: ${workflow?.status ?? "unavailable"}`
		].join("\n")
	];
	if (input.testerNote?.trim()) sections.push("## What the tester expected", input.testerNote.trim(), "_(This is the tester’s own description of the expected merge behaviour — treat it as a product signal, not a bug repro.)_");
	sections.push("## CRDT state", crdtSection(input.crdt));
	if (mediaUiDiagnostics !== void 0) sections.push("## Media UI diagnostics", "Counts and booleans only; selected filenames and resolved media URLs are not included.", fence("json", json(mediaUiDiagnostics)));
	sections.push("## Agent tool calls", agentTools.section);
	if (input.mergeTrace?.length) sections.push("## Merge trace", mergeSection(input.mergeTrace));
	sections.push("## Frontend", [
		`- **Frontend version:** 1.59.1`,
		`- **Frontend commit:** 1a2e6b01c114f0cd905ad8372286653ebff58e92`,
		`- **Distribution:** ${DISTRIBUTION}`,
		`- **API base:** ${api.apiURL("")}`,
		`- **User agent:** ${navigator.userAgent}`,
		`- **Viewport:** ${window.innerWidth}×${window.innerHeight}`,
		`- **Extensions (${extensionNames.length}):** ${extensionNames.join(", ") || "none"}`
	].join("\n"));
	sections.push("## System", systemReport.section);
	sections.push("## CRDT event log", `${SHARING_WARNING} Operation payload values appear as \`${REDACTED}\`; op ids and workflow ids appear verbatim.`, fence("json", truncate(json(redactEventPayloads(input.events)), MAX_SECTION_CHARS)));
	sections.push("## Document stamps (LWW ledger)", `${SHARING_WARNING} Stamp keys name every actor that wrote to the document.`, fence("json", truncate(json(input.crdt.stamps), MAX_SECTION_CHARS)));
	if (workflow?.section !== void 0) sections.push("## Workflow", `${SHARING_WARNING} Prompts and API keys embedded in nodes appear verbatim.`, workflow.section);
	sections.push("## Settings", settingsReport.section);
	sections.push("## Server logs", logsReport.section);
	return truncateReport(sections.join("\n\n"));
}
//#endregion
//#region src/workbench/extensions/agent/crdt/mergeTrace.ts
/**
* The shared vocabulary for talking about CRDT merges and sequencing.
*
* A tester who sees a surprising outcome needs three answers, in this order:
* WHICH CELL was contested, WHICH ORDER the contenders sorted in, and WHY the
* loser lost. The pinned applier already names all three — `writeTarget` is
* the cell, `stampKey` is the order, `ApplyOutcome` is the verdict — so this
* module deliberately re-exports that language rather than inventing a
* parallel one. Anything the panel renders is a rewording of a fact the
* document itself would report.
*
* Nothing here reads or writes a shared document: these are pure functions
* over ops and over a read-only snapshot the caller supplies.
*/
/**
* The glossary the panel renders next to the trace, so a bug report and the
* code use the same words for the same thing.
*/
var MERGE_VOCABULARY = [
	{
		term: "register",
		meaning: "The single cell two edits can contest — e.g. one widget on one node, or one input slot. Edits to different registers never conflict."
	},
	{
		term: "stamp",
		meaning: "The total order edits are compared in: [base_version, actor, op_id]. Higher wins; the op_id breaks exact ties so every replica picks the same winner offline."
	},
	{
		term: "applied",
		meaning: "The edit took effect and now owns its register."
	},
	{
		term: "lww-dropped",
		meaning: "The edit reached the document but an edit with a higher stamp already owned the register, so it was discarded. Last-writer-wins."
	},
	{
		term: "no-op (delete-wins)",
		meaning: "The edit targeted a node that was already deleted. Deletion is not a register contest: once a node is gone, writes to it vanish silently until something re-adds it."
	},
	{
		term: "no-op (duplicate)",
		meaning: "The document had already applied this op_id. Retries are idempotent by design, so a resend changes nothing."
	},
	{
		term: "rejected",
		meaning: "The document refused the edit (unknown op kind, deferred kind, bad payload). The rest of the batch is abandoned; the prefix before it is kept."
	},
	{
		term: "not-reached",
		meaning: "An earlier op in the same batch was rejected, so this one was never attempted (abort-remainder)."
	}
];
/** The node an op addresses, or `null` for ops that address the whole graph. */
function opNodeId(op) {
	if (op.op === "clear" || op.op === "reset_doc") return null;
	const raw = op.node_id;
	if (raw !== void 0) return String(raw);
	const target = op.to_node;
	return target === void 0 ? null : String(target);
}
/**
* A human label for the contested cell.
*
* `writeTarget` returns the applier's own tuple (e.g. `['widget', '7',
* 'seed']`); rendering it verbatim is honest but unreadable, so each shape
* gets a sentence and anything unrecognised falls back to the raw tuple
* rather than being hidden.
*/
function registerLabel(target) {
	const [kind, ...rest] = target.map((part) => String(part));
	switch (kind) {
		case "widget": return `widget "${rest[1]}" on node ${rest[0]}`;
		case "input": return `input slot ${rest[1]} on node ${rest[0]}`;
		case "node": return `node ${rest[0]}`;
		case "clear": return "the whole graph";
		default: return target.map((part) => String(part)).join(" · ");
	}
}
function formatStampKey(key) {
	const [baseVersion, actor, opId] = key;
	return `v${baseVersion} · ${actor} · ${opId.slice(0, 8)}`;
}
function explainVerdict(op, label, verdict) {
	switch (verdict.kind) {
		case "applied": return `Applied. \`${op.op}\` now owns ${label}.`;
		case "no-op":
			if (verdict.because === "delete-wins") return `No effect: node ${opNodeId(op) ?? "?"} had already been deleted, so this write had nowhere to land. Deletion is not a stamp contest — it wins over every write that arrives after it, whatever the stamps say. A later add_node re-creates the node as a fresh incarnation and does NOT resurrect this value.`;
			if (verdict.because === "duplicate-op-id") return `No effect: op_id ${op.op_id.slice(0, 8)} had already been applied. Resends are idempotent, which is why the sender never re-mints an op_id.`;
			return "No effect. The document had nothing to change for this op.";
		case "lww-dropped": return verdict.incumbent ? `Dropped: ${label} was already owned by a higher stamp (${formatStampKey(verdict.incumbent)}) than this op's (${formatStampKey(stampKey(op))}). Last-writer-wins picked the incumbent.` : `Dropped: a higher stamp already owned ${label}. Last-writer-wins picked the incumbent.`;
		case "rejected": return `Rejected (${verdict.code}): ${verdict.message}. Everything after it in the same batch was abandoned; everything before it was kept.`;
		case "not-reached": return "Never attempted: an earlier op in the same batch was rejected, and a batch abandons everything after the failure. The ops before it are kept, so resending the batch without the bad op converges.";
	}
}
function traceEntry(op, index, verdict) {
	const target = writeTarget(op);
	const widgetWrite = op;
	const label = registerLabel(widgetWrite.op === "set_widget" && widgetWrite.node_id !== void 0 && typeof widgetWrite.widget === "string" ? [
		"widget",
		widgetWrite.node_id,
		widgetWrite.widget
	] : target);
	return {
		index,
		opId: op.op_id,
		kind: op.op,
		actor: op.actor,
		register: stampTargetKey(op),
		registerLabel: label,
		stamp: stampKey(op),
		nodeId: opNodeId(op),
		verdict,
		explanation: explainVerdict(op, label, verdict)
	};
}
/**
* Group a trace by the register each op contested — the view that answers
* "why did these two edits fight?" at a glance.
*/
function groupByRegister(entries) {
	const groups = /* @__PURE__ */ new Map();
	for (const entry of entries) {
		const group = groups.get(entry.register) ?? {
			label: entry.registerLabel,
			entries: []
		};
		group.entries.push(entry);
		groups.set(entry.register, group);
	}
	return [...groups].map(([register, group]) => ({
		register,
		...group
	})).sort((a, b) => b.entries.length - a.entries.length);
}
function nodeLifecycle(entries) {
	const incarnations = /* @__PURE__ */ new Map();
	const rows = [];
	for (const entry of entries) {
		if (entry.nodeId === null) continue;
		const current = incarnations.get(entry.nodeId) ?? 1;
		if (entry.kind === "add_node" && entry.verdict.kind === "applied") {
			const next = incarnations.has(entry.nodeId) ? current + 1 : 1;
			incarnations.set(entry.nodeId, next);
			rows.push({
				nodeId: entry.nodeId,
				incarnation: next,
				entry
			});
			continue;
		}
		if (entry.verdict.kind === "applied") incarnations.set(entry.nodeId, current);
		rows.push({
			nodeId: entry.nodeId,
			incarnation: current,
			entry
		});
	}
	return rows;
}
//#endregion
//#region src/workbench/extensions/agent/crdt/mergeScenarios.ts
/**
* A merge laboratory: run an ordered op stream through the REAL applier and
* report, per op, what the document decided and why.
*
* The point is that this is not a model of the merge rules — it IS the merge
* rules. `applyOps` here is byte-for-byte the function the cloud doc host
* runs, so a verdict shown in the panel is the verdict production would
* produce for that arrival order. A simulator that merely *described* the
* semantics would drift from them the first time the pin moved, and a tester
* shown a drifted explanation is worse off than one shown nothing.
*
* Everything is local and synchronous: no socket, no backend, no shared doc.
*/
function stampKeyOf(value) {
	if (!Array.isArray(value) || value.length < 3) return null;
	const [baseVersion, actor, opId] = value;
	if (typeof baseVersion !== "number" || typeof actor !== "string" || typeof opId !== "string") return null;
	return [
		baseVersion,
		actor,
		opId
	];
}
/**
* Turn the applier's outcome into a verdict that says WHY.
*
* `applyOps` reports a bare `no-op` both for a resend it has already seen and
* for a write to a node someone deleted. The two are distinguishable only
* from the document as it stood BEFORE the op, which is why this is probed
* per op rather than reconstructed afterwards.
*/
function verdictFor(outcome, wasDuplicate, nodePresentAfter, incumbentStamp) {
	switch (outcome.outcome) {
		case "applied": return { kind: "applied" };
		case "lww-dropped": return {
			kind: "lww-dropped",
			incumbent: incumbentStamp
		};
		case "rejected": return outcome.reason.code === "batch_aborted" ? {
			kind: "not-reached",
			code: outcome.reason.code
		} : {
			kind: "rejected",
			code: outcome.reason.code,
			message: outcome.reason.message
		};
		case "no-op":
			if (wasDuplicate) return {
				kind: "no-op",
				because: "duplicate-op-id"
			};
			if (nodePresentAfter === false) return {
				kind: "no-op",
				because: "delete-wins"
			};
			return {
				kind: "no-op",
				because: "unknown"
			};
	}
}
/**
* `mint` clones the workflow with `structuredClone`, which throws on a
* Proxy — and a caller holding the scenario in Vue reactive state hands one
* over without ever knowing. Round-tripping through JSON is the cheapest way
* to guarantee the plain data the applier's contract assumes.
*/
function asPlainJson(workflow) {
	return JSON.parse(JSON.stringify(workflow));
}
/**
* Replay `batches` against a fresh document minted from `workflow`.
*
* Duplicate detection, node presence and register ownership are sampled at
* each op's position. The real batch still determines the final outcome; a
* prefix replay on a clone captures the stamp visible when that op settled.
*/
function simulateOpStream(workflow, catalog, batches) {
	const doc = mint(asPlainJson(workflow), catalog);
	const entries = [];
	let index = 0;
	for (const batch of batches) {
		const nodeIds = batch.map(opNodeId);
		const spentOpIds = new Set(batch.filter((op) => hasAppliedOp(doc, op.op_id)).map((op) => op.op_id));
		const present = /* @__PURE__ */ new Map();
		for (const id of nodeIds) if (id !== null && !present.has(id)) present.set(id, hasNode(doc, id));
		const beforeBatch = encodeStateAsUpdate(doc);
		const result = applyOps(doc, batch, catalog);
		const stampsByPosition = batch.map((_, position) => {
			const prefixDoc = new Doc();
			applyUpdate(prefixDoc, beforeBatch);
			applyOps(prefixDoc, batch.slice(0, position + 1), catalog);
			return readStamps(prefixDoc);
		});
		batch.forEach((op, position) => {
			const outcome = result.outcomes.at(position);
			const nodeId = nodeIds[position];
			const verdict = outcome ? verdictFor(outcome, spentOpIds.has(op.op_id), nodeId === null ? null : present.get(nodeId) ?? false, stampKeyOf(stampsByPosition[position][stampTargetKey(op)])) : {
				kind: "no-op",
				because: "unknown"
			};
			spentOpIds.add(op.op_id);
			if (nodeId !== null && outcome?.outcome === "applied") {
				if (op.op === "add_node") present.set(nodeId, true);
				else if (op.op === "delete_node") present.set(nodeId, false);
			}
			entries.push(traceEntry(op, index, verdict));
			index++;
		});
	}
	const graph = readGraph(doc);
	const survivingWidgets = {};
	for (const [id, node] of Object.entries(graph.nodes)) {
		const widgets = node.widgets;
		if (typeof widgets !== "object" || widgets === null) continue;
		for (const [name, value] of Object.entries(widgets)) survivingWidgets[`${id}.${name}`] = value;
	}
	return {
		entries,
		survivingNodeIds: Object.keys(graph.nodes),
		survivingWidgets
	};
}
function runScenario(scenario) {
	return simulateOpStream(scenario.workflow, scenario.catalog, scenario.batches);
}
/** Each op arrives in its own batch — the ordinary frame-by-frame case. */
function separately(...ops) {
	return ops.map((op) => [op]);
}
var CATALOG = { types: {
	CLIPTextEncode: { widget_order: ["text"] },
	KSampler: { widget_order: ["seed", "steps"] }
} };
var SEED_WORKFLOW = {
	nodes: [{
		id: "A",
		type: "CLIPTextEncode",
		pos: [0, 0],
		widgets_values: ["a cat"],
		inputs: [],
		outputs: []
	}, {
		id: "B",
		type: "KSampler",
		pos: [200, 0],
		widgets_values: [1, 20],
		inputs: [],
		outputs: []
	}],
	links: []
};
/**
* Mint one scenario op through the SAME envelope code the real write leg
* uses, so a scenario cannot accidentally demonstrate stamp semantics the
* production sender would never produce.
*/
function op(body, actor, baseVersion) {
	const [minted] = mintWireOps([body], {
		actor,
		baseVersion
	});
	return minted;
}
var ALICE = "human:alice:tab1";
var BOB = "human:bob:tab2";
function addNodeA(actor, baseVersion) {
	return op({
		op: "add_node",
		node_id: "A",
		class_type: "CLIPTextEncode",
		pos: [0, 0],
		node: {
			id: "A",
			type: "CLIPTextEncode",
			pos: [0, 0],
			widgets_values: ["a dog"]
		}
	}, actor, baseVersion);
}
/**
* The scenarios a tester runs to build intuition. Each is a question, not a
* demo: the title says what is contested and the `question` says what the
* outcome is supposed to teach.
*/
var mergeScenarios;
function getMergeScenarios() {
	return mergeScenarios ??= [
		{
			id: "delete-then-write-then-add",
			title: "delete A → set widget on A → add A",
			question: "Does an edit made while a node is deleted survive if the node comes back?",
			workflow: SEED_WORKFLOW,
			catalog: CATALOG,
			batches: separately(op({
				op: "delete_node",
				node_id: "A",
				removed_links: []
			}, ALICE, 1), op({
				op: "set_widget",
				node_id: "A",
				widget: "text",
				value: "a bird"
			}, BOB, 1), addNodeA(BOB, 2))
		},
		{
			id: "write-then-delete-then-write",
			title: "set widget → delete A → set widget again",
			question: "Where exactly does the delete cut the timeline for a node’s values?",
			workflow: SEED_WORKFLOW,
			catalog: CATALOG,
			batches: separately(op({
				op: "set_widget",
				node_id: "A",
				widget: "text",
				value: "first"
			}, ALICE, 1), op({
				op: "delete_node",
				node_id: "A",
				removed_links: []
			}, BOB, 2), op({
				op: "set_widget",
				node_id: "A",
				widget: "text",
				value: "second"
			}, ALICE, 3))
		},
		{
			id: "concurrent-widget-writes",
			title: "two people set the same widget concurrently",
			question: "Both were minted against the same document version, and the one that arrives SECOND loses. What decided it?",
			workflow: SEED_WORKFLOW,
			catalog: CATALOG,
			batches: separately(op({
				op: "set_widget",
				node_id: "B",
				widget: "seed",
				value: 222
			}, BOB, 4), op({
				op: "set_widget",
				node_id: "B",
				widget: "seed",
				value: 111
			}, ALICE, 4))
		},
		{
			id: "stale-write-loses",
			title: "a stale write arrives after a newer one",
			question: "Does arrival order or stamp order decide a widget register contest?",
			workflow: SEED_WORKFLOW,
			catalog: CATALOG,
			batches: separately(op({
				op: "set_widget",
				node_id: "B",
				widget: "steps",
				value: 50
			}, ALICE, 9), op({
				op: "set_widget",
				node_id: "B",
				widget: "steps",
				value: 4
			}, BOB, 2))
		},
		{
			id: "idempotent-resend",
			title: "the same op is sent twice",
			question: "Is a retry safe, and how is it distinguishable from a conflict?",
			workflow: SEED_WORKFLOW,
			catalog: CATALOG,
			batches: (() => {
				const once = op({
					op: "set_widget",
					node_id: "B",
					widget: "seed",
					value: 7
				}, ALICE, 1);
				return separately(once, once);
			})()
		},
		{
			id: "batch-abort",
			title: "a rejected op in the middle of ONE batch",
			question: "All three ship together. What happens to the ops queued behind the rejection?",
			workflow: SEED_WORKFLOW,
			catalog: CATALOG,
			batches: [[
				op({
					op: "set_widget",
					node_id: "B",
					widget: "seed",
					value: 99
				}, ALICE, 1),
				op({
					op: "set_widget",
					node_id: "B",
					widget: "not_a_widget",
					value: 1
				}, ALICE, 2),
				op({
					op: "set_widget",
					node_id: "B",
					widget: "steps",
					value: 3
				}, ALICE, 3)
			]]
		}
	];
}
//#endregion
//#region src/workbench/extensions/agent/crdt/mediaUiDiagnostics.ts
function selectedMediaPresent(node, widgetName) {
	const value = node.widgets?.find((widget) => widget.name === widgetName)?.value;
	return value !== void 0 && value !== null && value !== "" && value !== "none";
}
function nodeRootsById(root) {
	const roots = /* @__PURE__ */ new Map();
	for (const element of root.querySelectorAll("[data-node-id]")) {
		const nodeId = element.dataset.nodeId;
		if (nodeId === void 0) continue;
		const matchingRoots = roots.get(nodeId);
		if (matchingRoots) matchingRoots.push(element);
		else roots.set(nodeId, [element]);
	}
	return roots;
}
function mediaKinds(evidence) {
	const kinds = [];
	const hasImage = [
		evidence.previewMediaType === "image",
		evidence.selectedImagePresent,
		evidence.outputImageCount > 0,
		evidence.imageUrlCount > 0,
		evidence.legacyImageCount > 0,
		evidence.vueImageCount > 0
	].some(Boolean);
	const hasAudio = [
		evidence.previewMediaType === "audio",
		evidence.selectedAudioPresent,
		evidence.outputAudioCount > 0,
		evidence.audioUiRegistered,
		evidence.vueAudioCount > 0
	].some(Boolean);
	if (hasImage) kinds.push("image");
	if (hasAudio) kinds.push("audio");
	return kinds;
}
function descendantCount(roots, selector) {
	return roots.reduce((count, element) => count + element.querySelectorAll(selector).length, 0);
}
function outputCounts(output) {
	return {
		image: output?.images?.length ?? 0,
		audio: output?.audio?.length ?? 0
	};
}
function audioUiWidget(node) {
	return node.widgets?.find((widget) => widget.name === "audioUI");
}
function audioElementFor(widget) {
	if (!widget) return null;
	return isDOMWidget(widget) ? widget.element : null;
}
function audioElementState(element) {
	if (!element) return {
		connected: false,
		sourcePresent: false,
		hiddenAsEmpty: false
	};
	return {
		connected: element.isConnected,
		sourcePresent: Boolean(element.currentSrc || element.getAttribute("src")),
		hiddenAsEmpty: element.classList.contains("empty-audio-widget")
	};
}
function diagnosticForNode(node, source) {
	const output = source.getNodeOutputs(node);
	const imageUrls = source.getNodeImageUrls(node) ?? [];
	const legacyImages = node.imgs ?? [];
	const audioUi = audioUiWidget(node);
	const audioState = audioElementState(audioElementFor(audioUi));
	const counts = outputCounts(output);
	const selectedImagePresent = selectedMediaPresent(node, "image");
	const selectedAudioPresent = selectedMediaPresent(node, "audio");
	const roots = source.nodeRootsById.get(String(node.id)) ?? [];
	const vueImageCount = descendantCount(roots, "img");
	const vueAudioCount = descendantCount(roots, "audio");
	const kinds = mediaKinds({
		previewMediaType: node.previewMediaType,
		imageUrlCount: imageUrls.length,
		legacyImageCount: legacyImages.length,
		outputImageCount: counts.image,
		outputAudioCount: counts.audio,
		selectedImagePresent,
		selectedAudioPresent,
		audioUiRegistered: audioUi !== void 0,
		vueImageCount,
		vueAudioCount
	});
	if (!kinds.length) return null;
	return {
		nodeId: String(node.id),
		nodeType: node.comfyClass ?? node.type,
		mediaKinds: kinds,
		selectedImagePresent,
		selectedAudioPresent,
		outputImageCount: counts.image,
		outputAudioCount: counts.audio,
		resolvedImageUrlCount: imageUrls.length,
		legacyImageCount: legacyImages.length,
		loadedLegacyImageCount: legacyImages.filter((image) => image.complete && image.naturalWidth > 0).length,
		vueNodeCount: roots.length,
		vueImageCount,
		vueAudioCount,
		audioUiRegistered: audioUi !== void 0,
		audioElementConnected: audioState.connected,
		audioSourcePresent: audioState.sourcePresent,
		audioHiddenAsEmpty: audioState.hiddenAsEmpty,
		hideOutputImages: node.hideOutputImages ?? false
	};
}
function isDiagnostic(diagnostic) {
	return diagnostic !== null;
}
function collectMediaUiDiagnostics({ nodes, getNodeOutputs, getNodeImageUrls, root }) {
	const source = {
		getNodeOutputs,
		getNodeImageUrls,
		nodeRootsById: nodeRootsById(root)
	};
	return nodes.map((node) => diagnosticForNode(node, source)).filter(isDiagnostic);
}
//#endregion
//#region src/workbench/extensions/agent/crdt/CrdtDevPanel.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "relative flex max-h-1/2 min-h-0 flex-col font-mono text-xs" };
var _hoisted_2 = ["title"];
var _hoisted_3 = ["title"];
var _hoisted_4 = {
	key: 2,
	class: "flex min-h-0 grow flex-col overflow-hidden border-y bg-background text-foreground",
	"data-testid": "crdt-dev-panel"
};
var _hoisted_5 = { class: "flex h-8 shrink-0 items-center gap-2 border-b px-2" };
var _hoisted_6 = { class: "font-bold" };
var _hoisted_7 = { class: "ml-auto flex items-center gap-1 text-muted-foreground" };
var _hoisted_8 = ["value"];
var _hoisted_9 = ["title"];
var _hoisted_10 = ["title"];
var _hoisted_11 = { class: "flex shrink-0 border-b" };
var _hoisted_12 = ["data-testid", "onClick"];
var _hoisted_13 = { class: "min-h-0 flex-1 space-y-3 overflow-y-auto p-2" };
var _hoisted_14 = { class: "mb-1 font-bold text-muted-foreground" };
var _hoisted_15 = { class: "w-full" };
var _hoisted_16 = { class: "pr-2 align-top text-muted-foreground" };
var _hoisted_17 = { class: "break-all" };
var _hoisted_18 = ["aria-label"];
var _hoisted_19 = { class: "mb-1 font-bold text-muted-foreground" };
var _hoisted_20 = { class: "w-full" };
var _hoisted_21 = { class: "pr-2 align-top text-muted-foreground" };
var _hoisted_22 = { class: "break-all" };
var _hoisted_23 = { class: "text-muted-foreground" };
var _hoisted_24 = { class: "mb-1 font-bold" };
var _hoisted_25 = { class: "break-all" };
var _hoisted_26 = { class: "flex flex-wrap items-center gap-1" };
var _hoisted_27 = { value: "" };
var _hoisted_28 = ["value"];
var _hoisted_29 = { value: "" };
var _hoisted_30 = ["value"];
var _hoisted_31 = { value: "" };
var _hoisted_32 = ["value"];
var _hoisted_33 = { class: "ml-auto text-muted-foreground" };
var _hoisted_34 = {
	class: "space-y-1",
	"data-testid": "crdt-dev-panel-log"
};
var _hoisted_35 = ["onClick"];
var _hoisted_36 = { class: "flex items-baseline gap-1" };
var _hoisted_37 = { class: "text-muted-foreground" };
var _hoisted_38 = { class: "font-bold" };
var _hoisted_39 = { class: "break-all text-muted-foreground" };
var _hoisted_40 = {
	key: 0,
	class: "mt-1 flex flex-wrap gap-1"
};
var _hoisted_41 = ["aria-label", "onClick"];
var _hoisted_42 = ["aria-label", "onClick"];
var _hoisted_43 = {
	key: 1,
	class: "px-1.5 py-0.5 text-muted-foreground"
};
var _hoisted_44 = {
	class: "rounded-sm border bg-secondary px-2 py-1 font-bold text-muted-foreground",
	"data-testid": "crdt-dev-panel-simulation-label"
};
var _hoisted_45 = ["value", "selected"];
var _hoisted_46 = { class: "text-muted-foreground" };
var _hoisted_47 = {
	class: "list-none space-y-2 pl-0",
	"data-testid": "crdt-dev-panel-trace"
};
var _hoisted_48 = { class: "flex flex-wrap items-baseline gap-1" };
var _hoisted_49 = { class: "text-muted-foreground" };
var _hoisted_50 = { class: "font-bold" };
var _hoisted_51 = { class: "text-muted-foreground" };
var _hoisted_52 = { class: "text-muted-foreground" };
var _hoisted_53 = { class: "mt-0.5 mb-0" };
var _hoisted_54 = { class: "mb-1 font-bold text-muted-foreground" };
var _hoisted_55 = { class: "break-all text-muted-foreground" };
var _hoisted_56 = { key: 0 };
var _hoisted_57 = { class: "mb-1 font-bold text-muted-foreground" };
var _hoisted_58 = { class: "font-bold" };
var _hoisted_59 = {
	key: 1,
	class: "text-muted-foreground"
};
var _hoisted_60 = { class: "mb-1 font-bold" };
var _hoisted_61 = { class: "mb-1 font-bold text-muted-foreground" };
var _hoisted_62 = { class: "space-y-1" };
var _hoisted_63 = { class: "font-bold" };
var _hoisted_64 = { class: "ml-0 text-muted-foreground" };
var _hoisted_65 = {
	for: "crdt-tester-note",
	class: "mb-1 block font-bold text-muted-foreground"
};
var _hoisted_66 = ["placeholder"];
var _hoisted_67 = { class: "shrink-0 border-t p-2" };
var _hoisted_68 = { class: "mb-1 text-muted-foreground" };
var _hoisted_69 = { class: "mb-1 flex flex-wrap gap-1" };
var _hoisted_70 = [
	"aria-checked",
	"data-testid",
	"onClick"
];
var _hoisted_71 = { class: "mt-0 mb-2 text-muted-foreground" };
var _hoisted_72 = { class: "flex gap-1" };
var _hoisted_73 = ["disabled"];
var _hoisted_74 = {
	key: 0,
	class: "mt-2"
};
var _hoisted_75 = {
	role: "alert",
	class: "m-0 text-destructive"
};
var _hoisted_76 = ["aria-label", "value"];
/**
* The CRDT debug instrument.
*
* Rendered into `AgentPanel`'s `#instrument` slot, as a real child of its flex
* column directly above the composer — NOT as an overlay. The predecessor was
* `fixed right-3 bottom-3` and sat on the composer's submit button, and its
* status strip was a block element that pushed the composer below the fold.
*
* Being a flex sibling is what makes that unrepeatable: the composer is
* `shrink-0`, so it claims its intrinsic height before this element is
* offered any, and the conversation area above absorbs the difference. An
* overlay bounded by a percentage of the panel cannot make that promise —
* the composer's height is fixed in pixels, so any percentage reservation
* fails below some viewport, silently, on exactly the laptops testers use.
*
* The OUTER wrapper carries `max-h-1/2` + `min-h-0` and must not be
* `shrink-0`. Both halves are load-bearing and were each wrong once: a
* percentage max-height resolves against the parent, so putting it on the
* inner sheet measured it against this auto-height wrapper and capped
* nothing; and a flex item defaults to `min-height: auto`, so without
* `min-h-0` the wrapper refuses to shrink below its content and pushes the
* composer out of the clipped column — the original bug, reintroduced.
*/
var OPEN_KEY = "Comfy.Agent.CrdtDevPanel.open";
var HIDDEN_KEY = "Comfy.Agent.CrdtDevPanel.hidden";
var MAX_RETAINED_DETAIL_CODE_POINTS = 2e4;
var MAX_NODE_ID_BUTTONS = 50;
var NOTE_KEY = "Comfy.Agent.CrdtDevPanel.note";
//#endregion
//#region src/workbench/extensions/agent/crdt/CrdtDevPanel.vue
var CrdtDevPanel_default = /* @__PURE__ */ defineComponent({
	__name: "CrdtDevPanel",
	props: {
		status: {},
		snapshot: { type: Function }
	},
	setup(__props) {
		const { t } = useI18n();
		const S = {
			title: "CRDT debug",
			close: "Close",
			hide: "Hide until re-enabled",
			open: "Open CRDT debug panel",
			restore: "Show CRDT debug",
			tabStatus: "Status",
			tabLog: "Log",
			tabMerge: "Merge lab",
			simulated: "Simulated — not this session",
			none: "—",
			yes: "yes",
			no: "no",
			allScopes: "all layers",
			allLevels: "all levels",
			allKinds: "all kinds",
			clear: "Clear",
			copy: "Copy",
			copyDocumentId: "Copy document id",
			copyLogDetail: "Copy log detail",
			moreNodeIds: (count) => `+${count} more`,
			unserializableDetail: "[unserializable detail]",
			copyLog: "Copy log",
			copyReport: "Copy full report",
			copying: "Collecting…",
			copied: "Copied",
			copyFailed: "Copy failed",
			events: "events",
			sectionDoc: "Document",
			sectionFollower: "Follower",
			sectionProxy: "Backend",
			sectionVocab: "What the words mean",
			sectionOutcome: "Result after the whole sequence",
			sectionByRegister: "Grouped by contested register",
			sectionLifecycle: "Node lifecycle",
			run: "Run sequence",
			question: "Question",
			notePrompt: "Does this feel wrong? Describe the rule you would rather have. It is included verbatim in the copied report.",
			notePlaceholder: "e.g. \"re-adding a node should restore the widget edit made while it was deleted\"",
			survivingNodes: "nodes left",
			survivingWidgets: "widget values left",
			verbosity: "console",
			includeLogs: "Server logs",
			includeSettings: "Settings",
			includeWorkflow: "Workflow JSON",
			includeHint: "These can carry prompts, file paths and API keys. Read the report before pasting it anywhere."
		};
		const REPORT_SOURCE_LABELS = [
			{
				key: "serverLogs",
				label: S.includeLogs
			},
			{
				key: "settings",
				label: S.includeSettings
			},
			{
				key: "workflow",
				label: S.includeWorkflow
			}
		];
		const STATUS_ROWS = [
			["doc id", () => __props.status.workflowId ?? S.none],
			["connected", () => __props.status.connected ? S.yes : S.no],
			["updates applied", () => String(__props.status.updatesApplied)],
			["outcomes (recv/applied/skip/err/gap/reset/drop)", () => {
				const o = __props.status.outcomes;
				return [
					o.received,
					o.applied,
					o.skipped,
					o.errored,
					o.gap,
					o.reset,
					o.dropped
				].join("/");
			}],
			["last frame", () => __props.status.lastFrameType ?? S.none]
		];
		const SCOPES = ["wire", "doc"];
		const VERDICT_TONE = {
			applied: "text-success border-success",
			"lww-dropped": "text-muted-foreground border-border",
			"no-op": "text-muted-foreground border-border",
			rejected: "text-destructive border-destructive",
			"not-reached": "text-muted-foreground border-border"
		};
		const open = ref(readOpen());
		const tab = ref("status");
		const dismissed = ref(readHidden());
		const chipButton = useTemplateRef("chipButton");
		const closeButton = useTemplateRef("closeButton");
		function readOpen() {
			try {
				return localStorage.getItem(OPEN_KEY) === "true";
			} catch {
				return false;
			}
		}
		function readHidden() {
			try {
				return localStorage.getItem(HIDDEN_KEY) === "true";
			} catch {
				return false;
			}
		}
		function setHidden(hidden) {
			try {
				localStorage.setItem(HIDDEN_KEY, String(hidden));
			} catch {
				return;
			}
		}
		function setOpen(value) {
			open.value = value;
			if (value) nextTick(poll);
			try {
				localStorage.setItem(OPEN_KEY, String(value));
			} catch {}
		}
		function onDocumentKeydown(event) {
			if (!open.value || event.key !== "Escape") return;
			event.stopPropagation();
			if (event.target instanceof HTMLSelectElement) return;
			setOpen(false);
		}
		useEventListener(document, "keydown", onDocumentKeydown);
		const docState = shallowRef(null);
		let pollHandle;
		let logCopyReset;
		let reportCopyReset;
		let itemCopyReset;
		function poll() {
			if (!open.value || tab.value !== "status") return;
			docState.value = __props.snapshot?.() ?? null;
		}
		onMounted(() => {
			poll();
			pollHandle = setInterval(poll, 1e3);
		});
		onBeforeUnmount(() => {
			itemCopyRequest++;
			if (pollHandle !== void 0) clearInterval(pollHandle);
			clearTimeout(logCopyReset);
			clearTimeout(reportCopyReset);
			clearTimeout(itemCopyReset);
		});
		watch(open, (value) => {
			(value ? closeButton.value : chipButton.value)?.focus();
		}, { flush: "post" });
		watch(closeButton, (button) => {
			if (open.value) button?.focus();
		}, { flush: "post" });
		watch(tab, poll);
		const docRows = computed(() => {
			const state = docState.value;
			if (!state) return [["document", S.none]];
			return [
				["schema error", state.schemaError ?? S.none],
				["schema version", String(state.meta.schema_version ?? S.none)],
				["last seq", state.lastSeq === null ? S.none : String(state.lastSeq)],
				["tab id", state.tabId ?? S.none],
				["nodes", `${state.nodeIds.length}: ${state.nodeIds.join(", ") || S.none}`],
				["links", String(state.linkIds.length)],
				["applied op ids", String(state.appliedOpIds.length)],
				["stamped registers", String(Object.keys(state.stamps).length)]
			];
		});
		const scopeFilter = ref("");
		const levelFilter = ref("");
		const kindFilter = ref("");
		const expanded = ref(null);
		const matchingEvents = computed(() => devEvents.value.filter((event) => (!scopeFilter.value || event.scope === scopeFilter.value) && (!levelFilter.value || event.level === levelFilter.value) && (!kindFilter.value || event.kind === kindFilter.value)));
		const visibleLogRows = computed(() => [...matchingEvents.value].reverse().slice(0, 150).map((event) => {
			const detail = truncateDetail(stringifyDetail(event.detail), MAX_RETAINED_DETAIL_CODE_POINTS);
			const allNodeIds = eventNodeIds(event);
			return {
				event,
				detail,
				excerpt: truncateDetail(detail),
				nodeIds: allNodeIds.slice(0, MAX_NODE_ID_BUTTONS),
				hiddenNodeIdCount: Math.max(0, allNodeIds.length - MAX_NODE_ID_BUTTONS)
			};
		}));
		const level = ref(crdtLogLevel());
		function onLevelChange(next) {
			level.value = next;
			setCrdtLogLevel(next);
		}
		const mergeScenarios = getMergeScenarios();
		const scenario = shallowRef(mergeScenarios[0]);
		const simulation = shallowRef(null);
		function readNote() {
			try {
				return localStorage.getItem(NOTE_KEY) ?? "";
			} catch {
				return "";
			}
		}
		const testerNote = ref(readNote());
		watch(testerNote, (next) => {
			try {
				localStorage.setItem(NOTE_KEY, next);
			} catch {}
		});
		function selectScenario(id) {
			const next = mergeScenarios.find((candidate) => candidate.id === id);
			if (!next) return;
			scenario.value = next;
			simulation.value = null;
		}
		function run() {
			simulation.value = runScenario(scenario.value);
		}
		const registerGroups = computed(() => simulation.value ? groupByRegister(simulation.value.entries) : []);
		const lifecycle = computed(() => simulation.value ? nodeLifecycle(simulation.value.entries) : []);
		function registerLine(entry) {
			return `${entry.registerLabel} · stamp v${entry.stamp[0]}`;
		}
		function lifecycleLine(row) {
			return `node ${row.nodeId} #${row.incarnation} · ${row.entry.kind} · ${verdictLabel(row.entry)}`;
		}
		function verdictLabel(entry) {
			const verdict = entry.verdict;
			if (verdict.kind === "no-op") return `no-op · ${verdict.because}`;
			if (verdict.kind === "rejected") return `rejected · ${verdict.code}`;
			return verdict.kind;
		}
		const logCopyState = ref("idle");
		const reportCopyState = ref({ status: "idle" });
		const itemCopy = ref(null);
		const reportSources = ref({ ...DEFAULT_REPORT_SOURCES });
		const { copy } = useClipboard({ legacy: true });
		let itemCopyRequest = 0;
		const copyReportLabel = computed(() => {
			if (reportCopyState.value.status === "busy") return S.copying;
			if (reportCopyState.value.status === "done") return S.copied;
			if (reportCopyState.value.status === "failed") return t("agent.diagnosticReport.retry");
			return S.copyReport;
		});
		const copyLogLabel = computed(() => {
			if (logCopyState.value === "done") return S.copied;
			if (logCopyState.value === "failed") return S.copyFailed;
			return S.copyLog;
		});
		async function writeClipboard(text) {
			try {
				await copy(text);
				return true;
			} catch (error) {
				reportError(error, {
					surface: "agent",
					errorType: "crdt_dev_panel_clipboard_write_failed"
				});
				return false;
			}
		}
		async function copyItem(key, text) {
			const request = ++itemCopyRequest;
			const ok = await writeClipboard(text);
			if (request !== itemCopyRequest) return;
			itemCopy.value = {
				key,
				state: ok ? "done" : "failed"
			};
			clearTimeout(itemCopyReset);
			itemCopyReset = setTimeout(() => itemCopy.value = null, 1600);
		}
		function itemCopyLabel(key, idle = S.copy) {
			if (itemCopy.value?.key !== key) return idle;
			return itemCopy.value.state === "done" ? S.copied : S.copyFailed;
		}
		function flashLogCopyState(ok) {
			clearTimeout(logCopyReset);
			logCopyState.value = ok ? "done" : "failed";
			logCopyReset = setTimeout(() => logCopyState.value = "idle", 1600);
		}
		async function copyLog() {
			try {
				flashLogCopyState(await writeClipboard(stringifyDevEvents(matchingEvents.value)));
			} catch {
				flashLogCopyState(false);
			}
		}
		async function copyReport() {
			clearTimeout(reportCopyReset);
			const retainedReport = reportCopyState.value.status === "failed" ? reportCopyState.value.report : null;
			reportCopyState.value = { status: "busy" };
			if (retainedReport !== null) {
				await copyCollectedReport(retainedReport);
				return;
			}
			try {
				const crdt = __props.snapshot?.() ?? docState.value ?? fallbackSnapshot();
				await copyCollectedReport(await collectCrdtDebugReport({
					crdt,
					events: devEvents.value,
					agentMessages: useAgentConversationStore().messages,
					identifiers: collectIdentifiers(crdt),
					testerNote: testerNote.value,
					mergeTrace: simulation.value?.entries,
					mediaUiDiagnostics: collectCurrentMediaUiDiagnostics(),
					sources: reportSources.value,
					...reportSources.value.workflow ? serializeActiveWorkflow() : {}
				}));
			} catch (error) {
				reportError(error, {
					surface: "agent",
					errorType: "crdt_dev_panel_report_copy_failed"
				});
				reportCopyState.value = {
					status: "failed",
					report: null
				};
			}
		}
		function collectCurrentMediaUiDiagnostics() {
			try {
				const nodeOutputStore = useNodeOutputStore();
				return collectMediaUiDiagnostics({
					nodes: collectAllNodes(app.rootGraph),
					getNodeOutputs: (node) => nodeOutputStore.getNodeOutputs(node),
					getNodeImageUrls: (node) => nodeOutputStore.getNodeImageUrls(node),
					root: document
				});
			} catch (error) {
				reportError(error, {
					surface: "agent",
					errorType: "agent_crdt_media_ui_diagnostics_failed",
					level: "warning"
				});
				return;
			}
		}
		async function copyCollectedReport(report) {
			try {
				await navigator.clipboard.writeText(report);
			} catch {
				reportCopyState.value = {
					status: "failed",
					report
				};
				return;
			}
			reportCopyState.value = { status: "done" };
			reportCopyReset = setTimeout(() => reportCopyState.value = { status: "idle" }, 1600);
		}
		function fallbackSnapshot() {
			return {
				status: __props.status,
				tabId: null,
				lastSeq: null,
				schemaError: null,
				meta: {},
				nodeIds: [],
				linkIds: [],
				appliedOpIds: [],
				stamps: {}
			};
		}
		function serializeActiveWorkflow() {
			try {
				return { workflow: app.rootGraph.serialize() };
			} catch (error) {
				return { workflowError: String(error) };
			}
		}
		/**
		* The IDs a backend engineer needs to find this session in Datadog/logs —
		* see {@link ReportIdentifiers}. Collected here rather than inside
		* `crdtDebugReport.ts` because every value lives behind a Pinia store or
		* composable, and that module deliberately stays framework-store-free.
		*
		* Per-field try/catch, not one wrapping try/catch: a store that throws
		* (uninitialized outside a real app mount, e.g. in a test) must not blank
		* out the eight other identifiers that read fine — the same fault-isolation
		* principle `attempt()` uses for the async sources in crdtDebugReport.ts.
		*/
		function collectIdentifiers(crdt) {
			const read = (get) => {
				try {
					return get();
				} catch {
					return null;
				}
			};
			const recentJobIds = read(() => {
				const queueStore = useQueueStore();
				return [
					...queueStore.runningTasks,
					...queueStore.pendingTasks,
					...queueStore.historyTasks
				].map((task) => task.jobId);
			}) ?? [];
			const conversation = read(() => useAgentConversationStore());
			const recentAgentTurnIds = conversation ? [...new Set(conversation.messages.map((message) => message.id))].reverse().slice(0, 10) : [];
			const crdtLamport = Object.values(crdt.stamps).reduce((highest, stamp) => {
				const counter = Array.isArray(stamp) ? stamp[0] : void 0;
				if (typeof counter !== "number") return highest;
				return highest === null ? counter : Math.max(highest, counter);
			}, null);
			const activeWorkflow = read(() => useWorkflowStore().activeWorkflow);
			return {
				userId: read(() => useCurrentUser().resolvedUserInfo.value?.id ?? null),
				organizationId: null,
				workspaceId: read(() => useTeamWorkspaceStore().activeWorkspaceId ?? null),
				agentThreadId: conversation?.threadId ?? null,
				activeAgentTurnId: conversation?.activeTurnId ?? null,
				recentAgentTurnIds,
				tabId: crdt.tabId,
				activeJobId: read(() => useExecutionStore().activeJobId ?? null),
				recentJobIds,
				workflowPath: activeWorkflow?.path ?? null,
				workflowId: crdt.status.workflowId ?? null,
				graphId: activeWorkflow?.activeState?.id ?? null,
				docId: crdt.status.workflowId ?? null,
				crdtSequence: crdt.lastSeq,
				crdtLamport,
				clientId: read(() => api.clientId ?? null),
				deployEnv: read(() => resolveDeployEnv() ?? null),
				backendUrl: read(() => `${api.api_host}${api.api_base}`) ?? "unknown"
			};
		}
		function dismiss() {
			setOpen(false);
			dismissed.value = true;
			setHidden(true);
		}
		function restore() {
			dismissed.value = false;
			setHidden(false);
		}
		const proxyTarget = computed(() => api.apiURL(""));
		const chipLabel = computed(() => `CRDT ${__props.status.connected ? "live" : "off"} · ${__props.status.updatesApplied}`);
		function stringifyDetail(detail) {
			try {
				return JSON.stringify(detail, devEventReplacer()) ?? "";
			} catch {
				return S.unserializableDetail;
			}
		}
		function truncateDetail(detail, limit = 200) {
			if (detail.length <= limit) return detail;
			let end = 0;
			let count = 0;
			for (const codePoint of detail) {
				if (count === limit) break;
				end += codePoint.length;
				count++;
			}
			return end < detail.length ? `${detail.slice(0, end)}…` : detail;
		}
		function readNodeIdList(detail, key) {
			const value = Reflect.get(detail, key);
			return Array.isArray(value) ? value : [];
		}
		function eventNodeIds(event) {
			if (event.kind !== "doc_nodes_changed") return [];
			const detail = event.detail;
			if (typeof detail !== "object" || detail === null) return [];
			const added = readNodeIdList(detail, "added");
			const removed = readNodeIdList(detail, "removed");
			return [...new Set([...added, ...removed].filter((id) => typeof id === "string"))];
		}
		function fmtTime(at) {
			return new Date(at).toLocaleTimeString();
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1, [dismissed.value ? (openBlock(), createElementBlock("button", {
				key: 0,
				type: "button",
				title: S.restore,
				class: "mr-4 mb-1 flex h-6 cursor-pointer items-center gap-1 self-end rounded-full border bg-secondary px-2 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground",
				"data-testid": "crdt-dev-panel-restore",
				onClick: restore
			}, [_cache[11] || (_cache[11] = createBaseVNode("span", { class: "icon-[lucide--eye] size-3" }, null, -1)), createTextVNode(" " + toDisplayString(S.restore), 1)], 8, _hoisted_2)) : !open.value ? (openBlock(), createElementBlock("button", {
				key: 1,
				ref_key: "chipButton",
				ref: chipButton,
				type: "button",
				title: S.open,
				class: "mr-4 mb-1 flex h-6 cursor-pointer items-center gap-1 self-end rounded-full border bg-secondary px-2 text-muted-foreground transition-colors hover:bg-accent hover:text-foreground",
				"data-testid": "crdt-dev-panel-chip",
				onClick: _cache[0] || (_cache[0] = ($event) => setOpen(true))
			}, [createBaseVNode("span", { class: normalizeClass(unref(cn)("size-1.5 rounded-full", __props.status.connected ? "bg-success" : "bg-destructive")) }, null, 2), createTextVNode(" " + toDisplayString(chipLabel.value), 1)], 8, _hoisted_3)) : (openBlock(), createElementBlock("section", _hoisted_4, [
				createBaseVNode("header", _hoisted_5, [
					createBaseVNode("span", _hoisted_6, toDisplayString(S.title), 1),
					createBaseVNode("label", _hoisted_7, [createTextVNode(toDisplayString(S.verbosity) + " ", 1), withDirectives(createBaseVNode("select", {
						"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => level.value = $event),
						class: "rounded-sm border bg-secondary px-1 py-0.5",
						"data-testid": "crdt-dev-panel-verbosity",
						onChange: _cache[2] || (_cache[2] = ($event) => onLevelChange(level.value))
					}, [(openBlock(true), createElementBlock(Fragment, null, renderList(unref(CRDT_LOG_LEVELS), (option) => {
						return openBlock(), createElementBlock("option", {
							key: option,
							value: option
						}, toDisplayString(option), 9, _hoisted_8);
					}), 128))], 544), [[vModelSelect, level.value]])]),
					createBaseVNode("button", {
						type: "button",
						title: S.hide,
						class: "cursor-pointer text-muted-foreground hover:text-destructive",
						"data-testid": "crdt-dev-panel-dismiss",
						onClick: dismiss
					}, [..._cache[12] || (_cache[12] = [createBaseVNode("span", { class: "icon-[lucide--eye-off] size-4" }, null, -1)])], 8, _hoisted_9),
					createBaseVNode("button", {
						ref_key: "closeButton",
						ref: closeButton,
						type: "button",
						title: S.close,
						class: "cursor-pointer text-muted-foreground hover:text-foreground",
						"data-testid": "crdt-dev-panel-close",
						onClick: _cache[3] || (_cache[3] = ($event) => setOpen(false))
					}, [..._cache[13] || (_cache[13] = [createBaseVNode("span", { class: "icon-[lucide--x] size-4" }, null, -1)])], 8, _hoisted_10)
				]),
				createBaseVNode("nav", _hoisted_11, [(openBlock(true), createElementBlock(Fragment, null, renderList([
					["status", S.tabStatus],
					["log", S.tabLog],
					["merge", S.tabMerge]
				], (entry) => {
					return openBlock(), createElementBlock("button", {
						key: entry[0],
						type: "button",
						class: normalizeClass(unref(cn)("flex-1 cursor-pointer px-2 py-1 transition-colors", tab.value === entry[0] ? "border-b-2 border-primary text-foreground" : "text-muted-foreground hover:text-foreground")),
						"data-testid": `crdt-dev-panel-tab-${entry[0]}`,
						onClick: ($event) => tab.value = entry[0]
					}, toDisplayString(entry[1]), 11, _hoisted_12);
				}), 128))]),
				createBaseVNode("div", _hoisted_13, [tab.value === "status" ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
					createBaseVNode("section", null, [createBaseVNode("div", _hoisted_14, toDisplayString(S.sectionFollower), 1), createBaseVNode("table", _hoisted_15, [createBaseVNode("tbody", null, [(openBlock(), createElementBlock(Fragment, null, renderList(STATUS_ROWS, (row) => {
						return createBaseVNode("tr", { key: row[0] }, [createBaseVNode("td", _hoisted_16, toDisplayString(row[0]), 1), createBaseVNode("td", _hoisted_17, [createTextVNode(toDisplayString(row[1]()) + " ", 1), row[0] === "doc id" && __props.status.workflowId ? (openBlock(), createElementBlock("button", {
							key: 0,
							type: "button",
							class: "ml-1 cursor-pointer rounded-sm border px-1.5 py-0.5 hover:bg-accent",
							"aria-label": S.copyDocumentId,
							onClick: _cache[4] || (_cache[4] = ($event) => copyItem(`doc:${__props.status.workflowId}`, __props.status.workflowId))
						}, toDisplayString(itemCopyLabel(`doc:${__props.status.workflowId}`)), 9, _hoisted_18)) : createCommentVNode("", true)])]);
					}), 64))])])]),
					createBaseVNode("section", null, [createBaseVNode("div", _hoisted_19, toDisplayString(S.sectionDoc), 1), createBaseVNode("table", _hoisted_20, [createBaseVNode("tbody", null, [(openBlock(true), createElementBlock(Fragment, null, renderList(docRows.value, (row) => {
						return openBlock(), createElementBlock("tr", { key: row[0] }, [createBaseVNode("td", _hoisted_21, toDisplayString(row[0]), 1), createBaseVNode("td", _hoisted_22, toDisplayString(row[1]), 1)]);
					}), 128))])])]),
					createBaseVNode("section", _hoisted_23, [createBaseVNode("div", _hoisted_24, toDisplayString(S.sectionProxy), 1), createBaseVNode("div", _hoisted_25, toDisplayString(proxyTarget.value), 1)])
				], 64)) : tab.value === "log" ? (openBlock(), createElementBlock(Fragment, { key: 1 }, [createBaseVNode("div", _hoisted_26, [
					withDirectives(createBaseVNode("select", {
						"onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => scopeFilter.value = $event),
						class: "rounded-sm border bg-secondary px-1 py-0.5",
						"data-testid": "crdt-dev-panel-scope-filter"
					}, [createBaseVNode("option", _hoisted_27, toDisplayString(S.allScopes), 1), (openBlock(), createElementBlock(Fragment, null, renderList(SCOPES, (scope) => {
						return createBaseVNode("option", {
							key: scope,
							value: scope
						}, toDisplayString(scope), 9, _hoisted_28);
					}), 64))], 512), [[vModelSelect, scopeFilter.value]]),
					withDirectives(createBaseVNode("select", {
						"onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => levelFilter.value = $event),
						class: "rounded-sm border bg-secondary px-1 py-0.5"
					}, [createBaseVNode("option", _hoisted_29, toDisplayString(S.allLevels), 1), (openBlock(true), createElementBlock(Fragment, null, renderList(unref(CRDT_LOG_LEVELS), (option) => {
						return openBlock(), createElementBlock("option", {
							key: option,
							value: option
						}, toDisplayString(option), 9, _hoisted_30);
					}), 128))], 512), [[vModelSelect, levelFilter.value]]),
					withDirectives(createBaseVNode("select", {
						"onUpdate:modelValue": _cache[7] || (_cache[7] = ($event) => kindFilter.value = $event),
						class: "rounded-sm border bg-secondary px-1 py-0.5",
						"data-testid": "crdt-dev-panel-filter"
					}, [createBaseVNode("option", _hoisted_31, toDisplayString(S.allKinds), 1), (openBlock(true), createElementBlock(Fragment, null, renderList(unref(DEV_EVENT_KINDS), (kind) => {
						return openBlock(), createElementBlock("option", {
							key: kind,
							value: kind
						}, toDisplayString(kind), 9, _hoisted_32);
					}), 128))], 512), [[vModelSelect, kindFilter.value]]),
					createBaseVNode("span", _hoisted_33, toDisplayString(matchingEvents.value.length) + " " + toDisplayString(S.events), 1),
					createBaseVNode("button", {
						type: "button",
						class: "cursor-pointer rounded-sm border px-1.5 py-0.5 hover:bg-accent",
						onClick: _cache[8] || (_cache[8] = ($event) => unref(clearDevEvents)())
					}, toDisplayString(S.clear), 1)
				]), createBaseVNode("div", _hoisted_34, [(openBlock(true), createElementBlock(Fragment, null, renderList(visibleLogRows.value, (row) => {
					return openBlock(), createElementBlock("div", {
						key: row.event.seq,
						class: "border-b pb-1"
					}, [createBaseVNode("button", {
						type: "button",
						class: "block w-full cursor-pointer text-left hover:bg-accent",
						onClick: ($event) => expanded.value = expanded.value === row.event.seq ? null : row.event.seq
					}, [createBaseVNode("div", _hoisted_36, [
						createBaseVNode("span", _hoisted_37, toDisplayString(fmtTime(row.event.at)), 1),
						createBaseVNode("span", { class: normalizeClass(unref(cn)("rounded-sm border px-1", row.event.level === "warn" && "border-destructive text-destructive")) }, toDisplayString(row.event.scope), 3),
						createBaseVNode("span", _hoisted_38, toDisplayString(row.event.kind), 1)
					]), createBaseVNode("div", _hoisted_39, toDisplayString(expanded.value === row.event.seq ? row.detail : row.excerpt), 1)], 8, _hoisted_35), row.detail || row.nodeIds.length ? (openBlock(), createElementBlock("div", _hoisted_40, [
						row.detail ? (openBlock(), createElementBlock("button", {
							key: 0,
							type: "button",
							class: "cursor-pointer rounded-sm border px-1.5 py-0.5 hover:bg-accent",
							"aria-label": S.copyLogDetail,
							onClick: ($event) => copyItem(`detail:${row.event.seq}`, row.detail)
						}, toDisplayString(itemCopyLabel(`detail:${row.event.seq}`)), 9, _hoisted_41)) : createCommentVNode("", true),
						(openBlock(true), createElementBlock(Fragment, null, renderList(row.nodeIds, (nodeId) => {
							return openBlock(), createElementBlock("button", {
								key: nodeId,
								type: "button",
								class: "cursor-pointer rounded-sm border px-1.5 py-0.5 hover:bg-accent",
								"aria-label": `${S.copy} node id ${nodeId}`,
								onClick: ($event) => copyItem(`node:${row.event.seq}:${nodeId}`, nodeId)
							}, toDisplayString(itemCopyLabel(`node:${row.event.seq}:${nodeId}`, nodeId)), 9, _hoisted_42);
						}), 128)),
						row.hiddenNodeIdCount ? (openBlock(), createElementBlock("span", _hoisted_43, toDisplayString(S.moreNodeIds(row.hiddenNodeIdCount)), 1)) : createCommentVNode("", true)
					])) : createCommentVNode("", true)]);
				}), 128))])], 64)) : (openBlock(), createElementBlock(Fragment, { key: 2 }, [
					createBaseVNode("div", _hoisted_44, toDisplayString(S.simulated), 1),
					createBaseVNode("select", {
						class: "w-full rounded-sm border bg-secondary p-1",
						"data-testid": "crdt-dev-panel-scenario",
						onChange: _cache[9] || (_cache[9] = ($event) => selectScenario($event.target.value))
					}, [(openBlock(true), createElementBlock(Fragment, null, renderList(unref(mergeScenarios), (option) => {
						return openBlock(), createElementBlock("option", {
							key: option.id,
							value: option.id,
							selected: option.id === scenario.value.id
						}, toDisplayString(option.title), 9, _hoisted_45);
					}), 128))], 32),
					createBaseVNode("p", _hoisted_46, toDisplayString(S.question) + ": " + toDisplayString(scenario.value.question), 1),
					createBaseVNode("button", {
						type: "button",
						class: "w-full cursor-pointer rounded-sm border border-primary px-2 py-1 hover:bg-accent",
						"data-testid": "crdt-dev-panel-run",
						onClick: run
					}, toDisplayString(S.run), 1),
					simulation.value ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
						createBaseVNode("ol", _hoisted_47, [(openBlock(true), createElementBlock(Fragment, null, renderList(simulation.value.entries, (entry) => {
							return openBlock(), createElementBlock("li", {
								key: entry.index,
								class: "border-l-2 pl-2"
							}, [
								createBaseVNode("div", _hoisted_48, [
									createBaseVNode("span", _hoisted_49, toDisplayString(entry.index + 1) + ".", 1),
									createBaseVNode("span", _hoisted_50, toDisplayString(entry.kind), 1),
									createBaseVNode("span", _hoisted_51, toDisplayString(entry.actor), 1),
									createBaseVNode("span", { class: normalizeClass(unref(cn)("ml-auto rounded-sm border px-1", VERDICT_TONE[entry.verdict.kind])) }, toDisplayString(verdictLabel(entry)), 3)
								]),
								createBaseVNode("div", _hoisted_52, toDisplayString(registerLine(entry)), 1),
								createBaseVNode("p", _hoisted_53, toDisplayString(entry.explanation), 1)
							]);
						}), 128))]),
						createBaseVNode("section", null, [
							createBaseVNode("div", _hoisted_54, toDisplayString(S.sectionOutcome), 1),
							createBaseVNode("div", null, toDisplayString(simulation.value.survivingNodeIds.length) + " " + toDisplayString(S.survivingNodes) + ": " + toDisplayString(simulation.value.survivingNodeIds.join(", ") || S.none), 1),
							createBaseVNode("div", _hoisted_55, toDisplayString(S.survivingWidgets) + ": " + toDisplayString(truncateDetail(stringifyDetail(simulation.value.survivingWidgets))), 1)
						]),
						registerGroups.value.length ? (openBlock(), createElementBlock("section", _hoisted_56, [createBaseVNode("div", _hoisted_57, toDisplayString(S.sectionByRegister), 1), (openBlock(true), createElementBlock(Fragment, null, renderList(registerGroups.value, (group) => {
							return openBlock(), createElementBlock("div", { key: group.register }, [createBaseVNode("div", _hoisted_58, toDisplayString(group.label), 1), (openBlock(true), createElementBlock(Fragment, null, renderList(group.entries, (entry) => {
								return openBlock(), createElementBlock("div", {
									key: entry.index,
									class: "pl-2 text-muted-foreground"
								}, toDisplayString(entry.kind) + " · " + toDisplayString(entry.actor) + " · " + toDisplayString(verdictLabel(entry)), 1);
							}), 128))]);
						}), 128))])) : createCommentVNode("", true),
						lifecycle.value.length ? (openBlock(), createElementBlock("section", _hoisted_59, [createBaseVNode("div", _hoisted_60, toDisplayString(S.sectionLifecycle), 1), (openBlock(true), createElementBlock(Fragment, null, renderList(lifecycle.value, (row) => {
							return openBlock(), createElementBlock("div", { key: `${row.nodeId}-${row.entry.index}` }, toDisplayString(lifecycleLine(row)), 1);
						}), 128))])) : createCommentVNode("", true)
					], 64)) : createCommentVNode("", true),
					createBaseVNode("section", null, [createBaseVNode("div", _hoisted_61, toDisplayString(S.sectionVocab), 1), createBaseVNode("dl", _hoisted_62, [(openBlock(true), createElementBlock(Fragment, null, renderList(unref(MERGE_VOCABULARY), (item) => {
						return openBlock(), createElementBlock("div", { key: item.term }, [createBaseVNode("dt", _hoisted_63, toDisplayString(item.term), 1), createBaseVNode("dd", _hoisted_64, toDisplayString(item.meaning), 1)]);
					}), 128))])]),
					createBaseVNode("section", null, [createBaseVNode("label", _hoisted_65, toDisplayString(S.notePrompt), 1), withDirectives(createBaseVNode("textarea", {
						id: "crdt-tester-note",
						"onUpdate:modelValue": _cache[10] || (_cache[10] = ($event) => testerNote.value = $event),
						rows: "3",
						placeholder: S.notePlaceholder,
						class: "w-full rounded-sm border bg-secondary p-1",
						"data-testid": "crdt-dev-panel-note"
					}, null, 8, _hoisted_66), [[vModelText, testerNote.value]])])
				], 64))]),
				createBaseVNode("footer", _hoisted_67, [
					createBaseVNode("div", _hoisted_68, toDisplayString(unref(t)("agent.diagnosticReport.includedSources")), 1),
					createBaseVNode("div", _hoisted_69, [(openBlock(), createElementBlock(Fragment, null, renderList(REPORT_SOURCE_LABELS, (source) => {
						return createBaseVNode("button", {
							key: source.key,
							type: "button",
							role: "switch",
							"aria-checked": reportSources.value[source.key],
							class: normalizeClass(unref(cn)("flex cursor-pointer items-center gap-1 rounded-full border px-2 py-0.5 transition-colors", reportSources.value[source.key] ? "border-primary text-foreground" : "border-border text-muted-foreground")),
							"data-testid": `crdt-dev-panel-include-${String(source.key)}`,
							onClick: ($event) => reportSources.value[source.key] = !reportSources.value[source.key]
						}, [createBaseVNode("span", { class: normalizeClass(unref(cn)("size-3 shrink-0", reportSources.value[source.key] ? "icon-[lucide--check]" : "icon-[lucide--minus] opacity-50")) }, null, 2), createTextVNode(" " + toDisplayString(source.label), 1)], 10, _hoisted_70);
					}), 64))]),
					createBaseVNode("p", _hoisted_71, toDisplayString(S.includeHint), 1),
					createBaseVNode("div", _hoisted_72, [createBaseVNode("button", {
						type: "button",
						class: "flex-1 cursor-pointer rounded-sm border px-2 py-1 hover:bg-accent",
						onClick: copyLog
					}, toDisplayString(copyLogLabel.value), 1), createBaseVNode("button", {
						type: "button",
						disabled: reportCopyState.value.status === "busy",
						class: "flex-2 cursor-pointer rounded-sm border border-primary px-2 py-1 hover:bg-accent disabled:cursor-default",
						"data-testid": "crdt-dev-panel-copy-report",
						onClick: copyReport
					}, toDisplayString(copyReportLabel.value), 9, _hoisted_73)]),
					reportCopyState.value.status === "failed" ? (openBlock(), createElementBlock("div", _hoisted_74, [createBaseVNode("p", _hoisted_75, toDisplayString(reportCopyState.value.report === null ? unref(t)("agent.diagnosticReport.collectionFailed") : unref(t)("agent.diagnosticReport.clipboardFailed")), 1), reportCopyState.value.report !== null ? (openBlock(), createElementBlock("textarea", {
						key: 0,
						"aria-label": unref(t)("agent.diagnosticReport.manualCopy"),
						value: reportCopyState.value.report,
						readonly: "",
						rows: "3",
						class: "mt-1 w-full rounded-sm border bg-secondary p-1"
					}, null, 8, _hoisted_76)) : createCommentVNode("", true)])) : createCommentVNode("", true)
				])
			]))]);
		};
	}
});
//#endregion
export { CrdtDevPanel_default as default };
