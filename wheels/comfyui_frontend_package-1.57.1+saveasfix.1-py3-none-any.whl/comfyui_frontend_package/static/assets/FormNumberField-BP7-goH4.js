import "./rolldown-runtime-xtsTai4I.js";
import { F as createBaseVNode, G as defineComponent, I as createBlock, Kt as normalizeClass, U as createVNode, Wt as unref, ct as openBlock, dt as renderSlot, et as mergeProps, wt as withCtx, z as createPropsRestProxy } from "./vendor-vue-core-CuN1excl.js";
import { Nn as useForwardProps, it as NumberFieldDecrement_default$1, rt as NumberFieldIncrement_default$1 } from "./vendor-reka-ui-NRTk7aIV.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { n as NumberField_default, t as NumberFieldInput_default } from "./NumberFieldInput-CUxTsNZT.js";
//#endregion
//#region src/components/ui/number-field/NumberFieldDecrement.vue
var NumberFieldDecrement_default = /* @__PURE__ */ defineComponent({
	__name: "NumberFieldDecrement",
	props: {
		disabled: { type: Boolean },
		asChild: { type: Boolean },
		as: {},
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	},
	setup(__props) {
		const restProps = createPropsRestProxy(__props, ["class"]);
		const forwarded = useForwardProps(restProps);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(NumberFieldDecrement_default$1), mergeProps(unref(forwarded), {
				"data-slot": "number-field-decrement",
				class: unref(cn)("flex h-full w-6 shrink-0 cursor-pointer items-center justify-center rounded-l-lg border-none bg-transparent text-muted-foreground hover:bg-accent focus-visible:ring-1 focus-visible:ring-ring focus-visible:outline-none focus-visible:ring-inset disabled:pointer-events-none disabled:opacity-30", __props.class)
			}), {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default", {}, () => [_cache[0] || (_cache[0] = createBaseVNode("i", { class: "icon-[lucide--minus] size-4" }, null, -1))])]),
				_: 3
			}, 16, ["class"]);
		};
	}
});
//#endregion
//#region src/components/ui/number-field/NumberFieldIncrement.vue
var NumberFieldIncrement_default = /* @__PURE__ */ defineComponent({
	__name: "NumberFieldIncrement",
	props: {
		disabled: { type: Boolean },
		asChild: { type: Boolean },
		as: {},
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	},
	setup(__props) {
		const restProps = createPropsRestProxy(__props, ["class"]);
		const forwarded = useForwardProps(restProps);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(NumberFieldIncrement_default$1), mergeProps(unref(forwarded), {
				"data-slot": "number-field-increment",
				class: unref(cn)("flex h-full w-6 shrink-0 cursor-pointer items-center justify-center rounded-r-lg border-none bg-transparent text-muted-foreground hover:bg-accent focus-visible:ring-1 focus-visible:ring-ring focus-visible:outline-none focus-visible:ring-inset disabled:pointer-events-none disabled:opacity-30", __props.class)
			}), {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default", {}, () => [_cache[0] || (_cache[0] = createBaseVNode("i", { class: "icon-[lucide--plus] size-4" }, null, -1))])]),
				_: 3
			}, 16, ["class"]);
		};
	}
});
//#endregion
//#region src/components/common/FormNumberField.vue
var FormNumberField_default = /* @__PURE__ */ defineComponent({
	__name: "FormNumberField",
	props: {
		class: {
			type: [
				Boolean,
				null,
				String,
				Object,
				Array
			],
			default: "w-32"
		},
		modelValue: {},
		id: {},
		min: {},
		max: {},
		step: {},
		disabled: { type: Boolean },
		ariaLabelledby: {},
		ariaLabel: {},
		formatOptions: {},
		stepSnapping: { type: Boolean },
		inputClass: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	},
	emits: ["update:modelValue"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		return (_ctx, _cache) => {
			return openBlock(), createBlock(NumberField_default, {
				id: __props.id,
				"model-value": __props.modelValue,
				min: __props.min,
				max: __props.max,
				step: __props.step,
				disabled: __props.disabled,
				"format-options": __props.formatOptions,
				"step-snapping": __props.stepSnapping,
				class: normalizeClass(__props.class),
				"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => emit("update:modelValue", $event))
			}, {
				default: withCtx(() => [
					createVNode(NumberFieldDecrement_default, { "aria-label": _ctx.$t("g.decrement") }, null, 8, ["aria-label"]),
					renderSlot(_ctx.$slots, "prefix"),
					createVNode(NumberFieldInput_default, {
						"aria-label": __props.ariaLabel,
						"aria-labelledby": __props.ariaLabelledby,
						class: normalizeClass(__props.inputClass)
					}, null, 8, [
						"aria-label",
						"aria-labelledby",
						"class"
					]),
					renderSlot(_ctx.$slots, "suffix"),
					createVNode(NumberFieldIncrement_default, { "aria-label": _ctx.$t("g.increment") }, null, 8, ["aria-label"])
				]),
				_: 3
			}, 8, [
				"id",
				"model-value",
				"min",
				"max",
				"step",
				"disabled",
				"format-options",
				"step-snapping",
				"class"
			]);
		};
	}
});
//#endregion
export { FormNumberField_default as t };
