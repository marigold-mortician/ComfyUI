import { a as __toESM } from "./rolldown-runtime-xtsTai4I.js";
import { Rn as difference } from "./litegraph-CgrqhFEE.js";
import { t as delay } from "./delay-Cu8bS1zn.js";
import { n as useSettingStore } from "./settingStore-DRRi2kOn.js";
import { t as useNodeOutputStore } from "./nodeOutputStore-DmbNgTmp.js";
import { g as PRESERVED_QUERY_NAMESPACES, o as WorkspaceApiError, r as workspaceApi, s as DEPLOYMENT_LISTING_BACKSTOP_MS, t as useTeamWorkspaceStore, u as DEPLOYMENT_LISTING_RETRY_DELAYS_MS, y as getPreservedQueryParam } from "./teamWorkspaceStore-BNm5cZOK.js";
import { a as extractApiPrompt, c as resultItemType, i as api, o as extractWorkflow } from "./api-BdJmXw98.js";
import { Ft as ref, Ht as toValue, It as shallowReactive, Mt as onScopeDispose, Nt as reactive, Ot as effectScope, P as computed, Rt as shallowRef, bt as watch, d as defineStore, zt as toRaw } from "./vendor-vue-core-CuN1excl.js";
import { Gr as useIntervalFn, Ur as until, Xr as whenever, ar as useEventListener, qn as useAsyncState, zr as refAutoReset } from "./vendor-reka-ui-NRTk7aIV.js";
import { D as union, O as unknown, S as object, T as string, a as _enum, f as discriminatedUnion, l as array, r as datetime, t as fromZodError, u as boolean, v as literal, w as record, x as number } from "./vendor-zod-Del_rmdp.js";
import { Ot as zTaskResponse$1, T as zAsset$1, dt as zListAssetsResponse } from "./zod.gen-DzuaBm8H.js";
import { d as t, l as st } from "./i18n-BRluoVl-.js";
import { b as isPreviewableMediaType, m as getMediaTypeFromFilename } from "./formatUtil-DsZFGVbT.js";
import { r as reportError } from "./reportError-BHgDVvfb.js";
import { n as toError } from "./errorUtil-DoQyAUQC.js";
import { J as tryNormalizeNodeExecutionId } from "./graphTraversalUtil-BUK1cr2m.js";
import { E as WORKSPACE_STORAGE_KEYS } from "./storageIO-CAjGLygi.js";
import { t as useFeatureFlags } from "./useFeatureFlags-B3zg5FdZ.js";
import { r as pendingServerFact } from "./agentPanelStore-DndzlR19.js";
import { i as useNodeDefStore } from "./nodeDefStore-CF96GLZA.js";
import { i as parseErrorResponse } from "./errors-Bls3VadO.js";
import { n as useExecutionStore } from "./executionStore-DSsREODN.js";
import { t as require_quick_lru } from "./quick-lru-CwZ_Nev1.js";
import { c as getAssetFilename, i as getAssetCategories, y as isModelTypeCovered } from "./assetMetadataUtils-IzKjxxiA.js";
import { t as appendCloudResParam } from "./cloudPreviewUtil-QoYZLRNr.js";
import { n as resultItemPreviewUrl, o as filterPreviewableResults, r as resultItemUrl, t as findResultIndexByUrl } from "./resultItemUrl-BV9Vi8QF.js";
//#region src/platform/assets/schemas/assetSchema.ts
var zAsset = object({
	...zAsset$1.shape,
	created_at: datetime({ local: true }),
	hash: string().optional(),
	id: string(),
	last_access_time: datetime({ local: true }).optional(),
	preview_url: string().optional(),
	size: zAsset$1.shape.size.unwrap().transform(Number).optional(),
	tags: zAsset$1.shape.tags.default([]),
	thumbnail_url: string().optional(),
	updated_at: datetime({ local: true }),
	user_metadata: zAsset$1.shape.user_metadata.nullable().transform((value) => value ?? void 0).optional()
});
var zAssetResponse = zListAssetsResponse.pick({
	total: true,
	has_more: true,
	next_cursor: true
}).extend({ assets: array(zAsset) });
object({
	name: string(),
	pathIndex: number()
});
var zValidationError = object({
	code: string(),
	message: string(),
	field: string()
});
var zValidationResult = object({
	is_valid: boolean(),
	errors: array(zValidationError).optional(),
	warnings: array(zValidationError).optional()
});
object({
	content_length: number(),
	final_url: string(),
	content_type: string().optional(),
	filename: string().optional(),
	name: string().optional(),
	tags: array(string()).optional(),
	preview_url: string().optional(),
	preview_image: string().optional(),
	validation: zValidationResult.optional()
});
var zAsyncUploadTask = object({
	task_id: string(),
	status: _enum([
		"created",
		"running",
		"completed",
		"failed"
	]),
	message: string().optional()
});
var zAsyncUploadResponse = discriminatedUnion("type", [object({
	type: literal("sync"),
	asset: zAsset
}), object({
	type: literal("async"),
	task: zAsyncUploadTask
})]);
var assetFilenameSchema = string().trim().min(1, "Filename cannot be empty").regex(/^[^\\:*?"<>|]+$/, "Invalid filename characters").regex(/^(?!\/)/, "Path must not be absolute").refine((value) => !value.split("/").includes(".."), "Path must not contain \"..\" segments");
var assetItemSchema = zAsset;
var assetResponseSchema = zAssetResponse;
var asyncUploadResponseSchema = zAsyncUploadResponse;
object({
	name: string().optional(),
	base_model: array(string()).optional(),
	additional_tags: array(string()).optional(),
	user_description: string().optional()
});
var tagsOperationResultSchema = object({
	total_tags: array(string()),
	added: array(string()).optional(),
	removed: array(string()).optional(),
	already_present: array(string()).optional(),
	not_present: array(string()).optional()
});
//#endregion
//#region src/platform/assets/constants/assetEvents.ts
/**
* Wire-level websocket event the backend broadcasts when a seed scan's fast
* (insert) phase completes — the moment newly scanned files' tags and loader
* paths become queryable.
*/
var ASSETS_SEED_FAST_COMPLETE_EVENT = "assets.seed.fast_complete";
//#endregion
//#region src/platform/workspace/deploymentHint.ts
var COMFY_CLOUD = "cloud";
function hintKey(workspaceId) {
	return `${WORKSPACE_STORAGE_KEYS.DEPLOYMENT_HINT_PREFIX}${workspaceId}`;
}
function unconfirmedCloudKey(workspaceId) {
	return `${WORKSPACE_STORAGE_KEYS.UNCONFIRMED_CLOUD_HINT_PREFIX}${workspaceId}`;
}
/** Reads this browser's deployment hint for the workspace; `unknown` when none is recorded or storage is unreadable. */
function readDeploymentHint(workspaceId) {
	if (workspaceId === null) return "unknown";
	try {
		const hint = localStorage.getItem(hintKey(workspaceId));
		if (hint !== null) return hint === COMFY_CLOUD ? "cloud" : "deployment";
		return localStorage.getItem(unconfirmedCloudKey(workspaceId)) === null ? "unknown" : "unconfirmed";
	} catch {
		return "unknown";
	}
}
/** Records the workspace's next boot target (null for Comfy Cloud), clearing any unconfirmed hint. */
function setDeploymentHint(workspaceId, deploymentId) {
	try {
		localStorage.setItem(hintKey(workspaceId), deploymentId ?? COMFY_CLOUD);
		localStorage.removeItem(unconfirmedCloudKey(workspaceId));
	} catch {
		console.warn("Failed to persist the deployment hint");
	}
}
/** Records Comfy Cloud as the workspace's next boot target until a listing says otherwise. */
function setUnconfirmedCloudHint(workspaceId) {
	try {
		localStorage.setItem(unconfirmedCloudKey(workspaceId), "1");
	} catch {
		console.warn("Failed to persist the deployment hint");
	}
}
/** True when the page was opened from a deployment link, in its URL or stashed across sign-in. */
function hasDeploymentLink() {
	return new URLSearchParams(window.location.search).has("deployment") || getPreservedQueryParam(PRESERVED_QUERY_NAMESPACES.DEPLOYMENT, "deployment") !== void 0;
}
//#endregion
//#region src/platform/workspace/deploymentPickState.ts
/** The `loaded` event for a listing from GET /api/workspaces/{id}/deployments. */
function loadedEvent(listing) {
	return {
		type: "loaded",
		deployments: listing.items,
		pickedDeploymentId: listing.picked_deployment_id ?? null,
		pickSource: listing.pick_source ?? null,
		defaultDeploymentId: listing.default_deployment_id ?? null,
		gonePickedDeploymentId: listing.gone_picked_deployment_id ?? null,
		goneDefaultDeploymentId: listing.gone_default_deployment_id ?? null,
		buildsVisible: listing.builds_visible
	};
}
/** The listing fields of a state or a `loaded` event, without the rest. */
function listingOf(source) {
	return {
		deployments: source.deployments,
		pickedDeploymentId: source.pickedDeploymentId,
		pickSource: source.pickSource,
		defaultDeploymentId: source.defaultDeploymentId,
		gonePickedDeploymentId: source.gonePickedDeploymentId,
		goneDefaultDeploymentId: source.goneDefaultDeploymentId,
		buildsVisible: source.buildsVisible
	};
}
function reduceDeploymentPick(state, event) {
	switch (event.type) {
		case "loaded": return withListing(state, listingOf(event));
		case "loadRefused": return state.phase === "switching" ? {
			phase: "switching",
			target: state.target,
			previousPhase: "hidden"
		} : { phase: "hidden" };
		case "loadFailed": return state.phase === "switching" || "deployments" in state ? state : { phase: "hidden" };
		case "switchStarted": return startSwitch(state, event.target);
		case "switchFailed": return endSwitch(state, (listing) => listing);
		case "defaultChanged": return endSwitch(state, (listing) => ({
			...listing,
			defaultDeploymentId: event.defaultDeploymentId,
			goneDefaultDeploymentId: null
		}));
		case "followedInPlace": return endSwitch(state, (listing) => ({
			...listing,
			pickSource: "workspace_default"
		}));
		case "workspaceChanged": return { phase: "idle" };
	}
}
function withListing(state, listing) {
	if (state.phase !== "switching") return {
		phase: "ready",
		...listing
	};
	return {
		phase: "switching",
		target: state.target,
		...listing
	};
}
function startSwitch(state, target) {
	if (state.phase === "switching") return state;
	if (state.phase === "ready") return {
		phase: "switching",
		target,
		...listingOf(state)
	};
	return {
		phase: "switching",
		target,
		previousPhase: state.phase
	};
}
function endSwitch(state, shown) {
	if (state.phase !== "switching") return state;
	if (!("deployments" in state)) return { phase: state.previousPhase };
	return {
		phase: "ready",
		...shown(listingOf(state))
	};
}
/**
* What changed between the deployment a page booted on and the one it runs
* on now (null for Comfy Cloud in both): `release` when the same deployment
* runs another Release, `deployment` when it runs on another deployment or
* Comfy Cloud with other nodes, null when its nodes are the same.
*/
function changeBetween(boot, now) {
	if (releaseOf(boot) === releaseOf(now)) return null;
	return deploymentOf(boot) === deploymentOf(now) ? "release" : "deployment";
}
function releaseOf(deployment) {
	return deployment?.release_id ?? null;
}
function deploymentOf(deployment) {
	return deployment?.deployment_id ?? null;
}
//#endregion
//#region src/platform/workspace/deploymentSwitchReload.ts
var SWITCH_LANDING_KEY = "Comfy.DeploymentSwitch.Reloading";
function forgetSwitchLanding() {
	try {
		sessionStorage.removeItem(SWITCH_LANDING_KEY);
	} catch {
		return;
	}
}
function markSwitchLanding() {
	try {
		sessionStorage.setItem(SWITCH_LANDING_KEY, "1");
	} catch {
		return;
	}
}
var stayWatch = new AbortController();
function onNextInteraction(callback) {
	stayWatch.abort();
	const controller = new AbortController();
	stayWatch = controller;
	const run = () => {
		controller.abort();
		callback();
	};
	for (const type of ["pointerdown", "keydown"]) window.addEventListener(type, run, {
		capture: true,
		signal: controller.signal
	});
}
/** Reloads for a switch; `onStay` runs on the next interaction if it stays. */
function reloadForDeploymentSwitch(onStay) {
	markSwitchLanding();
	onNextInteraction(() => {
		forgetSwitchLanding();
		onStay();
	});
	window.location.reload();
}
/** True once, on the first boot after a deployment switch reloaded this tab. */
function takeDeploymentSwitchLanding() {
	try {
		const landed = sessionStorage.getItem(SWITCH_LANDING_KEY) !== null;
		sessionStorage.removeItem(SWITCH_LANDING_KEY);
		return landed;
	} catch {
		return false;
	}
}
//#endregion
//#region src/platform/workspace/stores/deploymentPickStore.ts
/**
* The deployment this browser runs on and the deployments it may pick
* (FE-2434), plus the workspace's default deployment an owner sets for
* members with no pick of their own (BE-17480). A deployment keeps its URL
* while its owner updates it to new Releases, so a pick follows those updates.
*
* A pick changes what the editor is served at boot (the node
* catalog of the Release the deployment runs and its packs' JavaScript), so a successful pick or clear reloads
* the page rather than patching the running editor.
*/
var useDeploymentPickStore = defineStore("deploymentPick", () => {
	const workspaceStore = useTeamWorkspaceStore();
	const state = shallowRef({ phase: "idle" });
	function dispatch(event) {
		state.value = reduceDeploymentPick(state.value, event);
	}
	const deployments = computed(() => "deployments" in state.value ? state.value.deployments : []);
	const pickedDeploymentId = computed(() => "pickedDeploymentId" in state.value ? state.value.pickedDeploymentId : null);
	const pickedDeployment = computed(() => deployments.value.find((d) => d.deployment_id === pickedDeploymentId.value) ?? null);
	const pickSource = computed(() => "pickSource" in state.value ? state.value.pickSource : null);
	/**
	* The workspace's default deployment when it is gone: still recorded, so
	* an owner can clear it, but members on it run on Comfy Cloud.
	*/
	const goneDefaultDeploymentId = computed(() => "goneDefaultDeploymentId" in state.value ? state.value.goneDefaultDeploymentId : null);
	/**
	* Set once a listing says ingest found this browser's own pick gone and
	* cleared it. Only that one listing says so, so the page keeps it until a
	* later listing shows a deployment picked again.
	*/
	const sawPickGone = shallowRef(false);
	const goneDeployment = computed(() => {
		if (sawPickGone.value) return "pick";
		if (goneDefaultDeploymentId.value !== null && pickSource.value !== "browser") return "default";
		return null;
	});
	const defaultDeploymentId = computed(() => "defaultDeploymentId" in state.value ? state.value.defaultDeploymentId : null);
	const defaultDeployment = computed(() => deployments.value.find((d) => d.deployment_id === defaultDeploymentId.value) ?? null);
	/**
	* True when this browser has no pick of its own and so runs on whatever
	* the workspace says: its default deployment, or Comfy Cloud without one.
	*/
	const followsWorkspace = computed(() => pickSource.value !== "browser");
	const canSetDefault = computed(() => pendingServerFact("BE-20674", workspaceStore.activeWorkspace?.role === "owner"));
	/**
	* True once a listing has answered, and while a reload of it is in flight.
	* False before any listing answers, when the account cannot pick, and when
	* the load failed with no listing to show. A listing that answered is shown
	* even when a newer load fails or never answers.
	*/
	const isVisible = computed(() => "deployments" in state.value);
	const isSwitching = computed(() => state.value.phase === "switching");
	const listingRefused = shallowRef(false);
	/**
	* The deployment this page booted on, from the first listing that
	* answered: null for Comfy Cloud (a gone pick, a rollout refusal, an ingest
	* without these routes, or a boot listing the editor gave up on; see
	* `bootOnComfyCloud`), undefined before the model source is known. The
	* editor's node catalog is that deployment's Release as it was at boot,
	* since a pick or a workspace switch reloads the page.
	*/
	const bootDeployment = shallowRef(void 0);
	/**
	* A change made elsewhere since this page booted that its nodes do not
	* show, read from the latest listing: `release` when its deployment now
	* runs another Release, `deployment` when it now runs on another
	* deployment or Comfy Cloud with other nodes (an owner changed the
	* default it follows, or its pick is gone). Jobs already run on the new
	* one; only a reload brings its nodes. Null when nothing changed.
	*/
	const changeSinceBoot = computed(() => {
		const boot = bootDeployment.value;
		if (boot === void 0 || !isVisible.value) return null;
		return changeBetween(boot, pickedDeployment.value);
	});
	const switcherOpenAsks = shallowRef(0);
	function requestSwitcherOpen() {
		switcherOpenAsks.value++;
	}
	/**
	* Orders the answers. Each `load()` takes the next number (`latestRequest`);
	* `lastApplied` is the number of the newest answer put on screen. A listing
	* or a 403 applies when it is newer than that, so a listing that answered
	* stays shown when a newer load fails or never answers; an older listing
	* still passes on a gone pick it reports. A plain failure
	* applies only when it is the latest load asked for and nothing newer has
	* applied, so it never replaces a listing that may still arrive. A default
	* the server took moves `lastApplied` up to `latestRequest`, which drops
	* every listing asked for before the change.
	*/
	let latestRequest = 0;
	let lastApplied = 0;
	let reportedLoadFailure = false;
	function load() {
		return loadListing([]);
	}
	/**
	* Load the listing, retrying a failure with no definite answer after each
	* of `retryDelaysMs` while this workspace is still the active one.
	*/
	async function loadListing(retryDelaysMs) {
		const id = workspaceStore.workspaceId;
		if (!id) return;
		const request = ++latestRequest;
		const event = await listingEvent(id, retryDelaysMs, () => workspaceStore.workspaceId === id, (err) => noteLoadFailure(id, err));
		if (workspaceStore.workspaceId !== id) return;
		applyAnswer(id, request, event);
	}
	function applyAnswer(workspaceId, request, event) {
		if (request <= lastApplied) {
			if (event.type === "loaded") keepPickGone(event.gonePickedDeploymentId);
			return;
		}
		if (event.type === "loadFailed") {
			if (request === latestRequest) dispatch(event);
			return;
		}
		lastApplied = request;
		dispatch(event);
		listingRefused.value = event.type === "loadRefused";
		if (event.type === "loaded") noteListing(event.gonePickedDeploymentId);
		if (event.type === "loadRefused" && bootDeployment.value === void 0) bootDeployment.value = null;
		rememberBootTarget(workspaceId);
	}
	function noteLoadFailure(workspaceId, err) {
		if (isTransient(err) && readDeploymentHint(workspaceId) === "unknown" && !hasDeploymentLink()) setUnconfirmedCloudHint(workspaceId);
		if (reportedLoadFailure || workspaceStore.workspaceId !== workspaceId) return;
		reportedLoadFailure = true;
		reportError(err, {
			surface: "workspace",
			errorType: "error_loading_deployment_listing"
		});
	}
	function rememberBootTarget(workspaceId) {
		setDeploymentHint(workspaceId, pickedDeployment.value?.deployment_id ?? null);
	}
	function reloadOnto(workspaceId, deploymentId) {
		setDeploymentHint(workspaceId, deploymentId);
		reloadForDeploymentSwitch(() => {
			dispatch({ type: "switchFailed" });
			load();
		});
	}
	function keepPickGone(gonePickedDeploymentId) {
		if (gonePickedDeploymentId !== null && pickedDeployment.value === null) sawPickGone.value = true;
	}
	function noteListing(gonePickedDeploymentId) {
		if (gonePickedDeploymentId !== null) sawPickGone.value = true;
		else if (pickedDeployment.value !== null) sawPickGone.value = false;
		if (bootDeployment.value === void 0) bootDeployment.value = pickedDeployment.value;
	}
	let firstLoad = null;
	/**
	* Another workspace, or another account (signed in without a reload), has
	* its own deployments: drop the old listing at once rather than show it
	* until the new one answers, and drop any listing still in flight. The
	* deployment this page booted on stays, since its nodes are still the
	* editor's until a reload.
	*/
	watch(() => workspaceStore.workspaceId, () => {
		dispatch({ type: "workspaceChanged" });
		sawPickGone.value = false;
		listingRefused.value = false;
		lastApplied = latestRequest;
		firstLoad = null;
	}, { flush: "sync" });
	/**
	* The page's first load, started at boot so the editor learns which
	* deployment it booted on; later calls wait on that same load. It retries
	* a failure with no definite answer (`DEPLOYMENT_LISTING_RETRY_DELAYS_MS`)
	* and reports only the last one.
	*/
	function loadOnce() {
		if (!firstLoad && workspaceStore.workspaceId) firstLoad = loadListing(DEPLOYMENT_LISTING_RETRY_DELAYS_MS);
		return firstLoad ?? Promise.resolve();
	}
	/**
	* The editor starts on Comfy Cloud's models when the boot listing failed
	* or did not answer in time. A listing that answers later does not change
	* that; it shows as `changeSinceBoot` when it names a deployment.
	*/
	function bootOnComfyCloud() {
		if (bootDeployment.value === void 0) bootDeployment.value = null;
	}
	/**
	* Pick a deployment for this browser, or null for Comfy Cloud, then reload so
	* the editor boots on it. Resolves to the server's refusal, or null when
	* the pick took (the page is reloading) or there was nothing to do.
	* Choosing what this browser already runs on does nothing, so a browser
	* that follows the workspace default keeps following it. Picking Comfy
	* Cloud while following a default is this browser's own choice: it wins
	* over the default, until `followWorkspace` drops it.
	*/
	async function pick(deploymentId) {
		const id = workspaceStore.workspaceId;
		if (!id || state.value.phase !== "ready") return null;
		if (deploymentId === pickedDeploymentId.value) return null;
		return pickAndReload(id, deploymentId);
	}
	/**
	* Pick the deployment a link names (BE-20294), then reload like `pick`.
	* It waits for the page's first listing, so a link to what this browser
	* already runs on does nothing, but it does not need that listing to have
	* answered: an account outside the rollout, or a deployment that is gone
	* or not the workspace's, gets the server's refusal rather than nothing.
	*/
	async function pickFromLink(deploymentId) {
		const id = workspaceStore.workspaceId;
		if (!id || state.value.phase === "switching") return { kind: "unchanged" };
		let timeout;
		if (!await Promise.race([loadOnce().then(() => true), new Promise((resolve) => {
			timeout = setTimeout(() => resolve(false), 45e3);
		})]).finally(() => clearTimeout(timeout))) return { kind: "timedOut" };
		if (workspaceStore.workspaceId !== id || isSwitching.value) return { kind: "unchanged" };
		if (deploymentId === pickedDeploymentId.value) return { kind: "unchanged" };
		return pickLinkAndReload(id, deploymentId);
	}
	async function pickLinkAndReload(workspaceId, deploymentId) {
		dispatch({
			type: "switchStarted",
			target: deploymentId
		});
		const controller = new AbortController();
		let timeout;
		const selection = workspaceApi.pickDeployment(workspaceId, { deployment_id: deploymentId }, controller.signal).then(() => ({ kind: "picked" }), (error) => ({
			kind: "refused",
			message: errorMessage(error)
		}));
		const outcome = await Promise.race([selection, new Promise((resolve) => {
			timeout = setTimeout(() => {
				resolve({ kind: "timedOut" });
				controller.abort();
			}, DEPLOYMENT_LISTING_BACKSTOP_MS);
		})]).finally(() => clearTimeout(timeout));
		if (workspaceStore.workspaceId !== workspaceId) return { kind: "unchanged" };
		if (outcome.kind === "picked") reloadOnto(workspaceId, deploymentId);
		else dispatch({ type: "switchFailed" });
		return outcome;
	}
	async function pickAndReload(workspaceId, deploymentId) {
		dispatch({
			type: "switchStarted",
			target: deploymentId
		});
		try {
			if (deploymentId === null) await workspaceApi.clearDeployment(workspaceId);
			else await workspaceApi.pickDeployment(workspaceId, { deployment_id: deploymentId });
		} catch (err) {
			dispatch({ type: "switchFailed" });
			return errorMessage(err);
		}
		reloadOnto(workspaceId, deploymentId);
		return null;
	}
	async function followInPlace(workspaceId) {
		dispatch({
			type: "switchStarted",
			target: pickedDeploymentId.value
		});
		try {
			await workspaceApi.clearDeployment(workspaceId, { follow: "workspace" });
		} catch (err) {
			dispatch({ type: "switchFailed" });
			return errorMessage(err);
		}
		lastApplied = latestRequest;
		dispatch({ type: "followedInPlace" });
		await load();
		return null;
	}
	/**
	* Drop this browser's own pick so it runs on whatever the workspace says
	* (its default deployment, or Comfy Cloud), then reload. Resolves like `pick`.
	*/
	async function followWorkspace() {
		const id = workspaceStore.workspaceId;
		if (!id || state.value.phase !== "ready") return null;
		if (followsWorkspace.value) return null;
		if (defaultDeploymentId.value === pickedDeploymentId.value) return followInPlace(id);
		dispatch({
			type: "switchStarted",
			target: defaultDeploymentId.value
		});
		try {
			await workspaceApi.clearDeployment(id, { follow: "workspace" });
		} catch (err) {
			dispatch({ type: "switchFailed" });
			return errorMessage(err);
		}
		reloadOnto(id, defaultDeploymentId.value);
		return null;
	}
	/** True when this default would change what this browser runs on. */
	function defaultMovesThisBrowser(deploymentId) {
		return followsWorkspace.value && deploymentId !== pickedDeploymentId.value;
	}
	/**
	* Set the workspace's default deployment (owner only), or clear it with null.
	* Members with no pick of their own move to it at their next boot. This
	* browser reloads only when it has no pick of its own, since only then
	* does the new default change what it runs on. Otherwise the new default
	* shows at once and the listing is refreshed to confirm it; a failed
	* refresh keeps the new default on screen, since the server has it, and a
	* listing asked for before the change is dropped when it lands.
	* Resolves to the server's refusal, or null when the default took.
	*/
	async function setDefault(deploymentId) {
		const id = workspaceStore.workspaceId;
		if (!id || state.value.phase !== "ready") return null;
		if (deploymentId === (defaultDeploymentId.value ?? goneDefaultDeploymentId.value)) return null;
		dispatch({
			type: "switchStarted",
			target: pickedDeploymentId.value
		});
		try {
			if (deploymentId === null) await workspaceApi.clearDefaultDeployment(id);
			else await workspaceApi.setDefaultDeployment(id, { deployment_id: deploymentId });
		} catch (err) {
			dispatch({ type: "switchFailed" });
			return errorMessage(err);
		}
		if (defaultMovesThisBrowser(deploymentId)) {
			reloadOnto(id, deploymentId);
			return null;
		}
		lastApplied = latestRequest;
		dispatch({
			type: "defaultChanged",
			defaultDeploymentId: deploymentId
		});
		await load();
		return null;
	}
	return {
		state,
		deployments,
		pickedDeploymentId,
		pickedDeployment,
		goneDeployment,
		pickSource,
		defaultDeploymentId,
		goneDefaultDeploymentId,
		defaultDeployment,
		followsWorkspace,
		canSetDefault,
		isVisible,
		isSwitching,
		listingRefused,
		bootDeployment,
		changeSinceBoot,
		switcherOpenAsks,
		load,
		loadOnce,
		bootOnComfyCloud,
		pick,
		pickFromLink,
		followWorkspace,
		setDefault,
		defaultMovesThisBrowser,
		requestSwitcherOpen
	};
});
async function listingEvent(workspaceId, retryDelaysMs, stillWanted, onFailure) {
	for (let attempt = 0;; attempt++) try {
		return loadedEvent(await workspaceApi.listDeployments(workspaceId));
	} catch (err) {
		if (!(attempt < retryDelaysMs.length) || !isTransient(err) || !stillWanted()) return loadFailure(err, onFailure);
		await new Promise((resolve) => setTimeout(resolve, retryDelaysMs[attempt]));
		if (!stillWanted()) return { type: "loadFailed" };
	}
}
/**
* A listing request that got no definite answer: no response (a network
* error or the request timeout), a 408 or 429, or a 5xx. A failure before
* the request (the sign-in step) is not retried.
*/
function isTransient(err) {
	if (!(err instanceof WorkspaceApiError)) return false;
	const { status } = err;
	return status === void 0 || status === 408 || status === 429 || status >= 500;
}
function loadFailure(err, onFailure) {
	if (err instanceof WorkspaceApiError && (err.status === 403 || err.status === 404)) return { type: "loadRefused" };
	onFailure(err);
	return { type: "loadFailed" };
}
function errorMessage(err) {
	return err instanceof Error ? err.message : String(err);
}
//#endregion
//#region src/platform/assets/mappings/modelNodeMappings.ts
var loraStackFilename = /^loras\.(?:0|[1-9]\d*)\.lora_name$/;
/**
* Default mappings from model directories to loader nodes.
*
* Each entry maps a model folder (as it appears in the model browser)
* to the node class that loads models from that folder and the
* input name or pattern used to select the model widget.
*
* An empty key ('') means the node auto-loads models without a widget
* selector, so no widget value is assigned when the node is added.
*
* Hierarchical fallback is handled by the store: "a/b/c" tries
* "a/b/c" → "a/b" → "a", so registering a parent directory covers
* all its children unless a more specific entry exists.
*
* Patterns enable the picker on every matching widget. Model drops populate
* the first matching widget.
*
* Format: [modelDirectory, nodeClass, inputNameOrPattern]
*/
var MODEL_NODE_MAPPINGS = [
	[
		"checkpoints",
		"CheckpointLoaderSimple",
		"ckpt_name"
	],
	[
		"checkpoints",
		"ImageOnlyCheckpointLoader",
		"ckpt_name"
	],
	[
		"loras",
		"LoraLoader",
		"lora_name"
	],
	[
		"loras",
		"LoraLoaderModelOnly",
		"lora_name"
	],
	[
		"loras",
		"LoadLoraModel",
		loraStackFilename
	],
	[
		"loras",
		"LoadLoraTextEncoder",
		loraStackFilename
	],
	[
		"vae",
		"VAELoader",
		"vae_name"
	],
	[
		"controlnet",
		"ControlNetLoader",
		"control_net_name"
	],
	[
		"diffusion_models",
		"UNETLoader",
		"unet_name"
	],
	[
		"upscale_models",
		"UpscaleModelLoader",
		"model_name"
	],
	[
		"style_models",
		"StyleModelLoader",
		"style_model_name"
	],
	[
		"gligen",
		"GLIGENLoader",
		"gligen_name"
	],
	[
		"clip_vision",
		"CLIPVisionLoader",
		"clip_name"
	],
	[
		"text_encoders",
		"CLIPLoader",
		"clip_name"
	],
	[
		"audio_encoders",
		"AudioEncoderLoader",
		"audio_encoder_name"
	],
	[
		"model_patches",
		"ModelPatchLoader",
		"name"
	],
	[
		"latent_upscale_models",
		"LatentUpscaleModelLoader",
		"model_name"
	],
	[
		"animatediff_models",
		"ADE_LoadAnimateDiffModel",
		"model_name"
	],
	[
		"animatediff_motion_lora",
		"ADE_AnimateDiffLoRALoader",
		"name"
	],
	[
		"chatterbox/chatterbox",
		"FL_ChatterboxTTS",
		""
	],
	[
		"chatterbox/chatterbox_turbo",
		"FL_ChatterboxTurboTTS",
		""
	],
	[
		"chatterbox/chatterbox_multilingual",
		"FL_ChatterboxMultilingualTTS",
		""
	],
	[
		"chatterbox/chatterbox_vc",
		"FL_ChatterboxVC",
		""
	],
	[
		"sam2",
		"DownloadAndLoadSAM2Model",
		"model"
	],
	[
		"sams",
		"SAMLoader",
		"model_name"
	],
	[
		"depthanything3",
		"DownloadAndLoadDepthAnythingV3Model",
		"model"
	],
	[
		"ipadapter",
		"IPAdapterModelLoader",
		"ipadapter_file"
	],
	[
		"nlf",
		"LoadNLFModel",
		"nlf_model"
	],
	[
		"FlashVSR",
		"FlashVSRNode",
		""
	],
	[
		"FlashVSR-v1.1",
		"FlashVSRNode",
		""
	],
	[
		"SEEDVR2",
		"SeedVR2LoadDiTModel",
		"model"
	],
	[
		"LLM/checkpoints",
		"LoadChatGLM3",
		"chatglm3_checkpoint"
	],
	[
		"liveportrait",
		"DownloadAndLoadLivePortraitModels",
		""
	],
	[
		"mimicmotion",
		"DownloadAndLoadMimicMotionModel",
		"model"
	],
	[
		"dwpose",
		"MimicMotionGetPoses",
		""
	],
	[
		"face_parsing",
		"FaceParsingModelLoader(FaceParsing)",
		""
	],
	[
		"rife",
		"RIFE VFI",
		"ckpt_name"
	],
	[
		"UltraShape",
		"UltraShapeLoadModel",
		"checkpoint"
	],
	[
		"detection",
		"OnnxDetectionModelLoader",
		"yolo_model"
	],
	[
		"CogVideo",
		"DownloadAndLoadCogVideoModel",
		""
	],
	[
		"CogVideo/ControlNet",
		"DownloadAndLoadCogVideoControlNet",
		""
	],
	[
		"checkpoints",
		"DynamiCrafterModelLoader",
		"ckpt_name"
	],
	[
		"controlnet",
		"DynamiCrafterCNLoader",
		"ckpt_name"
	],
	[
		"inpaint",
		"INPAINT_LoadInpaintModel",
		"model_name"
	],
	[
		"inpaint",
		"INPAINT_LoadFooocusInpaint",
		"head"
	],
	[
		"inpaint",
		"INPAINT_LoadFooocusInpaint",
		"patch"
	],
	[
		"yolo",
		"LayerMask: ObjectDetectorYOLO8",
		"yolo_model"
	],
	[
		"mediapipe",
		"LivePortraitLoadMediaPipeCropper",
		""
	],
	[
		"superprompt-v1",
		"Superprompt",
		""
	],
	[
		"background_removal",
		"LoadBackgroundRemovalModel",
		"bg_removal_name"
	],
	[
		"frame_interpolation",
		"FrameInterpolationModelLoader",
		"model_name"
	],
	[
		"film",
		"FILM VFI",
		"ckpt_name"
	],
	[
		"atm",
		"ATM VFI",
		"ckpt_name"
	],
	[
		"momo",
		"MOMO VFI",
		"ckpt_name"
	],
	[
		"diffusion_models",
		"MelBandRoFormerModelLoader",
		"model_name"
	],
	[
		"geometry_estimation",
		"LoadMoGeModel",
		"model_name"
	],
	[
		"optical_flow",
		"OpticalFlowLoader",
		"model_name"
	],
	[
		"loras",
		"WanVideoLoraSelect",
		"lora"
	],
	[
		"loras",
		"LTXICLoRALoaderModelOnly",
		"lora_name"
	]
];
//#endregion
//#region src/utils/widgetBinding.ts
function matchesWidgetName(name, selector) {
	return name !== "" && (typeof selector === "string" ? name === selector : name.search(selector) !== -1);
}
//#endregion
//#region src/stores/modelToNodeStore.ts
/** Helper class that defines how to construct a node from a model. */
var ModelNodeProvider = class {
	/** The node definition to use for this model. */
	nodeDef;
	/** The input name or pattern used to select the model widget. */
	key;
	constructor(nodeDef, key) {
		this.nodeDef = nodeDef;
		this.key = key;
	}
};
/** Service for mapping model types (by folder name) to nodes. */
var useModelToNodeStore = defineStore("modelToNode", () => {
	const modelToNodeMap = ref({});
	const nodeDefStore = useNodeDefStore();
	const haveDefaultsLoaded = ref(false);
	const registeredNodeTypes = computed(() => Object.fromEntries(Object.values(modelToNodeMap.value).filter((providers) => providers !== void 0).flat().map((provider) => [provider.nodeDef.name, provider.key])));
	/** Internal computed for efficient reverse lookup: nodeType -> category */
	const nodeTypeToCategory = computed(() => {
		const lookup = {};
		for (const [category, providers] of Object.entries(modelToNodeMap.value)) {
			if (!providers) continue;
			for (const provider of providers) if (!lookup[provider.nodeDef.name]) lookup[provider.nodeDef.name] = category;
		}
		return lookup;
	});
	/** Get set of all registered node types for efficient lookup */
	function getRegisteredNodeTypes() {
		registerDefaults();
		return registeredNodeTypes.value;
	}
	function isModelWidget(nodeType, widgetName) {
		const key = getRegisteredNodeTypes()[nodeType];
		return key !== void 0 && matchesWidgetName(widgetName, key);
	}
	/**
	* Get the category for a given node type.
	* Performs efficient O(1) lookup using cached reverse map.
	* @param nodeType The node type name to find the category for
	* @returns The category name, or undefined if not found
	*/
	function getCategoryForNodeType(nodeType) {
		registerDefaults();
		if (!nodeType || typeof nodeType !== "string") return;
		return nodeTypeToCategory.value[nodeType];
	}
	/**
	* Find providers for modelType with hierarchical fallback.
	* Tries exact match first, then progressively shorter parent paths.
	* e.g., "a/b/c" tries "a/b/c" → "a/b" → "a".
	*/
	function findProvidersWithFallback(modelType) {
		if (!modelType || typeof modelType !== "string") return;
		const segments = modelType.split("/");
		for (let i = segments.length; i >= 1; i--) {
			const path = segments.slice(0, i).join("/");
			const providers = modelToNodeMap.value[path];
			if (providers && providers.length > 0) return providers;
		}
	}
	/**
	* Get the node provider for the given model type name.
	* Supports hierarchical lookups: if "parent/child" has no match, falls back to "parent".
	* @param modelType The name of the model type to get the node provider for.
	* @returns The node provider for the given model type name.
	*/
	function getNodeProvider(modelType) {
		if (typeof modelType !== "string") return void 0;
		registerDefaults();
		return findProvidersWithFallback(modelType)?.[0];
	}
	/**
	* Get the list of all valid node providers for the given model type name.
	* Supports hierarchical lookups: if "parent/child" has no match, falls back to "parent".
	* @param modelType The name of the model type to get the node providers for.
	* @returns The list of all valid node providers for the given model type name.
	*/
	function getAllNodeProviders(modelType) {
		if (typeof modelType !== "string") return [];
		registerDefaults();
		return findProvidersWithFallback(modelType) ?? [];
	}
	/**
	* Register a node provider for the given model type name.
	* @param modelType The name of the model type to register the node provider for.
	* @param nodeProvider The node provider to register.
	*/
	function registerNodeProvider(modelType, nodeProvider) {
		registerDefaults();
		if (!nodeProvider.nodeDef) return;
		(modelToNodeMap.value[modelType] ??= []).push(nodeProvider);
	}
	/**
	* Register a node provider for the given simple names.
	* @param modelType The name of the model type to register the node provider for.
	* @param nodeClass The node class name to register.
	* @param key The key to use for the node input.
	*/
	function quickRegister(modelType, nodeClass, key) {
		registerNodeProvider(modelType, new ModelNodeProvider(nodeDefStore.nodeDefsByName[nodeClass], key));
	}
	function registerDefaults() {
		if (haveDefaultsLoaded.value) return;
		if (Object.keys(nodeDefStore.nodeDefsByName).length === 0) return;
		haveDefaultsLoaded.value = true;
		for (const [modelType, nodeClass, key] of MODEL_NODE_MAPPINGS) quickRegister(modelType, nodeClass, key);
	}
	return {
		modelToNodeMap,
		getRegisteredNodeTypes,
		isModelWidget,
		getCategoryForNodeType,
		getNodeProvider,
		getAllNodeProviders,
		registerNodeProvider,
		quickRegister,
		registerDefaults
	};
});
//#endregion
//#region src/platform/assets/services/assetService.ts
/**
* Maps CivitAI validation error codes to localized error messages
*/
function getLocalizedErrorMessage(errorCode) {
	return {
		FILE_TOO_LARGE: st("assetBrowser.errorFileTooLarge", "File too large"),
		FORMAT_NOT_ALLOWED: st("assetBrowser.errorFormatNotAllowed", "Format not allowed"),
		UNSAFE_PICKLE_SCAN: st("assetBrowser.errorUnsafePickleScan", "Unsafe pickle scan"),
		UNSAFE_VIRUS_SCAN: st("assetBrowser.errorUnsafeVirusScan", "Unsafe virus scan"),
		MODEL_TYPE_NOT_SUPPORTED: st("assetBrowser.errorModelTypeNotSupported", "Model type not supported"),
		INVALID_URL: st("assetBrowser.errorInvalidUrl", "Please provide a URL."),
		INVALID_URL_FORMAT: st("assetBrowser.errorInvalidUrlFormat", "The URL format is invalid. Please check and try again."),
		UNSUPPORTED_SOURCE: st("assetBrowser.errorUnsupportedSource", "This URL is not supported. Only Hugging Face and Civitai URLs are allowed."),
		UNAUTHORIZED: st("assetBrowser.errorUnauthorized", "Please sign in to continue."),
		USER_TOKEN_INVALID: st("assetBrowser.errorUserTokenInvalid", "Your stored API token is invalid or expired. Please update your token in settings."),
		USER_TOKEN_ACCESS_DENIED: st("assetBrowser.errorUserTokenAccessDenied", "Your API token does not have access to this resource. Please check your token permissions."),
		UNAUTHORIZED_SOURCE: st("assetBrowser.errorUnauthorizedSource", "This resource requires authentication. Please add your API token in settings."),
		ACCESS_FORBIDDEN: st("assetBrowser.errorAccessForbidden", "Access to this resource is forbidden."),
		RESOURCE_NOT_FOUND: st("assetBrowser.errorResourceNotFound", "The file was not found. Please check the URL and try again."),
		RATE_LIMITED: st("assetBrowser.errorRateLimited", "Too many requests. Please try again in a few minutes."),
		SOURCE_SERVER_ERROR: st("assetBrowser.errorSourceServerError", "The source server is experiencing issues. Please try again later."),
		NETWORK_TIMEOUT: st("assetBrowser.errorNetworkTimeout", "Request timed out. Please try again."),
		CONNECTION_REFUSED: st("assetBrowser.errorConnectionRefused", "Unable to connect to the source. Please try again later."),
		INVALID_HOST: st("assetBrowser.errorInvalidHost", "The source URL hostname could not be resolved."),
		NETWORK_ERROR: st("assetBrowser.errorNetworkError", "A network error occurred. Please check your connection and try again."),
		REQUEST_CANCELLED: st("assetBrowser.errorRequestCancelled", "Request was cancelled."),
		DOWNLOAD_CANCELLED: st("assetBrowser.errorDownloadCancelled", "Download was cancelled."),
		METADATA_FETCH_FAILED: st("assetBrowser.errorMetadataFetchFailed", "Failed to fetch file information from the source."),
		HTTP_ERROR: st("assetBrowser.errorHttpError", "An error occurred while fetching metadata."),
		SERVICE_UNAVAILABLE: st("assetBrowser.errorServiceUnavailable", "Service temporarily unavailable. Please try again later."),
		INTERNAL_ERROR: st("assetBrowser.errorInternalError", "An unexpected error occurred. Please try again.")
	}[errorCode] || st("assetBrowser.errorUnknown", "Unknown error") || "Unknown error";
}
var ASSETS_ENDPOINT = "/assets";
var ASSETS_SEED_ENDPOINT = "/assets/seed";
var ASSETS_DOWNLOAD_ENDPOINT = "/assets/download";
var ASSETS_EXPORT_ENDPOINT = "/assets/export";
var DEFAULT_LIMIT = 500;
var MAX_PAGINATION_BATCHES = 1e3;
var MODELS_TAG = "models";
/** Asset tag used by the backend for placeholder records that are not installed. */
var MISSING_TAG = "missing";
var DEFAULT_EXCLUDED_ASSET_TAGS = [MISSING_TAG];
var EMPTY_PAGE = {
	assets: [],
	total: 0,
	has_more: false
};
var uploadedAssetResponseSchema = assetItemSchema.extend({ created_new: boolean() });
function normalizeAssetTags(tags) {
	return tags.map((tag) => tag.trim()).filter(Boolean);
}
/**
* Orders loader paths as subdirectories before files at every level,
* alphabetical within each group. The asset API returns models in storage
* order, which would otherwise interleave root-level files with folder
* contents in the sidebar tree.
*/
function compareLoaderPaths(a, b) {
	const aSegments = a.split("/");
	const bSegments = b.split("/");
	const sharedDepth = Math.min(aSegments.length, bSegments.length);
	for (let i = 0; i < sharedDepth; i++) {
		const aIsFile = i === aSegments.length - 1;
		if (aIsFile !== (i === bSegments.length - 1)) return aIsFile ? 1 : -1;
		const order = aSegments[i].localeCompare(bSegments[i], void 0, { numeric: true });
		if (order !== 0) return order;
	}
	return 0;
}
/**
* Validates asset response data using Zod schema
*/
function validateAssetResponse(data) {
	const result = assetResponseSchema.safeParse(data);
	if (result.success) return result.data;
	const error = fromZodError(result.error);
	throw new Error(`Invalid asset response against zod schema:\n${error}`);
}
function validateUploadedAssetResponse(data) {
	const result = uploadedAssetResponseSchema.safeParse(data);
	if (result.success) return result.data;
	console.error("Invalid asset upload response:", fromZodError(result.error));
	throw new Error(st("assetBrowser.errorUploadFailed", "Failed to upload asset. Please try again."));
}
/**
* Private service for asset-related network requests
* Not exposed globally - used internally by ComfyApi
*/
function createAssetService() {
	/**
	* Model assets bucketed by folder category, built from a single walk of the
	* `models` tag rather than a fetch per category. Shared by the folder list
	* and per-folder listings so the sidebar loads every model in one pass.
	*/
	let modelBuckets = null;
	let modelBucketsRequestId = 0;
	let pendingModelBuckets = null;
	let modelBucketsMode = null;
	/**
	* Discards the cached model buckets so the next read re-walks the models
	* tag. Bumping the request id keeps a walk that was already in flight from
	* repopulating the cache with pre-invalidation data.
	*/
	function invalidateModelBuckets() {
		modelBucketsRequestId++;
		modelBuckets = null;
		pendingModelBuckets = null;
	}
	/**
	* Handles API response with consistent error handling and Zod validation
	*/
	async function handleAssetRequest(options, context) {
		const { includeTags, excludeTags = DEFAULT_EXCLUDED_ASSET_TAGS, limit = DEFAULT_LIMIT, offset, after, includePublic, signal } = options;
		const normalizedIncludeTags = normalizeAssetTags(includeTags);
		const normalizedExcludeTags = normalizeAssetTags(excludeTags);
		const queryParams = new URLSearchParams({
			include_tags: normalizedIncludeTags.join(","),
			limit: limit.toString()
		});
		if (normalizedExcludeTags.length > 0) queryParams.set("exclude_tags", normalizedExcludeTags.join(","));
		if (after !== void 0) queryParams.set("after", after);
		else if (offset !== void 0 && offset > 0) queryParams.set("offset", offset.toString());
		if (includePublic !== void 0) queryParams.set("include_public", includePublic ? "true" : "false");
		const url = `${ASSETS_ENDPOINT}?${queryParams.toString()}`;
		const res = signal ? await api.fetchApi(url, { signal }) : await api.fetchApi(url);
		if (!res.ok) throw new Error(`Unable to load ${context}: Server returned ${res.status}. Please try again.`);
		return validateAssetResponse(await res.json());
	}
	/**
	* Walks every `models`-tagged asset once and buckets each into the folder
	* categories `getAssetCategories` resolves for it. A single asset lands in
	* every category it is tagged with (e.g. a shared-root model in both
	* `checkpoints` and `diffusion_models`); an asset covered by `model_type:`
	* tags is grouped by those alone, so a legacy bare-tag twin left over from a
	* partial re-tagging cannot also cross-list it into another folder. Which
	* folders are actually shown is decided by `/experiment/models`; models with
	* no category tag are dropped with a warning rather than hidden silently.
	*/
	async function buildModelBuckets(modelTypeMode) {
		const assets = await getAllAssetsByTag(MODELS_TAG, false);
		const buckets = /* @__PURE__ */ new Map();
		for (const asset of assets) {
			const folders = [...new Set(getAssetCategories(asset, modelTypeMode))];
			if (folders.length === 0) {
				console.warn(`Asset ${asset.id} (${asset.name}) is tagged '${MODELS_TAG}' but has no model category; skipping.`);
				continue;
			}
			if (modelTypeMode && !asset.loader_path) {
				console.warn(`Asset ${asset.id} (${asset.name}) has no loader_path; skipping.`);
				continue;
			}
			const loaderValue = asset.loader_path ?? getAssetFilename(asset);
			if (!assetFilenameSchema.safeParse(loaderValue).success) {
				console.warn(`Asset ${asset.id} (${asset.name}) has an unsafe loader path ('${loaderValue}'); skipping.`);
				continue;
			}
			for (const folder of folders) {
				const bucket = buckets.get(folder);
				if (bucket) bucket.push(asset);
				else buckets.set(folder, [asset]);
			}
		}
		for (const bucket of buckets.values()) bucket.sort((a, b) => compareLoaderPaths(a.loader_path ?? getAssetFilename(a), b.loader_path ?? getAssetFilename(b)));
		return buckets;
	}
	/** Returns the memoized model buckets, walking the models tag on first read. */
	async function loadModelBuckets() {
		const modelTypeMode = useFeatureFlags().flags.supportsModelTypeTags;
		if (modelBucketsMode !== modelTypeMode) invalidateModelBuckets();
		if (modelBuckets) return modelBuckets;
		if (pendingModelBuckets) return pendingModelBuckets;
		modelBucketsMode = modelTypeMode;
		const requestId = ++modelBucketsRequestId;
		const walk = async () => {
			try {
				const buckets = await buildModelBuckets(modelTypeMode);
				if (requestId === modelBucketsRequestId) modelBuckets = buckets;
				return buckets;
			} finally {
				if (requestId === modelBucketsRequestId) pendingModelBuckets = null;
			}
		};
		pendingModelBuckets = walk();
		return pendingModelBuckets;
	}
	/**
	* Gets the models in the specified folder from the single models walk.
	* @param folder The folder to list models from, such as 'checkpoints'
	* @returns The list of model filenames within the specified folder
	*/
	async function getAssetModels(folder) {
		const modelTypeMode = useFeatureFlags().flags.supportsModelTypeTags;
		const buckets = await loadModelBuckets();
		return (buckets.get(folder) ?? buckets.get(folder.split("/")[0])?.filter((asset) => !(modelTypeMode && isModelTypeCovered(asset)) && asset.tags.some((tag) => tag === folder || tag.startsWith(`${folder}/`))) ?? []).map((asset) => ({
			name: asset.loader_path ?? getAssetFilename(asset),
			pathIndex: 0
		}));
	}
	/**
	* Asks the backend to rescan the model roots on disk so newly added files
	* become assets. Fire-and-forget: the scan's fast (insert) phase already
	* writes the category tags and filenames the sidebar needs and is announced
	* by an `assets.seed.fast_complete` websocket event. A 409 means a scan is
	* already running, which will emit the same event, so it is not an error.
	*/
	async function seedModelAssets() {
		const res = await api.fetchApi(ASSETS_SEED_ENDPOINT, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ roots: ["models"] })
		});
		if (!res.ok && res.status !== 409) throw new Error(`Unable to start asset scan: Server returned ${res.status}`);
	}
	/**
	* Subscribes to the backend's scan fast-phase completion broadcast — the
	* moment newly scanned files' tags and loader paths become queryable. The
	* wire-level event name is shared via `ASSETS_SEED_FAST_COMPLETE_EVENT`;
	* consumers receive a callback and an unsubscribe function.
	*/
	function onModelsScanned(callback) {
		const handler = () => {
			callback();
		};
		api.addCustomEventListener(ASSETS_SEED_FAST_COMPLETE_EVENT, handler);
		return () => {
			api.removeCustomEventListener(ASSETS_SEED_FAST_COMPLETE_EVENT, handler);
		};
	}
	/**
	* Checks if a widget input should use the asset browser based on both input name and node comfyClass
	*
	* @param nodeType - The ComfyUI node comfyClass (e.g., 'CheckpointLoaderSimple', 'LoraLoader')
	* @param widgetName - The name of the widget to check (e.g., 'ckpt_name')
	* @returns true if this input should use asset browser
	*/
	function isAssetBrowserEligible(nodeType, widgetName) {
		if (!nodeType || !widgetName) return false;
		return useModelToNodeStore().isModelWidget(nodeType, widgetName);
	}
	/**
	* Whether widget-embedded asset pickers (canvas + Vue node model widgets) are
	* enabled on Comfy Cloud without a deployment: MODEL_NODE_MAPPINGS is maintained for
	* cloud asset tagging. NOT the asset-API gate — that is
	* useFeatureFlags().flags.assetsEnabled.
	*/
	function isWidgetAssetPickerEnabled() {
		return false;
	}
	/**
	* Checks if the asset browser should be used for a given node input.
	* Combines the cloud environment check, user setting, and eligibility check.
	*
	* @param nodeType - The ComfyUI node comfyClass
	* @param widgetName - The name of the widget to check
	* @returns true if this input should use the asset browser
	*/
	function shouldUseWidgetAssetPicker(nodeType, widgetName) {
		return isWidgetAssetPickerEnabled() && isAssetBrowserEligible(nodeType, widgetName);
	}
	/**
	* Gets assets for a specific node type by finding the matching category
	* and fetching all assets with that category tag
	*
	* @param nodeType - The ComfyUI node type (e.g., 'CheckpointLoaderSimple')
	* @param options - Pagination options
	* @param options.limit - Maximum number of assets to return (default: 500)
	* @param options.offset - Number of assets to skip (default: 0)
	* @returns Promise<AssetItem[]> - Full asset objects with preserved metadata
	*/
	async function getAssetsForNodeType(nodeType, options = {}) {
		return (await getAssetsPageForNodeType(nodeType, options)).assets;
	}
	/**
	* Gets one paginated asset response for a specific node type by finding the
	* matching category and fetching assets with that category tag.
	*
	* Unlike {@link getAssetsForNodeType}, the full response envelope is
	* returned so callers can drive keyset cursor pagination from
	* `next_cursor`/`has_more`.
	*
	* @param nodeType - The ComfyUI node type (e.g., 'CheckpointLoaderSimple')
	* @param options - Pagination options
	* @param options.limit - Maximum number of assets to return (default: 500)
	* @param options.offset - Number of assets to skip (ignored when `after` is set)
	* @param options.after - Keyset cursor from a prior response's `next_cursor`
	* @param options.signal - Optional abort signal for cancelling the request
	* @returns Promise<AssetResponse> - Page of assets plus pagination metadata
	*/
	async function getAssetsPageForNodeType(nodeType, { limit = DEFAULT_LIMIT, offset = 0, after, signal } = {}) {
		if (!nodeType || typeof nodeType !== "string") return EMPTY_PAGE;
		const category = useModelToNodeStore().getCategoryForNodeType(nodeType);
		if (!category) return EMPTY_PAGE;
		return await handleAssetRequest({
			includeTags: [MODELS_TAG, category],
			limit,
			offset,
			after,
			signal
		}, `assets for ${nodeType}`);
	}
	/**
	* Gets complete details for a specific asset by ID
	* Calls the detail endpoint which includes user_metadata and all fields
	*
	* @param id - The asset ID
	* @returns Promise<AssetItem> - Complete asset object with user_metadata
	*/
	async function getAssetDetails(id) {
		const res = await api.fetchApi(`${ASSETS_ENDPOINT}/${id}`);
		if (!res.ok) throw new Error(`Unable to load asset details for ${id}: Server returned ${res.status}. Please try again.`);
		const data = await res.json();
		const result = assetItemSchema.safeParse(data);
		if (result.success) return result.data;
		const error = fromZodError(result.error);
		throw new Error(`Invalid asset response against zod schema:\n${error}`);
	}
	/**
	* Gets assets filtered by a specific tag
	*
	* @param tag - The tag to filter by (e.g., 'models', 'input')
	* @param includePublic - Whether to include public assets (default: true)
	* @param options - Pagination options
	* @param options.limit - Maximum number of assets to return (default: 500)
	* @param options.offset - Number of assets to skip (default: 0)
	* @param options.signal - Optional abort signal for cancelling the request
	* @returns Promise<AssetItem[]> - Full asset objects filtered by tag, excluding missing assets
	*/
	async function getAssetsByTag(tag, includePublic = true, { limit = DEFAULT_LIMIT, offset = 0, after, signal } = {}) {
		return (await getAssetsPageByTag(tag, includePublic, {
			limit,
			offset,
			after,
			signal
		})).assets;
	}
	/**
	* Gets one paginated asset response filtered by a specific tag.
	*/
	async function getAssetsPageByTag(tag, includePublic = true, { limit = DEFAULT_LIMIT, offset = 0, after, signal } = {}) {
		return await handleAssetRequest({
			includeTags: [tag],
			limit,
			offset,
			after,
			includePublic,
			signal
		}, `assets for tag ${tag}`);
	}
	/**
	* Gets every asset for a tag by walking paginated asset API responses.
	*
	* Uses keyset (cursor) pagination: each page is fetched with the prior
	* response's `next_cursor`, which is stable under concurrent inserts/deletes
	* and avoids the duplicate/skip drift that offset paging exhibits when the
	* underlying set changes mid-walk. Falls back to terminating on `has_more`
	* when the server omits `next_cursor`.
	*
	* @param tag - The tag to filter by (e.g., 'models', 'input')
	* @param includePublic - Whether to include public assets (default: true)
	* @param options - Pagination options
	* @param options.limit - Page size for each request (default: 500)
	* @param options.signal - Optional abort signal for cancelling requests
	* @returns Promise<AssetItem[]> - Full asset objects filtered by tag
	*/
	async function getAllAssetsByTag(tag, includePublic = true, { limit = DEFAULT_LIMIT, signal } = {}) {
		const assets = [];
		const pageSize = limit > 0 ? limit : DEFAULT_LIMIT;
		let after;
		let batchCount = 0;
		for (;;) {
			if (signal?.aborted) throw new DOMException("Aborted", "AbortError");
			if (batchCount++ >= MAX_PAGINATION_BATCHES) {
				console.warn(`Paginated walk for tag '${tag}' hit the ${MAX_PAGINATION_BATCHES}-batch backstop; returning a truncated listing.`);
				return assets;
			}
			const data = await getAssetsPageByTag(tag, includePublic, {
				limit: pageSize,
				after,
				signal
			});
			const batch = data.assets;
			if (batch.length === 0) return assets;
			assets.push(...batch);
			if (!data.has_more || !data.next_cursor || data.next_cursor === after) return assets;
			after = data.next_cursor;
		}
	}
	/**
	* Deletes an asset by ID
	* Only available in cloud environment
	*
	* @param id - The asset ID (UUID)
	* @returns Promise<void>
	* @throws Error if deletion fails
	*/
	async function deleteAsset(id) {
		const res = await api.fetchApi(`${ASSETS_ENDPOINT}/${id}`, { method: "DELETE" });
		if (!res.ok) throw new Error(`Unable to delete asset ${id}: Server returned ${res.status}`);
	}
	/**
	* Update metadata of an asset by ID
	* Only available in cloud environment
	*
	* @param id - The asset ID (UUID)
	* @param newData - The data to update
	* @returns Promise<AssetItem>
	* @throws Error if update fails
	*/
	async function updateAsset(id, newData) {
		const res = await api.fetchApi(`${ASSETS_ENDPOINT}/${id}`, {
			method: "PUT",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(newData)
		});
		if (!res.ok) throw new Error(`Unable to update asset ${id}: Server returned ${res.status}`);
		const newAsset = assetItemSchema.safeParse(await res.json());
		if (newAsset.success) return newAsset.data;
		throw new Error(`Unable to update asset ${id}: Invalid response - ${newAsset.error}`);
	}
	/**
	* Retrieves metadata from a download URL without downloading the file
	*
	* @param url - Download URL to retrieve metadata from (will be URL-encoded)
	* @returns Promise with metadata including content_length, final_url, filename, etc.
	* @throws Error if metadata retrieval fails
	*/
	async function getAssetMetadata(url) {
		const encodedUrl = encodeURIComponent(url);
		const res = await api.fetchApi(`${ASSETS_ENDPOINT}/remote-metadata?url=${encodedUrl}`);
		if (!res.ok) {
			const { code } = await parseErrorResponse(res);
			throw new Error(getLocalizedErrorMessage(code));
		}
		const data = await res.json();
		if (data.validation?.is_valid === false) throw new Error(getLocalizedErrorMessage(data.validation.errors?.[0]?.code || "UNKNOWN_ERROR"));
		return data;
	}
	/**
	* Uploads an asset by providing a URL to download from
	*
	* @param params - Upload parameters
	* @param params.url - HTTP/HTTPS URL to download from
	* @param params.name - Display name (determines extension)
	* @param params.tags - Optional freeform tags
	* @param params.user_metadata - Optional custom metadata object
	* @param params.preview_id - Optional UUID for preview asset
	* @returns Promise<AssetItem & { created_new: boolean }> - Asset object with created_new flag
	* @throws Error if upload fails
	*/
	async function uploadAssetFromUrl(params) {
		const res = await api.fetchApi(ASSETS_ENDPOINT, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(params)
		});
		if (!res.ok) throw new Error(st("assetBrowser.errorUploadFailed", "Failed to upload asset. Please try again."));
		return validateUploadedAssetResponse(await res.json());
	}
	/**
	* Uploads an asset from base64 data
	*
	* @param params - Upload parameters
	* @param params.data - Base64 data URL (e.g., "data:image/png;base64,...")
	* @param params.name - Display name (determines extension)
	* @param params.tags - Optional freeform tags
	* @param params.user_metadata - Optional custom metadata object
	* @returns Promise<AssetItem & { created_new: boolean }> - Asset object with created_new flag
	* @throws Error if upload fails
	*/
	async function uploadAssetFromBase64(params) {
		if (!params.data || !params.data.startsWith("data:")) throw new Error("Invalid data URL: expected a string starting with \"data:\"");
		const blob = await fetch(params.data).then((r) => r.blob());
		const formData = new FormData();
		formData.append("file", blob, params.name);
		if (params.tags) formData.append("tags", JSON.stringify(params.tags));
		if (params.user_metadata) formData.append("user_metadata", JSON.stringify(params.user_metadata));
		const res = await api.fetchApi(ASSETS_ENDPOINT, {
			method: "POST",
			body: formData
		});
		if (!res.ok) throw new Error(`Failed to upload asset from base64: ${res.status} ${res.statusText}`);
		return validateUploadedAssetResponse(await res.json());
	}
	/**
	* Add tags to an asset
	* @param id - The asset ID (UUID)
	* @param tags - Tags to add
	* @returns Promise<TagsOperationResult>
	*/
	async function addAssetTags(id, tags) {
		const res = await api.fetchApi(`${ASSETS_ENDPOINT}/${id}/tags`, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ tags })
		});
		if (!res.ok) throw new Error(`Unable to add tags to asset ${id}: Server returned ${res.status}`);
		const result = await res.json();
		const parseResult = tagsOperationResultSchema.safeParse(result);
		if (!parseResult.success) throw fromZodError(parseResult.error);
		return parseResult.data;
	}
	/**
	* Remove tags from an asset
	* @param id - The asset ID (UUID)
	* @param tags - Tags to remove
	* @returns Promise<TagsOperationResult>
	*/
	async function removeAssetTags(id, tags) {
		const res = await api.fetchApi(`${ASSETS_ENDPOINT}/${id}/tags`, {
			method: "DELETE",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ tags })
		});
		if (!res.ok) throw new Error(`Unable to remove tags from asset ${id}: Server returned ${res.status}`);
		const result = await res.json();
		const parseResult = tagsOperationResultSchema.safeParse(result);
		if (!parseResult.success) throw fromZodError(parseResult.error);
		return parseResult.data;
	}
	/**
	* Uploads an asset asynchronously using the /api/assets/download endpoint
	* Returns immediately with either the asset (if already exists) or a task to track
	*
	* @param params - Upload parameters
	* @param params.source_url - HTTP/HTTPS URL to download from
	* @param params.tags - Optional freeform tags
	* @param params.user_metadata - Optional custom metadata object
	* @param params.preview_id - Optional UUID for preview asset
	* @returns Promise<AsyncUploadResponse> - Either sync asset or async task info
	* @throws Error if upload fails
	*/
	async function uploadAssetAsync(params) {
		const res = await api.fetchApi(ASSETS_DOWNLOAD_ENDPOINT, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(params)
		});
		if (!res.ok) throw new Error(st("assetBrowser.errorUploadFailed", "Failed to upload asset. Please try again."));
		const data = await res.json();
		if (res.status === 202) {
			const result = asyncUploadResponseSchema.safeParse({
				type: "async",
				task: data
			});
			if (!result.success) throw new Error(st("assetBrowser.errorUploadFailed", "Failed to parse async upload response. Please try again."));
			return result.data;
		}
		const result = asyncUploadResponseSchema.safeParse({
			type: "sync",
			asset: data
		});
		if (!result.success) throw new Error(st("assetBrowser.errorUploadFailed", "Failed to parse sync upload response. Please try again."));
		return result.data;
	}
	async function createAssetExport(params) {
		const res = await api.fetchApi(ASSETS_EXPORT_ENDPOINT, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(params)
		});
		if (!res.ok) throw new Error(`Failed to create asset export: ${res.status}`);
		return await res.json();
	}
	async function getExportDownloadUrl(exportName) {
		const res = await api.fetchApi(`/assets/exports/${exportName}`);
		if (!res.ok) throw new Error(`Failed to get export download URL: ${res.status}`);
		return await res.json();
	}
	return {
		getAssetModels,
		invalidateModelBuckets,
		onModelsScanned,
		seedModelAssets,
		isWidgetAssetPickerEnabled,
		isAssetBrowserEligible,
		shouldUseWidgetAssetPicker,
		getAssetsForNodeType,
		getAssetsPageForNodeType,
		getAssetDetails,
		getAssetsByTag,
		getAssetsPageByTag,
		getAllAssetsByTag,
		deleteAsset,
		updateAsset,
		addAssetTags,
		removeAssetTags,
		getAssetMetadata,
		uploadAssetFromUrl,
		uploadAssetFromBase64,
		uploadAssetAsync,
		createAssetExport,
		getExportDownloadUrl
	};
}
var assetService = createAssetService();
//#endregion
//#region src/platform/assets/schemas/assetMetadataSchema.ts
/**
* Type guard to check if metadata is OutputAssetMetadata
*/
function isOutputAssetMetadata(metadata) {
	return !!metadata && typeof metadata.jobId === "string" && typeof metadata.subfolder === "string";
}
/**
* Safely extract output asset metadata
*/
function getOutputAssetMetadata(userMetadata) {
	if (isOutputAssetMetadata(userMetadata)) return userMetadata;
	return null;
}
//#endregion
//#region src/platform/assets/composables/media/assetMappers.ts
/**
* Extract asset type from tags array
* @param tags The tags array from AssetItem
* @returns The asset type ('input' or 'output')
*/
function getAssetType(tags) {
	if (tags?.[0] === "output") return "output";
	return "input";
}
/**
* Maps a TaskItemImpl output to an AssetItem format
* @param taskItem The task item containing execution data
* @param output The output from the task
* @param useDisplayName Whether to truncate the filename for display
* @returns AssetItem formatted object
*/
function mapTaskOutputToAssetItem(taskItem, output) {
	const metadata = {
		jobId: taskItem.jobId,
		nodeId: output.nodeId,
		subfolder: output.subfolder,
		executionTimeInSeconds: taskItem.executionTimeInSeconds,
		format: output.format,
		create_time: taskItem.createTime
	};
	const executionTime = taskItem.executionStartTimestamp ? new Date(taskItem.executionStartTimestamp).toISOString() : (/* @__PURE__ */ new Date()).toISOString();
	return {
		id: taskItem.jobId,
		name: output.filename,
		display_name: output.display_name,
		size: 0,
		created_at: executionTime,
		updated_at: executionTime,
		tags: ["output"],
		thumbnail_url: resultItemPreviewUrl(output),
		preview_url: resultItemUrl(output),
		user_metadata: metadata
	};
}
var byCreatedAtAsc = (a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime() || a.name.localeCompare(b.name);
var byCreatedAtDesc = (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
var byIsTemp = (a, b) => Number(b.tags.includes("temp")) - Number(a.tags.includes("temp"));
function flatAssetToResultItem(asset) {
	const metadata = getOutputAssetMetadata(asset.user_metadata);
	const url = asset.preview_url ?? "";
	return {
		assetId: asset.id,
		display_name: asset.display_name ?? void 0,
		filename: asset.name,
		format: metadata?.format,
		mediaType: getMediaTypeFromFilename(asset.name),
		nodeId: metadata?.nodeId ?? "",
		subfolder: metadata?.subfolder ?? "",
		type: asset.tags.includes("temp") ? "temp" : "output",
		url,
		previewUrl: asset.thumbnail_url ?? url
	};
}
/**
* Group flat per-file output assets into one asset per job, mirroring the
* grouped shape produced from the history API: the group id is the job id and
* user_metadata carries outputCount/allOutputs. Assets without output job
* metadata pass through ungrouped.
*/
function unflattenOutputAssets(flatAssets) {
	const assetsByJob = /* @__PURE__ */ new Map();
	const ungrouped = [];
	for (const asset of flatAssets) {
		const { job_id } = asset;
		if (!job_id) {
			ungrouped.push(asset);
			continue;
		}
		const group = assetsByJob.get(job_id);
		if (group) group.push(asset);
		else assetsByJob.set(job_id, [asset]);
	}
	return [...[...assetsByJob.entries()].map(([job_id, assets]) => {
		const ordered = [...assets].sort(byCreatedAtAsc);
		const representative = [...ordered].sort(byIsTemp).findLast((asset) => isPreviewableMediaType(getMediaTypeFromFilename(asset.name))) ?? ordered.at(-1);
		return {
			...representative,
			id: job_id,
			created_at: ordered.at(-1).created_at,
			user_metadata: {
				jobId: job_id,
				subfolder: "",
				...representative.user_metadata,
				assetId: representative.id,
				outputCount: ordered.length,
				allOutputs: ordered.map(flatAssetToResultItem)
			}
		};
	}), ...ungrouped].sort(byCreatedAtDesc);
}
/**
* Strips ComfyUI's trailing directory-type annotation (e.g. ` [input]`,
* ` [output]`, `[temp]`) from a filename returned by the OSS internal
* `/internal/files/{type}` endpoint. The annotation is part of the wire
* format LoadImage-style widgets expect, but for the assets sidebar we
* want the canonical on-disk filename so type detection / titles work.
*/
function stripDirectoryAnnotation(filename) {
	return filename.replace(/\s*\[(?:input|output|temp)\]\s*$/i, "");
}
/**
* Maps input directory file to AssetItem format
* @param filename The filename
* @param index File index for unique ID
* @param directory The directory type
* @returns AssetItem formatted object
*/
function mapInputFileToAssetItem(filename, index, directory = "input") {
	const cleanName = stripDirectoryAnnotation(filename);
	const params = new URLSearchParams({
		filename: cleanName,
		type: directory
	});
	const preview_url = api.apiURL(`/view?${params}`);
	appendCloudResParam(params, cleanName);
	const created_at = (/* @__PURE__ */ new Date()).toISOString();
	return {
		id: `${directory}-${index}-${cleanName}`,
		name: cleanName,
		size: 0,
		created_at,
		updated_at: created_at,
		tags: [directory],
		thumbnail_url: api.apiURL(`/view?${params}`),
		preview_url
	};
}
//#endregion
//#region src/utils/pagedList.ts
var WrappedList = class {
	childList;
	transform;
	items;
	constructor(childList, transform) {
		this.childList = childList;
		this.transform = transform;
		this.items = computed(() => this.transform(toValue(this.childList.items)));
	}
	get hasMore() {
		return this.childList.hasMore;
	}
	async invalidate(stale) {
		await this.childList.invalidate(stale);
	}
	get isLoading() {
		return this.childList.isLoading;
	}
	loadMore() {
		return this.childList.loadMore();
	}
	async loadNew() {
		await this.childList.loadNew();
	}
};
function getPagedList(params, state) {
	const key = state.paramKeyFn(params);
	const entry = state.cache.get(key) ?? {
		list: state.factory(params),
		refCount: 0
	};
	state.cache.set(key, entry);
	entry.refCount++;
	onScopeDispose(() => --entry.refCount || state.cache.delete(key));
	return new SharedPagedList(entry.list, state.cache, state.itemKeyFn);
}
var SharedPagedList = class {
	childList;
	cache;
	itemKeyFn;
	constructor(childList, cache, itemKeyFn) {
		this.childList = childList;
		this.cache = cache;
		this.itemKeyFn = itemKeyFn;
	}
	overlapping() {
		const snapshot = toValue(this.childList.items);
		if (snapshot.length === 0) return [this.childList];
		const staleKeys = new Set(snapshot.map(this.itemKeyFn));
		return [...this.cache.values()].filter((e) => toValue(e.list.items).some((item) => staleKeys.has(this.itemKeyFn(item)))).map((e) => e.list);
	}
	get hasMore() {
		return this.childList.hasMore;
	}
	async invalidate(stale) {
		const toInvalidate = stale ? [...this.cache.values()].map((l) => l.list) : this.overlapping();
		await Promise.all(toInvalidate.map((l) => l.invalidate(stale)));
	}
	get isLoading() {
		return this.childList.isLoading;
	}
	get items() {
		return this.childList.items;
	}
	loadMore() {
		return this.childList.loadMore();
	}
	async loadNew() {
		await Promise.all(this.overlapping().map((l) => l.loadNew()));
	}
};
var PREEMPT_KIND = Symbol();
function usePreemptableQueue() {
	const queue = [];
	const running = ref(false);
	let controller = new AbortController();
	function makeTask(kind, runner) {
		let resolve;
		const promise = new Promise((r) => resolve = r);
		const start = () => runner(controller.signal).catch(() => void 0).then(resolve);
		return {
			kind,
			promise,
			resolve,
			start
		};
	}
	function enqueue(kind, runner) {
		if (queue[0]?.kind === PREEMPT_KIND) return queue[0].promise;
		const existing = queue.find((task) => task.kind === kind);
		if (existing) return existing.promise;
		const task = makeTask(kind, runner);
		queue.push(task);
		if (queue.length === 1) startQueue();
		return task.promise;
	}
	async function preempt(runner) {
		if (queue[0]?.kind === PREEMPT_KIND) return queue[0].promise;
		const task = makeTask(PREEMPT_KIND, runner);
		controller.abort();
		controller = new AbortController();
		const active = queue.at(0);
		const existing = queue.splice(0, queue.length, task);
		if (active) {
			await active.promise;
			queue.push(task);
			for (const task of existing) task.resolve();
		} else startQueue();
		await task.promise;
	}
	async function startQueue() {
		running.value = true;
		while (queue.length) {
			await queue[0].start();
			queue.shift();
		}
		running.value = false;
	}
	return {
		enqueue,
		preempt,
		running
	};
}
//#endregion
//#region src/utils/requestUtil.ts
function sortedParams(params = {}) {
	const keys = Object.keys(params).sort();
	const obj = {};
	for (const k of keys) {
		const v = params[k];
		if (v === void 0) continue;
		obj[k] = Array.isArray(v) ? [...v].sort((a, b) => a.localeCompare(b)) : v;
	}
	return obj;
}
function encodeParams(params = {}) {
	const sorted = sortedParams(params);
	return Object.entries(sorted).map(([key, value]) => {
		const encoded = Array.isArray(value) ? value.map(String).map(encodeURIComponent).join(",") : encodeURIComponent(String(value));
		return `${encodeURIComponent(key)}=${encoded}`;
	}).join("&");
}
//#endregion
//#region src/platform/assets/composables/useAssetsQuery.ts
var BASE_PARAMS = {
	include_public: false,
	limit: 100,
	sort: "created_at",
	tags_none: ["missing"]
};
function assetsQueryInternal(params = {}, options = {}) {
	const onError = options.onError ?? console.error;
	let nextCursor;
	const seenCursors = /* @__PURE__ */ new Set();
	let loadGeneration = 0;
	const morePages = ref(true);
	const backingOff = refAutoReset(false, 2e3);
	const hasMore = computed(() => morePages.value && !backingOff.value);
	const items = ref([]);
	const { enqueue, preempt, running: isLoading } = usePreemptableQueue();
	let loadMorePromise;
	let invalidationQueue = Promise.resolve();
	async function doLoadMore(signal) {
		if (!hasMore.value) return;
		const requestedCursor = nextCursor ?? params.after;
		if (seenCursors.has(requestedCursor)) return;
		const assetResponse = await doQuery({ after: requestedCursor }, signal);
		if (!assetResponse) return;
		const knownIds = new Set(items.value.map(({ id }) => id));
		const newItems = assetResponse.assets.filter(({ id }) => {
			if (knownIds.has(id)) return false;
			knownIds.add(id);
			return true;
		});
		seenCursors.add(requestedCursor);
		nextCursor = assetResponse.next_cursor;
		morePages.value = assetResponse.has_more && nextCursor !== void 0 && !seenCursors.has(nextCursor);
		items.value.push(...newItems);
		loadGeneration++;
	}
	function loadMore() {
		if (!loadMorePromise) {
			const startingGeneration = loadGeneration;
			loadMorePromise = enqueue("loadMore", doLoadMore).then(() => loadGeneration > startingGeneration).finally(() => {
				loadMorePromise = void 0;
			});
		}
		return loadMorePromise;
	}
	function loadNew() {
		return enqueue("loadNew", async function(signal) {
			const knownIds = new Set(items.value.map((item) => item.id));
			const seenIds = new Set(knownIds);
			const newItems = [];
			let headCursor;
			const seenHeadCursors = /* @__PURE__ */ new Set();
			for (;;) {
				if (seenHeadCursors.has(headCursor)) break;
				seenHeadCursors.add(headCursor);
				const assetResponse = await doQuery(headCursor ? { after: headCursor } : {
					after: headCursor,
					limit: 10
				}, signal);
				if (!assetResponse) return;
				const { assets, has_more, next_cursor } = assetResponse;
				if (assets.some((asset) => {
					if (knownIds.has(asset.id)) return true;
					if (!seenIds.has(asset.id)) {
						seenIds.add(asset.id);
						newItems.push(asset);
					}
					return false;
				}) || !has_more || next_cursor === void 0) break;
				headCursor = next_cursor;
			}
			items.value.splice(0, 0, ...newItems);
		});
	}
	async function applyInvalidation(stale) {
		if (stale) {
			await preempt(() => Promise.resolve());
			const ids = new Set(stale);
			items.value = items.value.filter((item) => !ids.has(item.id));
			return;
		}
		await preempt(async () => {
			morePages.value = true;
			nextCursor = void 0;
			seenCursors.clear();
			items.value = [];
			await until(backingOff).toBe(false);
			await doLoadMore();
		});
	}
	function invalidate(stale) {
		const operation = invalidationQueue.then(() => applyInvalidation(stale));
		invalidationQueue = operation;
		return operation;
	}
	async function doQuery(overrideParams, signal) {
		const requestOptions = { signal };
		const query = encodeParams({
			...BASE_PARAMS,
			...params,
			...overrideParams
		});
		const resp = await api.fetchApi(`/assets?${query}`, requestOptions).catch((e) => onError("asset fetch failed", e));
		if (!resp) {
			if (!signal?.aborted) backingOff.value = true;
			return;
		}
		if (!resp.ok) {
			onError("asset request failed", resp);
			if (resp.status === 429 || resp.status >= 500) backingOff.value = true;
			else morePages.value = false;
			return;
		}
		const jsonresp = await resp.json().catch((e) => onError("failed to decode asset json response", e));
		if (!jsonresp) {
			morePages.value = false;
			return;
		}
		const parseResult = assetResponseSchema.safeParse(jsonresp);
		if (!parseResult.success) {
			onError("Failed to parse asset response", fromZodError(parseResult.error));
			morePages.value = false;
			return;
		}
		return parseResult.data;
	}
	loadMore();
	return {
		hasMore,
		invalidate,
		isLoading,
		items,
		loadMore,
		loadNew
	};
}
var sharedState = {
	cache: /* @__PURE__ */ new Map(),
	factory: assetsQueryInternal,
	paramKeyFn: encodeParams,
	itemKeyFn: (item) => item.id
};
function useAssetsQuery(params) {
	return getPagedList(params, sharedState);
}
async function invalidateAll() {
	await Promise.all([...sharedState.cache.values()].map((e) => e.list.invalidate()));
}
//#endregion
//#region src/stores/resultItemParsing.ts
var METADATA_KEYS = /* @__PURE__ */ new Set(["animated", "text"]);
function isUnknownArray(value) {
	return Array.isArray(value);
}
/**
* Validates that an unknown value is a well-formed ResultItem.
*
* Requires `filename` (string) since it is needed for a valid URL.
* `subfolder` is optional here — URL building falls back to ''.
*/
function isResultItem(item) {
	if (!item || typeof item !== "object" || Array.isArray(item)) return false;
	if (!("filename" in item) || typeof item.filename !== "string") return false;
	if ("type" in item && item.type !== void 0 && !resultItemType.safeParse(item.type).success) return false;
	return true;
}
function parseNodeOutput(nodeId, nodeOutput) {
	if (!nodeOutput) return [];
	return Object.entries(nodeOutput).flatMap(([mediaType, items]) => {
		if (METADATA_KEYS.has(mediaType) || !isUnknownArray(items)) return [];
		return items.filter(isResultItem).map((item) => ({
			subfolder: "",
			...item,
			mediaType,
			nodeId
		}));
	});
}
function parseTaskOutput(taskOutput) {
	return Object.entries(taskOutput).flatMap(([nodeId, nodeOutput]) => parseNodeOutput(nodeId, nodeOutput));
}
//#endregion
//#region src/services/extensionServiceAccess.ts
/** `useExtensionService` for `queueStore`, which `extensionService` reaches through the widget stores. */
var useExtensionServiceAccess;
/** Called by `extensionService` when it loads. */
function provideExtensionService(useService) {
	useExtensionServiceAccess = useService;
}
//#endregion
//#region src/services/jobOutputCache.ts
var import_quick_lru = /* @__PURE__ */ __toESM(require_quick_lru(), 1);
var MAX_TASK_CACHE_SIZE = 50;
var MAX_JOB_DETAIL_CACHE_SIZE = 50;
var MAX_JOB_ASSETS_CACHE_SIZE = 50;
var taskCache = new import_quick_lru.default({ maxSize: MAX_TASK_CACHE_SIZE });
var jobDetailCache = new import_quick_lru.default({ maxSize: MAX_JOB_DETAIL_CACHE_SIZE });
var jobAssetsCache = new import_quick_lru.default({ maxSize: MAX_JOB_ASSETS_CACHE_SIZE });
var inFlightJobAssets = /* @__PURE__ */ new Map();
var latestTaskRequestId = null;
function findActiveIndex(items, url) {
	return findResultIndexByUrl(items, url);
}
/**
* Gets previewable outputs for a task, with lazy loading, caching, and request deduping.
* Returns null if a newer request superseded this one while loading.
*/
async function getOutputsForTask(task) {
	const requestId = task.jobId;
	latestTaskRequestId = requestId;
	if (!((task.outputsCount ?? 0) > 1)) return [...task.previewableOutputs];
	const cached = taskCache.get(requestId);
	if (cached) return [...cached.previewableOutputs];
	try {
		const loadedTask = await task.loadFullOutputs();
		if (latestTaskRequestId !== requestId) return null;
		taskCache.set(requestId, loadedTask);
		return [...loadedTask.previewableOutputs];
	} catch (error) {
		if (latestTaskRequestId !== requestId) return null;
		console.warn("Failed to load full outputs, using preview:", error);
		return [...task.previewableOutputs];
	}
}
function getPreviewableOutputs(outputs) {
	if (!outputs) return [];
	return filterPreviewableResults(parseTaskOutput(outputs));
}
function getPreviewableOutputsFromJobDetail(jobDetail) {
	return getPreviewableOutputs(jobDetail?.outputs);
}
async function getJobDetail(jobId) {
	const cached = jobDetailCache.get(jobId);
	if (cached) return cached;
	try {
		const detail = await api.getJobDetail(jobId);
		if (detail) jobDetailCache.set(jobId, detail);
		return detail;
	} catch (error) {
		console.warn("Failed to fetch job detail:", error);
		return;
	}
}
/**
* Gets a job's output assets with LRU caching and in-flight request dedupe,
* so N concurrent resolutions of the same job issue one network request.
* Only complete, non-empty results are cached: an empty list usually means the
* endpoint is unavailable or the assets are not yet persisted, and a truncated
* one means a page failed mid-pagination. Caching either would pin an
* under-resolved set until LRU eviction, long after the endpoint recovered.
*/
async function getJobAssets(jobId) {
	const cached = jobAssetsCache.get(jobId);
	if (cached) return cached;
	const inFlight = inFlightJobAssets.get(jobId);
	if (inFlight) return inFlight;
	const request = api.getJobAssets(jobId).then(({ assets, complete }) => {
		if (complete && assets.length) jobAssetsCache.set(jobId, assets);
		return assets;
	}).finally(() => inFlightJobAssets.delete(jobId));
	inFlightJobAssets.set(jobId, request);
	return request;
}
async function getJobWorkflow(jobId) {
	const detail = await getJobDetail(jobId);
	return await extractWorkflow(detail);
}
/**
* The API-format graph a job stores, available only for jobs that embed no
* editor workflow. Returned unvalidated — see `extractApiPrompt`.
*/
async function getJobApiPrompt(jobId) {
	const detail = await getJobDetail(jobId);
	return extractApiPrompt(detail);
}
//#endregion
//#region src/stores/queueStore.ts
function toAugmentedPreviewOutput(previewOutput) {
	return {
		...previewOutput,
		filename: previewOutput.filename ?? "",
		subfolder: previewOutput.subfolder ?? ""
	};
}
var TaskItemImpl = class TaskItemImpl {
	job;
	outputs;
	flatOutputs;
	constructor(job, outputs, flatOutputs) {
		this.job = job;
		const effectiveOutputs = outputs ?? (job.preview_output ? { [job.preview_output.nodeId]: { [job.preview_output.mediaType]: [job.preview_output] } } : {});
		this.outputs = effectiveOutputs;
		this.flatOutputs = flatOutputs ?? (!outputs && job.preview_output?.mediaType === "text" ? [toAugmentedPreviewOutput(job.preview_output)] : this.calculateFlatOutputs());
	}
	calculateFlatOutputs() {
		return parseTaskOutput(this.outputs);
	}
	/** All outputs that support preview (images, videos, audio, 3D, text) */
	get previewableOutputs() {
		return filterPreviewableResults(this.flatOutputs);
	}
	get previewOutput() {
		const previewable = this.previewableOutputs;
		return previewable.findLast((output) => output.type === "output") ?? previewable.at(-1);
	}
	get taskType() {
		switch (this.job.status) {
			case "in_progress": return "Running";
			case "pending": return "Pending";
			default: return "History";
		}
	}
	get apiTaskType() {
		switch (this.taskType) {
			case "Running":
			case "Pending": return "queue";
			case "History": return "history";
		}
	}
	get key() {
		return this.jobId + this.displayStatus;
	}
	get jobId() {
		return this.job.id;
	}
	get outputsCount() {
		return this.job.outputs_count ?? void 0;
	}
	/** Absent on backends or jobs that predate this field. */
	get previewableOutputsCount() {
		return this.job.previewable_outputs_count ?? void 0;
	}
	get status() {
		return this.job.status;
	}
	get errorMessage() {
		return this.job.execution_error?.exception_message ?? void 0;
	}
	get executionError() {
		return this.job.execution_error ?? void 0;
	}
	get workflowId() {
		return this.job.workflow_id ?? void 0;
	}
	get createTime() {
		return this.job.create_time;
	}
	get interrupted() {
		return this.job.status === "failed" && this.job.execution_error?.exception_type === "InterruptProcessingException";
	}
	get isHistory() {
		return this.taskType === "History";
	}
	get isRunning() {
		return this.taskType === "Running";
	}
	get displayStatus() {
		switch (this.job.status) {
			case "in_progress": return "Running";
			case "pending": return "Pending";
			case "completed": return "Completed";
			case "failed": return "Failed";
			case "cancelled": return "Cancelled";
		}
	}
	get executionStartTimestamp() {
		return this.job.execution_start_time ?? void 0;
	}
	get executionEndTimestamp() {
		return this.job.execution_end_time ?? void 0;
	}
	get executionTime() {
		if (!this.executionStartTimestamp || !this.executionEndTimestamp) return;
		return this.executionEndTimestamp - this.executionStartTimestamp;
	}
	get executionTimeInSeconds() {
		return this.executionTime !== void 0 ? this.executionTime / 1e3 : void 0;
	}
	/**
	* Loads full outputs for tasks that only have preview data
	* Returns a new TaskItemImpl with full outputs and execution status
	*/
	async loadFullOutputs() {
		if (!this.isHistory) return this;
		const jobDetail = await getJobDetail(this.jobId);
		if (!jobDetail?.outputs) return this;
		return new TaskItemImpl(this.job, jobDetail.outputs);
	}
	async loadWorkflow(app) {
		if (!this.isHistory) return;
		const jobDetail = await getJobDetail(this.jobId);
		const workflowData = await extractWorkflow(jobDetail);
		if (!workflowData) return;
		await app.loadGraphData(toRaw(workflowData));
		const outputsToLoad = jobDetail?.outputs ?? this.outputs;
		const nodeOutputsStore = useNodeOutputStore();
		const rawOutputs = toRaw(outputsToLoad);
		for (const rawNodeExecutionId in rawOutputs) {
			const nodeExecutionId = tryNormalizeNodeExecutionId(rawNodeExecutionId);
			if (!nodeExecutionId) continue;
			nodeOutputsStore.setNodeOutputsByExecutionId(nodeExecutionId, rawOutputs[rawNodeExecutionId]);
		}
		useExtensionServiceAccess().invokeExtensions("onNodeOutputsUpdated", app.nodeOutputs);
	}
	flatten() {
		if (this.displayStatus !== "Completed") return [this];
		return this.flatOutputs.map((output, i) => new TaskItemImpl({
			...this.job,
			id: `${this.jobId}-${i}`
		}, { [output.nodeId]: { [output.mediaType]: [output] } }, [output]));
	}
};
var useQueueStore = defineStore("queue", () => {
	const runningTasks = shallowRef([]);
	const pendingTasks = shallowRef([]);
	const historyTasks = shallowRef([]);
	const hasFetchedHistorySnapshot = ref(false);
	const maxHistoryItems = ref(64);
	const isLoading = ref(false);
	const updateState = {
		inFlight: false,
		dirty: false
	};
	const hasDirtyUpdate = () => updateState.dirty;
	const tasks = computed(() => [
		...pendingTasks.value,
		...runningTasks.value,
		...historyTasks.value
	]);
	const flatTasks = computed(() => tasks.value.flatMap((task) => task.flatten()));
	const lastJobHistoryPriority = computed(() => historyTasks.value.length ? historyTasks.value[0].job.priority : -1);
	const hasPendingTasks = computed(() => pendingTasks.value.length > 0);
	const activeJobsCount = computed(() => pendingTasks.value.length + runningTasks.value.length);
	let currentUpdate = Promise.resolve();
	const update = async () => {
		if (updateState.inFlight) {
			updateState.dirty = true;
			return;
		}
		currentUpdate = fetchQueueAndHistory();
		await currentUpdate;
	};
	/** Like `update()`, but a coalesced call also waits for the trailing re-fetch. */
	async function updateFresh() {
		if (!updateState.inFlight) return update();
		updateState.dirty = true;
		await currentUpdate;
		await currentUpdate;
	}
	async function fetchQueueAndHistory() {
		updateState.inFlight = true;
		updateState.dirty = false;
		isLoading.value = true;
		try {
			const [queueResult, historyResult] = await Promise.allSettled([api.getQueue({ throwOnError: true }), api.getHistory(maxHistoryItems.value)]);
			if (queueResult.status === "fulfilled") {
				const queue = queueResult.value;
				runningTasks.value = queue.Running.map((job) => new TaskItemImpl(job));
				pendingTasks.value = queue.Pending.map((job) => new TaskItemImpl(job));
				const appearedTasks = [...pendingTasks.value, ...runningTasks.value];
				const executionStore = useExecutionStore();
				appearedTasks.forEach((task) => {
					const jobIdString = task.jobId;
					const workflowId = task.workflowId;
					if (workflowId && jobIdString) executionStore.registerJobWorkflowIdMapping(jobIdString, workflowId);
				});
				const activeJobIds = /* @__PURE__ */ new Set([...queue.Running.map((j) => j.id), ...queue.Pending.map((j) => j.id)]);
				executionStore.reconcileInitializingJobs(activeJobIds);
			} else console.error("Failed to fetch queue:", queueResult.reason);
			if (historyResult.status === "fulfilled") {
				const history = historyResult.value;
				const currentHistory = toValue(historyTasks);
				const sortedHistory = [...history].sort((a, b) => b.create_time - a.create_time).slice(0, toValue(maxHistoryItems));
				const existingByJobId = new Map(currentHistory.map((impl) => [impl.jobId, impl]));
				const nextHistoryTasks = sortedHistory.map((job) => {
					const existing = existingByJobId.get(job.id);
					if (!existing) return new TaskItemImpl(job);
					if (existing.outputsCount !== (job.outputs_count ?? void 0) || existing.previewableOutputsCount !== (job.previewable_outputs_count ?? void 0)) return new TaskItemImpl(job);
					return existing;
				});
				if (!(nextHistoryTasks.length === currentHistory.length && nextHistoryTasks.every((task, index) => task === currentHistory[index]))) historyTasks.value = nextHistoryTasks;
				hasFetchedHistorySnapshot.value = true;
			} else console.error("Failed to fetch history:", historyResult.reason);
		} finally {
			isLoading.value = false;
			updateState.inFlight = false;
			if (hasDirtyUpdate()) update();
		}
	}
	const clear = async (targets = ["queue", "history"]) => {
		if (targets.length === 0) return;
		await Promise.all(targets.map((type) => api.clearItems(type)));
		await update();
	};
	const deleteTask = async (task) => {
		await api.deleteItem(task.apiTaskType, task.jobId);
		await update();
	};
	return {
		runningTasks,
		pendingTasks,
		historyTasks,
		hasFetchedHistorySnapshot,
		maxHistoryItems,
		isLoading,
		tasks,
		flatTasks,
		lastJobHistoryPriority,
		hasPendingTasks,
		activeJobsCount,
		update,
		updateFresh,
		clear,
		delete: deleteTask
	};
});
var useQueuePendingTaskCountStore = defineStore("queuePendingTaskCount", {
	state: () => ({ count: 0 }),
	actions: { update(e) {
		const queueRemaining = e.detail?.exec_info?.queue_remaining;
		if (queueRemaining != null) this.count = queueRemaining;
	} }
});
var useQueueUIStore = defineStore("queueUIStore", () => {
	const settingStore = useSettingStore();
	const isOverlayExpanded = computed({
		get: () => settingStore.get("Comfy.Queue.History.Expanded"),
		set: (value) => settingStore.set("Comfy.Queue.History.Expanded", value)
	});
	function toggleOverlay() {
		isOverlayExpanded.value = !isOverlayExpanded.value;
	}
	return {
		isOverlayExpanded,
		toggleOverlay
	};
});
//#endregion
//#region src/platform/tasks/services/taskSchema.ts
var zTaskStatus = union([zTaskResponse$1.shape.status, literal("cancelled")]);
var zTaskResponse = zTaskResponse$1.extend({ status: zTaskStatus });
//#endregion
//#region src/platform/tasks/services/taskService.ts
var TASKS_ENDPOINT = "/tasks";
/**
* Result payload of a `task:download_file` task.
*
* `/tasks` is shared by every task type, so `TaskResponse.result` stays the
* generated opaque record and each caller parses the shape its own task type
* produces. Narrowing `result` on the shared response instead makes `getTask`
* reject every other task type's result, which silently disables
* reconciliation for those callers.
*/
var zDownloadFileResult = object({
	success: boolean(),
	file_path: string().optional(),
	bytes_downloaded: number().optional(),
	content_type: string().optional(),
	hash: string().optional(),
	filename: string().optional(),
	asset_id: string().optional(),
	metadata: record(string(), unknown()).optional(),
	error: string().optional()
});
/** Returns the download-file result, or `undefined` if it is absent or malformed. */
function parseDownloadFileResult(result) {
	const parsed = zDownloadFileResult.safeParse(result);
	return parsed.success ? parsed.data : void 0;
}
/**
* A `getTask` failure that proves the task row no longer exists, as opposed to
* a transient failure worth retrying. Callers tracking a task that can never
* reach a terminal status need to tell those apart to stop polling it.
*/
var TaskNotFoundError = class extends Error {
	constructor(taskId) {
		super(`Task not found: ${taskId}`);
		this.name = "TaskNotFoundError";
	}
};
function createTaskService() {
	async function getTask(taskId) {
		try {
			const res = await api.fetchApi(`${TASKS_ENDPOINT}/${encodeURIComponent(taskId)}`);
			if (!res.ok) return {
				ok: false,
				error: res.status === 404 ? new TaskNotFoundError(taskId) : /* @__PURE__ */ new Error(`Failed to get task ${taskId}: ${res.status}`)
			};
			const data = await res.json();
			const result = zTaskResponse.safeParse(data);
			if (!result.success) return {
				ok: false,
				error: new Error(fromZodError(result.error).message)
			};
			return {
				ok: true,
				value: result.data
			};
		} catch (error) {
			return {
				ok: false,
				error: toError(error)
			};
		}
	}
	async function cancelTask(taskId) {
		try {
			const res = await api.fetchApi(`${TASKS_ENDPOINT}/${encodeURIComponent(taskId)}`, { method: "DELETE" });
			if (res.status === 404) return {
				ok: true,
				value: "missing"
			};
			if (res.status === 409) return {
				ok: true,
				value: "not-cancellable"
			};
			if (!res.ok) return {
				ok: false,
				error: /* @__PURE__ */ new Error(`Failed to cancel task ${taskId}: ${res.status}`)
			};
			return {
				ok: true,
				value: "cancelling"
			};
		} catch (error) {
			return {
				ok: false,
				error: toError(error)
			};
		}
	}
	return {
		getTask,
		cancelTask
	};
}
var taskService = createTaskService();
//#endregion
//#region src/stores/assetDownloadStore.ts
var activeStatuses = /* @__PURE__ */ new Set(["created", "running"]);
var finishedStatuses = /* @__PURE__ */ new Set([
	"completed",
	"failed",
	"cancelled",
	"cancellation_unconfirmed"
]);
var recheckableStatuses = /* @__PURE__ */ new Set([
	"created",
	"running",
	"failed",
	"cancellation_pending"
]);
var reconcilableTaskStatuses = /* @__PURE__ */ new Set([
	"completed",
	"failed",
	"cancelled"
]);
var wireTaskStatuses = /* @__PURE__ */ new Set([
	"created",
	"running",
	"completed",
	"failed",
	"cancelled"
]);
function isDownloadActive(status) {
	return activeStatuses.has(status);
}
function isDownloadCancelled(status) {
	return status === "cancellation_pending" || status === "cancellation_unconfirmed" || status === "cancelled";
}
function isDownloadFinished(status) {
	return finishedStatuses.has(status);
}
function isDownloadRecheckable(status) {
	return recheckableStatuses.has(status);
}
var STALE_THRESHOLD_MS = 1e4;
var POLL_INTERVAL_MS = 1e4;
/**
* `cancellation_pending` is not a finished status, so the dialog withholds its
* Close control while a download is in it. Bounding how long we wait for the
* backend to confirm keeps a backend that accepts the DELETE and then never
* reports a terminal status from pinning the toast open until a page reload.
*/
var MAX_CANCELLATION_RECONCILE_ATTEMPTS = 6;
var MAX_TASK_NOT_FOUND_ATTEMPTS = 2;
var MAX_FAILED_RECONCILE_ATTEMPTS = 30;
var MAX_DISMISSED_DOWNLOADS = 256;
function generateDownloadTrackingPlaceholder(taskId, modelType, assetName) {
	return {
		taskId,
		modelType,
		assetName,
		bytesTotal: 0,
		bytesDownloaded: 0,
		progress: 0,
		status: "created",
		lastUpdate: Date.now()
	};
}
function shouldIgnoreDownloadUpdate(currentStatus, nextStatus) {
	if (currentStatus === "completed") return true;
	if (currentStatus === "cancelled") return nextStatus !== "completed";
	if (currentStatus === "cancellation_pending") return !reconcilableTaskStatuses.has(nextStatus);
	if (currentStatus === "cancellation_unconfirmed") return activeStatuses.has(nextStatus);
	return false;
}
/**
* Settle a cancellation the backend will never confirm. `cancelled` is not
* immutable in `shouldIgnoreDownloadUpdate`, so a later authoritative
* `completed` still replaces it; the stale error from any premature `failed`
* message is dropped because it no longer describes this entry.
*/
function finalizeCancellation(download) {
	download.status = "cancelled";
	download.error = void 0;
	download.lastUpdate = Date.now();
}
/**
* Record a reconciliation attempt that left a pending cancellation unresolved,
* exposing an unconfirmed but dismissible state once the attempts are
* exhausted. A later WebSocket completion can still replace it, but polling
* stops once the bounded reconciliation window is exhausted.
*/
function noteAuthoritativePendingCancellation(download) {
	if (download.status !== "cancellation_pending") return;
	const attempts = (download.cancellationReconcileAttempts ?? 0) + 1;
	download.cancellationReconcileAttempts = attempts;
	if (attempts >= MAX_CANCELLATION_RECONCILE_ATTEMPTS) {
		download.status = "cancellation_unconfirmed";
		download.lastUpdate = Date.now();
	}
}
function resultValue(value, fallback) {
	return value === void 0 ? fallback : value;
}
function requiredResultValue(value, fallback) {
	return value === void 0 ? fallback : value;
}
function createReconciledDownloadMessage(download, task) {
	const reconciledResult = parseDownloadFileResult(task.result) ?? {};
	const assetId = resultValue(reconciledResult.asset_id, download.assetId);
	const assetName = requiredResultValue(reconciledResult.filename, download.assetName);
	const bytesDownloaded = requiredResultValue(reconciledResult.bytes_downloaded, download.bytesDownloaded);
	const error = resultValue(task.error_message, reconciledResult.error);
	return {
		task_id: download.taskId,
		asset_id: assetId,
		asset_name: assetName,
		bytes_total: download.bytesTotal,
		bytes_downloaded: bytesDownloaded,
		progress: task.status === "completed" ? 100 : download.progress,
		status: task.status,
		error
	};
}
function canCancelDownload(download, isCancelling) {
	if (!download || isCancelling) return false;
	return activeStatuses.has(download.status) || download.status === "failed";
}
function isSettledDownload(download) {
	return download.status === "completed" || download.status === "cancelled" || download.status === "cancellation_unconfirmed";
}
function beginPendingCancellation(download) {
	download.status = "cancellation_pending";
	download.error = void 0;
	download.cancellationReconcileAttempts = 0;
	download.lastUpdate = Date.now();
}
function settleUnknownDownloadStatus(existing, data) {
	if (!existing || isSettledDownload(existing) || existing.status === "cancellation_pending" || existing.status === "failed") return;
	existing.status = "failed";
	existing.error = data.error || `Unknown task status: ${data.status}`;
	existing.lastUpdate = Date.now();
}
var useAssetDownloadStore = defineStore("assetDownload", () => {
	const downloads = ref(/* @__PURE__ */ new Map());
	const cancellingTaskIds = ref(/* @__PURE__ */ new Set());
	const reconcilingTasks = /* @__PURE__ */ new Map();
	const dismissedPendingDownloads = /* @__PURE__ */ new Map();
	const taskNotFoundAttempts = /* @__PURE__ */ new Map();
	const unavailableTaskIds = reactive(/* @__PURE__ */ new Set());
	const failedReconcileAttempts = reactive(/* @__PURE__ */ new Map());
	const settledFailureTaskIds = reactive(/* @__PURE__ */ new Set());
	const lastCompletedDownload = ref(null);
	const downloadList = computed(() => Array.from(downloads.value.values()));
	const activeDownloads = computed(() => downloadList.value.filter((download) => isDownloadActive(download.status)));
	const finishedDownloads = computed(() => downloadList.value.filter((download) => isDownloadFinished(download.status)));
	const unacknowledgedDownloads = computed(() => finishedDownloads.value.filter((d) => d.status === "completed" && d.assetId && !d.acknowledged));
	const sessionDownloadCount = computed(() => unacknowledgedDownloads.value.length);
	const hasActiveDownloads = computed(() => activeDownloads.value.length > 0);
	const hasDownloads = computed(() => downloads.value.size > 0);
	const hasPendingCancellation = computed(() => downloadList.value.some((download) => download.status === "cancellation_pending"));
	const recheckableDownloads = computed(() => downloadList.value.filter((download) => isDownloadRecheckable(download.status) && !unavailableTaskIds.has(download.taskId) && !settledFailureTaskIds.has(download.taskId)));
	const hasRecheckableDownloads = computed(() => recheckableDownloads.value.length > 0);
	function isDownloadedThisSession(assetId) {
		return unacknowledgedDownloads.value.some((d) => d.assetId === assetId);
	}
	function acknowledgeAsset(assetId) {
		for (const download of downloads.value.values()) if (download.assetId === assetId) download.acknowledged = true;
	}
	function trackDownload(taskId, modelType, assetName) {
		if (downloads.value.has(taskId)) return;
		dismissedPendingDownloads.delete(taskId);
		taskNotFoundAttempts.delete(taskId);
		unavailableTaskIds.delete(taskId);
		failedReconcileAttempts.delete(taskId);
		settledFailureTaskIds.delete(taskId);
		downloads.value.set(taskId, generateDownloadTrackingPlaceholder(taskId, modelType, assetName));
	}
	function rememberDismissedDownload(download) {
		dismissedPendingDownloads.delete(download.taskId);
		dismissedPendingDownloads.set(download.taskId, {
			modelType: download.modelType,
			completionNotified: download.status === "completed"
		});
		while (dismissedPendingDownloads.size > MAX_DISMISSED_DOWNLOADS) {
			const oldestTaskId = dismissedPendingDownloads.keys().next().value;
			if (oldestTaskId === void 0) break;
			dismissedPendingDownloads.delete(oldestTaskId);
		}
	}
	function consumeDismissedDownload(data) {
		if (!dismissedPendingDownloads.has(data.task_id)) return false;
		const dismissed = dismissedPendingDownloads.get(data.task_id);
		if (data.status === "completed" && dismissed?.modelType && !dismissed.completionNotified) {
			lastCompletedDownload.value = {
				taskId: data.task_id,
				modelType: dismissed.modelType,
				timestamp: Date.now()
			};
			dismissed.completionNotified = true;
		}
		return true;
	}
	function handleAssetDownload(e) {
		const data = e.detail;
		if (consumeDismissedDownload(data)) return;
		const existing = downloads.value.get(data.task_id);
		if (!wireTaskStatuses.has(data.status)) {
			settleUnknownDownloadStatus(existing, data);
			return;
		}
		if (shouldIgnoreDownloadUpdate(existing?.status, data.status)) return;
		if (activeStatuses.has(data.status)) {
			taskNotFoundAttempts.delete(data.task_id);
			unavailableTaskIds.delete(data.task_id);
			failedReconcileAttempts.delete(data.task_id);
			settledFailureTaskIds.delete(data.task_id);
		}
		const download = {
			taskId: data.task_id,
			assetId: data.asset_id,
			assetName: data.asset_name,
			bytesTotal: data.bytes_total,
			bytesDownloaded: data.bytes_downloaded,
			progress: data.progress,
			status: data.status,
			error: data.error,
			lastUpdate: Date.now(),
			modelType: existing?.modelType
		};
		downloads.value.set(data.task_id, download);
		if (data.status === "completed" && download.modelType) lastCompletedDownload.value = {
			taskId: data.task_id,
			modelType: download.modelType,
			timestamp: Date.now()
		};
	}
	function handleTaskNotFound(download) {
		if (download.status === "cancellation_pending") {
			taskNotFoundAttempts.delete(download.taskId);
			finalizeCancellation(download);
			return;
		}
		const attempts = (taskNotFoundAttempts.get(download.taskId) ?? 0) + 1;
		taskNotFoundAttempts.set(download.taskId, attempts);
		if (attempts < MAX_TASK_NOT_FOUND_ATTEMPTS) {
			download.lastUpdate = Date.now();
			return;
		}
		taskNotFoundAttempts.delete(download.taskId);
		unavailableTaskIds.add(download.taskId);
		download.status = "failed";
		download.error = t("progressToast.taskUnavailable");
		download.lastUpdate = Date.now();
	}
	async function runReconciliation(download) {
		const result = await taskService.getTask(download.taskId);
		if (downloads.value.get(download.taskId) !== download) return;
		if (!result.ok) {
			if (result.error instanceof TaskNotFoundError) handleTaskNotFound(download);
			else taskNotFoundAttempts.delete(download.taskId);
			return;
		}
		taskNotFoundAttempts.delete(download.taskId);
		unavailableTaskIds.delete(download.taskId);
		const task = result.value;
		if (download.status === "cancellation_pending" && activeStatuses.has(task.status)) {
			noteAuthoritativePendingCancellation(download);
			return;
		}
		const message = createReconciledDownloadMessage(download, task);
		if (!message) {
			download.lastUpdate = Date.now();
			noteAuthoritativePendingCancellation(download);
			return;
		}
		if (task.status === "failed") {
			const attempts = (failedReconcileAttempts.get(download.taskId) ?? 0) + 1;
			failedReconcileAttempts.set(download.taskId, attempts);
			if (attempts >= MAX_FAILED_RECONCILE_ATTEMPTS) settledFailureTaskIds.add(download.taskId);
		} else {
			failedReconcileAttempts.delete(download.taskId);
			settledFailureTaskIds.delete(download.taskId);
		}
		handleAssetDownload(new CustomEvent("asset_download", { detail: message }));
	}
	async function reconcileDownload(download, rereadAfterInFlight = false) {
		const inFlight = reconcilingTasks.get(download.taskId);
		if (inFlight) {
			if (!rereadAfterInFlight) return;
			await inFlight;
			const latest = downloads.value.get(download.taskId);
			if (!latest || isSettledDownload(latest)) return;
			download = latest;
		}
		const reconciliation = runReconciliation(download);
		reconcilingTasks.set(download.taskId, reconciliation);
		try {
			await reconciliation;
		} finally {
			if (reconcilingTasks.get(download.taskId) === reconciliation) reconcilingTasks.delete(download.taskId);
		}
	}
	async function pollStaleDownloads() {
		const now = Date.now();
		const staleDownloads = recheckableDownloads.value.filter((d) => now - d.lastUpdate >= STALE_THRESHOLD_MS);
		if (staleDownloads.length === 0) return;
		await Promise.all(staleDownloads.map((download) => reconcileDownload(download)));
	}
	const { pause, resume } = useIntervalFn(() => void pollStaleDownloads(), POLL_INTERVAL_MS, { immediate: false });
	watch(hasRecheckableDownloads, (hasRecheckable) => {
		if (hasRecheckable) resume();
		else pause();
	}, { immediate: true });
	api.addEventListener("asset_download", handleAssetDownload);
	function clearFinishedDownloads() {
		for (const download of finishedDownloads.value) {
			rememberDismissedDownload(download);
			taskNotFoundAttempts.delete(download.taskId);
			unavailableTaskIds.delete(download.taskId);
			failedReconcileAttempts.delete(download.taskId);
			settledFailureTaskIds.delete(download.taskId);
			downloads.value.delete(download.taskId);
		}
	}
	function clearDismissibleDownloads() {
		for (const download of downloadList.value) if (isDownloadFinished(download.status) || download.status === "cancellation_pending") {
			rememberDismissedDownload(download);
			taskNotFoundAttempts.delete(download.taskId);
			unavailableTaskIds.delete(download.taskId);
			failedReconcileAttempts.delete(download.taskId);
			settledFailureTaskIds.delete(download.taskId);
			downloads.value.delete(download.taskId);
		}
	}
	async function cancelDownload(taskId) {
		if (!canCancelDownload(downloads.value.get(taskId), cancellingTaskIds.value.has(taskId))) return {
			ok: true,
			value: false
		};
		cancellingTaskIds.value.add(taskId);
		try {
			const result = await taskService.cancelTask(taskId);
			if (!result.ok) return result;
			const current = downloads.value.get(taskId);
			if (!current) return {
				ok: true,
				value: false
			};
			if (isSettledDownload(current)) return {
				ok: true,
				value: result.value === "cancelling"
			};
			unavailableTaskIds.delete(taskId);
			failedReconcileAttempts.delete(taskId);
			settledFailureTaskIds.delete(taskId);
			if (result.value === "missing") {
				beginPendingCancellation(current);
				await reconcileDownload(current, true);
				const latest = downloads.value.get(taskId);
				if (!latest) return {
					ok: true,
					value: false
				};
				if (latest.status === "cancelled") return {
					ok: true,
					value: true
				};
				return {
					ok: true,
					value: false
				};
			}
			if (result.value === "not-cancellable") {
				await reconcileDownload(current, true);
				return {
					ok: true,
					value: false
				};
			}
			beginPendingCancellation(current);
			return {
				ok: true,
				value: true
			};
		} finally {
			cancellingTaskIds.value.delete(taskId);
		}
	}
	return {
		activeDownloads,
		finishedDownloads,
		hasActiveDownloads,
		hasDownloads,
		hasPendingCancellation,
		downloadList,
		lastCompletedDownload,
		sessionDownloadCount,
		trackDownload,
		cancellingTaskIds,
		cancelDownload,
		clearDismissibleDownloads,
		clearFinishedDownloads,
		isDownloadedThisSession,
		acknowledgeAsset
	};
});
//#endregion
//#region src/stores/assetsStore.ts
/**
* Fetch input files from the internal API (OSS version)
*/
async function fetchInputFilesFromAPI() {
	const response = await fetch(api.internalURL("/files/input"), { headers: { "Comfy-User": api.user } });
	if (!response.ok) throw new Error("Failed to fetch input files");
	return (await response.json()).map((name, index) => mapInputFileToAssetItem(name, index, "input"));
}
/**
* Convert history job items to asset items
*/
function mapHistoryToAssets(historyItems) {
	const assetItems = [];
	for (const job of historyItems) {
		if (job.status !== "completed" || !job.preview_output) continue;
		const task = new TaskItemImpl(job);
		if (!task.previewOutput) continue;
		const assetItem = mapTaskOutputToAssetItem(task, task.previewOutput);
		assetItem.user_metadata = {
			...assetItem.user_metadata,
			outputCount: task.previewableOutputsCount ?? task.outputsCount ?? task.previewableOutputs.length,
			allOutputs: task.previewableOutputs
		};
		assetItems.push(assetItem);
	}
	return assetItems.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
}
var BATCH_SIZE = 200;
var MAX_HISTORY_ITEMS = 1e3;
var MAX_OUTPUT_LOOKUP_PAGES = 20;
var useAssetsStore = defineStore("assets", () => {
	const assetDownloadStore = useAssetDownloadStore();
	const modelToNodeStore = useModelToNodeStore();
	const { flags } = useFeatureFlags();
	const deletingAssetIds = shallowReactive(/* @__PURE__ */ new Set());
	const setAssetDeleting = (assetId, isDeleting) => {
		if (isDeleting) deletingAssetIds.add(assetId);
		else deletingAssetIds.delete(assetId);
	};
	const isAssetDeleting = (assetId) => {
		return deletingAssetIds.has(assetId);
	};
	const { state: rawInputAssets, isLoading: inputLoading, execute: executeUpdateInputs } = useAsyncState(fetchInputFilesFromAPI, [], {
		immediate: false,
		resetOnExecute: false,
		onError: (err) => {
			console.error("Error fetching input assets:", err);
		}
	});
	const historyInputs = {
		hasMore: false,
		invalidate: async () => {
			await executeUpdateInputs();
		},
		isLoading: inputLoading,
		items: rawInputAssets,
		loadMore: async () => false,
		loadNew: async () => void 0
	};
	function useHistoryAssets() {
		const historyOffset = ref(0);
		const hasMoreHistory = ref(true);
		const isLoadingMore = ref(false);
		const allHistoryItems = ref([]);
		const loadedIds = shallowReactive(/* @__PURE__ */ new Set());
		/**
		* Fetch history assets with pagination support
		* @param loadMore - true for pagination (append), false for initial load (replace)
		*/
		const fetchHistoryAssets = async (loadMore = false) => {
			if (!loadMore) {
				historyOffset.value = 0;
				hasMoreHistory.value = true;
				allHistoryItems.value = [];
				loadedIds.clear();
			}
			const history = await api.getHistory(BATCH_SIZE, { offset: historyOffset.value });
			const newAssets = mapHistoryToAssets(history);
			if (loadMore) for (const asset of newAssets) {
				if (loadedIds.has(asset.id)) continue;
				loadedIds.add(asset.id);
				const assetTime = new Date(asset.created_at).getTime();
				const insertIndex = allHistoryItems.value.findIndex((item) => new Date(item.created_at).getTime() < assetTime);
				if (insertIndex === -1) allHistoryItems.value.push(asset);
				else allHistoryItems.value.splice(insertIndex, 0, asset);
			}
			else {
				allHistoryItems.value = newAssets;
				newAssets.forEach((asset) => loadedIds.add(asset.id));
			}
			historyOffset.value += BATCH_SIZE;
			hasMoreHistory.value = history.length === BATCH_SIZE;
			if (allHistoryItems.value.length > MAX_HISTORY_ITEMS) {
				const removed = allHistoryItems.value.slice(MAX_HISTORY_ITEMS);
				allHistoryItems.value = allHistoryItems.value.slice(0, MAX_HISTORY_ITEMS);
				removed.forEach((item) => loadedIds.delete(item.id));
			}
			return allHistoryItems.value;
		};
		const historyAssets = ref([]);
		const historyLoading = ref(false);
		const historyError = ref(null);
		let historyQueue = Promise.resolve();
		let refreshPromise;
		let loadMorePromise;
		/**
		* Initial load of history assets
		*/
		const doUpdateHistory = async () => {
			historyLoading.value = true;
			historyError.value = null;
			try {
				await fetchHistoryAssets(false);
				historyAssets.value = allHistoryItems.value;
			} catch (err) {
				console.error("Error fetching history assets:", err);
				historyError.value = err;
				if (!historyAssets.value.length) historyAssets.value = [];
			} finally {
				historyLoading.value = false;
			}
		};
		const updateHistory = () => {
			if (!refreshPromise) {
				refreshPromise = historyQueue.then(doUpdateHistory).finally(() => {
					refreshPromise = void 0;
				});
				historyQueue = refreshPromise;
			}
			return refreshPromise;
		};
		/**
		* Load more history items (infinite scroll)
		*/
		const doLoadMoreHistory = async () => {
			isLoadingMore.value = true;
			historyError.value = null;
			try {
				await fetchHistoryAssets(true);
				historyAssets.value = allHistoryItems.value;
				return true;
			} catch (err) {
				console.error("Error loading more history:", err);
				historyError.value = err;
				if (!historyAssets.value.length) historyAssets.value = [];
				return false;
			} finally {
				isLoadingMore.value = false;
			}
		};
		const loadMoreHistory = () => {
			if (!loadMorePromise) {
				const operation = historyQueue.then(() => hasMoreHistory.value ? doLoadMoreHistory() : false);
				loadMorePromise = operation.finally(() => {
					loadMorePromise = void 0;
				});
				historyQueue = operation.then(() => void 0);
			}
			return loadMorePromise;
		};
		return {
			hasMore: hasMoreHistory,
			invalidate: updateHistory,
			isLoading: computed(() => historyLoading.value || isLoadingMore.value),
			items: historyAssets,
			loadMore: loadMoreHistory,
			loadNew: updateHistory
		};
	}
	const inputAssets = ref(void 0);
	const outputAssets = ref(void 0);
	let assetsScope;
	watch(() => flags.assetsEnabled, (isAssets) => {
		if (assetsScope) assetsScope.stop();
		assetsScope = void 0;
		if (isAssets) {
			assetsScope = effectScope();
			assetsScope.run(() => {
				inputAssets.value = useAssetsQuery({ tags_any: ["input"] });
				const flatAssets = useAssetsQuery({ tags_any: ["output", "temp"] });
				outputAssets.value = new WrappedList(flatAssets, unflattenOutputAssets);
			});
		} else {
			inputAssets.value = historyInputs;
			outputAssets.value = useHistoryAssets();
		}
	}, { immediate: true });
	async function loadOutputAsset(assetId) {
		const assets = outputAssets.value;
		const hasAsset = () => toValue(assets.items).some(({ id }) => id === assetId);
		let pagesLoaded = 0;
		while (!hasAsset() && toValue(assets.hasMore) && pagesLoaded++ < MAX_OUTPUT_LOOKUP_PAGES) if (!await assets.loadMore()) break;
		return hasAsset();
	}
	useEventListener(api, "assets.seed.completed", async ({ detail }) => {
		if (detail.phase !== "fast") {
			await outputAssets.value.invalidate();
			await inputAssets.value.invalidate();
		} else if (detail.created) {
			await outputAssets.value.loadNew();
			await inputAssets.value.loadNew();
		}
	});
	/**
	* Map of asset hash filename to asset item for O(1) lookup
	* Cloud assets use hash for the hash-based filename
	*/
	const inputAssetsByFilename = computed(() => {
		const map = /* @__PURE__ */ new Map();
		for (const asset of toValue(inputAssets.value.items)) {
			const hash = asset.hash;
			if (hash) map.set(hash, asset);
		}
		return map;
	});
	/**
	* @param filename Hash-based filename (e.g., "72e786ff...efb7.png")
	* @returns Human-readable asset name or original filename if not found
	*/
	function getInputName(filename) {
		return inputAssetsByFilename.value.get(filename)?.name ?? filename;
	}
	const MODEL_BATCH_SIZE = 500;
	const MAX_PAGINATION_BATCHES = 1e3;
	/**
	* Model assets cached by category (e.g., 'checkpoints', 'loras')
	* Multiple node types sharing the same category share the same cache entry.
	* Public API accepts nodeType for backwards compatibility but translates
	* to category internally using modelToNodeStore.getCategoryForNodeType().
	*
	* Runs on every distribution; whether anything fetches through it is
	* decided by consumers via `assetService.isWidgetAssetPickerEnabled()`,
	* which hard-gates widget surfaces to cloud.
	*/
	const getModelState = () => {
		const modelStateByCategory = ref(/* @__PURE__ */ new Map());
		const assetsArrayCache = /* @__PURE__ */ new Map();
		const pendingRequestByCategory = /* @__PURE__ */ new Map();
		const pendingPromiseByCategory = /* @__PURE__ */ new Map();
		const abortByCategory = /* @__PURE__ */ new Map();
		function createState(existingAssets) {
			const assets = new Map(existingAssets);
			return reactive({
				assets,
				offset: 0,
				nextCursor: void 0,
				hasMore: true,
				isLoading: true
			});
		}
		function isStale(category, state) {
			const committed = modelStateByCategory.value.get(category);
			const pending = pendingRequestByCategory.get(category);
			return committed !== state && pending !== state;
		}
		const EMPTY_ASSETS = [];
		/**
		* Resolve a key to a category. Handles both nodeType and tag:xxx formats.
		* @param key Either a nodeType (e.g., 'CheckpointLoaderSimple') or tag key (e.g., 'tag:models')
		* @returns The category or undefined if not resolvable
		*/
		function resolveCategory(key) {
			if (key.startsWith("tag:")) return key;
			return modelToNodeStore.getCategoryForNodeType(key);
		}
		/**
		* Get assets by nodeType or tag key.
		* Translates nodeType to category internally for cache lookup.
		* @param key Either a nodeType (e.g., 'CheckpointLoaderSimple') or tag key (e.g., 'tag:models')
		*/
		function getAssets(key) {
			const category = resolveCategory(key);
			if (!category) return EMPTY_ASSETS;
			const assetsMap = modelStateByCategory.value.get(category)?.assets;
			if (!assetsMap) return EMPTY_ASSETS;
			const cached = assetsArrayCache.get(category);
			if (cached && cached.source === assetsMap) return cached.array;
			const array = Array.from(assetsMap.values());
			assetsArrayCache.set(category, {
				source: assetsMap,
				array
			});
			return array;
		}
		function isLoading(key) {
			const category = resolveCategory(key);
			if (!category) return false;
			return modelStateByCategory.value.get(category)?.isLoading ?? false;
		}
		function getError(key) {
			const category = resolveCategory(key);
			if (!category) return void 0;
			return modelStateByCategory.value.get(category)?.error;
		}
		function hasMore(key) {
			const category = resolveCategory(key);
			if (!category) return false;
			return modelStateByCategory.value.get(category)?.hasMore ?? false;
		}
		function hasAssetKey(key) {
			const category = resolveCategory(key);
			if (!category) return false;
			return modelStateByCategory.value.has(category);
		}
		/**
		* Check if a category exists in the cache.
		* Checks both direct category keys and tag-prefixed keys.
		* @param category The category to check (e.g., 'checkpoints', 'loras')
		*/
		function hasCategory(category) {
			return modelStateByCategory.value.has(category) || modelStateByCategory.value.has(`tag:${category}`);
		}
		/**
		* Internal helper to fetch and cache assets for a category.
		* Loads first batch immediately, then progressively loads remaining batches.
		* Keeps existing data visible until new data is successfully fetched.
		*
		* Concurrent calls for the same category are short-circuited: if a request
		* is already in progress (tracked via pendingRequestByCategory), subsequent
		* calls return immediately to avoid redundant work.
		*/
		async function updateModelsForCategory(category, fetcher) {
			if (pendingPromiseByCategory.has(category)) return pendingPromiseByCategory.get(category);
			const state = createState(modelStateByCategory.value.get(category)?.assets);
			abortByCategory.get(category)?.abort();
			const controller = new AbortController();
			abortByCategory.set(category, controller);
			const seenIds = /* @__PURE__ */ new Set();
			const hasExistingData = modelStateByCategory.value.has(category);
			if (hasExistingData) pendingRequestByCategory.set(category, state);
			else {
				pendingRequestByCategory.set(category, state);
				modelStateByCategory.value.set(category, state);
			}
			async function loadBatches() {
				let isFirstBatch = true;
				let walkCompleted = false;
				const seenCursors = /* @__PURE__ */ new Set();
				let batchCount = 0;
				while (state.hasMore) {
					if (batchCount++ >= MAX_PAGINATION_BATCHES) {
						state.hasMore = false;
						break;
					}
					try {
						const after = state.nextCursor;
						const response = await fetcher(after !== void 0 ? {
							limit: MODEL_BATCH_SIZE,
							after,
							signal: controller.signal
						} : {
							limit: MODEL_BATCH_SIZE,
							offset: state.offset,
							signal: controller.signal
						});
						if (isStale(category, state)) return;
						const newAssets = response.assets;
						if (isFirstBatch) {
							assetsArrayCache.delete(category);
							if (hasExistingData) {
								pendingRequestByCategory.delete(category);
								modelStateByCategory.value.set(category, state);
							}
						}
						for (const asset of newAssets) {
							seenIds.add(asset.id);
							state.assets.set(asset.id, asset);
						}
						state.assets = new Map(state.assets);
						state.offset += newAssets.length;
						if (!response.has_more) {
							state.hasMore = false;
							walkCompleted = true;
						} else if (newAssets.length === 0) state.hasMore = false;
						else if (response.next_cursor !== void 0) {
							if (seenCursors.has(response.next_cursor)) state.hasMore = false;
							else {
								seenCursors.add(response.next_cursor);
								state.nextCursor = response.next_cursor;
							}
						} else {
							state.nextCursor = void 0;
							if (newAssets.length < MODEL_BATCH_SIZE) {
								state.hasMore = false;
								walkCompleted = true;
							}
						}
						if (isFirstBatch) {
							state.isLoading = false;
							isFirstBatch = false;
						}
						if (state.hasMore) await delay(50, { signal: controller.signal });
					} catch (err) {
						if (controller.signal.aborted) {
							if (isFirstBatch) state.isLoading = false;
							return;
						}
						if (isStale(category, state)) return;
						console.error(`Error loading batch for ${category}:`, err);
						state.error = err instanceof Error ? err : new Error(String(err));
						state.hasMore = false;
						state.isLoading = false;
						const committed = modelStateByCategory.value.get(category);
						if (committed && committed !== state) committed.error = state.error;
						if (pendingRequestByCategory.get(category) === state) pendingRequestByCategory.delete(category);
						return;
					}
				}
				if (walkCompleted) {
					const staleIds = [...state.assets.keys()].filter((id) => !seenIds.has(id));
					for (const id of staleIds) state.assets.delete(id);
				}
				assetsArrayCache.delete(category);
				if (pendingRequestByCategory.get(category) === state) pendingRequestByCategory.delete(category);
			}
			const promise = loadBatches();
			pendingPromiseByCategory.set(category, promise);
			try {
				await promise;
			} finally {
				if (pendingPromiseByCategory.get(category) === promise) pendingPromiseByCategory.delete(category);
				if (abortByCategory.get(category) === controller) abortByCategory.delete(category);
			}
		}
		/**
		* Fetch and cache model assets for a specific node type.
		* Translates nodeType to category internally - multiple node types
		* sharing the same category will share the same cache entry.
		* @param nodeType The node type to fetch assets for (e.g., 'CheckpointLoaderSimple')
		*/
		async function updateModelsForNodeType(nodeType) {
			const category = modelToNodeStore.getCategoryForNodeType(nodeType);
			if (!category) return;
			await updateModelsForCategory(category, (opts) => assetService.getAssetsPageForNodeType(nodeType, opts));
		}
		/**
		* Fetch and cache model assets for a specific tag
		* @param tag The tag to fetch assets for (e.g., 'models')
		*/
		async function updateModelsForTag(tag) {
			await updateModelsForCategory(`tag:${tag}`, (opts) => assetService.getAssetsPageByTag(tag, true, opts));
		}
		/**
		* Invalidate the cache for a specific category.
		* Forces a refetch on next access.
		* @param category The category to invalidate (e.g., 'checkpoints', 'loras')
		*/
		function invalidateCategory(category) {
			abortByCategory.get(category)?.abort();
			abortByCategory.delete(category);
			modelStateByCategory.value.delete(category);
			assetsArrayCache.delete(category);
			pendingRequestByCategory.delete(category);
			pendingPromiseByCategory.delete(category);
		}
		/**
		* Optimistically update an asset in the cache
		* @param assetId The asset ID to update
		* @param updates Partial asset data to merge
		* @param cacheKey Optional cache key to target (nodeType or 'tag:xxx')
		*/
		function updateAssetInCache(assetId, updates, cacheKey) {
			const category = cacheKey ? resolveCategory(cacheKey) : void 0;
			if (cacheKey && !category) return;
			const categoriesToCheck = category ? [category] : Array.from(modelStateByCategory.value.keys());
			for (const cat of categoriesToCheck) {
				const state = modelStateByCategory.value.get(cat);
				if (!state?.assets) continue;
				const existingAsset = state.assets.get(assetId);
				if (existingAsset) {
					const updatedAsset = {
						...existingAsset,
						...updates
					};
					state.assets.set(assetId, updatedAsset);
					assetsArrayCache.delete(cat);
					if (cacheKey) return;
				}
			}
		}
		/**
		* Update asset metadata with optimistic cache update
		* @param asset The asset to update
		* @param userMetadata The user_metadata to save
		* @param cacheKey Optional cache key to target for optimistic update
		*/
		async function updateAssetMetadata(asset, userMetadata, cacheKey) {
			const originalMetadata = asset.user_metadata;
			updateAssetInCache(asset.id, { user_metadata: userMetadata }, cacheKey);
			try {
				const updatedAsset = await assetService.updateAsset(asset.id, { user_metadata: userMetadata });
				updateAssetInCache(asset.id, updatedAsset, cacheKey);
			} catch (error) {
				console.error("Failed to update asset metadata:", error);
				updateAssetInCache(asset.id, { user_metadata: originalMetadata }, cacheKey);
			}
		}
		/**
		* Update asset tags using add/remove endpoints
		* @param asset The asset to update (used to read current tags)
		* @param newTags The desired tags array
		* @param cacheKey Optional cache key to target for optimistic update
		*/
		async function updateAssetTags(asset, newTags, cacheKey) {
			const originalTags = asset.tags;
			const tagsToAdd = difference(newTags, originalTags);
			const tagsToRemove = difference(originalTags, newTags);
			if (tagsToAdd.length === 0 && tagsToRemove.length === 0) return;
			updateAssetInCache(asset.id, { tags: newTags }, cacheKey);
			let removedTagsOnServer = [];
			try {
				let removeResult;
				if (tagsToRemove.length > 0) {
					removeResult = await assetService.removeAssetTags(asset.id, tagsToRemove);
					removedTagsOnServer = removeResult.removed ?? tagsToRemove;
				}
				const finalTags = ((tagsToAdd.length > 0 ? await assetService.addAssetTags(asset.id, tagsToAdd) : void 0) ?? removeResult)?.total_tags;
				if (finalTags) updateAssetInCache(asset.id, { tags: finalTags }, cacheKey);
			} catch (error) {
				console.error("Failed to update asset tags:", error);
				updateAssetInCache(asset.id, { tags: originalTags }, cacheKey);
				if (removedTagsOnServer.length > 0) try {
					await assetService.addAssetTags(asset.id, removedTagsOnServer);
				} catch (compensationError) {
					console.error("Failed to restore tags after partial failure; invalidating cache to force refetch:", compensationError);
					const categoriesToInvalidate = /* @__PURE__ */ new Set();
					const resolved = cacheKey ? resolveCategory(cacheKey) : void 0;
					if (resolved) categoriesToInvalidate.add(resolved);
					for (const [category, state] of modelStateByCategory.value.entries()) if (state.assets.has(asset.id)) categoriesToInvalidate.add(category);
					for (const category of categoriesToInvalidate) invalidateCategory(category);
				}
			}
		}
		/**
		* Invalidate model caches for a given category (e.g., 'checkpoints', 'loras')
		* Clears the category cache and tag-based caches so next access triggers refetch
		* @param category The model category to invalidate (e.g., 'checkpoints')
		*/
		function invalidateModelsForCategory(category) {
			invalidateCategory(category);
			invalidateCategory(`tag:${category}`);
			invalidateCategory("tag:models");
		}
		return {
			getAssets,
			isLoading,
			getError,
			hasMore,
			hasAssetKey,
			hasCategory,
			updateModelsForNodeType,
			updateModelsForTag,
			invalidateCategory,
			updateAssetMetadata,
			updateAssetTags,
			invalidateModelsForCategory
		};
	};
	const { getAssets, isLoading: isModelLoading, getError, hasMore, hasAssetKey, hasCategory, updateModelsForNodeType, updateModelsForTag, invalidateCategory, updateAssetMetadata, updateAssetTags, invalidateModelsForCategory } = getModelState();
	whenever(() => assetDownloadStore.lastCompletedDownload, async (latestDownload) => {
		const { modelType } = latestDownload;
		const nodeTypeUpdates = modelToNodeStore.getAllNodeProviders(modelType).filter((provider) => provider.nodeDef.name).map((provider) => updateModelsForNodeType(provider.nodeDef.name).then(() => provider.nodeDef.name));
		const tagUpdates = [updateModelsForTag(modelType), updateModelsForTag("models")];
		const results = await Promise.allSettled([...nodeTypeUpdates, ...tagUpdates]);
		for (const result of results) if (result.status === "rejected") console.error(`Failed to refresh model cache for provider: ${result.reason}`);
	});
	return {
		inputAssets,
		outputAssets,
		invalidateAll,
		loadOutputAsset,
		deletingAssetIds,
		setAssetDeleting,
		isAssetDeleting,
		inputAssetsByFilename,
		getInputName,
		getAssets,
		isModelLoading,
		getError,
		hasMore,
		hasAssetKey,
		hasCategory,
		updateModelsForNodeType,
		updateModelsForTag,
		invalidateCategory,
		updateAssetMetadata,
		updateAssetTags,
		invalidateModelsForCategory
	};
});
//#endregion
export { takeDeploymentSwitchLanding as A, MISSING_TAG as C, matchesWidgetName as D, useModelToNodeStore as E, assetResponseSchema as F, readDeploymentHint as M, assetFilenameSchema as N, useDeploymentPickStore as O, assetItemSchema as P, getOutputAssetMetadata as S, assetService as T, parseNodeOutput as _, taskService as a, usePreemptableQueue as b, useQueueUIStore as c, getJobAssets as d, getJobDetail as f, provideExtensionService as g, getPreviewableOutputsFromJobDetail as h, TaskNotFoundError as i, hasDeploymentLink as j, reloadForDeploymentSwitch as k, findActiveIndex as l, getOutputsForTask as m, isDownloadCancelled as n, useQueuePendingTaskCountStore as o, getJobWorkflow as p, useAssetDownloadStore as r, useQueueStore as s, useAssetsStore as t, getJobApiPrompt as u, encodeParams as v, MODELS_TAG as w, getAssetType as x, WrappedList as y };
