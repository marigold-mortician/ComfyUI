import "./rolldown-runtime-xtsTai4I.js";
import { $ as mergeModels, B as createSlots, E as withModifiers, F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, I as createBlock, Jt as normalizeStyle, Kt as normalizeClass, O as Fragment, P as computed, R as createElementBlock, U as createVNode, Wt as unref, Yt as toDisplayString, _t as useModel, bt as watch, ct as openBlock, dt as renderSlot, et as mergeProps, ut as renderList, wt as withCtx, yt as useTemplateRef, z as createPropsRestProxy } from "./vendor-vue-core-CuN1excl.js";
import { $t as ComboboxEmpty_default, B as SelectPortal_default, F as SelectViewport_default, G as SelectContent_default, Gn as unrefElement, H as SelectItemIndicator_default, I as SelectValue_default, Jt as ComboboxTrigger_default, K as SelectRoot_default, L as SelectTrigger_default, Qt as ComboboxInput_default, U as SelectItem_default, V as SelectItemText_default, Xt as ComboboxItemIndicator_default, Yt as ComboboxPortal_default, Zt as ComboboxItem_default, en as ComboboxContent_default, nn as ComboboxRoot_default, qt as ComboboxViewport_default, tn as ComboboxAnchor_default, wn as FocusScope_default } from "./vendor-reka-ui-NRTk7aIV.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { n as useAttrsClass, r as useSelectSearch, t as usePopoverSizing } from "./usePopoverSizing-ux16dO36.js";
import { a as selectItemVariants, i as selectEmptyMessageClass, o as selectTriggerVariants, r as selectDropdownClass, s as stopEscapeToDocument, t as selectContentClass } from "./select.variants-BBeExFA3.js";
//#region src/components/ui/single-select/SearchableSingleSelect.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$1 = {
	key: 0,
	class: "icon-[lucide--loader-circle] shrink-0 animate-spin text-muted-foreground"
};
var _hoisted_2 = { class: "truncate" };
var _hoisted_3 = { class: "px-2 pt-2" };
var _hoisted_4 = { class: "flex items-center gap-2 rounded-lg border px-3 py-1.5" };
var _hoisted_5 = { class: "truncate" };
//#endregion
//#region src/components/ui/single-select/SearchableSingleSelect.vue
var SearchableSingleSelect_default = /* @__PURE__ */ defineComponent({
	inheritAttrs: false,
	__name: "SearchableSingleSelect",
	props: /*@__PURE__*/ mergeModels({
		label: {},
		accessibleLabel: {},
		searchLabel: {},
		emptyText: {},
		options: { default: () => [] },
		size: { default: "lg" },
		invalid: {
			type: Boolean,
			default: false
		},
		loading: {
			type: Boolean,
			default: false
		},
		disabled: {
			type: Boolean,
			default: false
		},
		searchPlaceholder: {},
		listMaxHeight: { default: "28rem" },
		popoverMinWidth: {},
		popoverMaxWidth: {},
		contentStyle: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	}, {
		"modelValue": { required: true },
		"modelModifiers": {}
	}),
	emits: ["update:modelValue"],
	setup(__props) {
		const { attrsClass, attrsWithoutClass } = useAttrsClass();
		const selectedItem = useModel(__props, "modelValue");
		const triggerRef = useTemplateRef("trigger");
		const isOpen = ref(false);
		const searchQuery = ref("");
		const filteredOptions = useSelectSearch(searchQuery, () => __props.options);
		const selectedOption = computed({
			get: () => __props.options.find(({ value }) => value === selectedItem.value),
			set: (option) => {
				selectedItem.value = option?.value;
			}
		});
		watch(isOpen, (open) => {
			if (!open) searchQuery.value = "";
		});
		function onContentKeydown(event) {
			if (event.key === "Tab") {
				unrefElement(triggerRef)?.focus();
				isOpen.value = false;
				return;
			}
			if (event.key === "Escape") {
				stopEscapeToDocument(event);
				isOpen.value = false;
			}
		}
		const optionStyle = usePopoverSizing({
			minWidth: __props.popoverMinWidth,
			maxWidth: __props.popoverMaxWidth
		});
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(ComboboxRoot_default), {
				modelValue: selectedOption.value,
				"onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => selectedOption.value = $event),
				open: isOpen.value,
				"onUpdate:open": _cache[4] || (_cache[4] = ($event) => isOpen.value = $event),
				by: "value",
				disabled: __props.disabled,
				"ignore-filter": ""
			}, {
				default: withCtx(() => [createVNode(unref(ComboboxAnchor_default), { "as-child": "" }, {
					default: withCtx(() => [createVNode(unref(ComboboxTrigger_default), mergeProps({ ref: "trigger" }, unref(attrsWithoutClass), {
						tabindex: "0",
						"aria-label": __props.accessibleLabel,
						"aria-busy": __props.loading || void 0,
						"aria-invalid": __props.invalid || void 0,
						class: unref(cn)(unref(selectTriggerVariants)({
							size: __props.size,
							border: __props.invalid ? "invalid" : "none"
						}), unref(attrsClass))
					}), {
						default: withCtx(() => [createBaseVNode("div", { class: normalizeClass(unref(cn)("flex flex-1 items-center gap-2 overflow-hidden py-2 pl-2", __props.size === "md" ? "text-xs" : "text-sm")) }, [__props.loading ? (openBlock(), createElementBlock("i", _hoisted_1$1)) : renderSlot(_ctx.$slots, "icon", {}, void 0, void 0, 1), createBaseVNode("span", _hoisted_2, toDisplayString(selectedOption.value?.name ?? __props.label), 1)], 2), createBaseVNode("div", { class: normalizeClass(unref(selectDropdownClass)) }, [..._cache[5] || (_cache[5] = [createBaseVNode("i", { class: "icon-[lucide--chevron-down] text-muted-foreground" }, null, -1)])], 2)]),
						_: 3
					}, 16, [
						"aria-label",
						"aria-busy",
						"aria-invalid",
						"class"
					])]),
					_: 3
				}), (openBlock(), createBlock(unref(ComboboxPortal_default), { key: Number(isOpen.value) }, {
					default: withCtx(() => [createVNode(unref(ComboboxContent_default), {
						position: "popper",
						"side-offset": 8,
						align: "start",
						style: normalizeStyle([unref(optionStyle), __props.contentStyle]),
						class: normalizeClass(unref(cn)(unref(selectContentClass), "min-w-(--reka-combobox-trigger-width)")),
						onKeydown: onContentKeydown
					}, {
						default: withCtx(() => [createVNode(unref(FocusScope_default), {
							class: "contents",
							onMountAutoFocus: _cache[1] || (_cache[1] = withModifiers(() => {}, ["prevent"])),
							onUnmountAutoFocus: _cache[2] || (_cache[2] = withModifiers(() => {}, ["prevent"]))
						}, {
							default: withCtx(() => [createBaseVNode("div", _hoisted_3, [createBaseVNode("div", _hoisted_4, [_cache[6] || (_cache[6] = createBaseVNode("i", { class: "icon-[lucide--search] text-muted-foreground" }, null, -1)), createVNode(unref(ComboboxInput_default), {
								modelValue: searchQuery.value,
								"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => searchQuery.value = $event),
								"aria-label": __props.searchLabel,
								placeholder: __props.searchPlaceholder,
								class: "w-full border-none bg-transparent text-sm outline-none"
							}, null, 8, [
								"modelValue",
								"aria-label",
								"placeholder"
							])])]), createVNode(unref(ComboboxViewport_default), {
								style: normalizeStyle({ maxHeight: `min(${__props.listMaxHeight}, 50vh)` }),
								class: "scrollbar-custom w-full"
							}, {
								default: withCtx(() => [(openBlock(true), createElementBlock(Fragment, null, renderList(unref(filteredOptions), (opt) => {
									return openBlock(), createBlock(unref(ComboboxItem_default), {
										key: opt.value,
										value: opt,
										class: normalizeClass(unref(selectItemVariants)({ layout: "single" }))
									}, {
										default: withCtx(() => [createBaseVNode("span", _hoisted_5, toDisplayString(opt.name), 1), createVNode(unref(ComboboxItemIndicator_default), { class: "flex shrink-0 items-center justify-center" }, {
											default: withCtx(() => [..._cache[7] || (_cache[7] = [createBaseVNode("i", {
												class: "icon-[lucide--check] text-foreground",
												"aria-hidden": "true"
											}, null, -1)])]),
											_: 1
										})]),
										_: 2
									}, 1032, ["value", "class"]);
								}), 128)), createVNode(unref(ComboboxEmpty_default), { class: normalizeClass(unref(selectEmptyMessageClass)) }, {
									default: withCtx(() => [createTextVNode(toDisplayString(__props.emptyText), 1)]),
									_: 1
								}, 8, ["class"])]),
								_: 1
							}, 8, ["style"])]),
							_: 1
						})]),
						_: 1
					}, 8, ["style", "class"])]),
					_: 1
				}))]),
				_: 3
			}, 8, [
				"modelValue",
				"open",
				"disabled"
			]);
		};
	}
});
//#endregion
//#region src/components/ui/single-select/SingleSelect.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = {
	key: 0,
	class: "icon-[lucide--loader-circle] shrink-0 animate-spin text-muted-foreground"
};
//#endregion
//#region src/components/ui/single-select/SingleSelect.vue
var SingleSelect_default = /* @__PURE__ */ defineComponent({
	inheritAttrs: false,
	__name: "SingleSelect",
	props: /*@__PURE__*/ mergeModels({
		label: {},
		accessibleLabel: {},
		options: { default: () => [] },
		size: { default: "lg" },
		invalid: {
			type: Boolean,
			default: false
		},
		loading: {
			type: Boolean,
			default: false
		},
		disabled: {
			type: Boolean,
			default: false
		},
		searchPlaceholder: {},
		listMaxHeight: { default: "28rem" },
		popoverMinWidth: {},
		popoverMaxWidth: {},
		contentStyle: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] },
		searchable: {
			type: Boolean,
			default: false
		},
		searchLabel: {},
		emptyText: {}
	}, {
		"modelValue": { required: true },
		"modelModifiers": {}
	}),
	emits: ["update:modelValue"],
	setup(__props) {
		const { attrsClass, attrsWithoutClass } = useAttrsClass();
		const selectedItem = useModel(__props, "modelValue");
		const isOpen = ref(false);
		function onContentKeydown(event) {
			if (event.key === "Escape") {
				stopEscapeToDocument(event);
				isOpen.value = false;
			}
		}
		const optionStyle = usePopoverSizing({
			minWidth: __props.popoverMinWidth,
			maxWidth: __props.popoverMaxWidth
		});
		return (_ctx, _cache) => {
			return __props.searchable && __props.searchLabel !== void 0 && __props.emptyText !== void 0 ? (openBlock(), createBlock(SearchableSingleSelect_default, mergeProps({
				key: 0,
				modelValue: selectedItem.value,
				"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => selectedItem.value = $event)
			}, unref(attrsWithoutClass), {
				class: unref(attrsClass),
				label: __props.label,
				"accessible-label": __props.accessibleLabel,
				"search-label": __props.searchLabel,
				"empty-text": __props.emptyText,
				options: __props.options,
				size: __props.size,
				invalid: __props.invalid,
				loading: __props.loading,
				disabled: __props.disabled,
				"search-placeholder": __props.searchPlaceholder,
				"list-max-height": __props.listMaxHeight,
				"popover-min-width": __props.popoverMinWidth,
				"popover-max-width": __props.popoverMaxWidth,
				"content-style": __props.contentStyle
			}), {
				icon: withCtx(() => [renderSlot(_ctx.$slots, "icon")]),
				_: 3
			}, 16, [
				"modelValue",
				"class",
				"label",
				"accessible-label",
				"search-label",
				"empty-text",
				"options",
				"size",
				"invalid",
				"loading",
				"disabled",
				"search-placeholder",
				"list-max-height",
				"popover-min-width",
				"popover-max-width",
				"content-style"
			])) : (openBlock(), createBlock(unref(SelectRoot_default), {
				key: 1,
				modelValue: selectedItem.value,
				"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => selectedItem.value = $event),
				open: isOpen.value,
				"onUpdate:open": _cache[2] || (_cache[2] = ($event) => isOpen.value = $event),
				disabled: __props.disabled
			}, {
				default: withCtx(() => [createVNode(unref(SelectTrigger_default), mergeProps(unref(attrsWithoutClass), {
					"aria-label": __props.accessibleLabel,
					"aria-busy": __props.loading || void 0,
					"aria-invalid": __props.invalid || void 0,
					class: unref(cn)(unref(selectTriggerVariants)({
						size: __props.size,
						border: __props.invalid ? "invalid" : "none"
					}), unref(attrsClass))
				}), {
					default: withCtx(() => [createBaseVNode("div", { class: normalizeClass(unref(cn)("flex flex-1 items-center gap-2 overflow-hidden py-2 pl-2", __props.size === "md" ? "text-xs" : "text-sm")) }, [__props.loading ? (openBlock(), createElementBlock("i", _hoisted_1)) : renderSlot(_ctx.$slots, "icon", {}, void 0, void 0, 1), createVNode(unref(SelectValue_default), {
						placeholder: __props.label,
						class: "truncate"
					}, null, 8, ["placeholder"])], 2), createBaseVNode("div", { class: normalizeClass(unref(selectDropdownClass)) }, [..._cache[3] || (_cache[3] = [createBaseVNode("i", { class: "icon-[lucide--chevron-down] text-muted-foreground" }, null, -1)])], 2)]),
					_: 3
				}, 16, [
					"aria-label",
					"aria-busy",
					"aria-invalid",
					"class"
				]), createVNode(unref(SelectPortal_default), null, {
					default: withCtx(() => [createVNode(unref(SelectContent_default), {
						position: "popper",
						"side-offset": 8,
						align: "start",
						style: normalizeStyle([unref(optionStyle), __props.contentStyle]),
						class: normalizeClass(unref(cn)(unref(selectContentClass), "min-w-(--reka-select-trigger-width)")),
						onKeydown: onContentKeydown
					}, {
						default: withCtx(() => [createVNode(unref(SelectViewport_default), {
							style: normalizeStyle({ maxHeight: `min(${__props.listMaxHeight}, 50vh)` }),
							class: "scrollbar-custom w-full"
						}, {
							default: withCtx(() => [(openBlock(true), createElementBlock(Fragment, null, renderList(__props.options, (opt) => {
								return openBlock(), createBlock(unref(SelectItem_default), {
									key: opt.value,
									value: opt.value,
									class: normalizeClass(unref(selectItemVariants)({ layout: "single" }))
								}, {
									default: withCtx(() => [createVNode(unref(SelectItemText_default), { class: "truncate" }, {
										default: withCtx(() => [createTextVNode(toDisplayString(opt.name), 1)]),
										_: 2
									}, 1024), createVNode(unref(SelectItemIndicator_default), { class: "flex shrink-0 items-center justify-center" }, {
										default: withCtx(() => [..._cache[4] || (_cache[4] = [createBaseVNode("i", {
											class: "icon-[lucide--check] text-foreground",
											"aria-hidden": "true"
										}, null, -1)])]),
										_: 1
									})]),
									_: 2
								}, 1032, ["value", "class"]);
							}), 128))]),
							_: 1
						}, 8, ["style"])]),
						_: 1
					}, 8, ["style", "class"])]),
					_: 1
				})]),
				_: 3
			}, 8, [
				"modelValue",
				"open",
				"disabled"
			]));
		};
	}
});
//#endregion
//#region src/components/common/AppSingleSelect.vue
var AppSingleSelect_default = /* @__PURE__ */ defineComponent({
	__name: "AppSingleSelect",
	props: /*@__PURE__*/ mergeModels({
		label: {},
		options: {},
		size: {},
		invalid: { type: Boolean },
		loading: { type: Boolean },
		disabled: { type: Boolean },
		searchPlaceholder: {},
		listMaxHeight: {},
		popoverMinWidth: {},
		popoverMaxWidth: {},
		contentStyle: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] },
		searchable: { type: Boolean },
		accessibleLabel: {},
		searchLabel: {},
		emptyText: {}
	}, {
		"modelValue": { required: true },
		"modelModifiers": {}
	}),
	emits: ["update:modelValue"],
	setup(__props) {
		const restProps = createPropsRestProxy(__props, [
			"label",
			"accessibleLabel",
			"searchLabel",
			"searchPlaceholder",
			"emptyText"
		]);
		const selectedItem = useModel(__props, "modelValue");
		const { t } = useI18n();
		return (_ctx, _cache) => {
			return openBlock(), createBlock(SingleSelect_default, mergeProps(restProps, {
				modelValue: selectedItem.value,
				"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => selectedItem.value = $event),
				label: __props.label,
				"accessible-label": __props.accessibleLabel ?? (__props.label || unref(t)("g.singleSelectDropdown")),
				"search-label": __props.searchLabel ?? unref(t)("g.search"),
				"search-placeholder": __props.searchPlaceholder ?? unref(t)("g.search"),
				"empty-text": __props.emptyText ?? unref(t)("g.noResultsFound")
			}), createSlots({ _: 2 }, [_ctx.$slots.icon ? {
				name: "icon",
				fn: withCtx(() => [renderSlot(_ctx.$slots, "icon")]),
				key: "0"
			} : void 0]), 1040, [
				"modelValue",
				"label",
				"accessible-label",
				"search-label",
				"search-placeholder",
				"empty-text"
			]);
		};
	}
});
//#endregion
export { AppSingleSelect_default as t };
