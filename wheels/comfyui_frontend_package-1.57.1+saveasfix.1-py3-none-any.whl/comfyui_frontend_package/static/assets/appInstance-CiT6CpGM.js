import "./rolldown-runtime-xtsTai4I.js";
import { N as isTypedArray$1 } from "./cloneDeep-BX7AjX4w.js";
import { t as assert } from "./assert--qJvwrYk.js";
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isTypedArray.mjs
/**
* Checks if a value is a TypedArray.
* @param x The value to check.
* @returns Returns true if `x` is a TypedArray, false otherwise.
*
* @example
* const arr = new Uint8Array([1, 2, 3]);
* isTypedArray(arr); // true
*
* const regularArray = [1, 2, 3];
* isTypedArray(regularArray); // false
*
* const buffer = new ArrayBuffer(16);
* isTypedArray(buffer); // false
*/
function isTypedArray(x) {
	return isTypedArray$1(x);
}
//#endregion
//#region src/scripts/appRegistry.ts
var instance;
/**
* Called once by `@/scripts/app` after it constructs the singleton. Modules
* that the app imports cannot import `@/scripts/app` back without a cycle, so
* they reach the instance through `useApp` from `@/scripts/appInstance`.
*/
function registerApp(app) {
	instance = app;
}
function useApp() {
	assert(instance, "ComfyApp accessed before registerApp");
	return instance;
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.appRegistry = window.comfyAPI.appRegistry || {};
window.comfyAPI.appRegistry.registerApp = registerApp;
window.comfyAPI.appRegistry.useApp = useApp;
//#endregion
export { useApp as n, isTypedArray as r, registerApp as t };
