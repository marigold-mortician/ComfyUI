import "./rolldown-runtime-xtsTai4I.js";
//#region packages/mask-editor/src/brushUtils.ts
/**
* Calculates the effective brush size based on the base size and hardness.
* As hardness decreases, the effective size increases to allow for a softer falloff.
*
* @param size - The base radius of the brush
* @param hardness - The hardness of the brush (0.0 to 1.0)
* @returns The effective radius of the brush
*/
function getEffectiveBrushSize(size, hardness) {
	return size * (1 + (1 - hardness) * .5);
}
/**
* Calculates the effective hardness to maintain the visual "hard core" of the brush.
* Since the effective size is larger, we need to adjust the hardness value so that
* the inner hard circle remains at the same physical radius as the original size * hardness.
*
* @param size - The base radius of the brush
* @param hardness - The base hardness of the brush
* @param effectiveSize - The effective radius (calculated by getEffectiveBrushSize)
* @returns The adjusted hardness value (0.0 to 1.0)
*/
function getEffectiveHardness(size, hardness, effectiveSize) {
	if (effectiveSize <= 0) return 0;
	return size * hardness / effectiveSize;
}
//#endregion
//#region packages/mask-editor/src/splineUtils.ts
/**
* Evaluates a Catmull-Rom spline at parameter t between p1 and p2
* @param p0 Previous control point
* @param p1 Start point of the curve segment
* @param p2 End point of the curve segment
* @param p3 Next control point
* @param t Parameter in range [0, 1]
* @returns Interpolated point on the curve
*/
function catmullRomSpline(p0, p1, p2, p3, t) {
	const alpha = .5;
	const getT = (t, p0, p1) => {
		const d = Math.hypot(p1.x - p0.x, p1.y - p0.y);
		return t + Math.pow(d, alpha);
	};
	const t0 = 0;
	const t1 = getT(t0, p0, p1);
	const t2 = getT(t1, p1, p2);
	const t3 = getT(t2, p2, p3);
	const tInterp = t1 + (t2 - t1) * t;
	const interp = (pA, pB, tA, tB, t) => {
		if (Math.abs(tB - tA) < 1e-4) return pA;
		const k = (t - tA) / (tB - tA);
		return add(mul(pA, 1 - k), mul(pB, k));
	};
	const A1 = interp(p0, p1, t0, t1, tInterp);
	const A2 = interp(p1, p2, t1, t2, tInterp);
	const A3 = interp(p2, p3, t2, t3, tInterp);
	return interp(interp(A1, A2, t0, t2, tInterp), interp(A2, A3, t1, t3, tInterp), t1, t2, tInterp);
}
function add(p1, p2) {
	return {
		x: p1.x + p2.x,
		y: p1.y + p2.y
	};
}
function mul(p, s) {
	return {
		x: p.x * s,
		y: p.y * s
	};
}
/**
* Resamples a curve segment with a starting offset (remainder from previous segment).
* Returns the resampled points and the new remainder distance.
*
* @param points Points defining the curve segment
* @param spacing Desired spacing between points
* @param startOffset Distance to travel before placing the first point (remainder)
* @returns Object containing points and new remainder
*/
function resampleSegment(points, spacing, startOffset) {
	if (points.length === 0) return {
		points: [],
		remainder: startOffset
	};
	const result = [];
	let currentDist = 0;
	let nextSampleDist = startOffset;
	for (let i = 0; i < points.length - 1; i++) {
		const p1 = points[i];
		const p2 = points[i + 1];
		const dx = p2.x - p1.x;
		const dy = p2.y - p1.y;
		const segmentLen = Math.hypot(dx, dy);
		if (segmentLen < 1e-4) {
			while (nextSampleDist <= currentDist) {
				result.push(p1);
				nextSampleDist += spacing;
			}
			continue;
		}
		while (nextSampleDist <= currentDist + segmentLen) {
			const t = (nextSampleDist - currentDist) / segmentLen;
			const x = p1.x + t * dx;
			const y = p1.y + t * dy;
			result.push({
				x,
				y
			});
			nextSampleDist += spacing;
		}
		currentDist += segmentLen;
	}
	return {
		points: result,
		remainder: nextSampleDist - currentDist
	};
}
//#endregion
//#region packages/mask-editor/src/StrokeProcessor.ts
var StrokeProcessor = class {
	controlPoints = [];
	remainder = 0;
	spacing;
	isFirstPoint = true;
	hasProcessedSegment = false;
	constructor(spacing) {
		this.spacing = spacing;
	}
	/**
	* Adds a point to the stroke and returns any new equidistant points generated.
	* Maintain a sliding window of 4 control points for spline generation
	*/
	addPoint(point) {
		if (this.isFirstPoint) {
			this.controlPoints.push(point);
			this.controlPoints.push(point);
			this.isFirstPoint = false;
			return [];
		}
		this.controlPoints.push(point);
		if (this.controlPoints.length < 4) return [];
		const p0 = this.controlPoints[0];
		const p1 = this.controlPoints[1];
		const p2 = this.controlPoints[2];
		const p3 = this.controlPoints[3];
		const newPoints = this.processSegment(p0, p1, p2, p3);
		this.controlPoints.shift();
		return newPoints;
	}
	/**
	* End stroke and flush remaining segments
	*/
	endStroke() {
		if (this.controlPoints.length < 2) return [];
		const newPoints = [];
		while (this.controlPoints.length >= 3) {
			const p0 = this.controlPoints[0];
			const p1 = this.controlPoints[1];
			const p2 = this.controlPoints[2];
			const p3 = p2;
			const points = this.processSegment(p0, p1, p2, p3);
			newPoints.push(...points);
			this.controlPoints.shift();
		}
		if (!this.hasProcessedSegment && this.controlPoints.length >= 2) {
			const p = this.controlPoints[1];
			const points = this.processSegment(p, p, p, p);
			newPoints.push(...points);
		}
		return newPoints;
	}
	processSegment(p0, p1, p2, p3) {
		this.hasProcessedSegment = true;
		const densePoints = [];
		const dist = Math.hypot(p2.x - p1.x, p2.y - p1.y);
		const samples = Math.max(5, Math.ceil(dist));
		for (let i = 0; i < samples; i++) {
			const t = i / samples;
			densePoints.push(catmullRomSpline(p0, p1, p2, p3, t));
		}
		densePoints.push(p2);
		const { points, remainder } = resampleSegment(densePoints, this.spacing, this.remainder);
		this.remainder = remainder;
		return points;
	}
};
//#endregion
export { getEffectiveHardness as i, resampleSegment as n, getEffectiveBrushSize as r, StrokeProcessor as t };
