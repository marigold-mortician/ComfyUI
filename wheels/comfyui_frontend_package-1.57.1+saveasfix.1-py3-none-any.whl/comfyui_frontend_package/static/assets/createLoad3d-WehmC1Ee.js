import { t as createLoad3d } from "./createLoad3d-DVjBd0bL.js";
export { createLoad3d };
