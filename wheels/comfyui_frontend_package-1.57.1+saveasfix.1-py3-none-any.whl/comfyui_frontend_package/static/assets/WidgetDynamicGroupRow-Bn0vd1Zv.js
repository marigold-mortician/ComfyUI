import "./rolldown-runtime-xtsTai4I.js";
import { F as createBaseVNode, G as defineComponent, R as createElementBlock, U as createVNode, Wt as unref, Yt as toDisplayString, ct as openBlock, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
//#region src/renderer/extensions/vueNodes/widgets/components/WidgetDynamicGroupRow.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "flex items-center gap-2" };
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/components/WidgetDynamicGroupRow.vue
var WidgetDynamicGroupRow_default = /* @__PURE__ */ defineComponent({
	__name: "WidgetDynamicGroupRow",
	props: { widget: {} },
	emits: ["removed"],
	setup(__props, { emit: __emit }) {
		const { t } = useI18n();
		const emit = __emit;
		function removeRow() {
			const name = __props.widget.name;
			__props.widget.callback?.(void 0);
			emit("removed", name);
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1, [
				_cache[1] || (_cache[1] = createBaseVNode("span", { class: "h-px flex-1 bg-border" }, null, -1)),
				createBaseVNode("span", null, toDisplayString(__props.widget.label), 1),
				createVNode(Button_default, {
					variant: "textonly",
					size: "icon",
					class: "size-6",
					disabled: __props.widget.options?.disabled,
					"aria-label": unref(t)("dynamicGroup.remove", { row: __props.widget.label }),
					onClick: removeRow
				}, {
					default: withCtx(() => [..._cache[0] || (_cache[0] = [createBaseVNode("i", { class: "icon-[lucide--x] size-4" }, null, -1)])]),
					_: 1
				}, 8, ["disabled", "aria-label"])
			]);
		};
	}
});
//#endregion
export { WidgetDynamicGroupRow_default as default };
