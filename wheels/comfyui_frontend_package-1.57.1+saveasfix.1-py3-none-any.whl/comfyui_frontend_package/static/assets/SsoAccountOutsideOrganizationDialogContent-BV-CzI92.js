import "./rolldown-runtime-xtsTai4I.js";
import { F as createBaseVNode, G as defineComponent, H as createTextVNode, I as createBlock, U as createVNode, Wt as unref, Yt as toDisplayString, ct as openBlock, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
import { t as ACCOUNT_OUTSIDE_ORGANIZATION_DIALOG_KEY } from "./ssoRequiredDialogKey-DRv9w9ql.js";
import { t as AppDialogPanel_default } from "./AppDialogPanel-BklaJBTn.js";
//#region src/platform/auth/sso/SsoAccountOutsideOrganizationDialogContent.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "m-0 p-4 text-sm text-muted-foreground" };
//#endregion
//#region src/platform/auth/sso/SsoAccountOutsideOrganizationDialogContent.vue
var SsoAccountOutsideOrganizationDialogContent_default = /* @__PURE__ */ defineComponent({
	__name: "SsoAccountOutsideOrganizationDialogContent",
	setup(__props) {
		const { t } = useI18n();
		const dialogStore = useDialogStore();
		function dismiss() {
			dialogStore.closeDialog({ key: ACCOUNT_OUTSIDE_ORGANIZATION_DIALOG_KEY });
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(AppDialogPanel_default, {
				unpadded: "",
				onClose: dismiss
			}, {
				title: withCtx(() => [createTextVNode(toDisplayString(unref(t)("auth.sso.outsideOrganization.title")), 1)]),
				footer: withCtx(() => [createVNode(Button_default, {
					variant: "secondary",
					size: "lg",
					autofocus: "",
					onClick: dismiss
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(unref(t)("g.close")), 1)]),
					_: 1
				})]),
				default: withCtx(() => [createBaseVNode("p", _hoisted_1, toDisplayString(unref(t)("auth.sso.outsideOrganization.body")), 1)]),
				_: 1
			});
		};
	}
});
//#endregion
export { SsoAccountOutsideOrganizationDialogContent_default as default };
