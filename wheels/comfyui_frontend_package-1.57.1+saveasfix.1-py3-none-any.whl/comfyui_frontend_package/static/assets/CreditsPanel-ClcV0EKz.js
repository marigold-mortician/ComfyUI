import { t as CreditsPanel_default } from "./CreditsPanel-BId6Jwkl.js";
export { CreditsPanel_default as default };
