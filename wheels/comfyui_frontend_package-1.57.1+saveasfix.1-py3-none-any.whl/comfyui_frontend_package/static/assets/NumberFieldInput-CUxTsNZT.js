import "./rolldown-runtime-xtsTai4I.js";
import { G as defineComponent, I as createBlock, Kt as normalizeClass, Wt as unref, ct as openBlock, dt as renderSlot, et as mergeProps, q as guardReactiveProps, qt as normalizeProps, wt as withCtx, z as createPropsRestProxy } from "./vendor-vue-core-CuN1excl.js";
import { Nn as useForwardProps, at as NumberFieldRoot_default, nt as NumberFieldInput_default$1 } from "./vendor-reka-ui-NRTk7aIV.js";
import { t as cn } from "./src-BHQtMnZc.js";
//#endregion
//#region src/components/ui/number-field/NumberField.vue
var NumberField_default = /* @__PURE__ */ defineComponent({
	__name: "NumberField",
	props: {
		defaultValue: {},
		modelValue: {},
		min: {},
		max: {},
		step: {},
		stepSnapping: {
			type: Boolean,
			default: false
		},
		allowInvalid: { type: Boolean },
		focusOnChange: { type: Boolean },
		formatOptions: {},
		locale: {},
		disabled: { type: Boolean },
		readonly: { type: Boolean },
		disableWheelChange: {
			type: Boolean,
			default: true
		},
		invertWheelChange: { type: Boolean },
		id: {},
		startingValue: {},
		asChild: { type: Boolean },
		as: {},
		name: {},
		required: { type: Boolean },
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	},
	emits: ["update:modelValue"],
	setup(__props, { emit: __emit }) {
		const restProps = createPropsRestProxy(__props, [
			"class",
			"stepSnapping",
			"disableWheelChange"
		]);
		const emits = __emit;
		const forwarded = useForwardProps(restProps);
		function updateModelValue(value) {
			if (value === void 0 || value === restProps.modelValue) return;
			emits("update:modelValue", value);
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(NumberFieldRoot_default), mergeProps(unref(forwarded), {
				"data-slot": "number-field",
				"step-snapping": __props.stepSnapping,
				"disable-wheel-change": __props.disableWheelChange,
				class: unref(cn)("flex h-10 w-full items-center rounded-lg bg-secondary text-foreground focus-within:ring-1 focus-within:ring-ring hover:bg-accent data-disabled:pointer-events-none data-disabled:opacity-50", __props.class),
				"onUpdate:modelValue": updateModelValue
			}), {
				default: withCtx((slotProps) => [renderSlot(_ctx.$slots, "default", normalizeProps(guardReactiveProps(slotProps)))]),
				_: 3
			}, 16, [
				"step-snapping",
				"disable-wheel-change",
				"class"
			]);
		};
	}
});
//#endregion
//#region src/components/ui/number-field/NumberFieldInput.vue
var NumberFieldInput_default = /* @__PURE__ */ defineComponent({
	__name: "NumberFieldInput",
	props: { class: { type: [
		Boolean,
		null,
		String,
		Object,
		Array
	] } },
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(NumberFieldInput_default$1), {
				"data-slot": "number-field-input",
				class: normalizeClass(unref(cn)("min-w-0 flex-1 border-none bg-transparent text-center text-base focus-visible:outline-none", __props.class))
			}, null, 8, ["class"]);
		};
	}
});
//#endregion
export { NumberField_default as n, NumberFieldInput_default as t };
