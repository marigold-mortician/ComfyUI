import "./rolldown-runtime-xtsTai4I.js";
import { J as scopeMediaRoute, O as webSessionRequests, i as api, q as isMediaRoute } from "./api-BdJmXw98.js";
import { F as isResultItemType } from "./graphTraversalUtil-BUK1cr2m.js";
import { t as useFeatureFlags } from "./useFeatureFlags-B3zg5FdZ.js";
import { S as getOutputAssetMetadata, T as assetService, t as useAssetsStore } from "./assetsStore-CNmOJwRQ.js";
//#region src/platform/assets/utils/assetTypeUtil.ts
/**
* Extract asset type from an asset's tags array
* Falls back to a default type if tags are not present
*
* @param asset The asset to extract type from
* @param defaultType Default type to use if tags are empty (default: 'output')
* @returns The asset type ('input', 'output', 'temp', etc.)
*
* @example
* getAssetType(asset) // Returns 'output' or first tag
* getAssetType(asset, 'input') // Returns 'input' if no tags
*/
function getAssetType(asset, defaultType = "output") {
	return new URLSearchParams((asset.preview_url ?? "").split("?")[1] ?? "").get("type") || asset.tags[0] || defaultType;
}
//#endregion
//#region src/platform/assets/utils/assetUrlUtil.ts
/**
* Utilities for constructing asset URLs
*/
/**
* Get the download/view URL for an asset
* Constructs the proper URL with filename encoding, type, and subfolder parameters
*
* @param asset The asset to get URL for
* @param defaultType Default type if asset doesn't have tags (default: 'output')
* @returns Full URL for viewing/downloading the asset
*
* @example
* const url = getAssetUrl(asset)
* downloadFile(url, asset.name)
*/
function getAssetUrl(asset, defaultType = "output") {
	const assetType = getAssetType(asset, defaultType);
	const subfolder = getAssetSubfolder(asset);
	const params = new URLSearchParams();
	params.set("filename", asset.name);
	params.set("type", assetType);
	if (subfolder) params.set("subfolder", subfolder);
	return api.apiURL(`/view?${params}`);
}
/** `/view` URL of the asset's own file, not its preview. */
function getAssetViewUrl(asset) {
	const root = asset.tags.find(isResultItemType);
	if (!asset.loader_path || !root) return getAssetUrl(asset);
	const slash = asset.loader_path.lastIndexOf("/");
	const params = new URLSearchParams({
		filename: asset.loader_path.slice(slash + 1),
		type: root
	});
	if (slash > 0) params.set("subfolder", asset.loader_path.slice(0, slash));
	return api.apiURL(`/view?${params}`);
}
/**
* Get the subfolder an asset lives in, relative to its type root
*
* Reads `preview_url` first and falls back to `user_metadata`, mirroring how
* {@link getAssetType} resolves the type.
*
* @param asset The asset to get the subfolder for
* @returns The subfolder, or an empty string when the asset is at the root
*/
function getAssetSubfolder(asset) {
	const previewSubfolder = new URLSearchParams((asset.preview_url ?? "").split("?")[1] ?? "").get("subfolder");
	if (previewSubfolder) return previewSubfolder;
	const { subfolder } = asset.user_metadata ?? {};
	return typeof subfolder === "string" ? subfolder : "";
}
/**
* Id of the assets-API asset holding this item's own file. A card grouped per
* job carries the job id as its `id` and keeps its own asset id in metadata.
*/
function getAssetContentId(asset) {
	return getOutputAssetMetadata(asset.user_metadata)?.assetId || asset.id;
}
/**
* URL of the asset's own file, for downloading or loading it whole.
*
* With the assets API enabled the file is served by id, so no path inference
* is needed and a preview that is only a thumbnail is never mistaken for the
* file. Otherwise the item came from the history API, whose `preview_url`
* already points at the file, with a `/view` URL as fallback.
*
* `disposition: 'inline'` asks the assets-API content endpoint to serve the
* file for in-page rendering (e.g. a `<video>` source) instead of its
* default `attachment` disposition, which browsers try to save rather than
* play. It has no effect on the history-backed fallback, whose `/view`
* endpoint has no such distinction.
*/
function getAssetFileUrl(asset, options) {
	if (useFeatureFlags().flags.assetsEnabled) {
		const query = options?.disposition ? `?disposition=${options.disposition}` : "";
		return api.apiURL(`/assets/${getAssetContentId(asset)}/content${query}`);
	}
	return asset.preview_url || getAssetUrl(asset);
}
/**
* URL for loading the asset's own video or audio file into a `<video>` or
* `<audio>` `src`, which sends cookies but no headers.
*
* On Cloud, a cookie-authenticated `/assets/:id/content` request is looked up
* in the session's default workspace only, so it 404s for an asset that lives
* in another workspace. `/view` looks across the user's workspaces, so an
* asset with a content hash is loaded through `/view?filename=<hash>`, the same
* way image previews are. Without a hash (or off Cloud) this falls back to
* {@link getAssetFileUrl} with an inline disposition.
*
* @param asset The asset whose file should be played
* @returns The URL to set as the media element's `src`
*/
function getAssetInlineMediaUrl(asset) {
	return getAssetFileUrl(asset, { disposition: "inline" });
}
/**
* Prepares a server-supplied media URL (e.g. `thumbnail_url`/`preview_url`)
* for an `<img>`, `<video>` or `<audio>` `src`, which sends cookies but no
* headers.
*
* Root-relative media routes go through `api.apiURL` so a web session names
* its workspace on them, as do absolute URLs on this page's own origin. Any
* other URL is returned as is: other-origin and signed external URLs, `blob:`
* and `data:` URLs, protocol-relative URLs and non-media routes.
*
* @param url The URL the server supplied, if any
* @returns The URL to load, or an empty string when there is none
*/
function resolveMediaSrc(url) {
	if (!url) return "";
	if (url.startsWith("//")) return url;
	if (url.startsWith("/")) return isMediaRoute(url) ? api.apiURL(url) : url;
	return scopeSameOriginMediaUrl(url);
}
function scopeSameOriginMediaUrl(url) {
	const requests = webSessionRequests();
	if (!requests || !/^https?:\/\//i.test(url)) return url;
	try {
		const parsed = new URL(url);
		if (parsed.origin !== window.location.origin) return url;
		const route = `${parsed.pathname}${parsed.search}${parsed.hash}`;
		const scoped = scopeMediaRoute(route, requests.workspaceId());
		return scoped === route ? url : `${parsed.origin}${scoped}`;
	} catch {
		return url;
	}
}
//#endregion
//#region src/platform/assets/utils/assetPreviewUtil.ts
/**
* Whether the backend can serve asset preview/thumbnail data.
*/
function isAssetPreviewSupported() {
	return useFeatureFlags().flags.assetsEnabled;
}
async function fetchAssets(params) {
	const query = new URLSearchParams(params);
	const res = await api.fetchApi(`/assets?${query}`);
	if (!res.ok) return [];
	return (await res.json()).assets ?? [];
}
function resolvePreviewUrl(asset) {
	if (asset.preview_url) return api.apiURL(asset.preview_url);
	const contentId = asset.preview_id ?? getAssetContentId(asset);
	return api.apiURL(`/assets/${contentId}/content`);
}
/**
* Find an output asset record by content hash, falling back to name.
* On cloud, output filenames are content-hashed; use hash to match.
* On local, filenames are not hashed; use name_contains to match.
*/
async function findOutputAsset(name) {
	const hashMatch = (await fetchAssets({ hash: name })).find((a) => a.hash === name);
	if (hashMatch) return hashMatch;
	return (await fetchAssets({ name_contains: name })).find((a) => a.name === name);
}
async function findServerPreviewUrl(name) {
	try {
		const asset = await findOutputAsset(name);
		if (!asset?.preview_id) return null;
		return resolvePreviewUrl(asset);
	} catch {
		return null;
	}
}
async function persistThumbnail(name, blob) {
	try {
		const asset = await findOutputAsset(name);
		if (!asset || asset.preview_id) return;
		const previewFilename = `${asset.name}_preview.png`;
		const uploaded = await assetService.uploadAssetFromBase64({
			data: await blobToDataUrl(blob),
			name: previewFilename,
			tags: ["output"],
			user_metadata: { filename: previewFilename }
		});
		await assetService.updateAsset(asset.id, { preview_id: uploaded.id });
		await useAssetsStore().outputAssets.invalidate();
	} catch {}
}
function blobToDataUrl(blob) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => resolve(reader.result);
		reader.onerror = reject;
		reader.readAsDataURL(blob);
	});
}
//#endregion
export { resolvePreviewUrl as a, getAssetSubfolder as c, resolveMediaSrc as d, getAssetType as f, persistThumbnail as i, getAssetUrl as l, findServerPreviewUrl as n, getAssetFileUrl as o, isAssetPreviewSupported as r, getAssetInlineMediaUrl as s, findOutputAsset as t, getAssetViewUrl as u };
