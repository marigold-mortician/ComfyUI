import { t as WidgetLegacy_default } from "./WidgetLegacy-DPUgO3-4.js";
export { WidgetLegacy_default as default };
