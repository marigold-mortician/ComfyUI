import "./rolldown-runtime-xtsTai4I.js";
import { E as withModifiers, F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, I as createBlock, Jt as normalizeStyle, Kt as normalizeClass, L as createCommentVNode, P as computed, R as createElementBlock, U as createVNode, Wt as unref, Yt as toDisplayString, ct as openBlock, wt as withCtx, yt as useTemplateRef } from "./vendor-vue-core-CuN1excl.js";
import { Tt as PopoverTrigger_default, jt as PopoverRoot_default } from "./vendor-reka-ui-NRTk7aIV.js";
import { a as TooltipTrigger_default, o as TooltipContent_default, s as Tooltip_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { t as PopoverContent_default } from "./PopoverContent-CJioRepA.js";
//#region src/components/topbar/TopbarBadge.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = ["aria-label"];
var _hoisted_2 = { class: "font-inter text-sm" };
var _hoisted_3 = {
	key: 1,
	class: "text-xs"
};
var labelClasses = "shrink-0 rounded-full border border-border px-2 py-0.5 text-xs text-muted-foreground";
//#endregion
//#region src/components/topbar/TopbarBadge.vue
var TopbarBadge_default = /* @__PURE__ */ defineComponent({
	__name: "TopbarBadge",
	props: {
		badge: {},
		displayMode: { default: "full" },
		reverseOrder: { type: Boolean },
		noPadding: { type: Boolean },
		backgroundColor: { default: "var(--background)" }
	},
	setup(__props) {
		const popoverOpen = ref(false);
		const badgeContent = useTemplateRef("badgeContent");
		const variant = computed(() => __props.badge.variant ?? "info");
		const menuBackgroundStyle = computed(() => ({ backgroundColor: __props.backgroundColor }));
		const showLabel = computed(() => {
			if (!__props.badge.label) return false;
			const needle = __props.badge.label.toLowerCase();
			return !__props.badge.text.toLowerCase().split(/\s+/).some((word) => word.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}]+$/gu, "").startsWith(needle));
		});
		const triggerShowsLabel = computed(() => Boolean(__props.displayMode === "compact" ? showLabel.value : __props.badge.label && !iconClass.value));
		const textClasses = computed(() => {
			switch (variant.value) {
				case "error": return "text-destructive";
				case "warning": return "text-warning";
				default: return "text-foreground";
			}
		});
		const iconClass = computed(() => {
			if (__props.badge.icon) return __props.badge.icon;
			switch (variant.value) {
				case "error": return "pi pi-exclamation-circle";
				case "warning": return "icon-[lucide--triangle-alert]";
				default: return;
			}
		});
		const badgeIconClass = computed(() => cn("size-4 shrink-0 text-base", iconClass.value, textClasses.value));
		const dotClasses = computed(() => {
			switch (variant.value) {
				case "error": return "bg-destructive";
				case "warning": return "bg-warning";
				default: return "bg-muted-foreground";
			}
		});
		return (_ctx, _cache) => {
			return __props.displayMode !== "full" ? (openBlock(), createBlock(unref(PopoverRoot_default), {
				key: 0,
				open: popoverOpen.value,
				"onUpdate:open": _cache[1] || (_cache[1] = ($event) => popoverOpen.value = $event)
			}, {
				default: withCtx(() => [createVNode(unref(PopoverTrigger_default), { "as-child": "" }, {
					default: withCtx(() => [createBaseVNode("button", {
						type: "button",
						"aria-label": triggerShowsLabel.value ? void 0 : __props.badge.text,
						class: normalizeClass(unref(cn)("relative flex h-full shrink-0 cursor-pointer items-center border-0 bg-transparent transition-opacity hover:opacity-80", __props.displayMode === "icon-only" ? "justify-center px-2" : "gap-2 whitespace-nowrap", __props.displayMode === "compact" && __props.reverseOrder && "flex-row-reverse", __props.displayMode === "compact" && !__props.noPadding && "px-3")),
						style: normalizeStyle(menuBackgroundStyle.value)
					}, [iconClass.value ? (openBlock(), createElementBlock("i", {
						key: 0,
						"data-testid": "badge-icon",
						"aria-hidden": "true",
						class: normalizeClass(badgeIconClass.value)
					}, null, 2)) : createCommentVNode("", true), triggerShowsLabel.value ? (openBlock(), createElementBlock("div", {
						key: 1,
						class: normalizeClass(labelClasses)
					}, toDisplayString(__props.badge.label), 1)) : !iconClass.value ? (openBlock(), createElementBlock("div", {
						key: 2,
						"data-testid": "badge-dot",
						class: normalizeClass(["size-2 shrink-0 rounded-full", dotClasses.value])
					}, null, 2)) : createCommentVNode("", true)], 14, _hoisted_1)]),
					_: 1
				}), createVNode(PopoverContent_default, {
					align: "start",
					class: "w-auto max-w-xs min-w-40 p-3",
					onOpenAutoFocus: _cache[0] || (_cache[0] = withModifiers(($event) => badgeContent.value?.focus(), ["prevent"]))
				}, {
					default: withCtx(() => [createBaseVNode("div", {
						ref_key: "badgeContent",
						ref: badgeContent,
						tabindex: "-1",
						class: "flex flex-col gap-2 outline-none"
					}, [
						showLabel.value ? (openBlock(), createElementBlock("div", {
							key: 0,
							class: normalizeClass(unref(cn)(labelClasses, "w-fit"))
						}, toDisplayString(__props.badge.label), 3)) : createCommentVNode("", true),
						createBaseVNode("div", _hoisted_2, toDisplayString(__props.badge.text), 1),
						__props.badge.tooltip ? (openBlock(), createElementBlock("div", _hoisted_3, toDisplayString(__props.badge.tooltip), 1)) : createCommentVNode("", true)
					], 512)]),
					_: 1
				})]),
				_: 1
			}, 8, ["open"])) : (openBlock(), createBlock(Tooltip_default, {
				key: 1,
				disabled: !__props.badge.tooltip
			}, {
				default: withCtx(() => [createVNode(TooltipTrigger_default, { "as-child": "" }, {
					default: withCtx(() => [createBaseVNode("div", {
						class: normalizeClass(unref(cn)("flex h-full shrink-0 items-center gap-1 whitespace-nowrap", __props.reverseOrder && "flex-row-reverse", !__props.noPadding && "px-2")),
						style: normalizeStyle(menuBackgroundStyle.value)
					}, [
						iconClass.value ? (openBlock(), createElementBlock("i", {
							key: 0,
							"data-testid": "badge-icon",
							"aria-hidden": "true",
							class: normalizeClass(badgeIconClass.value)
						}, null, 2)) : createCommentVNode("", true),
						createBaseVNode("div", { class: normalizeClass(["font-inter text-xs font-medium", textClasses.value]) }, toDisplayString(__props.badge.text), 3),
						showLabel.value ? (openBlock(), createElementBlock("div", {
							key: 1,
							class: normalizeClass(labelClasses)
						}, toDisplayString(__props.badge.label), 1)) : createCommentVNode("", true)
					], 6)]),
					_: 1
				}), createVNode(TooltipContent_default, null, {
					default: withCtx(() => [createTextVNode(toDisplayString(__props.badge.tooltip), 1)]),
					_: 1
				})]),
				_: 1
			}, 8, ["disabled"]));
		};
	}
});
//#endregion
export { TopbarBadge_default as t };
