import "./rolldown-runtime-xtsTai4I.js";
import { D as union, O as unknown, S as object, T as string, b as never, d as custom, f as discriminatedUnion, l as array, v as literal, x as number } from "./vendor-zod-Del_rmdp.js";
import { C as zAgentTurnAccepted$1, Pt as zWorkflowListResponse, S as zAgentToolCallData$1, a as zAgentAskResolvedData, d as zAgentMessage$1, f as zAgentPendingAskBase, i as zAgentAskKind, kt as zToolCallSummary, l as zAgentError$1, n as zAgentAnswerAccepted, o as zAgentAttachmentRejected, t as zAgentAdmissionError, u as zAgentIdentity$1, v as zAgentRunMode$1, x as zAgentThreadListResponse } from "./zod.gen-DzuaBm8H.js";
import { G as isNodeLocatorId } from "./graphTraversalUtil-BUK1cr2m.js";
//#region src/workbench/extensions/agent/schemas/agentApiSchema.ts
/**
* The 202 from the answer route. A backend that predates the committed-answer
* body sends only `status`, so `selected` is optional here.
*/
var zAgentAnswerReceipt = zAgentAnswerAccepted.partial({ selected: true });
var zTurnId = string().brand();
var toTurnId = (value) => zTurnId.parse(value);
var zAgentTurnAccepted = zAgentTurnAccepted$1.extend({ workflow_id: string().optional() }).passthrough();
var RENDERED_ASK_KINDS = [
	"run_approval",
	"ask_user",
	"delete_approval"
];
var zTolerantPendingAsk = zAgentPendingAskBase.extend({
	kind: zAgentAskKind.or(literal("unknown")).catch("unknown"),
	context: unknown().optional()
});
var zAgentRunMode = zAgentRunMode$1.superRefine(({ mode, credit_limit }, ctx) => {
	if (mode === "auto_limited" && (credit_limit === null || !Number.isInteger(credit_limit) || credit_limit <= 0)) ctx.addIssue({
		code: "custom",
		path: ["credit_limit"],
		message: "auto_limited requires a positive credit limit"
	});
	if (mode !== "auto_limited" && credit_limit !== null) ctx.addIssue({
		code: "custom",
		path: ["credit_limit"],
		message: "credit limit is only valid for auto_limited"
	});
});
var SKILL_NAME_MAX = 256;
/**
* Display-only, so an over-long name is clamped. Rejecting it would drop
* the live frame or the whole persisted transcript.
*/
var zSkillName = string().transform((skill) => Array.from(skill).slice(0, SKILL_NAME_MAX).join("")).nullish();
/**
* One entry of a persisted assistant row's `content.tool_calls` (see
* `agentTranscript.ts`'s `parseToolCallEntry`), the reload-path counterpart
* to the live WebSocket's `zAgentToolCallData` above. Sourced from the
* generated `ToolCallSummary` schema (Comfy-Org/cloud#10360), but relaxed:
* the generated schema requires `tool_call_id`, narrows `status` to the
* closed `'success' | 'error'` wire vocabulary, and requires `duration_ms`
* to be an integer, which is only true for rows persisted after that
* backend change landed. Real historical rows can still carry a bare `id`
* with no `tool_call_id`, a `status` of `'ok'` (an older success alias —
* see `toolCallOk` in `agentTranscript.ts`), or a non-finite/negative
* `duration_ms`. `parseToolCallEntry` picks only the fields it actually
* reads from this, so an unrelated field (e.g. a strict
* `started_at`/`finished_at` datetime) never gates the entry.
*/
var zPersistedToolCallSummary = zToolCallSummary.extend({
	id: string(),
	tool_call_id: string().nullish(),
	status: string().nullish(),
	duration_ms: custom((val) => typeof val === "number" && !Number.isNaN(val)).nullish(),
	skill: zSkillName
});
/**
* One persisted `content.thinking` entry: a model round's thinking text,
* anchored to that round's first tool call when it made one.
*/
var zPersistedThinkingEntry = object({
	text: string(),
	tool_call_id: string().nullish()
});
/**
* The message-parse boundary's `content.tool_calls` field is deliberately
* `z.array(z.unknown())`, not the stricter `zPersistedToolCallSummary`
* above: `agentRestClient.ts`'s `request()` calls `.parse()` (throws) on
* the whole `AgentMessages` array, so a single non-conforming historical
* tool-call row must never fail the entire conversation-history load.
* `agentTranscript.ts`'s `parseToolCallEntry` runs its own `safeParse`
* per entry and degrades just that one row instead.
*
* The generated `AgentMessage.content` schema also keeps a
* `[key: string]: unknown` index signature on its TS type but no matching
* `.passthrough()` on its zod schema — the `.passthrough()` below re-widens
* it so a persisted row's other `content` fields (`text`, `attachments`,
* `attachment_refs`, `workflow_references`, ...; see `agentTranscript.ts`)
* keep parsing.
*/
var zAgentMessageContent = object({ tool_calls: unknown().optional() }).passthrough();
var zAgentMessage = zAgentMessage$1.extend({
	content: zAgentMessageContent.optional(),
	pending_ask: zTolerantPendingAsk.optional()
}).passthrough();
var zAgentMessages = array(zAgentMessage);
var zAgentThreads = zAgentThreadListResponse.passthrough();
var zCloudWorkflowIndex = zWorkflowListResponse.pick({ pagination: true }).extend({ data: array(object({
	id: string(),
	name: string().optional()
}).passthrough()) });
var zAgentError = union([zAgentError$1, zAgentAdmissionError]);
var zAttachmentRejection = zAgentAttachmentRejected.pick({
	rejected: true,
	rejected_count: true,
	type: true
});
/**
* The 403 body the agent service returns when it will not serve the turn's
* `workflow_id` to the caller's workspace, whether the row is gone or belongs
* elsewhere. The message is the only discriminator on the wire: a 403 refusing
* the thread or the message carries the same shape with a different subject.
*/
var zDisownedWorkflowError = object({ error: literal("workflow not found or access denied") });
/**
* The 409 body the agent service returns when the thread already has a turn in
* progress (`rejectTurnInProgress` in `services/agent/server/agent_handler.go`).
* `type` is the discriminator — a 409 from the cancel or answer endpoints
* carries no `type` at all — and the two ids name the turn that holds the
* thread, so the client can re-attach to it instead of reporting a dead end.
*
* Both ids are optional on the wire: the server resolves them best-effort and
* documents that a lookup failure "still yields the 409, just without the id".
* A conflict with no ids is still a conflict, so the discriminator alone has to
* be enough to recognise one.
*/
var zTurnInProgressError = object({
	type: literal("TURN_IN_PROGRESS"),
	active_message_id: string().optional(),
	turn_id: string().optional()
}).passthrough();
var zAgentThinkingData = object({
	delta: string(),
	message_id: string(),
	thread_id: string()
}).passthrough();
var zAgentToolCallData = zAgentToolCallData$1.extend({
	skill: zSkillName,
	args: never().optional(),
	workflow_id: zAgentToolCallData$1.shape.workflow_id.catch(void 0),
	op_ids: zAgentToolCallData$1.shape.op_ids.catch(void 0),
	doc_seq: zAgentToolCallData$1.shape.doc_seq.catch(void 0),
	doc_lineage_seq: zAgentToolCallData$1.shape.doc_lineage_seq.catch(void 0),
	job_id: string().min(1).max(128).refine((value) => !value.includes("\0") && !value.includes("\n") && !value.includes("\r") && !value.includes("	")).optional().catch(void 0),
	job_workflow_id: string().min(1).optional().catch(void 0)
}).passthrough();
var zAgentMessageDeltaData = object({
	delta: string(),
	message_id: string(),
	thread_id: string()
}).passthrough();
var zAgentMessageDraftData = object({
	text: string(),
	message_id: string(),
	thread_id: string()
}).passthrough();
var zAgentUsage = object({
	input_tokens: number().nullish(),
	output_tokens: number().nullish(),
	total_tokens: number().nullish(),
	cache_read_input_tokens: number().nullish(),
	cache_creation_input_tokens: number().nullish()
}).passthrough();
var zAgentMessageDoneData = object({
	message_id: string(),
	thread_id: string(),
	usage: zAgentUsage.nullish().catch(void 0)
}).passthrough();
var zAgentActiveTabData = object({
	workflow_id: string(),
	node_locator_id: string().max(256).refine((value) => isNodeLocatorId(value)).optional(),
	name: string().optional(),
	thread_id: string().optional(),
	message_id: string().optional()
}).passthrough();
var zAgentThinkingEvent = object({
	type: literal("agent_thinking"),
	data: zAgentThinkingData
});
var zAgentToolCallEvent = object({
	type: literal("agent_tool_call"),
	data: zAgentToolCallData
});
var zAgentMessageDeltaEvent = object({
	type: literal("agent_message_delta"),
	data: zAgentMessageDeltaData
});
var zAgentMessageDraftEvent = object({
	type: literal("agent_message_draft"),
	data: zAgentMessageDraftData
});
var zAgentMessageDoneEvent = object({
	type: literal("agent_message_done"),
	data: zAgentMessageDoneData
});
var zAgentActiveTabEvent = object({
	type: literal("agent_active_tab"),
	data: zAgentActiveTabData
});
var zAgentAskEvent = object({
	type: literal("agent_ask"),
	data: zTolerantPendingAsk.extend({ thread_id: string() })
});
var zAgentAskResolvedEvent = object({
	type: literal("agent_ask_resolved"),
	data: zAgentAskResolvedData
});
var zAgentWsEvent = discriminatedUnion("type", [
	zAgentThinkingEvent,
	zAgentToolCallEvent,
	zAgentMessageDeltaEvent,
	zAgentMessageDraftEvent,
	zAgentMessageDoneEvent,
	zAgentActiveTabEvent,
	zAgentAskEvent,
	zAgentAskResolvedEvent
]);
var AGENT_WS_EVENT_TYPES = new Set(zAgentWsEvent.options.map((option) => option.shape.type.value));
function isAgentEvent(type) {
	return AGENT_WS_EVENT_TYPES.has(type);
}
function parseAgentWsEvent(value) {
	return zAgentWsEvent.safeParse(value);
}
var zAgentIdentity = zAgentIdentity$1.extend({ user_id: string().min(1) });
//#endregion
export { zTurnInProgressError as _, zAgentAnswerReceipt as a, zAgentMessages as c, zAgentTurnAccepted as d, zAttachmentRejection as f, zPersistedToolCallSummary as g, zPersistedThinkingEntry as h, toTurnId as i, zAgentRunMode as l, zDisownedWorkflowError as m, isAgentEvent as n, zAgentError as o, zCloudWorkflowIndex as p, parseAgentWsEvent as r, zAgentIdentity as s, RENDERED_ASK_KINDS as t, zAgentThreads as u };
