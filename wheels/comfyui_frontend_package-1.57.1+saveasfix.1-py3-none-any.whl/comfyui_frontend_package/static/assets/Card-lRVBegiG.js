import "./rolldown-runtime-xtsTai4I.js";
import { G as defineComponent, Kt as normalizeClass, R as createElementBlock, Wt as unref, ct as openBlock, dt as renderSlot } from "./vendor-vue-core-CuN1excl.js";
import { i as cva } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
//#region src/components/ui/card/card.variants.ts
var cardVariants = cva({
	base: "border",
	variants: { surface: {
		background: "overflow-hidden rounded-2xl bg-background",
		secondary: "rounded-lg bg-secondary"
	} },
	defaultVariants: { surface: "background" }
});
//#endregion
//#region src/components/ui/card/Card.vue
var Card_default = /* @__PURE__ */ defineComponent({
	__name: "Card",
	props: {
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] },
		surface: {}
	},
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", { class: normalizeClass(unref(cn)(unref(cardVariants)({ surface: __props.surface }), __props.class)) }, [renderSlot(_ctx.$slots, "default")], 2);
		};
	}
});
//#endregion
export { Card_default as t };
