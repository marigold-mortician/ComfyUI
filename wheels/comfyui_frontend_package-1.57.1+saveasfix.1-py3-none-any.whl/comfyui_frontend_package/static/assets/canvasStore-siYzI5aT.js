import "./rolldown-runtime-xtsTai4I.js";
import { Et as useSelectionStore, K as resolveSelectable, Nt as graphScopeOf, Vt as LayoutSource, w as useLayoutMutations } from "./litegraph-DsPnoImk.js";
import { d as isLGraphNode } from "./litegraphUtil-8EMdlR16.js";
import { Ft as ref, P as computed, Rt as shallowRef, d as defineStore } from "./vendor-vue-core-CuN1excl.js";
import { Xr as whenever, ar as useEventListener } from "./vendor-reka-ui-NRTk7aIV.js";
import { b as createPositionBounds, n as useWorkflowStore } from "./workflowStore-ChkUx7Si.js";
import { t as useToast } from "./toastStore-Dg65fRgL.js";
import { t as useAgentPanelStore } from "./agentPanelStore-CFwk6coW.js";
//#region src/utils/appMode.ts
function getWorkflowMode(workflow) {
	return workflow?.activeMode ?? workflow?.initialMode ?? "graph";
}
function isAppModeValue(mode) {
	return mode === "app" || mode === "builder:arrange";
}
//#endregion
//#region src/composables/useAppMode.ts
var enableAppBuilder = ref(true);
function useAppMode() {
	const workflowStore = useWorkflowStore();
	const mode = computed(() => getWorkflowMode(workflowStore.activeWorkflow));
	const isBuilderMode = computed(() => isSelectMode.value || isArrangeMode.value);
	const isSelectInputsMode = computed(() => mode.value === "builder:inputs");
	const isSelectOutputsMode = computed(() => mode.value === "builder:outputs");
	const isSelectMode = computed(() => isSelectInputsMode.value || isSelectOutputsMode.value);
	const isArrangeMode = computed(() => mode.value === "builder:arrange");
	const isAppMode = computed(() => isAppModeValue(mode.value));
	const isGraphMode = computed(() => mode.value === "graph" || isSelectMode.value);
	function setMode(newMode) {
		const workflow = workflowStore.activeWorkflow;
		if (workflow) workflow.activeMode = newMode;
	}
	return {
		mode,
		enableAppBuilder,
		isBuilderMode,
		isSelectMode,
		isSelectInputsMode,
		isSelectOutputsMode,
		isArrangeMode,
		isAppMode,
		isGraphMode,
		setMode
	};
}
//#endregion
//#region src/composables/canvas/visibleCanvasViewport.ts
function visibleCanvasViewport(canvas) {
	const panel = useAgentPanelStore();
	const [width, height] = canvas.ds.getViewportSize();
	const uncoveredWidth = width - (panel.isVisible ? panel.width : 0);
	return [
		0,
		0,
		uncoveredWidth > 0 ? uncoveredWidth : width,
		height
	];
}
//#endregion
//#region src/renderer/core/canvas/canvasStore.ts
var promoteRecommendedWidgets;
/** Called by `promotionUtils` when it loads; it imports this store. */
function providePromoteRecommendedWidgets(promote) {
	promoteRecommendedWidgets = promote;
}
var useTitleEditorStore = defineStore("titleEditor", () => {
	return { titleEditorTarget: shallowRef(null) };
});
var useCanvasStore = defineStore("canvas", () => {
	/**
	* The LGraphCanvas instance.
	*
	* The root LGraphCanvas object is a shallow ref.
	*/
	const canvas = shallowRef(null);
	const selectionStore = useSelectionStore();
	const appScalePercentage = ref(100);
	const updateAppScalePercentage = (scale) => {
		appScalePercentage.value = Math.round(scale * 100);
	};
	const { isAppMode, setMode } = useAppMode();
	const linearMode = computed({
		get: () => isAppMode.value,
		set: (val) => {
			setMode(val ? "app" : "graph");
		}
	});
	const isReadOnly = ref(false);
	let originalOnChanged = void 0;
	const initScaleSync = () => {
		const ds = canvas.value?.ds;
		if (!ds) return;
		originalOnChanged = ds.onChanged;
		updateAppScalePercentage(ds.scale);
		ds.onChanged = () => {
			if (ds.scale) updateAppScalePercentage(ds.scale);
			originalOnChanged?.(ds.scale, ds.offset);
		};
	};
	const cleanupScaleSync = () => {
		const ds = canvas.value?.ds;
		if (!ds) return;
		ds.onChanged = originalOnChanged;
		originalOnChanged = void 0;
	};
	const getCanvas = () => {
		if (!canvas.value) throw new Error("getCanvas: canvas is null");
		return canvas.value;
	};
	/**
	* Sets the canvas zoom level from a percentage value
	* @param percentage - Zoom percentage value (1-1000, where 1000 = 1000% zoom)
	*/
	const setAppZoomFromPercentage = (percentage) => {
		const currentCanvas = canvas.value;
		if (!currentCanvas || percentage <= 0) return;
		const newScale = percentage / 100;
		const { ds } = currentCanvas;
		const { element } = ds;
		ds.changeScale(newScale, [element.width / 2, element.height / 2]);
		currentCanvas.setDirty(true, true);
		updateAppScalePercentage(newScale);
	};
	const currentGraph = shallowRef(null);
	const rootGraphId = computed(() => currentGraph.value?.rootGraph.id);
	const isInSubgraph = ref(false);
	const isGhostPlacing = ref(false);
	const isPickingNodes = ref(false);
	const toast = useToast();
	function startNodePicking() {
		const currentCanvas = canvas.value;
		if (!currentCanvas || isPickingNodes.value) return;
		isPickingNodes.value = true;
		toast.held = true;
		const selected = [...currentCanvas.selectedItems];
		const bounds = createPositionBounds(selected.length ? selected : currentCanvas.graph?.nodes ?? [], 40);
		if (bounds) currentCanvas.animateToBounds(bounds, { viewport: visibleCanvasViewport(currentCanvas) });
	}
	function stopNodePicking() {
		if (!isPickingNodes.value) return;
		isPickingNodes.value = false;
		toast.held = false;
		canvas.value?.deselectAll();
	}
	/** The selected items of the on-screen graph, derived from the selection store. */
	const selectedItems = computed(() => {
		const graph = currentGraph.value;
		if (!graph) return [];
		return selectionStore.selectedKeys(graphScopeOf(graph)).flatMap((key) => resolveSelectable(graph, key) ?? []);
	});
	const selectedNodeIds = computed(() => new Set(selectedItems.value.filter(isLGraphNode).map((item) => item.id)));
	whenever(() => canvas.value, (newCanvas) => {
		currentGraph.value = newCanvas.graph;
		useEventListener(() => currentGraph.value?.events, "node:before-removed", (e) => {
			newCanvas.deselect(e.detail.node, { notify: false });
		});
		isReadOnly.value = newCanvas.read_only;
		useEventListener(newCanvas.canvas, "litegraph:read-only-changed", (event) => {
			isReadOnly.value = event.detail.readOnly;
		});
		useEventListener(newCanvas.canvas, "litegraph:set-graph", (event) => {
			const newGraph = event.detail.newGraph ?? newCanvas.graph;
			currentGraph.value = newGraph;
			isInSubgraph.value = Boolean(newCanvas.subgraph);
		});
		useEventListener(newCanvas.canvas, "subgraph-opened", () => {
			isInSubgraph.value = true;
		});
		useEventListener(newCanvas.canvas, "subgraph-converted", (e) => promoteRecommendedWidgets(e.detail.subgraphNode));
		useEventListener(newCanvas.canvas, "litegraph:ghost-placement", (e) => {
			isGhostPlacing.value = e.detail.active;
			const graph = currentGraph.value;
			if (e.detail.active && graph) useLayoutMutations(LayoutSource.Canvas).setNodeOrder(graph, e.detail.nodeId, "front");
		});
	}, { immediate: true });
	return {
		canvas,
		selectedItems,
		selectedNodeIds,
		appScalePercentage,
		linearMode,
		isReadOnly,
		getCanvas,
		setAppZoomFromPercentage,
		initScaleSync,
		cleanupScaleSync,
		currentGraph,
		rootGraphId,
		isInSubgraph,
		isGhostPlacing,
		isPickingNodes,
		startNodePicking,
		stopNodePicking
	};
});
//#endregion
export { useAppMode as a, visibleCanvasViewport as i, useCanvasStore as n, getWorkflowMode as o, useTitleEditorStore as r, isAppModeValue as s, providePromoteRecommendedWidgets as t };
