import "./rolldown-runtime-xtsTai4I.js";
//#region src/platform/billing/subscription/composables/billingDialogsAccess.ts
/** `useBillingDialogs` for the dialogs it opens, which cannot import it back. */
var useBillingDialogsAccess;
/** Called by `useBillingDialogs` when it loads. */
function provideBillingDialogs(useDialogs) {
	useBillingDialogsAccess = useDialogs;
}
//#endregion
export { useBillingDialogsAccess as n, provideBillingDialogs as t };
