import "./rolldown-runtime-xtsTai4I.js";
import { $ as mergeModels, E as withModifiers, F as createBaseVNode, Ft as ref, G as defineComponent, I as createBlock, Jt as normalizeStyle, L as createCommentVNode, O as Fragment, R as createElementBlock, Wt as unref, _t as useModel, ct as openBlock, ut as renderList, wt as withCtx, yt as useTemplateRef } from "./vendor-vue-core-CuN1excl.js";
import { ar as useEventListener } from "./vendor-reka-ui-NRTk7aIV.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as AppColorPicker_default } from "./AppColorPicker-DF4cO9Dd.js";
//#region src/composables/palette/usePaletteSwatchRow.ts
function usePaletteSwatchRow({ modelValue, container, onEditEnd }) {
	function updateAt(i, value) {
		if (modelValue.value[i] === value) return;
		const next = modelValue.value.slice();
		next[i] = value;
		modelValue.value = next;
		onEditEnd?.(`color:${i}`);
	}
	function remove(i) {
		const next = modelValue.value.slice();
		next.splice(i, 1);
		modelValue.value = next;
		onEditEnd?.();
	}
	function addColor() {
		modelValue.value = [...modelValue.value, "#ffffff"];
		onEditEnd?.();
	}
	const drag = ref(null);
	function onPointerDown(i, e) {
		if (e.button !== 0) return;
		drag.value = {
			index: i,
			startX: e.clientX,
			startY: e.clientY,
			active: false
		};
	}
	useEventListener(document, "pointermove", (e) => {
		const d = drag.value;
		if (!d) return;
		if ((e.buttons & 1) === 0) {
			drag.value = null;
			return;
		}
		if (!d.active) {
			if (Math.abs(e.clientX - d.startX) + Math.abs(e.clientY - d.startY) < 4) return;
			d.active = true;
		}
		const rows = container.value?.querySelectorAll("[data-index]");
		if (!rows) return;
		for (const other of rows) {
			if (parseInt(other.dataset.index || "-1", 10) === d.index) continue;
			const r = other.getBoundingClientRect();
			if (e.clientX >= r.left && e.clientX <= r.right && e.clientY >= r.top - 6 && e.clientY <= r.bottom + 6) {
				const oi = parseInt(other.dataset.index || "-1", 10);
				if (oi < 0) continue;
				const next = modelValue.value.slice();
				const [moved] = next.splice(d.index, 1);
				const insertAt = e.clientX > r.left + r.width / 2 ? oi + 1 : oi;
				next.splice(insertAt > d.index ? insertAt - 1 : insertAt, 0, moved);
				modelValue.value = next;
				drag.value = null;
				onEditEnd?.();
				return;
			}
		}
	});
	useEventListener(document, "pointerup", () => {
		drag.value = null;
	});
	useEventListener(document, "pointercancel", () => {
		drag.value = null;
	});
	return {
		updateAt,
		remove,
		addColor,
		onPointerDown
	};
}
//#endregion
//#region src/components/palette/PaletteSwatchRow.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = [
	"data-index",
	"data-hex",
	"title",
	"onContextmenu",
	"onPointerdown"
];
var _hoisted_2 = ["title"];
//#endregion
//#region src/components/palette/PaletteSwatchRow.vue
var PaletteSwatchRow_default = /* @__PURE__ */ defineComponent({
	__name: "PaletteSwatchRow",
	props: /*@__PURE__*/ mergeModels({ max: { default: 5 } }, {
		"modelValue": { required: true },
		"modelModifiers": {}
	}),
	emits: /*@__PURE__*/ mergeModels(["editEnd"], ["update:modelValue"]),
	setup(__props, { emit: __emit }) {
		const modelValue = useModel(__props, "modelValue");
		const emit = __emit;
		const { t } = useI18n();
		const container = useTemplateRef("container");
		const { updateAt, remove, addColor, onPointerDown } = usePaletteSwatchRow({
			modelValue,
			container,
			onEditEnd: (mergeKey) => emit("editEnd", mergeKey)
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				ref_key: "container",
				ref: container,
				class: "flex flex-wrap items-center gap-1"
			}, [(openBlock(true), createElementBlock(Fragment, null, renderList(modelValue.value, (hex, i) => {
				return openBlock(), createBlock(AppColorPicker_default, {
					key: i,
					"model-value": hex,
					alpha: false,
					"onUpdate:modelValue": (value) => unref(updateAt)(i, value)
				}, {
					trigger: withCtx(() => [createBaseVNode("button", {
						type: "button",
						"data-index": i,
						"data-hex": hex,
						class: "relative size-5 cursor-pointer rounded-sm border border-node-border p-0",
						style: normalizeStyle({ background: hex }),
						title: unref(t)("palette.swatchTitle"),
						onContextmenu: withModifiers(($event) => unref(remove)(i), ["prevent", "stop"]),
						onPointerdown: ($event) => unref(onPointerDown)(i, $event)
					}, null, 44, _hoisted_1)]),
					_: 2
				}, 1032, ["model-value", "onUpdate:modelValue"]);
			}), 128)), modelValue.value.length < __props.max ? (openBlock(), createElementBlock("button", {
				key: 0,
				type: "button",
				class: "h-5 rounded-sm border border-node-border bg-input px-2 text-xs leading-none",
				title: unref(t)("palette.addColor"),
				onClick: _cache[0] || (_cache[0] = (...args) => unref(addColor) && unref(addColor)(...args))
			}, " + ", 8, _hoisted_2)) : createCommentVNode("", true)], 512);
		};
	}
});
//#endregion
export { PaletteSwatchRow_default as t };
