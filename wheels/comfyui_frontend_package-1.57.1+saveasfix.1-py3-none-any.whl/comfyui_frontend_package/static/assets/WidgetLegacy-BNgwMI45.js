import { t as WidgetLegacy_default } from "./WidgetLegacy-DZbHVTF5.js";
export { WidgetLegacy_default as default };
