import "./rolldown-runtime-xtsTai4I.js";
import { F as createBaseVNode, G as defineComponent, I as createBlock, Kt as normalizeClass, R as createElementBlock, Wt as unref, ct as openBlock, dt as renderSlot, et as mergeProps, wt as withCtx, z as createPropsRestProxy } from "./vendor-vue-core-CuN1excl.js";
import { Nn as useForwardProps, jn as Primitive } from "./vendor-reka-ui-NRTk7aIV.js";
import { t as cn } from "./src-BHQtMnZc.js";
//#endregion
//#region src/components/actionbar/TinyChevronIcon.vue
var TinyChevronIcon_default = /* @__PURE__ */ defineComponent({
	__name: "TinyChevronIcon",
	props: { rotateUp: {
		type: Boolean,
		default: false
	} },
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("svg", {
				class: normalizeClass(["h-[5px] min-h-[5px] w-[8px] min-w-[8px]", { "rotate-180": __props.rotateUp }]),
				xmlns: "http://www.w3.org/2000/svg",
				width: "8",
				height: "5",
				viewBox: "0 0 8 5",
				fill: "none",
				"aria-hidden": "true"
			}, [..._cache[0] || (_cache[0] = [createBaseVNode("path", {
				d: "M0.650391 0.649902L3.65039 3.6499L6.65039 0.649902",
				stroke: "currentColor",
				"stroke-width": "1.3",
				"stroke-linecap": "round",
				"stroke-linejoin": "round"
			}, null, -1)])], 2);
		};
	}
});
//#endregion
//#region src/components/ui/button-group/ButtonGroup.vue
var ButtonGroup_default = /* @__PURE__ */ defineComponent({
	__name: "ButtonGroup",
	props: {
		class: {
			type: [
				Boolean,
				null,
				String,
				Object,
				Array
			],
			default: ""
		},
		asChild: { type: Boolean },
		as: { default: "div" }
	},
	setup(__props) {
		const restProps = createPropsRestProxy(__props, ["as", "class"]);
		const forwardedProps = useForwardProps(restProps);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(Primitive), mergeProps(unref(forwardedProps), {
				as: __props.as,
				class: unref(cn)("inline-flex items-stretch overflow-hidden rounded-md", __props.class)
			}), {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
				_: 3
			}, 16, ["as", "class"]);
		};
	}
});
//#endregion
export { TinyChevronIcon_default as n, ButtonGroup_default as t };
