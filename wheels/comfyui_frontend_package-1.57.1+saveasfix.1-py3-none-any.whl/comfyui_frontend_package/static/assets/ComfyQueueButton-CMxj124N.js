import { t as ComfyQueueButton_default } from "./ComfyQueueButton-DO9TBksa.js";
export { ComfyQueueButton_default as default };
