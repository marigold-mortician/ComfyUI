import "./rolldown-runtime-xtsTai4I.js";
import { m as getActiveCheckoutJourney, v as toCheckoutJourneyContext } from "./useBillingContext-Cc-YANxo.js";
import { Mt as onScopeDispose } from "./vendor-vue-core-CuN1excl.js";
import { ar as useEventListener } from "./vendor-reka-ui-NRTk7aIV.js";
import { n as useTelemetry } from "./telemetry-IkzvF0TI.js";
//#region src/platform/billing/utils/checkoutJourneyTelemetry.ts
/**
* The last progress phase this tab reported on a journey, and whether an exit
* or a handoff already accounts for it. Only new progress reopens it.
*/
var progress = null;
function trackCheckoutJourneyPhase(record, phase) {
	if (phase.phase !== "abandoned" && phase.phase !== "ended") progress = {
		journeyId: record.journey_id,
		lastPhase: phase.phase,
		accounted: false
	};
	useTelemetry()?.trackCheckoutJourneyEvent({
		...toCheckoutJourneyContext(record),
		...phase
	});
}
function unaccountedProgress(journey) {
	return progress?.journeyId === journey.journey_id && !progress.accounted ? progress : null;
}
/** The journey continues on the hosted checkout, so closing this dialog is not an exit. */
function handOffCheckoutJourney() {
	const journey = getActiveCheckoutJourney();
	const open = journey && unaccountedProgress(journey);
	if (open) open.accounted = true;
}
/**
* Where the customer left a journey no operation is bound to. An observation,
* not a verdict: once an operation exists its own events own the end.
*/
function reportCheckoutJourneyExit(exit) {
	const journey = getActiveCheckoutJourney();
	if (!journey || journey.billing_op_id !== void 0) return;
	const open = unaccountedProgress(journey);
	if (!open) return;
	open.accounted = true;
	trackCheckoutJourneyPhase(journey, {
		phase: "abandoned",
		last_phase: open.lastPhase,
		exit
	});
}
/** For a checkout dialog: its close, or the page going away while it is open, is an exit. */
function useCheckoutJourneyExit() {
	useEventListener(window, "pagehide", () => reportCheckoutJourneyExit("page_exit"));
	onScopeDispose(() => reportCheckoutJourneyExit("dialog_close"));
}
//#endregion
export { trackCheckoutJourneyPhase as n, useCheckoutJourneyExit as r, handOffCheckoutJourney as t };
