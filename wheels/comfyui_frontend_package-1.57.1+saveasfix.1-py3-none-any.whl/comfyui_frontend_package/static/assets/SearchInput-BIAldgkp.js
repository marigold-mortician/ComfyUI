import "./rolldown-runtime-xtsTai4I.js";
import { $ as mergeModels, E as withModifiers, F as createBaseVNode, Ft as ref, G as defineComponent, I as createBlock, Kt as normalizeClass, P as computed, R as createElementBlock, U as createVNode, Wt as unref, _t as useModel, ct as openBlock, dt as renderSlot, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { Qt as ComboboxInput_default, Yr as watchDebounced, nn as ComboboxRoot_default, tn as ComboboxAnchor_default } from "./vendor-reka-ui-NRTk7aIV.js";
import { i as cva, t as Button_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
//#region src/components/ui/search-input/searchInput.variants.ts
var searchInputVariants = cva({
	base: "relative flex w-full cursor-text items-center rounded-lg bg-secondary text-foreground focus-within:ring-1 focus-within:ring-ring",
	variants: {
		size: {
			sm: "h-6 p-1",
			md: "h-8 px-2 py-1.5",
			lg: "h-10 p-2",
			xl: "h-12 p-2"
		},
		invalid: { true: "ring-1 ring-destructive" }
	},
	defaultVariants: { size: "md" }
});
var searchInputSizeConfig = {
	sm: {
		icon: "size-3",
		iconPos: "left-2",
		inputPl: "pl-6",
		inputText: "text-xs",
		clearPos: "left-1"
	},
	md: {
		icon: "size-4",
		iconPos: "left-2.5",
		inputPl: "pl-8",
		inputText: "text-xs",
		clearPos: "left-2.5"
	},
	lg: {
		icon: "size-4",
		iconPos: "left-2.5",
		inputPl: "pl-8",
		inputText: "text-xs",
		clearPos: "left-2.5"
	},
	xl: {
		icon: "size-4",
		iconPos: "left-2.5",
		inputPl: "pl-8",
		inputText: "text-xs",
		clearPos: "left-2"
	}
};
//#endregion
//#region src/components/ui/search-input/SearchInput.vue
var SearchInput_default = /* @__PURE__ */ defineComponent({
	__name: "SearchInput",
	props: /*@__PURE__*/ mergeModels({
		placeholder: {},
		accessibleLabel: {},
		clearLabel: {},
		icon: { default: "icon-[lucide--search]" },
		debounceTime: { default: 300 },
		autofocus: {
			type: Boolean,
			default: false
		},
		loading: {
			type: Boolean,
			default: false
		},
		invalid: {
			type: Boolean,
			default: false
		},
		disabled: {
			type: Boolean,
			default: false
		},
		size: { default: "md" },
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	}, {
		"modelValue": { required: true },
		"modelModifiers": {}
	}),
	emits: /*@__PURE__*/ mergeModels(["search", "blur"], ["update:modelValue"]),
	setup(__props, { expose: __expose, emit: __emit }) {
		const emit = __emit;
		const sizeConfig = computed(() => searchInputSizeConfig[__props.size]);
		const modelValue = useModel(__props, "modelValue");
		const inputRef = ref(null);
		function focus() {
			inputRef.value?.$el?.focus();
		}
		__expose({ focus });
		function clearSearch() {
			modelValue.value = "";
			focus();
		}
		watchDebounced(modelValue, (value) => {
			emit("search", value);
		}, { debounce: __props.debounceTime });
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(ComboboxRoot_default), {
				open: false,
				"ignore-filter": "",
				disabled: __props.disabled,
				class: normalizeClass(__props.class)
			}, {
				default: withCtx(() => [createVNode(unref(ComboboxAnchor_default), {
					class: normalizeClass(unref(cn)(unref(searchInputVariants)({
						size: __props.size,
						invalid: __props.invalid
					}), __props.disabled && "pointer-events-none opacity-50")),
					onClick: focus
				}, {
					default: withCtx(() => [renderSlot(_ctx.$slots, "trailing", {
						iconClass: sizeConfig.value.icon,
						positionClass: sizeConfig.value.iconPos
					}, () => [modelValue.value ? (openBlock(), createBlock(Button_default, {
						key: 0,
						class: normalizeClass(unref(cn)("absolute", sizeConfig.value.clearPos)),
						variant: "textonly",
						size: "icon-sm",
						disabled: __props.disabled,
						"aria-label": __props.clearLabel,
						onClick: withModifiers(clearSearch, ["stop"])
					}, {
						default: withCtx(() => [createBaseVNode("i", { class: normalizeClass(unref(cn)("icon-[lucide--x]", sizeConfig.value.icon)) }, null, 2)]),
						_: 1
					}, 8, [
						"class",
						"disabled",
						"aria-label"
					])) : __props.loading ? (openBlock(), createElementBlock("i", {
						key: 1,
						class: normalizeClass(unref(cn)("pointer-events-none absolute icon-[lucide--loader-circle] animate-spin", sizeConfig.value.iconPos, sizeConfig.value.icon))
					}, null, 2)) : (openBlock(), createElementBlock("i", {
						key: 2,
						class: normalizeClass(unref(cn)("pointer-events-none absolute", sizeConfig.value.iconPos, sizeConfig.value.icon, __props.icon))
					}, null, 2))]), createVNode(unref(ComboboxInput_default), {
						ref_key: "inputRef",
						ref: inputRef,
						modelValue: modelValue.value,
						"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => modelValue.value = $event),
						class: normalizeClass(unref(cn)("size-full border-none bg-transparent outline-none", sizeConfig.value.inputPl, sizeConfig.value.inputText)),
						placeholder: __props.placeholder,
						"aria-label": __props.accessibleLabel,
						"aria-invalid": __props.invalid,
						"auto-focus": __props.autofocus,
						onBlur: _cache[1] || (_cache[1] = ($event) => emit("blur"))
					}, null, 8, [
						"modelValue",
						"class",
						"placeholder",
						"aria-label",
						"aria-invalid",
						"auto-focus"
					])]),
					_: 3
				}, 8, ["class"])]),
				_: 3
			}, 8, ["disabled", "class"]);
		};
	}
});
//#endregion
export { searchInputSizeConfig as n, searchInputVariants as r, SearchInput_default as t };
