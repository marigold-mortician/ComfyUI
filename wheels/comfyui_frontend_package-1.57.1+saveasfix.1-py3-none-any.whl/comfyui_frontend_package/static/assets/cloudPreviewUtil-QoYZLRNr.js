import "./rolldown-runtime-xtsTai4I.js";
import "./formatUtil-DsZFGVbT.js";
//#region src/platform/distribution/cloudPreviewUtil.ts
/**
* Appends `res=512` to the given URLSearchParams when in cloud mode
* and the file is an image (or filename is unknown).
*
* The cloud backend resizes images server-side to prevent
* the frontend from loading very large originals for previews.
*/
function appendCloudResParam(params, filename) {}
//#endregion
export { appendCloudResParam as t };
