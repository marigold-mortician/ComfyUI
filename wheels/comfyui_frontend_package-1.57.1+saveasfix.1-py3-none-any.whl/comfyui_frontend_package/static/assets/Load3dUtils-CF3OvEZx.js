import "./rolldown-runtime-xtsTai4I.js";
import { i as api } from "./api-BdJmXw98.js";
import { n as useApp } from "./appInstance-CiT6CpGM.js";
import { t as useToast } from "./toastStore-Dg65fRgL.js";
import { d as t } from "./i18n-BRluoVl-.js";
import { t as getErrorMessage } from "./errorUtil-DoQyAUQC.js";
//#region src/services/uploadTempFile.ts
async function uploadTempFile(file, subfolder) {
	const body = new FormData();
	body.append("image", file);
	body.append("subfolder", subfolder);
	body.append("type", "temp");
	const resp = await api.fetchApi("/upload/image", {
		method: "POST",
		body
	});
	if (resp.status !== 200) {
		const reason = `${resp.status} - ${resp.statusText}`;
		useToast().warning(t("g.uploadFailed", { reason }));
		return {
			ok: false,
			reason
		};
	}
	return {
		file: await resp.json(),
		ok: true
	};
}
//#endregion
//#region src/extensions/core/load3d/Load3dUtils.ts
var Load3dUtils = class {
	static async uploadTempImage(imageData, prefix, fileType = "png") {
		const blob = await fetch(imageData).then((r) => r.blob());
		const name = `${prefix}_${Date.now()}.${fileType}`;
		const upload = await uploadTempFile(new File([blob], name, { type: fileType === "mp4" ? "video/mp4" : "image/png" }), "threed");
		if (!upload.ok) throw new Error(`Error uploading temp file: ${upload.reason}`);
		return upload.file;
	}
	static MAX_UPLOAD_SIZE_MB = 100;
	static async uploadFile(file, subfolder) {
		let uploadPath;
		const fileSizeMB = file.size / 1024 / 1024;
		if (fileSizeMB > this.MAX_UPLOAD_SIZE_MB) {
			const message = t("toastMessages.fileTooLarge", {
				size: fileSizeMB.toFixed(1),
				maxSize: this.MAX_UPLOAD_SIZE_MB
			});
			console.warn("[Load3D] uploadFile: file too large", fileSizeMB.toFixed(2), "MB");
			useToast().warning(message);
			return;
		}
		try {
			const body = new FormData();
			body.append("image", file);
			body.append("subfolder", subfolder);
			const resp = await api.fetchApi("/upload/image", {
				method: "POST",
				body
			});
			if (resp.status === 200) {
				const data = await resp.json();
				let path = data.name;
				if (data.subfolder) path = data.subfolder + "/" + path;
				uploadPath = path;
			} else useToast().warning(t("g.uploadFailed", { reason: `${resp.status} - ${resp.statusText}` }));
		} catch (error) {
			console.error("[Load3D] uploadFile: exception", error);
			useToast().warning(t("g.uploadFailed", { reason: getErrorMessage(error) ?? t("g.unknownError") }));
		}
		return uploadPath;
	}
	static splitFilePath(path) {
		const folder_separator = path.lastIndexOf("/");
		if (folder_separator === -1) return ["", path];
		return [path.substring(0, folder_separator), path.substring(folder_separator + 1)];
	}
	static getResourceURL(subfolder, filename, type = "input") {
		return `/view?${[
			"filename=" + encodeURIComponent(filename),
			"type=" + type,
			"subfolder=" + subfolder,
			useApp().getRandParam().substring(1)
		].join("&")}`;
	}
	static async uploadMultipleFiles(files, subfolder = "3d") {
		const uploadPromises = Array.from(files).map((file) => this.uploadFile(file, subfolder));
		await Promise.all(uploadPromises);
	}
	static mapSceneLightIntensityToHdri(sceneIntensity, sceneMin, sceneMax) {
		const span = sceneMax - sceneMin;
		const t = span > 0 ? (sceneIntensity - sceneMin) / span : 0;
		const mapped = Math.min(1, Math.max(0, t)) * 5;
		return Math.min(5, Math.max(.25, mapped));
	}
};
//#endregion
export { uploadTempFile as n, Load3dUtils as t };
