import "./rolldown-runtime-xtsTai4I.js";
import { F as createBaseVNode, G as defineComponent, I as createBlock, U as createVNode, Wt as unref, ct as openBlock, dt as renderSlot, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { Tn as DialogClose_default$1 } from "./vendor-reka-ui-NRTk7aIV.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
//#endregion
//#region src/components/ui/dialog/DialogClose.vue
var DialogClose_default = /* @__PURE__ */ defineComponent({
	__name: "DialogClose",
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(DialogClose_default$1), { "as-child": "" }, {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default", {}, () => [createVNode(Button_default, {
					size: "icon",
					variant: "muted-textonly"
				}, {
					default: withCtx(() => [..._cache[0] || (_cache[0] = [createBaseVNode("i", { class: "icon-[lucide--x]" }, null, -1)])]),
					_: 1
				})])]),
				_: 3
			});
		};
	}
});
//#endregion
export { DialogClose_default as t };
