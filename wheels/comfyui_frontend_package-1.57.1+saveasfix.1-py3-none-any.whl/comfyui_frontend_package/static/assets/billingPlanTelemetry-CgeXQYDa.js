import "./rolldown-runtime-xtsTai4I.js";
import { m as toTierKey } from "./tierPricing-Dm5JzLf8.js";
//#region src/platform/billing/subscription/utils/billingPlanTelemetry.ts
/** The plan a customer is on, in the telemetry vocabulary; absent when it names none. */
function toCurrentTier(tier) {
	if (tier === "TEAM") return "team";
	return tier && toTierKey(tier) || void 0;
}
function toBillingCycle(duration) {
	if (!duration) return void 0;
	return duration === "ANNUAL" ? "yearly" : "monthly";
}
//#endregion
export { toCurrentTier as n, toBillingCycle as t };
