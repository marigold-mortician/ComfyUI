import "./rolldown-runtime-xtsTai4I.js";
import { F as createBaseVNode, G as defineComponent, H as createTextVNode, I as createBlock, R as createElementBlock, Wt as unref, Yt as toDisplayString, bt as watch, ct as openBlock, tt as nextTick, wt as withCtx, yt as useTemplateRef } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as ComfyQueueButton_default } from "./ComfyQueueButton-DO9TBksa.js";
import { n as usePartnerNodesRunGate } from "./usePartnerNodesRunGate-CDN3pb24.js";
import { t as useAuthDialogs } from "./useAuthDialogs-AEcL-pGe.js";
//#endregion
//#region src/components/actionbar/ComfyRunButton/LocalRunButtonWrapper.vue
var LocalRunButtonWrapper_default = /* @__PURE__ */ defineComponent({
	__name: "LocalRunButtonWrapper",
	setup(__props) {
		const { t } = useI18n();
		const { gate, partnerNodes } = usePartnerNodesRunGate();
		const { showApiNodesSignInDialog } = useAuthDialogs();
		const root = useTemplateRef("root");
		watch(gate, async () => {
			if (!root.value?.contains(document.activeElement)) return;
			await nextTick();
			root.value?.querySelector("button")?.focus();
		});
		function openPartnerSignInDialog() {
			showApiNodesSignInDialog(partnerNodes.value.map((node) => node.displayName));
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				ref_key: "root",
				ref: root,
				class: "contents"
			}, [unref(gate) === "none" ? (openBlock(), createBlock(ComfyQueueButton_default, { key: 0 })) : (openBlock(), createBlock(Button_default, {
				key: 1,
				tooltip: unref(t)("actionbar.partnerRunGate.signInCaption"),
				"tooltip-side": "bottom",
				variant: "secondary",
				size: "unset",
				class: "h-8 gap-1.5 rounded-lg px-4",
				"data-testid": "partner-sign-in-to-run-button",
				"aria-describedby": "partner-run-gate-caption",
				onClick: openPartnerSignInDialog
			}, {
				default: withCtx(() => [_cache[0] || (_cache[0] = createBaseVNode("i", {
					class: "icon-[lucide--log-in] size-4",
					"aria-hidden": "true"
				}, null, -1)), createTextVNode(" " + toDisplayString(unref(t)("actionbar.partnerRunGate.signInToRun")), 1)]),
				_: 1
			}, 8, ["tooltip"]))], 512);
		};
	}
});
//#endregion
export { LocalRunButtonWrapper_default as default };
