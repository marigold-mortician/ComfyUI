import "./rolldown-runtime-xtsTai4I.js";
import { B as createSlots, F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, I as createBlock, Kt as normalizeClass, L as createCommentVNode, O as Fragment, P as computed, R as createElementBlock, U as createVNode, Wt as unref, X as inject, Yt as toDisplayString, bt as watch, ct as openBlock, dt as renderSlot, et as mergeProps, lt as provide, pt as resolveDynamicComponent, q as guardReactiveProps, qt as normalizeProps, rt as onBeforeUnmount, st as onUpdated, wt as withCtx, yt as useTemplateRef, z as createPropsRestProxy } from "./vendor-vue-core-CuN1excl.js";
import { Mn as useForwardPropsEmits, Nn as useForwardProps, a as TooltipTrigger_default$1, c as TooltipRoot_default, d as injectTooltipProviderContext, f as TooltipArrow_default, jn as Primitive, l as injectTooltipRootContext, o as TooltipPortal_default, s as TooltipContent_default$1 } from "./vendor-reka-ui-NRTk7aIV.js";
import { n as clsx, t as cn } from "./src-BHQtMnZc.js";
//#region src/components/ui/tooltip/tooltipConfig.ts
var appTooltipProviderDefaults = {
	delayDuration: 300,
	disableHoverableContent: true,
	ignoreNonKeyboardFocus: true
};
var tooltipOpenOnClickKey = Symbol("tooltipOpenOnClick");
//#endregion
//#region src/components/ui/tooltip/Tooltip.vue
var Tooltip_default = /* @__PURE__ */ defineComponent({
	__name: "Tooltip",
	props: {
		defaultOpen: { type: Boolean },
		open: { type: Boolean },
		delayDuration: {},
		disableClosingTrigger: { type: Boolean },
		disabled: { type: Boolean },
		ignoreNonKeyboardFocus: { type: Boolean },
		openOnClick: {
			type: Boolean,
			default: false
		}
	},
	emits: ["update:open"],
	setup(__props, { emit: __emit }) {
		const props = createPropsRestProxy(__props, ["disableClosingTrigger", "openOnClick"]);
		const forwarded = useForwardPropsEmits(props, __emit);
		provide(tooltipOpenOnClickKey, () => __props.openOnClick);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(TooltipRoot_default), mergeProps(unref(forwarded), { "disable-closing-trigger": __props.openOnClick || __props.disableClosingTrigger || void 0 }), {
				default: withCtx((slotProps) => [renderSlot(_ctx.$slots, "default", normalizeProps(guardReactiveProps(slotProps)))]),
				_: 3
			}, 16, ["disable-closing-trigger"]);
		};
	}
});
//#endregion
//#region src/components/ui/tooltip/TooltipContent.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$1 = { class: "pointer-events-none" };
var _hoisted_2$1 = {
	ref: "text",
	"data-testid": "tooltip-text"
};
//#endregion
//#region src/components/ui/tooltip/TooltipContent.vue
var TooltipContent_default = /* @__PURE__ */ defineComponent({
	inheritAttrs: false,
	__name: "TooltipContent",
	props: {
		forceMount: { type: Boolean },
		ariaLabel: {},
		asChild: { type: Boolean },
		as: {},
		side: {},
		sideOffset: { default: 4 },
		align: {},
		alignOffset: {},
		avoidCollisions: { type: Boolean },
		collisionBoundary: {},
		collisionPadding: { default: 8 },
		arrowPadding: {},
		sticky: {},
		hideWhenDetached: { type: Boolean },
		positionStrategy: {},
		updatePositionStrategy: {},
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	},
	emits: ["escapeKeyDown", "pointerDownOutside"],
	setup(__props, { emit: __emit }) {
		const restProps = createPropsRestProxy(__props, [
			"class",
			"sideOffset",
			"collisionPadding"
		]);
		const emits = __emit;
		const rootContext = injectTooltipRootContext();
		const textElement = useTemplateRef("text");
		const repeatsTriggerName = ref(false);
		function normalizedText(text) {
			return text?.replace(/\s+/g, " ").trim() ?? "";
		}
		function syncRepeatsTriggerName() {
			const trigger = rootContext.trigger.value;
			const text = normalizedText(textElement.value?.textContent);
			repeatsTriggerName.value = !!trigger && text !== "" && normalizedText(trigger.getAttribute("aria-label") ?? trigger.textContent) === text;
		}
		watch(textElement, syncRepeatsTriggerName, { flush: "post" });
		onUpdated(syncRepeatsTriggerName);
		const forwarded = useForwardPropsEmits(computed(() => ({
			sideOffset: __props.sideOffset,
			collisionPadding: __props.collisionPadding,
			...restProps
		})), emits);
		return (_ctx, _cache) => {
			return unref(rootContext).open.value ? (openBlock(), createBlock(unref(TooltipPortal_default), { key: 0 }, {
				default: withCtx(() => [createBaseVNode("div", _hoisted_1$1, [createVNode(unref(TooltipContent_default$1), mergeProps({
					...unref(forwarded),
					..._ctx.$attrs
				}, {
					"aria-label": restProps.ariaLabel ?? (repeatsTriggerName.value ? " " : void 0),
					"data-slot": "tooltip-content",
					"data-testid": "tooltip-content",
					class: unref(cn)("z-overlay max-w-96 rounded-md border bg-background px-3 py-2 text-xs/tight whitespace-pre-line text-foreground shadow-md", __props.class),
					onEscapeKeyDown: _cache[0] || (_cache[0] = ($event) => unref(rootContext).onClose())
				}), {
					default: withCtx(() => [createBaseVNode("div", _hoisted_2$1, [renderSlot(_ctx.$slots, "default")], 512), createVNode(unref(TooltipArrow_default), {
						width: 10,
						height: 5,
						class: "-mt-px fill-background stroke-border"
					})]),
					_: 3
				}, 16, ["aria-label", "class"])])]),
				_: 3
			})) : createCommentVNode("", true);
		};
	}
});
//#endregion
//#region src/components/ui/tooltip/TooltipTrigger.vue
var TooltipTrigger_default = /* @__PURE__ */ defineComponent({
	__name: "TooltipTrigger",
	props: {
		reference: {},
		asChild: { type: Boolean },
		as: {}
	},
	setup(__props) {
		const forwarded = useForwardProps(__props);
		const rootContext = injectTooltipRootContext();
		const providerContext = injectTooltipProviderContext();
		const openOnClick = inject(tooltipOpenOnClickKey, () => false);
		const hovered = ref(false);
		let buttonsHeld = false;
		watch(rootContext.disabled, (disabled) => {
			if (disabled) rootContext.onClose();
		});
		watch(rootContext.open, (open) => {
			if (open && buttonsHeld) rootContext.onClose();
		});
		watch(() => hovered.value || rootContext.open.value, (active, _, onCleanup) => {
			if (!active) return;
			const close = () => rootContext.onClose();
			window.addEventListener("wheel", close, {
				capture: true,
				passive: true
			});
			onCleanup(() => window.removeEventListener("wheel", close, { capture: true }));
		});
		onBeforeUnmount(() => {
			if (rootContext.open.value) providerContext.onClose();
		});
		function trackButtons(event) {
			buttonsHeld = event.buttons !== 0;
		}
		function openOnMouseEnter(event) {
			hovered.value = true;
			trackButtons(event);
			if (buttonsHeld || rootContext.disabled.value) return;
			rootContext.onTriggerEnter();
		}
		function openOnClickIfEnabled() {
			if (openOnClick() && !rootContext.disabled.value) rootContext.onOpen();
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(TooltipTrigger_default$1), mergeProps(unref(forwarded), {
				onPointerenter: openOnMouseEnter,
				onPointerleave: _cache[0] || (_cache[0] = ($event) => hovered.value = false),
				onPointermove: trackButtons,
				onPointerup: trackButtons,
				onClick: openOnClickIfEnabled
			}), {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
				_: 3
			}, 16);
		};
	}
});
//#endregion
//#region node_modules/.pnpm/cva@1.0.0-beta.4_typescript@6.0.3/node_modules/cva/dist/index.mjs
/**
* Copyright 2022 Joe Bell. All rights reserved.
*
* This file is licensed to you under the Apache License, Version 2.0
* (the "License"); you may not use this file except in compliance with the
* License. You may obtain a copy of the License at
*
*   http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
* WARRANTIES OR REPRESENTATIONS OF ANY KIND, either express or implied. See the
* License for the specific language governing permissions and limitations under
* the License.
*/ var falsyToString = (value) => typeof value === "boolean" ? `${value}` : value === 0 ? "0" : value;
var defineConfig = (options) => {
	const cx = function() {
		for (var _len = arguments.length, inputs = new Array(_len), _key = 0; _key < _len; _key++) inputs[_key] = arguments[_key];
		var _options_hooks;
		var _options_hooks1;
		if (typeof (options === null || options === void 0 ? void 0 : (_options_hooks = options.hooks) === null || _options_hooks === void 0 ? void 0 : _options_hooks["cx:done"]) !== "undefined") return options === null || options === void 0 ? void 0 : options.hooks["cx:done"](clsx(inputs));
		if (typeof (options === null || options === void 0 ? void 0 : (_options_hooks1 = options.hooks) === null || _options_hooks1 === void 0 ? void 0 : _options_hooks1.onComplete) !== "undefined") return options === null || options === void 0 ? void 0 : options.hooks.onComplete(clsx(inputs));
		return clsx(inputs);
	};
	const cva = (config) => (props) => {
		var _config_compoundVariants;
		if ((config === null || config === void 0 ? void 0 : config.variants) == null) return cx(config === null || config === void 0 ? void 0 : config.base, props === null || props === void 0 ? void 0 : props.class, props === null || props === void 0 ? void 0 : props.className);
		const { variants, defaultVariants } = config;
		const getVariantClassNames = Object.keys(variants).map((variant) => {
			const variantProp = props === null || props === void 0 ? void 0 : props[variant];
			const defaultVariantProp = defaultVariants === null || defaultVariants === void 0 ? void 0 : defaultVariants[variant];
			const variantKey = falsyToString(variantProp) || falsyToString(defaultVariantProp);
			return variants[variant][variantKey];
		});
		const defaultsAndProps = {
			...defaultVariants,
			...props && Object.entries(props).reduce((acc, param) => {
				let [key, value] = param;
				return typeof value === "undefined" ? acc : {
					...acc,
					[key]: value
				};
			}, {})
		};
		const getCompoundVariantClassNames = config === null || config === void 0 ? void 0 : (_config_compoundVariants = config.compoundVariants) === null || _config_compoundVariants === void 0 ? void 0 : _config_compoundVariants.reduce((acc, param) => {
			let { class: cvClass, className: cvClassName, ...cvConfig } = param;
			return Object.entries(cvConfig).every((param) => {
				let [cvKey, cvSelector] = param;
				const selector = defaultsAndProps[cvKey];
				return Array.isArray(cvSelector) ? cvSelector.includes(selector) : selector === cvSelector;
			}) ? [
				...acc,
				cvClass,
				cvClassName
			] : acc;
		}, []);
		return cx(config === null || config === void 0 ? void 0 : config.base, getVariantClassNames, getCompoundVariantClassNames, props === null || props === void 0 ? void 0 : props.class, props === null || props === void 0 ? void 0 : props.className);
	};
	const compose = function() {
		for (var _len = arguments.length, components = new Array(_len), _key = 0; _key < _len; _key++) components[_key] = arguments[_key];
		return (props) => {
			const propsWithoutClass = Object.fromEntries(Object.entries(props || {}).filter((param) => {
				let [key] = param;
				return !["class", "className"].includes(key);
			}));
			return cx(components.map((component) => component(propsWithoutClass)), props === null || props === void 0 ? void 0 : props.class, props === null || props === void 0 ? void 0 : props.className);
		};
	};
	return {
		compose,
		cva,
		cx
	};
};
var { compose, cva, cx } = defineConfig();
//#endregion
//#region packages/design-system/src/button.variants.ts
var buttonVariants = cva({
	base: "relative inline-flex cursor-pointer touch-manipulation appearance-none items-center justify-center gap-2 rounded-md border-none font-inter text-sm font-medium whitespace-nowrap transition-colors focus-visible:ring-1 focus-visible:ring-ring focus-visible:outline-none disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([width]):not([height])]:size-4",
	variants: {
		variant: {
			secondary: "bg-secondary text-foreground hover:bg-accent",
			primary: "bg-primary text-foreground hover:bg-primary/90",
			inverted: "bg-foreground text-background hover:bg-foreground/80",
			destructive: "bg-destructive text-foreground hover:bg-destructive/90",
			textonly: "bg-transparent text-foreground hover:bg-accent",
			"muted-textonly": "bg-transparent text-muted-foreground hover:bg-accent",
			"destructive-textonly": "bg-transparent text-destructive hover:bg-destructive/10",
			outline: "border border-solid bg-transparent text-foreground hover:bg-accent",
			link: "bg-transparent text-muted-foreground hover:text-foreground",
			"overlay-white": "bg-white text-gray-600 hover:bg-white/90",
			base: "bg-background text-foreground hover:bg-accent",
			tertiary: "bg-muted text-foreground hover:bg-muted/80",
			subscribe: "border-transparent bg-credit text-charcoal-800 hover:opacity-80",
			"brand-ghost": "bg-white/8 text-primary-warm-white hover:bg-white/20 focus-visible:ring-2 focus-visible:ring-brand-yellow",
			"brand-solid": "bg-brand-yellow text-primary-comfy-ink hover:bg-brand-yellow/90 focus-visible:ring-2 focus-visible:ring-primary-warm-white",
			"brand-ghost-accent": "bg-white/8 text-primary-warm-white hover:bg-brand-yellow hover:text-primary-comfy-ink focus-visible:ring-2 focus-visible:ring-brand-yellow"
		},
		size: {
			sm: "h-6 rounded-sm px-2 py-1 text-xs",
			md: "h-8 rounded-lg p-2 text-xs",
			lg: "h-10 rounded-lg px-4 py-2 text-sm",
			"icon-sm": "size-5 p-0",
			icon: "size-8 rounded-lg",
			"icon-lg": "size-10 rounded-lg",
			link: "gap-1 px-0 py-2 text-sm/5 font-normal hover:underline",
			brand: "h-12 rounded-2xl px-5 font-formula text-sm font-semibold tracking-[0.7px] uppercase lg:h-13 xl:h-14 2xl:h-16",
			"brand-icon": "size-10 rounded-2xl xl:size-12",
			unset: ""
		}
	},
	defaultVariants: {
		variant: "secondary",
		size: "md"
	}
});
//#endregion
//#region src/components/ui/tooltip/TextTooltip.vue
var TextTooltip_default = /* @__PURE__ */ defineComponent({
	__name: "TextTooltip",
	props: {
		text: {},
		side: {}
	},
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createBlock(Tooltip_default, { disabled: !__props.text }, {
				default: withCtx(() => [createVNode(TooltipTrigger_default, { "as-child": "" }, {
					default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
					_: 3
				}), createVNode(TooltipContent_default, { side: __props.side }, {
					default: withCtx(() => [renderSlot(_ctx.$slots, "content", {}, () => [createTextVNode(toDisplayString(__props.text), 1)])]),
					_: 3
				}, 8, ["side"])]),
				_: 3
			}, 8, ["disabled"]);
		};
	}
});
//#endregion
//#region src/components/ui/button/Button.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = {
	key: 0,
	class: "icon-[lucide--loader-circle] size-4 shrink-0 animate-spin",
	"aria-hidden": "true"
};
var _hoisted_2 = {
	key: 1,
	class: "sr-only"
};
var _hoisted_3 = {
	key: 3,
	"aria-hidden": "true",
	class: "pointer-events-none absolute -top-1 -right-1 size-2 rounded-full bg-foreground"
};
//#endregion
//#region src/components/ui/button/Button.vue
var Button_default = /* @__PURE__ */ defineComponent({
	inheritAttrs: false,
	__name: "Button",
	props: {
		class: {
			type: [
				Boolean,
				null,
				String,
				Object,
				Array
			],
			default: ""
		},
		disabled: {
			type: Boolean,
			default: false
		},
		icon: {},
		indicator: { type: Boolean },
		loading: {
			type: Boolean,
			default: false
		},
		size: {},
		tooltip: {},
		tooltipSide: {},
		variant: {},
		asChild: { type: Boolean },
		as: { default: "button" }
	},
	setup(__props) {
		const WithoutTooltip = (_, { slots }) => slots.default?.()[0];
		return (_ctx, _cache) => {
			return openBlock(), createBlock(resolveDynamicComponent(__props.tooltip === void 0 ? WithoutTooltip : TextTooltip_default), {
				text: __props.tooltip,
				side: __props.tooltipSide
			}, createSlots({
				default: withCtx(() => [createVNode(unref(Primitive), mergeProps({
					as: __props.as,
					"as-child": __props.asChild,
					disabled: __props.disabled || __props.loading,
					"aria-busy": __props.loading || void 0,
					"data-variant": __props.variant,
					class: unref(cn)(unref(buttonVariants)({
						variant: __props.variant,
						size: __props.size
					}), __props.class)
				}, _ctx.$attrs), {
					default: withCtx(() => [
						__props.loading ? (openBlock(), createElementBlock("i", _hoisted_1)) : createCommentVNode("", true),
						__props.loading ? (openBlock(), createElementBlock("span", _hoisted_2, [renderSlot(_ctx.$slots, "default")])) : (openBlock(), createElementBlock(Fragment, { key: 2 }, [__props.icon ? (openBlock(), createElementBlock("i", {
							key: 0,
							class: normalizeClass(unref(cn)(__props.icon, "size-4 shrink-0")),
							"aria-hidden": "true"
						}, null, 2)) : createCommentVNode("", true), renderSlot(_ctx.$slots, "default")], 64)),
						__props.indicator ? (openBlock(), createElementBlock("span", _hoisted_3)) : createCommentVNode("", true)
					]),
					_: 3
				}, 16, [
					"as",
					"as-child",
					"disabled",
					"aria-busy",
					"data-variant",
					"class"
				])]),
				_: 2
			}, [_ctx.$slots.tooltip ? {
				name: "content",
				fn: withCtx(() => [renderSlot(_ctx.$slots, "tooltip")]),
				key: "0"
			} : void 0]), 1032, ["text", "side"]);
		};
	}
});
//#endregion
export { TooltipTrigger_default as a, appTooltipProviderDefaults as c, cva as i, TextTooltip_default as n, TooltipContent_default as o, buttonVariants as r, Tooltip_default as s, Button_default as t };
