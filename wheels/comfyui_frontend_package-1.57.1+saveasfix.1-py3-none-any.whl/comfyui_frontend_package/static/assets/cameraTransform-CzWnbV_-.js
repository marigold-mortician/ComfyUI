import "./rolldown-runtime-xtsTai4I.js";
import { Ut as Vector3, ct as Matrix4, gt as PerspectiveCamera, ht as OrthographicCamera, wt as Quaternion } from "./vendor-three-B-UiePqj.js";
import { E as withModifiers, F as createBaseVNode, Ft as ref, G as defineComponent, Kt as normalizeClass, L as createCommentVNode, R as createElementBlock, Wt as unref, ct as openBlock, dt as renderSlot } from "./vendor-vue-core-CuN1excl.js";
import { t as cn } from "./src-BHQtMnZc.js";
//#region src/extensions/core/load3d/components/ViewportWidgetShell.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "pointer-events-none absolute inset-x-0 top-0" };
var _hoisted_2 = {
	key: 0,
	class: "pointer-events-none absolute inset-x-0 bottom-0"
};
//#endregion
//#region src/extensions/core/load3d/components/ViewportWidgetShell.vue
var ViewportWidgetShell_default = /* @__PURE__ */ defineComponent({
	__name: "ViewportWidgetShell",
	props: { bottomClass: {} },
	emits: ["mouseenter", "mouseleave"],
	setup(__props, { expose: __expose, emit: __emit }) {
		const emit = __emit;
		const container = ref(null);
		const toolbar = ref(null);
		function focusContainer() {
			container.value?.focus();
		}
		__expose({
			container,
			toolbar
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				class: "relative size-full min-h-[300px]",
				onPointerdown: _cache[5] || (_cache[5] = withModifiers(() => {}, ["stop"])),
				onMousedown: _cache[6] || (_cache[6] = withModifiers(() => {}, ["stop"]))
			}, [
				createBaseVNode("div", {
					ref_key: "container",
					ref: container,
					class: "relative size-full",
					"data-capture-wheel": "true",
					tabindex: "-1",
					onPointerdown: withModifiers(focusContainer, ["stop"]),
					onContextmenu: _cache[0] || (_cache[0] = withModifiers(() => {}, ["stop", "prevent"])),
					onMouseenter: _cache[1] || (_cache[1] = ($event) => emit("mouseenter")),
					onMouseleave: _cache[2] || (_cache[2] = ($event) => emit("mouseleave"))
				}, null, 544),
				createBaseVNode("div", _hoisted_1, [createBaseVNode("div", {
					ref_key: "toolbar",
					ref: toolbar,
					class: "pointer-events-auto flex h-10 items-center gap-1 bg-popover px-2",
					onWheel: _cache[3] || (_cache[3] = withModifiers(() => {}, ["stop"]))
				}, [renderSlot(_ctx.$slots, "top")], 544)]),
				_ctx.$slots.bottom ? (openBlock(), createElementBlock("div", _hoisted_2, [createBaseVNode("div", {
					class: normalizeClass(unref(cn)("pointer-events-auto flex h-10 items-center gap-1 bg-popover px-2", __props.bottomClass)),
					onWheel: _cache[4] || (_cache[4] = withModifiers(() => {}, ["stop"]))
				}, [renderSlot(_ctx.$slots, "bottom")], 34)])) : createCommentVNode("", true)
			], 32);
		};
	}
});
//#endregion
//#region packages/viewport3d/src/cameraInfo/handles/pointerInteraction.ts
var PointerInteraction = class {
	host;
	handleDrag = null;
	freeDrag = null;
	hovered = null;
	pendingRotation = null;
	pendingDolly = null;
	pendingDragPointer = null;
	pendingHoverPointer = null;
	inputFrame = null;
	constructor(host) {
		this.host = host;
	}
	get hoveredHandle() {
		return this.hovered;
	}
	attach() {
		const canvas = this.host.canvas;
		canvas.addEventListener("pointerdown", this.onPointerDown);
		canvas.addEventListener("pointermove", this.onPointerMove);
		canvas.addEventListener("pointerup", this.onPointerUp);
		canvas.addEventListener("pointercancel", this.onPointerUp);
		canvas.addEventListener("pointerleave", this.onPointerLeave);
		canvas.addEventListener("wheel", this.onWheel, { passive: false });
	}
	detach() {
		const canvas = this.host.canvas;
		canvas.removeEventListener("pointerdown", this.onPointerDown);
		canvas.removeEventListener("pointermove", this.onPointerMove);
		canvas.removeEventListener("pointerup", this.onPointerUp);
		canvas.removeEventListener("pointercancel", this.onPointerUp);
		canvas.removeEventListener("pointerleave", this.onPointerLeave);
		canvas.removeEventListener("wheel", this.onWheel);
	}
	cancel() {
		this.cancelInputFrame();
		const wasDraggingHandle = this.handleDrag !== null;
		this.handleDrag = null;
		this.freeDrag = null;
		if (wasDraggingHandle) this.host.handleDragChanged(false);
		this.setHovered(null);
		this.host.canvas.style.cursor = this.host.idleCursor();
	}
	setHovered(type) {
		if (this.hovered === type) return;
		this.hovered = type;
		this.host.hoverChanged(type);
		this.host.canvas.style.cursor = this.host.idleCursor();
	}
	onPointerDown = (event) => {
		if (event.button !== 0) return;
		const type = this.host.pickHandle(event);
		if (type) {
			this.pendingHoverPointer = null;
			this.setHovered(type);
			this.handleDrag = {
				type,
				pointerId: event.pointerId
			};
			this.host.handleDragChanged(true);
		} else if (this.host.freeDragEnabled()) this.freeDrag = {
			pointerId: event.pointerId,
			lastX: event.clientX,
			lastY: event.clientY
		};
		else return;
		this.host.canvas.setPointerCapture(event.pointerId);
		this.host.canvas.style.cursor = "grabbing";
		event.stopPropagation();
	};
	onPointerMove = (event) => {
		if (this.freeDrag) {
			if (event.pointerId !== this.freeDrag.pointerId) return;
			const dx = event.clientX - this.freeDrag.lastX;
			const dy = event.clientY - this.freeDrag.lastY;
			this.freeDrag.lastX = event.clientX;
			this.freeDrag.lastY = event.clientY;
			this.pendingRotation = {
				dx: (this.pendingRotation?.dx ?? 0) + dx,
				dy: (this.pendingRotation?.dy ?? 0) + dy
			};
			this.scheduleInputFrame();
			return;
		}
		if (!this.handleDrag) {
			this.pendingHoverPointer = {
				clientX: event.clientX,
				clientY: event.clientY
			};
			this.scheduleInputFrame();
			return;
		}
		if (event.pointerId !== this.handleDrag.pointerId) return;
		this.pendingDragPointer = {
			clientX: event.clientX,
			clientY: event.clientY
		};
		this.scheduleInputFrame();
	};
	onPointerUp = (event) => {
		const active = this.freeDrag ?? this.handleDrag;
		if (!active || event.pointerId !== active.pointerId) return;
		this.flushInput();
		this.cancelInputFrame();
		if (this.host.canvas.hasPointerCapture(event.pointerId)) this.host.canvas.releasePointerCapture(event.pointerId);
		const wasDraggingHandle = this.handleDrag !== null;
		this.freeDrag = null;
		this.handleDrag = null;
		if (wasDraggingHandle) this.host.handleDragChanged(false);
		this.host.canvas.style.cursor = this.host.idleCursor();
	};
	onPointerLeave = () => {
		if (this.handleDrag || this.freeDrag) return;
		this.pendingHoverPointer = null;
		this.setHovered(null);
	};
	onWheel = (event) => {
		if (!this.host.wheelEnabled()) return;
		event.preventDefault();
		event.stopPropagation();
		this.pendingDolly = (this.pendingDolly ?? 0) + event.deltaY;
		this.scheduleInputFrame();
	};
	scheduleInputFrame() {
		if (this.inputFrame !== null) return;
		this.inputFrame = requestAnimationFrame(() => {
			this.inputFrame = null;
			this.flushInput();
		});
	}
	flushInput() {
		const rotation = this.pendingRotation;
		const dolly = this.pendingDolly;
		const dragPointer = this.pendingDragPointer;
		const hoverPointer = this.pendingHoverPointer;
		this.pendingRotation = null;
		this.pendingDolly = null;
		this.pendingDragPointer = null;
		this.pendingHoverPointer = null;
		if (dragPointer && this.handleDrag) this.host.dragHandle(this.handleDrag.type, dragPointer);
		else if (hoverPointer && !this.handleDrag) this.setHovered(this.host.pickHandle(hoverPointer));
		if (rotation) this.host.freeDrag(rotation.dx, rotation.dy);
		if (dolly !== null) this.host.wheel(dolly);
	}
	cancelInputFrame() {
		if (this.inputFrame !== null) {
			cancelAnimationFrame(this.inputFrame);
			this.inputFrame = null;
		}
		this.pendingRotation = null;
		this.pendingDolly = null;
		this.pendingDragPointer = null;
		this.pendingHoverPointer = null;
	}
};
var PREVIEW_PADDING = 8;
var PREVIEW_BORDER_COLOR = 2763306;
var PREVIEW_BACKGROUND_COLOR = 657930;
var DEFAULT_LAYOUT = {
	width: 200,
	height: 150,
	marginRight: PREVIEW_PADDING,
	marginBottom: PREVIEW_PADDING
};
function fitCameraAspect(camera, aspect) {
	if (!Number.isFinite(aspect) || aspect <= 0) return;
	if (camera instanceof PerspectiveCamera) {
		if (Math.abs(camera.aspect - aspect) < 1e-4) return;
		camera.aspect = aspect;
		camera.updateProjectionMatrix();
		return;
	}
	if (camera instanceof OrthographicCamera) {
		const half = (camera.top - camera.bottom) / 2 || 1;
		const left = -half * aspect;
		const right = half * aspect;
		if (Math.abs(camera.left - left) < 1e-4 && Math.abs(camera.right - right) < 1e-4) return;
		camera.left = left;
		camera.right = right;
		camera.updateProjectionMatrix();
	}
}
function withPreviewAspect(camera, aspect, render) {
	if (camera instanceof PerspectiveCamera) {
		const saved = camera.aspect;
		camera.aspect = aspect;
		camera.updateProjectionMatrix();
		render();
		camera.aspect = saved;
		camera.updateProjectionMatrix();
		return;
	}
	if (camera instanceof OrthographicCamera) {
		const { left, right, top, bottom } = camera;
		const half = (top - bottom) / 2 || 1;
		camera.left = -half * aspect;
		camera.right = half * aspect;
		camera.top = half;
		camera.bottom = -half;
		camera.updateProjectionMatrix();
		render();
		Object.assign(camera, {
			left,
			right,
			top,
			bottom
		});
		camera.updateProjectionMatrix();
		return;
	}
	render();
}
function fitsCanvas({ width, height, marginRight, marginBottom }, canvas) {
	return width > 0 && height > 0 && canvas.width >= width + marginRight * 2 && canvas.height >= height + marginBottom + PREVIEW_PADDING;
}
function renderInsetPreview({ renderer, view, canvas, scene, camera, hidden, layout = DEFAULT_LAYOUT, borderColor = PREVIEW_BORDER_COLOR, backgroundColor = PREVIEW_BACKGROUND_COLOR }) {
	if (!fitsCanvas(layout, canvas)) return;
	const { width, height, marginRight, marginBottom } = layout;
	const restore = hidden.filter((item) => item.isVisible()).map((item) => () => item.setVisible(true));
	for (const item of hidden) item.setVisible(false);
	const x = canvas.width - width - marginRight;
	const y = marginBottom;
	withPreviewAspect(camera, width / height, () => {
		view.setViewport(x - 1, y - 1, width + 2, height + 2);
		view.setScissor(x - 1, y - 1, width + 2, height + 2);
		view.setScissorTest(true);
		renderer.setClearColor(borderColor);
		renderer.clear();
		view.setViewport(x, y, width, height);
		view.setScissor(x, y, width, height);
		renderer.setClearColor(backgroundColor);
		renderer.clear();
		renderer.render(scene, camera);
	});
	for (const restoreItem of restore) restoreItem();
}
//#endregion
//#region packages/viewport3d/src/cameraInfo/cameraTransform.ts
var DEG2RAD = Math.PI / 180;
function orbitPosition(target, yawDeg, pitchDeg, distance) {
	const y = yawDeg * DEG2RAD;
	const p = pitchDeg * DEG2RAD;
	const cp = Math.cos(p);
	return new Vector3(target.x + distance * cp * Math.sin(y), target.y + distance * Math.sin(p), target.z + distance * cp * Math.cos(y));
}
function lookAtQuaternion(position, target, rollDeg) {
	const targetVec = new Vector3(target.x, target.y, target.z);
	const m = new Matrix4().lookAt(position, targetVec, new Vector3(0, 1, 0));
	const q = new Quaternion().setFromRotationMatrix(m);
	if (rollDeg !== 0) {
		const rollQ = new Quaternion().setFromAxisAngle(new Vector3(0, 0, 1), rollDeg * DEG2RAD);
		q.multiply(rollQ);
	}
	return q;
}
function normalizeQuaternion(q) {
	if (q.lengthSq() === 0) q.set(0, 0, 0, 1);
	else q.normalize();
	return q;
}
function computeSubjectTransform(state) {
	if (state.mode === "quaternion") {
		const p = state.quaternion.position;
		const q = state.quaternion.quat;
		const quaternion = normalizeQuaternion(new Quaternion(q.x, q.y, q.z, q.w));
		return {
			position: new Vector3(p.x, p.y, p.z),
			quaternion
		};
	}
	const position = state.mode === "orbit" ? orbitPosition(state.target, state.orbit.yaw, state.orbit.pitch, state.orbit.distance) : new Vector3(state.lookAt.position.x, state.lookAt.position.y, state.lookAt.position.z);
	return {
		position,
		quaternion: lookAtQuaternion(position, state.target, state.roll)
	};
}
//#endregion
export { PointerInteraction as a, renderInsetPreview as i, normalizeQuaternion as n, ViewportWidgetShell_default as o, fitCameraAspect as r, computeSubjectTransform as t };
