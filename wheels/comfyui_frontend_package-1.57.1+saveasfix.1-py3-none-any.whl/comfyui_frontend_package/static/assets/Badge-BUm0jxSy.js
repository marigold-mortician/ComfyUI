import "./rolldown-runtime-xtsTai4I.js";
import { F as createBaseVNode, G as defineComponent, I as createBlock, Kt as normalizeClass, L as createCommentVNode, R as createElementBlock, Wt as unref, ct as openBlock, dt as renderSlot, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { i as cva, t as Button_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
//#region src/components/ui/badge/badge.variants.ts
var badgeVariants = cva({
	base: "inline-flex shrink-0 items-center justify-center gap-1 font-medium whitespace-nowrap",
	variants: {
		variant: {
			tag: "rounded-md px-2 py-1 text-sm font-bold",
			chip: "min-h-7 rounded-full px-2 py-1 text-sm",
			badge: "min-h-5 min-w-5 rounded-full px-1.5 text-xs",
			compact: "h-5 rounded-full px-2 py-0.5 text-xs normal-case",
			label: "h-3.5 rounded-full px-1 text-3xs font-semibold uppercase",
			circle: "size-3.5 rounded-full text-3xs font-semibold",
			outline: "rounded-sm border px-1.5 py-0.5 text-2xs",
			square: "rounded-sm px-1.5 py-0.5 text-xs",
			pill: "rounded-full px-2 py-0.5 text-2xs",
			dot: "size-2 rounded-full p-0"
		},
		severity: {
			default: "bg-primary text-foreground",
			contrast: "bg-foreground text-background",
			primary: "bg-primary/10 text-foreground",
			secondary: "bg-secondary text-foreground",
			muted: "bg-muted text-muted-foreground",
			danger: "bg-destructive text-foreground",
			info: "bg-primary/20 text-foreground",
			success: "bg-success/15 text-foreground",
			warning: "bg-warning text-warning-foreground"
		}
	},
	compoundVariants: [{
		variant: "outline",
		class: "bg-transparent text-foreground"
	}],
	defaultVariants: {
		variant: "tag",
		severity: "secondary"
	}
});
//#endregion
//#region src/components/ui/badge/Badge.vue
var Badge_default = /* @__PURE__ */ defineComponent({
	__name: "Badge",
	props: {
		variant: {},
		severity: {},
		class: {
			type: [
				Boolean,
				null,
				String,
				Object,
				Array
			],
			default: ""
		},
		removable: { type: Boolean },
		removeLabel: {}
	},
	emits: ["remove"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("span", { class: normalizeClass(unref(cn)(unref(badgeVariants)({
				variant: __props.variant,
				severity: __props.severity
			}), __props.class)) }, [
				renderSlot(_ctx.$slots, "icon"),
				renderSlot(_ctx.$slots, "default"),
				__props.removable ? (openBlock(), createBlock(Button_default, {
					key: 0,
					type: "button",
					variant: "textonly",
					size: "icon-sm",
					class: "-mr-1 rounded-full text-current",
					"aria-label": __props.removeLabel,
					onClick: _cache[0] || (_cache[0] = ($event) => emit("remove", $event))
				}, {
					default: withCtx(() => [..._cache[1] || (_cache[1] = [createBaseVNode("i", {
						class: "icon-[lucide--x] size-3",
						"aria-hidden": "true"
					}, null, -1)])]),
					_: 1
				}, 8, ["aria-label"])) : createCommentVNode("", true)
			], 2);
		};
	}
});
//#endregion
export { Badge_default as t };
