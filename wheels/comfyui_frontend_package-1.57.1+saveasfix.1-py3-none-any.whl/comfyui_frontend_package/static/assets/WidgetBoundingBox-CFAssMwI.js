import "./rolldown-runtime-xtsTai4I.js";
import { Rt as isBoundsObject } from "./litegraph-DsPnoImk.js";
import { $ as mergeModels, At as isRef, F as createBaseVNode, G as defineComponent, I as createBlock, L as createCommentVNode, P as computed, R as createElementBlock, U as createVNode, Wt as unref, Yt as toDisplayString, _t as useModel, ct as openBlock, tt as nextTick } from "./vendor-vue-core-CuN1excl.js";
import { i as WidgetHistoryButtons_default, n as widgetHistoryScope, r as useWidgetValueHistory } from "./widgetHistoryScope-CDAdgtIP.js";
import { t as ScrubableNumberInput_default } from "./ScrubableNumberInput-Dig5Z8Hb.js";
//#region src/components/boundingbox/WidgetBoundingBox.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = {
	class: "flex flex-col gap-1",
	"data-testid": "bounding-box"
};
var _hoisted_2 = { class: "grid grid-cols-[auto_1fr] gap-x-2 gap-y-1 text-xs" };
var _hoisted_3 = { class: "content-center" };
var _hoisted_4 = { class: "content-center" };
var _hoisted_5 = { class: "content-center" };
var _hoisted_6 = { class: "content-center" };
//#endregion
//#region src/components/boundingbox/WidgetBoundingBox.vue
var WidgetBoundingBox_default = /* @__PURE__ */ defineComponent({
	__name: "WidgetBoundingBox",
	props: /*@__PURE__*/ mergeModels({
		disabled: {
			type: Boolean,
			default: false
		},
		widget: {},
		nodeId: {}
	}, {
		"modelValue": { default: () => ({
			x: 0,
			y: 0,
			width: 512,
			height: 512
		}) },
		"modelModifiers": {}
	}),
	emits: /*@__PURE__*/ mergeModels(["editEnd"], ["update:modelValue"]),
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const modelValue = useModel(__props, "modelValue");
		const { canUndo, canRedo, undo, redo, commit } = useWidgetValueHistory({
			scope: () => __props.widget ? widgetHistoryScope(__props.widget, __props.nodeId) : null,
			read: () => modelValue.value,
			apply: (value) => {
				if (isBoundsObject(value)) modelValue.value = value;
			}
		});
		function boundsField(field) {
			return computed({
				get: () => modelValue.value[field],
				set: (value) => {
					modelValue.value = {
						...modelValue.value,
						[field]: value
					};
					emit("editEnd", field);
					nextTick(() => commit(field));
				}
			});
		}
		const x = boundsField("x");
		const y = boundsField("y");
		const width = boundsField("width");
		const height = boundsField("height");
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1, [__props.widget ? (openBlock(), createBlock(WidgetHistoryButtons_default, {
				key: 0,
				class: "self-end",
				"can-undo": unref(canUndo),
				"can-redo": unref(canRedo),
				onUndo: unref(undo),
				onRedo: unref(redo)
			}, null, 8, [
				"can-undo",
				"can-redo",
				"onUndo",
				"onRedo"
			])) : createCommentVNode("", true), createBaseVNode("div", _hoisted_2, [
				createBaseVNode("label", _hoisted_3, toDisplayString(_ctx.$t("boundingBox.x")), 1),
				createVNode(ScrubableNumberInput_default, {
					modelValue: unref(x),
					"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(x) ? x.value = $event : null),
					min: 0,
					step: 1,
					disabled: __props.disabled,
					"data-testid": "bounding-box-x"
				}, null, 8, ["modelValue", "disabled"]),
				createBaseVNode("label", _hoisted_4, toDisplayString(_ctx.$t("boundingBox.y")), 1),
				createVNode(ScrubableNumberInput_default, {
					modelValue: unref(y),
					"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(y) ? y.value = $event : null),
					min: 0,
					step: 1,
					disabled: __props.disabled,
					"data-testid": "bounding-box-y"
				}, null, 8, ["modelValue", "disabled"]),
				createBaseVNode("label", _hoisted_5, toDisplayString(_ctx.$t("boundingBox.width")), 1),
				createVNode(ScrubableNumberInput_default, {
					modelValue: unref(width),
					"onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(width) ? width.value = $event : null),
					min: 1,
					step: 1,
					disabled: __props.disabled,
					"data-testid": "bounding-box-width"
				}, null, 8, ["modelValue", "disabled"]),
				createBaseVNode("label", _hoisted_6, toDisplayString(_ctx.$t("boundingBox.height")), 1),
				createVNode(ScrubableNumberInput_default, {
					modelValue: unref(height),
					"onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => isRef(height) ? height.value = $event : null),
					min: 1,
					step: 1,
					disabled: __props.disabled,
					"data-testid": "bounding-box-height"
				}, null, 8, ["modelValue", "disabled"])
			])]);
		};
	}
});
//#endregion
export { WidgetBoundingBox_default as t };
