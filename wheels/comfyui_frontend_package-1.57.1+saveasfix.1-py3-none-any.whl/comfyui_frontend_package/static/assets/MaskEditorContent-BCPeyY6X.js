import { a as __toESM, n as __exportAll, r as __name } from "./rolldown-runtime-xtsTai4I.js";
import { t as debounce } from "./debounce-CrddqoI1.js";
import { n as useSettingStore } from "./settingStore-DRRi2kOn.js";
import { C as vModelText, E as withModifiers, F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, I as createBlock, Jt as normalizeStyle, Kt as normalizeClass, L as createCommentVNode, O as Fragment, P as computed, R as createElementBlock, Tt as withDirectives, U as createVNode, Wt as unref, Yt as toDisplayString, at as onMounted, bt as watch, ct as openBlock, ot as onUnmounted, pt as resolveDynamicComponent, rt as onBeforeUnmount, tt as nextTick, ut as renderList, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { Fr as createSharedComposable, tr as useElementBounding } from "./vendor-reka-ui-NRTk7aIV.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as cn$2 } from "./src-BHQtMnZc.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
import { i as setStorageValue, n as getStorageValue } from "./utils-DPLBHlcF.js";
import { t as require_quick_lru } from "./quick-lru-CwZ_Nev1.js";
import { a as MaskBlendMode, i as CompositionOperation, n as BrushShape, o as Tools, r as ColorComparisonMethod, s as allTools, t as useMaskEditorStore } from "./maskEditorStore-2_6OgZyt.js";
import { t as LoadingOverlay_default } from "./LoadingOverlay-BMlANKim.js";
import { r as useMaskEditorDataStore } from "./imageWidgetAdapter-B1Eu9NmR.js";
import { n as useMaskEditorLoader } from "./useMaskEditorLoader-Bm0ZG91F.js";
import { n as hexToRgb, r as parseToRgb, t as useCanvasTools } from "./useCanvasTools-BUULrHPz.js";
import { i as getEffectiveHardness, n as resampleSegment, r as getEffectiveBrushSize, t as StrokeProcessor } from "./StrokeProcessor-DnTwSoJ2.js";
//#region src/renderer/extensions/maskEditor/composables/useBrushPersistence.ts
var STORAGE_KEY = "maskeditor_brush_settings";
function loadBrushFromStorage() {
	try {
		const brushString = getStorageValue(STORAGE_KEY);
		if (brushString) return JSON.parse(brushString);
		return null;
	} catch (error) {
		console.error("Failed to load brush from cache:", error);
		return null;
	}
}
var debouncedWrite = debounce((serialized) => {
	try {
		setStorageValue(STORAGE_KEY, serialized);
	} catch (error) {
		console.error("Failed to save brush to cache:", error);
	}
}, 300);
function useBrushPersistence() {
	const store = useMaskEditorStore();
	function save() {
		debouncedWrite(JSON.stringify(store.brushSettings));
	}
	function loadAndApply() {
		const cached = loadBrushFromStorage();
		if (!cached) return;
		store.setBrushSize(cached.size);
		store.setBrushOpacity(cached.opacity);
		store.setBrushHardness(cached.hardness);
		store.brushSettings.type = cached.type;
		store.setBrushStepSize(cached.stepSize ?? 5);
	}
	return {
		loadAndApply,
		save
	};
}
//#endregion
//#region packages/mask-editor/src/useCanvasManager.ts
function useCanvasManager() {
	const store = useMaskEditorStore();
	const prepareMask = async (image, maskCanvasEl, maskContext) => {
		const maskColor = store.maskColor;
		maskContext.drawImage(image, 0, 0, maskCanvasEl.width, maskCanvasEl.height);
		const maskData = maskContext.getImageData(0, 0, maskCanvasEl.width, maskCanvasEl.height);
		for (let i = 0; i < maskData.data.length; i += 4) {
			const alpha = maskData.data[i + 3];
			maskData.data[i] = maskColor.r;
			maskData.data[i + 1] = maskColor.g;
			maskData.data[i + 2] = maskColor.b;
			maskData.data[i + 3] = 255 - alpha;
		}
		maskContext.globalCompositeOperation = "source-over";
		maskContext.putImageData(maskData, 0, 0);
	};
	const invalidateCanvas = async (origImage, maskImage, paintImage) => {
		const { imgCanvas, maskCanvas, rgbCanvas, imgCtx, maskCtx, rgbCtx } = store;
		if (!imgCanvas || !maskCanvas || !rgbCanvas || !imgCtx || !maskCtx || !rgbCtx) throw new Error("Canvas elements or contexts not available");
		imgCanvas.width = origImage.width;
		imgCanvas.height = origImage.height;
		maskCanvas.width = origImage.width;
		maskCanvas.height = origImage.height;
		rgbCanvas.width = origImage.width;
		rgbCanvas.height = origImage.height;
		imgCtx.drawImage(origImage, 0, 0, origImage.width, origImage.height);
		if (paintImage) rgbCtx.drawImage(paintImage, 0, 0, paintImage.width, paintImage.height);
		await prepareMask(maskImage, maskCanvas, maskCtx);
	};
	const setCanvasBackground = () => {
		const canvasBackground = store.canvasBackground;
		if (!canvasBackground) return;
		if (store.maskBlendMode === MaskBlendMode.Black) canvasBackground.style.backgroundColor = "rgba(0,0,0,1)";
		else if (store.maskBlendMode === MaskBlendMode.White) canvasBackground.style.backgroundColor = "rgba(255,255,255,1)";
		else canvasBackground.style.backgroundColor = "rgba(255,255,255,1)";
	};
	const updateMaskColor = async () => {
		const { maskCanvas, maskCtx, maskColor, maskBlendMode, maskOpacity } = store;
		if (!maskCanvas || !maskCtx) return;
		if (maskBlendMode === MaskBlendMode.Negative) {
			maskCanvas.style.mixBlendMode = "difference";
			maskCanvas.style.opacity = "1";
		} else {
			maskCanvas.style.mixBlendMode = "initial";
			maskCanvas.style.opacity = String(maskOpacity);
		}
		maskCtx.fillStyle = `rgb(${maskColor.r}, ${maskColor.g}, ${maskColor.b})`;
		setCanvasBackground();
		const maskData = maskCtx.getImageData(0, 0, maskCanvas.width, maskCanvas.height);
		for (let i = 0; i < maskData.data.length; i += 4) {
			maskData.data[i] = maskColor.r;
			maskData.data[i + 1] = maskColor.g;
			maskData.data[i + 2] = maskColor.b;
		}
		maskCtx.putImageData(maskData, 0, 0);
	};
	return {
		invalidateCanvas,
		updateMaskColor
	};
}
//#endregion
//#region src/renderer/extensions/maskEditor/composables/useImageLoader.ts
function useImageLoaderInternal() {
	const store = useMaskEditorStore();
	const dataStore = useMaskEditorDataStore();
	const canvasManager = useCanvasManager();
	const loadImages = async () => {
		const inputData = dataStore.inputData;
		if (!inputData) throw new Error("No input data available in dataStore");
		const { imgCanvas, maskCanvas, rgbCanvas, imgCtx, maskCtx } = store;
		if (!imgCanvas || !maskCanvas || !rgbCanvas || !imgCtx || !maskCtx) throw new Error("Canvas elements or contexts not available");
		imgCtx.clearRect(0, 0, imgCanvas.width, imgCanvas.height);
		maskCtx.clearRect(0, 0, maskCanvas.width, maskCanvas.height);
		const baseImage = inputData.baseLayer.image;
		const maskImage = inputData.maskLayer.image;
		const paintImage = inputData.paintLayer?.image;
		maskCanvas.width = baseImage.width;
		maskCanvas.height = baseImage.height;
		rgbCanvas.width = baseImage.width;
		rgbCanvas.height = baseImage.height;
		store.image = baseImage;
		await canvasManager.invalidateCanvas(baseImage, maskImage, paintImage || null);
		await canvasManager.updateMaskColor();
		return baseImage;
	};
	return { loadImages };
}
var useImageLoader = createSharedComposable(useImageLoaderInternal);
//#endregion
//#region packages/mask-editor/src/useKeyboard.ts
function isTextEntryTarget(element) {
	return element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement || element instanceof HTMLElement && element.isContentEditable;
}
function useKeyboard(containerRef) {
	const store = useMaskEditorStore();
	const keysDown = ref([]);
	const isKeyDown = (key) => {
		return keysDown.value.includes(key);
	};
	const clearKeys = () => {
		keysDown.value = [];
	};
	const handleSpaceKey = (event) => {
		const activeElement = document.activeElement;
		const isStuckInsideEditor = activeElement !== null && !!containerRef?.value?.contains(activeElement);
		if (isTextEntryTarget(activeElement) && !isStuckInsideEditor) return;
		event.preventDefault();
		if (activeElement instanceof HTMLElement) activeElement.blur();
	};
	const handleKeyDown = (event) => {
		if (!keysDown.value.includes(event.key)) keysDown.value.push(event.key);
		if (event.key === " ") handleSpaceKey(event);
		if ((event.ctrlKey || event.metaKey) && !event.altKey) {
			const key = event.key.toUpperCase();
			if (key === "Y" && !event.shiftKey || key === "Z" && event.shiftKey) store.canvasHistory.redo();
			else if (key === "Z" && !event.shiftKey) store.canvasHistory.undo();
		}
	};
	const handleKeyUp = (event) => {
		keysDown.value = keysDown.value.filter((key) => key !== event.key);
	};
	const addListeners = () => {
		document.addEventListener("keydown", handleKeyDown, true);
		document.addEventListener("keyup", handleKeyUp);
		window.addEventListener("blur", clearKeys);
	};
	const removeListeners = () => {
		document.removeEventListener("keydown", handleKeyDown, true);
		document.removeEventListener("keyup", handleKeyUp);
		window.removeEventListener("blur", clearKeys);
	};
	return {
		isKeyDown,
		addListeners,
		removeListeners
	};
}
//#endregion
//#region packages/mask-editor/src/panZoomUtils.ts
var ZOOM_MIN = .2;
var ZOOM_MAX = 10;
function calculateFitView(params) {
	const { rootWidth, rootHeight, imageWidth, imageHeight, toolPanelWidth, sidePanelWidth } = params;
	const availableWidth = rootWidth - sidePanelWidth - toolPanelWidth;
	const availableHeight = rootHeight;
	const zoomRatioWidth = availableWidth / imageWidth;
	const zoomRatioHeight = availableHeight / imageHeight;
	const zoomRatio = Math.min(zoomRatioWidth, zoomRatioHeight);
	const aspectRatio = imageWidth / imageHeight;
	const panOffset = {
		x: toolPanelWidth,
		y: 0
	};
	let fittedWidth;
	let fittedHeight;
	if (zoomRatioHeight > zoomRatioWidth) {
		fittedWidth = availableWidth;
		fittedHeight = fittedWidth / aspectRatio;
		panOffset.y = (availableHeight - fittedHeight) / 2;
	} else {
		fittedHeight = availableHeight;
		fittedWidth = fittedHeight * aspectRatio;
		panOffset.x = (availableWidth - fittedWidth) / 2 + toolPanelWidth;
	}
	return {
		zoomRatio,
		panOffset,
		fittedWidth,
		fittedHeight
	};
}
function clampZoom(zoom) {
	return Math.max(ZOOM_MIN, Math.min(ZOOM_MAX, zoom));
}
function getWheelZoomFactor(deltaY) {
	return deltaY < 0 ? 1.1 : .9;
}
function calculateZoomAroundPoint(currentZoom, zoomFactor, panOffset, focalX, focalY) {
	const newZoom = clampZoom(currentZoom * zoomFactor);
	const scaleFactor = newZoom / currentZoom;
	return {
		zoomRatio: newZoom,
		panOffset: {
			x: panOffset.x + focalX - focalX * scaleFactor,
			y: panOffset.y + focalY - focalY * scaleFactor
		}
	};
}
function calculateDragPan(mouseDownPoint, currentPoint, initialPan) {
	return {
		x: initialPan.x - (mouseDownPoint.x - currentPoint.x),
		y: initialPan.y - (mouseDownPoint.y - currentPoint.y)
	};
}
function calculateSingleTouchPan(lastPoint, currentPoint, panOffset) {
	return {
		x: panOffset.x + (currentPoint.x - lastPoint.x),
		y: panOffset.y + (currentPoint.y - lastPoint.y)
	};
}
function getDistanceBetweenPoints(a, b) {
	const dx = a.x - b.x;
	const dy = a.y - b.y;
	return Math.sqrt(dx * dx + dy * dy);
}
function getMidpoint(a, b) {
	return {
		x: (a.x + b.x) / 2,
		y: (a.y + b.y) / 2
	};
}
function getCursorPoint(clientPoint, panOffset) {
	return {
		x: clientPoint.x - panOffset.x,
		y: clientPoint.y - panOffset.y
	};
}
function isDoubleTap(currentTime, lastTapTime, delay) {
	return currentTime - lastTapTime < delay;
}
function easeOutCubic(progress) {
	return 1 - Math.pow(1 - progress, 3);
}
function interpolateView(startZoom, targetZoom, startPan, targetPan, easedProgress) {
	return {
		zoomRatio: startZoom + (targetZoom - startZoom) * easedProgress,
		panOffset: {
			x: startPan.x + (targetPan.x - startPan.x) * easedProgress,
			y: startPan.y + (targetPan.y - startPan.y) * easedProgress
		}
	};
}
function calculatePanZoomStyles(imageWidth, imageHeight, zoomRatio, panOffset) {
	const rawWidth = imageWidth * zoomRatio;
	const rawHeight = imageHeight * zoomRatio;
	return {
		rawWidth,
		rawHeight,
		containerLeft: `${panOffset.x}px`,
		containerTop: `${panOffset.y}px`,
		containerWidth: `${rawWidth}px`,
		containerHeight: `${rawHeight}px`
	};
}
//#endregion
//#region packages/mask-editor/src/usePanAndZoom.ts
function usePanAndZoom() {
	const store = useMaskEditorStore();
	const DOUBLE_TAP_DELAY = 300;
	const lastTwoFingerTap = ref(0);
	const isTouchZooming = ref(false);
	const lastTouchZoomDistance = ref(0);
	const lastTouchMidPoint = ref({
		x: 0,
		y: 0
	});
	const lastTouchPoint = ref({
		x: 0,
		y: 0
	});
	const zoom_ratio = ref(1);
	const interpolatedZoomRatio = ref(1);
	const pan_offset = ref({
		x: 0,
		y: 0
	});
	const mouseDownPoint = ref(null);
	const initialPan = ref({
		x: 0,
		y: 0
	});
	const canvasContainer = ref(null);
	const maskCanvas = ref(null);
	const rgbCanvas = ref(null);
	const rootElement = ref(null);
	const toolPanelElement = ref(null);
	const sidePanelElement = ref(null);
	const image = ref(null);
	const imageRootWidth = ref(0);
	const imageRootHeight = ref(0);
	const cursorPoint = ref({
		x: 0,
		y: 0
	});
	const penPointerIdList = ref([]);
	const updateCursorPosition = (clientPoint) => {
		const point = getCursorPoint(clientPoint, pan_offset.value);
		cursorPoint.value = point;
		store.setCursorPoint(point);
	};
	const handleDoubleTap = () => {
		store.canvasHistory.undo();
	};
	const invalidatePanZoom = async () => {
		const currentImage = image.value;
		if (!currentImage?.width || !currentImage.height || !zoom_ratio.value) {
			console.warn("Missing required properties for pan/zoom");
			return;
		}
		const styles = calculatePanZoomStyles(currentImage.width, currentImage.height, zoom_ratio.value, pan_offset.value);
		if (!canvasContainer.value) canvasContainer.value = store.canvasContainer;
		if (!canvasContainer.value) return;
		Object.assign(canvasContainer.value.style, {
			width: styles.containerWidth,
			height: styles.containerHeight,
			left: styles.containerLeft,
			top: styles.containerTop
		});
		if (!rgbCanvas.value) rgbCanvas.value = store.rgbCanvas;
		if (rgbCanvas.value) {
			if (rgbCanvas.value.width !== currentImage.width || rgbCanvas.value.height !== currentImage.height) {
				rgbCanvas.value.width = currentImage.width;
				rgbCanvas.value.height = currentImage.height;
			}
			rgbCanvas.value.style.width = styles.containerWidth;
			rgbCanvas.value.style.height = styles.containerHeight;
		}
		store.setPanOffset(pan_offset.value);
		store.setZoomRatio(zoom_ratio.value);
	};
	const handlePanStart = (event) => {
		mouseDownPoint.value = {
			x: event.clientX,
			y: event.clientY
		};
		store.isPanning = true;
		initialPan.value = { ...pan_offset.value };
	};
	const handlePanMove = async (event) => {
		if (mouseDownPoint.value === null) {
			console.error("mouseDownPoint is null");
			return;
		}
		pan_offset.value = calculateDragPan(mouseDownPoint.value, {
			x: event.clientX,
			y: event.clientY
		}, initialPan.value);
		await invalidatePanZoom();
	};
	const handleSingleTouchPan = async (touch) => {
		pan_offset.value = calculateSingleTouchPan(lastTouchPoint.value, {
			x: touch.clientX,
			y: touch.clientY
		}, pan_offset.value);
		await invalidatePanZoom();
		lastTouchPoint.value = {
			x: touch.clientX,
			y: touch.clientY
		};
	};
	const touchToPoint = (touch) => ({
		x: touch.clientX,
		y: touch.clientY
	});
	const handleTouchStart = (event) => {
		event.preventDefault();
		if (penPointerIdList.value.length > 0) return;
		store.brushVisible = false;
		if (event.touches.length === 2) {
			const currentTime = (/* @__PURE__ */ new Date()).getTime();
			if (isDoubleTap(currentTime, lastTwoFingerTap.value, DOUBLE_TAP_DELAY)) {
				handleDoubleTap();
				lastTwoFingerTap.value = 0;
			} else {
				lastTwoFingerTap.value = currentTime;
				const p0 = touchToPoint(event.touches[0]);
				const p1 = touchToPoint(event.touches[1]);
				isTouchZooming.value = true;
				lastTouchZoomDistance.value = getDistanceBetweenPoints(p0, p1);
				lastTouchMidPoint.value = getMidpoint(p0, p1);
			}
		} else if (event.touches.length === 1) lastTouchPoint.value = touchToPoint(event.touches[0]);
	};
	const handleTouchMove = async (event) => {
		event.preventDefault();
		if (penPointerIdList.value.length > 0) return;
		lastTwoFingerTap.value = 0;
		if (isTouchZooming.value && event.touches.length === 2) {
			const p0 = touchToPoint(event.touches[0]);
			const p1 = touchToPoint(event.touches[1]);
			const newDistance = getDistanceBetweenPoints(p0, p1);
			const pinchFactor = newDistance / lastTouchZoomDistance.value;
			const midpoint = getMidpoint(p0, p1);
			const draggedPan = {
				x: pan_offset.value.x + midpoint.x - lastTouchMidPoint.value.x,
				y: pan_offset.value.y + midpoint.y - lastTouchMidPoint.value.y
			};
			if (!maskCanvas.value) maskCanvas.value = store.maskCanvas;
			if (!maskCanvas.value) return;
			const rect = maskCanvas.value.getBoundingClientRect();
			const focalX = midpoint.x - rect.left;
			const focalY = midpoint.y - rect.top;
			const result = calculateZoomAroundPoint(zoom_ratio.value, pinchFactor, draggedPan, focalX, focalY);
			zoom_ratio.value = result.zoomRatio;
			pan_offset.value = result.panOffset;
			await invalidatePanZoom();
			lastTouchZoomDistance.value = newDistance;
			lastTouchMidPoint.value = midpoint;
		} else if (event.touches.length === 1) await handleSingleTouchPan(event.touches[0]);
	};
	const handleTouchEnd = (event) => {
		event.preventDefault();
		if (event.touches.length > 0) lastTouchPoint.value = touchToPoint(event.touches[0]);
		else {
			isTouchZooming.value = false;
			lastTouchMidPoint.value = {
				x: 0,
				y: 0
			};
		}
	};
	const zoom = async (event) => {
		const cursorPosition = {
			x: event.clientX,
			y: event.clientY
		};
		if (!maskCanvas.value) maskCanvas.value = store.maskCanvas;
		if (!maskCanvas.value) return;
		const rect = maskCanvas.value.getBoundingClientRect();
		const focalX = cursorPosition.x - rect.left;
		const focalY = cursorPosition.y - rect.top;
		const result = calculateZoomAroundPoint(zoom_ratio.value, getWheelZoomFactor(event.deltaY), pan_offset.value, focalX, focalY);
		zoom_ratio.value = result.zoomRatio;
		pan_offset.value = result.panOffset;
		await invalidatePanZoom();
		const zoomRatio = maskCanvas.value.clientWidth / imageRootWidth.value;
		interpolatedZoomRatio.value = zoomRatio;
		store.displayZoomRatio = zoomRatio;
		updateCursorPosition(cursorPosition);
	};
	const getPanelDimensions = () => {
		const toolPanelWidth = toolPanelElement.value?.getBoundingClientRect().width || 64;
		return {
			sidePanelWidth: sidePanelElement.value?.getBoundingClientRect().width || 220,
			toolPanelWidth
		};
	};
	const smoothResetView = async (duration = 500) => {
		if (!image.value || !rootElement.value) return;
		const startZoom = zoom_ratio.value;
		const startPan = { ...pan_offset.value };
		const { sidePanelWidth, toolPanelWidth } = getPanelDimensions();
		const fitResult = calculateFitView({
			rootWidth: rootElement.value.clientWidth,
			rootHeight: rootElement.value.clientHeight,
			imageWidth: image.value.width,
			imageHeight: image.value.height,
			toolPanelWidth,
			sidePanelWidth
		});
		const startTime = performance.now();
		const animate = async (currentTime) => {
			const elapsed = currentTime - startTime;
			const progress = Math.min(elapsed / duration, 1);
			const eased = easeOutCubic(progress);
			const frame = interpolateView(startZoom, fitResult.zoomRatio, startPan, fitResult.panOffset, eased);
			zoom_ratio.value = frame.zoomRatio;
			pan_offset.value = frame.panOffset;
			await invalidatePanZoom();
			const interpolatedRatio = startZoom + (1 - startZoom) * eased;
			store.displayZoomRatio = interpolatedRatio;
			if (progress < 1) requestAnimationFrame(animate);
		};
		requestAnimationFrame(animate);
		interpolatedZoomRatio.value = 1;
	};
	const initializeCanvasPanZoom = async (img, root, toolPanel, sidePanel) => {
		rootElement.value = root;
		toolPanelElement.value = toolPanel || null;
		sidePanelElement.value = sidePanel || null;
		const { sidePanelWidth, toolPanelWidth } = getPanelDimensions();
		const fitResult = calculateFitView({
			rootWidth: root.clientWidth,
			rootHeight: root.clientHeight,
			imageWidth: img.width,
			imageHeight: img.height,
			toolPanelWidth,
			sidePanelWidth
		});
		if (image.value === null) image.value = img;
		imageRootWidth.value = fitResult.fittedWidth;
		imageRootHeight.value = fitResult.fittedHeight;
		zoom_ratio.value = fitResult.zoomRatio;
		pan_offset.value = fitResult.panOffset;
		penPointerIdList.value = [];
		await invalidatePanZoom();
	};
	watch(() => store.resetZoomTrigger, async () => {
		if (interpolatedZoomRatio.value === 1) return;
		await smoothResetView();
	});
	const addPenPointerId = (pointerId) => {
		if (!penPointerIdList.value.includes(pointerId)) penPointerIdList.value.push(pointerId);
	};
	const removePenPointerId = (pointerId) => {
		const index = penPointerIdList.value.indexOf(pointerId);
		if (index !== -1) penPointerIdList.value.splice(index, 1);
	};
	return {
		initializeCanvasPanZoom,
		handlePanStart,
		handlePanMove,
		handleTouchStart,
		handleTouchMove,
		handleTouchEnd,
		updateCursorPosition,
		zoom,
		invalidatePanZoom,
		addPenPointerId,
		removePenPointerId
	};
}
//#endregion
//#region packages/mask-editor/src/pointer.ts
function isMiddlePointerInput(event) {
	return event.button === 1 || event.buttons === 4;
}
function isMiddleButtonHeld(event) {
	return (event.buttons & 4) === 4;
}
var brushTextureCache = new (/* @__PURE__ */ __toESM(require_quick_lru(), 1)).default({ maxSize: 20 });
function resetDirtyRect() {
	return {
		minX: Infinity,
		minY: Infinity,
		maxX: -Infinity,
		maxY: -Infinity
	};
}
function updateDirtyRect(rect, x, y, radius) {
	const padding = 2;
	return {
		minX: Math.min(rect.minX, x - radius - padding),
		minY: Math.min(rect.minY, y - radius - padding),
		maxX: Math.max(rect.maxX, x + radius + padding),
		maxY: Math.max(rect.maxY, y + radius + padding)
	};
}
function formatRgba(hex, alpha) {
	const { r, g, b } = hexToRgb(hex);
	return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}
function premultiplyData(data) {
	for (let i = 0; i < data.length; i += 4) {
		const a = data[i + 3] / 255;
		data[i] = Math.round(data[i] * a);
		data[i + 1] = Math.round(data[i + 1] * a);
		data[i + 2] = Math.round(data[i + 2] * a);
	}
}
function drawShapeOnContext(ctx, brushType, x, y, radius) {
	ctx.beginPath();
	if (brushType === BrushShape.Rect) ctx.rect(x - radius, y - radius, radius * 2, radius * 2);
	else ctx.arc(x, y, radius, 0, Math.PI * 2, false);
	ctx.fill();
}
function createBrushGradient(ctx, x, y, radius, hardness, color, opacity, isErasing) {
	if (!Number.isFinite(x) || !Number.isFinite(y) || !Number.isFinite(radius)) return ctx.createRadialGradient(0, 0, 0, 0, 0, 0);
	const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius);
	if (isErasing) {
		gradient.addColorStop(0, `rgba(255, 255, 255, ${opacity})`);
		gradient.addColorStop(hardness, `rgba(255, 255, 255, ${opacity})`);
		gradient.addColorStop(1, `rgba(255, 255, 255, 0)`);
	} else {
		const { r, g, b } = parseToRgb(color);
		gradient.addColorStop(0, `rgba(${r}, ${g}, ${b}, ${opacity})`);
		gradient.addColorStop(hardness, `rgba(${r}, ${g}, ${b}, ${opacity})`);
		gradient.addColorStop(1, `rgba(${r}, ${g}, ${b}, 0)`);
	}
	return gradient;
}
function getCachedBrushTexture(radius, hardness, color, opacity) {
	const cacheKey = `${radius}_${hardness}_${color}`;
	const cached = brushTextureCache.get(cacheKey);
	if (cached) return cached;
	const size = Math.max(1, Math.ceil(radius * 2));
	if (!Number.isFinite(size)) throw new Error(`Invalid brush radius: ${radius}`);
	const tempCanvas = document.createElement("canvas");
	tempCanvas.width = size;
	tempCanvas.height = size;
	const tempCtx = tempCanvas.getContext("2d");
	if (!tempCtx) throw new Error("Unable to create 2D canvas context for brush texture");
	const centerX = size / 2;
	const centerY = size / 2;
	const hardRadius = radius * hardness;
	const imageData = tempCtx.createImageData(size, size);
	const data = imageData.data;
	const { r, g, b } = parseToRgb(color);
	const fadeRange = radius - hardRadius;
	for (let y = 0; y < size; y++) {
		const dy = y + .5 - centerY;
		for (let x = 0; x < size; x++) {
			const dx = x + .5 - centerX;
			const index = (y * size + x) * 4;
			const distFromEdge = Math.max(Math.abs(dx), Math.abs(dy));
			let pixelOpacity = 0;
			if (distFromEdge <= hardRadius) pixelOpacity = opacity;
			else if (distFromEdge <= radius) {
				const fadeProgress = (distFromEdge - hardRadius) / fadeRange;
				pixelOpacity = opacity * Math.pow(1 - fadeProgress, 2);
			}
			data[index] = r;
			data[index + 1] = g;
			data[index + 2] = b;
			data[index + 3] = pixelOpacity * 255;
		}
	}
	tempCtx.putImageData(imageData, 0, 0);
	brushTextureCache.set(cacheKey, tempCanvas);
	return tempCanvas;
}
function drawRgbShape(ctx, point, brushType, brushRadius, hardness, opacity, rgbColor) {
	const { x, y } = point;
	if (brushType === BrushShape.Rect && hardness < 1) {
		const brushTexture = getCachedBrushTexture(brushRadius, hardness, formatRgba(rgbColor, opacity), opacity);
		ctx.drawImage(brushTexture, x - brushRadius, y - brushRadius);
		return;
	}
	if (hardness === 1) {
		ctx.fillStyle = formatRgba(rgbColor, opacity);
		drawShapeOnContext(ctx, brushType, x, y, brushRadius);
		return;
	}
	ctx.fillStyle = createBrushGradient(ctx, x, y, brushRadius, hardness, rgbColor, opacity, false);
	drawShapeOnContext(ctx, brushType, x, y, brushRadius);
}
function drawMaskShape(ctx, point, brushType, brushRadius, hardness, opacity, isErasing, maskColor) {
	const { x, y } = point;
	if (brushType === BrushShape.Rect && hardness < 1) {
		const brushTexture = getCachedBrushTexture(brushRadius, hardness, isErasing ? `rgba(255, 255, 255, ${opacity})` : `rgba(${maskColor.r}, ${maskColor.g}, ${maskColor.b}, ${opacity})`, opacity);
		ctx.drawImage(brushTexture, x - brushRadius, y - brushRadius);
		return;
	}
	if (hardness === 1) {
		ctx.fillStyle = isErasing ? `rgba(255, 255, 255, ${opacity})` : `rgba(${maskColor.r}, ${maskColor.g}, ${maskColor.b}, ${opacity})`;
		drawShapeOnContext(ctx, brushType, x, y, brushRadius);
		return;
	}
	ctx.fillStyle = createBrushGradient(ctx, x, y, brushRadius, hardness, `rgb(${maskColor.r}, ${maskColor.g}, ${maskColor.b})`, opacity, isErasing);
	drawShapeOnContext(ctx, brushType, x, y, brushRadius);
}
//#endregion
//#region packages/mask-editor/src/useCoordinateTransform.ts
function useCoordinateTransformInternal() {
	const store = useMaskEditorStore();
	const screenToCanvas = (clientPoint) => {
		const pointerZoneEl = unref(store.pointerZone);
		const canvasContainerEl = unref(store.canvasContainer);
		const canvasEl = unref(store.maskCanvas);
		if (!pointerZoneEl || !canvasContainerEl || !canvasEl) {
			console.warn("screenToCanvas called before elements are available");
			return {
				x: 0,
				y: 0
			};
		}
		const pointerZoneRect = pointerZoneEl.getBoundingClientRect();
		const canvasContainerRect = canvasContainerEl.getBoundingClientRect();
		const canvasRect = canvasEl.getBoundingClientRect();
		const absoluteX = pointerZoneRect.left + clientPoint.x;
		const absoluteY = pointerZoneRect.top + clientPoint.y;
		const canvasX = absoluteX - canvasContainerRect.left;
		const canvasY = absoluteY - canvasContainerRect.top;
		const scaleX = canvasEl.width / canvasRect.width;
		const scaleY = canvasEl.height / canvasRect.height;
		return {
			x: canvasX * scaleX,
			y: canvasY * scaleY
		};
	};
	const canvasToScreen = (canvasPoint) => {
		const pointerZoneEl = unref(store.pointerZone);
		const canvasContainerEl = unref(store.canvasContainer);
		const canvasEl = unref(store.maskCanvas);
		if (!pointerZoneEl || !canvasContainerEl || !canvasEl) {
			console.warn("canvasToScreen called before elements are available");
			return {
				x: 0,
				y: 0
			};
		}
		const pointerZoneRect = pointerZoneEl.getBoundingClientRect();
		const canvasContainerRect = canvasContainerEl.getBoundingClientRect();
		const canvasRect = canvasEl.getBoundingClientRect();
		const scaleX = canvasRect.width / canvasEl.width;
		const scaleY = canvasRect.height / canvasEl.height;
		const displayX = canvasPoint.x * scaleX;
		const displayY = canvasPoint.y * scaleY;
		const absoluteX = canvasContainerRect.left + displayX;
		const absoluteY = canvasContainerRect.top + displayY;
		return {
			x: absoluteX - pointerZoneRect.left,
			y: absoluteY - pointerZoneRect.top
		};
	};
	return {
		screenToCanvas,
		canvasToScreen
	};
}
var useCoordinateTransform = createSharedComposable(useCoordinateTransformInternal);
//#endregion
//#region packages/mask-editor/src/useBrushAdjustment.ts
function useBrushAdjustment(initialSettings) {
	const store = useMaskEditorStore();
	const coordinateTransform = useCoordinateTransform();
	const initialPoint = ref(null);
	const initialBrushSize = ref(0);
	const initialBrushHardness = ref(0);
	const useDominantAxis = ref(initialSettings?.useDominantAxis ?? false);
	const brushAdjustmentSpeed = ref(initialSettings?.brushAdjustmentSpeed ?? 1);
	async function startBrushAdjustment(event) {
		event.preventDefault();
		const coords = {
			x: event.offsetX,
			y: event.offsetY
		};
		const coords_canvas = coordinateTransform.screenToCanvas(coords);
		store.brushPreviewGradientVisible = true;
		initialPoint.value = coords_canvas;
		initialBrushSize.value = store.brushSettings.size;
		initialBrushHardness.value = store.brushSettings.hardness;
	}
	async function handleBrushAdjustment(event) {
		if (!initialPoint.value) return;
		const coords = {
			x: event.offsetX,
			y: event.offsetY
		};
		const brushDeadZone = 5;
		const coords_canvas = coordinateTransform.screenToCanvas(coords);
		const delta_x = coords_canvas.x - initialPoint.value.x;
		const delta_y = coords_canvas.y - initialPoint.value.y;
		const effectiveDeltaX = Math.abs(delta_x) < brushDeadZone ? 0 : delta_x;
		const effectiveDeltaY = Math.abs(delta_y) < brushDeadZone ? 0 : delta_y;
		let finalDeltaX = effectiveDeltaX;
		let finalDeltaY = effectiveDeltaY;
		if (useDominantAxis.value) {
			const ratio = Math.abs(effectiveDeltaX) / Math.abs(effectiveDeltaY);
			const threshold = 2;
			if (ratio > threshold) finalDeltaY = 0;
			else if (ratio < 1 / threshold) finalDeltaX = 0;
		}
		const newSize = Math.max(1, Math.min(500, initialBrushSize.value + finalDeltaX / 35 * brushAdjustmentSpeed.value));
		const newHardness = Math.max(0, Math.min(1, initialBrushHardness.value - finalDeltaY / 4e3 * brushAdjustmentSpeed.value));
		store.setBrushSize(newSize);
		store.setBrushHardness(newHardness);
	}
	return {
		startBrushAdjustment,
		handleBrushAdjustment
	};
}
//#endregion
//#region node_modules/.pnpm/typegpu@0.8.2/node_modules/typegpu/chunk-CRZWTZM2.js
var m$1 = "0.8.2";
var o$1 = Symbol(`typegpu:${m$1}:$internal`);
var kn$1 = Symbol(`typegpu:${m$1}:$gpuValueOf`);
var me$3 = Symbol(`typegpu:${m$1}:$getNameForward`);
var He = Symbol(`typegpu:${m$1}:$providing`);
var qe = Symbol(`typegpu:${m$1}:$ownSnippet`);
var oe = Symbol(`typegpu:${m$1}:$resolve`);
var Je$2 = Symbol(`typegpu:${m$1}:$repr`);
Symbol(`typegpu:${m$1}:$gpuRepr`);
Symbol(`typegpu:${m$1}:$reprPartial`);
Symbol(`typegpu:${m$1}:$memIdent`);
Symbol(`typegpu:${m$1}:$invalidStorageSchema`);
Symbol(`typegpu:${m$1}:$validUniformSchema`);
Symbol(`typegpu:${m$1}:$validVertexSchema`);
Symbol(`typegpu:${m$1}:$invalidSchemaReason`);
function u(e) {
	return !!e?.[o$1];
}
var Mn$1 = {
	[o$1]: !0,
	type: "void",
	toString() {
		return "void";
	}
};
var Wt$2 = [
	"bool",
	"f32",
	"f16",
	"i32",
	"u32",
	"u16",
	"vec2f",
	"vec2h",
	"vec2i",
	"vec2u",
	"vec2<bool>",
	"vec3f",
	"vec3h",
	"vec3i",
	"vec3u",
	"vec3<bool>",
	"vec4f",
	"vec4h",
	"vec4i",
	"vec4u",
	"vec4<bool>",
	"mat2x2f",
	"mat3x3f",
	"mat4x4f",
	"struct",
	"array",
	"ptr",
	"atomic",
	"decorated",
	"abstractInt",
	"abstractFloat",
	"void",
	"texture_1d",
	"texture_storage_1d",
	"texture_2d",
	"texture_storage_2d",
	"texture_multisampled_2d",
	"texture_depth_2d",
	"texture_depth_multisampled_2d",
	"texture_2d_array",
	"texture_storage_2d_array",
	"texture_depth_2d_array",
	"texture_cube",
	"texture_depth_cube",
	"texture_cube_array",
	"texture_depth_cube_array",
	"texture_3d",
	"texture_storage_3d",
	"texture_external",
	"sampler",
	"sampler_comparison"
];
function Ee$2(e) {
	let t = e;
	return u(t) && typeof t.kind == "string" && t.kind.startsWith("vec");
}
__name(Ee$2, "Ee");
function Ct$1(e) {
	let t = e;
	return u(t) && typeof t.type == "string" && t.type.startsWith("vec2");
}
__name(Ct$1, "Ct");
function Ot$1(e) {
	let t = e;
	return u(t) && typeof t.type == "string" && t.type.startsWith("vec3");
}
__name(Ot$1, "Ot");
function Mt$1(e) {
	let t = e;
	return u(t) && typeof t.type == "string" && t.type.startsWith("vec4");
}
__name(Mt$1, "Mt");
function ae$1(e) {
	return Ct$1(e) || Ot$1(e) || Mt$1(e);
}
__name(ae$1, "ae");
function Xe$2(e) {
	let t = e;
	return u(t) && typeof t.kind?.startsWith == "function" && t.kind.startsWith("mat");
}
__name(Xe$2, "Xe");
function Lt(e) {
	return u(e) && e?.type === "mat2x2f";
}
function jt$1(e) {
	return u(e) && e?.type === "mat3x3f";
}
__name(jt$1, "jt");
function Gt$1(e) {
	return u(e) && e?.type === "mat4x4f";
}
__name(Gt$1, "Gt");
function Ue$2(e) {
	return Lt(e) || jt$1(e) || Gt$1(e);
}
__name(Ue$2, "Ue");
function Ln$1(e) {
	return Ee$2(e) && [
		"vec2f",
		"vec3f",
		"vec4f"
	].includes(e.kind);
}
__name(Ln$1, "Ln");
function C(e) {
	return u(e) && Wt$2.includes(e?.type);
}
function fe$2(e) {
	return u(e) && e?.type === "array";
}
__name(fe$2, "fe");
function we$3(e) {
	return u(e) && e?.type === "struct";
}
__name(we$3, "we");
function jn$1(e) {
	return u(e) && e?.type === "ptr";
}
__name(jn$1, "jn");
function Gn$1(e) {
	return u(e) && e?.type === "atomic";
}
__name(Gn$1, "Gn");
function Te$2(e) {
	return u(e) && e?.type === "@align";
}
__name(Te$2, "Te");
function ge$1(e) {
	return u(e) && e?.type === "@size";
}
__name(ge$1, "ge");
function Ze$1(e) {
	return u(e) && e?.type === "@location";
}
__name(Ze$1, "Ze");
function Ne$1(e) {
	return u(e) && e?.type === "@builtin";
}
__name(Ne$1, "Ne");
function _$1(e) {
	return u(e) && e?.type === "decorated";
}
__name(_$1, "_");
function Yn$2(e) {
	return u(e) && e.type === "void";
}
__name(Yn$2, "Yn");
function Qe$2(e) {
	let t = e?.type;
	return u(e) && (t === "abstractInt" || t === "abstractFloat" || t === "f32" || t === "f16" || t === "i32" || t === "u32");
}
__name(Qe$2, "Qe");
function Hn$2(e) {
	let t = e?.type;
	return u(e) && (t === "f16" || t === "vec2h" || t === "vec3h" || t === "vec4h");
}
__name(Hn$2, "Hn");
var A$2 = false;
Object.assign(globalThis, { __TYPEGPU_AUTONAME__: (e, t) => (Yt$1(e) && u(e) && !D(e) && e.$name(t), e) });
var ue$2 = globalThis;
function et$2(e) {
	return !!e?.[me$3];
}
__name(et$2, "et");
function D(e) {
	return et$2(e) ? D(e[me$3]) : nt$2(e)?.name;
}
function k(e, t) {
	et$2(e) && k(e[me$3], t), Ht$1(e, { name: t });
}
function Yt$1(e) {
	return !!e?.$name;
}
__name(Yt$1, "Yt");
function tt$2(e) {
	return !!nt$2(e)?.ast;
}
__name(tt$2, "tt");
function nt$2(e) {
	return ue$2.__TYPEGPU_META__.get(e);
}
__name(nt$2, "nt");
function Ht$1(e, t) {
	ue$2.__TYPEGPU_META__ ??= /* @__PURE__ */ new WeakMap();
	let n = ue$2.__TYPEGPU_META__;
	n.set(e, {
		...n.get(e),
		...t
	});
}
__name(Ht$1, "Ht");
var rt$2 = [
	"uint8",
	"uint8x2",
	"uint8x4",
	"sint8",
	"sint8x2",
	"sint8x4",
	"unorm8",
	"unorm8x2",
	"unorm8x4",
	"snorm8",
	"snorm8x2",
	"snorm8x4",
	"uint16",
	"uint16x2",
	"uint16x4",
	"sint16",
	"sint16x2",
	"sint16x4",
	"unorm16",
	"unorm16x2",
	"unorm16x4",
	"snorm16",
	"snorm16x2",
	"snorm16x4",
	"float16",
	"float16x2",
	"float16x4",
	"float32",
	"float32x2",
	"float32x3",
	"float32x4",
	"uint32",
	"uint32x2",
	"uint32x3",
	"uint32x4",
	"sint32",
	"sint32x2",
	"sint32x3",
	"sint32x4",
	"unorm10-10-10-2",
	"unorm8x4-bgra"
];
var er$2 = {
	f32: "float32",
	vec2f: "float32x2",
	vec3f: "float32x3",
	vec4f: "float32x4",
	f16: "float16",
	vec2h: "float16x2",
	vec4h: "float16x4",
	u32: "uint32",
	vec2u: "uint32x2",
	vec3u: "uint32x3",
	vec4u: "uint32x4",
	i32: "sint32",
	vec2i: "sint32x2",
	vec3i: "sint32x3",
	vec4i: "sint32x4"
};
function S$2(e) {
	return e.type === "decorated" || e.type === "loose-decorated" ? e.inner : e;
}
__name(S$2, "S");
var qt$1 = [
	"unstruct",
	"disarray",
	"loose-decorated",
	...rt$2
];
function Re$1(e) {
	return u(e) && qt$1.includes(e?.type);
}
__name(Re$1, "Re");
function ce$1(e) {
	return u(e) && e?.type === "disarray";
}
__name(ce$1, "ce");
function ye$2(e) {
	return u(e) && e?.type === "unstruct";
}
__name(ye$2, "ye");
function I$1(e) {
	return u(e) && e?.type === "loose-decorated";
}
__name(I$1, "I");
function O$3(e) {
	return e.attribs?.find(Te$2)?.params[0];
}
__name(O$3, "O");
function at$1(e) {
	return e.attribs?.find(ge$1)?.params[0];
}
__name(at$1, "at");
function or$2(e) {
	return e.attribs?.find(Ze$1)?.params[0];
}
__name(or$2, "or");
function ar$2(e) {
	return C(e) || Re$1(e);
}
__name(ar$2, "ar");
var ut$1 = {
	type: "unknown",
	toString() {
		return "unknown";
	}
};
var it$1 = class {
	static {
		__name(this, "it");
	}
	constructor(t, n, r) {
		this.name = t;
		this.lhs = n;
		this.operator = r;
	}
};
var st$2 = class {
	static {
		__name(this, "st");
	}
	constructor(t) {
		this.matrix = t;
	}
};
var ot$1 = class {
	static {
		__name(this, "ot");
	}
	constructor(t) {
		this.op = t;
		k(this, "consoleLog");
	}
	[o$1] = !0;
};
var We$2 = "Invariant failed";
function Ve$3(e, t) {
	if (e) return;
	if (!A$2) throw new Error(We$2);
	let n = typeof t == "function" ? t() : t;
	let r = n ? `${We$2}: ${n}` : We$2;
	throw new Error(r);
}
__name(Ve$3, "Ve");
var ct = class e extends Error {
	constructor(n, r) {
		let i = r.map((s) => `- ${tt$2(s) ? `fn*:${D(s)}` : s}`);
		i.length > 20 && (i = [
			...i.slice(0, 11),
			"...",
			...i.slice(-10)
		]);
		super(`Resolution of the following tree failed:
${i.join(`
`)}: ${n && typeof n == "object" && "message" in n ? n.message : n}`);
		this.cause = n;
		this.trace = r;
		Object.setPrototypeOf(this, e.prototype);
	}
	appendToTrace(n) {
		let r = [n, ...this.trace];
		return new e(this.cause, r);
	}
};
var yt$1 = class e extends Error {
	constructor(n, r) {
		let i = r.map((s) => `- ${s}`);
		i.length > 20 && (i = [
			...i.slice(0, 11),
			"...",
			...i.slice(-10)
		]);
		super(`Execution of the following tree failed:
${i.join(`
`)}: ${n && typeof n == "object" && "message" in n ? n.message : n}`);
		this.cause = n;
		this.trace = r;
		Object.setPrototypeOf(this, e.prototype);
	}
	appendToTrace(n) {
		let r = [n, ...this.trace];
		return new e(this.cause, r);
	}
};
var lt$1 = class e extends Error {
	constructor(n) {
		super(`Missing value for '${n}'`);
		this.slot = n;
		Object.setPrototypeOf(this, e.prototype);
	}
};
var pt$2 = class e extends Error {
	constructor(t) {
		super(`Buffer '${D(t) ?? "<unnamed>"}' is not bindable as a uniform. Use .$usage('uniform') to allow it.`), Object.setPrototypeOf(this, e.prototype);
	}
};
var ht$1 = class e extends Error {
	constructor(t, n) {
		super(`The function '${t ?? "<unnamed>"}' is missing links to the following external values: ${n}.`), Object.setPrototypeOf(this, e.prototype);
	}
};
var xt$1 = class e extends Error {
	constructor(t) {
		super(`Missing bind groups for layouts: '${[...t].map((n) => D(n) ?? "<unnamed>").join(", ")}'. Please provide it using pipeline.with(bindGroup).(...)`), Object.setPrototypeOf(this, e.prototype);
	}
};
var dt$1 = class e extends Error {
	constructor(t) {
		super(`Missing vertex buffers for layouts: '${[...t].map((n) => D(n) ?? "<unnamed>").join(", ")}'. Please provide it using pipeline.with(layout, buffer).(...)`), Object.setPrototypeOf(this, e.prototype);
	}
};
var mt$1 = class e extends Error {
	constructor(t) {
		super(t), Object.setPrototypeOf(this, e.prototype);
	}
};
var ft$1 = class e extends Error {
	constructor(t) {
		super(t), Object.setPrototypeOf(this, e.prototype);
	}
};
var be$2 = class e extends Error {
	constructor(t) {
		super(t), Object.setPrototypeOf(this, e.prototype);
	}
};
function wt(e) {
	return e?.resourceType === "slot";
}
function Tt$1(e) {
	return e?.resourceType === "derived";
}
__name(Tt$1, "Tt");
function gt$1(e) {
	return e?.[He] !== void 0;
}
__name(gt$1, "gt");
function dr$1(e) {
	return e?.resourceType === "accessor";
}
__name(dr$1, "dr");
var ze$2 = class {
	static {
		__name(this, "ze");
	}
	constructor(t, n) {
		this.value = t;
		this.dataType = n;
	}
};
function Ce$3(e) {
	return e instanceof ze$2;
}
__name(Ce$3, "Ce");
function gr$1(e) {
	return Qe$2(e.dataType);
}
__name(gr$1, "gr");
function x$1(e, t) {
	if (A$2 && Ce$3(e)) throw new Error("Cannot nest snippets");
	return new ze$2(e, S$2(t));
}
__name(x$1, "x");
var Se$2 = class {
	static {
		__name(this, "Se");
	}
	type = "normal";
};
var vt$1 = class {
	static {
		__name(this, "vt");
	}
	type = "codegen";
};
var bt = class {
	constructor(t, n) {
		this.buffers = t;
		this.vars = n;
	}
	type = "simulate";
};
function Jt$1(e) {
	return !!e?.[oe];
}
__name(Jt$1, "Jt");
function Vt$2(e) {
	return e?.[qe];
}
__name(Vt$2, "Vt");
function _r$2(e) {
	return typeof e == "number" || typeof e == "boolean" || typeof e == "string" || Jt$1(e) || C(e) || wt(e) || Tt$1(e) || gt$1(e);
}
__name(_r$2, "_r");
function Ar$1(e) {
	return !!e && typeof e == "object" && "getMappedRange" in e && "mapAsync" in e;
}
__name(Ar$1, "Ar");
var Ie$3 = !1;
function Fr$2(e) {
	if (Ie$3) return e();
	try {
		return Ie$3 = !0, e();
	} finally {
		Ie$3 = !1;
	}
}
__name(Fr$2, "Fr");
function Pr$2() {
	return Ie$3;
}
__name(Pr$2, "Pr");
var F$1;
function Br$2(e, t) {
	if (Ve$3(F$1 === void 0 || F$1 === e, "Cannot nest context providers"), F$1 === e) return t();
	F$1 = e;
	try {
		return t();
	} finally {
		F$1 = void 0;
	}
}
__name(Br$2, "Br");
function zt$2() {
	return F$1;
}
__name(zt$2, "zt");
var Xt$1 = new Se$2();
function Er$2() {
	return F$1?.mode ?? Xt$1;
}
__name(Er$2, "Er");
function Oe$1() {
	return F$1?.mode.type === "codegen";
}
__name(Oe$1, "Oe");
function d$2(e, ...t) {
	let n = zt$2();
	function r(s) {
		return Ce$3(s) ? n.resolve(s.value, s.dataType).value : s;
	}
	let i = "";
	for (let s = 0; s < e.length; ++s) {
		i += e[s];
		let p = t[s];
		Array.isArray(p) ? i += p.filter((y) => y !== void 0).map(r).join(", ") : p && (i += r(p));
	}
	return i;
}
__name(d$2, "d");
function St(e, t) {
	throw new Error(`Failed to handle ${e} at ${t}`);
}
var Me$2 = {
	rank: Number.POSITIVE_INFINITY,
	action: "none"
};
function _e$2(e, t) {
	let n = S$2(e);
	let r = S$2(t);
	if (n.type === r.type) return {
		rank: 0,
		action: "none"
	};
	if (n.type === "abstractFloat") {
		if (r.type === "f32") return {
			rank: 1,
			action: "none"
		};
		if (r.type === "f16") return {
			rank: 2,
			action: "none"
		};
	}
	if (n.type === "abstractInt") {
		if (r.type === "i32") return {
			rank: 3,
			action: "none"
		};
		if (r.type === "u32") return {
			rank: 4,
			action: "none"
		};
		if (r.type === "abstractFloat") return {
			rank: 5,
			action: "none"
		};
		if (r.type === "f32") return {
			rank: 6,
			action: "none"
		};
		if (r.type === "f16") return {
			rank: 7,
			action: "none"
		};
	}
	return ae$1(n) && ae$1(r) ? _e$2(n.primitive, r.primitive) : Ue$2(n) && Ue$2(r) ? {
		rank: 0,
		action: "none"
	} : Me$2;
}
__name(_e$2, "_e");
function Zt$1(e, t) {
	let n = S$2(e);
	let r = S$2(t);
	if (n.type === "ptr" && _e$2(n.inner, r).rank < Number.POSITIVE_INFINITY) return {
		rank: 0,
		action: "deref"
	};
	if (r.type === "ptr" && _e$2(n, r.inner).rank < Number.POSITIVE_INFINITY) return {
		rank: 1,
		action: "ref"
	};
	let i = {
		f32: 0,
		f16: 1,
		i32: 2,
		u32: 3,
		bool: 4
	};
	if (n.type in i && r.type in i) {
		let s = n.type;
		let p = r.type;
		if (s !== p) {
			let y = i[s];
			return {
				rank: i[p] < y ? 10 : 20,
				action: "cast",
				targetType: r
			};
		}
	}
	if (n.type === "abstractFloat") {
		if (r.type === "u32") return {
			rank: 2,
			action: "cast",
			targetType: r
		};
		if (r.type === "i32") return {
			rank: 1,
			action: "cast",
			targetType: r
		};
	}
	return Me$2;
}
__name(Zt$1, "Zt");
function Qt$1(e, t, n) {
	let r = _e$2(e, t);
	return r.rank < Number.POSITIVE_INFINITY ? r : n ? Zt$1(e, t) : Me$2;
}
__name(Qt$1, "Qt");
function It(e, t, n) {
	let r;
	for (let s of t) {
		let p = [];
		let y = 0;
		for (let l of e) {
			let g = Qt$1(l, s, n);
			if (y += g.rank, g.rank === Number.POSITIVE_INFINITY) break;
			p.push(g);
		}
		y < (r?.sum ?? Number.POSITIVE_INFINITY) && (r = {
			type: s,
			details: p,
			sum: y
		});
	}
	if (!r) return;
	let i = r.details.map((s, p) => ({
		sourceIndex: p,
		action: s.action,
		...s.action === "cast" && { targetType: s.targetType }
	}));
	return {
		targetType: r.type,
		actions: i,
		hasImplicitConversions: i.some((s) => s.action === "cast")
	};
}
function _t$2(e, t) {
	if (e.length === 0) return;
	let n = [...new Set((t || e).map(S$2))];
	let r = It(e, n, !1);
	if (r) return r;
	let i = It(e, n, !0);
	if (i) return i;
}
__name(_t$2, "_t");
function en$2(e, t, n) {
	if (t.action === "none") return x$1(e.value, n);
	switch (t.action) {
		case "ref": return x$1(d$2`&${e}`, n);
		case "deref": return x$1(d$2`*${e}`, n);
		case "cast": return n(e);
		default: St(t.action, "applyActionToSnippet");
	}
}
__name(en$2, "en");
function Hr$1(e, t) {
	if (e.some((r) => r.type === "unknown")) return;
	let n = _t$2(e, t);
	if (n) return e.map(() => n.targetType);
}
__name(Hr$1, "Hr");
function At(e, t, n = !0) {
	let r = e.map((s) => s.dataType);
	if (r.some((s) => s.type === "unknown")) return;
	let i = _t$2(r, t);
	if (i) return e.map((s, p) => {
		let y = i.actions[p];
		return Ve$3(y, "Action should not be undefined"), en$2(s, y, i.targetType);
	});
}
function Dt$1(e, t, n = !0) {
	if (t === e.dataType) return x$1(e.value, t);
	if (e.dataType.type === "unknown") return x$1(d$2`${x$1(e.value, t)}`, t);
	let r = At([e], [t], n);
	if (!r) throw new be$2(`Cannot convert value of type '${e.dataType.type}' to type '${t.type}'`);
	return r[0];
}
__name(Dt$1, "Dt");
function qr$1(e, t) {
	return Object.keys(e.propTypes).map((r) => {
		let i = t[r];
		if (!i) throw new Error(`Missing property ${r}`);
		let s = e.propTypes[r];
		return At([i], [s])?.[0] ?? i;
	});
}
__name(qr$1, "qr");
function tn$2(e) {
	return typeof e != "string" && Vt$2(e) === void 0;
}
__name(tn$2, "tn");
function $t(e, t, n, r = "keep") {
	let i = ((...s) => Oe$1() ? t(...s) : e(...s));
	return k(i, n), i.toString = () => n, Object.defineProperty(i, o$1, { value: {
		jsImpl: e,
		gpuImpl: t,
		argConversionHint: r
	} }), i;
}
var Ae$2 = class extends Error {
	static {
		__name(this, "Ae");
	}
	constructor(t) {
		super(t), this.name = this.constructor.name;
	}
};
function P(e) {
	let t = (...r) => {
		let { argTypes: i, returnType: s } = typeof e.signature == "function" ? e.signature(...r.map((l) => l.dataType)) : e.signature, y = r.map((l, g) => Dt$1(l, i[g], !e.ignoreImplicitCastWarning));
		if (y.every((l) => tn$2(l.value)) && typeof e.normalImpl == "function") try {
			return x$1(e.normalImpl(...y.map((l) => l.value)), s);
		} catch (l) {
			if (!(l instanceof Ae$2)) throw l;
		}
		return x$1(e.codegenImpl(...y), s);
	};
	let n = ((...r) => {
		if (Oe$1()) return t(...r);
		if (typeof e.normalImpl == "string") throw new Ae$2(e.normalImpl);
		return e.normalImpl(...r);
	});
	return k(n, e.name), n.toString = () => e.name, Object.defineProperty(n, o$1, { value: {
		jsImpl: e.normalImpl,
		gpuImpl: t,
		argConversionHint: "keep"
	} }), n;
}
var ai = {
	[o$1]: !0,
	type: "abstractInt",
	toString() {
		return "abstractInt";
	}
};
var ui = {
	[o$1]: !0,
	type: "abstractFloat",
	toString() {
		return "abstractFloat";
	}
};
var nn$2 = P({
	name: "bool",
	signature: (e) => ({
		argTypes: e ? [e] : [],
		returnType: b$2
	}),
	normalImpl(e) {
		return e === void 0 ? !1 : typeof e == "boolean" ? e : !!e;
	},
	codegenImpl: (e) => e.dataType.type === "bool" ? d$2`${e}` : d$2`bool(${e})`
});
var b$2 = Object.assign(nn$2, { type: "bool" });
var rn$2 = P({
	name: "u32",
	signature: (e) => ({
		argTypes: e ? [e] : [],
		returnType: c
	}),
	normalImpl(e) {
		return e === void 0 ? 0 : typeof e == "boolean" ? e ? 1 : 0 : (e & 4294967295) >>> 0;
	},
	codegenImpl: (e) => e.dataType.type === "u32" ? d$2`${e}` : d$2`u32(${e})`
});
var c = Object.assign(rn$2, { type: "u32" });
var sn$2 = P({
	name: "i32",
	signature: (e) => ({
		argTypes: e ? [e] : [],
		returnType: T$1
	}),
	normalImpl(e) {
		return e === void 0 ? 0 : typeof e == "boolean" ? e ? 1 : 0 : e | 0;
	},
	codegenImpl: (e) => e.dataType.type === "i32" ? d$2`${e}` : d$2`i32(${e})`
});
var T$1 = Object.assign(sn$2, { type: "i32" });
var on$2 = P({
	name: "f32",
	signature: (e) => ({
		argTypes: e ? [e] : [],
		returnType: h$1
	}),
	normalImpl(e) {
		return e === void 0 ? 0 : typeof e == "boolean" ? e ? 1 : 0 : Math.fround(e);
	},
	codegenImpl: (e) => e.dataType.type === "f32" ? d$2`${e}` : d$2`f32(${e})`
});
var h$1 = Object.assign(on$2, { type: "f32" });
var kt$2 = /* @__PURE__ */ new ArrayBuffer(4);
var an$2 = new Float32Array(kt$2);
var un$1 = new Uint32Array(kt$2);
function cn$1(e) {
	an$2[0] = e;
	let t = un$1[0];
	let n = t >>> 31 & 1;
	let r = t >>> 23 & 255;
	let i = t & 8388607;
	return r === 255 ? n << 15 | 31744 | (i ? 512 : 0) : (r = r - 127 + 15, r <= 0 ? r < -10 ? n << 15 : (i = (i | 8388608) >> 1 - r, i = i + 4096 >> 13, n << 15 | i) : r >= 31 || (i = i + 4096, i & 8388608 && (i = 0, ++r, r >= 31)) ? n << 15 | 31744 : n << 15 | r << 10 | i >> 13);
}
__name(cn$1, "cn");
function yn(e) {
	let t = e & 32768 ? -1 : 1;
	let n = e >> 10 & 31;
	let r = e & 1023;
	return n === 0 ? r ? t * r * 2 ** -24 : t * 0 : n === 31 ? r ? NaN : t === 1 ? Number.POSITIVE_INFINITY : Number.NEGATIVE_INFINITY : t * (1 + r / 1024) * 2 ** (n - 15);
}
function ln$1(e) {
	return yn(cn$1(e));
}
__name(ln$1, "ln");
var pn$1 = P({
	name: "f16",
	signature: (e) => ({
		argTypes: e ? [e] : [],
		returnType: $$3
	}),
	normalImpl(e) {
		return e === void 0 ? 0 : typeof e == "boolean" ? e ? 1 : 0 : ln$1(e);
	},
	codegenImpl: (e) => e.dataType.type === "f16" ? d$2`${e}` : d$2`f16(${e})`
});
var $$3 = Object.assign(pn$1, { type: "f16" });
var le$3 = class extends Array {
	static {
		__name(this, "le");
	}
	castElement() {
		return this[o$1].elementSchema[o$1].jsImpl;
	}
	[oe]() {
		let t = this[o$1].elementSchema;
		return this.every((n) => !n) ? x$1(`${this.kind}()`, t) : this.every((n) => this[0] === n) ? x$1(`${this.kind}(${this[0]})`, t) : x$1(`${this.kind}(${this.join(", ")})`, t);
	}
	toString() {
		return this[oe]().value;
	}
	get xx() {
		return new this._Vec2(this[0], this[0]);
	}
	get xy() {
		return new this._Vec2(this[0], this[1]);
	}
	get xz() {
		return new this._Vec2(this[0], this[2]);
	}
	get xw() {
		return new this._Vec2(this[0], this[3]);
	}
	get yx() {
		return new this._Vec2(this[1], this[0]);
	}
	get yy() {
		return new this._Vec2(this[1], this[1]);
	}
	get yz() {
		return new this._Vec2(this[1], this[2]);
	}
	get yw() {
		return new this._Vec2(this[1], this[3]);
	}
	get zx() {
		return new this._Vec2(this[2], this[0]);
	}
	get zy() {
		return new this._Vec2(this[2], this[1]);
	}
	get zz() {
		return new this._Vec2(this[2], this[2]);
	}
	get zw() {
		return new this._Vec2(this[2], this[3]);
	}
	get wx() {
		return new this._Vec2(this[3], this[0]);
	}
	get wy() {
		return new this._Vec2(this[3], this[1]);
	}
	get wz() {
		return new this._Vec2(this[3], this[2]);
	}
	get ww() {
		return new this._Vec2(this[3], this[3]);
	}
	get xxx() {
		return new this._Vec3(this[0], this[0], this[0]);
	}
	get xxy() {
		return new this._Vec3(this[0], this[0], this[1]);
	}
	get xxz() {
		return new this._Vec3(this[0], this[0], this[2]);
	}
	get xxw() {
		return new this._Vec3(this[0], this[0], this[3]);
	}
	get xyx() {
		return new this._Vec3(this[0], this[1], this[0]);
	}
	get xyy() {
		return new this._Vec3(this[0], this[1], this[1]);
	}
	get xyz() {
		return new this._Vec3(this[0], this[1], this[2]);
	}
	get xyw() {
		return new this._Vec3(this[0], this[1], this[3]);
	}
	get xzx() {
		return new this._Vec3(this[0], this[2], this[0]);
	}
	get xzy() {
		return new this._Vec3(this[0], this[2], this[1]);
	}
	get xzz() {
		return new this._Vec3(this[0], this[2], this[2]);
	}
	get xzw() {
		return new this._Vec3(this[0], this[2], this[3]);
	}
	get xwx() {
		return new this._Vec3(this[0], this[3], this[0]);
	}
	get xwy() {
		return new this._Vec3(this[0], this[3], this[1]);
	}
	get xwz() {
		return new this._Vec3(this[0], this[3], this[2]);
	}
	get xww() {
		return new this._Vec3(this[0], this[3], this[3]);
	}
	get yxx() {
		return new this._Vec3(this[1], this[0], this[0]);
	}
	get yxy() {
		return new this._Vec3(this[1], this[0], this[1]);
	}
	get yxz() {
		return new this._Vec3(this[1], this[0], this[2]);
	}
	get yxw() {
		return new this._Vec3(this[1], this[0], this[3]);
	}
	get yyx() {
		return new this._Vec3(this[1], this[1], this[0]);
	}
	get yyy() {
		return new this._Vec3(this[1], this[1], this[1]);
	}
	get yyz() {
		return new this._Vec3(this[1], this[1], this[2]);
	}
	get yyw() {
		return new this._Vec3(this[1], this[1], this[3]);
	}
	get yzx() {
		return new this._Vec3(this[1], this[2], this[0]);
	}
	get yzy() {
		return new this._Vec3(this[1], this[2], this[1]);
	}
	get yzz() {
		return new this._Vec3(this[1], this[2], this[2]);
	}
	get yzw() {
		return new this._Vec3(this[1], this[2], this[3]);
	}
	get ywx() {
		return new this._Vec3(this[1], this[3], this[0]);
	}
	get ywy() {
		return new this._Vec3(this[1], this[3], this[1]);
	}
	get ywz() {
		return new this._Vec3(this[1], this[3], this[2]);
	}
	get yww() {
		return new this._Vec3(this[1], this[3], this[3]);
	}
	get zxx() {
		return new this._Vec3(this[2], this[0], this[0]);
	}
	get zxy() {
		return new this._Vec3(this[2], this[0], this[1]);
	}
	get zxz() {
		return new this._Vec3(this[2], this[0], this[2]);
	}
	get zxw() {
		return new this._Vec3(this[2], this[0], this[3]);
	}
	get zyx() {
		return new this._Vec3(this[2], this[1], this[0]);
	}
	get zyy() {
		return new this._Vec3(this[2], this[1], this[1]);
	}
	get zyz() {
		return new this._Vec3(this[2], this[1], this[2]);
	}
	get zyw() {
		return new this._Vec3(this[2], this[1], this[3]);
	}
	get zzx() {
		return new this._Vec3(this[2], this[2], this[0]);
	}
	get zzy() {
		return new this._Vec3(this[2], this[2], this[1]);
	}
	get zzz() {
		return new this._Vec3(this[2], this[2], this[2]);
	}
	get zzw() {
		return new this._Vec3(this[2], this[2], this[3]);
	}
	get zwx() {
		return new this._Vec3(this[2], this[3], this[0]);
	}
	get zwy() {
		return new this._Vec3(this[2], this[3], this[1]);
	}
	get zwz() {
		return new this._Vec3(this[2], this[3], this[2]);
	}
	get zww() {
		return new this._Vec3(this[2], this[3], this[3]);
	}
	get wxx() {
		return new this._Vec3(this[3], this[0], this[0]);
	}
	get wxy() {
		return new this._Vec3(this[3], this[0], this[1]);
	}
	get wxz() {
		return new this._Vec3(this[3], this[0], this[2]);
	}
	get wxw() {
		return new this._Vec3(this[3], this[0], this[3]);
	}
	get wyx() {
		return new this._Vec3(this[3], this[1], this[0]);
	}
	get wyy() {
		return new this._Vec3(this[3], this[1], this[1]);
	}
	get wyz() {
		return new this._Vec3(this[3], this[1], this[2]);
	}
	get wyw() {
		return new this._Vec3(this[3], this[1], this[3]);
	}
	get wzx() {
		return new this._Vec3(this[3], this[2], this[0]);
	}
	get wzy() {
		return new this._Vec3(this[3], this[2], this[1]);
	}
	get wzz() {
		return new this._Vec3(this[3], this[2], this[2]);
	}
	get wzw() {
		return new this._Vec3(this[3], this[2], this[3]);
	}
	get wwx() {
		return new this._Vec3(this[3], this[3], this[0]);
	}
	get wwy() {
		return new this._Vec3(this[3], this[3], this[1]);
	}
	get wwz() {
		return new this._Vec3(this[3], this[3], this[2]);
	}
	get www() {
		return new this._Vec3(this[3], this[3], this[3]);
	}
	get xxxx() {
		return new this._Vec4(this[0], this[0], this[0], this[0]);
	}
	get xxxy() {
		return new this._Vec4(this[0], this[0], this[0], this[1]);
	}
	get xxxz() {
		return new this._Vec4(this[0], this[0], this[0], this[2]);
	}
	get xxxw() {
		return new this._Vec4(this[0], this[0], this[0], this[3]);
	}
	get xxyx() {
		return new this._Vec4(this[0], this[0], this[1], this[0]);
	}
	get xxyy() {
		return new this._Vec4(this[0], this[0], this[1], this[1]);
	}
	get xxyz() {
		return new this._Vec4(this[0], this[0], this[1], this[2]);
	}
	get xxyw() {
		return new this._Vec4(this[0], this[0], this[1], this[3]);
	}
	get xxzx() {
		return new this._Vec4(this[0], this[0], this[2], this[0]);
	}
	get xxzy() {
		return new this._Vec4(this[0], this[0], this[2], this[1]);
	}
	get xxzz() {
		return new this._Vec4(this[0], this[0], this[2], this[2]);
	}
	get xxzw() {
		return new this._Vec4(this[0], this[0], this[2], this[3]);
	}
	get xxwx() {
		return new this._Vec4(this[0], this[0], this[3], this[0]);
	}
	get xxwy() {
		return new this._Vec4(this[0], this[0], this[3], this[1]);
	}
	get xxwz() {
		return new this._Vec4(this[0], this[0], this[3], this[2]);
	}
	get xxww() {
		return new this._Vec4(this[0], this[0], this[3], this[3]);
	}
	get xyxx() {
		return new this._Vec4(this[0], this[1], this[0], this[0]);
	}
	get xyxy() {
		return new this._Vec4(this[0], this[1], this[0], this[1]);
	}
	get xyxz() {
		return new this._Vec4(this[0], this[1], this[0], this[2]);
	}
	get xyxw() {
		return new this._Vec4(this[0], this[1], this[0], this[3]);
	}
	get xyyx() {
		return new this._Vec4(this[0], this[1], this[1], this[0]);
	}
	get xyyy() {
		return new this._Vec4(this[0], this[1], this[1], this[1]);
	}
	get xyyz() {
		return new this._Vec4(this[0], this[1], this[1], this[2]);
	}
	get xyyw() {
		return new this._Vec4(this[0], this[1], this[1], this[3]);
	}
	get xyzx() {
		return new this._Vec4(this[0], this[1], this[2], this[0]);
	}
	get xyzy() {
		return new this._Vec4(this[0], this[1], this[2], this[1]);
	}
	get xyzz() {
		return new this._Vec4(this[0], this[1], this[2], this[2]);
	}
	get xyzw() {
		return new this._Vec4(this[0], this[1], this[2], this[3]);
	}
	get xywx() {
		return new this._Vec4(this[0], this[1], this[3], this[0]);
	}
	get xywy() {
		return new this._Vec4(this[0], this[1], this[3], this[1]);
	}
	get xywz() {
		return new this._Vec4(this[0], this[1], this[3], this[2]);
	}
	get xyww() {
		return new this._Vec4(this[0], this[1], this[3], this[3]);
	}
	get xzxx() {
		return new this._Vec4(this[0], this[2], this[0], this[0]);
	}
	get xzxy() {
		return new this._Vec4(this[0], this[2], this[0], this[1]);
	}
	get xzxz() {
		return new this._Vec4(this[0], this[2], this[0], this[2]);
	}
	get xzxw() {
		return new this._Vec4(this[0], this[2], this[0], this[3]);
	}
	get xzyx() {
		return new this._Vec4(this[0], this[2], this[1], this[0]);
	}
	get xzyy() {
		return new this._Vec4(this[0], this[2], this[1], this[1]);
	}
	get xzyz() {
		return new this._Vec4(this[0], this[2], this[1], this[2]);
	}
	get xzyw() {
		return new this._Vec4(this[0], this[2], this[1], this[3]);
	}
	get xzzx() {
		return new this._Vec4(this[0], this[2], this[2], this[0]);
	}
	get xzzy() {
		return new this._Vec4(this[0], this[2], this[2], this[1]);
	}
	get xzzz() {
		return new this._Vec4(this[0], this[2], this[2], this[2]);
	}
	get xzzw() {
		return new this._Vec4(this[0], this[2], this[2], this[3]);
	}
	get xzwx() {
		return new this._Vec4(this[0], this[2], this[3], this[0]);
	}
	get xzwy() {
		return new this._Vec4(this[0], this[2], this[3], this[1]);
	}
	get xzwz() {
		return new this._Vec4(this[0], this[2], this[3], this[2]);
	}
	get xzww() {
		return new this._Vec4(this[0], this[2], this[3], this[3]);
	}
	get xwxx() {
		return new this._Vec4(this[0], this[3], this[0], this[0]);
	}
	get xwxy() {
		return new this._Vec4(this[0], this[3], this[0], this[1]);
	}
	get xwxz() {
		return new this._Vec4(this[0], this[3], this[0], this[2]);
	}
	get xwxw() {
		return new this._Vec4(this[0], this[3], this[0], this[3]);
	}
	get xwyx() {
		return new this._Vec4(this[0], this[3], this[1], this[0]);
	}
	get xwyy() {
		return new this._Vec4(this[0], this[3], this[1], this[1]);
	}
	get xwyz() {
		return new this._Vec4(this[0], this[3], this[1], this[2]);
	}
	get xwyw() {
		return new this._Vec4(this[0], this[3], this[1], this[3]);
	}
	get xwzx() {
		return new this._Vec4(this[0], this[3], this[2], this[0]);
	}
	get xwzy() {
		return new this._Vec4(this[0], this[3], this[2], this[1]);
	}
	get xwzz() {
		return new this._Vec4(this[0], this[3], this[2], this[2]);
	}
	get xwzw() {
		return new this._Vec4(this[0], this[3], this[2], this[3]);
	}
	get xwwx() {
		return new this._Vec4(this[0], this[3], this[3], this[0]);
	}
	get xwwy() {
		return new this._Vec4(this[0], this[3], this[3], this[1]);
	}
	get xwwz() {
		return new this._Vec4(this[0], this[3], this[3], this[2]);
	}
	get xwww() {
		return new this._Vec4(this[0], this[3], this[3], this[3]);
	}
	get yxxx() {
		return new this._Vec4(this[1], this[0], this[0], this[0]);
	}
	get yxxy() {
		return new this._Vec4(this[1], this[0], this[0], this[1]);
	}
	get yxxz() {
		return new this._Vec4(this[1], this[0], this[0], this[2]);
	}
	get yxxw() {
		return new this._Vec4(this[1], this[0], this[0], this[3]);
	}
	get yxyx() {
		return new this._Vec4(this[1], this[0], this[1], this[0]);
	}
	get yxyy() {
		return new this._Vec4(this[1], this[0], this[1], this[1]);
	}
	get yxyz() {
		return new this._Vec4(this[1], this[0], this[1], this[2]);
	}
	get yxyw() {
		return new this._Vec4(this[1], this[0], this[1], this[3]);
	}
	get yxzx() {
		return new this._Vec4(this[1], this[0], this[2], this[0]);
	}
	get yxzy() {
		return new this._Vec4(this[1], this[0], this[2], this[1]);
	}
	get yxzz() {
		return new this._Vec4(this[1], this[0], this[2], this[2]);
	}
	get yxzw() {
		return new this._Vec4(this[1], this[0], this[2], this[3]);
	}
	get yxwx() {
		return new this._Vec4(this[1], this[0], this[3], this[0]);
	}
	get yxwy() {
		return new this._Vec4(this[1], this[0], this[3], this[1]);
	}
	get yxwz() {
		return new this._Vec4(this[1], this[0], this[3], this[2]);
	}
	get yxww() {
		return new this._Vec4(this[1], this[0], this[3], this[3]);
	}
	get yyxx() {
		return new this._Vec4(this[1], this[1], this[0], this[0]);
	}
	get yyxy() {
		return new this._Vec4(this[1], this[1], this[0], this[1]);
	}
	get yyxz() {
		return new this._Vec4(this[1], this[1], this[0], this[2]);
	}
	get yyxw() {
		return new this._Vec4(this[1], this[1], this[0], this[3]);
	}
	get yyyx() {
		return new this._Vec4(this[1], this[1], this[1], this[0]);
	}
	get yyyy() {
		return new this._Vec4(this[1], this[1], this[1], this[1]);
	}
	get yyyz() {
		return new this._Vec4(this[1], this[1], this[1], this[2]);
	}
	get yyyw() {
		return new this._Vec4(this[1], this[1], this[1], this[3]);
	}
	get yyzx() {
		return new this._Vec4(this[1], this[1], this[2], this[0]);
	}
	get yyzy() {
		return new this._Vec4(this[1], this[1], this[2], this[1]);
	}
	get yyzz() {
		return new this._Vec4(this[1], this[1], this[2], this[2]);
	}
	get yyzw() {
		return new this._Vec4(this[1], this[1], this[2], this[3]);
	}
	get yywx() {
		return new this._Vec4(this[1], this[1], this[3], this[0]);
	}
	get yywy() {
		return new this._Vec4(this[1], this[1], this[3], this[1]);
	}
	get yywz() {
		return new this._Vec4(this[1], this[1], this[3], this[2]);
	}
	get yyww() {
		return new this._Vec4(this[1], this[1], this[3], this[3]);
	}
	get yzxx() {
		return new this._Vec4(this[1], this[2], this[0], this[0]);
	}
	get yzxy() {
		return new this._Vec4(this[1], this[2], this[0], this[1]);
	}
	get yzxz() {
		return new this._Vec4(this[1], this[2], this[0], this[2]);
	}
	get yzxw() {
		return new this._Vec4(this[1], this[2], this[0], this[3]);
	}
	get yzyx() {
		return new this._Vec4(this[1], this[2], this[1], this[0]);
	}
	get yzyy() {
		return new this._Vec4(this[1], this[2], this[1], this[1]);
	}
	get yzyz() {
		return new this._Vec4(this[1], this[2], this[1], this[2]);
	}
	get yzyw() {
		return new this._Vec4(this[1], this[2], this[1], this[3]);
	}
	get yzzx() {
		return new this._Vec4(this[1], this[2], this[2], this[0]);
	}
	get yzzy() {
		return new this._Vec4(this[1], this[2], this[2], this[1]);
	}
	get yzzz() {
		return new this._Vec4(this[1], this[2], this[2], this[2]);
	}
	get yzzw() {
		return new this._Vec4(this[1], this[2], this[2], this[3]);
	}
	get yzwx() {
		return new this._Vec4(this[1], this[2], this[3], this[0]);
	}
	get yzwy() {
		return new this._Vec4(this[1], this[2], this[3], this[1]);
	}
	get yzwz() {
		return new this._Vec4(this[1], this[2], this[3], this[2]);
	}
	get yzww() {
		return new this._Vec4(this[1], this[2], this[3], this[3]);
	}
	get ywxx() {
		return new this._Vec4(this[1], this[3], this[0], this[0]);
	}
	get ywxy() {
		return new this._Vec4(this[1], this[3], this[0], this[1]);
	}
	get ywxz() {
		return new this._Vec4(this[1], this[3], this[0], this[2]);
	}
	get ywxw() {
		return new this._Vec4(this[1], this[3], this[0], this[3]);
	}
	get ywyx() {
		return new this._Vec4(this[1], this[3], this[1], this[0]);
	}
	get ywyy() {
		return new this._Vec4(this[1], this[3], this[1], this[1]);
	}
	get ywyz() {
		return new this._Vec4(this[1], this[3], this[1], this[2]);
	}
	get ywyw() {
		return new this._Vec4(this[1], this[3], this[1], this[3]);
	}
	get ywzx() {
		return new this._Vec4(this[1], this[3], this[2], this[0]);
	}
	get ywzy() {
		return new this._Vec4(this[1], this[3], this[2], this[1]);
	}
	get ywzz() {
		return new this._Vec4(this[1], this[3], this[2], this[2]);
	}
	get ywzw() {
		return new this._Vec4(this[1], this[3], this[2], this[3]);
	}
	get ywwx() {
		return new this._Vec4(this[1], this[3], this[3], this[0]);
	}
	get ywwy() {
		return new this._Vec4(this[1], this[3], this[3], this[1]);
	}
	get ywwz() {
		return new this._Vec4(this[1], this[3], this[3], this[2]);
	}
	get ywww() {
		return new this._Vec4(this[1], this[3], this[3], this[3]);
	}
	get zxxx() {
		return new this._Vec4(this[2], this[0], this[0], this[0]);
	}
	get zxxy() {
		return new this._Vec4(this[2], this[0], this[0], this[1]);
	}
	get zxxz() {
		return new this._Vec4(this[2], this[0], this[0], this[2]);
	}
	get zxxw() {
		return new this._Vec4(this[2], this[0], this[0], this[3]);
	}
	get zxyx() {
		return new this._Vec4(this[2], this[0], this[1], this[0]);
	}
	get zxyy() {
		return new this._Vec4(this[2], this[0], this[1], this[1]);
	}
	get zxyz() {
		return new this._Vec4(this[2], this[0], this[1], this[2]);
	}
	get zxyw() {
		return new this._Vec4(this[2], this[0], this[1], this[3]);
	}
	get zxzx() {
		return new this._Vec4(this[2], this[0], this[2], this[0]);
	}
	get zxzy() {
		return new this._Vec4(this[2], this[0], this[2], this[1]);
	}
	get zxzz() {
		return new this._Vec4(this[2], this[0], this[2], this[2]);
	}
	get zxzw() {
		return new this._Vec4(this[2], this[0], this[2], this[3]);
	}
	get zxwx() {
		return new this._Vec4(this[2], this[0], this[3], this[0]);
	}
	get zxwy() {
		return new this._Vec4(this[2], this[0], this[3], this[1]);
	}
	get zxwz() {
		return new this._Vec4(this[2], this[0], this[3], this[2]);
	}
	get zxww() {
		return new this._Vec4(this[2], this[0], this[3], this[3]);
	}
	get zyxx() {
		return new this._Vec4(this[2], this[1], this[0], this[0]);
	}
	get zyxy() {
		return new this._Vec4(this[2], this[1], this[0], this[1]);
	}
	get zyxz() {
		return new this._Vec4(this[2], this[1], this[0], this[2]);
	}
	get zyxw() {
		return new this._Vec4(this[2], this[1], this[0], this[3]);
	}
	get zyyx() {
		return new this._Vec4(this[2], this[1], this[1], this[0]);
	}
	get zyyy() {
		return new this._Vec4(this[2], this[1], this[1], this[1]);
	}
	get zyyz() {
		return new this._Vec4(this[2], this[1], this[1], this[2]);
	}
	get zyyw() {
		return new this._Vec4(this[2], this[1], this[1], this[3]);
	}
	get zyzx() {
		return new this._Vec4(this[2], this[1], this[2], this[0]);
	}
	get zyzy() {
		return new this._Vec4(this[2], this[1], this[2], this[1]);
	}
	get zyzz() {
		return new this._Vec4(this[2], this[1], this[2], this[2]);
	}
	get zyzw() {
		return new this._Vec4(this[2], this[1], this[2], this[3]);
	}
	get zywx() {
		return new this._Vec4(this[2], this[1], this[3], this[0]);
	}
	get zywy() {
		return new this._Vec4(this[2], this[1], this[3], this[1]);
	}
	get zywz() {
		return new this._Vec4(this[2], this[1], this[3], this[2]);
	}
	get zyww() {
		return new this._Vec4(this[2], this[1], this[3], this[3]);
	}
	get zzxx() {
		return new this._Vec4(this[2], this[2], this[0], this[0]);
	}
	get zzxy() {
		return new this._Vec4(this[2], this[2], this[0], this[1]);
	}
	get zzxz() {
		return new this._Vec4(this[2], this[2], this[0], this[2]);
	}
	get zzxw() {
		return new this._Vec4(this[2], this[2], this[0], this[3]);
	}
	get zzyx() {
		return new this._Vec4(this[2], this[2], this[1], this[0]);
	}
	get zzyy() {
		return new this._Vec4(this[2], this[2], this[1], this[1]);
	}
	get zzyz() {
		return new this._Vec4(this[2], this[2], this[1], this[2]);
	}
	get zzyw() {
		return new this._Vec4(this[2], this[2], this[1], this[3]);
	}
	get zzzx() {
		return new this._Vec4(this[2], this[2], this[2], this[0]);
	}
	get zzzy() {
		return new this._Vec4(this[2], this[2], this[2], this[1]);
	}
	get zzzz() {
		return new this._Vec4(this[2], this[2], this[2], this[2]);
	}
	get zzzw() {
		return new this._Vec4(this[2], this[2], this[2], this[3]);
	}
	get zzwx() {
		return new this._Vec4(this[2], this[2], this[3], this[0]);
	}
	get zzwy() {
		return new this._Vec4(this[2], this[2], this[3], this[1]);
	}
	get zzwz() {
		return new this._Vec4(this[2], this[2], this[3], this[2]);
	}
	get zzww() {
		return new this._Vec4(this[2], this[2], this[3], this[3]);
	}
	get zwxx() {
		return new this._Vec4(this[2], this[3], this[0], this[0]);
	}
	get zwxy() {
		return new this._Vec4(this[2], this[3], this[0], this[1]);
	}
	get zwxz() {
		return new this._Vec4(this[2], this[3], this[0], this[2]);
	}
	get zwxw() {
		return new this._Vec4(this[2], this[3], this[0], this[3]);
	}
	get zwyx() {
		return new this._Vec4(this[2], this[3], this[1], this[0]);
	}
	get zwyy() {
		return new this._Vec4(this[2], this[3], this[1], this[1]);
	}
	get zwyz() {
		return new this._Vec4(this[2], this[3], this[1], this[2]);
	}
	get zwyw() {
		return new this._Vec4(this[2], this[3], this[1], this[3]);
	}
	get zwzx() {
		return new this._Vec4(this[2], this[3], this[2], this[0]);
	}
	get zwzy() {
		return new this._Vec4(this[2], this[3], this[2], this[1]);
	}
	get zwzz() {
		return new this._Vec4(this[2], this[3], this[2], this[2]);
	}
	get zwzw() {
		return new this._Vec4(this[2], this[3], this[2], this[3]);
	}
	get zwwx() {
		return new this._Vec4(this[2], this[3], this[3], this[0]);
	}
	get zwwy() {
		return new this._Vec4(this[2], this[3], this[3], this[1]);
	}
	get zwwz() {
		return new this._Vec4(this[2], this[3], this[3], this[2]);
	}
	get zwww() {
		return new this._Vec4(this[2], this[3], this[3], this[3]);
	}
	get wxxx() {
		return new this._Vec4(this[3], this[0], this[0], this[0]);
	}
	get wxxy() {
		return new this._Vec4(this[3], this[0], this[0], this[1]);
	}
	get wxxz() {
		return new this._Vec4(this[3], this[0], this[0], this[2]);
	}
	get wxxw() {
		return new this._Vec4(this[3], this[0], this[0], this[3]);
	}
	get wxyx() {
		return new this._Vec4(this[3], this[0], this[1], this[0]);
	}
	get wxyy() {
		return new this._Vec4(this[3], this[0], this[1], this[1]);
	}
	get wxyz() {
		return new this._Vec4(this[3], this[0], this[1], this[2]);
	}
	get wxyw() {
		return new this._Vec4(this[3], this[0], this[1], this[3]);
	}
	get wxzx() {
		return new this._Vec4(this[3], this[0], this[2], this[0]);
	}
	get wxzy() {
		return new this._Vec4(this[3], this[0], this[2], this[1]);
	}
	get wxzz() {
		return new this._Vec4(this[3], this[0], this[2], this[2]);
	}
	get wxzw() {
		return new this._Vec4(this[3], this[0], this[2], this[3]);
	}
	get wxwx() {
		return new this._Vec4(this[3], this[0], this[3], this[0]);
	}
	get wxwy() {
		return new this._Vec4(this[3], this[0], this[3], this[1]);
	}
	get wxwz() {
		return new this._Vec4(this[3], this[0], this[3], this[2]);
	}
	get wxww() {
		return new this._Vec4(this[3], this[0], this[3], this[3]);
	}
	get wyxx() {
		return new this._Vec4(this[3], this[1], this[0], this[0]);
	}
	get wyxy() {
		return new this._Vec4(this[3], this[1], this[0], this[1]);
	}
	get wyxz() {
		return new this._Vec4(this[3], this[1], this[0], this[2]);
	}
	get wyxw() {
		return new this._Vec4(this[3], this[1], this[0], this[3]);
	}
	get wyyx() {
		return new this._Vec4(this[3], this[1], this[1], this[0]);
	}
	get wyyy() {
		return new this._Vec4(this[3], this[1], this[1], this[1]);
	}
	get wyyz() {
		return new this._Vec4(this[3], this[1], this[1], this[2]);
	}
	get wyyw() {
		return new this._Vec4(this[3], this[1], this[1], this[3]);
	}
	get wyzx() {
		return new this._Vec4(this[3], this[1], this[2], this[0]);
	}
	get wyzy() {
		return new this._Vec4(this[3], this[1], this[2], this[1]);
	}
	get wyzz() {
		return new this._Vec4(this[3], this[1], this[2], this[2]);
	}
	get wyzw() {
		return new this._Vec4(this[3], this[1], this[2], this[3]);
	}
	get wywx() {
		return new this._Vec4(this[3], this[1], this[3], this[0]);
	}
	get wywy() {
		return new this._Vec4(this[3], this[1], this[3], this[1]);
	}
	get wywz() {
		return new this._Vec4(this[3], this[1], this[3], this[2]);
	}
	get wyww() {
		return new this._Vec4(this[3], this[1], this[3], this[3]);
	}
	get wzxx() {
		return new this._Vec4(this[3], this[2], this[0], this[0]);
	}
	get wzxy() {
		return new this._Vec4(this[3], this[2], this[0], this[1]);
	}
	get wzxz() {
		return new this._Vec4(this[3], this[2], this[0], this[2]);
	}
	get wzxw() {
		return new this._Vec4(this[3], this[2], this[0], this[3]);
	}
	get wzyx() {
		return new this._Vec4(this[3], this[2], this[1], this[0]);
	}
	get wzyy() {
		return new this._Vec4(this[3], this[2], this[1], this[1]);
	}
	get wzyz() {
		return new this._Vec4(this[3], this[2], this[1], this[2]);
	}
	get wzyw() {
		return new this._Vec4(this[3], this[2], this[1], this[3]);
	}
	get wzzx() {
		return new this._Vec4(this[3], this[2], this[2], this[0]);
	}
	get wzzy() {
		return new this._Vec4(this[3], this[2], this[2], this[1]);
	}
	get wzzz() {
		return new this._Vec4(this[3], this[2], this[2], this[2]);
	}
	get wzzw() {
		return new this._Vec4(this[3], this[2], this[2], this[3]);
	}
	get wzwx() {
		return new this._Vec4(this[3], this[2], this[3], this[0]);
	}
	get wzwy() {
		return new this._Vec4(this[3], this[2], this[3], this[1]);
	}
	get wzwz() {
		return new this._Vec4(this[3], this[2], this[3], this[2]);
	}
	get wzww() {
		return new this._Vec4(this[3], this[2], this[3], this[3]);
	}
	get wwxx() {
		return new this._Vec4(this[3], this[3], this[0], this[0]);
	}
	get wwxy() {
		return new this._Vec4(this[3], this[3], this[0], this[1]);
	}
	get wwxz() {
		return new this._Vec4(this[3], this[3], this[0], this[2]);
	}
	get wwxw() {
		return new this._Vec4(this[3], this[3], this[0], this[3]);
	}
	get wwyx() {
		return new this._Vec4(this[3], this[3], this[1], this[0]);
	}
	get wwyy() {
		return new this._Vec4(this[3], this[3], this[1], this[1]);
	}
	get wwyz() {
		return new this._Vec4(this[3], this[3], this[1], this[2]);
	}
	get wwyw() {
		return new this._Vec4(this[3], this[3], this[1], this[3]);
	}
	get wwzx() {
		return new this._Vec4(this[3], this[3], this[2], this[0]);
	}
	get wwzy() {
		return new this._Vec4(this[3], this[3], this[2], this[1]);
	}
	get wwzz() {
		return new this._Vec4(this[3], this[3], this[2], this[2]);
	}
	get wwzw() {
		return new this._Vec4(this[3], this[3], this[2], this[3]);
	}
	get wwwx() {
		return new this._Vec4(this[3], this[3], this[3], this[0]);
	}
	get wwwy() {
		return new this._Vec4(this[3], this[3], this[3], this[1]);
	}
	get wwwz() {
		return new this._Vec4(this[3], this[3], this[3], this[2]);
	}
	get wwww() {
		return new this._Vec4(this[3], this[3], this[3], this[3]);
	}
};
var U$1 = class extends le$3 {
	static {
		__name(this, "U");
	}
	e0;
	e1;
	constructor(t, n) {
		super(2), this.e0 = this.castElement()(t), this.e1 = this.castElement()(n ?? t);
	}
	get 0() {
		return this.e0;
	}
	get 1() {
		return this.e1;
	}
	set 0(t) {
		this.e0 = this.castElement()(t);
	}
	set 1(t) {
		this.e1 = this.castElement()(t);
	}
	get x() {
		return this[0];
	}
	get y() {
		return this[1];
	}
	set x(t) {
		this[0] = this.castElement()(t);
	}
	set y(t) {
		this[1] = this.castElement()(t);
	}
};
var N$1 = class extends le$3 {
	static {
		__name(this, "N");
	}
	e0;
	e1;
	e2;
	constructor(t, n, r) {
		super(3), this.e0 = this.castElement()(t), this.e1 = this.castElement()(n ?? t), this.e2 = this.castElement()(r ?? t);
	}
	get 0() {
		return this.e0;
	}
	get 1() {
		return this.e1;
	}
	get 2() {
		return this.e2;
	}
	set 0(t) {
		this.e0 = this.castElement()(t);
	}
	set 1(t) {
		this.e1 = this.castElement()(t);
	}
	set 2(t) {
		this.e2 = this.castElement()(t);
	}
	get x() {
		return this[0];
	}
	get y() {
		return this[1];
	}
	get z() {
		return this[2];
	}
	set x(t) {
		this[0] = this.castElement()(t);
	}
	set y(t) {
		this[1] = this.castElement()(t);
	}
	set z(t) {
		this[2] = this.castElement()(t);
	}
};
var R$1 = class extends le$3 {
	static {
		__name(this, "R");
	}
	e0;
	e1;
	e2;
	e3;
	constructor(t, n, r, i) {
		super(4), this.e0 = this.castElement()(t), this.e1 = this.castElement()(n ?? t), this.e2 = this.castElement()(r ?? t), this.e3 = this.castElement()(i ?? t);
	}
	get 0() {
		return this.e0;
	}
	get 1() {
		return this.e1;
	}
	get 2() {
		return this.e2;
	}
	get 3() {
		return this.e3;
	}
	set 0(t) {
		this.e0 = this.castElement()(t);
	}
	set 1(t) {
		this.e1 = this.castElement()(t);
	}
	set 2(t) {
		this.e2 = this.castElement()(t);
	}
	set 3(t) {
		this.e3 = this.castElement()(t);
	}
	get x() {
		return this[0];
	}
	get y() {
		return this[1];
	}
	get z() {
		return this[2];
	}
	get w() {
		return this[3];
	}
	set x(t) {
		this[0] = t;
	}
	set y(t) {
		this[1] = t;
	}
	set z(t) {
		this[2] = t;
	}
	set w(t) {
		this[3] = t;
	}
};
var M$1 = class e extends U$1 {
	get [o$1]() {
		return { elementSchema: h$1 };
	}
	get kind() {
		return "vec2f";
	}
	get _Vec2() {
		return e;
	}
	get _Vec3() {
		return Y$2;
	}
	get _Vec4() {
		return Z$1;
	}
};
var L$2 = class e extends U$1 {
	get [o$1]() {
		return { elementSchema: $$3 };
	}
	get kind() {
		return "vec2h";
	}
	get _Vec2() {
		return e;
	}
	get _Vec3() {
		return H$1;
	}
	get _Vec4() {
		return Q$2;
	}
};
var j$2 = class e extends U$1 {
	get [o$1]() {
		return { elementSchema: T$1 };
	}
	get kind() {
		return "vec2i";
	}
	get _Vec2() {
		return e;
	}
	get _Vec3() {
		return q$1;
	}
	get _Vec4() {
		return ee$2;
	}
};
var G = class e extends U$1 {
	get [o$1]() {
		return { elementSchema: c };
	}
	get kind() {
		return "vec2u";
	}
	get _Vec2() {
		return e;
	}
	get _Vec3() {
		return J$1;
	}
	get _Vec4() {
		return te$2;
	}
};
var K$1 = class e extends U$1 {
	get [o$1]() {
		return { elementSchema: b$2 };
	}
	get kind() {
		return "vec2<bool>";
	}
	get _Vec2() {
		return e;
	}
	get _Vec3() {
		return X$2;
	}
	get _Vec4() {
		return ne$2;
	}
};
var Y$2 = class e extends N$1 {
	get [o$1]() {
		return { elementSchema: h$1 };
	}
	get kind() {
		return "vec3f";
	}
	get _Vec2() {
		return M$1;
	}
	get _Vec3() {
		return e;
	}
	get _Vec4() {
		return Z$1;
	}
};
var H$1 = class e extends N$1 {
	get [o$1]() {
		return { elementSchema: $$3 };
	}
	get kind() {
		return "vec3h";
	}
	get _Vec2() {
		return L$2;
	}
	get _Vec3() {
		return e;
	}
	get _Vec4() {
		return Q$2;
	}
};
var q$1 = class e extends N$1 {
	get [o$1]() {
		return { elementSchema: T$1 };
	}
	get kind() {
		return "vec3i";
	}
	get _Vec2() {
		return j$2;
	}
	get _Vec3() {
		return e;
	}
	get _Vec4() {
		return ee$2;
	}
};
var J$1 = class e extends N$1 {
	get [o$1]() {
		return { elementSchema: c };
	}
	get kind() {
		return "vec3u";
	}
	get _Vec2() {
		return G;
	}
	get _Vec3() {
		return e;
	}
	get _Vec4() {
		return te$2;
	}
};
var X$2 = class e extends N$1 {
	get [o$1]() {
		return { elementSchema: b$2 };
	}
	get kind() {
		return "vec3<bool>";
	}
	get _Vec2() {
		return K$1;
	}
	get _Vec3() {
		return e;
	}
	get _Vec4() {
		return ne$2;
	}
};
var Z$1 = class e extends R$1 {
	get [o$1]() {
		return { elementSchema: h$1 };
	}
	get kind() {
		return "vec4f";
	}
	get _Vec2() {
		return M$1;
	}
	get _Vec3() {
		return Y$2;
	}
	get _Vec4() {
		return e;
	}
};
var Q$2 = class e extends R$1 {
	get [o$1]() {
		return { elementSchema: $$3 };
	}
	get kind() {
		return "vec4h";
	}
	get _Vec2() {
		return L$2;
	}
	get _Vec3() {
		return H$1;
	}
	get _Vec4() {
		return e;
	}
};
var ee$2 = class e extends R$1 {
	get [o$1]() {
		return { elementSchema: T$1 };
	}
	get kind() {
		return "vec4i";
	}
	get _Vec2() {
		return j$2;
	}
	get _Vec3() {
		return q$1;
	}
	get _Vec4() {
		return e;
	}
};
var te$2 = class e extends R$1 {
	get [o$1]() {
		return { elementSchema: c };
	}
	get kind() {
		return "vec4u";
	}
	get _Vec2() {
		return G;
	}
	get _Vec3() {
		return J$1;
	}
	get _Vec4() {
		return e;
	}
};
var ne$2 = class e extends R$1 {
	get [o$1]() {
		return { elementSchema: b$2 };
	}
	get kind() {
		return "vec4<bool>";
	}
	get _Vec2() {
		return K$1;
	}
	get _Vec3() {
		return X$2;
	}
	get _Vec4() {
		return e;
	}
};
var B$1 = f$1(M$1, h$1);
var hn$1 = f$1(L$2, $$3);
var pe$3 = f$1(j$2, T$1);
var he$3 = f$1(G, c);
var xn$1 = f$1(K$1, b$2);
var Le = f$1(Y$2, h$1);
var dn$1 = f$1(H$1, $$3);
var je = f$1(q$1, T$1);
var E = f$1(J$1, c);
var mn$1 = f$1(X$2, b$2);
var v = f$1(Z$1, h$1);
var fn$1 = f$1(Q$2, $$3);
var xe$2 = f$1(ee$2, T$1);
var de$1 = f$1(te$2, c);
var wn$1 = f$1(ne$2, b$2);
var bi = {
	vec2f: B$1,
	vec2h: hn$1,
	vec2i: pe$3,
	vec2u: he$3,
	"vec2<bool>": xn$1,
	vec3f: Le,
	vec3h: dn$1,
	vec3i: je,
	vec3u: E,
	"vec3<bool>": mn$1,
	vec4f: v,
	vec4h: fn$1,
	vec4i: xe$2,
	vec4u: de$1,
	"vec4<bool>": wn$1
};
function f$1(e, t) {
	let { kind: n, length: r } = new e(), s = P({
		name: n,
		signature: (...y) => ({
			argTypes: y.map((l) => {
				let g = S$2(l);
				return ae$1(g) ? g : t;
			}),
			returnType: p
		}),
		normalImpl: (...y) => {
			let l = new Array(y.length);
			let g = 0;
			for (let se of y) if (typeof se == "number" || typeof se == "boolean") l[g++] = se;
			else for (let Be = 0; Be < se.length; ++Be) l[g++] = se[Be];
			if (l.length <= 1 || l.length === r) return new e(...l);
			throw new Error(`'${n}' constructor called with invalid number of arguments.`);
		},
		ignoreImplicitCastWarning: !0,
		codegenImpl: (...y) => d$2`${n}(${y})`
	}), p = Object.assign(s, {
		type: n,
		primitive: t,
		[Je$2]: void 0
	});
	return p;
}
__name(f$1, "f");
var a = class {
	constructor(t) {
		this.type = t;
	}
	[o$1] = !0;
};
var De$2 = {
	uint8: c,
	uint8x2: he$3,
	uint8x4: de$1,
	sint8: T$1,
	sint8x2: pe$3,
	sint8x4: xe$2,
	unorm8: h$1,
	unorm8x2: B$1,
	unorm8x4: v,
	snorm8: h$1,
	snorm8x2: B$1,
	snorm8x4: v,
	uint16: c,
	uint16x2: he$3,
	uint16x4: de$1,
	sint16: T$1,
	sint16x2: pe$3,
	sint16x4: xe$2,
	unorm16: h$1,
	unorm16x2: B$1,
	unorm16x4: v,
	snorm16: h$1,
	snorm16x2: B$1,
	snorm16x4: v,
	float16: h$1,
	float16x2: B$1,
	float16x4: v,
	float32: h$1,
	float32x2: B$1,
	float32x3: Le,
	float32x4: v,
	uint32: c,
	uint32x2: he$3,
	uint32x3: E,
	uint32x4: de$1,
	sint32: T$1,
	sint32x2: pe$3,
	sint32x3: je,
	sint32x4: xe$2,
	"unorm10-10-10-2": v,
	"unorm8x4-bgra": v
};
var Ge$1 = new Set(Object.keys(De$2));
new a("uint8");
new a("uint8x2");
new a("uint8x4");
new a("sint8");
new a("sint8x2");
new a("sint8x4");
new a("unorm8");
new a("unorm8x2");
new a("unorm8x4");
new a("snorm8");
new a("snorm8x2");
new a("snorm8x4");
new a("uint16");
new a("uint16x2");
new a("uint16x4");
new a("sint16");
new a("sint16x2");
new a("sint16x4");
new a("unorm16");
new a("unorm16x2");
new a("unorm16x4");
new a("snorm16");
new a("snorm16x2");
new a("snorm16x4");
new a("float16");
new a("float16x2");
new a("float16x4");
new a("float32");
new a("float32x2");
new a("float32x3");
new a("float32x4");
new a("uint32");
new a("uint32x2");
new a("uint32x3");
new a("uint32x4");
new a("sint32");
new a("sint32x2");
new a("sint32x3");
new a("sint32x4");
new a("unorm10-10-10-2");
new a("unorm8x4-bgra");
function ds(e) {
	return u(e) && Ge$1.has(e?.type);
}
function Pt$1(e) {
	let t = String(e);
	if (t !== "[object Object]") return t;
	try {
		return JSON.stringify(e);
	} catch (n) {
		return console.error("Error parsing JSON:", n), "<invalid json>";
	}
}
__name(Pt$1, "Pt");
function Ft$1(e) {
	return Ee$2(e) || Xe$2(e) ? e.toString() : Array.isArray(e) ? `[${e.map(Ft$1).join(", ")}]` : e && typeof e == "object" ? `{ ${Object.entries(e).map(([t, n]) => `${t}: ${Ft$1(n)}`).join(", ")} }` : String(e);
}
__name(Ft$1, "Ft");
var Tn$1 = {
	f32: 4,
	f16: 2,
	i32: 4,
	u32: 4,
	bool: 4,
	u16: 2,
	vec2f: 8,
	vec2h: 4,
	vec2i: 8,
	vec2u: 8,
	vec2b: 8,
	vec3f: 16,
	vec3h: 8,
	vec3i: 16,
	vec3u: 16,
	vec3b: 16,
	vec4f: 16,
	vec4h: 8,
	vec4i: 16,
	vec4u: 16,
	vec4b: 16,
	mat2x2f: 8,
	mat3x3f: 16,
	mat4x4f: 16,
	atomic: 4
};
function gn$1(e) {
	let t = e?.type;
	let n = Tn$1[t];
	if (n !== void 0) return n;
	if (we$3(e)) return Object.values(e.propTypes).map(V).reduce((r, i) => r > i ? r : i);
	if (fe$2(e)) return V(e.elementType);
	if (ye$2(e)) {
		let r = Object.values(e.propTypes)[0];
		return r ? O$3(r) ?? 1 : 1;
	}
	if (ce$1(e)) return O$3(e.elementType) ?? 1;
	if (_$1(e) || I$1(e)) return O$3(e) ?? V(e.inner);
	if (Ge$1.has(t)) return 1;
	throw new Error(`Cannot determine alignment of data: ${Pt$1(e)}`);
}
__name(gn$1, "gn");
function vn$1(e) {
	if (ye$2(e)) {
		let t = Object.values(e.propTypes)[0];
		return t ? re$1(t) : 1;
	}
	return ce$1(e) ? re$1(e.elementType) : I$1(e) ? O$3(e) ?? re$1(e.inner) : O$3(e) ?? 1;
}
__name(vn$1, "vn");
var Bt$1 = /* @__PURE__ */ new WeakMap();
var Et$1 = /* @__PURE__ */ new WeakMap();
function V(e) {
	let t = Bt$1.get(e);
	return t === void 0 && (t = gn$1(e), Bt$1.set(e, t)), t;
}
function re$1(e) {
	let t = Et$1.get(e);
	return t === void 0 && (t = vn$1(e), Et$1.set(e, t)), t;
}
__name(re$1, "re");
var ie$2 = /* @__PURE__ */ __name((e, t) => {
	let n = t - 1;
	let r = ~n;
	return (e & n) === 0 ? e : (e & r) + t;
}, "ie");
var bn$1 = {
	bool: 4,
	f32: 4,
	f16: 2,
	i32: 4,
	u32: 4,
	u16: 2,
	vec2f: 8,
	vec2h: 4,
	vec2i: 8,
	vec2u: 8,
	"vec2<bool>": 8,
	vec3f: 12,
	vec3h: 6,
	vec3i: 12,
	vec3u: 12,
	"vec3<bool>": 12,
	vec4f: 16,
	vec4h: 8,
	vec4i: 16,
	vec4u: 16,
	"vec4<bool>": 16,
	mat2x2f: 16,
	mat3x3f: 48,
	mat4x4f: 64,
	uint8: 1,
	uint8x2: 2,
	uint8x4: 4,
	sint8: 1,
	sint8x2: 2,
	sint8x4: 4,
	unorm8: 1,
	unorm8x2: 2,
	unorm8x4: 4,
	snorm8: 1,
	snorm8x2: 2,
	snorm8x4: 4,
	uint16: 2,
	uint16x2: 4,
	uint16x4: 8,
	sint16: 2,
	sint16x2: 4,
	sint16x4: 8,
	unorm16: 2,
	unorm16x2: 4,
	unorm16x4: 8,
	snorm16: 2,
	snorm16x2: 4,
	snorm16x4: 8,
	float16: 2,
	float16x2: 4,
	float16x4: 8,
	float32: 4,
	float32x2: 8,
	float32x3: 12,
	float32x4: 16,
	uint32: 4,
	uint32x2: 8,
	uint32x3: 12,
	uint32x4: 16,
	sint32: 4,
	sint32x2: 8,
	sint32x3: 12,
	sint32x4: 16,
	"unorm10-10-10-2": 4,
	"unorm8x4-bgra": 4,
	atomic: 4
};
function Vn$1(e) {
	let t = 0;
	let n = e.propTypes;
	for (let r of Object.values(n)) {
		if (Number.isNaN(t)) throw new Error("Only the last property of a struct can be unbounded");
		if (t = ie$2(t, V(r)), t += z(r), Number.isNaN(t) && r.type !== "array") throw new Error("Cannot nest unbounded struct within another struct");
	}
	return ie$2(t, V(e));
}
__name(Vn$1, "Vn");
function zn$1(e) {
	let t = 0;
	let n = e.propTypes;
	for (let r of Object.values(n)) {
		let i = re$1(r);
		t = ie$2(t, i), t += z(r);
	}
	return t;
}
__name(zn$1, "zn");
function Sn$1(e) {
	let t = bn$1[e?.type];
	if (t !== void 0) return t;
	if (we$3(e)) return Vn$1(e);
	if (ye$2(e)) return zn$1(e);
	if (fe$2(e)) {
		if (e.elementCount === 0) return NaN;
		let n = V(e.elementType);
		return ie$2(z(e.elementType), n) * e.elementCount;
	}
	if (ce$1(e)) {
		let n = re$1(e.elementType);
		return ie$2(z(e.elementType), n) * e.elementCount;
	}
	if (_$1(e) || I$1(e)) return at$1(e) ?? z(e.inner);
	throw new Error(`Cannot determine size of data: ${e}`);
}
__name(Sn$1, "Sn");
var Ut$1 = /* @__PURE__ */ new WeakMap();
function z(e) {
	let t = Ut$1.get(e);
	return t === void 0 && (t = Sn$1(e), Ut$1.set(e, t)), t;
}
function $s(e) {
	return z(e);
}
function W(e, t) {
	return _$1(e) ? new ke$2(e.inner, [t, ...e.attribs]) : I$1(e) ? new Fe$2(e.inner, [t, ...e.attribs]) : Re$1(e) ? new Fe$2(e, [t]) : new ke$2(e, [t]);
}
function Ws(e, t) {
	return W(t, {
		[o$1]: !0,
		type: "@location",
		params: [e]
	});
}
function In$1(e) {
	return (_$1(e) || I$1(e)) && e.attribs.find(Ne$1) !== void 0;
}
__name(In$1, "In");
function Ms$1(e) {
	return !_$1(e) && !I$1(e) ? "" : e.attribs.map((t) => t.params.length === 0 ? `${t.type} ` : `${t.type}(${t.params.join(", ")}) `).join("");
}
__name(Ms$1, "Ms");
var $e$3 = class {
	static {
		__name(this, "$e");
	}
	constructor(t, n) {
		this.inner = t;
		this.attribs = n;
		let r = n.find(Te$2)?.params[0];
		let i = n.find(ge$1)?.params[0];
		if (r !== void 0) {
			if (r <= 0) throw new Error(`Custom data alignment must be a positive number, got: ${r}.`);
			if (Math.log2(r) % 1 !== 0) throw new Error(`Alignment has to be a power of 2, got: ${r}.`);
			if (C(this.inner) && r % V(this.inner) !== 0) throw new Error(`Custom alignment has to be a multiple of the standard data alignment. Got: ${r}, expected multiple of: ${V(this.inner)}.`);
		}
		if (i !== void 0) {
			if (i < z(this.inner)) throw new Error(`Custom data size cannot be smaller then the standard data size. Got: ${i}, expected at least: ${z(this.inner)}.`);
			if (i <= 0) throw new Error(`Custom data size must be a positive number. Got: ${i}.`);
		}
	}
	[o$1] = !0;
};
var ke$2 = class extends $e$3 {
	static {
		__name(this, "ke");
	}
	[o$1] = !0;
	type = "decorated";
};
var Fe$2 = class extends $e$3 {
	static {
		__name(this, "Fe");
	}
	[o$1] = !0;
	type = "loose-decorated";
};
function Pe$2(e, t) {
	let n = e?.type;
	let r = n in De$2 ? De$2[n] : e;
	return typeof r != "function" ? t : t === void 0 ? r() : r(t);
}
__name(Pe$2, "Pe");
function qs(e) {
	return Nt$1(e, !1);
}
function Js(e) {
	return Nt$1(e, !0);
}
function Nt$1(e, t) {
	let n = (r) => Object.fromEntries(Object.entries(e).map(([i, s]) => [i, Pe$2(s, r?.[i])]));
	return Object.setPrototypeOf(n, _n$1), n.propTypes = e, Object.defineProperty(n, o$1, { value: { isAbstruct: t } }), n;
}
__name(Nt$1, "Nt");
var _n$1 = {
	type: "struct",
	$name(e) {
		return k(this, e), this;
	},
	toString() {
		return `struct:${D(this) ?? "<unnamed>"}`;
	}
};
var Ye$2 = $t(((e, t) => t === void 0 ? (n) => Ke$1(e, n) : Ke$1(e, t)), (e, t) => {
	if (t?.value === void 0) {
		let n = (r) => Ye$2[o$1].gpuImpl(e, r);
		return n[o$1] = !0, x$1(n, ut$1);
	}
	if (typeof t.value != "number") throw new Error(`Cannot create array schema with count unknown at compile-time: '${t.value}'`);
	return x$1(Ke$1(e.value, t.value), e.value);
}, "arrayOf");
function Ke$1(e, t) {
	let n = (r) => {
		if (r && r.length !== t) throw new Error(`Array schema of ${t} elements of type ${e.type} called with ${r.length} argument(s).`);
		return Array.from({ length: t }, (i, s) => Pe$2(e, r?.[s]));
	};
	if (Object.setPrototypeOf(n, An$1), Number.isNaN(z(e))) throw new Error("Cannot nest runtime sized arrays.");
	if (n.elementType = e, !Number.isInteger(t) || t < 0) throw new Error(`Cannot create array schema with invalid element count: ${t}.`);
	return n.elementCount = t, n;
}
__name(Ke$1, "Ke");
var An$1 = {
	[o$1]: !0,
	type: "array",
	toString() {
		return `arrayOf(${this.elementType}, ${this.elementCount})`;
	}
};
function w$1(e, t) {
	return W(e, {
		[o$1]: !0,
		type: "@builtin",
		params: [t]
	});
}
__name(w$1, "w");
var yo$2 = {
	vertexIndex: w$1(c, "vertex_index"),
	instanceIndex: w$1(c, "instance_index"),
	position: w$1(v, "position"),
	clipDistances: w$1(Ye$2(c, 8), "clip_distances"),
	frontFacing: w$1(b$2, "front_facing"),
	fragDepth: w$1(h$1, "frag_depth"),
	sampleIndex: w$1(c, "sample_index"),
	sampleMask: w$1(c, "sample_mask"),
	localInvocationId: w$1(E, "local_invocation_id"),
	localInvocationIndex: w$1(c, "local_invocation_index"),
	globalInvocationId: w$1(E, "global_invocation_id"),
	workgroupId: w$1(E, "workgroup_id"),
	numWorkgroups: w$1(E, "num_workgroups"),
	subgroupInvocationId: w$1(c, "subgroup_invocation_id"),
	subgroupSize: w$1(c, "subgroup_size")
};
//#endregion
//#region node_modules/.pnpm/tinyest@0.1.2/node_modules/tinyest/index.js
var tinyest_exports = /* @__PURE__ */ __exportAll({
	FORMAT_VERSION: () => 1,
	FuncParameterType: () => t,
	NodeTypeCatalog: () => e
});
var e = {
	block: 0,
	binaryExpr: 1,
	assignmentExpr: 2,
	logicalExpr: 3,
	unaryExpr: 4,
	numericLiteral: 5,
	call: 6,
	memberAccess: 7,
	indexAccess: 8,
	return: 10,
	if: 11,
	let: 12,
	const: 13,
	for: 14,
	while: 15,
	continue: 16,
	break: 17,
	arrayExpr: 100,
	preUpdate: 101,
	postUpdate: 102,
	stringLiteral: 103,
	objectExpr: 104
};
var t = {
	identifier: "i",
	destructuredObject: "d"
};
//#endregion
//#region node_modules/.pnpm/typegpu@0.8.2/node_modules/typegpu/chunk-CGQB3SER.js
function S$1(n, e) {
	for (let [r, t] of Object.entries(e)) n[r] = t, t && (typeof t == "object" || typeof t == "function") && D(t) === void 0 && k(t, r);
}
__name(S$1, "S");
function Se$1(n, e, r) {
	let t = [...n.matchAll(/:\s*(?<arg>.*?)\s*[,)]/g)].map((s) => s ? s[1] : void 0);
	r(Object.fromEntries(e.flatMap((s, i) => {
		let o = t ? t[i] : void 0;
		return we$3(s) && o !== void 0 ? [[o, s]] : [];
	})));
}
__name(Se$1, "Se");
function $e$2(n, e, r) {
	let t = n.match(/->\s(?<output>[\w\d_]+)\s{/);
	let s = t ? t[1]?.trim() : void 0;
	we$3(e) && s && !/\s/g.test(s) && r({ [s]: e });
}
__name($e$2, "$e");
function ue$1(n) {
	return new RegExp(`(?<![\\w\\$_.])${n.replaceAll(".", "\\.").replaceAll("$", "\\$")}(?![\\w\\$_])`, "g");
}
__name(ue$1, "ue");
function R(n, e, r) {
	return Object.entries(e).reduce((t, [s, i]) => {
		let o = ue$1(s);
		if (r && s !== "Out" && s !== "In" && !o.test(r) && console.warn(`The external '${s}' wasn't used in the resolved template.`), _r$2(i) || Re$1(i) || tt$2(i)) return t.replaceAll(o, n.resolve(i).value);
		if (i !== null && typeof i == "object") {
			let a = [...r.matchAll(new RegExp(`${s.replaceAll(".", "\\.").replaceAll("$", "\\$")}\\.(?<prop>.*?)(?![\\w\\$_])`, "g"))].map((d) => d[1]);
			return [...new Set(a)].reduce((d, f) => f && f in i ? R(n, { [`${s}.${f}`]: i[f] }, d) : d, t);
		}
		return console.warn(`During resolution, the external '${s}' has been omitted. Only primitives, TGPU resources and plain JS objects can be used as externals.`), t;
	}, r);
}
function Y$1(n) {
	let { strippedCode: e, argRange: r } = pe$2(n), t = new $$2(e);
	t.consume("(");
	let s = [];
	for (; !t.isAt(")");) {
		let o = [];
		for (; t.isAt("@");) t.parseUntil(Q$1, X$1), t.consume(")"), o.push(t.lastParsed);
		t.parseUntil(ce);
		let a = t.lastParsed;
		let l;
		t.isAt(":") && (t.consume(":"), t.parseUntil(de, fe$1), l = t.lastParsed), s.push({
			identifier: a,
			attributes: o,
			type: l
		}), t.isAt(",") && t.consume(",");
	}
	t.consume(")");
	let i;
	if (t.isAt("->")) {
		t.consume("->");
		let o = [];
		for (; t.isAt("@");) t.parseUntil(Q$1, X$1), t.consume(")"), o.push(t.lastParsed);
		i = {
			type: t.str.slice(t.pos),
			attributes: o
		};
	}
	return {
		args: s,
		ret: i,
		range: {
			begin: r[0],
			end: r[1]
		}
	};
}
__name(Y$1, "Y");
function pe$2(n) {
	let e = new $$2(n);
	let r = "";
	let t;
	for (; !e.isFinished();) {
		if (e.isAt(le$2)) {
			e.advanceBy(1);
			continue;
		}
		if (e.isAt("//")) {
			e.consume("//"), e.parseUntil(Z), e.advanceBy(1);
			continue;
		}
		if (e.isAt("/*")) {
			e.parseUntil(me$2, ge), e.consume("*/");
			continue;
		}
		if (e.isAt("{")) return {
			strippedCode: r,
			argRange: [t, e.pos]
		};
		e.isAt("(") && t === void 0 && (t = e.pos), t !== void 0 && (r += e.str[e.pos]), e.advanceBy(1);
	}
	throw new Error("Invalid wgsl code!");
}
__name(pe$2, "pe");
var $$2 = class {
	static {
		__name(this, "$");
	}
	constructor(e) {
		this.str = e;
		this.#e = 0;
	}
	#t;
	#e;
	get pos() {
		return this.#e;
	}
	get lastParsed() {
		if (this.#t === void 0) throw new Error("Parse was not called yet!");
		return this.str.slice(this.#t, this.pos);
	}
	isFinished() {
		return this.#e >= this.str.length;
	}
	isAt(e) {
		if (typeof e == "string") {
			for (let r = 0; r < e.length; r++) if (this.str[this.#e + r] !== e[r]) return !1;
			return !0;
		}
		for (let r of e) if (this.isAt(r)) return !0;
		return !1;
	}
	parseUntil(e, r) {
		this.#t = this.#e;
		let t = 0;
		for (; this.#e < this.str.length;) {
			if (r && this.isAt(r[0]) && (t += 1), r && this.isAt(r[1]) && (t -= 1), t === 0 && this.isAt(e)) return this.#e;
			this.#e += 1;
		}
		throw new Error("Reached the end of the string without finding a match!");
	}
	advanceBy(e) {
		this.#e += e;
	}
	consume(e) {
		if (!this.isAt(e)) throw new Error(`Expected '${e}' at position ${this.#e}, but found '${this.str.slice(this.#e, this.#e + e.length)}'`);
		this.advanceBy(e.length);
	}
};
var Z = /* @__PURE__ */ new Set([
	`
`,
	"\v",
	"\f",
	"\r",
	"",
	"\u2028",
	"\u2029"
]);
var le$2 = /* @__PURE__ */ new Set([
	...Z,
	" ",
	"	",
	"‎",
	"‏"
]);
var Q$1 = /* @__PURE__ */ new Set([")"]);
var ce = /* @__PURE__ */ new Set([
	":",
	",",
	")"
]);
var de = /* @__PURE__ */ new Set([",", ")"]);
var me$2 = /* @__PURE__ */ new Set(["*/"]);
var X$1 = ["(", ")"];
var fe$1 = ["<", ">"];
var ge = ["/*", "*/"];
function ne$1(n, e = "") {
	let r = [];
	let t$1 = {
		applyExternals(i) {
			r.push(i);
		},
		resolve(i, o, a) {
			let l = {};
			for (let u of r) S$1(l, u);
			let d = i.getUniqueName(this);
			if (typeof n == "string") {
				if (!a) throw new Error("Explicit return type is required for string implementation");
				let u = R(i, l, n);
				let m = "";
				let x = "";
				if (e !== "") {
					let p = we$3(o[0]) ? `(in: ${i.resolve(o[0]).value})` : "()";
					let c = C(a) ? Ms$1(a) : "";
					m = `${p} ${a !== Mn$1 ? we$3(a) ? `-> ${i.resolve(a).value}` : `-> ${c !== "" ? c : "@location(0)"} ${i.resolve(a).value}` : ""} `, x = u;
				} else {
					let p = Y$1(u);
					if (p.args.length !== o.length) throw new Error(`WGSL implementation has ${p.args.length} arguments, while the shell has ${o.length} arguments.`);
					m = `(${p.args.map((E, ae) => `${E.identifier}: ${te$1(i, `parameter ${E.identifier}`, E.type, o[ae])}`).join(", ")}) ${a === Mn$1 ? "" : `-> ${te$1(i, "return type", p.ret?.type, a)}`}`, x = u.slice(p.range.end);
				}
				return i.addDeclaration(`${e}fn ${d}${m}${x}`), x$1(d, a);
			}
			let f = nt$2(n);
			if (f?.externals) S$1(l, Object.fromEntries(Object.entries(f.externals).filter(([m]) => !(m in l))));
			let O = f?.ast;
			if (!O) throw new Error("Missing metadata for tgpu.fn function body (either missing 'use gpu' directive, or misconfigured `unplugin-typegpu`)");
			let B = O.externalNames.filter((u) => !(u in l));
			if (B.length > 0) throw new ht$1(D(this), B);
			let A = O.params[1];
			A && A.type === "i" && e !== "" && S$1(l, { [A.name]: S$2(a) });
			let V = [];
			let v = [];
			for (let [u, m] of o.entries()) {
				let x = O.params[u];
				switch (x?.type) {
					case t.identifier: {
						let p = x.name;
						let c = x$1(i.makeNameValid(p), m);
						V.push(c), c.value !== p && v.push([p, c]);
						break;
					}
					case t.destructuredObject:
						V.push(x$1(`_arg_${u}`, m)), v.push(...x.props.map(({ name: p, alias: c }) => [c, x$1(`_arg_${u}.${p}`, o[u].propTypes[p])]));
						break;
					case void 0: V.push(x$1(`_arg_${u}`, m));
				}
			}
			let { head: ie, body: se, returnType: oe } = i.fnToWgsl({
				args: V,
				argAliases: Object.fromEntries(v),
				returnType: a,
				body: O.body,
				externalMap: l
			});
			return i.addDeclaration(`${e}fn ${d}${i.resolve(ie).value}${i.resolve(se).value}`), x$1(d, oe);
		}
	};
	let s = D(n);
	return s !== void 0 && k(t$1, s), t$1;
}
__name(ne$1, "ne");
function te$1(n, e, r, t) {
	let s = n.resolve(t).value.replace(/\s/g, "");
	if (!r) return s;
	let i = r.replace(/\s/g, "");
	if (i !== s) throw new Error(`Type mismatch between TGPU shell and WGSL code string: ${e}, JS type "${s}", WGSL type "${i}".`);
	return r;
}
__name(te$1, "te");
function xe$1(n, e = {}) {
	let r = 0;
	let t = /* @__PURE__ */ new Set();
	return Object.fromEntries(Object.entries(n ?? {}).map(([s, i]) => {
		let o = or$2(i);
		if (o !== void 0) {
			if (t.has(o)) throw new Error("Duplicate custom location attributes found");
			t.add(o);
		}
		return [s, i];
	}).map(([s, i]) => {
		if (In$1(i)) return [s, i];
		if (or$2(i) !== void 0) return [s, i];
		if (e[s]) return [s, Ws(e[s], i)];
		for (; t.has(r);) r++;
		return [s, Ws(r++, i)];
	}));
}
__name(xe$1, "xe");
function F(n, e = {}) {
	return ar$2(n) ? Yn$2(n) || or$2(n) !== void 0 ? n : Ws(0, n) : qs(xe$1(n, e));
}
function re(n, ...e) {
	return ye$1(n) ? he$2(n, ...e) : n;
}
function ye$1(n) {
	return Array.isArray(n) && "raw" in n && Array.isArray(n.raw) && n.raw.every((e) => typeof e == "string");
}
__name(ye$1, "ye");
function he$2(n, ...e) {
	return n.slice(1).reduce((r, t, s) => `${r}${e[s]}${t}`, n[0]);
}
__name(he$2, "he");
function Qe$1(n) {
	if (Object.keys(n.out).length === 0) throw new Error("A vertexFn output cannot be empty since it must include the 'position' builtin.");
	let e = {
		in: n.in,
		out: n.out,
		argTypes: n.in && Object.keys(n.in).length !== 0 ? [F(n.in)] : [],
		isEntry: !0
	};
	let r = (t, ...s) => Ie$2(e, re(t, ...s));
	return Object.assign(Object.assign(r, e), { does: r });
}
__name(Qe$1, "Qe");
function Ie$2(n, e) {
	let r = ne$1(e, "@vertex ");
	let t = n.argTypes[0];
	return {
		shell: n,
		$uses(i) {
			return r.applyExternals(i), this;
		},
		[o$1]: !0,
		[me$3]: r,
		$name(i) {
			return k(r, i), Yt$1(t) && t.$name(`${i}_Input`), this;
		},
		[oe](i) {
			let o = F(n.out, i.varyingLocations).$name(`${D(this) ?? ""}_Output`);
			return typeof e == "string" && (t && r.applyExternals({ In: t }), r.applyExternals({ Out: o })), r.resolve(i, n.argTypes, o);
		},
		toString() {
			return `vertexFn:${D(r) ?? "<unnamed>"}`;
		}
	};
}
__name(Ie$2, "Ie");
//#endregion
//#region node_modules/.pnpm/typegpu@0.8.2/node_modules/typegpu/chunk-ECR2EGZX.js
var Qe = class {};
function Wt$1(e) {
	let t = $t((...r) => {
		let a = [];
		for (let s of r) if (typeof s == "number") a.push(s);
		else for (let i = 0; i < s.length; ++i) a.push(s[i]);
		if (a.length !== 0 && a.length !== e.columns * e.rows) throw new Error(`'${e.type}' constructor called with invalid number of arguments.`);
		for (let s = a.length; s < e.columns * e.rows; ++s) a.push(0);
		return new e.MatImpl(...a);
	}, (...r) => x$1(d$2`${e.type}(${r})`, n), e.type);
	let n = Object.assign(t, {
		type: e.type,
		identity: fn[e.columns],
		translation: e.columns === 4 ? gn : void 0,
		scaling: e.columns === 4 ? hn : void 0,
		rotationX: e.columns === 4 ? vn : void 0,
		rotationY: e.columns === 4 ? bn : void 0,
		rotationZ: e.columns === 4 ? wn : void 0
	});
	return n;
}
__name(Wt$1, "Wt");
var zt$1 = class extends Qe {
	static {
		__name(this, "zt");
	}
	[o$1] = !0;
	columns;
	length = 4;
	constructor(...t) {
		super(), this.columns = [this.makeColumn(t[0], t[1]), this.makeColumn(t[2], t[3])];
	}
	get 0() {
		return this.columns[0].x;
	}
	get 1() {
		return this.columns[0].y;
	}
	get 2() {
		return this.columns[1].x;
	}
	get 3() {
		return this.columns[1].y;
	}
	set 0(t) {
		this.columns[0].x = t;
	}
	set 1(t) {
		this.columns[0].y = t;
	}
	set 2(t) {
		this.columns[1].x = t;
	}
	set 3(t) {
		this.columns[1].y = t;
	}
	*[Symbol.iterator]() {
		yield this[0], yield this[1], yield this[2], yield this[3];
	}
	[oe]() {
		return x$1(`${this.kind}(${Array.from({ length: this.length }).map((t, n) => this[n]).join(", ")})`, ie$1);
	}
	toString() {
		return this[oe]().value;
	}
};
var Vt$1 = class extends zt$1 {
	static {
		__name(this, "Vt");
	}
	kind = "mat2x2f";
	makeColumn(t, n) {
		return B$1(t, n);
	}
};
var Ft = class extends Qe {
	[o$1] = !0;
	columns;
	length = 12;
	constructor(...t) {
		super(), this.columns = [
			this.makeColumn(t[0], t[1], t[2]),
			this.makeColumn(t[3], t[4], t[5]),
			this.makeColumn(t[6], t[7], t[8])
		];
	}
	get 0() {
		return this.columns[0].x;
	}
	get 1() {
		return this.columns[0].y;
	}
	get 2() {
		return this.columns[0].z;
	}
	get 3() {
		return 0;
	}
	get 4() {
		return this.columns[1].x;
	}
	get 5() {
		return this.columns[1].y;
	}
	get 6() {
		return this.columns[1].z;
	}
	get 7() {
		return 0;
	}
	get 8() {
		return this.columns[2].x;
	}
	get 9() {
		return this.columns[2].y;
	}
	get 10() {
		return this.columns[2].z;
	}
	get 11() {
		return 0;
	}
	set 0(t) {
		this.columns[0].x = t;
	}
	set 1(t) {
		this.columns[0].y = t;
	}
	set 2(t) {
		this.columns[0].z = t;
	}
	set 3(t) {}
	set 4(t) {
		this.columns[1].x = t;
	}
	set 5(t) {
		this.columns[1].y = t;
	}
	set 6(t) {
		this.columns[1].z = t;
	}
	set 7(t) {}
	set 8(t) {
		this.columns[2].x = t;
	}
	set 9(t) {
		this.columns[2].y = t;
	}
	set 10(t) {
		this.columns[2].z = t;
	}
	set 11(t) {}
	*[Symbol.iterator]() {
		for (let t = 0; t < 12; t++) yield this[t];
	}
	[oe]() {
		return x$1(`${this.kind}(${this[0]}, ${this[1]}, ${this[2]}, ${this[4]}, ${this[5]}, ${this[6]}, ${this[8]}, ${this[9]}, ${this[10]})`, le$1);
	}
	toString() {
		return this[oe]().value;
	}
};
var Ct = class extends Ft {
	kind = "mat3x3f";
	makeColumn(t, n, r) {
		return Le(t, n, r);
	}
};
var Pt = class extends Qe {
	[o$1] = !0;
	columns;
	constructor(...t) {
		super(), this.columns = [
			this.makeColumn(t[0], t[1], t[2], t[3]),
			this.makeColumn(t[4], t[5], t[6], t[7]),
			this.makeColumn(t[8], t[9], t[10], t[11]),
			this.makeColumn(t[12], t[13], t[14], t[15])
		];
	}
	length = 16;
	get 0() {
		return this.columns[0].x;
	}
	get 1() {
		return this.columns[0].y;
	}
	get 2() {
		return this.columns[0].z;
	}
	get 3() {
		return this.columns[0].w;
	}
	get 4() {
		return this.columns[1].x;
	}
	get 5() {
		return this.columns[1].y;
	}
	get 6() {
		return this.columns[1].z;
	}
	get 7() {
		return this.columns[1].w;
	}
	get 8() {
		return this.columns[2].x;
	}
	get 9() {
		return this.columns[2].y;
	}
	get 10() {
		return this.columns[2].z;
	}
	get 11() {
		return this.columns[2].w;
	}
	get 12() {
		return this.columns[3].x;
	}
	get 13() {
		return this.columns[3].y;
	}
	get 14() {
		return this.columns[3].z;
	}
	get 15() {
		return this.columns[3].w;
	}
	set 0(t) {
		this.columns[0].x = t;
	}
	set 1(t) {
		this.columns[0].y = t;
	}
	set 2(t) {
		this.columns[0].z = t;
	}
	set 3(t) {
		this.columns[0].w = t;
	}
	set 4(t) {
		this.columns[1].x = t;
	}
	set 5(t) {
		this.columns[1].y = t;
	}
	set 6(t) {
		this.columns[1].z = t;
	}
	set 7(t) {
		this.columns[1].w = t;
	}
	set 8(t) {
		this.columns[2].x = t;
	}
	set 9(t) {
		this.columns[2].y = t;
	}
	set 10(t) {
		this.columns[2].z = t;
	}
	set 11(t) {
		this.columns[2].w = t;
	}
	set 12(t) {
		this.columns[3].x = t;
	}
	set 13(t) {
		this.columns[3].y = t;
	}
	set 14(t) {
		this.columns[3].z = t;
	}
	set 15(t) {
		this.columns[3].w = t;
	}
	*[Symbol.iterator]() {
		for (let t = 0; t < 16; t++) yield this[t];
	}
	[oe]() {
		return x$1(`${this.kind}(${Array.from({ length: this.length }).map((t, n) => this[n]).join(", ")})`, A$1);
	}
	toString() {
		return this[oe]().value;
	}
};
var kt$1 = class extends Pt {
	static {
		__name(this, "kt");
	}
	kind = "mat4x4f";
	makeColumn(t, n, r, a) {
		return v(t, n, r, a);
	}
};
var fn = {
	2: $t(() => ie$1(1, 0, 0, 1), () => x$1("mat2x2f(1, 0, 0, 1)", ie$1), "identity2"),
	3: $t(() => le$1(1, 0, 0, 0, 1, 0, 0, 0, 1), () => x$1("mat3x3f(1, 0, 0, 0, 1, 0, 0, 0, 1)", le$1), "identity3"),
	4: $t(() => A$1(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1), () => x$1("mat4x4f(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)", A$1), "identity4")
};
var gn = $t((e) => A$1(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, e.x, e.y, e.z, 1), (e) => x$1(d$2`mat4x4f(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, ${e}.x, ${e}.y, ${e}.z, 1)`, A$1), "translation4");
var hn = $t((e) => A$1(e.x, 0, 0, 0, 0, e.y, 0, 0, 0, 0, e.z, 0, 0, 0, 0, 1), (e) => x$1(d$2`mat4x4f(${e}.x, 0, 0, 0, 0, ${e}.y, 0, 0, 0, 0, ${e}.z, 0, 0, 0, 0, 1)`, A$1), "scaling4");
var vn = $t((e) => A$1(1, 0, 0, 0, 0, Math.cos(e), Math.sin(e), 0, 0, -Math.sin(e), Math.cos(e), 0, 0, 0, 0, 1), (e) => x$1(d$2`mat4x4f(1, 0, 0, 0, 0, cos(${e}), sin(${e}), 0, 0, -sin(${e}), cos(${e}), 0, 0, 0, 0, 1)`, A$1), "rotationX4");
var bn = $t((e) => A$1(Math.cos(e), 0, -Math.sin(e), 0, 0, 1, 0, 0, Math.sin(e), 0, Math.cos(e), 0, 0, 0, 0, 1), (e) => x$1(d$2`mat4x4f(cos(${e}), 0, -sin(${e}), 0, 0, 1, 0, 0, sin(${e}), 0, cos(${e}), 0, 0, 0, 0, 1)`, A$1), "rotationY4");
var wn = $t((e) => A$1(Math.cos(e), Math.sin(e), 0, 0, -Math.sin(e), Math.cos(e), 0, 0, 0, 0, 1, 0, 0, 0, 0, 1), (e) => x$1(d$2`mat4x4f(cos(${e}), sin(${e}), 0, 0, -sin(${e}), cos(${e}), 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)`, A$1), "rotationZ4");
var ie$1 = Wt$1({
	type: "mat2x2f",
	rows: 2,
	columns: 2,
	MatImpl: Vt$1
});
var le$1 = Wt$1({
	type: "mat3x3f",
	rows: 3,
	columns: 3,
	MatImpl: Ct
});
var A$1 = Wt$1({
	type: "mat4x4f",
	rows: 4,
	columns: 4,
	MatImpl: kt$1
});
function en$1(e) {
	return e?.[kn$1];
}
__name(en$1, "en");
var Sn = {
	f: {
		1: h$1,
		2: B$1,
		3: Le,
		4: v
	},
	h: {
		1: $$3,
		2: hn$1,
		3: dn$1,
		4: fn$1
	},
	i: {
		1: T$1,
		2: pe$3,
		3: je,
		4: xe$2
	},
	u: {
		1: c,
		2: he$3,
		3: E,
		4: de$1
	},
	b: {
		1: b$2,
		2: xn$1,
		3: mn$1,
		4: wn$1
	}
};
var Mn = {
	vec2f: B$1,
	vec2h: hn$1,
	vec2i: pe$3,
	vec2u: he$3,
	"vec2<bool>": xn$1,
	vec3f: Le,
	vec3h: dn$1,
	vec3i: je,
	vec3u: E,
	"vec3<bool>": mn$1,
	vec4f: v,
	vec4h: fn$1,
	vec4i: xe$2,
	vec4u: de$1,
	"vec4<bool>": wn$1,
	mat2x2f: ie$1,
	mat3x3f: le$1,
	mat4x4f: A$1
};
function Xe$1(e, t) {
	if (we$3(e) || ye$2(e)) return e.propTypes[t] ?? ut$1;
	if (e === b$2 || Qe$2(e)) return ut$1;
	let n = t.length;
	if (ae$1(e) && n >= 1 && n <= 4) {
		let a = Sn[e.type.includes("bool") ? "b" : e.type[4]][n];
		if (a) return a;
	}
	return ut$1;
}
__name(Xe$1, "Xe");
var tn$1 = {
	mat2x2f: B$1,
	mat3x3f: Le,
	mat4x4f: v
};
function mt(e) {
	return fe$2(e) || ce$1(e) ? e.elementType : ae$1(e) ? e.primitive : e.type in tn$1 ? tn$1[e.type] : ut$1;
}
function pt$1(e) {
	return e >= 2 ** 63 || e < -(2 ** 63) ? x$1(e, ui) : Number.isInteger(e) ? (Number.isSafeInteger(e) || console.warn(`The integer ${e} exceeds the safe integer range and may have lost precision.`), x$1(e, ai)) : x$1(e, ui);
}
__name(pt$1, "pt");
function yt(e) {
	return e.type === "abstractFloat" ? h$1 : e.type === "abstractInt" ? T$1 : e;
}
function os(e) {
	return e.map((t) => x$1(t.value, yt(t.dataType)));
}
function Tt(e) {
	if (Ce$3(e)) return e;
	return Vt$2(e) || (Ee$2(e) || Xe$2(e) ? x$1(e, Mn[e.kind]) : typeof e == "string" || typeof e == "function" || typeof e == "object" || typeof e == "symbol" || typeof e > "u" || e === null ? x$1(e, ut$1) : typeof e == "number" ? pt$1(e) : typeof e == "boolean" ? x$1(e, b$2) : x$1(e, ut$1));
}
var _t$1 = { get(e, t) {
	if (t in e) return Reflect.get(e, t);
	if (t === "toString" || t === Symbol.toStringTag || t === Symbol.toPrimitive) return () => e.toString();
	if (typeof t == "symbol") return;
	let r = Vt$2(e).dataType;
	let a = Xe$1(r, String(t));
	if (a.type !== "unknown") return new Proxy({
		[o$1]: !0,
		[oe]: (s) => x$1(`${s.resolve(e).value}.${String(t)}`, a),
		get [qe]() {
			return x$1(this, a);
		},
		toString: () => `${String(e)}.${t}`
	}, _t$1);
} };
function ys(e) {
	let t = e;
	for (;;) {
		let n = en$1(t);
		if (!n) break;
		t = n;
	}
	return t;
}
function nn$1(e, t) {
	return new Ut(e, t);
}
__name(nn$1, "nn");
var Ut = class {
	constructor(t, n) {
		this.dataType = t;
		this.#e = n;
	}
	[o$1] = {};
	#e;
	$name(t) {
		return k(this, t), this;
	}
	[oe](t) {
		let n = t.getUniqueName(this);
		let r = t.resolve(this.dataType).value;
		let a = t.resolve(this.#e, this.dataType).value;
		return t.addDeclaration(`const ${n}: ${r} = ${a};`), x$1(n, this.dataType);
	}
	toString() {
		return `const:${D(this) ?? "<unnamed>"}`;
	}
	get [kn$1]() {
		let t = this.dataType;
		return new Proxy({
			[o$1]: !0,
			get [qe]() {
				return x$1(this, t);
			},
			[oe]: (n) => n.resolve(this),
			toString: () => `const:${D(this) ?? "<unnamed>"}.$`
		}, _t$1);
	}
	get value() {
		return Oe$1() ? this[kn$1] : this.#e;
	}
	get $() {
		return this.value;
	}
};
function ws() {
	return {
		[o$1]: !0,
		type: "sampler",
		[Je$2]: void 0
	};
}
function Ss() {
	return {
		[o$1]: !0,
		type: "sampler_comparison",
		[Je$2]: void 0
	};
}
function Ms(e) {
	return !!e[o$1] && e.type === "sampler";
}
function Is(e) {
	return !!e[o$1] && e.type === "sampler_comparison";
}
function Vs(e) {
	if ("multisampled" in e) {
		if (e.multisampled) {
			if (e.dimension === "2d") return $n(e.sampleType);
			throw new Error(`Multisampled textures only support '2d' dimension, got '${e.dimension}'`);
		}
		switch (e.dimension) {
			case "1d": return In(e.sampleType);
			case "2d": return An(e.sampleType);
			case "2d-array": return zn(e.sampleType);
			case "3d": return Cn(e.sampleType);
			case "cube": return Vn(e.sampleType);
			case "cube-array": return Fn(e.sampleType);
			default: throw new Error(`Unsupported texture dimension: '${e.dimension}'`);
		}
	}
	if (!("access" in e)) throw new Error("Descriptor is neither a sampled nor a storage texture");
	switch (e.dimension) {
		case "1d": return Pn(e.format, e.access);
		case "2d": return kn(e.format, e.access);
		case "2d-array": return Wn(e.format, e.access);
		case "3d": return _n(e.format, e.access);
		default: throw new Error(`Unsupported storage texture dimension: '${e.dimension}'`);
	}
}
function L$1(e, t) {
	let r = e.startsWith("texture_depth") ? [
		"depth",
		"float",
		"unfilterable-float"
	] : t.sampleType.type === "i32" ? ["sint"] : t.sampleType.type === "u32" ? ["uint"] : ["float", "unfilterable-float"];
	return {
		[o$1]: !0,
		[Je$2]: void 0,
		type: e,
		bindingSampleType: r,
		...t
	};
}
__name(L$1, "L");
function xt(e, t) {
	return {
		[o$1]: !0,
		[Je$2]: void 0,
		type: e,
		...t
	};
}
var rn$1 = /* @__PURE__ */ new Map();
var dt = {
	"write-only": "write",
	"read-only": "read",
	"read-write": "read_write"
};
function $$1(e, t) {
	let n = rn$1.get(e);
	return n || (n = t(), rn$1.set(e, n)), n;
}
__name($$1, "$");
function In(e) {
	let t = e || h$1;
	return $$1(`texture_1d<${t.type}>`, () => L$1("texture_1d", {
		dimension: "1d",
		sampleType: t,
		multisampled: !1
	}));
}
function An(e) {
	let t = e || h$1;
	return $$1(`texture_2d<${t.type}>`, () => L$1("texture_2d", {
		dimension: "2d",
		sampleType: t,
		multisampled: !1
	}));
}
function $n(e) {
	let t = e || h$1;
	return $$1(`texture_multisampled_2d<${t.type}>`, () => L$1("texture_multisampled_2d", {
		dimension: "2d",
		sampleType: t,
		multisampled: !0
	}));
}
function zn(e) {
	let t = e || h$1;
	return $$1(`texture_2d_array<${t.type}>`, () => L$1("texture_2d_array", {
		dimension: "2d-array",
		sampleType: t,
		multisampled: !1
	}));
}
function Vn(e) {
	let t = e || h$1;
	return $$1(`texture_cube<${t.type}>`, () => L$1("texture_cube", {
		dimension: "cube",
		sampleType: t,
		multisampled: !1
	}));
}
function Fn(e) {
	let t = e || h$1;
	return $$1(`texture_cube_array<${t.type}>`, () => L$1("texture_cube_array", {
		dimension: "cube-array",
		sampleType: t,
		multisampled: !1
	}));
}
function Cn(e) {
	let t = e || h$1;
	return $$1(`texture_3d<${t.type}>`, () => L$1("texture_3d", {
		dimension: "3d",
		sampleType: t,
		multisampled: !1
	}));
}
function Pn(e, t) {
	let n = t || "write-only";
	return $$1(`texture_storage_1d<${e}, ${dt[n]}>`, () => xt("texture_storage_1d", {
		dimension: "1d",
		format: e,
		access: n
	}));
}
function kn(e, t) {
	let n = t || "write-only";
	return $$1(`texture_storage_2d<${e}, ${dt[n]}>`, () => xt("texture_storage_2d", {
		dimension: "2d",
		format: e,
		access: n
	}));
}
function Wn(e, t) {
	let n = t || "write-only";
	return $$1(`texture_storage_2d_array<${e}, ${dt[n]}>`, () => xt("texture_storage_2d_array", {
		dimension: "2d-array",
		format: e,
		access: n
	}));
}
function _n(e, t) {
	let n = t || "write-only";
	return $$1(`texture_storage_3d<${e}, ${dt[n]}>`, () => xt("texture_storage_3d", {
		dimension: "3d",
		format: e,
		access: n
	}));
}
function _s() {
	return $$1("texture_external", () => ({
		[o$1]: !0,
		[Je$2]: void 0,
		type: "texture_external",
		dimension: "2d"
	}));
}
function Us(e) {
	return !!e[o$1] && typeof e.multisampled == "boolean";
}
function Ds(e) {
	return !!e[o$1] && typeof e.format == "string" && typeof e.access == "string";
}
function Gs(e) {
	return new Dt(e);
}
var Dt = class {
	constructor(t) {
		this.inner = t;
	}
	[o$1] = !0;
	type = "atomic";
};
var me$1 = /* @__PURE__ */ __name((e, t, n) => {
	if (e === t) return 0;
	let r = y((n - e) / (t - e), 0, 1);
	return r * r * (3 - 2 * r);
}, "me");
var y = (e, t, n) => Math.min(Math.max(t, e), n);
var he$1 = /* @__PURE__ */ __name((e, t) => t === 0 ? e : Math.trunc(e / t), "he");
function Y(e) {
	let t = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(4));
	return t.setUint32(0, e, !0), t.getFloat32(0, !0);
}
function J(e) {
	let t = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(4));
	return t.setUint32(0, e, !0), t.getInt32(0, !0);
}
var N = xn$1[o$1].jsImpl;
var q = B$1[o$1].jsImpl;
var ye = hn$1[o$1].jsImpl;
var Ue$1 = pe$3[o$1].jsImpl;
var tt$1 = he$3[o$1].jsImpl;
var O$2 = mn$1[o$1].jsImpl;
var _ = Le[o$1].jsImpl;
var ee$1 = dn$1[o$1].jsImpl;
var De$1 = je[o$1].jsImpl;
var nt$1 = E[o$1].jsImpl;
var K = wn$1[o$1].jsImpl;
var j$1 = v[o$1].jsImpl;
var Te$1 = fn$1[o$1].jsImpl;
var Be = xe$2[o$1].jsImpl;
var rt$1 = de$1[o$1].jsImpl;
var Me$1 = /* @__PURE__ */ __name((e) => Math.sqrt(e.x ** 2 + e.y ** 2), "Me");
var Ie$1 = /* @__PURE__ */ __name((e) => Math.sqrt(e.x ** 2 + e.y ** 2 + e.z ** 2), "Ie");
var Ae$1 = /* @__PURE__ */ __name((e) => Math.sqrt(e.x ** 2 + e.y ** 2 + e.z ** 2 + e.w ** 2), "Ae");
var ft = (e, t) => e.x * t.x + e.y * t.y;
var gt = (e, t) => e.x * t.x + e.y * t.y + e.z * t.z;
var ht = (e, t) => e.x * t.x + e.y * t.y + e.z * t.z + e.w * t.w;
var h = (e) => (t) => q(e(t.x), e(t.y));
var b$1 = /* @__PURE__ */ __name((e) => (t) => ye(e(t.x), e(t.y)), "b");
var $e$1 = /* @__PURE__ */ __name((e) => (t) => Ue$1(e(t.x), e(t.y)), "$e");
var Ye$1 = /* @__PURE__ */ __name((e) => (t) => tt$1(e(t.x), e(t.y)), "Ye");
var f = (e) => (t) => _(e(t.x), e(t.y), e(t.z));
var w = (e) => (t) => ee$1(e(t.x), e(t.y), e(t.z));
var ze$1 = /* @__PURE__ */ __name((e) => (t) => De$1(e(t.x), e(t.y), e(t.z)), "ze");
var Je$1 = /* @__PURE__ */ __name((e) => (t) => nt$1(e(t.x), e(t.y), e(t.z)), "Je");
var x = (e) => (t) => j$1(e(t.x), e(t.y), e(t.z), e(t.w));
var S = (e) => (t) => Te$1(e(t.x), e(t.y), e(t.z), e(t.w));
var Ve$2 = /* @__PURE__ */ __name((e) => (t) => Be(e(t.x), e(t.y), e(t.z), e(t.w)), "Ve");
var et$1 = /* @__PURE__ */ __name((e) => (t) => rt$1(e(t.x), e(t.y), e(t.z), e(t.w)), "et");
var sn$1 = /* @__PURE__ */ __name((e) => (t) => {
	let n = t.columns;
	return ie$1(h(e)(n[0]), h(e)(n[1]));
}, "sn");
var an$1 = /* @__PURE__ */ __name((e) => (t) => {
	let n = t.columns;
	return le$1(f(e)(n[0]), f(e)(n[1]), f(e)(n[2]));
}, "an");
var on$1 = /* @__PURE__ */ __name((e) => (t) => {
	let n = t.columns;
	return A$1(x(e)(n[0]), x(e)(n[1]), x(e)(n[2]), x(e)(n[3]));
}, "on");
var pe$1 = /* @__PURE__ */ __name((e) => (t, n) => q(e(t.x, n.x), e(t.y, n.y)), "pe");
var ve = (e) => (t, n) => ye(e(t.x, n.x), e(t.y, n.y));
var Fe$1 = /* @__PURE__ */ __name((e) => (t, n) => Ue$1(e(t.x, n.x), e(t.y, n.y)), "Fe");
var Ce$2 = /* @__PURE__ */ __name((e) => (t, n) => tt$1(e(t.x, n.x), e(t.y, n.y)), "Ce");
var te = (e) => (t, n) => _(e(t.x, n.x), e(t.y, n.y), e(t.z, n.z));
var be$1 = /* @__PURE__ */ __name((e) => (t, n) => ee$1(e(t.x, n.x), e(t.y, n.y), e(t.z, n.z)), "be");
var Pe$1 = /* @__PURE__ */ __name((e) => (t, n) => De$1(e(t.x, n.x), e(t.y, n.y), e(t.z, n.z)), "Pe");
var ke$1 = /* @__PURE__ */ __name((e) => (t, n) => nt$1(e(t.x, n.x), e(t.y, n.y), e(t.z, n.z)), "ke");
var X = (e) => (t, n) => j$1(e(t.x, n.x), e(t.y, n.y), e(t.z, n.z), e(t.w, n.w));
var we$2 = /* @__PURE__ */ __name((e) => (t, n) => Te$1(e(t.x, n.x), e(t.y, n.y), e(t.z, n.z), e(t.w, n.w)), "we");
var We$1 = /* @__PURE__ */ __name((e) => (t, n) => Be(e(t.x, n.x), e(t.y, n.y), e(t.z, n.z), e(t.w, n.w)), "We");
var _e$1 = /* @__PURE__ */ __name((e) => (t, n) => rt$1(e(t.x, n.x), e(t.y, n.y), e(t.z, n.z), e(t.w, n.w)), "_e");
var Un = (e) => (t, n) => {
	let r = t.columns;
	let a = n.columns;
	return ie$1(pe$1(e)(r[0], a[0]), pe$1(e)(r[1], a[1]));
};
var Dn = (e) => (t, n) => {
	let r = t.columns;
	let a = n.columns;
	return le$1(te(e)(r[0], a[0]), te(e)(r[1], a[1]), te(e)(r[2], a[2]));
};
var Bn = (e) => (t, n) => {
	let r = t.columns;
	let a = n.columns;
	return A$1(X(e)(r[0], a[0]), X(e)(r[1], a[1]), X(e)(r[2], a[2]), X(e)(r[3], a[3]));
};
var Rn = (e) => (t, n, r) => q(e(t.x, n.x, r.x), e(t.y, n.y, r.y));
var Gn = (e) => (t, n, r) => ye(e(t.x, n.x, r.x), e(t.y, n.y, r.y));
var En = (e) => (t, n, r) => _(e(t.x, n.x, r.x), e(t.y, n.y, r.y), e(t.z, n.z, r.z));
var Ln = (e) => (t, n, r) => ee$1(e(t.x, n.x, r.x), e(t.y, n.y, r.y), e(t.z, n.z, r.z));
var Nn = (e) => (t, n, r) => j$1(e(t.x, n.x, r.x), e(t.y, n.y, r.y), e(t.z, n.z, r.z), e(t.w, n.w, r.w));
var On = (e) => (t, n, r) => Te$1(e(t.x, n.x, r.x), e(t.y, n.y, r.y), e(t.z, n.z, r.z), e(t.w, n.w, r.w));
var m = {
	eq: {
		vec2f: (e, t) => N(e.x === t.x, e.y === t.y),
		vec2h: (e, t) => N(e.x === t.x, e.y === t.y),
		vec2i: (e, t) => N(e.x === t.x, e.y === t.y),
		vec2u: (e, t) => N(e.x === t.x, e.y === t.y),
		"vec2<bool>": (e, t) => N(e.x === t.x, e.y === t.y),
		vec3f: (e, t) => O$2(e.x === t.x, e.y === t.y, e.z === t.z),
		vec3h: (e, t) => O$2(e.x === t.x, e.y === t.y, e.z === t.z),
		vec3i: (e, t) => O$2(e.x === t.x, e.y === t.y, e.z === t.z),
		vec3u: (e, t) => O$2(e.x === t.x, e.y === t.y, e.z === t.z),
		"vec3<bool>": (e, t) => O$2(e.x === t.x, e.y === t.y, e.z === t.z),
		vec4f: (e, t) => K(e.x === t.x, e.y === t.y, e.z === t.z, e.w === t.w),
		vec4h: (e, t) => K(e.x === t.x, e.y === t.y, e.z === t.z, e.w === t.w),
		vec4i: (e, t) => K(e.x === t.x, e.y === t.y, e.z === t.z, e.w === t.w),
		vec4u: (e, t) => K(e.x === t.x, e.y === t.y, e.z === t.z, e.w === t.w),
		"vec4<bool>": (e, t) => K(e.x === t.x, e.y === t.y, e.z === t.z, e.w === t.w)
	},
	lt: {
		vec2f: (e, t) => N(e.x < t.x, e.y < t.y),
		vec2h: (e, t) => N(e.x < t.x, e.y < t.y),
		vec2i: (e, t) => N(e.x < t.x, e.y < t.y),
		vec2u: (e, t) => N(e.x < t.x, e.y < t.y),
		vec3f: (e, t) => O$2(e.x < t.x, e.y < t.y, e.z < t.z),
		vec3h: (e, t) => O$2(e.x < t.x, e.y < t.y, e.z < t.z),
		vec3i: (e, t) => O$2(e.x < t.x, e.y < t.y, e.z < t.z),
		vec3u: (e, t) => O$2(e.x < t.x, e.y < t.y, e.z < t.z),
		vec4f: (e, t) => K(e.x < t.x, e.y < t.y, e.z < t.z, e.w < t.w),
		vec4h: (e, t) => K(e.x < t.x, e.y < t.y, e.z < t.z, e.w < t.w),
		vec4i: (e, t) => K(e.x < t.x, e.y < t.y, e.z < t.z, e.w < t.w),
		vec4u: (e, t) => K(e.x < t.x, e.y < t.y, e.z < t.z, e.w < t.w)
	},
	or: {
		"vec2<bool>": (e, t) => N(e.x || t.x, e.y || t.y),
		"vec3<bool>": (e, t) => O$2(e.x || t.x, e.y || t.y, e.z || t.z),
		"vec4<bool>": (e, t) => K(e.x || t.x, e.y || t.y, e.z || t.z, e.w || t.w)
	},
	all: {
		"vec2<bool>": (e) => e.x && e.y,
		"vec3<bool>": (e) => e.x && e.y && e.z,
		"vec4<bool>": (e) => e.x && e.y && e.z && e.w
	},
	abs: {
		vec2f: h(Math.abs),
		vec2h: b$1(Math.abs),
		vec2i: $e$1(Math.abs),
		vec2u: Ye$1(Math.abs),
		vec3f: f(Math.abs),
		vec3h: w(Math.abs),
		vec3i: ze$1(Math.abs),
		vec3u: Je$1(Math.abs),
		vec4f: x(Math.abs),
		vec4h: S(Math.abs),
		vec4i: Ve$2(Math.abs),
		vec4u: et$1(Math.abs)
	},
	atan2: {
		vec2f: pe$1(Math.atan2),
		vec2h: ve(Math.atan2),
		vec3f: te(Math.atan2),
		vec3h: be$1(Math.atan2),
		vec4f: X(Math.atan2),
		vec4h: we$2(Math.atan2)
	},
	acos: {
		vec2f: h(Math.acos),
		vec2h: b$1(Math.acos),
		vec2i: $e$1(Math.acos),
		vec2u: Ye$1(Math.acos),
		vec3f: f(Math.acos),
		vec3h: w(Math.acos),
		vec3i: ze$1(Math.acos),
		vec3u: Je$1(Math.acos),
		vec4f: x(Math.acos),
		vec4h: S(Math.acos),
		vec4i: Ve$2(Math.acos),
		vec4u: et$1(Math.acos)
	},
	acosh: {
		vec2f: h(Math.acosh),
		vec2h: b$1(Math.acosh),
		vec3f: f(Math.acosh),
		vec3h: w(Math.acosh),
		vec4f: x(Math.acosh),
		vec4h: S(Math.acosh)
	},
	asin: {
		vec2f: h(Math.asin),
		vec2h: b$1(Math.asin),
		vec3f: f(Math.asin),
		vec3h: w(Math.asin),
		vec4f: x(Math.asin),
		vec4h: S(Math.asin)
	},
	asinh: {
		vec2f: h(Math.asinh),
		vec2h: b$1(Math.asinh),
		vec3f: f(Math.asinh),
		vec3h: w(Math.asinh),
		vec4f: x(Math.asinh),
		vec4h: S(Math.asinh)
	},
	atan: {
		vec2f: h(Math.atan),
		vec2h: b$1(Math.atan),
		vec3f: f(Math.atan),
		vec3h: w(Math.atan),
		vec4f: x(Math.atan),
		vec4h: S(Math.atan)
	},
	atanh: {
		vec2f: h(Math.atanh),
		vec2h: b$1(Math.atanh),
		vec3f: f(Math.atanh),
		vec3h: w(Math.atanh),
		vec4f: x(Math.atanh),
		vec4h: S(Math.atanh)
	},
	ceil: {
		vec2f: h(Math.ceil),
		vec2h: b$1(Math.ceil),
		vec3f: f(Math.ceil),
		vec3h: w(Math.ceil),
		vec4f: x(Math.ceil),
		vec4h: S(Math.ceil)
	},
	clamp: {
		vec2f: (e, t, n) => q(y(e.x, t.x, n.x), y(e.y, t.y, n.y)),
		vec2h: (e, t, n) => ye(y(e.x, t.x, n.x), y(e.y, t.y, n.y)),
		vec2i: (e, t, n) => Ue$1(y(e.x, t.x, n.x), y(e.y, t.y, n.y)),
		vec2u: (e, t, n) => tt$1(y(e.x, t.x, n.x), y(e.y, t.y, n.y)),
		vec3f: (e, t, n) => _(y(e.x, t.x, n.x), y(e.y, t.y, n.y), y(e.z, t.z, n.z)),
		vec3h: (e, t, n) => ee$1(y(e.x, t.x, n.x), y(e.y, t.y, n.y), y(e.z, t.z, n.z)),
		vec3i: (e, t, n) => De$1(y(e.x, t.x, n.x), y(e.y, t.y, n.y), y(e.z, t.z, n.z)),
		vec3u: (e, t, n) => nt$1(y(e.x, t.x, n.x), y(e.y, t.y, n.y), y(e.z, t.z, n.z)),
		vec4f: (e, t, n) => j$1(y(e.x, t.x, n.x), y(e.y, t.y, n.y), y(e.z, t.z, n.z), y(e.w, t.w, n.w)),
		vec4h: (e, t, n) => Te$1(y(e.x, t.x, n.x), y(e.y, t.y, n.y), y(e.z, t.z, n.z), y(e.w, t.w, n.w)),
		vec4i: (e, t, n) => Be(y(e.x, t.x, n.x), y(e.y, t.y, n.y), y(e.z, t.z, n.z), y(e.w, t.w, n.w)),
		vec4u: (e, t, n) => rt$1(y(e.x, t.x, n.x), y(e.y, t.y, n.y), y(e.z, t.z, n.z), y(e.w, t.w, n.w))
	},
	length: {
		vec2f: Me$1,
		vec2h: Me$1,
		vec3f: Ie$1,
		vec3h: Ie$1,
		vec4f: Ae$1,
		vec4h: Ae$1
	},
	add: {
		vec2f: pe$1((e, t) => e + t),
		vec2h: ve((e, t) => e + t),
		vec2i: Fe$1((e, t) => e + t),
		vec2u: Ce$2((e, t) => e + t),
		vec3f: te((e, t) => e + t),
		vec3h: be$1((e, t) => e + t),
		vec3i: Pe$1((e, t) => e + t),
		vec3u: ke$1((e, t) => e + t),
		vec4f: X((e, t) => e + t),
		vec4h: we$2((e, t) => e + t),
		vec4i: We$1((e, t) => e + t),
		vec4u: _e$1((e, t) => e + t),
		mat2x2f: Un((e, t) => e + t),
		mat3x3f: Dn((e, t) => e + t),
		mat4x4f: Bn((e, t) => e + t)
	},
	smoothstep: {
		vec2f: Rn(me$1),
		vec2h: Gn(me$1),
		vec3f: En(me$1),
		vec3h: Ln(me$1),
		vec4f: Nn(me$1),
		vec4h: On(me$1)
	},
	addMixed: {
		vec2f: (e, t) => h((n) => n + t)(e),
		vec2h: (e, t) => b$1((n) => n + t)(e),
		vec2i: (e, t) => $e$1((n) => n + t)(e),
		vec2u: (e, t) => Ye$1((n) => n + t)(e),
		vec3f: (e, t) => f((n) => n + t)(e),
		vec3h: (e, t) => w((n) => n + t)(e),
		vec3i: (e, t) => ze$1((n) => n + t)(e),
		vec3u: (e, t) => Je$1((n) => n + t)(e),
		vec4f: (e, t) => x((n) => n + t)(e),
		vec4h: (e, t) => S((n) => n + t)(e),
		vec4i: (e, t) => Ve$2((n) => n + t)(e),
		vec4u: (e, t) => et$1((n) => n + t)(e),
		mat2x2f: (e, t) => sn$1((n) => n + t)(e),
		mat3x3f: (e, t) => an$1((n) => n + t)(e),
		mat4x4f: (e, t) => on$1((n) => n + t)(e)
	},
	mulSxV: {
		vec2f: (e, t) => h((n) => e * n)(t),
		vec2h: (e, t) => b$1((n) => e * n)(t),
		vec2i: (e, t) => $e$1((n) => e * n)(t),
		vec2u: (e, t) => Ye$1((n) => e * n)(t),
		vec3f: (e, t) => f((n) => e * n)(t),
		vec3h: (e, t) => w((n) => e * n)(t),
		vec3i: (e, t) => ze$1((n) => e * n)(t),
		vec3u: (e, t) => Je$1((n) => e * n)(t),
		vec4f: (e, t) => x((n) => e * n)(t),
		vec4h: (e, t) => S((n) => e * n)(t),
		vec4i: (e, t) => Ve$2((n) => e * n)(t),
		vec4u: (e, t) => et$1((n) => e * n)(t),
		mat2x2f: (e, t) => sn$1((n) => e * n)(t),
		mat3x3f: (e, t) => an$1((n) => e * n)(t),
		mat4x4f: (e, t) => on$1((n) => e * n)(t)
	},
	mulVxV: {
		vec2f: pe$1((e, t) => e * t),
		vec2h: ve((e, t) => e * t),
		vec2i: Fe$1((e, t) => e * t),
		vec2u: Ce$2((e, t) => e * t),
		vec3f: te((e, t) => e * t),
		vec3h: be$1((e, t) => e * t),
		vec3i: Pe$1((e, t) => e * t),
		vec3u: ke$1((e, t) => e * t),
		vec4f: X((e, t) => e * t),
		vec4h: we$2((e, t) => e * t),
		vec4i: We$1((e, t) => e * t),
		vec4u: _e$1((e, t) => e * t),
		mat2x2f: (e, t) => {
			let n = e.columns;
			let r = t.columns;
			return ie$1(n[0].x * r[0].x + n[1].x * r[0].y, n[0].y * r[0].x + n[1].y * r[0].y, n[0].x * r[1].x + n[1].x * r[1].y, n[0].y * r[1].x + n[1].y * r[1].y);
		},
		mat3x3f: (e, t) => {
			let n = e.columns;
			let r = t.columns;
			return le$1(n[0].x * r[0].x + n[1].x * r[0].y + n[2].x * r[0].z, n[0].y * r[0].x + n[1].y * r[0].y + n[2].y * r[0].z, n[0].z * r[0].x + n[1].z * r[0].y + n[2].z * r[0].z, n[0].x * r[1].x + n[1].x * r[1].y + n[2].x * r[1].z, n[0].y * r[1].x + n[1].y * r[1].y + n[2].y * r[1].z, n[0].z * r[1].x + n[1].z * r[1].y + n[2].z * r[1].z, n[0].x * r[2].x + n[1].x * r[2].y + n[2].x * r[2].z, n[0].y * r[2].x + n[1].y * r[2].y + n[2].y * r[2].z, n[0].z * r[2].x + n[1].z * r[2].y + n[2].z * r[2].z);
		},
		mat4x4f: (e, t) => {
			let n = e.columns;
			let r = t.columns;
			return A$1(n[0].x * r[0].x + n[1].x * r[0].y + n[2].x * r[0].z + n[3].x * r[0].w, n[0].y * r[0].x + n[1].y * r[0].y + n[2].y * r[0].z + n[3].y * r[0].w, n[0].z * r[0].x + n[1].z * r[0].y + n[2].z * r[0].z + n[3].z * r[0].w, n[0].w * r[0].x + n[1].w * r[0].y + n[2].w * r[0].z + n[3].w * r[0].w, n[0].x * r[1].x + n[1].x * r[1].y + n[2].x * r[1].z + n[3].x * r[1].w, n[0].y * r[1].x + n[1].y * r[1].y + n[2].y * r[1].z + n[3].y * r[1].w, n[0].z * r[1].x + n[1].z * r[1].y + n[2].z * r[1].z + n[3].z * r[1].w, n[0].w * r[1].x + n[1].w * r[1].y + n[2].w * r[1].z + n[3].w * r[1].w, n[0].x * r[2].x + n[1].x * r[2].y + n[2].x * r[2].z + n[3].x * r[2].w, n[0].y * r[2].x + n[1].y * r[2].y + n[2].y * r[2].z + n[3].y * r[2].w, n[0].z * r[2].x + n[1].z * r[2].y + n[2].z * r[2].z + n[3].z * r[2].w, n[0].w * r[2].x + n[1].w * r[2].y + n[2].w * r[2].z + n[3].w * r[2].w, n[0].x * r[3].x + n[1].x * r[3].y + n[2].x * r[3].z + n[3].x * r[3].w, n[0].y * r[3].x + n[1].y * r[3].y + n[2].y * r[3].z + n[3].y * r[3].w, n[0].z * r[3].x + n[1].z * r[3].y + n[2].z * r[3].z + n[3].z * r[3].w, n[0].w * r[3].x + n[1].w * r[3].y + n[2].w * r[3].z + n[3].w * r[3].w);
		}
	},
	mulMxV: {
		mat2x2f: (e, t) => {
			let n = e.columns;
			return q(n[0].x * t.x + n[1].x * t.y, n[0].y * t.x + n[1].y * t.y);
		},
		mat3x3f: (e, t) => {
			let n = e.columns;
			return _(n[0].x * t.x + n[1].x * t.y + n[2].x * t.z, n[0].y * t.x + n[1].y * t.y + n[2].y * t.z, n[0].z * t.x + n[1].z * t.y + n[2].z * t.z);
		},
		mat4x4f: (e, t) => {
			let n = e.columns;
			return j$1(n[0].x * t.x + n[1].x * t.y + n[2].x * t.z + n[3].x * t.w, n[0].y * t.x + n[1].y * t.y + n[2].y * t.z + n[3].y * t.w, n[0].z * t.x + n[1].z * t.y + n[2].z * t.z + n[3].z * t.w, n[0].w * t.x + n[1].w * t.y + n[2].w * t.z + n[3].w * t.w);
		}
	},
	mulVxM: {
		mat2x2f: (e, t) => {
			let n = t.columns;
			return q(e.x * n[0].x + e.y * n[0].y, e.x * n[1].x + e.y * n[1].y);
		},
		mat3x3f: (e, t) => {
			let n = t.columns;
			return _(e.x * n[0].x + e.y * n[0].y + e.z * n[0].z, e.x * n[1].x + e.y * n[1].y + e.z * n[1].z, e.x * n[2].x + e.y * n[2].y + e.z * n[2].z);
		},
		mat4x4f: (e, t) => {
			let n = t.columns;
			return j$1(e.x * n[0].x + e.y * n[0].y + e.z * n[0].z + e.w * n[0].w, e.x * n[1].x + e.y * n[1].y + e.z * n[1].z + e.w * n[1].w, e.x * n[2].x + e.y * n[2].y + e.z * n[2].z + e.w * n[2].w, e.x * n[3].x + e.y * n[3].y + e.z * n[3].z + e.w * n[3].w);
		}
	},
	div: {
		vec2f: pe$1((e, t) => e / t),
		vec2h: ve((e, t) => e / t),
		vec2i: Fe$1(he$1),
		vec2u: Ce$2(he$1),
		vec3f: te((e, t) => e / t),
		vec3h: be$1((e, t) => e / t),
		vec3i: Pe$1(he$1),
		vec3u: ke$1(he$1),
		vec4f: X((e, t) => e / t),
		vec4h: we$2((e, t) => e / t),
		vec4i: We$1(he$1),
		vec4u: _e$1(he$1)
	},
	dot: {
		vec2f: ft,
		vec2h: ft,
		vec2i: ft,
		vec2u: ft,
		vec3f: gt,
		vec3h: gt,
		vec3i: gt,
		vec3u: gt,
		vec4f: ht,
		vec4h: ht,
		vec4i: ht,
		vec4u: ht
	},
	normalize: {
		vec2f: (e) => {
			let t = Me$1(e);
			return q(e.x / t, e.y / t);
		},
		vec2h: (e) => {
			let t = Me$1(e);
			return ye(e.x / t, e.y / t);
		},
		vec2i: (e) => {
			let t = Me$1(e);
			return Ue$1(e.x / t, e.y / t);
		},
		vec2u: (e) => {
			let t = Me$1(e);
			return tt$1(e.x / t, e.y / t);
		},
		vec3f: (e) => {
			let t = Ie$1(e);
			return _(e.x / t, e.y / t, e.z / t);
		},
		vec3h: (e) => {
			let t = Ie$1(e);
			return ee$1(e.x / t, e.y / t, e.z / t);
		},
		vec3i: (e) => {
			let t = Ie$1(e);
			return De$1(e.x / t, e.y / t, e.z / t);
		},
		vec3u: (e) => {
			let t = Ie$1(e);
			return nt$1(e.x / t, e.y / t, e.z / t);
		},
		vec4f: (e) => {
			let t = Ae$1(e);
			return j$1(e.x / t, e.y / t, e.z / t, e.w / t);
		},
		vec4h: (e) => {
			let t = Ae$1(e);
			return Te$1(e.x / t, e.y / t, e.z / t, e.w / t);
		},
		vec4i: (e) => {
			let t = Ae$1(e);
			return Be(e.x / t, e.y / t, e.z / t, e.w / t);
		},
		vec4u: (e) => {
			let t = Ae$1(e);
			return rt$1(e.x / t, e.y / t, e.z / t, e.w / t);
		}
	},
	cross: {
		vec3f: (e, t) => _(e.y * t.z - e.z * t.y, e.z * t.x - e.x * t.z, e.x * t.y - e.y * t.x),
		vec3h: (e, t) => ee$1(e.y * t.z - e.z * t.y, e.z * t.x - e.x * t.z, e.x * t.y - e.y * t.x)
	},
	mod: {
		vec2f: pe$1((e, t) => e % t),
		vec2h: ve((e, t) => e % t),
		vec2i: Fe$1((e, t) => e % t),
		vec2u: Ce$2((e, t) => e % t),
		vec3f: te((e, t) => e % t),
		vec3h: be$1((e, t) => e % t),
		vec3i: Pe$1((e, t) => e % t),
		vec3u: ke$1((e, t) => e % t),
		vec4f: X((e, t) => e % t),
		vec4h: we$2((e, t) => e % t),
		vec4i: We$1((e, t) => e % t),
		vec4u: _e$1((e, t) => e % t)
	},
	floor: {
		vec2f: h(Math.floor),
		vec2h: b$1(Math.floor),
		vec3f: f(Math.floor),
		vec3h: w(Math.floor),
		vec4f: x(Math.floor),
		vec4h: S(Math.floor)
	},
	max: {
		vec2f: pe$1(Math.max),
		vec2h: ve(Math.max),
		vec2i: Fe$1(Math.max),
		vec2u: Ce$2(Math.max),
		vec3f: te(Math.max),
		vec3h: be$1(Math.max),
		vec3i: Pe$1(Math.max),
		vec3u: ke$1(Math.max),
		vec4f: X(Math.max),
		vec4h: we$2(Math.max),
		vec4i: We$1(Math.max),
		vec4u: _e$1(Math.max)
	},
	min: {
		vec2f: pe$1(Math.min),
		vec2h: ve(Math.min),
		vec2i: Fe$1(Math.min),
		vec2u: Ce$2(Math.min),
		vec3f: te(Math.min),
		vec3h: be$1(Math.min),
		vec3i: Pe$1(Math.min),
		vec3u: ke$1(Math.min),
		vec4f: X(Math.min),
		vec4h: we$2(Math.min),
		vec4i: We$1(Math.min),
		vec4u: _e$1(Math.min)
	},
	pow: {
		vec2f: (e, t) => q(e.x ** t.x, e.y ** t.y),
		vec2h: (e, t) => ye(e.x ** t.x, e.y ** t.y),
		vec3f: (e, t) => _(e.x ** t.x, e.y ** t.y, e.z ** t.z),
		vec3h: (e, t) => ee$1(e.x ** t.x, e.y ** t.y, e.z ** t.z),
		vec4f: (e, t) => j$1(e.x ** t.x, e.y ** t.y, e.z ** t.z, e.w ** t.w),
		vec4h: (e, t) => Te$1(e.x ** t.x, e.y ** t.y, e.z ** t.z, e.w ** t.w)
	},
	sign: {
		vec2f: h(Math.sign),
		vec2h: b$1(Math.sign),
		vec2i: $e$1(Math.sign),
		vec3f: f(Math.sign),
		vec3h: w(Math.sign),
		vec3i: ze$1(Math.sign),
		vec4f: x(Math.sign),
		vec4h: S(Math.sign),
		vec4i: Ve$2(Math.sign)
	},
	sqrt: {
		vec2f: h(Math.sqrt),
		vec2h: b$1(Math.sqrt),
		vec3f: f(Math.sqrt),
		vec3h: w(Math.sqrt),
		vec4f: x(Math.sqrt),
		vec4h: S(Math.sqrt)
	},
	mix: {
		vec2f: (e, t, n) => typeof n == "number" ? q(e.x * (1 - n) + t.x * n, e.y * (1 - n) + t.y * n) : q(e.x * (1 - n.x) + t.x * n.x, e.y * (1 - n.y) + t.y * n.y),
		vec2h: (e, t, n) => typeof n == "number" ? ye(e.x * (1 - n) + t.x * n, e.y * (1 - n) + t.y * n) : ye(e.x * (1 - n.x) + t.x * n.x, e.y * (1 - n.y) + t.y * n.y),
		vec3f: (e, t, n) => typeof n == "number" ? _(e.x * (1 - n) + t.x * n, e.y * (1 - n) + t.y * n, e.z * (1 - n) + t.z * n) : _(e.x * (1 - n.x) + t.x * n.x, e.y * (1 - n.y) + t.y * n.y, e.z * (1 - n.z) + t.z * n.z),
		vec3h: (e, t, n) => typeof n == "number" ? ee$1(e.x * (1 - n) + t.x * n, e.y * (1 - n) + t.y * n, e.z * (1 - n) + t.z * n) : ee$1(e.x * (1 - n.x) + t.x * n.x, e.y * (1 - n.y) + t.y * n.y, e.z * (1 - n.z) + t.z * n.z),
		vec4f: (e, t, n) => typeof n == "number" ? j$1(e.x * (1 - n) + t.x * n, e.y * (1 - n) + t.y * n, e.z * (1 - n) + t.z * n, e.w * (1 - n) + t.w * n) : j$1(e.x * (1 - n.x) + t.x * n.x, e.y * (1 - n.y) + t.y * n.y, e.z * (1 - n.z) + t.z * n.z, e.w * (1 - n.w) + t.w * n.w),
		vec4h: (e, t, n) => typeof n == "number" ? Te$1(e.x * (1 - n) + t.x * n, e.y * (1 - n) + t.y * n, e.z * (1 - n) + t.z * n, e.w * (1 - n) + t.w * n) : Te$1(e.x * (1 - n.x) + t.x * n.x, e.y * (1 - n.y) + t.y * n.y, e.z * (1 - n.z) + t.z * n.z, e.w * (1 - n.w) + t.w * n.w)
	},
	sin: {
		vec2f: h(Math.sin),
		vec2h: b$1(Math.sin),
		vec3f: f(Math.sin),
		vec3h: w(Math.sin),
		vec4f: x(Math.sin),
		vec4h: S(Math.sin)
	},
	cos: {
		vec2f: h(Math.cos),
		vec2h: b$1(Math.cos),
		vec3f: f(Math.cos),
		vec3h: w(Math.cos),
		vec4f: x(Math.cos),
		vec4h: S(Math.cos)
	},
	cosh: {
		vec2f: h(Math.cosh),
		vec2h: b$1(Math.cosh),
		vec3f: f(Math.cosh),
		vec3h: w(Math.cosh),
		vec4f: x(Math.cosh),
		vec4h: S(Math.cosh)
	},
	exp: {
		vec2f: h(Math.exp),
		vec2h: b$1(Math.exp),
		vec3f: f(Math.exp),
		vec3h: w(Math.exp),
		vec4f: x(Math.exp),
		vec4h: S(Math.exp)
	},
	exp2: {
		vec2f: h((e) => 2 ** e),
		vec2h: b$1((e) => 2 ** e),
		vec3f: f((e) => 2 ** e),
		vec3h: w((e) => 2 ** e),
		vec4f: x((e) => 2 ** e),
		vec4h: S((e) => 2 ** e)
	},
	log: {
		vec2f: h(Math.log),
		vec2h: b$1(Math.log),
		vec3f: f(Math.log),
		vec3h: w(Math.log),
		vec4f: x(Math.log),
		vec4h: S(Math.log)
	},
	log2: {
		vec2f: h(Math.log2),
		vec2h: b$1(Math.log2),
		vec3f: f(Math.log2),
		vec3h: w(Math.log2),
		vec4f: x(Math.log2),
		vec4h: S(Math.log2)
	},
	fract: {
		vec2f: h((e) => e - Math.floor(e)),
		vec2h: b$1((e) => e - Math.floor(e)),
		vec3f: f((e) => e - Math.floor(e)),
		vec3h: w((e) => e - Math.floor(e)),
		vec4f: x((e) => e - Math.floor(e)),
		vec4h: S((e) => e - Math.floor(e))
	},
	isCloseToZero: {
		vec2f: (e, t) => Math.abs(e.x) <= t && Math.abs(e.y) <= t,
		vec2h: (e, t) => Math.abs(e.x) <= t && Math.abs(e.y) <= t,
		vec3f: (e, t) => Math.abs(e.x) <= t && Math.abs(e.y) <= t && Math.abs(e.z) <= t,
		vec3h: (e, t) => Math.abs(e.x) <= t && Math.abs(e.y) <= t && Math.abs(e.z) <= t,
		vec4f: (e, t) => Math.abs(e.x) <= t && Math.abs(e.y) <= t && Math.abs(e.z) <= t && Math.abs(e.w) <= t,
		vec4h: (e, t) => Math.abs(e.x) <= t && Math.abs(e.y) <= t && Math.abs(e.z) <= t && Math.abs(e.w) <= t
	},
	neg: {
		vec2f: h((e) => -e),
		vec2h: b$1((e) => -e),
		vec2i: $e$1((e) => -e),
		vec2u: Ye$1((e) => -e),
		"vec2<bool>": (e) => N(!e.x, !e.y),
		vec3f: f((e) => -e),
		vec3h: w((e) => -e),
		vec3i: ze$1((e) => -e),
		vec3u: Je$1((e) => -e),
		"vec3<bool>": (e) => O$2(!e.x, !e.y, !e.z),
		vec4f: x((e) => -e),
		vec4h: S((e) => -e),
		vec4i: Ve$2((e) => -e),
		vec4u: et$1((e) => -e),
		"vec4<bool>": (e) => K(!e.x, !e.y, !e.z, !e.w)
	},
	select: {
		vec2f: (e, t, n) => q(n.x ? t.x : e.x, n.y ? t.y : e.y),
		vec2h: (e, t, n) => ye(n.x ? t.x : e.x, n.y ? t.y : e.y),
		vec2i: (e, t, n) => Ue$1(n.x ? t.x : e.x, n.y ? t.y : e.y),
		vec2u: (e, t, n) => tt$1(n.x ? t.x : e.x, n.y ? t.y : e.y),
		"vec2<bool>": (e, t, n) => N(n.x ? t.x : e.x, n.y ? t.y : e.y),
		vec3f: (e, t, n) => _(n.x ? t.x : e.x, n.y ? t.y : e.y, n.z ? t.z : e.z),
		vec3h: (e, t, n) => ee$1(n.x ? t.x : e.x, n.y ? t.y : e.y, n.z ? t.z : e.z),
		vec3i: (e, t, n) => De$1(n.x ? t.x : e.x, n.y ? t.y : e.y, n.z ? t.z : e.z),
		vec3u: (e, t, n) => nt$1(n.x ? t.x : e.x, n.y ? t.y : e.y, n.z ? t.z : e.z),
		"vec3<bool>": (e, t, n) => O$2(n.x ? t.x : e.x, n.y ? t.y : e.y, n.z ? t.z : e.z),
		vec4f: (e, t, n) => j$1(n.x ? t.x : e.x, n.y ? t.y : e.y, n.z ? t.z : e.z, n.w ? t.w : e.w),
		vec4h: (e, t, n) => Te$1(n.x ? t.x : e.x, n.y ? t.y : e.y, n.z ? t.z : e.z, n.w ? t.w : e.w),
		vec4i: (e, t, n) => Be(n.x ? t.x : e.x, n.y ? t.y : e.y, n.z ? t.z : e.z, n.w ? t.w : e.w),
		vec4u: (e, t, n) => rt$1(n.x ? t.x : e.x, n.y ? t.y : e.y, n.z ? t.z : e.z, n.w ? t.w : e.w),
		"vec4<bool>": (e, t, n) => K(n.x ? t.x : e.x, n.y ? t.y : e.y, n.z ? t.z : e.z, n.w ? t.w : e.w)
	},
	tanh: {
		vec2f: h(Math.tanh),
		vec2h: b$1(Math.tanh),
		vec3f: f(Math.tanh),
		vec3h: w(Math.tanh),
		vec4f: x(Math.tanh),
		vec4h: S(Math.tanh)
	},
	bitcastU32toF32: {
		vec2u: (e) => q(Y(e.x), Y(e.y)),
		vec3u: (e) => _(Y(e.x), Y(e.y), Y(e.z)),
		vec4u: (e) => j$1(Y(e.x), Y(e.y), Y(e.z), Y(e.w))
	},
	bitcastU32toI32: {
		vec2u: (e) => Ue$1(J(e.x), J(e.y)),
		vec3u: (e) => De$1(J(e.x), J(e.y), J(e.z)),
		vec4u: (e) => Be(J(e.x), J(e.y), J(e.z), J(e.w))
	}
};
function un(e, t) {
	if (typeof e == "number" && typeof t == "number") return e + t;
	if (typeof e == "number" && Ee$2(t)) return m.addMixed[t.kind](t, e);
	if (Ee$2(e) && typeof t == "number") return m.addMixed[e.kind](e, t);
	if (Ee$2(e) && Ee$2(t) || Xe$2(e) && Xe$2(t)) return m.add[e.kind](e, t);
	throw new Error("Add/Sub called with invalid arguments.");
}
var Bt = P({
	name: "add",
	signature: (...e) => {
		let t = Hr$1(e) ?? e;
		return {
			argTypes: t,
			returnType: Qe$2(t[0]) ? t[1] : t[0]
		};
	},
	normalImpl: un,
	codegenImpl: (e, t) => d$2`(${e} + ${t})`
});
function Kn$1(e, t) {
	return un(e, cn(-1, t));
}
__name(Kn$1, "Kn");
var Re = P({
	name: "sub",
	signature: (...e) => {
		let t = Hr$1(e) ?? e;
		return {
			argTypes: t,
			returnType: Qe$2(t[0]) ? t[1] : t[0]
		};
	},
	normalImpl: Kn$1,
	codegenImpl: (e, t) => d$2`(${e} - ${t})`
});
function cn(e, t) {
	if (typeof e == "number" && typeof t == "number") return e * t;
	if (typeof e == "number" && (Ee$2(t) || Xe$2(t))) return m.mulSxV[t.kind](e, t);
	if ((Ee$2(e) || Xe$2(e)) && typeof t == "number") return m.mulSxV[e.kind](t, e);
	if (Ee$2(e) && Ee$2(t)) return m.mulVxV[e.kind](e, t);
	if (Ln$1(e) && Xe$2(t)) return m.mulVxM[t.kind](e, t);
	if (Xe$2(e) && Ln$1(t)) return m.mulMxV[e.kind](e, t);
	if (Xe$2(e) && Xe$2(t)) return m.mulVxV[e.kind](e, t);
	throw new Error("Mul called with invalid arguments.");
}
var st$1 = P({
	name: "mul",
	signature: (...e) => {
		let t = Hr$1(e) ?? e;
		return {
			argTypes: t,
			returnType: Qe$2(t[0]) ? t[1] : Qe$2(t[1]) || t[0].type.startsWith("vec") ? t[0] : t[1].type.startsWith("vec") ? t[1] : t[0]
		};
	},
	normalImpl: cn,
	codegenImpl: (e, t) => d$2`(${e} * ${t})`
});
function qn(e, t) {
	if (typeof e == "number" && typeof t == "number") return e / t;
	if (typeof e == "number" && Ee$2(t)) {
		let n = bi[t.kind][o$1].jsImpl;
		return m.div[t.kind](n(e), t);
	}
	if (Ee$2(e) && typeof t == "number") {
		let n = bi[e.kind][o$1].jsImpl;
		return m.div[e.kind](e, n(t));
	}
	if (Ee$2(e) && Ee$2(t)) return m.div[e.kind](e, t);
	throw new Error("Div called with invalid arguments.");
}
var Rt = P({
	name: "div",
	signature: (...e) => {
		let t = Hr$1(e, [
			h$1,
			$$3,
			ui
		]) ?? e;
		return {
			argTypes: t,
			returnType: Qe$2(t[0]) ? t[1] : t[0]
		};
	},
	normalImpl: qn,
	codegenImpl: (e, t) => d$2`(${e} / ${t})`,
	ignoreImplicitCastWarning: !0
});
P({
	name: "mod",
	signature: (...e) => {
		let t = Hr$1(e) ?? e;
		return {
			argTypes: t,
			returnType: Qe$2(t[0]) ? t[1] : t[0]
		};
	},
	normalImpl(e, t) {
		if (typeof e == "number" && typeof t == "number") return e % t;
		if (typeof e == "number" && Ee$2(t)) {
			let n = bi[t.kind];
			return m.mod[t.kind](n(e), t);
		}
		if (Ee$2(e) && typeof t == "number") {
			let n = bi[e.kind];
			return m.mod[e.kind](e, n(t));
		}
		if (Ee$2(e) && Ee$2(t)) return m.mod[e.kind](e, t);
		throw new Error("Mod called with invalid arguments, expected types: number or vector.");
	},
	codegenImpl: (e, t) => d$2`(${e} % ${t})`
});
function jn(e) {
	return typeof e == "number" ? -e : m.neg[e.kind](e);
}
P({
	name: "neg",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: jn,
	codegenImpl: (e) => d$2`-(${e})`
});
function Zn$1(e) {
	return typeof e == "number" ? Math.abs(e) : m.abs[e.kind](e);
}
__name(Zn$1, "Zn");
P({
	name: "abs",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: Zn$1,
	codegenImpl: (e) => d$2`abs(${e})`
});
function Hn$1(e) {
	return typeof e == "number" ? Math.acos(e) : m.acos[e.kind](e);
}
__name(Hn$1, "Hn");
P({
	name: "acos",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: Hn$1,
	codegenImpl: (e) => d$2`acos(${e})`
});
function Qn(e) {
	return typeof e == "number" ? Math.acosh(e) : m.acosh[e.kind](e);
}
P({
	name: "acosh",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: Qn,
	codegenImpl: (e) => d$2`acosh(${e})`
});
function Xn$1(e) {
	return typeof e == "number" ? Math.asin(e) : m.asin[e.kind](e);
}
__name(Xn$1, "Xn");
P({
	name: "asin",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: Xn$1,
	codegenImpl: (e) => d$2`asin(${e})`
});
function Yn$1(e) {
	return typeof e == "number" ? Math.asinh(e) : m.asinh[e.kind](e);
}
__name(Yn$1, "Yn");
P({
	name: "asinh",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: Yn$1,
	codegenImpl: (e) => d$2`asinh(${e})`
});
function Jn$1(e) {
	return typeof e == "number" ? Math.atan(e) : m.atan[e.kind](e);
}
__name(Jn$1, "Jn");
P({
	name: "atan",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: Jn$1,
	codegenImpl: (e) => d$2`atan(${e})`
});
function er$1(e) {
	return typeof e == "number" ? Math.atanh(e) : m.atanh[e.kind](e);
}
__name(er$1, "er");
P({
	name: "atanh",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: er$1,
	codegenImpl: (e) => d$2`atanh(${e})`
});
function tr$1(e, t) {
	return typeof e == "number" && typeof t == "number" ? Math.atan2(e, t) : m.atan2[e.kind](e, t);
}
__name(tr$1, "tr");
P({
	name: "atan2",
	signature: (...e) => {
		let t = Hr$1(e, [
			h$1,
			$$3,
			ui
		]) ?? e;
		return {
			argTypes: t,
			returnType: t[0]
		};
	},
	normalImpl: tr$1,
	codegenImpl: (e, t) => d$2`atan2(${e}, ${t})`
});
function nr$1(e) {
	return typeof e == "number" ? Math.ceil(e) : m.ceil[e.kind](e);
}
__name(nr$1, "nr");
var Ma$1 = P({
	name: "ceil",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: nr$1,
	codegenImpl: (e) => d$2`ceil(${e})`
});
function rr$1(e, t, n) {
	return typeof e == "number" ? Math.min(Math.max(t, e), n) : m.clamp[e.kind](e, t, n);
}
__name(rr$1, "rr");
P({
	name: "clamp",
	signature: (...e) => {
		let t = Hr$1(e) ?? e;
		return {
			argTypes: t,
			returnType: t[0]
		};
	},
	normalImpl: rr$1,
	codegenImpl: (e, t, n) => d$2`clamp(${e}, ${t}, ${n})`
});
function sr$1(e) {
	return typeof e == "number" ? Math.cos(e) : m.cos[e.kind](e);
}
__name(sr$1, "sr");
P({
	name: "cos",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: sr$1,
	codegenImpl: (e) => d$2`cos(${e})`
});
function ar$1(e) {
	return typeof e == "number" ? Math.cosh(e) : m.cosh[e.kind](e);
}
__name(ar$1, "ar");
P({
	name: "cosh",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: ar$1,
	codegenImpl: (e) => d$2`cosh(${e})`
});
P({
	name: "countLeadingZeros",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: "CPU implementation for countLeadingZeros not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues",
	codegenImpl: (e) => d$2`countLeadingZeros(${e})`
});
P({
	name: "countOneBits",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: "CPU implementation for countOneBits not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues",
	codegenImpl: (e) => d$2`countOneBits(${e})`
});
P({
	name: "countTrailingZeros",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: "CPU implementation for countTrailingZeros not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues",
	codegenImpl: (e) => d$2`countTrailingZeros(${e})`
});
P({
	name: "cross",
	signature: (e, t) => ({
		argTypes: [e, t],
		returnType: e
	}),
	normalImpl: (e, t) => m.cross[e.kind](e, t),
	codegenImpl: (e, t) => d$2`cross(${e}, ${t})`
});
function or$1(e) {
	if (typeof e == "number") return e * 180 / Math.PI;
	throw new Ae$2("CPU implementation for degrees on vectors not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues");
}
__name(or$1, "or");
P({
	name: "degrees",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: or$1,
	codegenImpl: (e) => d$2`degrees(${e})`
});
P({
	name: "determinant",
	signature: (e) => ({
		argTypes: [e],
		returnType: h$1
	}),
	normalImpl: "CPU implementation for determinant not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues",
	codegenImpl: (e) => d$2`determinant(${e})`
});
function ur$1(e, t) {
	return typeof e == "number" && typeof t == "number" ? Math.abs(e - t) : fr(Re(e, t));
}
__name(ur$1, "ur");
P({
	name: "distance",
	signature: (e, t) => ({
		argTypes: [e, t],
		returnType: Hn$2(e) ? $$3 : h$1
	}),
	normalImpl: ur$1,
	codegenImpl: (e, t) => d$2`distance(${e}, ${t})`
});
var cr = P({
	name: "dot",
	signature: (e, t) => ({
		argTypes: [e, t],
		returnType: e.primitive
	}),
	normalImpl: (e, t) => m.dot[e.kind](e, t),
	codegenImpl: (e, t) => d$2`dot(${e}, ${t})`
});
P({
	name: "dot4U8Packed",
	signature: (e, t) => ({
		argTypes: [c, c],
		returnType: c
	}),
	normalImpl: "CPU implementation for dot4U8Packed not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues",
	codegenImpl: (e, t) => d$2`dot4U8Packed(${e}, ${t})`
});
P({
	name: "dot4I8Packed",
	signature: (e, t) => ({
		argTypes: [c, c],
		returnType: T$1
	}),
	normalImpl: "CPU implementation for dot4I8Packed not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues",
	codegenImpl: (e, t) => d$2`dot4I8Packed(${e}, ${t})`
});
function ir$1(e) {
	return typeof e == "number" ? Math.exp(e) : m.exp[e.kind](e);
}
__name(ir$1, "ir");
P({
	name: "exp",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: ir$1,
	codegenImpl: (e) => d$2`exp(${e})`
});
function lr(e) {
	return typeof e == "number" ? 2 ** e : m.exp2[e.kind](e);
}
P({
	name: "exp2",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: lr,
	codegenImpl: (e) => d$2`exp2(${e})`
});
P({
	name: "extractBits",
	signature: (e, t, n) => ({
		argTypes: [
			e,
			c,
			c
		],
		returnType: e
	}),
	normalImpl: "CPU implementation for extractBits not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues",
	codegenImpl: (e, t, n) => d$2`extractBits(${e}, ${t}, ${n})`
});
P({
	name: "faceForward",
	signature: (e, t, n) => ({
		argTypes: [
			e,
			t,
			n
		],
		returnType: e
	}),
	normalImpl: "CPU implementation for faceForward not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues",
	codegenImpl: (e, t, n) => d$2`faceForward(${e}, ${t}, ${n})`
});
P({
	name: "firstLeadingBit",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: "CPU implementation for firstLeadingBit not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues",
	codegenImpl: (e) => d$2`firstLeadingBit(${e})`
});
P({
	name: "firstTrailingBit",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: "CPU implementation for firstTrailingBit not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues",
	codegenImpl: (e) => d$2`firstTrailingBit(${e})`
});
function mr(e) {
	return typeof e == "number" ? Math.floor(e) : m.floor[e.kind](e);
}
P({
	name: "floor",
	signature: (...e) => ({
		argTypes: e,
		returnType: e[0]
	}),
	normalImpl: mr,
	codegenImpl: (e) => d$2`floor(${e})`
});
function pr$1(e, t, n) {
	if (typeof e == "number") return e * t + n;
	throw new Ae$2("CPU implementation for fma on vectors not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues");
}
__name(pr$1, "pr");
P({
	name: "fma",
	signature: (e, t, n) => ({
		argTypes: [
			e,
			t,
			n
		],
		returnType: e
	}),
	normalImpl: pr$1,
	codegenImpl: (e, t, n) => d$2`fma(${e}, ${t}, ${n})`
});
function yr(e) {
	return typeof e == "number" ? e - Math.floor(e) : m.fract[e.kind](e);
}
P({
	name: "fract",
	signature: (...e) => ({
		argTypes: e,
		returnType: e[0]
	}),
	normalImpl: yr,
	codegenImpl: (e) => d$2`fract(${e})`
});
var Tr = {
	f32: Js({
		fract: h$1,
		exp: T$1
	}),
	f16: Js({
		fract: $$3,
		exp: T$1
	}),
	abstractFloat: Js({
		fract: ui,
		exp: ai
	}),
	vec2f: Js({
		fract: B$1,
		exp: pe$3
	}),
	vec3f: Js({
		fract: Le,
		exp: je
	}),
	vec4f: Js({
		fract: v,
		exp: xe$2
	}),
	vec2h: Js({
		fract: hn$1,
		exp: pe$3
	}),
	vec3h: Js({
		fract: dn$1,
		exp: je
	}),
	vec4h: Js({
		fract: fn$1,
		exp: xe$2
	})
};
$t((e) => {
	throw new Ae$2("CPU implementation for frexp not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues");
}, (e) => {
	let t = Tr[e.dataType.type];
	if (!t) throw new Error(`Unsupported data type for frexp: ${e.dataType.type}. Supported types are f32, f16, abstractFloat, vec2f, vec3f, vec4f, vec2h, vec3h, vec4h.`);
	return x$1(d$2`frexp(${e})`, t);
}, "frexp");
P({
	name: "insertBits",
	signature: (e, t, n, r) => ({
		argTypes: [
			e,
			t,
			c,
			c
		],
		returnType: e
	}),
	normalImpl: "CPU implementation for insertBits not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues",
	codegenImpl: (e, t, n, r) => d$2`insertBits(${e}, ${t}, ${n}, ${r})`
});
function xr(e) {
	if (typeof e == "number") return 1 / Math.sqrt(e);
	throw new Ae$2("CPU implementation for inverseSqrt on vectors not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues");
}
P({
	name: "inverseSqrt",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: xr,
	codegenImpl: (e) => d$2`inverseSqrt(${e})`
});
P({
	name: "ldexp",
	signature: (e, t) => {
		switch (e.type) {
			case "abstractFloat": return {
				argTypes: [ui, ai],
				returnType: e
			};
			case "f32":
			case "f16": return {
				argTypes: [e, T$1],
				returnType: e
			};
			case "vec2f":
			case "vec2h": return {
				argTypes: [e, pe$3],
				returnType: e
			};
			case "vec3f":
			case "vec3h": return {
				argTypes: [e, je],
				returnType: e
			};
			case "vec4f":
			case "vec4h": return {
				argTypes: [e, xe$2],
				returnType: e
			};
			default: throw new Error(`Unsupported data type for ldexp: ${e.type}. Supported types are abstractFloat, f32, f16, vec2f, vec2h, vec3f, vec3h, vec4f, vec4h.`);
		}
	},
	normalImpl: "CPU implementation for ldexp not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues",
	codegenImpl: (e, t) => d$2`ldexp(${e}, ${t})`
});
function dr(e) {
	return typeof e == "number" ? Math.abs(e) : m.length[e.kind](e);
}
var fr = P({
	name: "length",
	signature: (e) => ({
		argTypes: [e],
		returnType: Hn$2(e) ? $$3 : h$1
	}),
	normalImpl: dr,
	codegenImpl: (e) => d$2`length(${e})`
});
function gr(e) {
	return typeof e == "number" ? Math.log(e) : m.log[e.kind](e);
}
P({
	name: "log",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: gr,
	codegenImpl: (e) => d$2`log(${e})`
});
function hr(e) {
	return typeof e == "number" ? Math.log2(e) : m.log2[e.kind](e);
}
P({
	name: "log2",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: hr,
	codegenImpl: (e) => d$2`log2(${e})`
});
function vr$1(e, t) {
	return typeof e == "number" ? Math.max(e, t) : m.max[e.kind](e, t);
}
__name(vr$1, "vr");
P({
	name: "max",
	signature: (...e) => {
		let t = Hr$1(e) ?? e;
		return {
			argTypes: t,
			returnType: t[0]
		};
	},
	normalImpl: vr$1,
	codegenImpl: (e, t) => d$2`max(${e}, ${t})`
});
function br(e, t) {
	return typeof e == "number" ? Math.min(e, t) : m.min[e.kind](e, t);
}
P({
	name: "min",
	signature: (...e) => {
		let t = Hr$1(e) ?? e;
		return {
			argTypes: t,
			returnType: t[0]
		};
	},
	normalImpl: br,
	codegenImpl: (e, t) => d$2`min(${e}, ${t})`
});
function wr(e, t, n) {
	if (typeof e == "number") {
		if (typeof n != "number" || typeof t != "number") throw new Error("When e1 and e2 are numbers, the blend factor must be a number.");
		return e * (1 - n) + t * n;
	}
	if (typeof e == "number" || typeof t == "number") throw new Error("e1 and e2 need to both be vectors of the same kind.");
	return m.mix[e.kind](e, t, n);
}
P({
	name: "mix",
	signature: (e, t, n) => ({
		argTypes: [
			e,
			t,
			n
		],
		returnType: e
	}),
	normalImpl: wr,
	codegenImpl: (e, t, n) => d$2`mix(${e}, ${t}, ${n})`
});
var Sr = {
	f32: Js({
		fract: h$1,
		whole: h$1
	}),
	f16: Js({
		fract: $$3,
		whole: $$3
	}),
	abstractFloat: Js({
		fract: ui,
		whole: ui
	}),
	vec2f: Js({
		fract: B$1,
		whole: B$1
	}),
	vec3f: Js({
		fract: Le,
		whole: Le
	}),
	vec4f: Js({
		fract: v,
		whole: v
	}),
	vec2h: Js({
		fract: hn$1,
		whole: hn$1
	}),
	vec3h: Js({
		fract: dn$1,
		whole: dn$1
	}),
	vec4h: Js({
		fract: fn$1,
		whole: fn$1
	})
};
P({
	name: "modf",
	signature: (e) => {
		let t = Sr[e.type];
		if (!t) throw new Error(`Unsupported data type for modf: ${e.type}. Supported types are f32, f16, abstractFloat, vec2f, vec3f, vec4f, vec2h, vec3h, vec4h.`);
		return {
			argTypes: [e],
			returnType: t
		};
	},
	normalImpl: "CPU implementation for modf not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues",
	codegenImpl: (e) => d$2`modf(${e})`
});
P({
	name: "normalize",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: (e) => m.normalize[e.kind](e),
	codegenImpl: (e) => d$2`normalize(${e})`
});
function Mr$1(e, t) {
	if (typeof e == "number" && typeof t == "number") return e ** t;
	if (Ee$2(e) && Ee$2(t)) return m.pow[e.kind](e, t);
	throw new Error("Invalid arguments to pow()");
}
__name(Mr$1, "Mr");
var ln = P({
	name: "pow",
	signature: (...e) => {
		let t = Hr$1(e, [
			h$1,
			$$3,
			ui
		]) ?? e;
		return {
			argTypes: t,
			returnType: Qe$2(t[0]) ? t[1] : t[0]
		};
	},
	normalImpl: Mr$1,
	codegenImpl: (e, t) => d$2`pow(${e}, ${t})`
});
P({
	name: "quantizeToF16",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: "CPU implementation for quantizeToF16 not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues",
	codegenImpl: (e) => d$2`quantizeToF16(${e})`
});
function Ir$1(e) {
	if (typeof e == "number") return e * Math.PI / 180;
	throw new Ae$2("CPU implementation for radians on vectors not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues");
}
__name(Ir$1, "Ir");
P({
	name: "radians",
	signature: (...e) => {
		let t = Hr$1(e, [
			h$1,
			$$3,
			ui
		]) ?? e;
		return {
			argTypes: t,
			returnType: t[0]
		};
	},
	normalImpl: Ir$1,
	codegenImpl: (e) => d$2`radians(${e})`
});
P({
	name: "reflect",
	signature: (e, t) => ({
		argTypes: [e, t],
		returnType: e
	}),
	normalImpl: (e, t) => Re(e, st$1(2 * cr(t, e), t)),
	codegenImpl: (e, t) => d$2`reflect(${e}, ${t})`
});
$t((e, t, n) => {
	throw new Ae$2("CPU implementation for refract not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues");
}, (e, t, n) => x$1(d$2`refract(${e}, ${t}, ${n})`, e.dataType), "refract", (e, t, n) => [
	e.dataType,
	t.dataType,
	Hn$2(e) ? $$3 : h$1
]);
P({
	name: "reverseBits",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: "CPU implementation for reverseBits not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues",
	codegenImpl: (e) => d$2`reverseBits(${e})`
});
function Ar(e) {
	if (typeof e == "number") return Math.round(e);
	throw new Ae$2("CPU implementation for round on vectors not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues");
}
P({
	name: "round",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: Ar,
	codegenImpl: (e) => d$2`round(${e})`
});
function $r$1(e) {
	if (typeof e == "number") return Math.max(0, Math.min(1, e));
	throw new Ae$2("CPU implementation for saturate on vectors not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues");
}
__name($r$1, "$r");
P({
	name: "saturate",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: $r$1,
	codegenImpl: (e) => d$2`saturate(${e})`
});
function zr$1(e) {
	return typeof e == "number" ? Math.sign(e) : m.sign[e.kind](e);
}
__name(zr$1, "zr");
P({
	name: "sign",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: zr$1,
	codegenImpl: (e) => d$2`sign(${e})`
});
function Vr$1(e) {
	return typeof e == "number" ? Math.sin(e) : m.sin[e.kind](e);
}
__name(Vr$1, "Vr");
P({
	name: "sin",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: Vr$1,
	codegenImpl: (e) => d$2`sin(${e})`
});
function Fr$1(e) {
	if (typeof e == "number") return Math.sinh(e);
	throw new Ae$2("CPU implementation for sinh on vectors not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues");
}
__name(Fr$1, "Fr");
P({
	name: "sinh",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: Fr$1,
	codegenImpl: (e) => d$2`sinh(${e})`
});
function Cr$1(e, t, n) {
	return typeof n == "number" ? me$1(e, t, n) : m.smoothstep[n.kind](e, t, n);
}
__name(Cr$1, "Cr");
P({
	name: "smoothstep",
	signature: (e, t, n) => ({
		argTypes: [
			e,
			t,
			n
		],
		returnType: n
	}),
	normalImpl: Cr$1,
	codegenImpl: (e, t, n) => d$2`smoothstep(${e}, ${t}, ${n})`
});
function Pr$1(e) {
	return typeof e == "number" ? Math.sqrt(e) : m.sqrt[e.kind](e);
}
__name(Pr$1, "Pr");
P({
	name: "sqrt",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: Pr$1,
	codegenImpl: (e) => d$2`sqrt(${e})`
});
function kr$1(e, t) {
	if (typeof e == "number") return e <= t ? 1 : 0;
	throw new Ae$2("CPU implementation for step on vectors not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues");
}
__name(kr$1, "kr");
P({
	name: "step",
	signature: (...e) => {
		let t = Hr$1(e, [
			h$1,
			$$3,
			ui
		]) ?? e;
		return {
			argTypes: t,
			returnType: t[0]
		};
	},
	normalImpl: kr$1,
	codegenImpl: (e, t) => d$2`step(${e}, ${t})`
});
function Wr$1(e) {
	if (typeof e == "number") return Math.tan(e);
	throw new Ae$2("CPU implementation for tan on vectors not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues");
}
__name(Wr$1, "Wr");
P({
	name: "tan",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: Wr$1,
	codegenImpl: (e) => d$2`tan(${e})`
});
function _r$1(e) {
	return typeof e == "number" ? Math.tanh(e) : m.tanh[e.kind](e);
}
__name(_r$1, "_r");
P({
	name: "tanh",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: _r$1,
	codegenImpl: (e) => d$2`tanh(${e})`
});
P({
	name: "transpose",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: "CPU implementation for transpose not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues",
	codegenImpl: (e) => d$2`transpose(${e})`
});
P({
	name: "trunc",
	signature: (e) => ({
		argTypes: [e],
		returnType: e
	}),
	normalImpl: "CPU implementation for trunc not implemented yet. Please submit an issue at https://github.com/software-mansion/TypeGPU/issues",
	codegenImpl: (e) => d$2`trunc(${e})`
});
var { NodeTypeCatalog: g } = tinyest_exports, Dr$1 = [
	"==",
	"!=",
	"<",
	"<=",
	">",
	">=",
	"<<",
	">>",
	"+",
	"-",
	"*",
	"/",
	"%",
	"|",
	"^",
	"&",
	"&&",
	"||"
], Br$1 = [
	"&&",
	"||",
	"==",
	"!=",
	"<",
	"<=",
	">",
	">="
], Rr$1 = [
	"vec2f",
	"vec3f",
	"vec4f",
	"vec2h",
	"vec3h",
	"vec4h",
	"vec2i",
	"vec3i",
	"vec4i",
	"vec2u",
	"vec3u",
	"vec4u",
	"mat2x2f",
	"mat3x3f",
	"mat4x4f"
], mn = {
	add: Bt,
	sub: Re,
	mul: st$1,
	div: Rt
};
function pn(e, t, n) {
	return n ? Br$1.includes(t) ? b$2 : t === "=" ? n : e : t === "!" || t === "~" ? b$2 : e;
}
var Gr$1 = {
	"+": Bt[o$1].gpuImpl,
	"-": Re[o$1].gpuImpl,
	"*": st$1[o$1].gpuImpl,
	"/": Rt[o$1].gpuImpl,
	"**": ln[o$1].gpuImpl
};
var Gt = class {
	#e = void 0;
	initGenerator(t) {
		this.#e = t;
	}
	get ctx() {
		if (!this.#e) throw new Error("WGSL Generator has not yet been initialized. Please call initialize(ctx) before using the generator.");
		return this.#e;
	}
	block([t, n]) {
		this.ctx.pushBlockScope();
		try {
			this.ctx.indent();
			let r = n.map((a) => this.statement(a)).join(`
`);
			return this.ctx.dedent(), `{
${r}
${this.ctx.pre}}`;
		} finally {
			this.ctx.popBlockScope();
		}
	}
	blockVariable(t, n) {
		let r = x$1(this.ctx.makeNameValid(t), n);
		return this.ctx.defineVariable(t, r), r;
	}
	identifier(t) {
		if (!t) throw new Error("Cannot resolve an empty identifier");
		let n = this.ctx.getById(t);
		if (!n) throw new Error(`Identifier ${t} not found`);
		return n;
	}
	typedExpression(t, n) {
		let r = this.ctx.expectedType;
		this.ctx.expectedType = n;
		try {
			return Dt$1(this.expression(t), n);
		} finally {
			this.ctx.expectedType = r;
		}
	}
	expression(t) {
		if (typeof t == "string") return this.identifier(t);
		if (typeof t == "boolean") return x$1(t, b$2);
		if (t[0] === g.logicalExpr || t[0] === g.binaryExpr || t[0] === g.assignmentExpr) {
			let [n, r, a, s] = t, i = this.expression(r), p = this.expression(s), d = Gr$1[a];
			if (d) return d(i, p);
			let M = t[0] === g.assignmentExpr ? i.dataType.type === "ptr" ? [i.dataType.inner] : [i.dataType] : void 0, [z, U] = At([i, p], M) ?? [i, p], at = this.ctx.resolve(z.value, z.dataType).value, Et = this.ctx.resolve(U.value, U.dataType).value, yn = pn(z.dataType, a, U.dataType);
			return x$1(Dr$1.includes(a) ? `(${at} ${a} ${Et})` : `${at} ${a} ${Et}`, yn);
		}
		if (t[0] === g.postUpdate) {
			let [n, r, a] = t, s = this.expression(a), i = this.ctx.resolve(s.value, s.dataType).value;
			return x$1(`${i}${r}`, s.dataType);
		}
		if (t[0] === g.unaryExpr) {
			let [n, r, a] = t, s = this.expression(a), i = this.ctx.resolve(s.value, s.dataType).value, p = pn(s.dataType, r);
			return x$1(`${r}${i}`, p);
		}
		if (t[0] === g.memberAccess) {
			let [n, r, a] = t, s = this.expression(r);
			if (s.value === console) return x$1(new ot$1(a), ut$1);
			if (Rr$1.includes(s.dataType.type) && a in mn) return {
				value: new it$1(a, s, mn[a][o$1].gpuImpl),
				dataType: ut$1
			};
			if (s.dataType.type === "unknown") {
				let i = s.value[a];
				return Tt(i);
			}
			return jn$1(s.dataType) ? x$1(`(*${this.ctx.resolve(s.value).value}).${a}`, Xe$1(s.dataType.inner, a)) : fe$2(s.dataType) && a === "length" ? s.dataType.elementCount === 0 ? x$1(`arrayLength(&${this.ctx.resolve(s.value).value})`, c) : x$1(String(s.dataType.elementCount), ai) : Ue$2(s.dataType) && a === "columns" ? x$1(new st$2(s), ut$1) : ae$1(s.dataType) && Ee$2(s.value) ? Tt(s.value[a]) : x$1(`${this.ctx.resolve(s.value).value}.${a}`, Xe$1(s.dataType, a));
		}
		if (t[0] === g.indexAccess) {
			let [n, r, a] = t, s = this.expression(r), i = this.expression(a), p = this.ctx.resolve(i.value, i.dataType).value;
			if (s.value instanceof st$2) return x$1(d$2`${s.value.matrix}[${p}]`, mt(s.value.matrix.dataType));
			let d = this.ctx.resolve(s.value, s.dataType).value;
			if (s.dataType.type === "unknown") {
				if (Array.isArray(a) && a[0] === g.numericLiteral) return Tt(s.value[a[1]]);
				throw new Error(`Unable to index a value of unknown type with index ${p}. If the value is an array, to address this, consider one of the following approaches: (1) declare the array using 'tgpu.const', (2) store the array in a buffer, or (3) define the array within the GPU function scope.`);
			}
			if (Ue$2(s.dataType)) throw new Error("The only way of accessing matrix elements in TGSL is through the 'columns' property.");
			return jn$1(s.dataType) ? x$1(`(*${d})[${p}]`, mt(s.dataType.inner)) : x$1(`${d}[${p}]`, ar$2(s.dataType) ? mt(s.dataType) : ut$1);
		}
		if (t[0] === g.numericLiteral) {
			let n = typeof t[1] == "string" ? pt$1(Lr$1(t[1])) : pt$1(t[1]);
			if (!n) throw new Error(`Invalid numeric literal ${t[1]}`);
			return n;
		}
		if (t[0] === g.call) {
			let [n, r, a] = t, s = this.expression(r);
			if (we$3(s.value) || fe$2(s.value)) {
				if (a.length > 1) throw new be$2("Array and struct schemas should always be called with at most 1 argument");
				if (!a[0]) return x$1(`${this.ctx.resolve(s.value).value}()`, s.value);
				let p = this.typedExpression(a[0], s.value);
				return x$1(this.ctx.resolve(p.value, s.value).value, s.value);
			}
			if (s.value === nn$1) throw new Error("Constants cannot be defined within TypeGPU function scope. To address this, move the constant definition outside the function scope.");
			if (s.value instanceof it$1) {
				if (!a[0]) throw new be$2(`An infix operator '${s.value.name}' was called without any arguments`);
				let p = this.expression(a[0]);
				return s.value.operator(s.value.lhs, p);
			}
			if (!u(s.value)) {
				let p = a.map((M) => this.expression(M));
				let d = this.ctx.shelllessRepo.get(s.value, p);
				if (d) return this.ctx.withResetIndentLevel(() => {
					let M = this.ctx.resolve(d);
					return x$1(d$2`${M.value}(${p})`, M.dataType);
				});
				throw new Error(`Function '${D(s.value) ?? String(s.value)}' is not marked with the 'use gpu' directive and cannot be used in a shader`);
			}
			let i = s.value[o$1]?.argConversionHint ?? "keep";
			try {
				let p;
				if (Array.isArray(i)) p = a.map((M, z) => {
					let U = i[z];
					if (!U) throw new be$2(`Function '${D(s.value)}' was called with too many arguments`);
					return this.typedExpression(M, U);
				});
				else {
					let M = a.map((z) => this.expression(z));
					i === "keep" ? p = M : i === "unify" ? p = At(M) ?? M : p = i(...M).map((z, U) => [z, M[U]]).map(([z, U]) => Dt$1(U, z));
				}
				if (s.value instanceof ot$1) return this.ctx.generateLog(s.value.op, p);
				let d = s.value(...p);
				if (!Ce$3(d)) throw new Error("Functions running in codegen mode must return snippets");
				return d;
			} catch (p) {
				throw new ct(p, [{ toString: () => D(s.value) }]);
			}
		}
		if (t[0] === g.objectExpr) {
			let n = t[1];
			let r = this.ctx.expectedType;
			if (!r || !we$3(r)) throw new be$2(`No target type could be inferred for object with keys [${Object.keys(n).join(", ")}], please wrap the object in the corresponding schema.`);
			let s = qr$1(r, Object.fromEntries(Object.entries(r.propTypes).map(([i, p]) => {
				let d = n[i];
				if (d === void 0) throw new be$2(`Missing property ${i} in object literal for struct ${r}`);
				return [i, this.typedExpression(d, p)];
			})));
			return x$1(d$2`${this.ctx.resolve(r).value}(${s})`, r);
		}
		if (t[0] === g.arrayExpr) {
			let [n, r] = t, a = this.ctx.expectedType, s, i;
			if (fe$2(a)) {
				if (s = a.elementType, i = r.map((d) => this.typedExpression(d, s)), i.length !== a.elementCount) throw new be$2(`Cannot create value of type '${a}' from an array of length: ${i.length}`);
			} else {
				let d = r.map((z) => this.expression(z));
				if (d.length === 0) throw new be$2("Cannot infer the type of an empty array literal.");
				let M = At(d);
				if (!M) throw new be$2("The given values cannot be automatically converted to a common type. Consider wrapping the array in an appropriate schema");
				i = M, s = yt(i[0]?.dataType);
			}
			return x$1(d$2`${`array<${this.ctx.resolve(s).value}, ${i.length}>`}(${i})`, Ye$2[o$1].jsImpl(s, i.length));
		}
		if (t[0] === g.stringLiteral) return x$1(t[1], ut$1);
		if (t[0] === g.preUpdate) throw new Error("Cannot use pre-updates in TGSL.");
		Er$1(t);
	}
	functionDefinition(t) {
		return this.block(t);
	}
	statement(t) {
		if (typeof t == "string") return `${this.ctx.pre}${this.ctx.resolve(this.identifier(t).value).value};`;
		if (typeof t == "boolean") return `${this.ctx.pre}${t ? "true" : "false"};`;
		if (t[0] === g.return) {
			let n = t[1];
			if (n !== void 0) {
				let r = this.ctx.topFunctionReturnType;
				let a = r ? this.typedExpression(n, r) : this.expression(n);
				return Ve$3(a.dataType.type !== "unknown", "Return type should be known"), this.ctx.reportReturnType(a.dataType), d$2`${this.ctx.pre}return ${a};`;
			}
			return `${this.ctx.pre}return;`;
		}
		if (t[0] === g.if) {
			let [n, r, a, s] = t, i = this.typedExpression(r, b$2), p = i.value === !1 ? void 0 : this.block(vt(a)), d = i.value === !0 || !s ? void 0 : this.block(vt(s));
			return i.value === !0 ? `${this.ctx.pre}${p}` : i.value === !1 ? d ? `${this.ctx.pre}${d}` : "" : d ? d$2`\
${this.ctx.pre}if (${i}) ${p}
${this.ctx.pre}else ${d}` : d$2`${this.ctx.pre}if (${i}) ${p}`;
		}
		if (t[0] === g.let || t[0] === g.const) {
			let [n, r, a] = t, s = a !== void 0 ? this.expression(a) : void 0;
			if (!s) throw new Error(`Cannot create variable '${r}' without an initial value.`);
			if (Re$1(s.dataType)) throw new Error(`Cannot create variable '${r}' with loose data type.`);
			let i = this.blockVariable(r, yt(s.dataType));
			return d$2`${this.ctx.pre}var ${i.value} = ${s};`;
		}
		if (t[0] === g.block) return this.block(t);
		if (t[0] === g.for) {
			let [n, r, a, s, i] = t, [p, d, M] = this.ctx.withResetIndentLevel(() => [
				r ? this.statement(r) : void 0,
				a ? this.typedExpression(a, b$2) : void 0,
				s ? this.statement(s) : void 0
			]), z = p ? p.slice(0, -1) : "", U = M ? M.slice(0, -1) : "", at = this.block(vt(i));
			return d$2`${this.ctx.pre}for (${z}; ${d}; ${U}) ${at}`;
		}
		if (t[0] === g.while) {
			let [n, r, a] = t, s = this.typedExpression(r, b$2), i = this.ctx.resolve(s.value).value, p = this.block(vt(a));
			return `${this.ctx.pre}while (${i}) ${p}`;
		}
		return t[0] === g.continue ? `${this.ctx.pre}continue;` : t[0] === g.break ? `${this.ctx.pre}break;` : `${this.ctx.pre}${this.ctx.resolve(this.expression(t).value).value};`;
	}
};
function Er$1(e) {
	throw new Error(`'${Pt$1(e)}' was not handled by the WGSL generator.`);
}
__name(Er$1, "Er");
function Lr$1(e) {
	return /^0x[0-9a-f]+$/i.test(e) ? Number.parseInt(e) : /^0b[01]+$/i.test(e) ? Number.parseInt(e.slice(2), 2) : Number.parseFloat(e);
}
__name(Lr$1, "Lr");
function vt(e) {
	return typeof e != "object" || e[0] !== g.block ? [g.block, [e]] : e;
}
var Bo$1 = new Gt();
//#endregion
//#region node_modules/.pnpm/typed-binary@4.3.3/node_modules/typed-binary/dist/index.js
var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, {
	enumerable: true,
	configurable: true,
	writable: true,
	value
}) : obj[key] = value;
var __export = (target, all) => {
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
};
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
__export({}, {
	BufferReader: () => BufferReader,
	BufferWriter: () => BufferWriter,
	MaxValue: () => MaxValue,
	Measurer: () => Measurer,
	UnresolvedReferenceError: () => UnresolvedReferenceError,
	ValidationError: () => ValidationError,
	arrayOf: () => arrayOf,
	bool: () => bool,
	byte: () => byte,
	chars: () => chars,
	concat: () => concat,
	dynamicArrayOf: () => dynamicArrayOf,
	f16: () => f16,
	f32: () => f32,
	f32Array: () => f32Array,
	f64Array: () => f64Array,
	generic: () => generic,
	genericEnum: () => genericEnum,
	i16: () => i16,
	i16Array: () => i16Array,
	i32: () => i32,
	i32Array: () => i32Array,
	i8: () => i8,
	i8Array: () => i8Array,
	keyed: () => keyed,
	object: () => object,
	optional: () => optional,
	string: () => string,
	tupleOf: () => tupleOf,
	u16: () => u16,
	u16Array: () => u16Array,
	u32: () => u32,
	u32Array: () => u32Array,
	u8: () => u8,
	u8Array: () => u8Array,
	u8ClampedArray: () => u8ClampedArray
});
var UnresolvedReferenceError = class _UnresolvedReferenceError extends Error {
	constructor(msg) {
		super(msg);
		Object.setPrototypeOf(this, _UnresolvedReferenceError.prototype);
	}
};
var ValidationError = class _ValidationError extends Error {
	constructor(msg) {
		super(msg);
		Object.setPrototypeOf(this, _ValidationError.prototype);
	}
};
var UnboundedMeasurer = class {
	constructor() {
		__publicField(this, "size", NaN);
		__publicField(this, "unbounded", this);
		__publicField(this, "isUnbounded", true);
	}
	add() {
		return this;
	}
	fork() {
		return this;
	}
};
var unboundedMeasurer = new UnboundedMeasurer();
var Measurer = class _Measurer {
	constructor() {
		__publicField(this, "size", 0);
		__publicField(this, "unbounded", unboundedMeasurer);
		__publicField(this, "isUnbounded", false);
	}
	add(bytes) {
		this.size += bytes;
		return this;
	}
	fork() {
		const forked = new _Measurer();
		forked.size = this.size;
		return forked;
	}
};
var MaxValue = Symbol("The biggest (in amount of bytes needed) value a schema can represent");
var Schema = class {
	constructor() {
		__publicField(this, "__unwrapped");
	}
	resolveReferences(ctx) {}
	seekProperty(_reference, _prop) {
		return null;
	}
};
var Ref = class {
	constructor(key) {
		this.key = key;
	}
};
var SubTypeKey = {
	STRING: "string",
	ENUM: "enum"
};
var ArraySchema = class extends Schema {
	constructor(_unstableElementSchema, length) {
		super();
		this._unstableElementSchema = _unstableElementSchema;
		this.length = length;
		__publicField(this, "elementSchema");
		this.elementSchema = _unstableElementSchema;
	}
	resolveReferences(ctx) {
		this.elementSchema = ctx.resolve(this._unstableElementSchema);
	}
	write(output, values) {
		if (values.length !== this.length) throw new ValidationError(`Expected array of length ${this.length}, got ${values.length}`);
		for (const value of values) this.elementSchema.write(output, value);
	}
	read(input) {
		const array = [];
		for (let i = 0; i < this.length; ++i) array.push(this.elementSchema.read(input));
		return array;
	}
	/**
	* Returns the maximum number of bytes this schema can take up.
	*
	* Returns `NaN` if the schema is unbounded. If you would like to know
	* how many bytes a particular value encoding will take up, use `.measure(value)`.
	*
	* Alias for `.measure(MaxValue).size`
	*/
	get maxSize() {
		return this.elementSchema.measure(MaxValue).size * this.length;
	}
	measure(values, measurer = new Measurer()) {
		for (let i = 0; i < this.length; ++i) this.elementSchema.measure(values === MaxValue ? MaxValue : values[i], measurer);
		return measurer;
	}
};
// @__NO_SIDE_EFFECTS__
function arrayOf(elementSchema, length) {
	return new ArraySchema(elementSchema, length);
}
var BoolSchema = class extends Schema {
	constructor() {
		super(...arguments);
		/**
		* The maximum number of bytes this schema can take up.
		*
		* Alias for `.measure(MaxValue).size`
		*/
		__publicField(this, "maxSize", 1);
	}
	read(input) {
		return input.readBool();
	}
	write(output, value) {
		output.writeBool(value);
	}
	measure(_, measurer = new Measurer()) {
		return measurer.add(1);
	}
};
var bool = new BoolSchema();
var _StringSchema = class _StringSchema extends Schema {
	static get _encoder() {
		if (!_StringSchema._cachedEncoder) _StringSchema._cachedEncoder = new TextEncoder();
		return _StringSchema._cachedEncoder;
	}
	read(input) {
		return input.readString();
	}
	write(output, value) {
		output.writeString(value);
	}
	measure(value, measurer = new Measurer()) {
		if (value === MaxValue) return measurer.unbounded;
		const encoded = _StringSchema._encoder.encode(value);
		return measurer.add(encoded.byteLength + 1);
	}
};
__publicField(_StringSchema, "_cachedEncoder");
var string = new _StringSchema();
var Int8Schema = class extends Schema {
	constructor() {
		super(...arguments);
		/**
		* The maximum number of bytes this schema can take up.
		*
		* Alias for `.measure(MaxValue).size`
		*/
		__publicField(this, "maxSize", 1);
	}
	read(input) {
		return input.readInt8();
	}
	write(output, value) {
		output.writeInt8(value);
	}
	measure(_, measurer = new Measurer()) {
		return measurer.add(1);
	}
};
var i8 = new Int8Schema();
var Uint8Schema = class extends Schema {
	constructor() {
		super(...arguments);
		/**
		* The maximum number of bytes this schema can take up.
		*
		* Alias for `.measure(MaxValue).size`
		*/
		__publicField(this, "maxSize", 1);
	}
	read(input) {
		return input.readUint8();
	}
	write(output, value) {
		output.writeUint8(value);
	}
	measure(_, measurer = new Measurer()) {
		return measurer.add(1);
	}
};
var u8 = new Uint8Schema();
var byte = u8;
var Int16Schema = class extends Schema {
	constructor() {
		super(...arguments);
		/**
		* The maximum number of bytes this schema can take up.
		*
		* Alias for `.measure(MaxValue).size`
		*/
		__publicField(this, "maxSize", 2);
	}
	read(input) {
		return input.readInt16();
	}
	write(output, value) {
		output.writeInt16(value);
	}
	measure(_, measurer = new Measurer()) {
		return measurer.add(2);
	}
};
var i16 = new Int16Schema();
var Uint16Schema = class extends Schema {
	constructor() {
		super(...arguments);
		/**
		* The maximum number of bytes this schema can take up.
		*
		* Alias for `.measure(MaxValue).size`
		*/
		__publicField(this, "maxSize", 2);
	}
	read(input) {
		return input.readUint16();
	}
	write(output, value) {
		output.writeUint16(value);
	}
	measure(_, measurer = new Measurer()) {
		return measurer.add(2);
	}
};
var u16 = new Uint16Schema();
var Int32Schema = class extends Schema {
	constructor() {
		super(...arguments);
		/**
		* The maximum number of bytes this schema can take up.
		*
		* Alias for `.measure(MaxValue).size`
		*/
		__publicField(this, "maxSize", 4);
	}
	read(input) {
		return input.readInt32();
	}
	write(output, value) {
		output.writeInt32(value);
	}
	measure(_, measurer = new Measurer()) {
		return measurer.add(4);
	}
};
var i32 = new Int32Schema();
var Uint32Schema = class extends Schema {
	constructor() {
		super(...arguments);
		/**
		* The maximum number of bytes this schema can take up.
		*
		* Alias for `.measure(MaxValue).size`
		*/
		__publicField(this, "maxSize", 4);
	}
	read(input) {
		return input.readUint32();
	}
	write(output, value) {
		output.writeUint32(value);
	}
	measure(_, measurer = new Measurer()) {
		return measurer.add(4);
	}
};
var u32 = new Uint32Schema();
var Float16Schema = class extends Schema {
	constructor() {
		super(...arguments);
		/**
		* The maximum number of bytes this schema can take up.
		*
		* Alias for `.measure(MaxValue).size`
		*/
		__publicField(this, "maxSize", 2);
	}
	read(input) {
		return input.readFloat16();
	}
	write(output, value) {
		output.writeFloat16(value);
	}
	measure(_, measurer = new Measurer()) {
		return measurer.add(2);
	}
};
var f16 = new Float16Schema();
var Float32Schema = class extends Schema {
	constructor() {
		super(...arguments);
		/**
		* The maximum number of bytes this schema can take up.
		*
		* Alias for `.measure(MaxValue).size`
		*/
		__publicField(this, "maxSize", 4);
	}
	read(input) {
		return input.readFloat32();
	}
	write(output, value) {
		output.writeFloat32(value);
	}
	measure(_, measurer = new Measurer()) {
		return measurer.add(4);
	}
};
var f32 = new Float32Schema();
var CharsSchema = class extends Schema {
	constructor(length) {
		super();
		this.length = length;
	}
	write(output, value) {
		if (value.length !== this.length) throw new ValidationError(`Expected char-string of length ${this.length}, got ${value.length}`);
		for (let i = 0; i < value.length; ++i) output.writeUint8(value.charCodeAt(i));
	}
	read(input) {
		let content = "";
		for (let i = 0; i < this.length; ++i) content += String.fromCharCode(input.readByte());
		return content;
	}
	measure(_, measurer = new Measurer()) {
		return measurer.add(this.length);
	}
};
// @__NO_SIDE_EFFECTS__
function chars(length) {
	return new CharsSchema(length);
}
// @__NO_SIDE_EFFECTS__
function exactEntries(record) {
	return Object.entries(record);
}
// @__NO_SIDE_EFFECTS__
function resolveMap(ctx, refs) {
	const props = {};
	for (const [key, ref] of /* @__PURE__ */ exactEntries(refs)) props[key] = ctx.resolve(ref);
	return props;
}
var ObjectSchema = class extends Schema {
	constructor(_properties) {
		super();
		this._properties = _properties;
		__publicField(this, "properties");
		this.properties = _properties;
	}
	resolveReferences(ctx) {
		this.properties = /* @__PURE__ */ resolveMap(ctx, this._properties);
	}
	write(output, value) {
		for (const [key, property] of /* @__PURE__ */ exactEntries(this.properties)) property.write(output, value[key]);
	}
	read(input) {
		const result = {};
		for (const [key, property] of /* @__PURE__ */ exactEntries(this.properties)) result[key] = property.read(input);
		return result;
	}
	/**
	* The maximum number of bytes this schema can take up.
	*
	* Is `NaN` if the schema is unbounded. If you would like to know
	* how many bytes a particular value encoding will take up, use `.measure(value)`.
	*
	* Alias for `.measure(MaxValue).size`
	*/
	get maxSize() {
		const measurer = new Measurer();
		for (const property of Object.values(this.properties)) property.measure(MaxValue, measurer);
		return measurer.size;
	}
	measure(value, measurer = new Measurer()) {
		for (const [key, property] of /* @__PURE__ */ exactEntries(this.properties)) property.measure(value === MaxValue ? MaxValue : value[key], measurer);
		return measurer;
	}
	seekProperty(reference, prop) {
		let bufferOffset = 0;
		for (const [key, property] of /* @__PURE__ */ exactEntries(this.properties)) {
			if (key === prop) return {
				bufferOffset,
				schema: property
			};
			bufferOffset += property.measure(reference).size;
		}
		return null;
	}
};
// @__NO_SIDE_EFFECTS__
function object(properties) {
	return new ObjectSchema(properties);
}
var GenericObjectSchema = class extends Schema {
	constructor(keyedBy, properties, _subTypeMap) {
		super();
		this.keyedBy = keyedBy;
		this._subTypeMap = _subTypeMap;
		__publicField(this, "_baseObject");
		__publicField(this, "subTypeMap");
		this._baseObject = new ObjectSchema(properties);
		this.subTypeMap = _subTypeMap;
	}
	resolveReferences(ctx) {
		this._baseObject.resolveReferences(ctx);
		this.subTypeMap = /* @__PURE__ */ resolveMap(ctx, this._subTypeMap);
	}
	write(output, value) {
		const subTypeKey = value.type;
		const subTypeDescription = this.subTypeMap[subTypeKey] || null;
		if (subTypeDescription === null) throw new Error(`Unknown sub-type '${subTypeKey.toString()}' in among '${JSON.stringify(Object.keys(this.subTypeMap))}'`);
		if (this.keyedBy === SubTypeKey.ENUM) output.writeUint8(value.type);
		else output.writeString(value.type);
		this._baseObject.write(output, value);
		for (const [key, extraProp] of /* @__PURE__ */ exactEntries(subTypeDescription.properties)) extraProp.write(output, value[key]);
	}
	read(input) {
		const subTypeKey = this.keyedBy === SubTypeKey.ENUM ? input.readByte() : input.readString();
		const subTypeDescription = this.subTypeMap[subTypeKey] || null;
		if (subTypeDescription === null) throw new Error(`Unknown sub-type '${subTypeKey}' in among '${JSON.stringify(Object.keys(this.subTypeMap))}'`);
		const result = this._baseObject.read(input);
		result.type = subTypeKey;
		if (subTypeDescription !== null) for (const [key, extraProp] of /* @__PURE__ */ exactEntries(subTypeDescription.properties)) result[key] = extraProp.read(input);
		return result;
	}
	measure(value, measurer = new Measurer()) {
		this._baseObject.measure(value, measurer);
		if (this.keyedBy === SubTypeKey.ENUM) measurer.add(1);
		else if (value !== MaxValue) measurer.add(value.type.length + 1);
		else return measurer.unbounded;
		if (value === MaxValue) {
			const biggestSubType = Object.values(this.subTypeMap).map((subType) => {
				const forkedMeasurer = measurer.fork();
				for (const prop of Object.values(subType.properties)) prop.measure(MaxValue, forkedMeasurer);
				return [subType, forkedMeasurer.size];
			}).reduce((a, b) => a[1] > b[1] ? a : b)[0];
			for (const prop of Object.values(biggestSubType.properties)) prop.measure(MaxValue, measurer);
		} else {
			const subTypeKey = value.type;
			const subTypeDescription = this.subTypeMap[subTypeKey] || null;
			if (subTypeDescription === null) throw new Error(`Unknown sub-type '${subTypeKey.toString()}', expected one of '${JSON.stringify(Object.keys(this.subTypeMap))}'`);
			for (const [key, prop] of /* @__PURE__ */ exactEntries(subTypeDescription.properties)) prop.measure(value[key], measurer);
		}
		return measurer;
	}
};
// @__NO_SIDE_EFFECTS__
function generic(properties, subTypeMap) {
	return new GenericObjectSchema(SubTypeKey.STRING, properties, subTypeMap);
}
// @__NO_SIDE_EFFECTS__
function genericEnum(properties, subTypeMap) {
	return new GenericObjectSchema(SubTypeKey.ENUM, properties, subTypeMap);
}
// @__NO_SIDE_EFFECTS__
function concat(objs) {
	return new ObjectSchema(Object.fromEntries(objs.flatMap(({ properties }) => Object.entries(properties))));
}
var DynamicArraySchema = class extends Schema {
	constructor(_unstableElementType) {
		super();
		this._unstableElementType = _unstableElementType;
		__publicField(this, "elementType");
		this.elementType = _unstableElementType;
	}
	resolveReferences(ctx) {
		this.elementType = ctx.resolve(this._unstableElementType);
	}
	write(output, values) {
		output.writeUint32(values.length);
		for (const value of values) this.elementType.write(output, value);
	}
	read(input) {
		const array = [];
		const len = input.readUint32();
		for (let i = 0; i < len; ++i) array.push(this.elementType.read(input));
		return array;
	}
	/**
	* The maximum number of bytes this schema can take up.
	*
	* Is `NaN` if the schema is unbounded. If you would like to know
	* how many bytes a particular value encoding will take up, use `.measure(value)`.
	*
	* Alias for `.measure(MaxValue).size`
	*/
	get maxSize() {
		return this.measure(MaxValue).size;
	}
	measure(values, measurer = new Measurer()) {
		if (values === MaxValue) return measurer.unbounded;
		measurer.add(4);
		for (const value of values) this.elementType.measure(value, measurer);
		return measurer;
	}
	seekProperty(reference, prop) {
		if (typeof prop === "symbol") return null;
		const indexProp = Number.parseInt(String(prop), 10);
		if (Number.isNaN(indexProp)) return null;
		if (reference === MaxValue) return {
			bufferOffset: this.elementType.measure(MaxValue).size * indexProp,
			schema: this.elementType
		};
		if (indexProp >= reference.length) return null;
		const measurer = new Measurer();
		for (let i = 0; i < indexProp; ++i) this.elementType.measure(reference[i], measurer);
		return {
			bufferOffset: measurer.size,
			schema: this.elementType
		};
	}
};
// @__NO_SIDE_EFFECTS__
function dynamicArrayOf(elementSchema) {
	return new DynamicArraySchema(elementSchema);
}
var RefSchema = class {
	constructor(key) {
		__publicField(this, "__unwrapped");
		__publicField(this, "ref");
		this.ref = new Ref(key);
	}
	resolveReferences() {
		throw new UnresolvedReferenceError("Tried to resolve a reference directly. Do it through a RefResolver instead.");
	}
	read() {
		throw new UnresolvedReferenceError("Tried to read a reference directly. Resolve it instead.");
	}
	write() {
		throw new UnresolvedReferenceError("Tried to write a reference directly. Resolve it instead.");
	}
	measure() {
		throw new UnresolvedReferenceError("Tried to measure size of a reference directly. Resolve it instead.");
	}
	seekProperty() {
		throw new UnresolvedReferenceError("Tried to seek property of a reference directly. Resolve it instead.");
	}
};
var RefResolve = class {
	constructor() {
		__publicField(this, "registry", {});
	}
	hasKey(key) {
		return this.registry[key] !== void 0;
	}
	register(key, schema) {
		this.registry[key] = schema;
	}
	resolve(unstableSchema) {
		if (unstableSchema instanceof RefSchema) {
			const key = unstableSchema.ref.key;
			if (this.registry[key] !== void 0) return this.registry[key];
			throw new UnresolvedReferenceError(`Couldn't resolve reference to ${key}. Unknown key.`);
		}
		unstableSchema.resolveReferences(this);
		return unstableSchema;
	}
};
var KeyedSchema = class {
	constructor(key, innerResolver) {
		this.key = key;
		__publicField(this, "__unwrapped");
		__publicField(this, "__keyDefinition");
		__publicField(this, "innerType");
		this.innerType = innerResolver(new RefSchema(key));
		this.resolveReferences(new RefResolve());
	}
	resolveReferences(ctx) {
		if (!ctx.hasKey(this.key)) {
			ctx.register(this.key, this.innerType);
			this.innerType.resolveReferences(ctx);
		}
	}
	read(input) {
		return this.innerType.read(input);
	}
	write(output, value) {
		this.innerType.write(output, value);
	}
	/**
	* The maximum number of bytes this schema can take up.
	*
	* Is `NaN` if the schema is unbounded. If you would like to know
	* how many bytes a particular value encoding will take up, use `.measure(value)`.
	*
	* Alias for `.measure(MaxValue).size`
	*/
	get maxSize() {
		return this.measure(MaxValue).size;
	}
	measure(value, measurer = new Measurer()) {
		return this.innerType.measure(value, measurer);
	}
	seekProperty(reference, prop) {
		return this.innerType.seekProperty(reference, prop);
	}
};
// @__NO_SIDE_EFFECTS__
function keyed(key, inner) {
	return new KeyedSchema(key, inner);
}
var OptionalSchema = class extends Schema {
	constructor(_innerUnstableSchema) {
		super();
		this._innerUnstableSchema = _innerUnstableSchema;
		__publicField(this, "innerSchema");
		this.innerSchema = _innerUnstableSchema;
	}
	resolveReferences(ctx) {
		this.innerSchema = ctx.resolve(this._innerUnstableSchema);
	}
	write(output, value) {
		if (value !== void 0 && value !== null) {
			output.writeBool(true);
			this.innerSchema.write(output, value);
		} else output.writeBool(false);
	}
	read(input) {
		if (input.readBool()) return this.innerSchema.read(input);
	}
	/**
	* The maximum number of bytes this schema can take up.
	*
	* Is `NaN` if the schema is unbounded. If you would like to know
	* how many bytes a particular value encoding will take up, use `.measure(value)`.
	*
	* Alias for `.measure(MaxValue).size`
	*/
	get maxSize() {
		return this.measure(MaxValue).size;
	}
	measure(value, measurer = new Measurer()) {
		if (value !== void 0) this.innerSchema.measure(value, measurer);
		return measurer.add(1);
	}
};
// @__NO_SIDE_EFFECTS__
function optional(innerType) {
	return new OptionalSchema(innerType);
}
// @__NO_SIDE_EFFECTS__
function resolveArray(ctx, refs) {
	return refs.map((ref) => ctx.resolve(ref));
}
var TupleSchema = class extends Schema {
	constructor(_unstableSchemas) {
		super();
		this._unstableSchemas = _unstableSchemas;
		__publicField(this, "schemas");
		this.schemas = _unstableSchemas;
	}
	resolveReferences(ctx) {
		this.schemas = /* @__PURE__ */ resolveArray(ctx, this._unstableSchemas);
	}
	write(output, values) {
		if (values.length !== this.schemas.length) throw new ValidationError(`Expected tuple of length ${this.schemas.length}, got ${values.length}`);
		for (let i = 0; i < this.schemas.length; ++i) this.schemas[i].write(output, values[i]);
	}
	read(input) {
		const array = [];
		for (let i = 0; i < this.schemas.length; ++i) array.push(this.schemas[i].read(input));
		return array;
	}
	/**
	* The maximum number of bytes this schema can take up.
	*
	* Is `NaN` if the schema is unbounded. If you would like to know
	* how many bytes a particular value encoding will take up, use `.measure(value)`.
	*
	* Alias for `.measure(MaxValue).size`
	*/
	get maxSize() {
		return this.measure(MaxValue).size;
	}
	measure(values, measurer = new Measurer()) {
		for (let i = 0; i < this.schemas.length; ++i) this.schemas[i].measure(values === MaxValue ? MaxValue : values[i], measurer);
		return measurer;
	}
};
// @__NO_SIDE_EFFECTS__
function tupleOf(schemas) {
	return new TupleSchema(schemas);
}
var TypedArraySchema = class extends Schema {
	constructor(length, _arrayConstructor) {
		super();
		this.length = length;
		this._arrayConstructor = _arrayConstructor;
		__publicField(this, "byteLength");
		this.byteLength = length * _arrayConstructor.BYTES_PER_ELEMENT;
	}
	write(output, value) {
		output.writeSlice(value);
	}
	read(input) {
		const buffer = new ArrayBuffer(this.byteLength);
		const view = new this._arrayConstructor(buffer, 0, this.length);
		input.readSlice(view, 0, this.byteLength);
		return view;
	}
	measure(_value, measurer = new Measurer()) {
		return measurer.add(this.byteLength);
	}
};
var u8Array = /* @__NO_SIDE_EFFECTS__ */ (length) => new TypedArraySchema(length, Uint8Array);
var u8ClampedArray = /* @__NO_SIDE_EFFECTS__ */ (length) => new TypedArraySchema(length, Uint8ClampedArray);
var u16Array = /* @__NO_SIDE_EFFECTS__ */ (length) => new TypedArraySchema(length, Uint16Array);
var u32Array = /* @__NO_SIDE_EFFECTS__ */ (length) => new TypedArraySchema(length, Uint32Array);
var i8Array = /* @__NO_SIDE_EFFECTS__ */ (length) => new TypedArraySchema(length, Int8Array);
var i16Array = /* @__NO_SIDE_EFFECTS__ */ (length) => new TypedArraySchema(length, Int16Array);
var i32Array = /* @__NO_SIDE_EFFECTS__ */ (length) => new TypedArraySchema(length, Int32Array);
var f32Array = /* @__NO_SIDE_EFFECTS__ */ (length) => new TypedArraySchema(length, Float32Array);
var f64Array = /* @__NO_SIDE_EFFECTS__ */ (length) => new TypedArraySchema(length, Float64Array);
// @__NO_SIDE_EFFECTS__
function isSystemBigEndian() {
	const array = /* @__PURE__ */ new Uint8Array(4);
	const view = new Uint32Array(array.buffer);
	view[0] = 1;
	return array[0] === 0;
}
// @__NO_SIDE_EFFECTS__
function getSystemEndianness() {
	return /* @__PURE__ */ isSystemBigEndian() ? "big" : "little";
}
// @__NO_SIDE_EFFECTS__
function unwrapBuffer(buffer) {
	let byteOffset = 0;
	let innerBuffer = buffer;
	if (!!innerBuffer && "buffer" in innerBuffer && "byteOffset" in innerBuffer) {
		byteOffset += innerBuffer.byteOffset;
		innerBuffer = innerBuffer.buffer;
	}
	return {
		buffer: innerBuffer,
		byteOffset,
		byteLength: buffer.byteLength
	};
}
var BufferIOBase = class {
	constructor(buffer, options) {
		__publicField(this, "dataView");
		__publicField(this, "littleEndian");
		__publicField(this, "needsByteSwap");
		__publicField(this, "byteOffset", 0);
		__publicField(this, "endianness");
		const { byteOffset = 0, endianness = "system" } = options != null ? options : {};
		this.byteOffset = byteOffset;
		const systemEndianness = /* @__PURE__ */ getSystemEndianness();
		this.endianness = endianness === "system" ? systemEndianness : endianness;
		this.littleEndian = this.endianness === "little";
		this.needsByteSwap = this.endianness !== systemEndianness;
		const unwrapped = /* @__PURE__ */ unwrapBuffer(buffer);
		this.byteOffset += unwrapped.byteOffset;
		this.dataView = new DataView(unwrapped.buffer);
	}
	get currentByteOffset() {
		return this.byteOffset;
	}
	seekTo(offset) {
		this.byteOffset = offset;
	}
	skipBytes(bytes) {
		this.byteOffset += bytes;
	}
};
var BufferReader = class extends BufferIOBase {
	constructor() {
		super(...arguments);
		__publicField(this, "_cachedTextDecoder");
	}
	get _textDecoder() {
		if (!this._cachedTextDecoder) this._cachedTextDecoder = new TextDecoder(void 0, { fatal: true });
		return this._cachedTextDecoder;
	}
	readBool() {
		return this.dataView.getUint8(this.byteOffset++) !== 0;
	}
	readByte() {
		return this.dataView.getUint8(this.byteOffset++);
	}
	readInt8() {
		return this.dataView.getInt8(this.byteOffset++);
	}
	readUint8() {
		return this.dataView.getUint8(this.byteOffset++);
	}
	readInt16() {
		const value = this.dataView.getInt16(this.byteOffset, this.littleEndian);
		this.byteOffset += 2;
		return value;
	}
	readUint16() {
		const value = this.dataView.getUint16(this.byteOffset, this.littleEndian);
		this.byteOffset += 2;
		return value;
	}
	readInt32() {
		const value = this.dataView.getInt32(this.byteOffset, this.littleEndian);
		this.byteOffset += 4;
		return value;
	}
	readUint32() {
		const value = this.dataView.getUint32(this.byteOffset, this.littleEndian);
		this.byteOffset += 4;
		return value;
	}
	readFloat16() {
		const value = this.dataView.getFloat16(this.byteOffset, this.littleEndian);
		this.byteOffset += 2;
		return value;
	}
	readFloat32() {
		const value = this.dataView.getFloat32(this.byteOffset, this.littleEndian);
		this.byteOffset += 4;
		return value;
	}
	readString() {
		let strLength = 0;
		while (this.byteOffset + strLength < this.dataView.byteLength) if (this.dataView.getUint8(this.byteOffset + strLength++) === 0) break;
		const result = this._textDecoder.decode(new Uint8Array(this.dataView.buffer, this.byteOffset, strLength - 1));
		this.byteOffset += strLength;
		return result;
	}
	readSlice(bufferView, offset, byteLength) {
		const unwrapped = /* @__PURE__ */ unwrapBuffer(bufferView);
		const destU8 = new Uint8Array(unwrapped.buffer, unwrapped.byteOffset + offset);
		const bytesPerElement = bufferView.BYTES_PER_ELEMENT;
		if (this.needsByteSwap && bytesPerElement > 1) for (let i = 0; i < byteLength; i += bytesPerElement) for (let j = bytesPerElement - 1; j >= 0; j--) destU8[i + j] = this.dataView.getUint8(this.byteOffset++);
		else {
			destU8.set(new Uint8Array(this.dataView.buffer, this.byteOffset, byteLength));
			this.byteOffset += byteLength;
		}
	}
};
var BufferWriter = class extends BufferIOBase {
	constructor() {
		super(...arguments);
		__publicField(this, "_cachedTextEncoder");
	}
	get _textEncoder() {
		if (!this._cachedTextEncoder) this._cachedTextEncoder = new TextEncoder();
		return this._cachedTextEncoder;
	}
	writeBool(value) {
		this.dataView.setUint8(this.byteOffset++, value ? 1 : 0);
	}
	writeByte(value) {
		this.dataView.setUint8(this.byteOffset++, value);
	}
	writeInt8(value) {
		this.dataView.setInt8(this.byteOffset++, value);
	}
	writeUint8(value) {
		this.dataView.setUint8(this.byteOffset++, value);
	}
	writeInt16(value) {
		this.dataView.setInt16(this.byteOffset, value, this.littleEndian);
		this.byteOffset += 2;
	}
	writeUint16(value) {
		this.dataView.setUint16(this.byteOffset, value, this.littleEndian);
		this.byteOffset += 2;
	}
	writeInt32(value) {
		this.dataView.setInt32(this.byteOffset, value, this.littleEndian);
		this.byteOffset += 4;
	}
	writeUint32(value) {
		this.dataView.setUint32(this.byteOffset, value, this.littleEndian);
		this.byteOffset += 4;
	}
	writeFloat16(value) {
		this.dataView.setFloat16(this.byteOffset, value, this.littleEndian);
		this.byteOffset += 2;
	}
	writeFloat32(value) {
		this.dataView.setFloat32(this.byteOffset, value, this.littleEndian);
		this.byteOffset += 4;
	}
	writeString(value) {
		const result = this._textEncoder.encodeInto(value, new Uint8Array(this.dataView.buffer, this.byteOffset));
		this.byteOffset += result.written;
		this.dataView.setUint8(this.byteOffset++, 0);
	}
	writeSlice(bufferView) {
		const unwrapped = /* @__PURE__ */ unwrapBuffer(bufferView);
		const srcU8 = new Uint8Array(unwrapped.buffer, unwrapped.byteOffset, unwrapped.byteLength);
		const bytesPerElement = bufferView.BYTES_PER_ELEMENT;
		if (this.needsByteSwap && bytesPerElement > 1) for (let i = 0; i < srcU8.length; i += bytesPerElement) for (let j = bytesPerElement - 1; j >= 0; j--) this.dataView.setUint8(this.byteOffset++, srcU8[i + j]);
		else {
			new Uint8Array(this.dataView.buffer, this.byteOffset).set(srcU8);
			this.byteOffset += srcU8.length;
		}
	}
};
//#endregion
//#region node_modules/.pnpm/typegpu@0.8.2/node_modules/typegpu/chunk-PWBIFP67.js
var ae = P({
	name: "bitcastU32toF32",
	normalImpl: ((e) => typeof e == "number" ? Y(e) : m.bitcastU32toF32[e.kind](e)),
	codegenImpl: (e) => d$2`bitcast<f32>(${e})`,
	signature: (...e) => {
		let t = Hr$1(e, [c]) ?? e;
		return {
			argTypes: t,
			returnType: ae$1(t[0]) ? t[0].type === "vec2u" ? B$1 : t[0].type === "vec3u" ? Le : v : h$1
		};
	}
});
var ne = P({
	name: "bitcastU32toI32",
	normalImpl: ((e) => typeof e == "number" ? J(e) : m.bitcastU32toI32[e.kind](e)),
	codegenImpl: (e) => d$2`bitcast<i32>(${e})`,
	signature: (...e) => {
		let t = Hr$1(e, [c]) ?? e;
		return {
			argTypes: t,
			returnType: ae$1(t[0]) ? t[0].type === "vec2u" ? pe$3 : t[0].type === "vec3u" ? je : xe$2 : T$1
		};
	}
});
var ie = $t((e) => {
	let t = /* @__PURE__ */ new ArrayBuffer(4);
	new BufferWriter(t).writeUint32(e);
	let l = new BufferReader(t);
	return B$1(l.readFloat16(), l.readFloat16());
}, (e) => x$1(d$2`unpack2x16float(${e})`, B$1), "unpack2x16float");
$t((e) => {
	let t = /* @__PURE__ */ new ArrayBuffer(4);
	let s = new BufferWriter(t);
	s.writeFloat16(e.x), s.writeFloat16(e.y);
	return c(new BufferReader(t).readUint32());
}, (e) => x$1(d$2`pack2x16float(${e})`, c), "pack2x16float");
$t((e) => {
	let t = /* @__PURE__ */ new ArrayBuffer(4);
	new BufferWriter(t).writeUint32(e);
	let l = new BufferReader(t);
	return v(l.readUint8() / 255, l.readUint8() / 255, l.readUint8() / 255, l.readUint8() / 255);
}, (e) => x$1(d$2`unpack4x8unorm(${e})`, v), "unpack4x8unorm");
$t((e) => {
	let t = /* @__PURE__ */ new ArrayBuffer(4);
	let s = new BufferWriter(t);
	s.writeUint8(e.x * 255), s.writeUint8(e.y * 255), s.writeUint8(e.z * 255), s.writeUint8(e.w * 255);
	return c(new BufferReader(t).readUint32());
}, (e) => x$1(d$2`pack4x8unorm(${e})`, c), "pack4x8unorm");
function T(e) {
	return e.type.includes("2") ? xn$1 : e.type.includes("3") ? mn$1 : wn$1;
}
var Ae = P({
	name: "allEq",
	signature: (...e) => ({
		argTypes: e,
		returnType: b$2
	}),
	normalImpl: (e, t) => $(A(e, t)),
	codegenImpl: (e, t) => d$2`all(${e} == ${t})`
});
var A = (e, t) => m.eq[e.kind](e, t);
P({
	name: "eq",
	signature: (...e) => ({
		argTypes: e,
		returnType: T(e[0])
	}),
	normalImpl: A,
	codegenImpl: (e, t) => d$2`(${e} == ${t})`
});
P({
	name: "ne",
	signature: (...e) => ({
		argTypes: e,
		returnType: T(e[0])
	}),
	normalImpl: (e, t) => d$1(A(e, t)),
	codegenImpl: (e, t) => d$2`(${e} != ${t})`
});
var M = (e, t) => m.lt[e.kind](e, t);
P({
	name: "lt",
	signature: (...e) => ({
		argTypes: e,
		returnType: T(e[0])
	}),
	normalImpl: M,
	codegenImpl: (e, t) => d$2`(${e} < ${t})`
});
P({
	name: "le",
	signature: (...e) => ({
		argTypes: e,
		returnType: T(e[0])
	}),
	normalImpl: (e, t) => I(M(e, t), A(e, t)),
	codegenImpl: (e, t) => d$2`(${e} <= ${t})`
});
P({
	name: "gt",
	signature: (...e) => ({
		argTypes: e,
		returnType: T(e[0])
	}),
	normalImpl: (e, t) => O$1(d$1(M(e, t)), d$1(A(e, t))),
	codegenImpl: (e, t) => d$2`(${e} > ${t})`
});
P({
	name: "ge",
	signature: (...e) => ({
		argTypes: e,
		returnType: T(e[0])
	}),
	normalImpl: (e, t) => d$1(M(e, t)),
	codegenImpl: (e, t) => d$2`(${e} >= ${t})`
});
var d$1 = /* @__PURE__ */ __name((e) => m.neg[e.kind](e), "d");
P({
	name: "not",
	signature: (...e) => ({
		argTypes: e,
		returnType: e[0]
	}),
	normalImpl: d$1,
	codegenImpl: (e) => d$2`!(${e})`
});
var I = (e, t) => m.or[e.kind](e, t);
P({
	name: "or",
	signature: (...e) => ({
		argTypes: e,
		returnType: e[0]
	}),
	normalImpl: I,
	codegenImpl: (e, t) => d$2`(${e} | ${t})`
});
var O$1 = /* @__PURE__ */ __name((e, t) => d$1(I(d$1(e), d$1(t))), "O");
P({
	name: "and",
	signature: (...e) => ({
		argTypes: e,
		returnType: e[0]
	}),
	normalImpl: O$1,
	codegenImpl: (e, t) => d$2`(${e} & ${t})`
});
var $ = (e) => m.all[e.kind](e);
P({
	name: "all",
	signature: (...e) => ({
		argTypes: e,
		returnType: b$2
	}),
	normalImpl: $,
	codegenImpl: (e) => d$2`all(${e})`
});
P({
	name: "any",
	signature: (...e) => ({
		argTypes: e,
		returnType: b$2
	}),
	normalImpl: (e) => !$(d$1(e)),
	codegenImpl: (e) => d$2`any(${e})`
});
P({
	name: "isCloseTo",
	signature: (...e) => ({
		argTypes: e,
		returnType: b$2
	}),
	normalImpl: (e, t, s = .01) => typeof e == "number" && typeof t == "number" ? Math.abs(e - t) < s : Ee$2(e) && Ee$2(t) ? m.isCloseToZero[e.kind](Re[o$1].jsImpl(e, t), s) : !1,
	codegenImpl: (e, t, s = x$1(.01, h$1)) => gr$1(e) && gr$1(t) ? d$2`(abs(f32(${e}) - f32(${t})) <= ${s})` : !gr$1(e) && !gr$1(t) ? d$2`all(abs(${e} - ${t}) <= (${e} - ${e}) + ${s})` : "false"
});
function j(e, t, s) {
	return typeof s == "boolean" ? s ? t : e : m.select[e.kind](e, t, s);
}
P({
	name: "select",
	signature: (e, t, s) => {
		let [l, b] = Hr$1([e, t]) ?? [e, t];
		return {
			argTypes: [
				l,
				b,
				s
			],
			returnType: l
		};
	},
	normalImpl: j,
	codegenImpl: (e, t, s) => d$2`select(${e}, ${t}, ${s})`
});
var L = {
	r8unorm: {
		channelType: h$1,
		vectorType: v,
		texelSize: 1,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !0,
		canMultisample: !0,
		canResolve: !0,
		storageBindings: [
			"write-only",
			"read-only",
			"read-write"
		]
	},
	r8snorm: {
		channelType: h$1,
		vectorType: v,
		texelSize: 1,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: ["write-only", "read-only"]
	},
	r8uint: {
		channelType: c,
		vectorType: de$1,
		texelSize: 1,
		sampleTypes: ["uint"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: [
			"write-only",
			"read-only",
			"read-write"
		]
	},
	r8sint: {
		channelType: T$1,
		vectorType: xe$2,
		texelSize: 1,
		sampleTypes: ["sint"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: [
			"write-only",
			"read-only",
			"read-write"
		]
	},
	rg8unorm: {
		channelType: h$1,
		vectorType: v,
		texelSize: 2,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !0,
		canMultisample: !0,
		canResolve: !0,
		storageBindings: ["write-only", "read-only"]
	},
	rg8snorm: {
		channelType: h$1,
		vectorType: v,
		texelSize: 2,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: ["write-only", "read-only"]
	},
	rg8uint: {
		channelType: c,
		vectorType: de$1,
		texelSize: 2,
		sampleTypes: ["uint"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: ["write-only", "read-only"]
	},
	rg8sint: {
		channelType: T$1,
		vectorType: xe$2,
		texelSize: 2,
		sampleTypes: ["sint"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: ["write-only", "read-only"]
	},
	rgba8unorm: {
		channelType: h$1,
		vectorType: v,
		texelSize: 4,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !0,
		canMultisample: !0,
		canResolve: !0,
		storageBindings: [
			"write-only",
			"read-only",
			"read-write"
		]
	},
	"rgba8unorm-srgb": {
		channelType: h$1,
		vectorType: v,
		texelSize: 4,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !0,
		canMultisample: !0,
		canResolve: !0,
		storageBindings: null
	},
	rgba8snorm: {
		channelType: h$1,
		vectorType: v,
		texelSize: 4,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: ["write-only", "read-only"]
	},
	rgba8uint: {
		channelType: c,
		vectorType: de$1,
		texelSize: 4,
		sampleTypes: ["uint"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: [
			"write-only",
			"read-only",
			"read-write"
		]
	},
	rgba8sint: {
		channelType: T$1,
		vectorType: xe$2,
		texelSize: 4,
		sampleTypes: ["sint"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: [
			"write-only",
			"read-only",
			"read-write"
		]
	},
	bgra8unorm: {
		channelType: h$1,
		vectorType: v,
		texelSize: 4,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !0,
		canMultisample: !0,
		canResolve: !0,
		storageBindings: ["write-only"]
	},
	"bgra8unorm-srgb": {
		channelType: h$1,
		vectorType: v,
		texelSize: 4,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !0,
		canMultisample: !0,
		canResolve: !0,
		storageBindings: null
	},
	r16unorm: {
		channelType: h$1,
		vectorType: v,
		texelSize: 2,
		sampleTypes: ["unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !0,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: ["write-only", "read-only"]
	},
	r16snorm: {
		channelType: h$1,
		vectorType: v,
		texelSize: 2,
		sampleTypes: ["unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !0,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: ["write-only", "read-only"]
	},
	r16uint: {
		channelType: c,
		vectorType: de$1,
		texelSize: 2,
		sampleTypes: ["uint"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: [
			"write-only",
			"read-only",
			"read-write"
		]
	},
	r16sint: {
		channelType: T$1,
		vectorType: xe$2,
		texelSize: 2,
		sampleTypes: ["sint"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: [
			"write-only",
			"read-only",
			"read-write"
		]
	},
	r16float: {
		channelType: h$1,
		vectorType: v,
		texelSize: 2,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !0,
		canMultisample: !0,
		canResolve: !0,
		storageBindings: [
			"write-only",
			"read-only",
			"read-write"
		]
	},
	rg16unorm: {
		channelType: h$1,
		vectorType: v,
		texelSize: 4,
		sampleTypes: ["unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !0,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: ["write-only", "read-only"]
	},
	rg16snorm: {
		channelType: h$1,
		vectorType: v,
		texelSize: 4,
		sampleTypes: ["unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !0,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: ["write-only", "read-only"]
	},
	rg16uint: {
		channelType: c,
		vectorType: de$1,
		texelSize: 4,
		sampleTypes: ["uint"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: ["write-only", "read-only"]
	},
	rg16sint: {
		channelType: T$1,
		vectorType: xe$2,
		texelSize: 4,
		sampleTypes: ["sint"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: ["write-only", "read-only"]
	},
	rg16float: {
		channelType: h$1,
		vectorType: v,
		texelSize: 4,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !0,
		canMultisample: !0,
		canResolve: !0,
		storageBindings: ["write-only", "read-only"]
	},
	rgba16unorm: {
		channelType: h$1,
		vectorType: v,
		texelSize: 8,
		sampleTypes: ["unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !0,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: ["write-only", "read-only"]
	},
	rgba16snorm: {
		channelType: h$1,
		vectorType: v,
		texelSize: 8,
		sampleTypes: ["unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !0,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: ["write-only", "read-only"]
	},
	rgba16uint: {
		channelType: c,
		vectorType: de$1,
		texelSize: 8,
		sampleTypes: ["uint"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: [
			"write-only",
			"read-only",
			"read-write"
		]
	},
	rgba16sint: {
		channelType: T$1,
		vectorType: xe$2,
		texelSize: 8,
		sampleTypes: ["sint"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: [
			"write-only",
			"read-only",
			"read-write"
		]
	},
	rgba16float: {
		channelType: h$1,
		vectorType: v,
		texelSize: 8,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !0,
		canMultisample: !0,
		canResolve: !0,
		storageBindings: [
			"write-only",
			"read-only",
			"read-write"
		]
	},
	r32uint: {
		channelType: c,
		vectorType: de$1,
		texelSize: 4,
		sampleTypes: ["uint"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: [
			"write-only",
			"read-only",
			"read-write"
		]
	},
	r32sint: {
		channelType: T$1,
		vectorType: xe$2,
		texelSize: 4,
		sampleTypes: ["sint"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: [
			"write-only",
			"read-only",
			"read-write"
		]
	},
	r32float: {
		channelType: h$1,
		vectorType: v,
		texelSize: 4,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !0,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: [
			"write-only",
			"read-only",
			"read-write"
		]
	},
	rg32uint: {
		channelType: c,
		vectorType: de$1,
		texelSize: 8,
		sampleTypes: ["uint"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: ["write-only", "read-only"]
	},
	rg32sint: {
		channelType: T$1,
		vectorType: xe$2,
		texelSize: 8,
		sampleTypes: ["sint"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: ["write-only", "read-only"]
	},
	rg32float: {
		channelType: h$1,
		vectorType: v,
		texelSize: 8,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !0,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: [
			"write-only",
			"read-only",
			"read-write"
		]
	},
	rgba32uint: {
		channelType: c,
		vectorType: de$1,
		texelSize: 16,
		sampleTypes: ["uint"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: [
			"write-only",
			"read-only",
			"read-write"
		]
	},
	rgba32sint: {
		channelType: T$1,
		vectorType: xe$2,
		texelSize: 16,
		sampleTypes: ["sint"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: [
			"write-only",
			"read-only",
			"read-write"
		]
	},
	rgba32float: {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !0,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: [
			"write-only",
			"read-only",
			"read-write"
		]
	},
	rgb10a2uint: {
		channelType: c,
		vectorType: de$1,
		texelSize: 4,
		sampleTypes: ["uint"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: ["write-only", "read-only"]
	},
	rgb10a2unorm: {
		channelType: h$1,
		vectorType: v,
		texelSize: 4,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !0,
		canMultisample: !0,
		canResolve: !0,
		storageBindings: ["write-only", "read-only"]
	},
	rg11b10ufloat: {
		channelType: h$1,
		vectorType: v,
		texelSize: 4,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !0,
		canBlend: !0,
		canMultisample: !0,
		canResolve: !0,
		storageBindings: ["write-only", "read-only"]
	},
	rgb9e5ufloat: {
		channelType: h$1,
		vectorType: v,
		texelSize: 4,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	stencil8: {
		channelType: c,
		vectorType: de$1,
		texelSize: 1,
		sampleTypes: ["uint"],
		aspects: ["stencil"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: null
	},
	depth16unorm: {
		channelType: h$1,
		vectorType: v,
		texelSize: 2,
		sampleTypes: ["depth", "unfilterable-float"],
		aspects: ["depth"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: null
	},
	depth24plus: {
		channelType: h$1,
		vectorType: v,
		texelSize: 4,
		sampleTypes: ["depth", "unfilterable-float"],
		aspects: ["depth"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: null
	},
	"depth24plus-stencil8": {
		channelType: h$1,
		vectorType: v,
		texelSize: 4,
		sampleTypes: ["depth", "unfilterable-float"],
		aspects: ["depth", "stencil"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: null
	},
	depth32float: {
		channelType: h$1,
		vectorType: v,
		texelSize: 4,
		sampleTypes: ["depth", "unfilterable-float"],
		aspects: ["depth"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: null
	},
	"depth32float-stencil8": {
		channelType: h$1,
		vectorType: v,
		texelSize: 4,
		sampleTypes: ["depth", "unfilterable-float"],
		aspects: ["depth", "stencil"],
		canRenderAttachment: !0,
		canBlend: !1,
		canMultisample: !0,
		canResolve: !1,
		storageBindings: null
	},
	"bc1-rgba-unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 8,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"bc1-rgba-unorm-srgb": {
		channelType: h$1,
		vectorType: v,
		texelSize: 8,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"bc2-rgba-unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"bc2-rgba-unorm-srgb": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"bc3-rgba-unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"bc3-rgba-unorm-srgb": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"bc4-r-unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 8,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"bc4-r-snorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 8,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"bc5-rg-unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"bc5-rg-snorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"bc6h-rgb-ufloat": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"bc6h-rgb-float": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"bc7-rgba-unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"bc7-rgba-unorm-srgb": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"etc2-rgb8unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 8,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"etc2-rgb8unorm-srgb": {
		channelType: h$1,
		vectorType: v,
		texelSize: 8,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"etc2-rgb8a1unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 8,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"etc2-rgb8a1unorm-srgb": {
		channelType: h$1,
		vectorType: v,
		texelSize: 8,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"etc2-rgba8unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"etc2-rgba8unorm-srgb": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"eac-r11unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 8,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"eac-r11snorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 8,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"eac-rg11unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"eac-rg11snorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-4x4-unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-4x4-unorm-srgb": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-5x4-unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-5x4-unorm-srgb": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-5x5-unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-5x5-unorm-srgb": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-6x5-unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-6x5-unorm-srgb": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-6x6-unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-6x6-unorm-srgb": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-8x5-unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-8x5-unorm-srgb": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-8x6-unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-8x6-unorm-srgb": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-8x8-unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-8x8-unorm-srgb": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-10x5-unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-10x5-unorm-srgb": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-10x6-unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-10x6-unorm-srgb": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-10x8-unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-10x8-unorm-srgb": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-10x10-unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-10x10-unorm-srgb": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-12x10-unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-12x10-unorm-srgb": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-12x12-unorm": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	},
	"astc-12x12-unorm-srgb": {
		channelType: h$1,
		vectorType: v,
		texelSize: 16,
		sampleTypes: ["float", "unfilterable-float"],
		aspects: ["color"],
		canRenderAttachment: !1,
		canBlend: !1,
		canMultisample: !1,
		canResolve: !1,
		storageBindings: null
	}
};
function Oe(e, t) {
	let s = L[e];
	if (!s) throw new Error(`Unknown texture format: ${e}`);
	let l = { ...s };
	switch (e) {
		case "r32float":
		case "rg32float":
		case "rgba32float":
			t.features.has("float32-filterable") || (l = {
				...l,
				sampleTypes: s.sampleTypes.filter((b) => b !== "float")
			}), t.features.has("float32-blendable") || (l = {
				...l,
				canBlend: !1
			});
			break;
		case "bgra8unorm":
			t.features.has("bgra8unorm-storage") || (l = {
				...l,
				storageBindings: null
			});
			break;
		case "rg11b10ufloat": t.features.has("rg11b10ufloat-renderable") || (l = {
			...l,
			canRenderAttachment: !1,
			canBlend: !1,
			canMultisample: !1,
			canResolve: !1
		});
	}
	if (l.storageBindings) {
		let b = t.features.has("texture-formats-tier1");
		let G = t.features.has("texture-formats-tier2");
		let g = [...l.storageBindings];
		[
			"r8unorm",
			"r8uint",
			"r8sint",
			"r16uint",
			"r16sint",
			"r16float",
			"rgba8unorm",
			"rgba8uint",
			"rgba8sint",
			"rgba16uint",
			"rgba16sint",
			"rgba16float",
			"r32uint",
			"r32sint",
			"r32float",
			"rgba32uint",
			"rgba32sint",
			"rgba32float"
		].includes(e) && !G && (g = g.filter((S) => S !== "read-write")), [
			"r8snorm",
			"rg8unorm",
			"rg8snorm",
			"rg8uint",
			"rg8sint",
			"rgba8snorm",
			"r16unorm",
			"r16snorm",
			"rg16unorm",
			"rg16snorm",
			"rg16uint",
			"rg16sint",
			"rg16float",
			"rgba16unorm",
			"rgba16snorm",
			"rgb10a2uint",
			"rgb10a2unorm",
			"rg11b10ufloat"
		].includes(e) && !b && (g = g.filter((S) => S !== "write-only" && S !== "read-only")), l = {
			...l,
			storageBindings: g.length > 0 ? g : null
		};
	}
	return l;
}
var Pe = [
	"f16",
	"clip_distances",
	"dual_source_blending",
	"subgroups",
	"primitive_index"
];
var Ce$1 = {
	f16: "shader-f16",
	clip_distances: "clip-distances",
	dual_source_blending: "dual-source-blending",
	subgroups: "subgroups",
	primitive_index: "primitive-index"
};
//#endregion
//#region node_modules/.pnpm/typegpu@0.8.2/node_modules/typegpu/index.js
function Hn(e) {
	return new vr(e);
}
var vr = class {
	constructor(t) {
		this.declaration = t;
	}
	[o$1] = !0;
	externalsToApply = [];
	$uses(t) {
		return this.externalsToApply.push(t), this;
	}
	[oe](t) {
		let r = {};
		for (let a of this.externalsToApply) S$1(r, a);
		let n = R(t, r, this.declaration);
		return t.addDeclaration(n), x$1("", Mn$1);
	}
	toString() {
		return `declare: ${this.declaration}`;
	}
};
function Et(e) {
	let t = {
		argTypes: e.in && Object.keys(e.in).length !== 0 ? [F(e.in)] : [],
		returnType: Mn$1,
		workgroupSize: [
			e.workgroupSize[0] ?? 1,
			e.workgroupSize[1] ?? 1,
			e.workgroupSize[2] ?? 1
		],
		isEntry: !0
	};
	let r = (n, ...a) => qa(t, e.workgroupSize, re(n, ...a));
	return Object.assign(Object.assign(r, t), { does: r });
}
function qa(e, t, r) {
	let n = ne$1(r, `@compute @workgroup_size(${t.join(", ")}) `);
	let a = e.argTypes[0];
	return {
		shell: e,
		$uses(s) {
			return n.applyExternals(s), this;
		},
		[o$1]: !0,
		[me$3]: n,
		$name(s) {
			return k(n, s), Yt$1(a) && a.$name(`${s}_Input`), this;
		},
		[oe](s) {
			return n.resolve(s, e.argTypes, e.returnType);
		},
		toString() {
			return `computeFn:${D(n) ?? "<unnamed>"}`;
		}
	};
}
function U(e, t) {
	let r = {
		[o$1]: !0,
		argTypes: e,
		returnType: t ?? Mn$1,
		isEntry: !1
	};
	return Object.assign((a, ...o) => Qa(r, re(a, ...o)), r);
}
function Ke(e) {
	return u(e) && e?.resourceType === "function";
}
function ja([e, t]) {
	return `${D(e) ?? "<unnamed>"}=${t}`;
}
function Qa(e, t) {
	let r = ne$1(t, "");
	let n = {
		shell: e,
		resourceType: "function",
		$uses(s) {
			return r.applyExternals(s), this;
		},
		[me$3]: r,
		$name(s) {
			return k(r, s), this;
		},
		with(s, i) {
			return Kn(o, [[dr$1(s) ? s.slot : s, i]]);
		},
		[oe](s) {
			return typeof t == "string" && (Se$1(t, e.argTypes, r.applyExternals), $e$2(t, e.returnType, r.applyExternals)), r.resolve(s, e.argTypes, e.returnType);
		}
	};
	let a = $t((...s) => Fr$2(() => {
		try {
			if (typeof t == "string") throw new Error("Cannot execute on the CPU functions constructed with raw WGSL");
			let u = t(...s.map((l, m) => Pe$2(e.argTypes[m], l)));
			return Pe$2(e.returnType, u);
		} catch (i) {
			throw i instanceof yt$1 ? i.appendToTrace(o) : new yt$1(i, [o]);
		}
	}), (...s) => x$1(new Vt(o, s), e.returnType), "tgpuFnCall", e.argTypes);
	let o = Object.assign(a, n);
	return o[o$1].implementation = t, Object.defineProperty(o, "toString", { value() {
		return `fn:${D(r) ?? "<unnamed>"}`;
	} }), o;
}
function Kn(e, t) {
	let r = {
		resourceType: "function",
		shell: e.shell,
		[He]: {
			inner: e,
			pairs: t
		},
		$uses(o) {
			return e.$uses(o), this;
		},
		[me$3]: e,
		$name(o) {
			return e.$name(o), this;
		},
		with(o, s) {
			return Kn(a, [...t, [dr$1(o) ? o.slot : o, s]]);
		}
	};
	let n = $t((...o) => e(...o), (...o) => x$1(new Vt(a, o), e.shell.returnType), "tgpuFnCall", e.shell.argTypes);
	let a = Object.assign(n, r);
	return a[o$1].implementation = e[o$1].implementation, Object.defineProperty(a, "toString", { value() {
		return `fn:${D(e) ?? "<unnamed>"}[${t.map(ja).join(", ")}]`;
	} }), a[o$1].implementation = e[o$1].implementation, a;
}
var Vt = class {
	[o$1] = !0;
	[qe];
	[me$3];
	#e;
	#r;
	constructor(t, r) {
		this.#e = t, this.#r = r, this[me$3] = t, this[qe] = x$1(this, this.#e.shell.returnType);
	}
	[oe](t) {
		return t.withResetIndentLevel(() => x$1(d$2`${t.resolve(this.#e).value}(${this.#r})`, this.#e.shell.returnType));
	}
	toString() {
		return `call:${D(this) ?? "<unnamed>"}`;
	}
};
function Yn(e) {
	let t = {
		in: e.in,
		out: e.out,
		returnType: F(e.out),
		isEntry: !0
	};
	let r = (n, ...a) => Ha(t, re(n, ...a));
	return Object.assign(Object.assign(r, t), { does: r });
}
function Ha(e, t) {
	let r = ne$1(t, "@fragment ");
	let n = e.returnType;
	return typeof t == "string" && $e$2(t, n, (o) => r.applyExternals(o)), {
		shell: e,
		outputType: n,
		$uses(o) {
			return r.applyExternals(o), this;
		},
		[o$1]: !0,
		[me$3]: r,
		$name(o) {
			return k(r, o), Yt$1(n) && n.$name(`${o}_Output`), this;
		},
		[oe](o) {
			let s = e.in ? F(e.in, o.varyingLocations).$name(`${D(this) ?? ""}_Input`) : void 0;
			return s && r.applyExternals({ In: s }), r.applyExternals({ Out: n }), r.resolve(o, s ? [s] : [], e.returnType);
		},
		toString() {
			return `fragmentFn:${D(r) ?? "<unnamed>"}`;
		}
	};
}
var Jn = /* @__PURE__ */ new Set([
	"alias",
	"break",
	"case",
	"const",
	"const_assert",
	"continue",
	"continuing",
	"default",
	"diagnostic",
	"discard",
	"else",
	"enable",
	"false",
	"fn",
	"for",
	"if",
	"let",
	"loop",
	"override",
	"requires",
	"return",
	"struct",
	"switch",
	"true",
	"var",
	"while",
	"NULL",
	"Self",
	"abstract",
	"active",
	"alignas",
	"alignof",
	"as",
	"asm",
	"asm_fragment",
	"async",
	"attribute",
	"auto",
	"await",
	"become",
	"cast",
	"catch",
	"class",
	"co_await",
	"co_return",
	"co_yield",
	"coherent",
	"column_major",
	"common",
	"compile",
	"compile_fragment",
	"concept",
	"const_cast",
	"consteval",
	"constexpr",
	"constinit",
	"crate",
	"debugger",
	"decltype",
	"delete",
	"demote",
	"demote_to_helper",
	"do",
	"dynamic_cast",
	"enum",
	"explicit",
	"export",
	"extends",
	"extern",
	"external",
	"fallthrough",
	"filter",
	"final",
	"finally",
	"friend",
	"from",
	"fxgroup",
	"get",
	"goto",
	"groupshared",
	"highp",
	"impl",
	"implements",
	"import",
	"inline",
	"instanceof",
	"interface",
	"layout",
	"lowp",
	"macro",
	"macro_rules",
	"match",
	"mediump",
	"meta",
	"mod",
	"module",
	"move",
	"mut",
	"mutable",
	"namespace",
	"new",
	"nil",
	"noexcept",
	"noinline",
	"nointerpolation",
	"non_coherent",
	"noncoherent",
	"noperspective",
	"null",
	"nullptr",
	"of",
	"operator",
	"package",
	"packoffset",
	"partition",
	"pass",
	"patch",
	"pixelfragment",
	"precise",
	"precision",
	"premerge",
	"priv",
	"protected",
	"pub",
	"public",
	"readonly",
	"ref",
	"regardless",
	"register",
	"reinterpret_cast",
	"require",
	"resource",
	"restrict",
	"self",
	"set",
	"shared",
	"sizeof",
	"smooth",
	"snorm",
	"static",
	"static_assert",
	"static_cast",
	"std",
	"subroutine",
	"super",
	"target",
	"template",
	"this",
	"thread_local",
	"throw",
	"trait",
	"try",
	"type",
	"typedef",
	"typeid",
	"typename",
	"typeof",
	"union",
	"unless",
	"unorm",
	"unsafe",
	"unsized",
	"use",
	"using",
	"varying",
	"virtual",
	"volatile",
	"wgsl",
	"where",
	"with",
	"writeonly",
	"yield"
]);
function Ir(e) {
	if (e === "_" || e.startsWith("__") || /\s/.test(e)) throw new Error(`Invalid identifier '${e}'. Choose an identifier without whitespaces or leading underscores.`);
	let t = e.split("_")[0];
	return !Jn.has(t);
}
var _t = class {
	makeValid(t) {
		return Ir(t) ? t : this.makeUnique(t);
	}
};
var Wt = class extends _t {
	lastUniqueId = 0;
	makeUnique(t) {
		let r;
		return t ? (r = t.replaceAll(/\s/g, "_"), r = r.replaceAll(/[^\w\d]/g, "")) : r = "item", `${r}_${this.lastUniqueId++}`;
	}
};
var Mt = class extends _t {
	_usedNames = new Set(Jn);
	makeUnique(t) {
		if (t === void 0) throw new Error("Unnamed item found when using a strict name registry");
		let r = 0;
		let n = t;
		for (; this._usedNames.has(n);) r++, n = `${t}_${r}`;
		return this._usedNames.add(n), n;
	}
};
function Xn(e, t) {
	let r = ne$1(t, "");
	return {
		[o$1]: !0,
		[me$3]: r,
		resourceType: "shellless-impl",
		[oe](n) {
			return r.resolve(n, e, void 0);
		},
		toString() {
			return `fn*:${D(r) ?? "<unnamed>"}`;
		}
	};
}
var kt = class {
	cache = /* @__PURE__ */ new Map();
	get(t, r) {
		let n = nt$2(t);
		if (!n?.ast) return;
		if (!r && n.ast.params.length > 0) throw new Error(`Cannot resolve '${D(t)}' directly, because it expects arguments. Either call it from another function, or wrap it in a shell`);
		let a = (r ?? []).map((i) => yt(i.dataType));
		let o = this.cache.get(t);
		if (o) {
			let i = o.find((u) => u.argTypes.every((l, m) => l === a[m]));
			if (i) return i.value;
		} else o = [], this.cache.set(t, o);
		let s = Xn(a, t);
		return o.push({
			argTypes: a,
			value: s
		}), s;
	}
};
var Ur = class {
	[o$1];
	constructor(t) {
		this[o$1] = {
			nameRegistry: t,
			shelllessRepo: new kt(),
			memoizedResolves: /* @__PURE__ */ new WeakMap(),
			memoizedDerived: /* @__PURE__ */ new WeakMap(),
			listeners: { name: /* @__PURE__ */ new Set() }
		};
	}
	on(t, r) {
		if (t === "name") {
			let n = this[o$1].listeners.name;
			return n.add(r), () => n.delete(r);
		}
		throw new Error(`Unsupported event: ${t}`);
	}
};
function Zn(e, t) {
	let r = e.nameRegistry.makeUnique(D(t));
	for (let n of e.listeners.name) n({
		target: t,
		name: r
	});
	return r;
}
function Q(e) {
	let { names: t = "random" } = e || {};
	return new Ur(t === "strict" ? new Mt() : new Wt());
}
function Ye(e) {
	return typeof e?.format == "string";
}
function ea(e, t) {
	let r = [];
	if (ar$2(e)) {
		if (!Ye(t)) throw new Error("Shader expected a single attribute, not a record of attributes to be passed in.");
		return r.push(t._layout), {
			usedVertexLayouts: r,
			bufferDefinitions: [{
				arrayStride: t._layout.stride,
				stepMode: t._layout.stepMode,
				attributes: [{
					format: t.format,
					offset: t.offset,
					shaderLocation: or$2(e) ?? 0
				}]
			}]
		};
	}
	let n = [];
	let a = /* @__PURE__ */ new WeakMap();
	let o = 0;
	for (let [s, i] of Object.entries(e)) {
		if (In$1(i)) continue;
		let u = t[s];
		if (!u) throw new Error(`An attribute by the name of '${s}' was not provided to the shader.`);
		let l = u._layout;
		let m = a.get(l);
		m || (r.push(l), m = [], n.push({
			arrayStride: l.stride,
			stepMode: l.stepMode,
			attributes: m
		}), a.set(l, m)), o = or$2(i) ?? o, m.push({
			format: u.format,
			offset: u.offset,
			shaderLocation: o++
		});
	}
	return {
		usedVertexLayouts: r,
		bufferDefinitions: n
	};
}
var Ka = [
	"bool",
	"f32",
	"f16",
	"i32",
	"u32",
	"vec2f",
	"vec3f",
	"vec4f",
	"vec2h",
	"vec3h",
	"vec4h",
	"vec2i",
	"vec3i",
	"vec4i",
	"vec2u",
	"vec3u",
	"vec4u",
	"vec2<bool>",
	"vec3<bool>",
	"vec4<bool>",
	"mat2x2f",
	"mat3x3f",
	"mat4x4f",
	"texture_external"
];
function Ya(e) {
	return Ka.includes(e.type);
}
function Fr(e, [t, r]) {
	if (!Ir(t)) throw new Error(`Property key '${t}' is a reserved WGSL word. Choose a different name.`);
	return `  ${Ms$1(r)}${t}: ${e.resolve(r).value},
`;
}
function Ja(e, t) {
	if (t[o$1].isAbstruct) throw new Error("Cannot resolve abstract struct types to WGSL.");
	let r = e.getUniqueName(t);
	return e.addDeclaration(`struct ${r} {
${Object.entries(t.propTypes).map((n) => Fr(e, n)).join("")}}`), r;
}
function Xa(e, t) {
	let r = e.getUniqueName(t);
	return e.addDeclaration(`struct ${r} {
${Object.entries(t.propTypes).map((n) => Ye(n[1]) ? Fr(e, [n[0], De$2[n[1].format]]) : Fr(e, n)).join("")}
}`), r;
}
function Za(e, t) {
	let r = e.resolve(t.elementType).value;
	return t.elementCount === 0 ? `array<${r}>` : `array<${r}, ${t.elementCount}>`;
}
function eo(e, t) {
	let r = e.resolve(Ye(t.elementType) ? De$2[t.elementType.format] : t.elementType).value;
	return t.elementCount === 0 ? `array<${r}>` : `array<${r}, ${t.elementCount}>`;
}
function Pr(e, t) {
	if (Re$1(t)) return t.type === "unstruct" ? Xa(e, t) : t.type === "disarray" ? eo(e, t) : t.type === "loose-decorated" ? e.resolve(Ye(t.inner) ? De$2[t.inner.format] : t.inner).value : e.resolve(De$2[t.type]).value;
	if (Ya(t)) return t.type;
	if (t.type === "struct") return Ja(e, t);
	if (t.type === "array") return Za(e, t);
	if (t.type === "atomic") return `atomic<${Pr(e, t.inner)}>`;
	if (t.type === "decorated") return e.resolve(t.inner).value;
	if (t.type === "ptr") return t.addressSpace === "storage" ? `ptr<storage, ${e.resolve(t.inner).value}, ${t.access === "read-write" ? "read_write" : t.access}>` : `ptr<${t.addressSpace}, ${e.resolve(t.inner).value}>`;
	if (t.type === "abstractInt" || t.type === "abstractFloat" || t.type === "void" || t.type === "u16") throw new Error(`${t.type} has no representation in WGSL`);
	if (Ds(t)) return `${t.type}<${t.format}, ${dt[t.access]}>`;
	if (Us(t)) return t.type.startsWith("texture_depth") ? t.type : `${t.type}<${t.sampleType.type}>`;
	if (Is(t) || Ms(t)) return t.type;
	St(t, "resolveData");
}
var Ge = class e {
	constructor(t) {
		this.bindings = t;
	}
	with(t, r) {
		return new e([...this.bindings, [dr$1(t) ? t.slot : t, r]]);
	}
	pipe(t) {
		let r = t(this);
		return new e([...this.bindings, ...r.bindings]);
	}
};
function* ta(e) {
	let t = 0;
	for (;;) e.has(t) || (yield t), t++;
}
function to(e, t) {
	let r = "size" in e ? e.size : e.currentByteOffset;
	let n = t - 1;
	let a = r & n;
	"skipBytes" in e ? e.skipBytes(t - a & n) : e.add(t - a & n);
}
var B = to;
var ra = /* @__PURE__ */ new WeakMap();
function Ot(e) {
	let t = ra.get(e);
	if (t) return t;
	let r = new Measurer();
	let n = {};
	let a;
	for (let o in e.propTypes) {
		let s = e.propTypes[o];
		if (s === void 0) throw new Error(`Property ${o} is undefined in struct`);
		let i = r.size;
		B(r, ye$2(e) ? re$1(s) : V(s)), a && (a.padding = r.size - i);
		let u = z(s);
		n[o] = {
			offset: r.size,
			size: u
		}, a = n[o], r.add(u);
	}
	return a && (a.padding = ie$2(z(e), V(e)) - r.size), ra.set(e, n), n;
}
var no = (() => {
	try {
		return new Function("return true"), !0;
	} catch {
		return !1;
	}
})();
var Dr = /* @__PURE__ */ new WeakMap();
var zt = {
	u32: "u32",
	vec2u: "u32",
	vec3u: "u32",
	vec4u: "u32",
	u16: "u16",
	i32: "i32",
	vec2i: "i32",
	vec3i: "i32",
	vec4i: "i32",
	f32: "f32",
	vec2f: "f32",
	vec3f: "f32",
	vec4f: "f32",
	f16: "f16",
	vec2h: "f16",
	vec3h: "f16",
	vec4h: "f16",
	mat2x2f: "f32",
	mat3x3f: "f32",
	mat4x4f: "f32"
};
var ao = {
	uint8: "u8",
	uint8x2: "u8",
	uint8x4: "u8",
	sint8: "i8",
	sint8x2: "i8",
	sint8x4: "i8",
	unorm8: "u8",
	unorm8x2: "u8",
	unorm8x4: "u8",
	snorm8: "i8",
	snorm8x2: "i8",
	snorm8x4: "i8",
	uint16: "u16",
	uint16x2: "u16",
	uint16x4: "u16",
	sint16: "i16",
	sint16x2: "i16",
	sint16x4: "i16",
	unorm16: "u16",
	unorm16x2: "u16",
	unorm16x4: "u16",
	snorm16: "i16",
	snorm16x2: "i16",
	snorm16x4: "i16",
	float16: "f16",
	float16x2: "f16",
	float16x4: "f16",
	float32: "f32",
	float32x2: "f32",
	float32x3: "f32",
	float32x4: "f32",
	uint32: "u32",
	uint32x2: "u32",
	uint32x3: "u32",
	uint32x4: "u32",
	sint32: "i32",
	sint32x2: "i32",
	sint32x3: "i32",
	sint32x4: "i32"
};
var Nt = {
	u32: "setUint32",
	i32: "setInt32",
	f32: "setFloat32",
	u16: "setUint16",
	i16: "setInt16",
	f16: "setFloat16",
	u8: "setUint8",
	i8: "setInt8"
};
var oo = {
	unorm8: (e) => `Math.round(${e} * 255)`,
	unorm8x2: (e) => `Math.round(${e} * 255)`,
	unorm8x4: (e) => `Math.round(${e} * 255)`,
	snorm8: (e) => `Math.round(${e} * 127)`,
	snorm8x2: (e) => `Math.round(${e} * 127)`,
	snorm8x4: (e) => `Math.round(${e} * 127)`,
	unorm16: (e) => `Math.round(${e} * 65535)`,
	unorm16x2: (e) => `Math.round(${e} * 65535)`,
	unorm16x4: (e) => `Math.round(${e} * 65535)`,
	snorm16: (e) => `Math.round(${e} * 32767)`,
	snorm16x2: (e) => `Math.round(${e} * 32767)`,
	snorm16x4: (e) => `Math.round(${e} * 32767)`
};
var na = {
	"unorm10-10-10-2": {
		writeFunction: "setUint32",
		generator: (e, t) => `output.setUint32(${e}, ((${t}.x*1023&0x3FF)<<22)|((${t}.y*1023&0x3FF)<<12)|((${t}.z*1023&0x3FF)<<2)|(${t}.w*3&3), littleEndian);
`
	},
	"unorm8x4-bgra": {
		writeFunction: "setUint8",
		generator: (e, t) => {
			let r = [
				"z",
				"y",
				"x",
				"w"
			];
			let n = "";
			for (let a = 0; a < 4; a++) n += `output.setUint8((${e} + ${a}), Math.round(${t}.${r[a]} * 255), littleEndian);
`;
			return n;
		}
	}
};
function qt(e, t, r, n = 0) {
	let a = [
		"i",
		"j",
		"k"
	][n] || `i${n}`;
	if (Gn$1(e) || _$1(e)) return qt(e.inner, t, r, n);
	if (we$3(e) || ye$2(e)) {
		let s = Ot(e);
		let i = "";
		for (let [u, l] of Object.entries(s)) {
			let m = e.propTypes[u];
			m && (i += qt(m, `(${t} + ${l.offset})`, `${r}.${u}`, n));
		}
		return i;
	}
	if (fe$2(e) || ce$1(e)) {
		let s = ie$2(z(e.elementType), V(e));
		let i = "";
		return i += `for (let ${a} = 0; ${a} < ${e.elementCount}; ${a}++) {
`, i += qt(e.elementType, `(${t} + ${a} * ${s})`, `${r}[${a}]`, n + 1), i += `}
`, i;
	}
	if (ae$1(e)) {
		let s = zt[e.type];
		let i = "";
		let u = Nt[s];
		let l = [
			"x",
			"y",
			"z",
			"w"
		];
		let m = Ct$1(e) ? 2 : Ot$1(e) ? 3 : 4;
		for (let y = 0; y < m; y++) i += `output.${u}((${t} + ${y * 4}), ${r}.${l[y]}, littleEndian);
`;
		return i;
	}
	if (Ue$2(e)) {
		let i = Nt[zt[e.type]];
		let u = Lt(e) ? 2 : jt$1(e) ? 3 : 4;
		let l = u * u;
		let m = ie$2(u * 4, 8);
		let y = "";
		for (let f = 0; f < l; f++) {
			let T = Math.floor(f / u);
			let w = f % u;
			let x = T * m + w * 4;
			y += `output.${i}((${t} + ${x}), ${r}.columns[${T}].${[
				"x",
				"y",
				"z",
				"w"
			][w]}, littleEndian);
`;
		}
		return y;
	}
	if (ds(e)) {
		let s = e.type;
		if (s in na) return na[s].generator(t, r);
		let i = ao[s];
		let u = Nt[i];
		let l = De$2[s];
		let m = Mt$1(l) ? 4 : Ot$1(l) ? 3 : Ct$1(l) ? 2 : 1;
		let y = i === "u8" || i === "i8" ? 1 : i === "u16" || i === "i16" || i === "f16" ? 2 : 4;
		let f = [
			"x",
			"y",
			"z",
			"w"
		];
		let T = oo[s];
		let w = "";
		for (let x = 0; x < m; x++) {
			let P = m === 1 ? r : `${r}.${f[x]}`;
			let F = T ? T(P) : P;
			w += `output.${u}((${t} + ${x * y}), ${F}, littleEndian);
`;
		}
		return w;
	}
	if (!Object.hasOwn(zt, e.type)) throw new Error(`Primitive ${e.type} is unsupported by compiled writer`);
	return `output.${Nt[zt[e.type]]}(${t}, ${r}, littleEndian);
`;
}
function Br(e) {
	if (!no) {
		console.warn("This environment does not allow eval - using default writer as fallback");
		return;
	}
	if (Dr.has(e)) return Dr.get(e);
	try {
		let t = qt(e, "offset", "value", 0);
		let r = new Function("output", "offset", "value", "littleEndian=true", t);
		return Dr.set(e, r), r;
	} catch (t) {
		console.warn(`Failed to compile writer for schema: ${e}
Reason: ${t instanceof Error ? t.message : String(t)}
Falling back to default writer`);
	}
}
var Ce = {
	bool() {
		throw new Error("Booleans are not host-shareable");
	},
	f32(e, t, r) {
		e.writeFloat32(r);
	},
	f16(e, t, r) {
		e.writeFloat16(r);
	},
	i32(e, t, r) {
		e.writeInt32(r);
	},
	u32(e, t, r) {
		e.writeUint32(r);
	},
	u16(e, t, r) {
		e.writeUint16(r);
	},
	vec2f(e, t, r) {
		e.writeFloat32(r.x), e.writeFloat32(r.y);
	},
	vec2h(e, t, r) {
		e.writeFloat16(r.x), e.writeFloat16(r.y);
	},
	vec2i(e, t, r) {
		e.writeInt32(r.x), e.writeInt32(r.y);
	},
	vec2u(e, t, r) {
		e.writeUint32(r.x), e.writeUint32(r.y);
	},
	"vec2<bool>"() {
		throw new Error("Booleans are not host-shareable");
	},
	vec3f(e, t, r) {
		e.writeFloat32(r.x), e.writeFloat32(r.y), e.writeFloat32(r.z);
	},
	vec3h(e, t, r) {
		e.writeFloat16(r.x), e.writeFloat16(r.y), e.writeFloat16(r.z);
	},
	vec3i(e, t, r) {
		e.writeInt32(r.x), e.writeInt32(r.y), e.writeInt32(r.z);
	},
	vec3u(e, t, r) {
		e.writeUint32(r.x), e.writeUint32(r.y), e.writeUint32(r.z);
	},
	"vec3<bool>"() {
		throw new Error("Booleans are not host-shareable");
	},
	vec4f(e, t, r) {
		e.writeFloat32(r.x), e.writeFloat32(r.y), e.writeFloat32(r.z), e.writeFloat32(r.w);
	},
	vec4h(e, t, r) {
		e.writeFloat16(r.x), e.writeFloat16(r.y), e.writeFloat16(r.z), e.writeFloat16(r.w);
	},
	vec4i(e, t, r) {
		e.writeInt32(r.x), e.writeInt32(r.y), e.writeInt32(r.z), e.writeInt32(r.w);
	},
	vec4u(e, t, r) {
		e.writeUint32(r.x), e.writeUint32(r.y), e.writeUint32(r.z), e.writeUint32(r.w);
	},
	"vec4<bool>"() {
		throw new Error("Booleans are not host-shareable");
	},
	mat2x2f(e, t, r) {
		for (let n = 0; n < r.length; ++n) e.writeFloat32(r[n]);
	},
	mat3x3f(e, t, r) {
		for (let n = 0; n < r.length; ++n) e.writeFloat32(r[n]);
	},
	mat4x4f(e, t, r) {
		for (let n = 0; n < r.length; ++n) e.writeFloat32(r[n]);
	},
	struct(e, t, r) {
		let n = V(t);
		B(e, n);
		for (let [a, o] of Object.entries(t.propTypes)) B(e, V(o)), Ee(e, o, r[a]);
		B(e, n);
	},
	array(e, t, r) {
		if (t.elementCount === 0) throw new Error("Cannot write using a runtime-sized schema.");
		let n = V(t);
		B(e, n);
		let a = e.currentByteOffset;
		for (let o = 0; o < Math.min(t.elementCount, r.length); o++) B(e, n), Ee(e, t.elementType, r[o]);
		e.seekTo(a + z(t));
	},
	ptr() {
		throw new Error("Pointers are not host-shareable");
	},
	atomic(e, t, r) {
		Ce[t.inner.type]?.(e, t, r);
	},
	decorated(e, t, r) {
		B(e, re$1(t));
		let a = e.currentByteOffset;
		Ce[t.inner?.type]?.(e, t.inner, r), e.seekTo(a + z(t));
	},
	uint8(e, t, r) {
		e.writeUint8(r);
	},
	uint8x2(e, t, r) {
		e.writeUint8(r.x), e.writeUint8(r.y);
	},
	uint8x4(e, t, r) {
		e.writeUint8(r.x), e.writeUint8(r.y), e.writeUint8(r.z), e.writeUint8(r.w);
	},
	sint8(e, t, r) {
		e.writeInt8(r);
	},
	sint8x2(e, t, r) {
		e.writeInt8(r.x), e.writeInt8(r.y);
	},
	sint8x4(e, t, r) {
		e.writeInt8(r.x), e.writeInt8(r.y), e.writeInt8(r.z), e.writeInt8(r.w);
	},
	unorm8(e, t, r) {
		e.writeUint8(Math.round(r * 255));
	},
	unorm8x2(e, t, r) {
		e.writeUint8(Math.round(r.x * 255)), e.writeUint8(Math.round(r.y * 255));
	},
	unorm8x4(e, t, r) {
		e.writeUint8(Math.round(r.x * 255)), e.writeUint8(Math.round(r.y * 255)), e.writeUint8(Math.round(r.z * 255)), e.writeUint8(Math.round(r.w * 255));
	},
	snorm8(e, t, r) {
		e.writeInt8(Math.round(r * 127));
	},
	snorm8x2(e, t, r) {
		e.writeInt8(Math.round(r.x * 127)), e.writeInt8(Math.round(r.y * 127));
	},
	snorm8x4(e, t, r) {
		e.writeInt8(Math.round(r.x * 127)), e.writeInt8(Math.round(r.y * 127)), e.writeInt8(Math.round(r.z * 127)), e.writeInt8(Math.round(r.w * 127));
	},
	uint16(e, t, r) {
		e.writeUint16(r);
	},
	uint16x2(e, t, r) {
		e.writeUint16(r.x), e.writeUint16(r.y);
	},
	uint16x4(e, t, r) {
		e.writeUint16(r.x), e.writeUint16(r.y), e.writeUint16(r.z), e.writeUint16(r.w);
	},
	sint16(e, t, r) {
		e.writeInt16(r);
	},
	sint16x2(e, t, r) {
		e.writeInt16(r.x), e.writeInt16(r.y);
	},
	sint16x4(e, t, r) {
		e.writeInt16(r.x), e.writeInt16(r.y), e.writeInt16(r.z), e.writeInt16(r.w);
	},
	unorm16(e, t, r) {
		e.writeUint16(r * 65535);
	},
	unorm16x2(e, t, r) {
		e.writeUint16(r.x * 65535), e.writeUint16(r.y * 65535);
	},
	unorm16x4(e, t, r) {
		e.writeUint16(r.x * 65535), e.writeUint16(r.y * 65535), e.writeUint16(r.z * 65535), e.writeUint16(r.w * 65535);
	},
	snorm16(e, t, r) {
		e.writeInt16(Math.round(r * 32767));
	},
	snorm16x2(e, t, r) {
		e.writeInt16(Math.round(r.x * 32767)), e.writeInt16(Math.round(r.y * 32767));
	},
	snorm16x4(e, t, r) {
		e.writeInt16(Math.round(r.x * 32767)), e.writeInt16(Math.round(r.y * 32767)), e.writeInt16(Math.round(r.z * 32767)), e.writeInt16(Math.round(r.w * 32767));
	},
	float16(e, t, r) {
		e.writeFloat16(r);
	},
	float16x2(e, t, r) {
		e.writeFloat16(r.x), e.writeFloat16(r.y);
	},
	float16x4(e, t, r) {
		e.writeFloat16(r.x), e.writeFloat16(r.y), e.writeFloat16(r.z), e.writeFloat16(r.w);
	},
	float32(e, t, r) {
		e.writeFloat32(r);
	},
	float32x2(e, t, r) {
		e.writeFloat32(r.x), e.writeFloat32(r.y);
	},
	float32x3(e, t, r) {
		e.writeFloat32(r.x), e.writeFloat32(r.y), e.writeFloat32(r.z);
	},
	float32x4(e, t, r) {
		e.writeFloat32(r.x), e.writeFloat32(r.y), e.writeFloat32(r.z), e.writeFloat32(r.w);
	},
	uint32(e, t, r) {
		e.writeUint32(r);
	},
	uint32x2(e, t, r) {
		e.writeUint32(r.x), e.writeUint32(r.y);
	},
	uint32x3(e, t, r) {
		e.writeUint32(r.x), e.writeUint32(r.y), e.writeUint32(r.z);
	},
	uint32x4(e, t, r) {
		e.writeUint32(r.x), e.writeUint32(r.y), e.writeUint32(r.z), e.writeUint32(r.w);
	},
	sint32(e, t, r) {
		e.writeInt32(r);
	},
	sint32x2(e, t, r) {
		e.writeInt32(r.x), e.writeInt32(r.y);
	},
	sint32x3(e, t, r) {
		e.writeInt32(r.x), e.writeInt32(r.y), e.writeInt32(r.z);
	},
	sint32x4(e, t, r) {
		e.writeInt32(r.x), e.writeInt32(r.y), e.writeInt32(r.z), e.writeInt32(r.w);
	},
	"unorm10-10-10-2"(e, t, r) {
		let n = 0;
		n |= (r.x * 1023 & 1023) << 22, n |= (r.y * 1023 & 1023) << 12, n |= (r.z * 1023 & 1023) << 2, n |= r.w * 3 & 3, e.writeUint32(n);
	},
	"unorm8x4-bgra"(e, t, r) {
		e.writeUint8(r.z * 255), e.writeUint8(r.y * 255), e.writeUint8(r.x * 255), e.writeUint8(r.w * 255);
	},
	disarray(e, t, r) {
		let n = V(t);
		B(e, n);
		let a = e.currentByteOffset;
		for (let o = 0; o < Math.min(t.elementCount, r.length); o++) B(e, n), Ce[t.elementType?.type]?.(e, t.elementType, r[o]);
		e.seekTo(a + z(t));
	},
	unstruct(e, t, r) {
		let n = t.propTypes;
		for (let [a, o] of Object.entries(n)) Ce[o.type]?.(e, o, r[a]);
	},
	"loose-decorated"(e, t, r) {
		B(e, re$1(t));
		let a = e.currentByteOffset;
		let o = Ce[t.inner?.type];
		return o?.(e, t.inner, r), e.seekTo(a + z(t)), r;
	}
};
function Ee(e, t, r) {
	let n = Ce[t.type];
	if (!n) throw new Error(`Cannot write data of type '${t.type}'.`);
	n(e, t, r);
}
var so = {
	bool() {
		throw new Error("Booleans are not host-shareable");
	},
	f32(e) {
		return e.readFloat32();
	},
	f16(e) {
		return e.readFloat16();
	},
	i32(e) {
		return e.readInt32();
	},
	u32(e) {
		return e.readUint32();
	},
	u16(e) {
		return e.readUint16();
	},
	vec2f(e) {
		return B$1(e.readFloat32(), e.readFloat32());
	},
	vec3f(e) {
		return Le(e.readFloat32(), e.readFloat32(), e.readFloat32());
	},
	vec4f(e) {
		return v(e.readFloat32(), e.readFloat32(), e.readFloat32(), e.readFloat32());
	},
	vec2h(e) {
		return hn$1(e.readFloat16(), e.readFloat16());
	},
	vec3h(e) {
		return dn$1(e.readFloat16(), e.readFloat16(), e.readFloat16());
	},
	vec4h(e) {
		return fn$1(e.readFloat16(), e.readFloat16(), e.readFloat16(), e.readFloat16());
	},
	vec2i(e) {
		return pe$3(e.readInt32(), e.readInt32());
	},
	vec3i(e) {
		return je(e.readInt32(), e.readInt32(), e.readInt32());
	},
	vec4i(e) {
		return xe$2(e.readInt32(), e.readInt32(), e.readInt32(), e.readInt32());
	},
	vec2u(e) {
		return he$3(e.readUint32(), e.readUint32());
	},
	vec3u(e) {
		return E(e.readUint32(), e.readUint32(), e.readUint32());
	},
	vec4u(e) {
		return de$1(e.readUint32(), e.readUint32(), e.readUint32(), e.readUint32());
	},
	"vec2<bool>"() {
		throw new Error("Booleans are not host-shareable");
	},
	"vec3<bool>"() {
		throw new Error("Booleans are not host-shareable");
	},
	"vec4<bool>"() {
		throw new Error("Booleans are not host-shareable");
	},
	mat2x2f(e) {
		return ie$1(e.readFloat32(), e.readFloat32(), e.readFloat32(), e.readFloat32());
	},
	mat3x3f(e) {
		let t = () => {
			let r = e.readFloat32();
			return e.readFloat32(), r;
		};
		return le$1(e.readFloat32(), e.readFloat32(), t(), e.readFloat32(), e.readFloat32(), t(), e.readFloat32(), e.readFloat32(), t());
	},
	mat4x4f(e) {
		return A$1(e.readFloat32(), e.readFloat32(), e.readFloat32(), e.readFloat32(), e.readFloat32(), e.readFloat32(), e.readFloat32(), e.readFloat32(), e.readFloat32(), e.readFloat32(), e.readFloat32(), e.readFloat32(), e.readFloat32(), e.readFloat32(), e.readFloat32(), e.readFloat32());
	},
	struct(e, t) {
		let r = V(t);
		B(e, r);
		let n = {};
		let a = t.propTypes;
		for (let [o, s] of Object.entries(a)) B(e, V(s)), n[o] = O(e, s);
		return B(e, r), n;
	},
	array(e, t) {
		if (t.elementCount === 0) throw new Error("Cannot read using a runtime-sized schema.");
		let r = V(t);
		let n = [];
		for (let a = 0; a < t.elementCount; a++) {
			B(e, r);
			let o = t.elementType;
			let s = O(e, o);
			n.push(s);
		}
		return B(e, r), n;
	},
	ptr() {
		throw new Error("Pointers are not host-shareable");
	},
	atomic(e, t) {
		return O(e, t.inner);
	},
	decorated(e, t) {
		B(e, re$1(t));
		let n = e.currentByteOffset;
		let a = O(e, t.inner);
		return e.seekTo(n + z(t)), a;
	},
	uint8: (e) => e.readUint8(),
	uint8x2: (e) => he$3(e.readUint8(), e.readUint8()),
	uint8x4: (e) => de$1(e.readUint8(), e.readUint8(), e.readUint8(), e.readUint8()),
	sint8: (e) => e.readInt8(),
	sint8x2: (e) => pe$3(e.readInt8(), e.readInt8()),
	sint8x4: (e) => xe$2(e.readInt8(), e.readInt8(), e.readInt8(), e.readInt8()),
	unorm8: (e) => e.readUint8() / 255,
	unorm8x2: (e) => B$1(e.readUint8() / 255, e.readUint8() / 255),
	unorm8x4: (e) => v(e.readUint8() / 255, e.readUint8() / 255, e.readUint8() / 255, e.readUint8() / 255),
	snorm8: (e) => e.readInt8() / 127,
	snorm8x2: (e) => B$1(e.readInt8() / 127, e.readInt8() / 127),
	snorm8x4: (e) => v(e.readInt8() / 127, e.readInt8() / 127, e.readInt8() / 127, e.readInt8() / 127),
	uint16: (e) => e.readUint16(),
	uint16x2: (e) => he$3(e.readUint16(), e.readUint16()),
	uint16x4: (e) => de$1(e.readUint16(), e.readUint16(), e.readUint16(), e.readUint16()),
	sint16: (e) => e.readInt16(),
	sint16x2: (e) => pe$3(e.readInt16(), e.readInt16()),
	sint16x4: (e) => xe$2(e.readInt16(), e.readInt16(), e.readInt16(), e.readInt16()),
	unorm16: (e) => e.readUint16() / 65535,
	unorm16x2: (e) => B$1(e.readUint16() / 65535, e.readUint16() / 65535),
	unorm16x4: (e) => v(e.readUint16() / 65535, e.readUint16() / 65535, e.readUint16() / 65535, e.readUint16() / 65535),
	snorm16: (e) => e.readInt16() / 32767,
	snorm16x2: (e) => B$1(e.readInt16() / 32767, e.readInt16() / 32767),
	snorm16x4: (e) => v(e.readInt16() / 32767, e.readInt16() / 32767, e.readInt16() / 32767, e.readInt16() / 32767),
	float16(e) {
		return e.readFloat16();
	},
	float16x2: (e) => B$1(e.readFloat16(), e.readFloat16()),
	float16x4: (e) => v(e.readFloat16(), e.readFloat16(), e.readFloat16(), e.readFloat16()),
	float32: (e) => e.readFloat32(),
	float32x2: (e) => B$1(e.readFloat32(), e.readFloat32()),
	float32x3: (e) => Le(e.readFloat32(), e.readFloat32(), e.readFloat32()),
	float32x4: (e) => v(e.readFloat32(), e.readFloat32(), e.readFloat32(), e.readFloat32()),
	uint32: (e) => e.readUint32(),
	uint32x2: (e) => he$3(e.readUint32(), e.readUint32()),
	uint32x3: (e) => E(e.readUint32(), e.readUint32(), e.readUint32()),
	uint32x4: (e) => de$1(e.readUint32(), e.readUint32(), e.readUint32(), e.readUint32()),
	sint32: (e) => e.readInt32(),
	sint32x2: (e) => pe$3(e.readInt32(), e.readInt32()),
	sint32x3: (e) => je(e.readInt32(), e.readInt32(), e.readInt32()),
	sint32x4: (e) => xe$2(e.readInt32(), e.readInt32(), e.readInt32(), e.readInt32()),
	"unorm10-10-10-2"(e) {
		let t = e.readUint32();
		return v((t >> 22) / 1023, (t >> 12 & 1023) / 1023, (t >> 2 & 1023) / 1023, (t & 3) / 3);
	},
	"unorm8x4-bgra"(e) {
		let t = e.readByte() / 255;
		let r = e.readByte() / 255;
		return v(e.readByte() / 255, r, t, e.readByte() / 255);
	},
	unstruct(e, t) {
		let r = {};
		let n = t.propTypes;
		for (let [a, o] of Object.entries(n)) r[a] = O(e, o);
		return r;
	},
	disarray(e, t) {
		let r = V(t);
		let n = [];
		for (let a = 0; a < t.elementCount; a++) B(e, r), n.push(O(e, t.elementType));
		return B(e, r), n;
	},
	"loose-decorated"(e, t) {
		B(e, re$1(t));
		let r = e.currentByteOffset;
		let n = O(e, t.inner);
		return e.seekTo(r + z(t)), n;
	}
};
function O(e, t) {
	let r = so[t.type];
	if (!r) throw new Error(`Cannot read data of type '${t.type}'.`);
	return r(e, t);
}
function aa(e, t) {
	let r = z(e);
	if (r === 0 || t === void 0 || t === null) return [];
	let n = new ArrayBuffer(r);
	let a = new BufferWriter(n);
	let o = [];
	function s(l, m, y, f) {
		if (m != null) {
			if (we$3(l) || ye$2(l)) {
				let T = Ot(l);
				for (let [w, x] of Object.entries(T)) {
					let P = l.propTypes[w];
					if (!P) continue;
					let F = m[w];
					F !== void 0 && s(P, F, y + x.offset, x.padding ?? f);
				}
				return;
			}
			if (fe$2(l) || ce$1(l)) {
				let T = l;
				let w = ie$2(z(T.elementType), V(T.elementType));
				if (!Array.isArray(m)) throw new Error("Partial value for array must be an array");
				let x = m ?? [];
				x.sort((P, F) => P.idx - F.idx);
				for (let { idx: P, value: F } of x) s(T.elementType, F, y + P * w, w - z(T.elementType));
			} else {
				let T = z(l);
				a.seekTo(y), Ee(a, l, m), o.push({
					start: y,
					end: y + T,
					padding: f
				});
			}
		}
	}
	if (s(e, t, 0), o.length === 0) return [];
	let i = [];
	let u = o[0];
	for (let l = 1; l < o.length; l++) {
		let m = o[l];
		if (!m || !u) throw new Error("Internal error: missing segment");
		m.start === u.end + (u.padding ?? 0) ? (u.end = m.end, u.padding = m.padding) : (i.push({ data: new Uint8Array(n, u.start, u.end - u.start) }), u = m);
	}
	if (!u) throw new Error("Internal error: missing segment");
	return i.push({ data: new Uint8Array(n, u.start, u.end - u.start) }), i;
}
function Te(e) {
	return !!e?.usableAsStorage;
}
var Je = class e extends Error {
	constructor(t) {
		super(`Resource '${D(t) ?? "<unnamed>"}' cannot be bound as 'storage'. Use .$usage('storage') to allow it.`), Object.setPrototypeOf(this, e.prototype);
	}
};
function jt(e) {
	return !!e.usableAsUniform;
}
var ua = {
	uniform: "uniform",
	mutable: "storage, read_write",
	readonly: "storage, read"
};
var Xe = class {
	constructor(t, r) {
		this.usage = t;
		this.buffer = r;
		this[o$1] = { dataType: r.dataType }, this[me$3] = r;
	}
	resourceType = "buffer-usage";
	[o$1];
	[me$3];
	$name(t) {
		return this.buffer.$name(t), this;
	}
	[oe](t) {
		let r = this.buffer.dataType, n = t.getUniqueName(this), { group: a, binding: o } = t.allocateFixedEntry(this.usage === "uniform" ? { uniform: r } : {
			storage: r,
			access: this.usage
		}, this.buffer), s = ua[this.usage];
		return t.addDeclaration(`@group(${a}) @binding(${o}) var<${s}> ${n}: ${t.resolve(r).value};`), x$1(n, r);
	}
	toString() {
		return `${this.usage}:${D(this) ?? "<unnamed>"}`;
	}
	get [kn$1]() {
		let t = this.buffer.dataType;
		return new Proxy({
			[o$1]: !0,
			get [qe]() {
				return x$1(this, t);
			},
			[oe]: (r) => r.resolve(this),
			toString: () => `${this.usage}:${D(this) ?? "<unnamed>"}.$`
		}, _t$1);
	}
	get $() {
		let t = Er$2();
		let r = Pr$2();
		if (t.type === "normal") throw new ft$1(r ? `Cannot access ${String(this.buffer)}. TypeGPU functions that depends on GPU resources need to be part of a compute dispatch, draw call or simulation` : ".$ and .value are inaccessible during normal JS execution. Try `.read()`");
		return t.type === "codegen" ? this[kn$1] : t.type === "simulate" ? (t.buffers.has(this.buffer) || t.buffers.set(this.buffer, Pe$2(this.buffer.dataType, this.buffer.initial)), t.buffers.get(this.buffer)) : St(t, "bufferUsage.ts#TgpuFixedBufferImpl/$");
	}
	get value() {
		return this.$;
	}
	set $(t) {
		let r = Er$2();
		let n = Pr$2();
		if (r.type === "normal") throw new ft$1(n ? `Cannot access ${String(this.buffer)}. TypeGPU functions that depends on GPU resources need to be part of a compute dispatch, draw call or simulation` : ".$ and .value are inaccessible during normal JS execution. Try `.write()`");
		if (r.type === "codegen") throw new Error("Unreachable bufferUsage.ts#TgpuFixedBufferImpl/$");
		if (r.type === "simulate") {
			r.buffers.set(this.buffer, t);
			return;
		}
		St(r, "bufferUsage.ts#TgpuFixedBufferImpl/$");
	}
	set value(t) {
		this.$ = t;
	}
};
var Ze = class {
	constructor(t, r, n) {
		this.usage = t;
		this.dataType = r;
		this[o$1] = { dataType: r }, this.#e = n, k(this, n.key);
	}
	[o$1];
	resourceType = "buffer-usage";
	#e;
	[oe](t) {
		let r = this.dataType;
		let n = t.getUniqueName(this);
		let a = t.allocateLayoutEntry(this.#e.layout);
		let o = ua[this.usage];
		return t.addDeclaration(`@group(${a}) @binding(${this.#e.idx}) var<${o}> ${n}: ${t.resolve(r).value};`), x$1(n, r);
	}
	toString() {
		return `${this.usage}:${D(this) ?? "<unnamed>"}`;
	}
	get [kn$1]() {
		let t = this.dataType;
		return new Proxy({
			[o$1]: !0,
			get [qe]() {
				return x$1(this, t);
			},
			[oe]: (r) => r.resolve(this),
			toString: () => `${this.usage}:${D(this) ?? "<unnamed>"}.$`
		}, _t$1);
	}
	get $() {
		if (Oe$1()) return this[kn$1];
		throw new Error("Direct access to buffer values is possible only as part of a compute dispatch or draw call. Try .read() or .write() instead");
	}
	get value() {
		return this.$;
	}
};
var oa = /* @__PURE__ */ new WeakMap();
function pa(e) {
	if (!Te(e)) throw new Error(`Cannot pass ${e} to asMutable, as it is not allowed to be used as storage. To allow it, call .$usage('storage') when creating the buffer.`);
	let t = oa.get(e);
	return t || (t = new Xe("mutable", e), oa.set(e, t)), t;
}
var sa = /* @__PURE__ */ new WeakMap();
function la(e) {
	if (!Te(e)) throw new Error(`Cannot pass ${e} to asReadonly, as it is not allowed to be used as storage. To allow it, call .$usage('storage') when creating the buffer.`);
	let t = sa.get(e);
	return t || (t = new Xe("readonly", e), sa.set(e, t)), t;
}
var ia = /* @__PURE__ */ new WeakMap();
function ma(e) {
	if (!jt(e)) throw new Error(`Cannot pass ${e} to asUniform, as it is not allowed to be used as a uniform. To allow it, call .$usage('uniform') when creating the buffer.`);
	let t = ia.get(e);
	return t || (t = new Xe("uniform", e), ia.set(e, t)), t;
}
var lo = {
	uniform: ma,
	mutable: pa,
	readonly: la
};
function et(e, t, r) {
	return C(t) ? new Qt(e, t, r) : new Qt(e, t, r, ["storage", "uniform"]);
}
function le(e) {
	return e.resourceType === "buffer";
}
var fo = /* @__PURE__ */ getSystemEndianness();
var Qt = class {
	constructor(t, r, n, a) {
		this.dataType = r;
		this.initialOrBuffer = n;
		this._disallowedUsages = a;
		this.#e = t.device, Ar$1(n) ? (this._ownBuffer = !1, this._buffer = n) : (this._ownBuffer = !0, this.initial = n);
	}
	[o$1] = !0;
	resourceType = "buffer";
	flags = GPUBufferUsage.COPY_DST | GPUBufferUsage.COPY_SRC;
	#e;
	_buffer = null;
	_ownBuffer;
	_destroyed = !1;
	_hostBuffer;
	initial;
	usableAsUniform = !1;
	usableAsStorage = !1;
	usableAsVertex = !1;
	usableAsIndex = !1;
	get buffer() {
		if (this._destroyed) throw new Error("This buffer has been destroyed");
		return this._buffer || (this._buffer = this.#e.createBuffer({
			size: z(this.dataType),
			usage: this.flags,
			mappedAtCreation: !!this.initial,
			label: D(this) ?? "<unnamed>"
		}), this.initial && (this._writeToTarget(this._buffer.getMappedRange(), this.initial), this._buffer.unmap())), this._buffer;
	}
	get destroyed() {
		return this._destroyed;
	}
	$name(t) {
		return k(this, t), this._buffer && (this._buffer.label = t), this;
	}
	$usage(...t) {
		for (let r of t) {
			if (this._disallowedUsages?.includes(r)) throw new Error(`Buffer of type ${this.dataType.type} cannot be used as ${r}`);
			this.flags |= r === "uniform" ? GPUBufferUsage.UNIFORM : 0, this.flags |= r === "storage" ? GPUBufferUsage.STORAGE : 0, this.flags |= r === "vertex" ? GPUBufferUsage.VERTEX : 0, this.flags |= r === "index" ? GPUBufferUsage.INDEX : 0, this.usableAsUniform = this.usableAsUniform || r === "uniform", this.usableAsStorage = this.usableAsStorage || r === "storage", this.usableAsVertex = this.usableAsVertex || r === "vertex", this.usableAsIndex = this.usableAsIndex || r === "index";
		}
		return this;
	}
	$addFlags(t) {
		if (!this._ownBuffer) throw new Error("Cannot add flags to a buffer that is not managed by TypeGPU.");
		return t & GPUBufferUsage.MAP_READ ? (this.flags = GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ, this) : t & GPUBufferUsage.MAP_WRITE ? (this.flags = GPUBufferUsage.COPY_SRC | GPUBufferUsage.MAP_WRITE, this) : (this.flags |= t, this);
	}
	compileWriter() {
		Br(this.dataType);
	}
	_writeToTarget(t, r) {
		let n = Br(this.dataType);
		if (n) try {
			n(new DataView(t), 0, r, fo === "little");
			return;
		} catch (a) {
			console.error(`Error when using compiled writer for buffer ${D(this) ?? "<unnamed>"} - this is likely a bug, please submit an issue at https://github.com/software-mansion/TypeGPU/issues
Using fallback writer instead.`, a);
		}
		Ee(new BufferWriter(t), this.dataType, r);
	}
	write(t) {
		let r = this.buffer;
		if (r.mapState === "mapped") {
			let a = r.getMappedRange();
			this._writeToTarget(a, t);
			return;
		}
		let n = z(this.dataType);
		this._hostBuffer || (this._hostBuffer = new ArrayBuffer(n)), this._writeToTarget(this._hostBuffer, t), this.#e.queue.writeBuffer(r, 0, this._hostBuffer, 0, n);
	}
	writePartial(t) {
		let r = this.buffer;
		let n = aa(this.dataType, t);
		if (r.mapState === "mapped") {
			let a = r.getMappedRange();
			let o = new Uint8Array(a);
			for (let s of n) o.set(s.data, s.data.byteOffset);
		} else for (let a of n) this.#e.queue.writeBuffer(r, a.data.byteOffset, a.data, 0, a.data.byteLength);
	}
	clear() {
		let t = this.buffer;
		if (t.mapState === "mapped") {
			new Uint8Array(t.getMappedRange()).fill(0);
			return;
		}
		let r = this.#e.createCommandEncoder();
		r.clearBuffer(t), this.#e.queue.submit([r.finish()]);
	}
	copyFrom(t) {
		if (this.buffer.mapState === "mapped") throw new Error("Cannot copy to a mapped buffer.");
		let r = z(this.dataType);
		let n = this.#e.createCommandEncoder();
		n.copyBufferToBuffer(t.buffer, 0, this.buffer, 0, r), this.#e.queue.submit([n.finish()]);
	}
	async read() {
		let t = this.buffer;
		if (t.mapState === "mapped") return O(new BufferReader(t.getMappedRange()), this.dataType);
		if (t.usage & GPUBufferUsage.MAP_READ) {
			await t.mapAsync(GPUMapMode.READ);
			let s = O(new BufferReader(t.getMappedRange()), this.dataType);
			return t.unmap(), s;
		}
		let r = (globalThis.__TYPEGPU_AUTONAME__ ?? ((a) => a))(this.#e.createBuffer({
			size: z(this.dataType),
			usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ
		}), "r");
		let n = this.#e.createCommandEncoder();
		n.copyBufferToBuffer(t, 0, r, 0, z(this.dataType)), this.#e.queue.submit([n.finish()]), await r.mapAsync(GPUMapMode.READ, 0, z(this.dataType));
		let a = O(new BufferReader(r.getMappedRange()), this.dataType);
		return r.unmap(), r.destroy(), a;
	}
	as(t) {
		return lo[t]?.(this);
	}
	destroy() {
		this._destroyed || (this._destroyed = !0, this._ownBuffer && this._buffer?.destroy());
	}
	toString() {
		return `buffer:${D(this) ?? "<unnamed>"}`;
	}
};
function fa(e, t) {
	return new Kt(ws(), e, t);
}
function da(e, t) {
	return new Kt(Ss(), e, t);
}
function tt(e) {
	let t = e;
	return t?.resourceType === "sampler" && !!t[o$1];
}
function rt(e) {
	let t = e;
	return t?.resourceType === "sampler-comparison" && !!t[o$1];
}
var Ht = class {
	constructor(t, r) {
		this.schema = t;
		this.#e = r, this.resourceType = t.type === "sampler_comparison" ? "sampler-comparison" : "sampler", k(this, r.key);
	}
	[o$1] = { unwrap: void 0 };
	resourceType;
	#e;
	[oe](t) {
		let r = t.getUniqueName(this);
		let n = t.allocateLayoutEntry(this.#e.layout);
		return t.addDeclaration(`@group(${n}) @binding(${this.#e.idx}) var ${r}: ${t.resolve(this.schema).value};`), x$1(r, this.schema);
	}
	get [kn$1]() {
		let t = this.schema;
		return new Proxy({
			[o$1]: !0,
			get [qe]() {
				return x$1(this, t);
			},
			[oe]: (r) => r.resolve(this),
			toString: () => `${this.toString()}.$`
		}, _t$1);
	}
	get $() {
		if (Oe$1()) return this[kn$1];
		throw new Error("Direct access to sampler values is possible only as part of a compute dispatch or draw call.");
	}
	get value() {
		return this.$;
	}
	toString() {
		return `${this.resourceType}:${D(this) ?? "<unnamed>"}`;
	}
};
var Kt = class {
	constructor(t, r, n) {
		this.schema = t;
		this.#t = r, this.#n = n, this.resourceType = t.type === "sampler_comparison" ? "sampler-comparison" : "sampler", this[o$1] = { unwrap: () => (this.#r || (this.#r = this.#n.device.createSampler({
			...this.#t,
			label: D(this) ?? "<unnamed>"
		})), this.#r) }, this.#e = r.minFilter === "linear" || r.magFilter === "linear" || r.mipmapFilter === "linear";
	}
	[o$1];
	resourceType;
	#e;
	#r = null;
	#t;
	#n;
	[oe](t) {
		let r = t.getUniqueName(this), { group: n, binding: a } = t.allocateFixedEntry(this.schema.type === "sampler_comparison" ? { sampler: "comparison" } : { sampler: this.#e ? "filtering" : "non-filtering" }, this);
		return t.addDeclaration(`@group(${n}) @binding(${a}) var ${r}: ${t.resolve(this.schema).value};`), x$1(r, this.schema);
	}
	get [kn$1]() {
		let t = this.schema;
		return new Proxy({
			[o$1]: !0,
			get [qe]() {
				return x$1(this, t);
			},
			[oe]: (r) => r.resolve(this),
			toString: () => `${this.toString()}.$`
		}, _t$1);
	}
	get $() {
		if (Oe$1()) return this[kn$1];
		throw new Error("Direct access to sampler values is possible only as part of a compute dispatch or draw call.");
	}
	get value() {
		return this.$;
	}
	$name(t) {
		return k(this, t), this;
	}
	toString() {
		return `${this.resourceType}:${D(this) ?? "<unnamed>"}`;
	}
};
var Yt = class {
	constructor(t, r) {
		this.schema = t;
		this.#e = r, k(this, r.key);
	}
	resourceType = "external-texture";
	[o$1] = !0;
	#e;
	[oe](t) {
		let r = t.getUniqueName(this);
		let n = t.allocateLayoutEntry(this.#e.layout);
		return t.addDeclaration(`@group(${n}) @binding(${this.#e.idx}) var ${r}: ${t.resolve(this.schema).value};`), x$1(r, _s());
	}
	get [kn$1]() {
		let t = this.schema;
		return new Proxy({
			[o$1]: !0,
			get [qe]() {
				return x$1(this, t);
			},
			[oe]: (r) => r.resolve(this),
			toString: () => `textureExternal:${D(this) ?? "<unnamed>"}.$`
		}, _t$1);
	}
	get $() {
		if (Oe$1()) return this[kn$1];
		throw new Error("Direct access to texture views values is possible only as part of a compute dispatch or draw call. Try .read() or .write() instead");
	}
	get value() {
		return this.$;
	}
	toString() {
		return `textureExternal:${D(this) ?? "<unnamed>"}`;
	}
};
function Jt(e) {
	let { videoWidth: t, videoHeight: r } = e;
	if (t && r) return {
		width: t,
		height: r
	};
	let { naturalWidth: n, naturalHeight: a } = e;
	if (n && a) return {
		width: n,
		height: a
	};
	let { codedWidth: o, codedHeight: s } = e;
	if (o && s) return {
		width: o,
		height: s
	};
	let { width: i, height: u } = e || HTMLCanvasElement || OffscreenCanvas || HTMLImageElement || ImageData;
	if (!i || !u) throw new Error("Cannot determine dimensions of the provided image source.");
	return {
		width: i,
		height: u
	};
}
var $r = /* @__PURE__ */ new WeakMap();
function ca(e) {
	let t = $r.get(e);
	return t || (t = /* @__PURE__ */ new Map(), $r.set(e, t)), t;
}
function ga(e) {
	let t = $r.get(e);
	t && t.clear();
}
function ya(e, t, r = 0, n) {
	if (t.dimension !== "2d") throw new Error("Cannot generate mipmaps for non-2D textures: only 2D textures are currently supported.");
	let a = n ?? t.mipLevelCount - r;
	let o = Oe(t.format, e);
	if (![...o.sampleTypes].some((i) => i === "float" || i === "unfilterable-float")) throw new Error(`Cannot generate mipmaps for format '${t.format}': only float and unfilterable-float formats are currently supported.`);
	if (!o.canRenderAttachment) throw new Error(`Cannot generate mipmaps for format '${t.format}': format does not support render attachments.`);
	for (let i = 0; i < t.depthOrArrayLayers; i++) for (let u = r; u < r + a - 1; u++) go(e, t, u, u + 1, i);
}
function Ta(e, t, r, n) {
	if (t.dimension === "3d") throw new Error("Cannot resample to 3D textures: only 2D textures are currently supported.");
	let a = L[t.format];
	if (![...a.sampleTypes].some((s) => s === "float" || s === "unfilterable-float")) throw new Error(`Cannot resample to format '${t.format}': only float and unfilterable-float formats are currently supported.`);
	if (!a.canRenderAttachment) throw new Error(`Cannot resample to format '${t.format}': format does not support render attachments.`);
	return co(e, t, r, n);
}
function co(e, t, r, n = 0) {
	let o = [...L[t.format].sampleTypes].includes("float");
	let s = `${o ? "filterable" : "unfilterable"}`;
	let i = ca(e);
	let u = i.get(s);
	if (!u) {
		let F = e.createShaderModule({ code: `
struct VertexOutput {
  @builtin(position) pos: vec4f,
  @location(0) uv: vec2f,
}

@vertex
fn vs_main(@builtin(vertex_index) vertexIndex: u32) -> VertexOutput {
  let pos = array<vec2f, 3>(vec2f(-1, -1), vec2f(3, -1), vec2f(-1, 3));
  let uv = array<vec2f, 3>(vec2f(0, 1), vec2f(2, 1), vec2f(0, -1));

  var output: VertexOutput;
  output.pos = vec4f(pos[vertexIndex], 0, 1);
  output.uv = uv[vertexIndex];
  return output;
}
      ` });
		let R = (globalThis.__TYPEGPU_AUTONAME__ ?? ((a) => a))(e.createSampler({
			magFilter: o ? "linear" : "nearest",
			minFilter: o ? "linear" : "nearest"
		}), "R");
		let Me = e.createBindGroupLayout({ entries: [{
			binding: 0,
			visibility: GPUShaderStage.FRAGMENT,
			texture: { sampleType: "float" }
		}, {
			binding: 1,
			visibility: GPUShaderStage.FRAGMENT,
			sampler: { type: o ? "filtering" : "non-filtering" }
		}] });
		let lr = e.createPipelineLayout({ bindGroupLayouts: [Me] });
		u = {
			vertexShader: F,
			fragmentShader: e.createShaderModule({ code: `
@group(0) @binding(0) var inputTexture: texture_2d<f32>;
@group(0) @binding(1) var inputSampler: sampler;

@fragment
fn fs_main(@location(0) uv: vec2f) -> @location(0) vec4f {
  ${o ? "return textureSample(inputTexture, inputSampler, uv);" : `let texelCoord = vec2u(uv * vec2f(textureDimensions(inputTexture)));
        return textureLoad(inputTexture, texelCoord, 0);`}
}
      ` }),
			bindGroupLayout: Me,
			pipelineLayout: lr,
			sampler: R
		}, i.set(s, u);
	}
	let l = (globalThis.__TYPEGPU_AUTONAME__ ?? ((a) => a))(e.createTexture({
		size: [...Object.values(Jt(r))],
		format: "rgba8unorm",
		usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.COPY_DST
	}), "l"), { width: m, height: y } = Jt(r);
	e.queue.copyExternalImageToTexture({ source: r }, { texture: l }, [
		m,
		y,
		1
	]);
	let f = (globalThis.__TYPEGPU_AUTONAME__ ?? ((a) => a))(e.createTexture({
		size: [
			t.width,
			t.height,
			1
		],
		format: t.format,
		usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.COPY_SRC
	}), "f");
	let T = e.createRenderPipeline({
		layout: u.pipelineLayout,
		vertex: { module: u.vertexShader },
		fragment: {
			module: u.fragmentShader,
			targets: [{ format: t.format }]
		},
		primitive: { topology: "triangle-list" }
	});
	let w = e.createBindGroup({
		layout: u.bindGroupLayout,
		entries: [{
			binding: 0,
			resource: l.createView()
		}, {
			binding: 1,
			resource: u.sampler
		}]
	});
	let x = e.createCommandEncoder();
	let P = x.beginRenderPass({ colorAttachments: [{
		view: f.createView(),
		loadOp: "clear",
		storeOp: "store"
	}] });
	P.setPipeline(T), P.setBindGroup(0, w), P.draw(3), P.end(), x.copyTextureToTexture({ texture: f }, {
		texture: t,
		origin: {
			x: 0,
			y: 0,
			z: n
		}
	}, {
		width: t.width,
		height: t.height,
		depthOrArrayLayers: 1
	}), e.queue.submit([x.finish()]), l.destroy(), f.destroy();
}
function go(e, t, r, n, a) {
	let s = [...Oe(t.format, e).sampleTypes].includes("float");
	let i = `${s ? "filterable" : "unfilterable"}`;
	let u = ca(e);
	let l = u.get(i);
	if (!l) {
		let P = e.createShaderModule({ code: `
struct VertexOutput {
  @builtin(position) pos: vec4f,
  @location(0) uv: vec2f,
}

@vertex
fn vs_main(@builtin(vertex_index) vertexIndex: u32) -> VertexOutput {
  let pos = array<vec2f, 3>(vec2f(-1, -1), vec2f(3, -1), vec2f(-1, 3));
  let uv = array<vec2f, 3>(vec2f(0, 1), vec2f(2, 1), vec2f(0, -1));

  var output: VertexOutput;
  output.pos = vec4f(pos[vertexIndex], 0, 1);
  output.uv = uv[vertexIndex];
  return output;
}
      ` });
		let F = e.createShaderModule({ code: `
@group(0) @binding(0) var inputTexture: texture_2d<f32>;
@group(0) @binding(1) var inputSampler: sampler;

@fragment
fn fs_main(@location(0) uv: vec2f) -> @location(0) vec4f {
  return textureSample(inputTexture, inputSampler, uv);
}
      ` });
		let R = (globalThis.__TYPEGPU_AUTONAME__ ?? ((a) => a))(e.createSampler({
			magFilter: s ? "linear" : "nearest",
			minFilter: s ? "linear" : "nearest"
		}), "R");
		let Me = e.createBindGroupLayout({ entries: [{
			binding: 0,
			visibility: GPUShaderStage.FRAGMENT,
			texture: { sampleType: s ? "float" : "unfilterable-float" }
		}, {
			binding: 1,
			visibility: GPUShaderStage.FRAGMENT,
			sampler: { type: s ? "filtering" : "non-filtering" }
		}] });
		l = {
			vertexShader: P,
			fragmentShader: F,
			bindGroupLayout: Me,
			pipelineLayout: e.createPipelineLayout({ bindGroupLayouts: [Me] }),
			sampler: R
		}, u.set(i, l);
	}
	let m = e.createRenderPipeline({
		layout: l.pipelineLayout,
		vertex: { module: l.vertexShader },
		fragment: {
			module: l.fragmentShader,
			targets: [{ format: t.format }]
		},
		primitive: { topology: "triangle-list" }
	});
	let y = t.createView({
		baseMipLevel: r,
		dimension: "2d",
		mipLevelCount: 1,
		...a !== void 0 && {
			baseArrayLayer: a,
			arrayLayerCount: 1
		}
	});
	let f = t.createView({
		baseMipLevel: n,
		dimension: "2d",
		mipLevelCount: 1,
		...a !== void 0 && {
			baseArrayLayer: a,
			arrayLayerCount: 1
		}
	});
	let T = e.createBindGroup({
		layout: l.bindGroupLayout,
		entries: [{
			binding: 0,
			resource: y
		}, {
			binding: 1,
			resource: l.sampler
		}]
	});
	let w = e.createCommandEncoder();
	let x = w.beginRenderPass({ colorAttachments: [{
		view: f,
		loadOp: "clear",
		storeOp: "store"
	}] });
	x.setPipeline(m), x.setBindGroup(0, T), x.draw(3), x.end(), e.queue.submit([w.finish()]);
}
function yo(e) {
	return {
		dimension: e.dimension ?? "2d",
		sampleType: L[e.format].channelType,
		multisampled: (e.sampleCount ?? 1) !== 1
	};
}
function To(e) {
	return e === "depth24plus-stencil8" || e === "depth32float-stencil8" ? ["depth", "stencil"] : e === "depth16unorm" || e === "depth24plus" || e === "depth32float" ? ["depth"] : e === "stencil8" ? ["stencil"] : ["color"];
}
function ha(e, t) {
	return new Lr(e, t);
}
function ee(e) {
	return e?.resourceType === "texture" && !!e[o$1];
}
function he(e) {
	return e?.resourceType === "texture-view" && !!e[o$1];
}
var Lr = class {
	constructor(t, r) {
		this.props = t;
		let n = t.format;
		this.#o = r, this.#e = L[n], this.#r = t.size[0] * (t.size[1] ?? 1) * (t.size[2] ?? 1) * this.#e.texelSize, this.aspects = To(n), this[o$1] = { unwrap: () => {
			if (this.#t) throw new Error("This texture has been destroyed");
			return this.#a || (this.#a = r.device.createTexture({
				label: D(this) ?? "<unnamed>",
				format: t.format,
				size: t.size,
				usage: this.#n,
				dimension: t.dimension ?? "2d",
				viewFormats: t.viewFormats ?? [],
				mipLevelCount: t.mipLevelCount ?? 1,
				sampleCount: t.sampleCount ?? 1
			})), this.#a;
		} };
	}
	[o$1];
	resourceType = "texture";
	aspects;
	usableAsSampled = !1;
	usableAsStorage = !1;
	usableAsRender = !1;
	#e;
	#r;
	#t = !1;
	#n = GPUTextureUsage.COPY_DST | GPUTextureUsage.COPY_SRC;
	#a = null;
	#o;
	$name(t) {
		return k(this, t), this;
	}
	$usage(...t) {
		let r = t.includes("storage");
		let n = t.includes("sampled");
		let a = t.includes("render");
		return this.#n |= n ? GPUTextureUsage.TEXTURE_BINDING : 0, this.#n |= r ? GPUTextureUsage.STORAGE_BINDING : 0, this.#n |= a ? GPUTextureUsage.RENDER_ATTACHMENT : 0, this.usableAsStorage ||= r, this.usableAsSampled ||= n, this.usableAsRender ||= a, this;
	}
	createView(t, r) {
		return new Rr(t ?? Vs(yo(this.props)), this, r);
	}
	#s(t = 0) {
		let r = 2 ** t, [n, a, o] = [
			Math.max(1, Math.floor((this.props.size[0] ?? 1) / r)),
			Math.max(1, Math.floor((this.props.size[1] ?? 1) / r)),
			Math.max(1, Math.floor((this.props.size[2] ?? 1) / r))
		];
		this.#o.device.queue.writeTexture({
			texture: this[o$1].unwrap(),
			mipLevel: t
		}, new Uint8Array(n * a * o * this.#e.texelSize), {
			bytesPerRow: this.#e.texelSize * n,
			rowsPerImage: a
		}, [
			n,
			a,
			o
		]);
	}
	clear(t = "all") {
		if (t === "all") {
			let r = this.props.mipLevelCount ?? 1;
			for (let n = 0; n < r; n++) this.#s(n);
		} else this.#s(t);
	}
	generateMipmaps(t = 0, r) {
		if (this.usableAsRender === !1) throw new Error("generateMipmaps called without specifying 'render' usage. Add it via the $usage('render') method.");
		let n = r ?? (this.props.mipLevelCount ?? 1) - t;
		if (n <= 1) {
			console.warn(`generateMipmaps is a no-op: would generate ${n} mip levels (base: ${t}, total: ${this.props.mipLevelCount ?? 1})`);
			return;
		}
		if (t >= (this.props.mipLevelCount ?? 1)) throw new Error(`Base mip level ${t} is out of range. Texture has ${this.props.mipLevelCount ?? 1} mip levels.`);
		ya(this.#o.device, this[o$1].unwrap(), t, n);
	}
	write(t, r = 0) {
		if (t instanceof ArrayBuffer || ArrayBuffer.isView(t)) {
			this.#u(t, r);
			return;
		}
		let n = this.props.dimension ?? "2d";
		if (!Array.isArray(t)) {
			this.#i(t, n === "3d" ? 0 : void 0);
			return;
		}
		let o = this.props.size[2] ?? 1;
		t.length > o && console.warn(`Too many image sources provided. Expected ${o} layers, got ${t.length}. Extra sources will be ignored.`);
		for (let s = 0; s < Math.min(t.length, o); s++) {
			let i = t[s];
			i && this.#i(i, s);
		}
	}
	#u(t, r) {
		let n = Math.max(1, this.props.size[0] >> r);
		let a = Math.max(1, (this.props.size[1] ?? 1) >> r);
		let o = Math.max(1, (this.props.size[2] ?? 1) >> r);
		let s = n * a * o * this.#e.texelSize;
		let i = t.byteLength ?? t.byteLength;
		if (i !== s) throw new Error(`Buffer size mismatch. Expected ${s} bytes for mip level ${r}, got ${i} bytes.`);
		this.#o.device.queue.writeTexture({
			texture: this[o$1].unwrap(),
			mipLevel: r
		}, t, {
			bytesPerRow: this.#e.texelSize * n,
			rowsPerImage: a
		}, [
			n,
			a,
			o
		]);
	}
	#i(t, r) {
		let n = this.props.size[0], a = this.props.size[1] ?? 1, { width: o, height: s } = Jt(t);
		if (o !== n || s !== a) {
			Ta(this.#o.device, this[o$1].unwrap(), t, r);
			return;
		}
		this.#o.device.queue.copyExternalImageToTexture({ source: t }, {
			texture: this[o$1].unwrap(),
			...r !== void 0 && { origin: {
				x: 0,
				y: 0,
				z: r
			} }
		}, r !== void 0 ? [
			n,
			a,
			1
		] : this.props.size);
	}
	copyFrom(t) {
		if (t.props.format !== this.props.format) throw new Error(`Texture format mismatch. Source texture has format ${t.props.format}, target texture has format ${this.props.format}`);
		if (t.props.size[0] !== this.props.size[0] || (t.props.size[1] ?? 1) !== (this.props.size[1] ?? 1) || (t.props.size[2] ?? 1) !== (this.props.size[2] ?? 1)) throw new Error(`Texture size mismatch. Source texture has size ${t.props.size.join("x")}, target texture has size ${this.props.size.join("x")}`);
		let r = this.#o.device.createCommandEncoder();
		r.copyTextureToTexture({ texture: t[o$1].unwrap() }, { texture: this[o$1].unwrap() }, t.props.size), this.#o.device.queue.submit([r.finish()]);
	}
	get destroyed() {
		return this.#t;
	}
	destroy() {
		this.#t || (this.#t = !0, this.#a?.destroy());
	}
};
var Rr = class {
	constructor(t, r, n) {
		this.schema = t;
		this.#e = r, this.#t = n, this[o$1] = { unwrap: () => {
			if (!this.#r) {
				let a = this.schema;
				let o;
				Ds(a) ? o = {
					label: D(this) ?? "<unnamed>",
					format: this.#t?.format ?? a.format,
					dimension: a.dimension
				} : o = {
					label: D(this) ?? "<unnamed>",
					format: this.#t?.format ?? this.#e.props.format,
					dimension: a.dimension
				}, this.#t?.mipLevelCount !== void 0 && (o.mipLevelCount = this.#t.mipLevelCount), this.#t?.arrayLayerCount !== void 0 && (o.arrayLayerCount = this.#t.arrayLayerCount), this.#r = this.#e[o$1].unwrap().createView(o);
			}
			return this.#r;
		} };
	}
	[o$1];
	resourceType = "texture-view";
	#e;
	#r;
	#t;
	$name(t) {
		return k(this, t), this.#r && (this.#r.label = t), this;
	}
	get [kn$1]() {
		let t = this.schema;
		return new Proxy({
			[o$1]: !0,
			get [qe]() {
				return x$1(this, t);
			},
			[oe]: (r) => r.resolve(this),
			toString: () => `${this.toString()}.$`
		}, _t$1);
	}
	get $() {
		if (Oe$1()) return this[kn$1];
		throw new Error("Direct access to texture view values is possible only as part of a compute dispatch or draw call. Try .read() or .write() instead");
	}
	get value() {
		return this.$;
	}
	toString() {
		return `textureView:${D(this) ?? "<unnamed>"}`;
	}
	[oe](t) {
		let r = t.getUniqueName(this), { group: n, binding: a } = t.allocateFixedEntry(Ds(this.schema) ? { storageTexture: this.schema } : {
			texture: this.schema,
			sampleType: this.#t?.sampleType ?? this.schema.bindingSampleType[0]
		}, this);
		return t.addDeclaration(`@group(${n}) @binding(${a}) var ${r}: ${t.resolve(this.schema).value};`), x$1(r, this.schema);
	}
};
var nt = class {
	constructor(t, r) {
		this.schema = t;
		this.#e = r, k(this, r.key);
	}
	[o$1] = { unwrap: void 0 };
	resourceType = "texture-view";
	#e;
	toString() {
		return `textureView:${D(this) ?? "<unnamed>"}`;
	}
	[oe](t) {
		let r = t.getUniqueName(this);
		let n = t.allocateLayoutEntry(this.#e.layout);
		return t.addDeclaration(`@group(${n}) @binding(${this.#e.idx}) var ${r}: ${t.resolve(this.schema).value};`), x$1(r, this.schema);
	}
	get [kn$1]() {
		let t = this.schema;
		return new Proxy({
			[o$1]: !0,
			get [qe]() {
				return x$1(this, t);
			},
			[oe]: (r) => r.resolve(this),
			toString: () => `${this.toString()}.$`
		}, _t$1);
	}
	get $() {
		if (Oe$1()) return this[kn$1];
		throw new Error("Direct access to texture views values is possible only as part of a compute dispatch or draw call. Try .read() or .write() instead");
	}
	get value() {
		return this.$;
	}
};
function Gr(e) {
	return !!e?.usableAsSampled;
}
var Xt = class e extends Error {
	constructor(t) {
		super(`Resource '${D(t) ?? "<unnamed>"}' cannot be bound as 'sampled'. Use .$usage('sampled') to allow it.`), Object.setPrototypeOf(this, e.prototype);
	}
};
function xo(e) {
	let t = {};
	for (let [r, n] of Object.entries(e)) {
		if (n === null) {
			t[r] = null;
			continue;
		}
		if ("texture" in n && typeof n.texture == "string") {
			let a = n.texture;
			t[r] = {
				...n,
				texture: Vs({
					dimension: n.viewDimension ?? "2d",
					sampleType: a === "sint" ? T$1 : a === "uint" ? c : h$1,
					multisampled: n.multisampled ?? !1
				})
			};
		} else if ("storageTexture" in n && typeof n.storageTexture == "string") {
			let a = {
				readonly: "read-only",
				writeonly: "write-only",
				mutable: "read-write"
			};
			t[r] = {
				...n,
				storageTexture: Vs({
					access: a[n.access ?? "writeonly"],
					format: n.storageTexture,
					dimension: n.viewDimension ?? "2d"
				})
			};
		} else "externalTexture" in n && Object.keys(n.externalTexture).length === 0 ? t[r] = {
			...n,
			externalTexture: {
				type: "texture_external",
				dimension: "2d"
			}
		} : t[r] = n;
	}
	return t;
}
function Zt(e) {
	return new Er(xo(e));
}
function er(e) {
	return !!e && e.resourceType === "bind-group-layout";
}
function xe(e) {
	return !!e && e.resourceType === "bind-group";
}
var Cr = class e extends Error {
	constructor(t, r) {
		super(`Bind group '${t ?? "<unnamed>"}' is missing a required binding '${r}'`), Object.setPrototypeOf(this, e.prototype);
	}
};
var xa = ["compute", "fragment"];
var at = [
	"compute",
	"vertex",
	"fragment"
];
var Er = class {
	constructor(t) {
		this.entries = t;
		let r = 0;
		for (let [n, a] of Object.entries(t)) {
			if (a === null) {
				r++;
				continue;
			}
			let o = {
				layout: this,
				key: n,
				idx: r
			};
			if ("uniform" in a && (this.bound[n] = new Ze("uniform", a.uniform, o)), "storage" in a) {
				let s = "type" in a.storage ? a.storage : a.storage(0);
				this.bound[n] = new Ze(a.access ?? "readonly", s, o);
			}
			"texture" in a && (this.bound[n] = new nt(a.texture, o)), "storageTexture" in a && (this.bound[n] = new nt(a.storageTexture, o)), "externalTexture" in a && (this.bound[n] = new Yt(a.externalTexture, o)), "sampler" in a && (this.bound[n] = new Ht(a.sampler === "comparison" ? Ss() : ws(), o)), Object.defineProperty(this.value, n, { get: () => this.bound[n].value }), r++;
		}
	}
	[o$1] = !0;
	_index;
	resourceType = "bind-group-layout";
	bound = {};
	value = {};
	$ = this.value;
	get [kn$1]() {
		return this.$;
	}
	toString() {
		return `bindGroupLayout:${D(this) ?? "<unnamed>"}`;
	}
	get index() {
		return this._index;
	}
	$name(t) {
		return k(this, t), this;
	}
	$idx(t) {
		return this._index = t, this;
	}
	unwrap(t) {
		return t.device.createBindGroupLayout({
			label: D(this) ?? "<unnamed>",
			entries: Object.values(this.entries).map((n, a) => {
				if (n === null) return null;
				let o = n.visibility;
				let s = {
					binding: a,
					visibility: 0
				};
				if ("uniform" in n) o = o ?? at, s.buffer = { type: "uniform" };
				else if ("storage" in n) o = o ?? (n.access === "mutable" ? xa : at), s.buffer = { type: n.access === "mutable" ? "storage" : "read-only-storage" };
				else if ("sampler" in n) o = o ?? at, s.sampler = { type: n.sampler };
				else if ("texture" in n) {
					o = o ?? at;
					let { multisampled: i, dimension: u, bindingSampleType: l } = n.texture;
					s.texture = {
						sampleType: n.sampleType ?? l[0],
						viewDimension: u,
						multisampled: i
					};
				} else if ("storageTexture" in n) {
					o = o ?? xa;
					let { dimension: i, access: u, format: l } = n.storageTexture;
					s.storageTexture = {
						access: u,
						format: l,
						viewDimension: i
					};
				} else "externalTexture" in n && (o = o ?? at, s.externalTexture = {});
				return o?.includes("compute") && (s.visibility |= GPUShaderStage.COMPUTE), o?.includes("vertex") && (s.visibility |= GPUShaderStage.VERTEX), o?.includes("fragment") && (s.visibility |= GPUShaderStage.FRAGMENT), s;
			}).filter((n) => n !== null)
		});
	}
};
var Ve = class {
	constructor(t, r) {
		this.layout = t;
		this.entries = r;
		for (let n of Object.keys(t.entries)) if (t.entries[n] !== null && !(n in r)) throw new Cr(D(t), n);
	}
	resourceType = "bind-group";
	unwrap(t) {
		return t.device.createBindGroup({
			label: D(this.layout) ?? "<unnamed>",
			layout: t.unwrap(this.layout),
			entries: Object.entries(this.layout.entries).map(([n, a], o) => {
				if (a === null) return null;
				let s = this.entries[n];
				if (s === void 0) throw new Error(`'${n}' is a resource required to populate bind group layout '${D(this.layout) ?? "<unnamed>"}'.`);
				if ("uniform" in a) {
					let i;
					if (le(s)) {
						if (!jt(s)) throw new pt$2(s);
						i = { buffer: t.unwrap(s) };
					} else i = { buffer: s };
					return {
						binding: o,
						resource: i
					};
				}
				if ("storage" in a) {
					let i;
					if (le(s)) {
						if (!Te(s)) throw new Je(s);
						i = { buffer: t.unwrap(s) };
					} else i = { buffer: s };
					return {
						binding: o,
						resource: i
					};
				}
				if ("texture" in a) {
					let i;
					if (ee(s)) {
						if (!Gr(s)) throw new Xt(s);
						i = t.unwrap(s.createView(a.texture));
					} else he(s) ? i = t.unwrap(s) : i = s;
					return {
						binding: o,
						resource: i
					};
				}
				if ("storageTexture" in a) {
					let i;
					if (ee(s)) {
						if (!Te(s)) throw new Je(s);
						i = t.unwrap(s.createView(a.storageTexture));
					} else he(s) ? i = t.unwrap(s) : i = s;
					return {
						binding: o,
						resource: i
					};
				}
				if ("sampler" in a) return rt(s) || tt(s) ? {
					binding: o,
					resource: t.unwrap(s)
				} : {
					binding: o,
					resource: s
				};
				if ("externalTexture" in a) return {
					binding: o,
					resource: s
				};
				throw new Error(`Malformed bind group entry: ${Pt$1(s)}`);
			}).filter((n) => n !== null)
		});
	}
};
function we(e) {
	return new Vr(e);
}
var Vr = class {
	constructor(t = void 0) {
		this.defaultValue = t;
	}
	[o$1] = !0;
	resourceType = "slot";
	$name(t) {
		return k(this, t), this;
	}
	areEqual(t, r) {
		return Object.is(t, r);
	}
	toString() {
		return `slot:${D(this) ?? "<unnamed>"}`;
	}
	get [kn$1]() {
		let t = zt$2();
		if (!t) throw new Error("Cannot access tgpu.slot's value outside of resolution.");
		return ys(t.unwrap(this));
	}
	get value() {
		return this[kn$1];
	}
	get $() {
		return this.value;
	}
};
function _e(e, t) {
	return new ot("private", e, t);
}
function _r(e) {
	return new ot("workgroup", e);
}
var ot = class {
	[o$1] = {};
	#e;
	#r;
	#t;
	constructor(t, r, n) {
		this.#e = t, this.#r = r, this.#t = n;
	}
	[oe](t) {
		let r = t.getUniqueName(this);
		let n = `var<${this.#e}> ${r}: ${t.resolve(this.#r).value}`;
		return this.#t ? t.addDeclaration(`${n} = ${t.resolve(this.#t, this.#r).value};`) : t.addDeclaration(`${n};`), x$1(r, this.#r);
	}
	$name(t) {
		return k(this, t), this;
	}
	toString() {
		return `var:${D(this) ?? "<unnamed>"}`;
	}
	get [kn$1]() {
		let t = this.#r;
		return new Proxy({
			[o$1]: !0,
			get [qe]() {
				return x$1(this, t);
			},
			[oe]: (r) => r.resolve(this),
			toString: () => `var:${D(this) ?? "<unnamed>"}.$`
		}, _t$1);
	}
	get $() {
		let t = Er$2();
		let r = Pr$2();
		if (t.type === "normal") throw new mt$1(r ? `Cannot access variable '${D(this) ?? "<unnamed>"}'. TypeGPU functions that depends on GPU resources need to be part of a compute dispatch, draw call or simulation` : "TypeGPU variables are inaccessible during normal JS execution. If you wanted to simulate GPU behavior, try `tgpu.simulate()`");
		return t.type === "codegen" ? this[kn$1] : t.type === "simulate" ? (t.vars[this.#e].has(this) || t.vars[this.#e].set(this, this.#t), t.vars[this.#e].get(this)) : St(t, "tgpuVariable.ts#TgpuVarImpl/$");
	}
	set $(t) {
		let r = Er$2();
		let n = Pr$2();
		if (r.type === "normal") throw new mt$1(n ? `Cannot access ${String(this)}. TypeGPU functions that depends on GPU resources need to be part of a compute dispatch, draw call or simulation` : "TypeGPU variables are inaccessible during normal JS execution. If you wanted to simulate GPU behavior, try `tgpu.simulate()`");
		if (r.type === "codegen") throw new Error("Unreachable tgpuVariable.ts#TgpuVarImpl/$");
		if (r.type === "simulate") {
			r.vars[this.#e].set(this, t);
			return;
		}
		St(r, "tgpuVariable.ts#TgpuVarImpl/$");
	}
	get value() {
		return this.$;
	}
	set value(t) {
		this.$ = t;
	}
};
var wa = _e(c, 0).$name("dataBlockIndex");
var ba = _e(c, 0).$name("dataByteIndex");
var Sa = we().$name("dataBuffer");
var bo = U([], c)`() {
  let i = dataByteIndex;
  dataByteIndex = dataByteIndex + 1u;
  return i;
}`.$uses({ dataByteIndex: ba }).$name("nextByteIndex");
var d = "dataBuffer[dataBlockIndex].serializedData[nextByteIndex()]";
var va = {
	f32: U([h$1])`(n) => {
  ${d} = bitcast<u32>(n);
}`,
	f16: U([$$3])`(n) => {
  ${d} = pack2x16float(vec2f(f32(n), 0.0));
}`,
	i32: U([T$1])`(n) => {
  ${d} = bitcast<u32>(n);
}`,
	u32: U([c])`(n) => {
  ${d} = n;
}`,
	bool: U([b$2])`(b) => {
  ${d} = u32(b);
}`,
	vec2f: U([B$1])`(v) => {
  ${d} = bitcast<u32>(v.x);
  ${d} = bitcast<u32>(v.y);
}`,
	vec3f: U([Le])`(v) => {
  ${d} = bitcast<u32>(v.x);
  ${d} = bitcast<u32>(v.y);
  ${d} = bitcast<u32>(v.z);
}`,
	vec4f: U([v])`(v) => {
  ${d} = bitcast<u32>(v.x);
  ${d} = bitcast<u32>(v.y);
  ${d} = bitcast<u32>(v.z);
  ${d} = bitcast<u32>(v.w);
}`,
	vec2h: U([hn$1])`(v) => {
  ${d} = pack2x16float(vec2f(f32(v.x), f32(v.y)));
}`,
	vec3h: U([dn$1])`(v) => {
  ${d} = pack2x16float(vec2f(f32(v.x), f32(v.y)));
  ${d} = pack2x16float(vec2f(f32(v.z), 0.0));
}`,
	vec4h: U([fn$1])`(v) => {
  ${d} = pack2x16float(vec2f(f32(v.x), f32(v.y)));
  ${d} = pack2x16float(vec2f(f32(v.z), f32(v.w)));
}`,
	vec2i: U([pe$3])`(v) => {
  ${d} = bitcast<u32>(v.x);
  ${d} = bitcast<u32>(v.y);
}`,
	vec3i: U([je])`(v) => {
  ${d} = bitcast<u32>(v.x);
  ${d} = bitcast<u32>(v.y);
  ${d} = bitcast<u32>(v.z);
}`,
	vec4i: U([xe$2])`(v) => {
  ${d} = bitcast<u32>(v.x);
  ${d} = bitcast<u32>(v.y);
  ${d} = bitcast<u32>(v.z);
  ${d} = bitcast<u32>(v.w);
}`,
	vec2u: U([he$3])`(v) => {
  ${d} = v.x;
  ${d} = v.y;
}`,
	vec3u: U([E])`(v) => {
  ${d} = v.x;
  ${d} = v.y;
  ${d} = v.z;
}`,
	vec4u: U([de$1])`(v) => {
  ${d} = v.x;
  ${d} = v.y;
  ${d} = v.z;
  ${d} = v.w;
}`,
	"vec2<bool>": U([xn$1])`(v) => {
  ${d} = u32(v.x);
  ${d} = u32(v.y);
}`,
	"vec3<bool>": U([mn$1])`(v) => {
  ${d} = u32(v.x);
  ${d} = u32(v.y);
  ${d} = u32(v.z);
}`,
	"vec4<bool>": U([wn$1])`(v) => {
  ${d} = u32(v.x);
  ${d} = u32(v.y);
  ${d} = u32(v.z);
  ${d} = u32(v.w);
}`,
	mat2x2f: U([ie$1])`(m) => {
  ${d} = bitcast<u32>(m[0][0]);
  ${d} = bitcast<u32>(m[0][1]);
  ${d} = bitcast<u32>(m[1][0]);
  ${d} = bitcast<u32>(m[1][1]);
}`,
	mat3x3f: U([le$1])`(m) => {
  ${d} = bitcast<u32>(m[0][0]);
  ${d} = bitcast<u32>(m[0][1]);
  ${d} = bitcast<u32>(m[0][2]);
  ${d} = 0u;
  ${d} = bitcast<u32>(m[1][0]);
  ${d} = bitcast<u32>(m[1][1]);
  ${d} = bitcast<u32>(m[1][2]);
  ${d} = 0u;
  ${d} = bitcast<u32>(m[2][0]);
  ${d} = bitcast<u32>(m[2][1]);
  ${d} = bitcast<u32>(m[2][2]);
  ${d} = 0u;
}`,
	mat4x4f: U([A$1])`(m) => {
  ${d} = bitcast<u32>(m[0][0]);
  ${d} = bitcast<u32>(m[0][1]);
  ${d} = bitcast<u32>(m[0][2]);
  ${d} = bitcast<u32>(m[0][3]);
  ${d} = bitcast<u32>(m[1][0]);
  ${d} = bitcast<u32>(m[1][1]);
  ${d} = bitcast<u32>(m[1][2]);
  ${d} = bitcast<u32>(m[1][3]);
  ${d} = bitcast<u32>(m[2][0]);
  ${d} = bitcast<u32>(m[2][1]);
  ${d} = bitcast<u32>(m[2][2]);
  ${d} = bitcast<u32>(m[2][3]);
  ${d} = bitcast<u32>(m[3][0]);
  ${d} = bitcast<u32>(m[3][1]);
  ${d} = bitcast<u32>(m[3][2]);
  ${d} = bitcast<u32>(m[3][3]);
}`
};
for (let [e, t] of Object.entries(va)) t.$name(`serialize${e[0].toLocaleUpperCase()}${e.slice(1)}`).$uses({
	dataBlockIndex: wa,
	nextByteIndex: bo,
	dataBuffer: Sa
});
function Ia(e) {
	return `(${e.map((t, r) => `_arg_${r}`).join(", ")})`;
}
function Ua(e, t) {
	let r = va[e.type];
	if (r) return r.with(Sa, t);
	if (we$3(e)) {
		let n = Object.keys(e.propTypes);
		let o = Fa(Object.values(e.propTypes), t);
		return U([e])`(arg) {\n  propsSerializer(${n.map((s) => `arg.${s}`).join(", ")});\n}`.$uses({ propsSerializer: o }).$name(`${D(e) ?? "struct"}Serializer`);
	}
	if (fe$2(e)) {
		let n = e.elementType;
		let a = e.elementCount;
		let o = Ua(n, t);
		return U([e])`(arg) {\n${Array.from({ length: a }, (s, i) => `  elementSerializer(arg[${i}]);`).join(`
`)}\n}`.$uses({ elementSerializer: o }).$name("arraySerializer");
	}
	throw new Error(`Cannot serialize data of type ${e.type}`);
}
function Fa(e, t) {
	let r = {};
	return U(e)`${Ia(e)} {\n${e.map((s, i) => (r[`serializer${i}`] = Ua(s, t), `  serializer${i}(_arg_${i});`)).join(`
`)}\n}`.$uses(r).$name("compoundSerializer");
}
function Pa(e, t, r, n, a) {
	let o = t.map(z).reduce((u, l) => u + l, 0);
	if (o > a.logSizeLimit) throw new Error(`Logged data needs to fit in ${a.logSizeLimit} bytes (one of the logs requires ${o} bytes). Consider increasing the limit by passing appropriate options to tgpu.init().`);
	let s = Fa(t, r).$name(`log${e}serializer`);
	let i = Ia(t);
	return U(t)`${i} {
  dataBlockIndex = atomicAdd(&indexBuffer, 1);
  if (dataBlockIndex >= ${a.logCountLimit}) {
    return;
  }
  dataBuffer[dataBlockIndex].id = ${e};
  dataByteIndex = 0;

  compoundSerializer${i};
}`.$uses({
		indexBuffer: n,
		dataBuffer: r,
		dataBlockIndex: wa,
		dataByteIndex: ba,
		compoundSerializer: s
	}).$name(`log${e}`);
}
var Da = [
	"log",
	"debug",
	"info",
	"warn",
	"error",
	"clear"
];
var So = {
	logCountLimit: 64,
	logSizeLimit: 252,
	messagePrefix: " GPU "
};
var Ba = x$1("/* console.log() */", Mn$1);
var tr = class {
	get logResources() {}
	generateLog() {
		return console.warn("'console.log' is currently only supported in compute pipelines."), Ba;
	}
};
var rr = class {
	#e;
	#r;
	#t = 1;
	#n;
	#a;
	constructor(t) {
		this.#e = {
			...So,
			...t[o$1].logOptions
		}, this.#r = /* @__PURE__ */ new Map();
		let r = qs({
			id: c,
			serializedData: Ye$2(c, Math.ceil(this.#e.logSizeLimit / 4))
		}).$name("SerializedLogData");
		this.#a = t.createMutable(Ye$2(r, this.#e.logCountLimit)).$name("dataBuffer"), this.#n = t.createMutable(Gs(c)).$name("indexBuffer");
	}
	generateLog(t, r, n) {
		if (!Da.includes(r)) return console.warn(`Unsupported log method '${r}' was used in TGSL.`), Ba;
		let a = os(n);
		let o = this.#t++;
		let s = a.filter((l) => l.dataType !== ut$1);
		let i = Pa(o, s.map((l) => l.dataType), this.#a, this.#n, this.#e);
		let u = a.map((l) => l.dataType === ut$1 ? l.value : l.dataType);
		return this.#r.set(o, {
			op: r,
			argTypes: u
		}), x$1(d$2`${t.resolve(i).value}(${s})`, Mn$1);
	}
	get logResources() {
		return this.#t === 1 ? void 0 : {
			dataBuffer: this.#a,
			indexBuffer: this.#n,
			options: this.#e,
			logIdToMeta: this.#r
		};
	}
};
var Aa = "#CATCHALL#";
var Mr = class {
	_stack = [];
	_itemDepth = 0;
	get itemDepth() {
		return this._itemDepth;
	}
	get topItem() {
		let t = this._stack[this._stack.length - 1];
		if (!t || t.type !== "item") throw new Error("Internal error, expected item layer to be on top.");
		return t;
	}
	get topFunctionScope() {
		return this._stack.findLast((t) => t.type === "functionScope");
	}
	pushItem() {
		this._itemDepth++, this._stack.push({
			type: "item",
			usedSlots: /* @__PURE__ */ new Set()
		});
	}
	popItem() {
		this.pop("item");
	}
	pushSlotBindings(t) {
		this._stack.push({
			type: "slotBinding",
			bindingMap: new WeakMap(t)
		});
	}
	popSlotBindings() {
		this.pop("slotBinding");
	}
	pushFunctionScope(t, r, n, a) {
		let o = {
			type: "functionScope",
			args: t,
			argAliases: r,
			returnType: n,
			externalMap: a,
			reportedReturnTypes: /* @__PURE__ */ new Set()
		};
		return this._stack.push(o), o;
	}
	popFunctionScope() {
		this.pop("functionScope");
	}
	pushBlockScope() {
		this._stack.push({
			type: "blockScope",
			declarations: /* @__PURE__ */ new Map()
		});
	}
	popBlockScope() {
		this.pop("blockScope");
	}
	pop(t) {
		let r = this._stack[this._stack.length - 1];
		if (!r || t && r.type !== t) throw new Error(`Internal error, expected a ${t} layer to be on top.`);
		this._stack.pop(), t === "item" && this._itemDepth--;
	}
	readSlot(t) {
		for (let r = this._stack.length - 1; r >= 0; --r) {
			let n = this._stack[r];
			if (n?.type === "item") n.usedSlots.add(t);
			else if (n?.type === "slotBinding") {
				let a = n.bindingMap.get(t);
				if (a !== void 0) return a;
			} else if (!(n?.type === "functionScope" || n?.type === "blockScope")) throw new Error("Unknown layer type.");
		}
		return t.defaultValue;
	}
	getSnippetById(t) {
		for (let r = this._stack.length - 1; r >= 0; --r) {
			let n = this._stack[r];
			if (n?.type === "functionScope") {
				let a = n.args.find((s) => s.value === t);
				if (a !== void 0) return a;
				if (n.argAliases[t]) return n.argAliases[t];
				let o = n.externalMap[t];
				return o != null ? Tt(o) : void 0;
			}
			if (n?.type === "blockScope") {
				let a = n.declarations.get(t);
				if (a !== void 0) return a;
			}
		}
	}
	defineBlockVariable(t, r) {
		if (r.dataType.type === "unknown") throw Error(`Tried to define variable '${t}' of unknown type`);
		for (let n = this._stack.length - 1; n >= 0; --n) {
			let a = this._stack[n];
			if (a?.type === "blockScope") {
				a.declarations.set(t, r);
				return;
			}
		}
		throw new Error("No block scope found to define a variable in.");
	}
};
var nr = [
	"",
	"  ",
	"    ",
	"      ",
	"        ",
	"          ",
	"            ",
	"              ",
	"                "
];
var Wr = nr.length - 1;
var kr = class {
	identLevel = 0;
	get pre() {
		return nr[this.identLevel] ?? nr[Wr].repeat(this.identLevel / Wr) + nr[this.identLevel % Wr];
	}
	indent() {
		let t = this.pre;
		return this.identLevel++, t;
	}
	dedent() {
		return this.identLevel--, this.pre;
	}
	withResetLevel(t) {
		let r = this.identLevel;
		this.identLevel = 0;
		try {
			return t();
		} finally {
			this.identLevel = r;
		}
	}
};
var st = class {
	#e;
	#r;
	_indentController = new kr();
	_itemStateStack = new Mr();
	#t = [];
	_declarations = [];
	_varyingLocations;
	#n = /* @__PURE__ */ new WeakSet();
	#a;
	get varyingLocations() {
		return this._varyingLocations;
	}
	[o$1] = { itemStateStack: this._itemStateStack };
	bindGroupLayoutsToPlaceholderMap = /* @__PURE__ */ new Map();
	_nextFreeLayoutPlaceholderIdx = 0;
	fixedBindings = [];
	enableExtensions;
	expectedType;
	constructor(t) {
		this.enableExtensions = t.enableExtensions, this.#r = t.shaderGenerator ?? Bo$1, this.#a = t.root ? new rr(t.root) : new tr(), this.#e = t.namespace[o$1];
	}
	getUniqueName(t) {
		return Zn(this.#e, t);
	}
	makeNameValid(t) {
		return this.#e.nameRegistry.makeValid(t);
	}
	get pre() {
		return this._indentController.pre;
	}
	get topFunctionReturnType() {
		let t = this._itemStateStack.topFunctionScope;
		return Ve$3(t, "Internal error, expected function scope to be present."), t.returnType;
	}
	get shelllessRepo() {
		return this.#e.shelllessRepo;
	}
	indent() {
		return this._indentController.indent();
	}
	dedent() {
		return this._indentController.dedent();
	}
	withResetIndentLevel(t) {
		return this._indentController.withResetLevel(t);
	}
	getById(t) {
		let r = this._itemStateStack.getSnippetById(t);
		return r === void 0 ? null : r;
	}
	defineVariable(t, r) {
		this._itemStateStack.defineBlockVariable(t, r);
	}
	reportReturnType(t) {
		let r = this._itemStateStack.topFunctionScope;
		Ve$3(r, "Internal error, expected function scope to be present."), r.reportedReturnTypes.add(t);
	}
	pushBlockScope() {
		this._itemStateStack.pushBlockScope();
	}
	popBlockScope() {
		this._itemStateStack.popBlockScope();
	}
	generateLog(t, r) {
		return this.#a.generateLog(this, t, r);
	}
	get logResources() {
		return this.#a.logResources;
	}
	fnToWgsl(t) {
		let r = this._itemStateStack.pushFunctionScope(t.args, t.argAliases, t.returnType, t.externalMap);
		try {
			this.#r.initGenerator(this);
			let n = this.#r.functionDefinition(t.body);
			let a = t.returnType;
			if (!a) {
				let o = [...r.reportedReturnTypes];
				if (o.length === 0) a = Mn$1;
				else {
					let s = _t$2(o);
					s && !s.hasImplicitConversions && (a = s.targetType);
				}
				if (!a) throw new Error(`Expected function to have a single return type, got [${o.join(", ")}]. Cast explicitly to the desired type.`);
				a = yt(a);
			}
			return {
				head: vo(this, t.args, a),
				body: n,
				returnType: a
			};
		} finally {
			this._itemStateStack.popFunctionScope();
		}
	}
	addDeclaration(t) {
		this._declarations.push(t);
	}
	allocateLayoutEntry(t) {
		let r = this.bindGroupLayoutsToPlaceholderMap;
		let n = r.get(t);
		return n || (n = `#BIND_GROUP_LAYOUT_${this._nextFreeLayoutPlaceholderIdx++}#`, r.set(t, n)), n;
	}
	allocateFixedEntry(t, r) {
		let n = this.fixedBindings.length;
		return this.fixedBindings.push({
			layoutEntry: t,
			resource: r
		}), {
			group: Aa,
			binding: n
		};
	}
	readSlot(t) {
		let r = this._itemStateStack.readSlot(t);
		if (r === void 0) throw new lt$1(t);
		return r;
	}
	withSlots(t, r) {
		this._itemStateStack.pushSlotBindings(t);
		try {
			return r();
		} finally {
			this._itemStateStack.popSlotBindings();
		}
	}
	withVaryingLocations(t, r) {
		this._varyingLocations = t;
		try {
			return r();
		} finally {
			this._varyingLocations = void 0;
		}
	}
	unwrap(t) {
		if (gt$1(t)) return this.withSlots(t[He].pairs, () => this.unwrap(t[He].inner));
		let r = t;
		for (;;) if (wt(r)) r = this.readSlot(r);
		else if (Tt$1(r)) r = this._getOrCompute(r);
		else break;
		return r;
	}
	_getOrCompute(t) {
		let r = this.#e.memoizedDerived.get(t) ?? [];
		this._itemStateStack.pushItem();
		try {
			for (let o of r) if ([...o.slotToValueMap.entries()].every(([i, u]) => i.areEqual(this._itemStateStack.readSlot(i), u))) return o.result;
			this.pushMode(new Se$2());
			let n;
			try {
				n = t["~compute"]();
			} finally {
				this.popMode("normal");
			}
			let a = /* @__PURE__ */ new Map();
			for (let o of this._itemStateStack.topItem.usedSlots) a.set(o, this._itemStateStack.readSlot(o));
			return r.push({
				slotToValueMap: a,
				result: n
			}), this.#e.memoizedDerived.set(t, r), n;
		} catch (n) {
			throw n instanceof ct ? n.appendToTrace(t) : new ct(n, [t]);
		} finally {
			this._itemStateStack.popItem();
		}
	}
	_getOrInstantiate(t) {
		let r = this.#e.memoizedResolves.get(t) ?? [];
		this._itemStateStack.pushItem();
		try {
			for (let o of r) if ([...o.slotToValueMap.entries()].every(([i, u]) => i.areEqual(this._itemStateStack.readSlot(i), u))) return o.result;
			let n;
			if (ar$2(t)) n = x$1(Pr(this, t), Mn$1);
			else if (Tt$1(t) || wt(t)) n = this.resolve(this.unwrap(t));
			else if (Jt$1(t)) n = t[oe](this);
			else if (tt$2(t)) {
				let o = this.#e.shelllessRepo.get(t, void 0);
				if (!o) throw new Error(`Couldn't resolve ${t.name}. Make sure it's a function that accepts no arguments, or call it from another TypeGPU function.`);
				return this.withResetIndentLevel(() => this.resolve(o));
			} else throw new TypeError(`Unresolvable internal value: ${Pt$1(t)}`);
			let a = /* @__PURE__ */ new Map();
			for (let o of this._itemStateStack.topItem.usedSlots) a.set(o, this._itemStateStack.readSlot(o));
			return r.push({
				slotToValueMap: a,
				result: n
			}), this.#e.memoizedResolves.set(t, r), n;
		} catch (n) {
			throw n instanceof ct ? n.appendToTrace(t) : new ct(n, [t]);
		} finally {
			this._itemStateStack.popItem();
		}
	}
	resolve(t, r) {
		if (Ke(t) || tt$2(t)) {
			if (this.#n.has(t) && !this.#e.memoizedResolves.has(t)) throw new Error(`Recursive function ${t} detected. Recursion is not allowed on the GPU.`);
			this.#n.add(t);
		}
		if (gt$1(t)) return this.withSlots(t[He].pairs, () => this.resolve(t[He].inner, r));
		if (u(t) || tt$2(t)) {
			if (this._itemStateStack.itemDepth === 0) try {
				this.pushMode(new vt$1());
				let n = Br$2(this, () => this._getOrInstantiate(t));
				return x$1(`${[...this._declarations].join(`

`)}${n.value}`, Mn$1);
			} finally {
				this.popMode("codegen");
			}
			return this._getOrInstantiate(t);
		}
		if (typeof t == "number") {
			let n = r ?? pt$1(t).dataType;
			if (Ve$3(n.type !== "unknown", "Schema has to be known for resolving numbers"), n.type === "abstractInt") return x$1(`${t}`, n);
			if (n.type === "u32") return x$1(`${t}u`, n);
			if (n.type === "i32") return x$1(`${t}i`, n);
			let a = t.toExponential();
			let o = n.type === "abstractFloat" && Number.isInteger(t) ? `${t}.` : `${t}`;
			let s = a.length < o.length ? a : o;
			return n.type === "f32" ? x$1(`${s}f`, n) : n.type === "f16" ? x$1(`${s}h`, n) : x$1(s, n);
		}
		if (typeof t == "boolean") return x$1(t ? "true" : "false", b$2);
		if (typeof t == "string") return x$1(t, Mn$1);
		if (r && fe$2(r)) {
			if (!Array.isArray(t)) throw new be$2(`Cannot coerce ${t} into value of type '${r}'`);
			if (r.elementCount !== t.length) throw new be$2(`Cannot create value of type '${r}' from an array of length: ${t.length}`);
			return x$1(d$2`array<${this.resolve(r.elementType)}, ${r.elementCount}>(${t.map((a) => x$1(a, r.elementType))})`, r);
		}
		if (Array.isArray(t)) return x$1(d$2`array(${t.map((n) => this.resolve(n))})`, ut$1);
		if (r && we$3(r)) return x$1(d$2`${this.resolve(r)}(${Object.entries(r.propTypes).map(([n, a]) => x$1(t[n], a))})`, r);
		throw new be$2(`Value ${t} (as json: ${Pt$1(t)}) is not resolvable${r ? ` to type ${r.type}` : ""}`);
	}
	pushMode(t) {
		this.#t.push(t);
	}
	popMode(t) {
		let r = this.#t.pop();
		t !== void 0 && Ve$3(r?.type === t, "Unexpected mode");
	}
	get mode() {
		return this.#t[this.#t.length - 1] ?? Xt$1;
	}
};
function me(e, t) {
	let r = new st(t);
	let a = (t.config ? r.withSlots(t.config(new Ge([])).bindings, () => r.resolve(e)) : r.resolve(e)).value;
	let o = r.bindGroupLayoutsToPlaceholderMap;
	let s = [];
	let u = ta(new Set([...o.keys()].map((f) => f.index).filter((f) => f !== void 0)));
	let l = r.fixedBindings.map((f, T) => [String(T), f.layoutEntry]);
	let m = () => {
		let f = u.next().value;
		let T = Zt(Object.fromEntries(l));
		return s[f] = T, a = a.replaceAll(Aa, String(f)), [f, new Ve(T, Object.fromEntries(r.fixedBindings.map((w, x) => [String(x), w.resource])))];
	};
	let y = l.length > 0 ? m() : void 0;
	for (let [f, T] of o.entries()) {
		let w = f.index ?? u.next().value;
		s[w] = f, a = a.replaceAll(T, String(w));
	}
	return t.enableExtensions && t.enableExtensions.length > 0 && (a = `${t.enableExtensions.map((T) => `enable ${T};`).join(`
`)}

${a}`), {
		code: a,
		usedBindGroupLayouts: s,
		catchall: y,
		logResources: r.logResources
	};
}
function vo(e, t, r) {
	let n = t.map((a) => `${a.value}: ${e.resolve(a.dataType).value}`).join(", ");
	return r.type !== "void" ? `(${n}) -> ${Ms$1(r)}${e.resolve(r).value} ` : `(${n}) `;
}
function Or(e) {
	let t = e;
	return t?.resourceType === "compute-pipeline" && !!t[o$1];
}
function zr(e) {
	let t = e;
	return t?.resourceType === "render-pipeline" && !!t[o$1];
}
function $a(e) {
	return zr(e) || Or(e);
}
function Nr(e) {
	let { externals: t, shaderGenerator: r, template: n, names: a = "random", config: o, enableExtensions: s } = e, i = {};
	S$1(i, t ?? {});
	let u = {
		[o$1]: !0,
		[oe](m) {
			return x$1(R(m, i, n ?? ""), Mn$1);
		},
		toString: () => "<root>"
	};
	let l = Object.values(t).filter($a);
	if (l.length > 1) throw new Error(`Found ${l.length} pipelines but can only resolve one at a time.`);
	return me(u, {
		namespace: typeof a == "string" ? Q({ names: a }) : a,
		enableExtensions: s,
		shaderGenerator: r,
		config: o,
		root: l[0]?.[o$1].branch
	});
}
function La(e) {
	return Nr(e).code;
}
function Ra(e) {
	let t = zt$2() ?? new st({
		namespace: Q(),
		shaderGenerator: Bo$1
	});
	let r = [
		1,
		1,
		1
	];
	let n = [
		1,
		1,
		1
	];
	let a = [
		r[0] * n[0],
		r[1] * n[1],
		r[2] * n[2]
	];
	let o = /* @__PURE__ */ new Map();
	let s = Array.from({ length: r[0] }, () => Array.from({ length: r[1] }, () => Array.from({ length: r[2] }, () => /* @__PURE__ */ new Map())));
	let i = Array.from({ length: a[0] }, () => Array.from({ length: a[1] }, () => Array.from({ length: a[2] }, () => /* @__PURE__ */ new Map())));
	let u = Array.from({ length: a[0] }, (l, m) => Array.from({ length: a[1] }, (y, f) => Array.from({ length: a[2] }, (T, w) => {
		let x = Math.floor(m / n[0]);
		let P = Math.floor(f / n[1]);
		let F = Math.floor(w / n[2]);
		return new bt(o, {
			private: i[m][f][w],
			workgroup: s[x][P][F]
		});
	})));
	t.pushMode(u[0][0][0]);
	try {
		return {
			value: Br$2(t, e),
			buffers: o,
			privateVars: i,
			workgroupVars: s
		};
	} finally {
		t.popMode("simulate");
	}
}
function Ga(e, t, r, n) {
	return new qr(e, t, r, n);
}
function it(e) {
	let t = e;
	return t?.resourceType === "query-set" && !!t[o$1];
}
var qr = class {
	constructor(t, r, n, a) {
		this.type = r;
		this.count = n;
		this.rawQuerySet = a;
		this.#e = t.device, this._ownQuerySet = !a, this._querySet = a || null;
	}
	resourceType = "query-set";
	#e;
	_querySet = null;
	_ownQuerySet;
	_destroyed = !1;
	_available = !0;
	_readBuffer = null;
	_resolveBuffer = null;
	get querySet() {
		if (this._destroyed) throw new Error("This QuerySet has been destroyed.");
		return this.rawQuerySet ? this.rawQuerySet : this._querySet ? this._querySet : (this._querySet = this.#e.createQuerySet({
			type: this.type,
			count: this.count
		}), this._querySet);
	}
	get destroyed() {
		return this._destroyed;
	}
	get available() {
		return this._available;
	}
	get [o$1]() {
		let t = this;
		return {
			get readBuffer() {
				return t._readBuffer || (t._readBuffer = t.#e.createBuffer({
					size: t.count * BigUint64Array.BYTES_PER_ELEMENT,
					usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ
				})), t._readBuffer;
			},
			get resolveBuffer() {
				return t._resolveBuffer || (t._resolveBuffer = t.#e.createBuffer({
					size: t.count * BigUint64Array.BYTES_PER_ELEMENT,
					usage: GPUBufferUsage.QUERY_RESOLVE | GPUBufferUsage.COPY_SRC
				})), t._resolveBuffer;
			}
		};
	}
	$name(t) {
		return k(this, t), this._querySet && (this._querySet.label = t), this;
	}
	resolve() {
		if (this._destroyed) throw new Error("This QuerySet has been destroyed.");
		if (!this._available) throw new Error("This QuerySet is busy resolving or reading.");
		let t = this.#e.createCommandEncoder();
		t.resolveQuerySet(this.querySet, 0, this.count, this[o$1].resolveBuffer, 0), this.#e.queue.submit([t.finish()]);
	}
	async read() {
		if (!this._resolveBuffer) throw new Error("QuerySet must be resolved before reading.");
		this._available = !1;
		try {
			let t = this.#e.createCommandEncoder();
			t.copyBufferToBuffer(this[o$1].resolveBuffer, 0, this[o$1].readBuffer, 0, this.count * BigUint64Array.BYTES_PER_ELEMENT), this.#e.queue.submit([t.finish()]);
			let r = this[o$1].readBuffer;
			await r.mapAsync(GPUMapMode.READ);
			let n = new BigUint64Array(r.getMappedRange().slice());
			return r.unmap(), Array.from(n);
		} finally {
			this._available = !0;
		}
	}
	destroy() {
		this._destroyed || (this._destroyed = !0, this._querySet && this._ownQuerySet && this._querySet.destroy(), this._readBuffer?.destroy(), this._resolveBuffer?.destroy(), this._readBuffer = this._resolveBuffer = null);
	}
};
var ut = class {
	constructor(t) {
		this._make = t;
	}
	_map = /* @__PURE__ */ new WeakMap();
	getOrMake(t, ...r) {
		if (this._map.has(t)) return this._map.get(t);
		let n = this._make(t, ...r);
		return this._map.set(t, n), n;
	}
};
var be = class {
	constructor(t, r) {
		this.resourceType = t;
		this.buffer = r;
		this[me$3] = r, this.#e = this.buffer.as(this.resourceType);
	}
	[o$1] = !0;
	[me$3];
	#e;
	$name(t) {
		return k(this[me$3], t), this;
	}
	write(t) {
		this.buffer.write(t);
	}
	writePartial(t) {
		this.buffer.writePartial(t);
	}
	read() {
		return this.buffer.read();
	}
	get [kn$1]() {
		return this.#e.$;
	}
	get $() {
		return this.#e.$;
	}
	get value() {
		return this.$;
	}
	[oe](t) {
		return t.resolve(this.#e);
	}
};
var b = (e) => ae(e ?? 0);
var H = (e) => ne(e ?? 0);
var We = (e) => ie(e ?? 0);
var Uo = {
	f32: (e) => b(e[0]),
	f16: (e) => We(e[0]).x,
	i32: (e) => H(e[0]),
	u32: (e) => e[0] ?? 0,
	bool: (e) => !!e[0],
	vec2f: (e) => B$1(b(e[0]), b(e[1])),
	vec3f: (e) => Le(b(e[0]), b(e[1]), b(e[2])),
	vec4f: (e) => v(b(e[0]), b(e[1]), b(e[2]), b(e[3])),
	vec2h(e) {
		let t = We(e[0]);
		return hn$1(t.x, t.y);
	},
	vec3h(e) {
		let t = We(e[0]);
		let r = We(e[1]);
		return dn$1(t.x, t.y, r.x);
	},
	vec4h(e) {
		let t = We(e[0]);
		let r = We(e[1]);
		return fn$1(t.x, t.y, r.x, r.y);
	},
	vec2i: (e) => pe$3(H(e[0]), H(e[1])),
	vec3i: (e) => je(H(e[0]), H(e[1]), H(e[2])),
	vec4i: (e) => xe$2(H(e[0]), H(e[1]), H(e[2]), H(e[3])),
	vec2u: (e) => he$3(e[0] ?? 0, e[1] ?? 0),
	vec3u: (e) => E(e[0] ?? 0, e[1] ?? 0, e[2] ?? 0),
	vec4u: (e) => de$1(e[0] ?? 0, e[1] ?? 0, e[2] ?? 0, e[3] ?? 0),
	"vec2<bool>": (e) => xn$1(!!e[0], !!e[1]),
	"vec3<bool>": (e) => mn$1(!!e[0], !!e[1], !!e[2]),
	"vec4<bool>": (e) => wn$1(!!e[0], !!e[1], !!e[2], !!e[3]),
	mat2x2f: (e) => ie$1(b(e[0]), b(e[1]), b(e[2]), b(e[3])),
	mat3x3f: (e) => le$1(b(e[0]), b(e[1]), b(e[2]), b(e[4]), b(e[5]), b(e[6]), b(e[8]), b(e[9]), b(e[10])),
	mat4x4f: (e) => A$1(b(e[0]), b(e[1]), b(e[2]), b(e[3]), b(e[4]), b(e[5]), b(e[6]), b(e[7]), b(e[8]), b(e[9]), b(e[10]), b(e[11]), b(e[12]), b(e[13]), b(e[14]), b(e[15]))
};
function Fo(e, t) {
	let r = Uo[t.type];
	if (r) return r(e);
	if (we$3(t)) {
		let n = Object.keys(t.propTypes);
		let o = jr(e, Object.values(t.propTypes));
		return Object.fromEntries(n.map((s, i) => [s, o[i]]));
	}
	if (fe$2(t)) {
		let n = t.elementType;
		let a = t.elementCount;
		return jr(e, Array.from({ length: a }, () => n));
	}
	throw new Error(`Cannot deserialize data of type ${t.type}`);
}
function jr(e, t) {
	let r = 0;
	return t.map((n) => {
		if (!C(n)) return n;
		let a = Math.ceil(z(n) / 4);
		let o = Fo(e.subarray(r, r + a), n);
		return r += a, o;
	});
}
function Po(e, t) {
	return jr(e, t).map(Ft$1);
}
function pt(e) {
	let { indexBuffer: t, dataBuffer: r, logIdToMeta: n, options: a } = e;
	r.read().then((o) => {
		o.filter((s) => s.id).forEach(({ id: s, serializedData: i }) => {
			let { argTypes: u, op: l } = n.get(s), m = Po(new Uint32Array(i), u);
			m.length === 0 && m.push(""), console[l](`%c${a.messagePrefix}%c ${m[0]}`, "background: #936ff5; color: white;", "color: inherit; background: none", ...m.slice(1));
		});
	}), t.read().then((o) => {
		o > a.logCountLimit && console.warn(`Log count limit per dispatch (${a.logCountLimit}) exceeded by ${o - a.logCountLimit} calls. Consider increasing the limit by passing appropriate options to tgpu.init().`);
	}), r.buffer.clear(), t.buffer.clear();
}
function ar(e, t, r) {
	if (!r.enabledFeatures.has("timestamp-query")) throw new Error("Performance callback requires the \"timestamp-query\" feature to be enabled on GPU device.");
	return e.timestampWrites ? {
		...e,
		performanceCallback: t
	} : {
		...e,
		performanceCallback: t,
		hasAutoQuerySet: !0,
		timestampWrites: {
			querySet: (globalThis.__TYPEGPU_AUTONAME__ ?? ((a) => a))(r.createQuerySet("timestamp", 2), "querySet"),
			beginningOfPassWriteIndex: 0,
			endOfPassWriteIndex: 1
		}
	};
}
function or(e, t, r) {
	if (!r.enabledFeatures.has("timestamp-query")) throw new Error("Timestamp writes require the \"timestamp-query\" feature to be enabled on GPU device.");
	e.hasAutoQuerySet && e.timestampWrites && e.timestampWrites.querySet.destroy();
	let n = { querySet: t.querySet };
	return t.beginningOfPassWriteIndex !== void 0 && (n.beginningOfPassWriteIndex = t.beginningOfPassWriteIndex), t.endOfPassWriteIndex !== void 0 && (n.endOfPassWriteIndex = t.endOfPassWriteIndex), {
		...e,
		hasAutoQuerySet: !1,
		timestampWrites: n
	};
}
function sr(e, t) {
	if (!e.timestampWrites) return {};
	let { querySet: r, beginningOfPassWriteIndex: n, endOfPassWriteIndex: a } = e.timestampWrites, o = { querySet: it(r) ? t.unwrap(r) : r };
	return n !== void 0 && (o.beginningOfPassWriteIndex = n), a !== void 0 && (o.endOfPassWriteIndex = a), { timestampWrites: o };
}
function lt({ root: e, priors: t }) {
	let r = t.timestampWrites?.querySet;
	let n = t.performanceCallback;
	if (!r) throw new Error("Cannot dispatch workgroups with performance callback without a query set.");
	if (!it(r)) throw new Error("Performance callback with raw GPUQuerySet is not supported. Use TgpuQuerySet instead.");
	let a = e.device.createCommandEncoder();
	a.resolveQuerySet(e.unwrap(r), 0, r.count, r[o$1].resolveBuffer, 0), e.device.queue.submit([a.finish()]), e.device.queue.onSubmittedWorkDone().then(async () => {
		if (!r.available) return;
		let o = await r.read();
		let s = o[t.timestampWrites?.beginningOfPassWriteIndex ?? 0];
		let i = o[t.timestampWrites?.endOfPassWriteIndex ?? 1];
		if (s === void 0 || i === void 0) throw new Error("QuerySet did not return valid timestamps.");
		await n(s, i);
	});
}
function Ca(e, t, r) {
	return new Qr(new Hr(e, t, r), {});
}
var Qr = class e {
	constructor(t, r) {
		this._core = t;
		this._priors = r;
		this[o$1] = {
			get rawPipeline() {
				return t.unwrap().pipeline;
			},
			get priors() {
				return r;
			},
			get branch() {
				return t.branch;
			}
		}, this[me$3] = t;
	}
	[o$1];
	resourceType = "compute-pipeline";
	[me$3];
	[oe](t) {
		return t.resolve(this._core);
	}
	toString() {
		return `computePipeline:${D(this) ?? "<unnamed>"}`;
	}
	get rawPipeline() {
		return this._core.unwrap().pipeline;
	}
	with(t, r) {
		return xe(t) ? new e(this._core, {
			...this._priors,
			bindGroupLayoutMap: new Map([...this._priors.bindGroupLayoutMap ?? [], [t.layout, t]])
		}) : new e(this._core, {
			...this._priors,
			bindGroupLayoutMap: new Map([...this._priors.bindGroupLayoutMap ?? [], [t, r]])
		});
	}
	withPerformanceCallback(t) {
		let r = ar(this._priors, t, this._core.branch);
		return new e(this._core, r);
	}
	withTimestampWrites(t) {
		let r = or(this._priors, t, this._core.branch);
		return new e(this._core, r);
	}
	dispatchWorkgroups(t, r, n) {
		let a = this._core.unwrap(), { branch: o } = this._core, s = {
			label: D(this._core) ?? "<unnamed>",
			...sr(this._priors, o)
		}, i = o.device.createCommandEncoder(), u = i.beginComputePass(s);
		u.setPipeline(a.pipeline);
		let l = new Set(a.usedBindGroupLayouts);
		if (a.usedBindGroupLayouts.forEach((m, y) => {
			if (a.catchall && y === a.catchall[0]) u.setBindGroup(y, o.unwrap(a.catchall[1])), l.delete(m);
			else {
				let f = this._priors.bindGroupLayoutMap?.get(m);
				f !== void 0 && (l.delete(m), u.setBindGroup(y, o.unwrap(f)));
			}
		}), l.size > 0) throw new xt$1(l);
		u.dispatchWorkgroups(t, r, n), u.end(), o.device.queue.submit([i.finish()]), a.logResources && pt(a.logResources), this._priors.performanceCallback && lt({
			root: o,
			priors: this._priors
		});
	}
	$name(t) {
		return k(this._core, t), this;
	}
};
var Hr = class {
	constructor(t, r, n) {
		this.branch = t;
		this._slotBindings = r;
		this._entryFn = n;
	}
	[o$1] = !0;
	_memo;
	[oe](t) {
		return t.withSlots(this._slotBindings, () => (t.resolve(this._entryFn), x$1("", Mn$1)));
	}
	toString() {
		return "computePipelineCore";
	}
	unwrap() {
		if (this._memo === void 0) {
			let t = this.branch.device;
			let r = Pe.filter((y) => this.branch.enabledFeatures.has(Ce$1[y]));
			let n;
			let o = Q({ names: this.branch.nameRegistrySetting });
			n = me(this, {
				namespace: o,
				enableExtensions: r,
				shaderGenerator: this.branch.shaderGenerator,
				root: this.branch
			});
			let { code: s, usedBindGroupLayouts: i, catchall: u, logResources: l } = n;
			u !== void 0 && i[u[0]]?.$name(`${D(this) ?? "<unnamed>"} - Automatic Bind Group & Layout`);
			let m = t.createShaderModule({
				label: `${D(this) ?? "<unnamed>"} - Shader`,
				code: s
			});
			this._memo = {
				pipeline: t.createComputePipeline({
					label: D(this) ?? "<unnamed>",
					layout: t.createPipelineLayout({
						label: `${D(this) ?? "<unnamed>"} - Pipeline Layout`,
						bindGroupLayouts: i.map((y) => this.branch.unwrap(y))
					}),
					compute: { module: m }
				}),
				usedBindGroupLayouts: i,
				catchall: u,
				logResources: l
			};
		}
		return this._memo;
	}
};
function Jr(e, t = "vertex") {
	return new Yr(e, t);
}
function ur(e) {
	return e?.resourceType === "vertex-layout";
}
var Kr = Symbol("defaultAttribEntry");
function ir(e, t, r, n, a) {
	if (_$1(t) || I$1(t)) {
		let o = or$2(t);
		return o !== void 0 && (n[a ?? Kr] = o), ir(e, t.inner, ie$2(r, re$1(t)), n);
	}
	if (we$3(t)) {
		let o = r;
		let s = t.propTypes;
		return Object.fromEntries(Object.entries(s).map(([i, u]) => {
			o = ie$2(o, V(u));
			let l = [i, ir(e, u, o, n, i)];
			return o += z(u), l;
		}));
	}
	if (ye$2(t)) {
		let o = r;
		let s = t.propTypes;
		return Object.fromEntries(Object.entries(s).map(([i, u]) => {
			o = ie$2(o, re$1(u));
			let l = [i, ir(e, u, o, n, i)];
			return o += z(u), l;
		}));
	}
	if ("type" in t && typeof t.type == "string") {
		if (rt$2.includes(t.type)) return {
			_layout: e,
			format: t.type,
			offset: r
		};
		let o = er$2[t.type];
		if (o) return {
			_layout: e,
			format: o,
			offset: r
		};
	}
	throw new Error(`Unsupported data used in vertex layout: ${String(t)}`);
}
var Yr = class {
	constructor(t, r) {
		this.schemaForCount = t;
		this.stepMode = r;
		let n = t(0);
		this.stride = ie$2(z(n.elementType), V(n)), this.attrib = ir(this, n.elementType, 0, this._customLocationMap);
	}
	[o$1] = !0;
	resourceType = "vertex-layout";
	stride;
	attrib;
	_customLocationMap = {};
	get vertexLayout() {
		if (this._customLocationMap[Kr] !== void 0) {
			if (typeof this.attrib.format != "string" || typeof this.attrib.offset != "number") throw new Error("Single attribute vertex layouts must have a format and offset.");
			return {
				arrayStride: this.stride,
				stepMode: this.stepMode,
				attributes: [{
					format: this.attrib.format,
					offset: this.attrib.offset,
					shaderLocation: this._customLocationMap[Kr]
				}]
			};
		}
		if (!Object.keys(this.attrib).every((r) => this._customLocationMap[r] !== void 0)) throw new Error("All attributes must have custom locations in order to unwrap a vertex layout.");
		return {
			arrayStride: this.stride,
			stepMode: this.stepMode,
			attributes: [...Object.entries(this.attrib).map(([r, n]) => ({
				format: n.format,
				offset: n.offset,
				shaderLocation: this._customLocationMap[r]
			}))]
		};
	}
	$name(t) {
		return k(this, t), this;
	}
};
function Do(e) {
	return typeof e?.loadOp == "string";
}
function Ea(e, t) {
	if (ar$2(e)) {
		if (!Do(t)) throw new Error("Expected a single color attachment, not a record.");
		return [t];
	}
	let r = [];
	for (let n of Object.keys(e)) {
		let a = e[n];
		if (In$1(a)) continue;
		let o = t[n];
		if (!o) throw new Error(`A color attachment by the name of '${n}' was not provided to the shader.`);
		r.push(o);
	}
	return r;
}
function Bo(e) {
	return typeof e?.format == "string";
}
function Va(e, t) {
	if (ar$2(e)) {
		if (Yn$2(e)) return [];
		if (!Bo(t)) throw new Error("Expected a single color target configuration, not a record.");
		return [t];
	}
	let r = [];
	for (let n of Object.keys(e)) {
		let a = e[n];
		if (In$1(a)) continue;
		let o = t[n];
		if (!o) throw new Error(`A color target by the name of '${n}' was not provided to the shader.`);
		r.push(o);
	}
	return r;
}
function en(e) {
	return new Xr(new Zr(e), {});
}
var Xr = class e {
	[o$1];
	resourceType = "render-pipeline";
	[me$3];
	hasIndexBuffer = !1;
	constructor(t, r) {
		this[o$1] = {
			core: t,
			priors: r,
			branch: t.options.branch
		}, this[me$3] = t;
	}
	[oe](t) {
		return t.resolve(this[o$1].core);
	}
	toString() {
		return `renderPipeline:${D(this) ?? "<unnamed>"}`;
	}
	$name(t) {
		return k(this[o$1].core, t), this;
	}
	with(t, r) {
		let n = this[o$1];
		if (xe(t)) return new e(n.core, {
			...n.priors,
			bindGroupLayoutMap: new Map([...n.priors.bindGroupLayoutMap ?? [], [t.layout, t]])
		});
		if (er(t)) return new e(n.core, {
			...n.priors,
			bindGroupLayoutMap: new Map([...n.priors.bindGroupLayoutMap ?? [], [t, r]])
		});
		if (ur(t)) return new e(n.core, {
			...n.priors,
			vertexLayoutMap: new Map([...n.priors.vertexLayoutMap ?? [], [t, r]])
		});
		throw new Error("Unsupported value passed into .with()");
	}
	withPerformanceCallback(t) {
		let r = this[o$1];
		let n = ar(r.priors, t, r.core.options.branch);
		return new e(r.core, n);
	}
	withTimestampWrites(t) {
		let r = this[o$1];
		let n = or(r.priors, t, r.core.options.branch);
		return new e(r.core, n);
	}
	withColorAttachment(t) {
		let r = this[o$1];
		return new e(r.core, {
			...r.priors,
			colorAttachment: t
		});
	}
	withDepthStencilAttachment(t) {
		let r = this[o$1];
		return new e(r.core, {
			...r.priors,
			depthStencilAttachment: t
		});
	}
	withIndexBuffer(t, r, n, a) {
		let o = this[o$1];
		if (Ar$1(t)) {
			if (typeof r != "string") throw new Error("If a GPUBuffer is passed, indexFormat must be provided.");
			return new e(o.core, {
				...o.priors,
				indexBuffer: {
					buffer: t,
					indexFormat: r,
					offsetBytes: n,
					sizeBytes: a
				}
			});
		}
		let s = {
			u32: "uint32",
			u16: "uint16"
		};
		let i = t.dataType.elementType;
		return new e(o.core, {
			...o.priors,
			indexBuffer: {
				buffer: t,
				indexFormat: s[i.type],
				offsetBytes: r !== void 0 ? r * z(i) : void 0,
				sizeBytes: a !== void 0 ? a * z(i) : void 0
			}
		});
	}
	setupRenderPass(t) {
		let r = this[o$1], n = r.core.unwrap(), { branch: a, fragmentFn: o } = r.core.options, s = o ? Ea(o.shell.out, r.priors.colorAttachment ?? {}).map((f) => ee(f.view) ? {
			...f,
			view: a.unwrap(f.view).createView()
		} : he(f.view) ? {
			...f,
			view: a.unwrap(f.view)
		} : f) : [null], i = {
			label: D(r.core) ?? "<unnamed>",
			colorAttachments: s,
			...sr(r.priors, a)
		};
		if (r.priors.depthStencilAttachment !== void 0) {
			let f = r.priors.depthStencilAttachment;
			ee(f.view) ? i.depthStencilAttachment = {
				...f,
				view: a.unwrap(f.view).createView()
			} : i.depthStencilAttachment = f;
		}
		let u = t.beginRenderPass(i);
		u.setPipeline(n.pipeline);
		let l = new Set(n.usedBindGroupLayouts);
		n.usedBindGroupLayouts.forEach((f, T) => {
			if (n.catchall && T === n.catchall[0]) u.setBindGroup(T, a.unwrap(n.catchall[1])), l.delete(f);
			else {
				let w = r.priors.bindGroupLayoutMap?.get(f);
				w !== void 0 && (l.delete(f), u.setBindGroup(T, a.unwrap(w)));
			}
		});
		let m = new Set(r.core.usedVertexLayouts);
		if (r.core.usedVertexLayouts.forEach((f, T) => {
			let w = r.priors.vertexLayoutMap?.get(f);
			w && (m.delete(f), u.setVertexBuffer(T, a.unwrap(w)));
		}), l.size > 0) throw new xt$1(l);
		if (m.size > 0) throw new dt$1(m);
		return u;
	}
	draw(t, r, n, a) {
		let o = this[o$1], { branch: s } = o.core.options, { logResources: i } = o.core.unwrap(), u = s.device.createCommandEncoder(), l = this.setupRenderPass(u);
		l.draw(t, r, n, a), l.end(), s.device.queue.submit([u.finish()]), i && pt(i), o.priors.performanceCallback && lt({
			root: s,
			priors: o.priors
		});
	}
	drawIndexed(t, r, n, a, o) {
		let s = this[o$1];
		if (!s.priors.indexBuffer) throw new Error("No index buffer set for this render pipeline.");
		let { logResources: i } = s.core.unwrap(), { branch: u } = s.core.options, { buffer: l, indexFormat: m, offsetBytes: y, sizeBytes: f } = s.priors.indexBuffer, T = u.device.createCommandEncoder(), w = this.setupRenderPass(T);
		Ar$1(l) ? w.setIndexBuffer(l, m, y, f) : w.setIndexBuffer(u.unwrap(l), m, y, f), w.drawIndexed(t, r, n, a, o), w.end(), u.device.queue.submit([T.finish()]), i && pt(i), s.priors.performanceCallback && lt({
			root: u,
			priors: s.priors
		});
	}
};
var Zr = class {
	constructor(t) {
		this.options = t;
		let r = ea(t.vertexFn.shell.in ?? {}, t.vertexAttribs);
		this._vertexBufferLayouts = r.bufferDefinitions, this.usedVertexLayouts = r.usedVertexLayouts, this._targets = t.fragmentFn && t.targets ? Va(t.fragmentFn.shell.out, t.targets) : [null];
	}
	[o$1] = !0;
	usedVertexLayouts;
	_memo;
	_vertexBufferLayouts;
	_targets;
	[oe](t) {
		let { vertexFn: r, fragmentFn: n, slotBindings: a } = this.options, o = Ao(r.shell.out, n?.shell.in, D(r) ?? "<unnamed>", D(n) ?? "<unnamed>");
		return t.withVaryingLocations(o, () => t.withSlots(a, () => (t.resolve(r), n && t.resolve(n), x$1("", Mn$1))));
	}
	toString() {
		return "renderPipelineCore";
	}
	unwrap() {
		if (this._memo === void 0) {
			let { branch: t, primitiveState: r, depthStencilState: n, multisampleState: a } = this.options, o = t.device, s = Pe.filter((F) => t.enabledFeatures.has(Ce$1[F])), i, l = Q({ names: t.nameRegistrySetting });
			i = me(this, {
				namespace: l,
				enableExtensions: s,
				shaderGenerator: t.shaderGenerator,
				root: t
			});
			let { code: m, usedBindGroupLayouts: y, catchall: f, logResources: T } = i;
			f !== void 0 && y[f[0]]?.$name(`${D(this) ?? "<unnamed>"} - Automatic Bind Group & Layout`);
			let w = o.createShaderModule({
				label: `${D(this) ?? "<unnamed>"} - Shader`,
				code: m
			});
			let x = {
				layout: o.createPipelineLayout({
					label: `${D(this) ?? "<unnamed>"} - Pipeline Layout`,
					bindGroupLayouts: y.map((F) => t.unwrap(F))
				}),
				vertex: {
					module: w,
					buffers: this._vertexBufferLayouts
				}
			};
			let P = D(this);
			P !== void 0 && (x.label = P), this.options.fragmentFn && (x.fragment = {
				module: w,
				targets: this._targets
			}), r && (C(r.stripIndexFormat) ? x.primitive = {
				...r,
				stripIndexFormat: {
					u32: "uint32",
					u16: "uint16"
				}[r.stripIndexFormat.type]
			} : x.primitive = r), n && (x.depthStencil = n), a && (x.multisample = a), this._memo = {
				pipeline: o.createRenderPipeline(x),
				usedBindGroupLayouts: y,
				catchall: f,
				logResources: T
			};
		}
		return this._memo;
	}
};
function Ao(e, t, r, n) {
	let a = {};
	let o = /* @__PURE__ */ new Set();
	function s(u, l) {
		a[u] = l, o.add(l);
	}
	for (let [u, l] of Object.entries(e)) {
		let m = or$2(l);
		m !== void 0 && s(u, m);
	}
	for (let [u, l] of Object.entries(t ?? {})) {
		let m = or$2(l);
		m !== void 0 && (a[u] === void 0 ? s(u, m) : a[u] !== m && console.warn(`Mismatched location between vertexFn (${r}) output (${a[u]}) and fragmentFn (${n}) input (${m}) for the key "${u}", using the location set on vertex output.`));
	}
	let i = 0;
	for (let u of Object.keys(e ?? {})) if (!(In$1(e[u]) || a[u] !== void 0)) {
		for (; o.has(i);) i++;
		s(u, i);
	}
	return a;
}
function $o(e) {
	if (e.includes(0)) throw new Error("Size and workgroupSize cannot contain zeroes.");
	return E(e[0] ?? 1, e[1] ?? 1, e[2] ?? 1);
}
var Lo = [
	E(1, 1, 1),
	E(256, 1, 1),
	E(16, 16, 1),
	E(8, 8, 4)
];
var tn = class e {
	#e;
	#r;
	#t;
	#n;
	#a;
	constructor(t, r, n, a) {
		this.#e = t, this.#r = r, this.#t = n, this.#n = a, this.#a = E();
	}
	with(t) {
		return new e(this.#e, this.#r.with(t), this.#t, this.#n);
	}
	dispatchThreads(...t) {
		let r = $o(t);
		let n = Ma$1(Le(r).div(Le(this.#n)));
		Ae(r, this.#a) || (this.#a = r, this.#t.write(r)), this.#r.dispatchWorkgroups(n.x, n.y, n.z);
	}
	get pipeline() {
		return this.#r;
	}
	get sizeUniform() {
		return this.#t;
	}
};
var rn = class e {
	constructor(t, r) {
		this._getRoot = t;
		this._slotBindings = r;
	}
	with(t, r) {
		return new e(this._getRoot, [...this._slotBindings, [dr$1(t) ? t.slot : t, r]]);
	}
	withCompute(t) {
		return new nn(this._getRoot(), this._slotBindings, t);
	}
	createGuardedComputePipeline(t) {
		let r = this._getRoot();
		if (t.length >= 4) throw new Error("Guarded compute callback only supports up to three dimensions.");
		let n = Lo[t.length];
		let a = U([
			c,
			c,
			c
		])(t);
		let o = (globalThis.__TYPEGPU_AUTONAME__ ?? ((a) => a))(r.createUniform(E), "o");
		let s = Et({
			workgroupSize: n,
			in: { id: yo$2.globalInvocationId }
		})`{
  if (any(in.id >= sizeUniform)) {
    return;
  }
  wrappedCallback(in.id.x, in.id.y, in.id.z);
}`.$uses({
			sizeUniform: o,
			wrappedCallback: a
		});
		return new tn(r, (globalThis.__TYPEGPU_AUTONAME__ ?? ((a) => a))(this.withCompute(s).createPipeline(), "i"), o, n);
	}
	withVertex(t, r) {
		return new an({
			branch: this._getRoot(),
			primitiveState: void 0,
			depthStencilState: void 0,
			slotBindings: this._slotBindings,
			vertexFn: t,
			vertexAttribs: r,
			multisampleState: void 0
		});
	}
	pipe(t) {
		let r = t(new Ge([]));
		return new e(this._getRoot, [...this._slotBindings, ...r.bindings]);
	}
};
var nn = class {
	constructor(t, r, n) {
		this._root = t;
		this._slotBindings = r;
		this._entryFn = n;
	}
	createPipeline() {
		return Ca(this._root, this._slotBindings, this._entryFn);
	}
};
var an = class e {
	constructor(t) {
		this._options = t;
	}
	withFragment(t, r, n) {
		return Ve$3(typeof t != "string", "Just type mismatch validation"), Ve$3(typeof r != "string", "Just type mismatch validation"), new on({
			...this._options,
			fragmentFn: t,
			targets: r
		});
	}
	withPrimitive(t) {
		return new e({
			...this._options,
			primitiveState: t
		});
	}
	withDepthStencil(t) {
		return new e({
			...this._options,
			depthStencilState: t
		});
	}
	withMultisample(t) {
		return new e({
			...this._options,
			multisampleState: t
		});
	}
	createPipeline() {
		return en({
			...this._options,
			fragmentFn: null,
			targets: null
		});
	}
};
var on = class e {
	constructor(t) {
		this._options = t;
	}
	withPrimitive(t) {
		return new e({
			...this._options,
			primitiveState: t
		});
	}
	withDepthStencil(t) {
		return new e({
			...this._options,
			depthStencilState: t
		});
	}
	withMultisample(t) {
		return new e({
			...this._options,
			multisampleState: t
		});
	}
	createPipeline() {
		return en(this._options);
	}
};
var pr = class extends rn {
	constructor(r, n, a, o, s) {
		super(() => this, []);
		this.device = r;
		this.nameRegistrySetting = n;
		this._ownDevice = a;
		this.shaderGenerator = s;
		this["~unstable"] = this, this[o$1] = { logOptions: o };
	}
	"~unstable";
	_unwrappedBindGroupLayouts = new ut((r) => r.unwrap(this));
	_unwrappedBindGroups = new ut((r) => r.unwrap(this));
	[o$1];
	get enabledFeatures() {
		return new Set(this.device.features);
	}
	createBuffer(r, n) {
		return et(this, r, n);
	}
	createUniform(r, n) {
		return new be("uniform", et(this, r, n).$usage("uniform"));
	}
	createMutable(r, n) {
		return new be("mutable", et(this, r, n).$usage("storage"));
	}
	createReadonly(r, n) {
		return new be("readonly", et(this, r, n).$usage("storage"));
	}
	createQuerySet(r, n, a) {
		return Ga(this, r, n, a);
	}
	createBindGroup(r, n) {
		return new Ve(r, n);
	}
	destroy() {
		ga(this.device), this._ownDevice && this.device.destroy();
	}
	createTexture(r) {
		return ha(r, this);
	}
	createSampler(r) {
		return fa(r, this);
	}
	createComparisonSampler(r) {
		return da(r, this);
	}
	unwrap(r) {
		if (Or(r)) return r[o$1].rawPipeline;
		if (zr(r)) return r[o$1].core.unwrap().pipeline;
		if (er(r)) return this._unwrappedBindGroupLayouts.getOrMake(r);
		if (xe(r)) return this._unwrappedBindGroups.getOrMake(r);
		if (le(r)) return r.buffer;
		if (ee(r)) return r[o$1].unwrap();
		if (he(r)) {
			if (!r[o$1].unwrap) throw new Error("Cannot unwrap laid-out texture view as it has no underlying resource.");
			return r[o$1].unwrap();
		}
		if (ur(r)) return r.vertexLayout;
		if (tt(r) || rt(r)) {
			if (r[o$1].unwrap) return r[o$1].unwrap();
			throw new Error("Cannot unwrap laid-out sampler.");
		}
		if (it(r)) return r.querySet;
		throw new Error(`Unknown resource type: ${r}`);
	}
	beginRenderPass(r, n) {
		let a = this.device.createCommandEncoder();
		let o = a.beginRenderPass(r);
		let s = /* @__PURE__ */ new Map();
		let i = /* @__PURE__ */ new Map();
		let u;
		let l = () => {
			if (!u) throw new Error("Cannot draw without a call to pass.setPipeline");
			let { core: m, priors: y } = u[o$1], f = m.unwrap();
			o.setPipeline(f.pipeline);
			let T = new Set(f.usedBindGroupLayouts);
			f.usedBindGroupLayouts.forEach((x, P) => {
				if (f.catchall && P === f.catchall[0]) o.setBindGroup(P, this.unwrap(f.catchall[1])), T.delete(x);
				else {
					let F = y.bindGroupLayoutMap?.get(x) ?? s.get(x);
					F !== void 0 && (T.delete(x), xe(F) ? o.setBindGroup(P, this.unwrap(F)) : o.setBindGroup(P, F));
				}
			});
			let w = /* @__PURE__ */ new Set();
			if (m.usedVertexLayouts.forEach((x, P) => {
				let F = y.vertexLayoutMap?.get(x);
				let R = F ? {
					buffer: F,
					offset: void 0,
					size: void 0
				} : i.get(x);
				!R || !R.buffer ? w.add(x) : le(R.buffer) ? o.setVertexBuffer(P, this.unwrap(R.buffer), R.offset, R.size) : o.setVertexBuffer(P, R.buffer, R.offset, R.size);
			}), T.size > 0) throw new xt$1(T);
			if (w.size > 0) throw new dt$1(w);
		};
		n({
			setViewport(...m) {
				o.setViewport(...m);
			},
			setScissorRect(...m) {
				o.setScissorRect(...m);
			},
			setBlendConstant(...m) {
				o.setBlendConstant(...m);
			},
			setStencilReference(...m) {
				o.setStencilReference(...m);
			},
			beginOcclusionQuery(...m) {
				o.beginOcclusionQuery(...m);
			},
			endOcclusionQuery(...m) {
				o.endOcclusionQuery(...m);
			},
			executeBundles(...m) {
				o.executeBundles(...m);
			},
			setPipeline(m) {
				u = m;
			},
			setIndexBuffer: (m, y, f, T) => {
				le(m) ? o.setIndexBuffer(this.unwrap(m), y, f, T) : o.setIndexBuffer(m, y, f, T);
			},
			setVertexBuffer(m, y, f, T) {
				i.set(m, {
					buffer: y,
					offset: f,
					size: T
				});
			},
			setBindGroup(m, y) {
				s.set(m, y);
			},
			draw(m, y, f, T) {
				l(), o.draw(m, y, f, T);
			},
			drawIndexed(...m) {
				l(), o.drawIndexed(...m);
			},
			drawIndirect(...m) {
				l(), o.drawIndirect(...m);
			},
			drawIndexedIndirect(...m) {
				l(), o.drawIndexedIndirect(...m);
			}
		}), o.end(), this.device.queue.submit([a.finish()]);
	}
	flush() {
		console.warn("flush() has been deprecated, and has no effect.");
	}
};
async function _a(e) {
	let { adapter: t, device: r, unstable_names: n = "random", unstable_logOptions: a } = e ?? {};
	if (!navigator.gpu) throw new Error("WebGPU is not supported by this browser.");
	let o = await navigator.gpu.requestAdapter(t);
	if (!o) throw new Error("Could not find a compatible GPU");
	let s = [];
	for (let u of r?.requiredFeatures ?? []) {
		if (!o.features.has(u)) throw new Error(`Requested feature "${u}" is not supported by the adapter.`);
		s.push(u);
	}
	for (let u of r?.optionalFeatures ?? []) o.features.has(u) ? s.push(u) : console.warn(`Optional feature "${u}" is not supported by the adapter.`);
	return new pr(await o.requestDevice({
		...r,
		requiredFeatures: s
	}), n, !0, a ?? {}, e?.shaderGenerator);
}
function Wa(e) {
	let { device: t, unstable_names: r = "random", unstable_logOptions: n } = e ?? {};
	return new pr(t, r, !1, n ?? {}, e?.shaderGenerator);
}
function Ma(e, t) {
	return new sn(e, t);
}
var sn = class {
	constructor(t, r = void 0) {
		this.schema = t;
		this.defaultValue = r;
		this.slot = we(r), this[me$3] = this.slot;
	}
	[o$1] = !0;
	[me$3];
	resourceType = "accessor";
	slot;
	get [kn$1]() {
		return new Proxy({
			[o$1]: !0,
			[qe]: this.#e(),
			[oe]: (t) => t.resolve(this),
			toString: () => `accessor:${D(this) ?? "<unnamed>"}.$`
		}, _t$1);
	}
	#e() {
		let r = ys(zt$2().unwrap(this.slot));
		return Ke(r) ? r[o$1].gpuImpl() : x$1(r, this.schema);
	}
	$name(t) {
		return this.slot.$name(t), this;
	}
	toString() {
		return `accessor:${D(this) ?? "<unnamed>"}`;
	}
	get value() {
		if (Oe$1()) return this[kn$1];
		throw new Error("`tgpu.accessor` relies on GPU resources and cannot be accessed outside of a compute dispatch or draw call");
	}
	get $() {
		return this.value;
	}
	[oe](t) {
		let r = this.#e();
		return x$1(t.resolve(r.value, r.dataType).value, r.dataType);
	}
};
function ka(e) {
	return Go(e);
}
function Ro([e, t]) {
	return `${D(e) ?? "<unnamed>"}=${t}`;
}
function Go(e) {
	if (zt$2()) throw new Error("Cannot create tgpu.derived objects at the resolution stage.");
	return {
		[o$1]: !0,
		resourceType: "derived",
		"~compute": e,
		get [kn$1]() {
			let r = zt$2();
			if (!r) throw new Error("Cannot access tgpu.derived's value outside of resolution.");
			return ys(r.unwrap(this));
		},
		get value() {
			return this[kn$1];
		},
		get $() {
			return this.value;
		},
		with(r, n) {
			return Oa(this, [[r, n]]);
		},
		toString() {
			return "derived";
		}
	};
}
function Oa(e, t) {
	return {
		[o$1]: !0,
		resourceType: "derived",
		"~compute"() {
			throw new Error("'~compute' should never be read on bound derived items.");
		},
		[He]: {
			inner: e,
			pairs: t
		},
		get [kn$1]() {
			let n = zt$2();
			if (!n) throw new Error("Cannot access tgpu.derived's value outside of resolution.");
			return ys(n.unwrap(this));
		},
		get value() {
			return this[kn$1];
		},
		get $() {
			return this.value;
		},
		with(n, a) {
			return Oa(e, [...t, [n, a]]);
		},
		toString() {
			return `derived[${t.map(Ro).join(", ")}]`;
		}
	};
}
var Co = {
	fn: U,
	bindGroupLayout: Zt,
	vertexLayout: Jr,
	slot: we,
	init: _a,
	initFromDevice: Wa,
	resolve: La,
	resolveWithContext: Nr,
	privateVar: _e,
	workgroupVar: _r,
	const: nn$1,
	"~unstable": {
		fn: U,
		fragmentFn: Yn,
		vertexFn: Qe$1,
		computeFn: Et,
		vertexLayout: Jr,
		namespace: Q,
		derived: ka,
		slot: we,
		accessor: Ma,
		privateVar: _e,
		workgroupVar: _r,
		const: nn$1,
		declare: Hn,
		simulate: Ra
	}
};
//#endregion
//#region packages/mask-editor/src/gpu/gpuSchema.ts
var BrushUniforms = (globalThis.__TYPEGPU_AUTONAME__ ?? ((a) => a))(qs({
	brushColor: Le,
	brushOpacity: h$1,
	hardness: h$1,
	screenSize: B$1,
	brushShape: c
}), "BrushUniforms");
var StrokePoint = (globalThis.__TYPEGPU_AUTONAME__ ?? ((a) => a))(qs({
	pos: Ws(0, B$1),
	size: Ws(1, h$1),
	pressure: Ws(2, h$1)
}), "StrokePoint");
//#endregion
//#region packages/mask-editor/src/gpu/brushShaders.ts
var VertexOutput = (globalThis.__TYPEGPU_AUTONAME__ ?? ((a) => a))(qs({
	position: yo$2.position,
	localUV: Ws(0, B$1),
	color: Ws(1, Le),
	opacity: Ws(2, h$1),
	hardness: Ws(3, h$1)
}), "VertexOutput");
var brushVertex = Co.resolve({
	template: `
@group(0) @binding(0) var<uniform> globals: BrushUniforms;

@vertex
fn vs(
  @location(0) quadPos: vec2<f32>,
  @location(1) pos: vec2<f32>,
  @location(2) size: f32,
  @location(3) pressure: f32
) -> VertexOutput {
  // Convert diameter to radius
  let radius = size * pressure;
  let pixelPos = pos + (quadPos * radius);
  
  // Convert pixel coordinates to Normalized Device Coordinates (NDC)
  let ndcX = (pixelPos.x / globals.screenSize.x) * 2.0 - 1.0;
  let ndcY = 1.0 - ((pixelPos.y / globals.screenSize.y) * 2.0);  // Flip Y axis for WebGPU coordinate system

  return VertexOutput(
    vec4<f32>(ndcX, ndcY, 0.0, 1.0),
    quadPos,
    globals.brushColor,
    pressure * globals.brushOpacity,
    globals.hardness
  );
}
`,
	externals: {
		BrushUniforms,
		VertexOutput
	}
});
var brushFragment = Co.resolve({
	template: `
@group(0) @binding(0) var<uniform> globals: BrushUniforms;

@fragment
fn fs(v: VertexOutput) -> @location(0) vec4<f32> {
  var dist: f32;
  if (globals.brushShape == 1u) {
    // Calculate Chebyshev distance for square shape
    dist = max(abs(v.localUV.x), abs(v.localUV.y));
  } else {
    // Calculate Euclidean distance for circle shape
    dist = length(v.localUV);
  }

  if (dist > 1.0) { discard; }

  // Calculate alpha with hardness and anti-aliasing
  let edgeWidth = fwidth(dist);
  let startFade = min(v.hardness, 1.0 - edgeWidth * 2.0);
  let linearAlpha = 1.0 - smoothstep(startFade, 1.0, dist);
  // Apply quadratic falloff for smoother edges
  let alphaShape = pow(linearAlpha, 2.0);
  
  // Return premultiplied alpha color
  let alpha = alphaShape * v.opacity;
  return vec4<f32>(v.color * alpha, alpha);
}
`,
	externals: {
		VertexOutput,
		BrushUniforms
	}
});
var blitShader = Co.resolve({
	template: `
@vertex fn vs(@builtin(vertex_index) vIdx: u32) -> @builtin(position) vec4<f32> {
  var pos = array<vec2<f32>, 3>(
    vec2<f32>(-1.0, -1.0), vec2<f32>(3.0, -1.0), vec2<f32>(-1.0, 3.0)
  );
  return vec4<f32>(pos[vIdx], 0.0, 1.0);
}

@group(0) @binding(0) var myTexture: texture_2d<f32>;

@fragment fn fs(@builtin(position) pos: vec4<f32>) -> @location(0) vec4<f32> {
  let c = textureLoad(myTexture, vec2<i32>(pos.xy), 0);
  // Treat texture as premultiplied to prevent double-darkening on overlaps
  return c;
}
`,
	externals: {}
});
var compositeShader = Co.resolve({
	template: `
@vertex fn vs(@builtin(vertex_index) vIdx: u32) -> @builtin(position) vec4<f32> {
  var pos = array<vec2<f32>, 3>(
    vec2<f32>(-1.0, -1.0), vec2<f32>(3.0, -1.0), vec2<f32>(-1.0, 3.0)
  );
  return vec4<f32>(pos[vIdx], 0.0, 1.0);
}

@group(0) @binding(0) var myTexture: texture_2d<f32>;
@group(1) @binding(0) var<uniform> globals: BrushUniforms;

@fragment fn fs(@builtin(position) pos: vec4<f32>) -> @location(0) vec4<f32> {
  let sampled = textureLoad(myTexture, vec2<i32>(pos.xy), 0);
  // Apply global brush opacity to accumulated coverage
  return sampled * globals.brushOpacity;
}
`,
	externals: { BrushUniforms }
});
var readbackShader = Co.resolve({
	template: `
@group(0) @binding(0) var inputTex: texture_2d<f32>;
@group(0) @binding(1) var<storage, read_write> outputBuf: array<u32>;

@compute @workgroup_size(8, 8)
fn main(@builtin(global_invocation_id) id: vec3<u32>) {
  let dims = textureDimensions(inputTex);
  if (id.x >= dims.x || id.y >= dims.y) { return; }

  let color = textureLoad(inputTex, vec2<i32>(id.xy), 0);
  
  var r = color.r;
  var g = color.g;
  var b = color.b;
  let a = color.a;

  if (a > 0.0) {
    r = r / a;
    g = g / a;
    b = b / a;
  }

  let ir = u32(clamp(r * 255.0 + 0.5, 0.0, 255.0));
  let ig = u32(clamp(g * 255.0 + 0.5, 0.0, 255.0));
  let ib = u32(clamp(b * 255.0 + 0.5, 0.0, 255.0));
  let ia = u32(clamp(a * 255.0 + 0.5, 0.0, 255.0));

  // Pack RGBA channels into a single u32 (Little Endian)
  let packed = ir | (ig << 8u) | (ib << 16u) | (ia << 24u);

  let index = id.y * dims.x + id.x;
  outputBuf[index] = packed;
}
`,
	externals: {}
});
//#endregion
//#region packages/mask-editor/src/gpu/GPUBrushRenderer.ts
var QUAD_VERTS = new Float32Array([
	-1,
	-1,
	1,
	-1,
	1,
	1,
	-1,
	1
]);
var QUAD_INDICES = new Uint16Array([
	0,
	1,
	2,
	0,
	2,
	3
]);
var UNIFORM_SIZE = 48;
var STROKE_STRIDE = $s(StrokePoint);
var MAX_STROKES = 1e4;
var GPUBrushRenderer = class {
	device;
	quadVertexBuffer;
	indexBuffer;
	instanceBuffer;
	uniformBuffer;
	renderPipeline;
	accumulatePipeline;
	blitPipeline;
	compositePipeline;
	compositePipelinePreview;
	erasePipeline;
	erasePipelinePreview;
	readbackPipeline;
	uniformBindGroupLayout;
	textureBindGroupLayout;
	mainUniformBindGroup;
	currentStrokeTexture = null;
	currentStrokeView = null;
	compositeTextureBindGroup = null;
	previewTextureBindGroup = null;
	lastReadbackTexture = null;
	lastReadbackBuffer = null;
	readbackBindGroup = null;
	lastBackgroundTexture = null;
	backgroundBindGroup = null;
	constructor(device, presentationFormat = "rgba8unorm") {
		this.device = device;
		this.quadVertexBuffer = device.createBuffer({
			size: QUAD_VERTS.byteLength,
			usage: GPUBufferUsage.VERTEX,
			mappedAtCreation: true
		});
		new Float32Array(this.quadVertexBuffer.getMappedRange()).set(QUAD_VERTS);
		this.quadVertexBuffer.unmap();
		this.indexBuffer = device.createBuffer({
			size: QUAD_INDICES.byteLength,
			usage: GPUBufferUsage.INDEX,
			mappedAtCreation: true
		});
		new Uint16Array(this.indexBuffer.getMappedRange()).set(QUAD_INDICES);
		this.indexBuffer.unmap();
		this.instanceBuffer = device.createBuffer({
			size: MAX_STROKES * STROKE_STRIDE,
			usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST
		});
		this.uniformBuffer = device.createBuffer({
			size: UNIFORM_SIZE,
			usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
		});
		const brushModuleV = device.createShaderModule({ code: brushVertex });
		const brushModuleF = device.createShaderModule({ code: brushFragment });
		this.uniformBindGroupLayout = device.createBindGroupLayout({ entries: [{
			binding: 0,
			visibility: GPUShaderStage.VERTEX | GPUShaderStage.FRAGMENT,
			buffer: { type: "uniform" }
		}] });
		this.textureBindGroupLayout = device.createBindGroupLayout({ entries: [{
			binding: 0,
			visibility: GPUShaderStage.FRAGMENT,
			texture: {}
		}] });
		this.mainUniformBindGroup = device.createBindGroup({
			layout: this.uniformBindGroupLayout,
			entries: [{
				binding: 0,
				resource: { buffer: this.uniformBuffer }
			}]
		});
		const renderPipelineLayout = device.createPipelineLayout({ bindGroupLayouts: [this.uniformBindGroupLayout] });
		this.renderPipeline = device.createRenderPipeline({
			layout: renderPipelineLayout,
			vertex: {
				module: brushModuleV,
				entryPoint: "vs",
				buffers: [{
					arrayStride: 8,
					stepMode: "vertex",
					attributes: [{
						shaderLocation: 0,
						offset: 0,
						format: "float32x2"
					}]
				}, {
					arrayStride: 16,
					stepMode: "instance",
					attributes: [
						{
							shaderLocation: 1,
							offset: 0,
							format: "float32x2"
						},
						{
							shaderLocation: 2,
							offset: 8,
							format: "float32"
						},
						{
							shaderLocation: 3,
							offset: 12,
							format: "float32"
						}
					]
				}]
			},
			fragment: {
				module: brushModuleF,
				entryPoint: "fs",
				targets: [{
					format: "rgba8unorm",
					blend: {
						color: {
							srcFactor: "one",
							dstFactor: "one-minus-src-alpha",
							operation: "add"
						},
						alpha: {
							srcFactor: "one",
							dstFactor: "one-minus-src-alpha",
							operation: "add"
						}
					}
				}]
			},
			primitive: { topology: "triangle-list" }
		});
		this.accumulatePipeline = device.createRenderPipeline({
			layout: renderPipelineLayout,
			vertex: {
				module: brushModuleV,
				entryPoint: "vs",
				buffers: [{
					arrayStride: 8,
					stepMode: "vertex",
					attributes: [{
						shaderLocation: 0,
						offset: 0,
						format: "float32x2"
					}]
				}, {
					arrayStride: 16,
					stepMode: "instance",
					attributes: [
						{
							shaderLocation: 1,
							offset: 0,
							format: "float32x2"
						},
						{
							shaderLocation: 2,
							offset: 8,
							format: "float32"
						},
						{
							shaderLocation: 3,
							offset: 12,
							format: "float32"
						}
					]
				}]
			},
			fragment: {
				module: brushModuleF,
				entryPoint: "fs",
				targets: [{
					format: "rgba8unorm",
					blend: {
						color: {
							srcFactor: "one",
							dstFactor: "one",
							operation: "max"
						},
						alpha: {
							srcFactor: "one",
							dstFactor: "one",
							operation: "max"
						}
					}
				}]
			},
			primitive: { topology: "triangle-list" }
		});
		const blitPipelineLayout = device.createPipelineLayout({ bindGroupLayouts: [this.textureBindGroupLayout] });
		this.blitPipeline = device.createRenderPipeline({
			layout: blitPipelineLayout,
			vertex: {
				module: device.createShaderModule({ code: blitShader }),
				entryPoint: "vs"
			},
			fragment: {
				module: device.createShaderModule({ code: blitShader }),
				entryPoint: "fs",
				targets: [{
					format: presentationFormat,
					blend: {
						color: {
							srcFactor: "one",
							dstFactor: "one-minus-src-alpha",
							operation: "add"
						},
						alpha: {
							srcFactor: "one",
							dstFactor: "one-minus-src-alpha",
							operation: "add"
						}
					}
				}]
			},
			primitive: { topology: "triangle-list" }
		});
		const compositePipelineLayout = device.createPipelineLayout({ bindGroupLayouts: [this.textureBindGroupLayout, this.uniformBindGroupLayout] });
		this.compositePipeline = device.createRenderPipeline({
			layout: compositePipelineLayout,
			vertex: {
				module: device.createShaderModule({ code: compositeShader }),
				entryPoint: "vs"
			},
			fragment: {
				module: device.createShaderModule({ code: compositeShader }),
				entryPoint: "fs",
				targets: [{
					format: "rgba8unorm",
					blend: {
						color: {
							srcFactor: "one",
							dstFactor: "one-minus-src-alpha",
							operation: "add"
						},
						alpha: {
							srcFactor: "one",
							dstFactor: "one-minus-src-alpha",
							operation: "add"
						}
					}
				}]
			},
			primitive: { topology: "triangle-list" }
		});
		this.compositePipelinePreview = device.createRenderPipeline({
			layout: compositePipelineLayout,
			vertex: {
				module: device.createShaderModule({ code: compositeShader }),
				entryPoint: "vs"
			},
			fragment: {
				module: device.createShaderModule({ code: compositeShader }),
				entryPoint: "fs",
				targets: [{
					format: presentationFormat,
					blend: {
						color: {
							srcFactor: "one",
							dstFactor: "one-minus-src-alpha",
							operation: "add"
						},
						alpha: {
							srcFactor: "one",
							dstFactor: "one-minus-src-alpha",
							operation: "add"
						}
					}
				}]
			},
			primitive: { topology: "triangle-list" }
		});
		this.erasePipeline = device.createRenderPipeline({
			layout: compositePipelineLayout,
			vertex: {
				module: device.createShaderModule({ code: compositeShader }),
				entryPoint: "vs"
			},
			fragment: {
				module: device.createShaderModule({ code: compositeShader }),
				entryPoint: "fs",
				targets: [{
					format: "rgba8unorm",
					blend: {
						color: {
							srcFactor: "zero",
							dstFactor: "one-minus-src-alpha",
							operation: "add"
						},
						alpha: {
							srcFactor: "zero",
							dstFactor: "one-minus-src-alpha",
							operation: "add"
						}
					}
				}]
			},
			primitive: { topology: "triangle-list" }
		});
		this.erasePipelinePreview = device.createRenderPipeline({
			layout: compositePipelineLayout,
			vertex: {
				module: device.createShaderModule({ code: compositeShader }),
				entryPoint: "vs"
			},
			fragment: {
				module: device.createShaderModule({ code: compositeShader }),
				entryPoint: "fs",
				targets: [{
					format: presentationFormat,
					blend: {
						color: {
							srcFactor: "zero",
							dstFactor: "one-minus-src-alpha",
							operation: "add"
						},
						alpha: {
							srcFactor: "zero",
							dstFactor: "one-minus-src-alpha",
							operation: "add"
						}
					}
				}]
			},
			primitive: { topology: "triangle-list" }
		});
		this.readbackPipeline = device.createComputePipeline({
			layout: "auto",
			compute: {
				module: device.createShaderModule({ code: readbackShader }),
				entryPoint: "main"
			}
		});
	}
	prepareStroke(width, height) {
		if (!this.currentStrokeTexture || this.currentStrokeTexture.width !== width || this.currentStrokeTexture.height !== height) {
			if (this.currentStrokeTexture) this.currentStrokeTexture.destroy();
			this.currentStrokeTexture = this.device.createTexture({
				size: [width, height],
				format: "rgba8unorm",
				usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_SRC
			});
			this.currentStrokeView = this.currentStrokeTexture.createView();
			this.compositeTextureBindGroup = null;
			this.previewTextureBindGroup = null;
			if (this.lastReadbackTexture === this.currentStrokeTexture) {
				this.readbackBindGroup = null;
				this.lastReadbackTexture = null;
			}
		}
		const encoder = this.device.createCommandEncoder();
		encoder.beginRenderPass({ colorAttachments: [{
			view: this.currentStrokeView,
			loadOp: "clear",
			clearValue: {
				r: 0,
				g: 0,
				b: 0,
				a: 0
			},
			storeOp: "store"
		}] }).end();
		this.device.queue.submit([encoder.finish()]);
	}
	renderStrokeToAccumulator(points, settings) {
		if (!this.currentStrokeView) return;
		this.renderStrokeInternal(this.currentStrokeView, this.accumulatePipeline, points, {
			...settings,
			opacity: settings.coverage
		});
	}
	compositeStroke(targetView, settings) {
		if (!this.currentStrokeTexture) return;
		const buffer = /* @__PURE__ */ new ArrayBuffer(UNIFORM_SIZE);
		const f32 = new Float32Array(buffer);
		const u32 = new Uint32Array(buffer);
		f32[0] = settings.color[0];
		f32[1] = settings.color[1];
		f32[2] = settings.color[2];
		f32[3] = settings.opacity;
		f32[4] = settings.hardness;
		f32[5] = 0;
		f32[6] = settings.screenSize[0];
		f32[7] = settings.screenSize[1];
		u32[8] = settings.brushShape;
		this.device.queue.writeBuffer(this.uniformBuffer, 0, buffer);
		const encoder = this.device.createCommandEncoder();
		const pipeline = settings.isErasing ? this.erasePipeline : this.compositePipeline;
		if (!this.compositeTextureBindGroup) this.compositeTextureBindGroup = this.device.createBindGroup({
			layout: this.textureBindGroupLayout,
			entries: [{
				binding: 0,
				resource: this.currentStrokeTexture.createView()
			}]
		});
		const pass = encoder.beginRenderPass({ colorAttachments: [{
			view: targetView,
			loadOp: "load",
			storeOp: "store"
		}] });
		pass.setPipeline(pipeline);
		pass.setBindGroup(0, this.compositeTextureBindGroup);
		pass.setBindGroup(1, this.mainUniformBindGroup);
		pass.draw(3);
		pass.end();
		this.device.queue.submit([encoder.finish()]);
	}
	renderStroke(targetView, points, settings) {
		this.renderStrokeInternal(targetView, this.renderPipeline, points, settings);
	}
	renderStrokeInternal(targetView, pipeline, points, settings) {
		if (points.length === 0) return;
		const buffer = /* @__PURE__ */ new ArrayBuffer(UNIFORM_SIZE);
		const f32 = new Float32Array(buffer);
		const u32 = new Uint32Array(buffer);
		f32[0] = settings.color[0];
		f32[1] = settings.color[1];
		f32[2] = settings.color[2];
		f32[3] = settings.opacity;
		f32[4] = settings.hardness;
		f32[5] = 0;
		f32[6] = settings.width;
		f32[7] = settings.height;
		u32[8] = settings.brushShape;
		this.device.queue.writeBuffer(this.uniformBuffer, 0, buffer);
		let processedPoints = 0;
		while (processedPoints < points.length) {
			const batchSize = Math.min(points.length - processedPoints, MAX_STROKES);
			const iData = new Float32Array(batchSize * 4);
			for (let i = 0; i < batchSize; i++) {
				const p = points[processedPoints + i];
				iData[i * 4 + 0] = p.x;
				iData[i * 4 + 1] = p.y;
				iData[i * 4 + 2] = settings.size;
				iData[i * 4 + 3] = p.pressure;
			}
			this.device.queue.writeBuffer(this.instanceBuffer, 0, iData);
			const encoder = this.device.createCommandEncoder();
			const pass = encoder.beginRenderPass({ colorAttachments: [{
				view: targetView,
				loadOp: "load",
				storeOp: "store"
			}] });
			pass.setPipeline(pipeline);
			pass.setBindGroup(0, this.mainUniformBindGroup);
			pass.setVertexBuffer(0, this.quadVertexBuffer);
			pass.setVertexBuffer(1, this.instanceBuffer);
			pass.setIndexBuffer(this.indexBuffer, "uint16");
			pass.drawIndexed(6, batchSize);
			pass.end();
			this.device.queue.submit([encoder.finish()]);
			processedPoints += batchSize;
		}
	}
	blitToCanvas(destinationCtx, settings, backgroundTexture) {
		const encoder = this.device.createCommandEncoder();
		const destView = destinationCtx.getCurrentTexture().createView();
		if (backgroundTexture) {
			if (this.lastBackgroundTexture !== backgroundTexture || !this.backgroundBindGroup) {
				this.backgroundBindGroup = this.device.createBindGroup({
					layout: this.textureBindGroupLayout,
					entries: [{
						binding: 0,
						resource: backgroundTexture.createView()
					}]
				});
				this.lastBackgroundTexture = backgroundTexture;
			}
			const pass = encoder.beginRenderPass({ colorAttachments: [{
				view: destView,
				loadOp: "clear",
				clearValue: {
					r: 0,
					g: 0,
					b: 0,
					a: 0
				},
				storeOp: "store"
			}] });
			pass.setPipeline(this.blitPipeline);
			pass.setBindGroup(0, this.backgroundBindGroup);
			pass.draw(3);
			pass.end();
		} else encoder.beginRenderPass({ colorAttachments: [{
			view: destView,
			loadOp: "clear",
			clearValue: {
				r: 0,
				g: 0,
				b: 0,
				a: 0
			},
			storeOp: "store"
		}] }).end();
		if (this.currentStrokeTexture) {
			const buffer = /* @__PURE__ */ new ArrayBuffer(UNIFORM_SIZE);
			const f32 = new Float32Array(buffer);
			const u32 = new Uint32Array(buffer);
			f32[0] = settings.color[0];
			f32[1] = settings.color[1];
			f32[2] = settings.color[2];
			f32[3] = settings.opacity;
			f32[4] = settings.hardness;
			f32[5] = 0;
			f32[6] = settings.screenSize[0];
			f32[7] = settings.screenSize[1];
			u32[8] = settings.brushShape;
			this.device.queue.writeBuffer(this.uniformBuffer, 0, buffer);
			const pipeline = settings.isErasing ? this.erasePipelinePreview : this.compositePipelinePreview;
			if (!this.previewTextureBindGroup) this.previewTextureBindGroup = this.device.createBindGroup({
				layout: this.textureBindGroupLayout,
				entries: [{
					binding: 0,
					resource: this.currentStrokeTexture.createView()
				}]
			});
			const passStroke = encoder.beginRenderPass({ colorAttachments: [{
				view: destView,
				loadOp: "load",
				storeOp: "store"
			}] });
			passStroke.setPipeline(pipeline);
			passStroke.setBindGroup(0, this.previewTextureBindGroup);
			passStroke.setBindGroup(1, this.mainUniformBindGroup);
			passStroke.draw(3);
			passStroke.end();
		}
		this.device.queue.submit([encoder.finish()]);
	}
	clearPreview(destinationCtx) {
		const encoder = this.device.createCommandEncoder();
		encoder.beginRenderPass({ colorAttachments: [{
			view: destinationCtx.getCurrentTexture().createView(),
			loadOp: "clear",
			clearValue: {
				r: 0,
				g: 0,
				b: 0,
				a: 0
			},
			storeOp: "store"
		}] }).end();
		this.device.queue.submit([encoder.finish()]);
	}
	prepareReadback(texture, outputBuffer) {
		if (this.lastReadbackTexture !== texture || this.lastReadbackBuffer !== outputBuffer || !this.readbackBindGroup) {
			this.readbackBindGroup = this.device.createBindGroup({
				layout: this.readbackPipeline.getBindGroupLayout(0),
				entries: [{
					binding: 0,
					resource: texture.createView()
				}, {
					binding: 1,
					resource: { buffer: outputBuffer }
				}]
			});
			this.lastReadbackTexture = texture;
			this.lastReadbackBuffer = outputBuffer;
		}
		const encoder = this.device.createCommandEncoder();
		const pass = encoder.beginComputePass();
		pass.setPipeline(this.readbackPipeline);
		pass.setBindGroup(0, this.readbackBindGroup);
		const width = texture.width;
		const height = texture.height;
		pass.dispatchWorkgroups(Math.ceil(width / 8), Math.ceil(height / 8));
		pass.end();
		this.device.queue.submit([encoder.finish()]);
	}
	destroy() {
		this.quadVertexBuffer.destroy();
		this.indexBuffer.destroy();
		this.instanceBuffer.destroy();
		this.uniformBuffer.destroy();
		if (this.currentStrokeTexture) this.currentStrokeTexture.destroy();
		this.compositeTextureBindGroup = null;
		this.previewTextureBindGroup = null;
		this.readbackBindGroup = null;
		this.backgroundBindGroup = null;
		this.lastReadbackTexture = null;
		this.lastReadbackBuffer = null;
		this.lastBackgroundTexture = null;
	}
};
//#endregion
//#region packages/mask-editor/src/gpuUtils.ts
/**
* Computes the clamped dirty-rect coordinates for a putImageData call.
*
* Returns the full canvas dimensions when the dirty rect is uninitialised
* (Infinity sentinels) or the resulting area has zero/negative size.
*/
function clampDirtyRect(rect, canvasWidth, canvasHeight) {
	const full = {
		dx: 0,
		dy: 0,
		dw: canvasWidth,
		dh: canvasHeight
	};
	if (rect.minX === Infinity || rect.maxX === -Infinity) return full;
	const dx = Math.floor(Math.max(0, rect.minX));
	const dy = Math.floor(Math.max(0, rect.minY));
	const dw = Math.ceil(Math.min(canvasWidth, rect.maxX)) - dx;
	const dh = Math.ceil(Math.min(canvasHeight, rect.maxY)) - dy;
	return dw > 0 && dh > 0 ? {
		dx,
		dy,
		dw,
		dh
	} : full;
}
/**
* Linearly interpolates a sequence of points at a fixed step size,
* returning GPU-ready stroke points with pressure=1.
*
* When skipResampling is true the input points are returned as-is (used
* during live preview where the caller has already handled spacing).
*/
function buildStrokePoints(points, skipResampling, stepSize) {
	if (skipResampling) return points.map((p) => ({
		x: p.x,
		y: p.y,
		pressure: 1
	}));
	const result = [];
	for (let i = 0; i < points.length - 1; i++) {
		const p1 = points[i];
		const p2 = points[i + 1];
		const steps = Math.max(1, Math.ceil(Math.hypot(p2.x - p1.x, p2.y - p1.y) / stepSize));
		for (let s = 0; s <= steps; s++) {
			const t = s / steps;
			result.push({
				x: p1.x + (p2.x - p1.x) * t,
				y: p1.y + (p2.y - p1.y) * t,
				pressure: 1
			});
		}
	}
	return result;
}
//#endregion
//#region packages/mask-editor/src/useGPUResources.ts
function useGPUResources() {
	const store = useMaskEditorStore();
	let maskTexture = null;
	let rgbTexture = null;
	let device = null;
	let renderer = null;
	let previewContext = null;
	let readbackStorageMask = null;
	let readbackStorageRgb = null;
	let readbackStagingMask = null;
	let readbackStagingRgb = null;
	let currentBufferSize = 0;
	const previewCanvas = ref(null);
	const isSavingHistory = ref(false);
	const dirtyRect = ref(resetDirtyRect());
	const hasRenderer = ref(false);
	const isRecreatingTextures = ref(false);
	watch(() => store.clearTrigger, () => clearGPU());
	watch(() => store.canvasHistory.currentStateIndex, async () => {
		if (isSavingHistory.value) return;
		await updateGPUFromCanvas();
		if (renderer && previewContext) renderer.clearPreview(previewContext);
	});
	watch(() => store.gpuTexturesNeedRecreation, async (needsRecreation) => {
		if (!needsRecreation || !device || !store.maskCanvas || isRecreatingTextures.value) return;
		/* c8 ignore start */
		isRecreatingTextures.value = true;
		const width = store.gpuTextureWidth;
		const height = store.gpuTextureHeight;
		try {
			maskTexture?.destroy();
			maskTexture = null;
			rgbTexture?.destroy();
			rgbTexture = null;
			maskTexture = (globalThis.__TYPEGPU_AUTONAME__ ?? ((a) => a))(createTexture(device, width, height), "maskTexture");
			rgbTexture = (globalThis.__TYPEGPU_AUTONAME__ ?? ((a) => a))(createTexture(device, width, height), "rgbTexture");
			if (store.pendingGPUMaskData && store.pendingGPURgbData) {
				device.queue.writeTexture({ texture: maskTexture }, store.pendingGPUMaskData, { bytesPerRow: width * 4 }, {
					width,
					height
				});
				device.queue.writeTexture({ texture: rgbTexture }, store.pendingGPURgbData, { bytesPerRow: width * 4 }, {
					width,
					height
				});
			} else await updateGPUFromCanvas();
			if (previewCanvas.value && renderer) {
				previewCanvas.value.width = width;
				previewCanvas.value.height = height;
			}
			resizeReadbackBuffers(device, width, height);
		} catch (error) {
			console.error("[useGPUResources] Failed to recreate GPU textures:", error);
		} finally {
			store.gpuTexturesNeedRecreation = false;
			store.gpuTextureWidth = 0;
			store.gpuTextureHeight = 0;
			store.pendingGPUMaskData = null;
			store.pendingGPURgbData = null;
			isRecreatingTextures.value = false;
		}
		/* c8 ignore stop */
	});
	onUnmounted(() => {
		// c8 ignore start
		renderer?.destroy();
		renderer = null;
		hasRenderer.value = false;
		maskTexture?.destroy();
		maskTexture = null;
		rgbTexture?.destroy();
		rgbTexture = null;
		readbackStorageMask?.destroy();
		readbackStorageMask = null;
		readbackStorageRgb?.destroy();
		readbackStorageRgb = null;
		readbackStagingMask?.destroy();
		readbackStagingMask = null;
		readbackStagingRgb?.destroy();
		readbackStagingRgb = null;
		previewContext = null;
		previewCanvas.value = null;
		dirtyRect.value = resetDirtyRect();
		// c8 ignore stop
	});
	/* c8 ignore start — requires a live GPUDevice */
	function createTexture(gpuDevice, width, height) {
		return gpuDevice.createTexture({
			size: [width, height],
			format: "rgba8unorm",
			usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.STORAGE_BINDING | GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.COPY_DST | GPUTextureUsage.COPY_SRC
		});
	}
	function resizeReadbackBuffers(gpuDevice, width, height) {
		const bufferSize = width * height * 4;
		if (currentBufferSize === bufferSize) return;
		readbackStorageMask?.destroy();
		readbackStorageRgb?.destroy();
		readbackStagingMask?.destroy();
		readbackStagingRgb?.destroy();
		readbackStorageMask = (globalThis.__TYPEGPU_AUTONAME__ ?? ((a) => a))(gpuDevice.createBuffer({
			size: bufferSize,
			usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC
		}), "readbackStorageMask");
		readbackStorageRgb = (globalThis.__TYPEGPU_AUTONAME__ ?? ((a) => a))(gpuDevice.createBuffer({
			size: bufferSize,
			usage: GPUBufferUsage.STORAGE | GPUBufferUsage.COPY_SRC
		}), "readbackStorageRgb");
		readbackStagingMask = (globalThis.__TYPEGPU_AUTONAME__ ?? ((a) => a))(gpuDevice.createBuffer({
			size: bufferSize,
			usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ
		}), "readbackStagingMask");
		readbackStagingRgb = (globalThis.__TYPEGPU_AUTONAME__ ?? ((a) => a))(gpuDevice.createBuffer({
			size: bufferSize,
			usage: GPUBufferUsage.COPY_DST | GPUBufferUsage.MAP_READ
		}), "readbackStagingRgb");
		currentBufferSize = bufferSize;
	}
	/* c8 ignore stop */
	async function initTypeGPU() {
		if (store.tgpuRoot) {
			/* c8 ignore start */
			device = store.tgpuRoot.device;
			return;
		}
		try {
			/* c8 ignore start — requires functional WebGPU hardware */
			const root = await Co.init();
			store.tgpuRoot = root;
			device = root.device;
			console.warn("✅ TypeGPU initialized! Root:", root);
			console.warn("Device info:", root.device.limits);
		} catch (error) {
			const message = error instanceof Error ? error.message : String(error);
			console.warn("Failed to initialize TypeGPU:", message);
		}
	}
	async function updateGPUFromCanvas() {
		if (!device || !maskTexture || !rgbTexture || !store.maskCanvas || !store.maskCtx || !store.rgbCtx) return;
		/* c8 ignore start — requires live GPU device and textures */
		const w = store.maskCanvas.width;
		const h = store.maskCanvas.height;
		const maskData = store.maskCtx.getImageData(0, 0, w, h);
		premultiplyData(maskData.data);
		device.queue.writeTexture({ texture: maskTexture }, maskData.data, { bytesPerRow: w * 4 }, {
			width: w,
			height: h
		});
		const rgbData = store.rgbCtx.getImageData(0, 0, w, h);
		premultiplyData(rgbData.data);
		device.queue.writeTexture({ texture: rgbTexture }, rgbData.data, { bytesPerRow: w * 4 }, {
			width: w,
			height: h
		});
		/* c8 ignore stop */
	}
	async function initGPUResources() {
		await initTypeGPU();
		if (!store.tgpuRoot || !device) {
			console.warn("TypeGPU not initialized, skipping GPU resource setup");
			return;
		}
		if (!store.maskCanvas || !store.rgbCanvas || !store.maskCtx || !store.rgbCtx) {
			console.warn("Canvas contexts not ready, skipping GPU resource setup");
			return;
		}
		const w = store.maskCanvas.width;
		const h = store.maskCanvas.height;
		/* c8 ignore start — requires functional WebGPU hardware */
		try {
			console.warn(`🎨 Initializing GPU resources for ${w}x${h} canvas`);
			maskTexture = (globalThis.__TYPEGPU_AUTONAME__ ?? ((a) => a))(createTexture(device, w, h), "maskTexture");
			rgbTexture = (globalThis.__TYPEGPU_AUTONAME__ ?? ((a) => a))(createTexture(device, w, h), "rgbTexture");
			await updateGPUFromCanvas();
			console.warn("✅ GPU resources initialized successfully");
			renderer = new GPUBrushRenderer(device, navigator.gpu.getPreferredCanvasFormat());
			hasRenderer.value = true;
			console.warn("✅ Brush renderer initialized");
		} catch (error) {
			console.error("Failed to initialize GPU resources:", error);
			maskTexture = null;
			rgbTexture = null;
		}
		/* c8 ignore stop */
	}
	function initPreviewCanvas(canvas) {
		if (!device) return;
		/* c8 ignore start — requires live GPUDevice and WebGPU canvas context */
		const ctx = canvas.getContext("webgpu");
		if (!ctx) return;
		ctx.configure({
			device,
			format: navigator.gpu.getPreferredCanvasFormat(),
			alphaMode: "premultiplied"
		});
		previewContext = ctx;
		previewCanvas.value = canvas;
		console.warn("✅ Preview Canvas Initialized");
		/* c8 ignore stop */
	}
	function clearGPU() {
		if (!device || !maskTexture || !rgbTexture || !store.maskCanvas) return;
		/* c8 ignore start — requires live GPUDevice and textures */
		const w = store.maskCanvas.width;
		const h = store.maskCanvas.height;
		const zeros = new Uint8Array(w * h * 4);
		device.queue.writeTexture({ texture: maskTexture }, zeros, { bytesPerRow: w * 4 }, {
			width: w,
			height: h
		});
		device.queue.writeTexture({ texture: rgbTexture }, zeros, { bytesPerRow: w * 4 }, {
			width: w,
			height: h
		});
		/* c8 ignore stop */
	}
	function destroy() {
		renderer?.destroy();
		maskTexture?.destroy();
		rgbTexture?.destroy();
		readbackStorageMask?.destroy();
		readbackStorageRgb?.destroy();
		readbackStagingMask?.destroy();
		readbackStagingRgb?.destroy();
		renderer = null;
		hasRenderer.value = false;
		maskTexture = null;
		rgbTexture = null;
		readbackStorageMask = null;
		readbackStorageRgb = null;
		readbackStagingMask = null;
		readbackStagingRgb = null;
		currentBufferSize = 0;
		previewContext = null;
		previewCanvas.value = null;
		dirtyRect.value = resetDirtyRect();
		/* c8 ignore next — tgpuRoot only exists after successful GPU init */
		if (store.tgpuRoot) {
			store.tgpuRoot.destroy();
			store.tgpuRoot = null;
		}
		device = null;
	}
	function prepareStroke() {
		if (!renderer || !store.maskCanvas) return;
		/* c8 ignore next */
		renderer.prepareStroke(store.maskCanvas.width, store.maskCanvas.height);
	}
	function clearPreview() {
		if (!renderer || !previewContext) return;
		/* c8 ignore next */
		renderer.clearPreview(previewContext);
	}
	function compositeStroke(isRgb, isErasing) {
		if (!renderer || !maskTexture || !rgbTexture || !store.maskCanvas) return;
		/* c8 ignore start — requires live renderer */
		const targetTex = isRgb ? rgbTexture : maskTexture;
		const { size, hardness, opacity, type } = store.brushSettings;
		const effectiveSize = getEffectiveBrushSize(size, hardness);
		const effectiveHardness = getEffectiveHardness(size, hardness, effectiveSize);
		const brushShape = type === BrushShape.Rect ? 1 : 0;
		renderer.compositeStroke(targetTex.createView(), {
			opacity,
			color: [
				0,
				0,
				0
			],
			hardness: effectiveHardness,
			screenSize: [store.maskCanvas.width, store.maskCanvas.height],
			brushShape,
			isErasing
		});
		/* c8 ignore stop */
	}
	async function copyGpuToCanvas() {
		if (!device || !maskTexture || !rgbTexture || !store.maskCanvas || !store.rgbCanvas || !store.maskCtx || !store.rgbCtx || !renderer) throw new Error("GPU resources not ready");
		/* c8 ignore start — requires live GPU device, textures and renderer */
		const width = store.maskCanvas.width;
		const height = store.maskCanvas.height;
		resizeReadbackBuffers(device, width, height);
		renderer.prepareReadback(maskTexture, readbackStorageMask);
		renderer.prepareReadback(rgbTexture, readbackStorageRgb);
		const encoder = device.createCommandEncoder();
		encoder.copyBufferToBuffer(readbackStorageMask, 0, readbackStagingMask, 0, currentBufferSize);
		encoder.copyBufferToBuffer(readbackStorageRgb, 0, readbackStagingRgb, 0, currentBufferSize);
		device.queue.submit([encoder.finish()]);
		await Promise.all([readbackStagingMask.mapAsync(GPUMapMode.READ), readbackStagingRgb.mapAsync(GPUMapMode.READ)]);
		const maskDataArr = new Uint8ClampedArray(readbackStagingMask.getMappedRange().slice(0));
		const rgbDataArr = new Uint8ClampedArray(readbackStagingRgb.getMappedRange().slice(0));
		readbackStagingMask.unmap();
		readbackStagingRgb.unmap();
		const maskImageData = new ImageData(maskDataArr, width, height);
		const rgbImageData = new ImageData(rgbDataArr, width, height);
		const { dx, dy, dw, dh } = clampDirtyRect(dirtyRect.value, width, height);
		store.maskCtx.putImageData(maskImageData, 0, 0, dx, dy, dw, dh);
		store.rgbCtx.putImageData(rgbImageData, 0, 0, dx, dy, dw, dh);
		return {
			maskData: maskImageData,
			rgbData: rgbImageData
		};
		/* c8 ignore stop */
	}
	function gpuRender(points, skipResampling = false) {
		if (!renderer || !maskTexture || !rgbTexture) return;
		/* c8 ignore start — requires live renderer */
		const isRgb = store.activeLayer === "rgb";
		const color = resolveColor(isRgb);
		const stepPercentage = Math.pow(100, store.brushSettings.stepSize / 100) / 100;
		const strokePoints = buildStrokePoints(points, skipResampling, Math.max(1, store.brushSettings.size * stepPercentage));
		const { size, hardness } = store.brushSettings;
		const effectiveSize = getEffectiveBrushSize(size, hardness);
		const effectiveHardness = getEffectiveHardness(size, hardness, effectiveSize);
		const brushShape = store.brushSettings.type === BrushShape.Rect ? 1 : 0;
		renderer.renderStrokeToAccumulator(strokePoints, {
			size: effectiveSize,
			coverage: 1,
			hardness: effectiveHardness,
			color,
			width: store.maskCanvas.width,
			height: store.maskCanvas.height,
			brushShape
		});
		for (const p of strokePoints) dirtyRect.value = updateDirtyRect(dirtyRect.value, p.x, p.y, effectiveSize);
		if (previewContext) {
			const isErasing = store.currentTool === "eraser" || store.maskCtx?.globalCompositeOperation === "destination-out";
			const targetTex = isRgb ? rgbTexture : maskTexture;
			renderer.blitToCanvas(previewContext, {
				opacity: store.brushSettings.opacity,
				color,
				hardness: effectiveHardness,
				screenSize: [store.maskCanvas.width, store.maskCanvas.height],
				brushShape,
				isErasing
			}, targetTex);
		}
		/* c8 ignore stop */
	}
	async function gpuDrawPoint(point, opacity = 1) {
		if (!renderer) return;
		/* c8 ignore start — requires live renderer */
		const width = store.maskCanvas.width;
		const height = store.maskCanvas.height;
		const { size, hardness } = store.brushSettings;
		const effectiveSize = getEffectiveBrushSize(size, hardness);
		const effectiveHardness = getEffectiveHardness(size, hardness, effectiveSize);
		const brushShape = store.brushSettings.type === BrushShape.Rect ? 1 : 0;
		dirtyRect.value = updateDirtyRect(dirtyRect.value, point.x, point.y, effectiveSize);
		renderer.renderStrokeToAccumulator([{
			x: point.x,
			y: point.y,
			pressure: opacity
		}], {
			size: effectiveSize,
			coverage: 1,
			hardness: effectiveHardness,
			color: [
				1,
				1,
				1
			],
			width,
			height,
			brushShape
		});
		if (maskTexture && previewContext) {
			const isRgb = store.activeLayer === "rgb";
			const isErasing = store.currentTool === "eraser" || store.maskCtx?.globalCompositeOperation === "destination-out";
			renderer.blitToCanvas(previewContext, {
				opacity: store.brushSettings.opacity,
				color: resolveColor(isRgb),
				hardness: effectiveHardness,
				screenSize: [width, height],
				brushShape,
				isErasing
			}, void 0);
		}
		/* c8 ignore stop */
	}
	/* c8 ignore start — only reachable after successful GPU init */
	function resolveColor(isRgb) {
		if (isRgb) {
			const c = parseToRgb(store.rgbColor);
			return [
				c.r / 255,
				c.g / 255,
				c.b / 255
			];
		}
		const c = store.maskColor;
		return [
			c.r / 255,
			c.g / 255,
			c.b / 255
		];
	}
	/* c8 ignore stop */
	return {
		initGPUResources,
		initPreviewCanvas,
		clearGPU,
		destroy,
		gpuRender,
		gpuDrawPoint,
		copyGpuToCanvas,
		prepareStroke,
		clearPreview,
		compositeStroke,
		hasRenderer,
		previewCanvas,
		isSavingHistory,
		dirtyRect
	};
}
//#endregion
//#region packages/mask-editor/src/useBrushDrawing.ts
function useBrushDrawing(initialSettings) {
	const store = useMaskEditorStore();
	const coordinateTransform = useCoordinateTransform();
	const { startBrushAdjustment, handleBrushAdjustment } = useBrushAdjustment(initialSettings);
	const gpu = useGPUResources();
	const isDrawing = ref(false);
	const isDrawingLine = ref(false);
	const lineStartPoint = ref(null);
	const lineRemainder = ref(0);
	const smoothingLastDrawTime = ref(/* @__PURE__ */ new Date());
	const initialDraw = ref(true);
	let strokeProcessor = null;
	function drawShape(point, overrideOpacity) {
		const brush = store.brushSettings;
		const mask_ctx = store.maskCtx;
		const rgb_ctx = store.rgbCtx;
		if (!mask_ctx || !rgb_ctx) throw new Error("Canvas contexts are required");
		const brushRadius = brush.size;
		const hardness = brush.hardness;
		const opacity = overrideOpacity ?? brush.opacity;
		const effectiveRadius = getEffectiveBrushSize(brushRadius, hardness);
		const effectiveHardness = getEffectiveHardness(brushRadius, hardness, effectiveRadius);
		const isErasing = mask_ctx.globalCompositeOperation === "destination-out";
		const currentTool = store.currentTool;
		if (store.activeLayer === "rgb" && (currentTool === Tools.Eraser || currentTool === Tools.PaintPen)) drawRgbShape(rgb_ctx, point, brush.type, effectiveRadius, effectiveHardness, opacity, store.rgbColor);
		else drawMaskShape(mask_ctx, point, brush.type, effectiveRadius, effectiveHardness, opacity, isErasing, store.maskColor);
		gpu.dirtyRect.value = updateDirtyRect(gpu.dirtyRect.value, point.x, point.y, effectiveRadius);
	}
	function initShape(compositionOperation) {
		const blendMode = store.maskBlendMode;
		const mask_ctx = store.maskCtx;
		const rgb_ctx = store.rgbCtx;
		if (!mask_ctx || !rgb_ctx) throw new Error("Canvas contexts are required");
		mask_ctx.beginPath();
		rgb_ctx.beginPath();
		if (compositionOperation === CompositionOperation.SourceOver) {
			mask_ctx.fillStyle = blendMode;
			mask_ctx.globalCompositeOperation = CompositionOperation.SourceOver;
			rgb_ctx.globalCompositeOperation = CompositionOperation.SourceOver;
		} else {
			mask_ctx.globalCompositeOperation = CompositionOperation.DestinationOut;
			rgb_ctx.globalCompositeOperation = CompositionOperation.DestinationOut;
		}
	}
	async function drawWithBetterSmoothing(point) {
		if (!strokeProcessor) return;
		const newPoints = strokeProcessor.addPoint(point);
		if (newPoints.length === 0) {
			if (gpu.hasRenderer.value && initialDraw.value)
 /* c8 ignore next */
			gpu.gpuRender([], true);
			return;
		}
		if (gpu.hasRenderer.value)
 /* c8 ignore next */
		gpu.gpuRender(newPoints, true);
		else for (const p of newPoints) drawShape(p);
		initialDraw.value = false;
	}
	async function drawLine(p1, p2, compositionOp, spacing) {
		const { points, remainder } = resampleSegment([p1, p2], spacing, lineRemainder.value);
		lineRemainder.value = remainder;
		initShape(compositionOp);
		if (gpu.hasRenderer.value)
 /* c8 ignore next */
		gpu.gpuRender(points);
		else for (const point of points) drawShape(point, 1);
	}
	async function startDrawing(event) {
		isDrawing.value = true;
		gpu.dirtyRect.value = resetDirtyRect();
		try {
			gpu.prepareStroke();
			const currentTool = store.currentTool;
			const coords = {
				x: event.offsetX,
				y: event.offsetY
			};
			const coords_canvas = coordinateTransform.screenToCanvas(coords);
			const compositionOp = currentTool === "eraser" || event.buttons === 2 ? CompositionOperation.DestinationOut : CompositionOperation.SourceOver;
			const stepPercentage = Math.pow(100, store.brushSettings.stepSize / 100) / 100;
			const targetSpacing = Math.max(1, store.brushSettings.size * stepPercentage);
			if (event.shiftKey && lineStartPoint.value) {
				isDrawingLine.value = true;
				await drawLine(lineStartPoint.value, coords_canvas, compositionOp, targetSpacing);
			} else {
				isDrawingLine.value = false;
				initShape(compositionOp);
				lineRemainder.value = targetSpacing;
			}
			lineStartPoint.value = coords_canvas;
			if (gpu.hasRenderer.value && gpu.previewCanvas.value) {
				/* c8 ignore start */
				const isRgb = store.activeLayer === "rgb";
				if (isRgb && store.rgbCanvas) {
					store.rgbCanvas.style.opacity = "0";
					gpu.previewCanvas.value.style.opacity = "1";
				} else if (!isRgb && store.maskCanvas) {
					store.maskCanvas.style.opacity = "0";
					gpu.previewCanvas.value.style.opacity = String(store.maskOpacity);
				}
			}
			strokeProcessor = new StrokeProcessor(targetSpacing);
			await drawWithBetterSmoothing(coords_canvas);
			smoothingLastDrawTime.value = /* @__PURE__ */ new Date();
		} catch (error) {
			/* c8 ignore start */
			const isRgb = store.activeLayer === "rgb";
			if (isRgb && store.rgbCanvas) store.rgbCanvas.style.opacity = "1";
			else if (!isRgb && store.maskCanvas) store.maskCanvas.style.opacity = String(store.maskOpacity);
			if (gpu.previewCanvas.value) gpu.previewCanvas.value.style.opacity = "1";
			gpu.clearPreview();
			/* c8 ignore stop */
			console.error("[useBrushDrawing] Failed to start drawing:", error);
			isDrawing.value = false;
			isDrawingLine.value = false;
		}
	}
	async function handleDrawing(event) {
		const diff = performance.now() - smoothingLastDrawTime.value.getTime();
		const coords = {
			x: event.offsetX,
			y: event.offsetY
		};
		const coords_canvas = coordinateTransform.screenToCanvas(coords);
		const currentTool = store.currentTool;
		if (diff > 20 && !isDrawing.value) requestAnimationFrame(async () => {
			if (!isDrawing.value) return;
			try {
				initShape(CompositionOperation.SourceOver);
				if (gpu.hasRenderer.value) await gpu.gpuDrawPoint(coords_canvas);
				else drawShape(coords_canvas);
			} catch (error) {
				console.error("[useBrushDrawing] Drawing error:", error);
			}
		});
		else requestAnimationFrame(async () => {
			if (!isDrawing.value) return;
			try {
				if (currentTool === "eraser" || event.buttons === 2) initShape(CompositionOperation.DestinationOut);
				else initShape(CompositionOperation.SourceOver);
				await drawWithBetterSmoothing(coords_canvas);
			} catch (error) {
				console.error("[useBrushDrawing] Drawing error:", error);
			}
		});
		smoothingLastDrawTime.value = /* @__PURE__ */ new Date();
	}
	async function drawEnd(event) {
		const coords = {
			x: event.offsetX,
			y: event.offsetY
		};
		const coords_canvas = coordinateTransform.screenToCanvas(coords);
		if (!isDrawing.value) return;
		isDrawing.value = false;
		lineStartPoint.value = coords_canvas;
		initialDraw.value = true;
		if (strokeProcessor) {
			const finalPoints = strokeProcessor.endStroke();
			if (finalPoints.length > 0) {
				if (gpu.hasRenderer.value)
 /* c8 ignore next */
				gpu.gpuRender(finalPoints, true);
				else for (const p of finalPoints) drawShape(p);
			}
			strokeProcessor = null;
		}
		const isRgb = store.activeLayer === "rgb";
		const isErasing = store.currentTool === "eraser" || store.maskCtx?.globalCompositeOperation === "destination-out";
		gpu.compositeStroke(isRgb, isErasing);
		let maskData;
		let rgbData;
		if (gpu.hasRenderer.value)
 /* c8 ignore start */
		try {
			const result = await gpu.copyGpuToCanvas();
			maskData = result.maskData;
			rgbData = result.rgbData;
		} catch (error) {
			console.warn("GPU readback failed, falling back to CPU:", error);
		}
		gpu.isSavingHistory.value = true;
		try {
			store.canvasHistory.saveState(maskData, rgbData);
			await nextTick();
		} finally {
			gpu.isSavingHistory.value = false;
		}
		gpu.clearPreview();
		if (isRgb && store.rgbCanvas) store.rgbCanvas.style.opacity = "1";
		else if (!isRgb && store.maskCanvas) store.maskCanvas.style.opacity = String(store.maskOpacity);
		if (gpu.previewCanvas.value) gpu.previewCanvas.value.style.opacity = "1";
	}
	return {
		startDrawing,
		handleDrawing,
		drawEnd,
		startBrushAdjustment,
		handleBrushAdjustment,
		destroy: gpu.destroy,
		initGPUResources: gpu.initGPUResources,
		initPreviewCanvas: gpu.initPreviewCanvas,
		clearGPU: gpu.clearGPU
	};
}
//#endregion
//#region packages/mask-editor/src/useToolManager.ts
function useToolManager(keyboard, panZoom, brushAdjustment) {
	const store = useMaskEditorStore();
	const coordinateTransform = useCoordinateTransform();
	const brushDrawing = useBrushDrawing(brushAdjustment);
	const canvasTools = useCanvasTools();
	const mouseDownPoint = ref(null);
	const toolSettings = {
		[Tools.MaskPen]: { newActiveLayerOnSet: "mask" },
		[Tools.Eraser]: {},
		[Tools.PaintPen]: { newActiveLayerOnSet: "rgb" },
		[Tools.MaskBucket]: {
			cursor: "url('/cursor/paintBucket.png') 30 25, auto",
			newActiveLayerOnSet: "mask"
		},
		[Tools.MaskColorFill]: {
			cursor: "url('/cursor/colorSelect.png') 15 25, auto",
			newActiveLayerOnSet: "mask"
		}
	};
	const setActiveLayer = (layer) => {
		store.activeLayer = layer;
		const currentTool = store.currentTool;
		if ([
			Tools.MaskPen,
			Tools.MaskBucket,
			Tools.MaskColorFill
		].includes(currentTool) && layer === "rgb") switchTool(Tools.PaintPen);
		if (currentTool === Tools.PaintPen && layer === "mask") switchTool(Tools.MaskPen);
	};
	const switchTool = (tool) => {
		store.currentTool = tool;
		const newActiveLayer = toolSettings[tool].newActiveLayerOnSet;
		if (newActiveLayer) store.activeLayer = newActiveLayer;
		const cursor = toolSettings[tool].cursor;
		const pointerZone = store.pointerZone;
		if (cursor && pointerZone) {
			store.brushVisible = false;
			pointerZone.style.cursor = cursor;
		} else if (pointerZone) {
			store.brushVisible = true;
			pointerZone.style.cursor = "none";
		}
	};
	const updateCursor = () => {
		const currentTool = store.currentTool;
		const cursor = toolSettings[currentTool].cursor;
		const pointerZone = store.pointerZone;
		if (cursor && pointerZone) {
			store.brushVisible = false;
			pointerZone.style.cursor = cursor;
		} else if (pointerZone) {
			store.brushVisible = true;
			pointerZone.style.cursor = "none";
		}
		store.brushPreviewGradientVisible = false;
	};
	watch(() => store.currentTool, (newTool) => {
		if (newTool !== Tools.MaskColorFill) canvasTools.clearLastColorSelectPoint();
	});
	const handlePointerDown = async (event) => {
		event.preventDefault();
		if (event.pointerType === "touch") return;
		if (event.pointerType === "pen") panZoom.addPenPointerId(event.pointerId);
		if (shouldStartPan(event)) {
			panZoom.handlePanStart(event);
			store.brushVisible = false;
			return;
		}
		if (store.currentTool === Tools.PaintPen && event.button === 0) {
			await brushDrawing.startDrawing(event);
			return;
		}
		if (store.currentTool === Tools.PaintPen && event.buttons === 1) {
			await brushDrawing.handleDrawing(event);
			return;
		}
		if (store.currentTool === Tools.MaskBucket && event.button === 0) {
			const offset = {
				x: event.offsetX,
				y: event.offsetY
			};
			const coords_canvas = coordinateTransform.screenToCanvas(offset);
			canvasTools.paintBucketFill(coords_canvas);
			return;
		}
		if (store.currentTool === Tools.MaskColorFill && event.button === 0) {
			const offset = {
				x: event.offsetX,
				y: event.offsetY
			};
			const coords_canvas = coordinateTransform.screenToCanvas(offset);
			await canvasTools.colorSelectFill(coords_canvas);
			return;
		}
		if (event.altKey && event.button === 2) {
			store.isAdjustingBrush = true;
			await brushDrawing.startBrushAdjustment(event);
			return;
		}
		const isDrawingTool = [
			Tools.MaskPen,
			Tools.Eraser,
			Tools.PaintPen
		].includes(store.currentTool);
		if ([0, 2].includes(event.button) && isDrawingTool) {
			await brushDrawing.startDrawing(event);
			return;
		}
	};
	const handlePointerMove = async (event) => {
		event.preventDefault();
		if (event.pointerType === "touch") return;
		const newCursorPoint = {
			x: event.clientX,
			y: event.clientY
		};
		panZoom.updateCursorPosition(newCursorPoint);
		if (shouldContinuePan(event)) {
			await panZoom.handlePanMove(event);
			return;
		}
		if (![
			Tools.MaskPen,
			Tools.Eraser,
			Tools.PaintPen
		].includes(store.currentTool)) return;
		if (store.isAdjustingBrush && (store.currentTool === Tools.MaskPen || store.currentTool === Tools.Eraser) && event.altKey && event.buttons === 2) {
			await brushDrawing.handleBrushAdjustment(event);
			return;
		}
		if (event.buttons === 1 || event.buttons === 2) {
			await brushDrawing.handleDrawing(event);
			return;
		}
	};
	const handlePointerUp = async (event) => {
		store.isPanning = false;
		store.brushVisible = true;
		if (event.pointerType === "pen") panZoom.removePenPointerId(event.pointerId);
		if (event.pointerType === "touch") return;
		updateCursor();
		store.isAdjustingBrush = false;
		await brushDrawing.drawEnd(event);
		mouseDownPoint.value = null;
	};
	function isLeftButtonSpacePan(event) {
		return event.buttons === 1 && keyboard.isKeyDown(" ");
	}
	function shouldStartPan(event) {
		return isMiddlePointerInput(event) || isLeftButtonSpacePan(event);
	}
	function shouldContinuePan(event) {
		return isMiddleButtonHeld(event) || isLeftButtonSpacePan(event);
	}
	return {
		switchTool,
		setActiveLayer,
		updateCursor,
		handlePointerDown,
		handlePointerMove,
		handlePointerUp,
		brushDrawing
	};
}
//#endregion
//#region src/renderer/extensions/maskEditor/components/BrushCursor.vue
var BrushCursor_default = /* @__PURE__ */ defineComponent({
	__name: "BrushCursor",
	props: { containerRef: {} },
	setup(__props) {
		const store = useMaskEditorStore();
		const { left: containerOffsetLeft, top: containerOffsetTop, update: updateContainerOffset } = useElementBounding(() => __props.containerRef);
		watch(() => store.cursorPoint, updateContainerOffset, { flush: "sync" });
		const brushOpacity = computed(() => {
			return store.brushVisible ? 1 : 0;
		});
		const brushRadius = computed(() => {
			const size = store.brushSettings.size;
			const hardness = store.brushSettings.hardness;
			return getEffectiveBrushSize(size, hardness) * store.zoomRatio;
		});
		const brushSize = computed(() => {
			return brushRadius.value * 2;
		});
		const brushLeft = computed(() => {
			return store.cursorPoint.x + store.panOffset.x - brushRadius.value - containerOffsetLeft.value;
		});
		const brushTop = computed(() => {
			return store.cursorPoint.y + store.panOffset.y - brushRadius.value - containerOffsetTop.value;
		});
		const borderRadius = computed(() => {
			return store.brushSettings.type === BrushShape.Rect ? "0%" : "50%";
		});
		const gradientVisible = computed(() => {
			return store.brushPreviewGradientVisible;
		});
		const gradientBackground = computed(() => {
			const size = store.brushSettings.size;
			const hardness = store.brushSettings.hardness;
			const effectiveSize = getEffectiveBrushSize(size, hardness);
			const effectiveHardness = getEffectiveHardness(size, hardness, effectiveSize);
			if (effectiveHardness === 1) return "rgba(255, 0, 0, 0.5)";
			const midStop = effectiveHardness * 100;
			const outerStop = 100;
			return `radial-gradient(
    circle,
    rgba(255, 0, 0, 0.5) 0%,
    rgba(255, 0, 0, 0.5) ${midStop}%,
    rgba(255, 0, 0, 0.125) ${midStop + (outerStop - midStop) * .5}%,
    rgba(255, 0, 0, 0) ${outerStop}%
  )`;
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				id: "maskEditor_brush",
				"data-testid": "brush-cursor",
				style: normalizeStyle({
					position: "absolute",
					opacity: brushOpacity.value,
					width: `${brushSize.value}px`,
					height: `${brushSize.value}px`,
					left: `${brushLeft.value}px`,
					top: `${brushTop.value}px`,
					borderRadius: borderRadius.value,
					pointerEvents: "none",
					zIndex: 1e3
				})
			}, [createBaseVNode("div", {
				id: "maskEditor_brushPreviewGradient",
				"data-testid": "brush-cursor-gradient",
				style: normalizeStyle({
					display: gradientVisible.value ? "block" : "none",
					background: gradientBackground.value
				})
			}, null, 4)], 4);
		};
	}
});
//#endregion
//#region src/renderer/extensions/maskEditor/components/PointerZone.vue
var PointerZone_default = /* @__PURE__ */ defineComponent({
	__name: "PointerZone",
	props: {
		toolManager: {},
		panZoom: {}
	},
	setup(__props) {
		const store = useMaskEditorStore();
		const pointerZoneRef = ref();
		onMounted(() => {
			if (!pointerZoneRef.value) {
				console.error("[PointerZone] Pointer zone ref not initialized");
				return;
			}
			store.pointerZone = pointerZoneRef.value;
		});
		watch(() => store.isPanning, (isPanning) => {
			if (!pointerZoneRef.value) return;
			if (isPanning) pointerZoneRef.value.style.cursor = "grabbing";
			else __props.toolManager.updateCursor();
		});
		const handlePointerDown = async (event) => {
			await __props.toolManager.handlePointerDown(event);
		};
		const handlePointerMove = async (event) => {
			await __props.toolManager.handlePointerMove(event);
		};
		const handlePointerUp = (event) => {
			__props.toolManager.handlePointerUp(event);
		};
		const handlePointerLeave = () => {
			store.brushVisible = false;
			if (pointerZoneRef.value) pointerZoneRef.value.style.cursor = "";
		};
		const handlePointerEnter = () => {
			__props.toolManager.updateCursor();
		};
		const handleTouchStart = (event) => {
			__props.panZoom.handleTouchStart(event);
		};
		const handleTouchMove = async (event) => {
			await __props.panZoom.handleTouchMove(event);
		};
		const handleTouchEnd = (event) => {
			__props.panZoom.handleTouchEnd(event);
		};
		const handleWheel = async (event) => {
			await __props.panZoom.zoom(event);
			const newCursorPoint = {
				x: event.clientX,
				y: event.clientY
			};
			__props.panZoom.updateCursorPosition(newCursorPoint);
		};
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				ref_key: "pointerZoneRef",
				ref: pointerZoneRef,
				"data-testid": "pointer-zone",
				class: "h-full w-[calc(100%-4rem-220px)]",
				onPointerdown: handlePointerDown,
				onPointermove: handlePointerMove,
				onPointerup: handlePointerUp,
				onPointerleave: handlePointerLeave,
				onPointerenter: handlePointerEnter,
				onTouchstart: handleTouchStart,
				onTouchmove: handleTouchMove,
				onTouchend: handleTouchEnd,
				onWheel: withModifiers(handleWheel, ["prevent"]),
				onContextmenu: _cache[0] || (_cache[0] = withModifiers(() => {}, ["prevent"]))
			}, null, 544);
		};
	}
});
//#endregion
//#region src/renderer/extensions/maskEditor/components/controls/SliderControl.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$11 = { class: "flex flex-col gap-3 pb-3" };
var _hoisted_2$11 = { class: "text-left font-sans text-xs text-muted-foreground" };
var _hoisted_3$6 = [
	"min",
	"max",
	"step",
	"value"
];
//#endregion
//#region src/renderer/extensions/maskEditor/components/controls/SliderControl.vue
var SliderControl_default = /* @__PURE__ */ defineComponent({
	__name: "SliderControl",
	props: {
		label: {},
		min: {},
		max: {},
		step: { default: 1 },
		modelValue: {}
	},
	emits: ["update:modelValue"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const onInput = (event) => {
			const value = Number(event.target.value);
			emit("update:modelValue", value);
		};
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$11, [createBaseVNode("span", _hoisted_2$11, toDisplayString(__props.label), 1), createBaseVNode("input", {
				type: "range",
				class: "maskEditor_sidePanelBrushRange",
				min: __props.min,
				max: __props.max,
				step: __props.step,
				value: __props.modelValue,
				onInput
			}, null, 40, _hoisted_3$6)]);
		};
	}
});
//#endregion
//#region src/renderer/extensions/maskEditor/components/ImageLayerSettingsPanel.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$10 = { class: "flex flex-col gap-3 pb-3" };
var _hoisted_2$10 = { class: "mt-2.5 text-center font-sans text-[15px] text-muted-foreground" };
var _hoisted_3$5 = { class: "text-left font-sans text-xs text-muted-foreground" };
var _hoisted_4$5 = { class: "relative -mt-2 -mb-1.5 flex h-[50px] min-h-6 w-full items-center gap-2.5 rounded-[10px]" };
var _hoisted_5$3 = ["value"];
var _hoisted_6$2 = { value: "black" };
var _hoisted_7$2 = { value: "white" };
var _hoisted_8$1 = { value: "negative" };
var _hoisted_9$1 = { class: "text-left font-sans text-xs text-muted-foreground" };
var _hoisted_10$1 = ["checked"];
var _hoisted_11$1 = { class: "maskEditor_sidePanelLayerPreviewContainer" };
var _hoisted_12$1 = {
	viewBox: "0 0 20 20",
	style: {}
};
var _hoisted_13$1 = ["disabled"];
var _hoisted_14$1 = { class: "text-left font-sans text-xs text-muted-foreground" };
var _hoisted_15$1 = ["checked"];
var _hoisted_16$1 = ["disabled"];
var _hoisted_17$1 = { class: "text-left font-sans text-xs text-muted-foreground" };
var _hoisted_18$1 = { class: "relative flex h-[50px] min-h-6 w-full items-center gap-2.5 rounded-[10px] bg-accent" };
var _hoisted_19$1 = ["checked"];
var _hoisted_20$1 = { class: "maskEditor_sidePanelLayerPreviewContainer" };
var _hoisted_21$1 = ["src", "alt"];
//#endregion
//#region src/renderer/extensions/maskEditor/components/ImageLayerSettingsPanel.vue
var ImageLayerSettingsPanel_default = /* @__PURE__ */ defineComponent({
	__name: "ImageLayerSettingsPanel",
	props: { toolManager: {} },
	setup(__props) {
		const { t } = useI18n();
		const store = useMaskEditorStore();
		const canvasManager = useCanvasManager();
		const maskLayerVisible = ref(true);
		const paintLayerVisible = ref(true);
		const baseImageLayerVisible = ref(true);
		const baseImageSrc = computed(() => {
			return store.image?.src ?? "";
		});
		const showLayerButtons = computed(() => {
			return store.currentTool === Tools.Eraser;
		});
		const onMaskLayerVisibilityChange = (event) => {
			const checked = event.target.checked;
			maskLayerVisible.value = checked;
			const maskCanvas = store.maskCanvas;
			if (maskCanvas) maskCanvas.style.opacity = checked ? String(store.maskOpacity) : "0";
		};
		const onPaintLayerVisibilityChange = (event) => {
			const checked = event.target.checked;
			paintLayerVisible.value = checked;
			const rgbCanvas = store.rgbCanvas;
			if (rgbCanvas) rgbCanvas.style.opacity = checked ? "1" : "0";
		};
		const onBaseImageLayerVisibilityChange = (event) => {
			const checked = event.target.checked;
			baseImageLayerVisible.value = checked;
			const imgCanvas = store.imgCanvas;
			if (imgCanvas) imgCanvas.style.opacity = checked ? "1" : "0";
		};
		const onMaskOpacityChange = (value) => {
			store.setMaskOpacity(value);
			const maskCanvas = store.maskCanvas;
			if (maskCanvas) maskCanvas.style.opacity = String(value);
			maskLayerVisible.value = value !== 0;
		};
		const onBlendModeChange = async (event) => {
			const value = event.target.value;
			let blendMode;
			switch (value) {
				case "white":
					blendMode = MaskBlendMode.White;
					break;
				case "negative":
					blendMode = MaskBlendMode.Negative;
					break;
				default: blendMode = MaskBlendMode.Black;
			}
			store.maskBlendMode = blendMode;
			await canvasManager.updateMaskColor();
		};
		const setActiveLayer = (layer) => {
			__props.toolManager?.setActiveLayer(layer);
		};
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$10, [
				createBaseVNode("h3", _hoisted_2$10, toDisplayString(unref(t)("maskEditor.layers")), 1),
				createVNode(SliderControl_default, {
					label: unref(t)("maskEditor.maskOpacity"),
					min: 0,
					max: 1,
					step: .01,
					"model-value": unref(store).maskOpacity,
					"onUpdate:modelValue": onMaskOpacityChange
				}, null, 8, ["label", "model-value"]),
				createBaseVNode("span", _hoisted_3$5, toDisplayString(unref(t)("maskEditor.maskBlendingOptions")), 1),
				createBaseVNode("div", _hoisted_4$5, [createBaseVNode("select", {
					class: "maskEditor_sidePanelDropdown",
					value: unref(store).maskBlendMode,
					onChange: onBlendModeChange
				}, [
					createBaseVNode("option", _hoisted_6$2, toDisplayString(unref(t)("maskEditor.black")), 1),
					createBaseVNode("option", _hoisted_7$2, toDisplayString(unref(t)("maskEditor.white")), 1),
					createBaseVNode("option", _hoisted_8$1, toDisplayString(unref(t)("maskEditor.negative")), 1)
				], 40, _hoisted_5$3)]),
				createBaseVNode("span", _hoisted_9$1, toDisplayString(unref(t)("maskEditor.maskLayer")), 1),
				createBaseVNode("div", {
					class: "relative flex h-[50px] min-h-6 w-full items-center gap-2.5 rounded-[10px] bg-accent",
					style: normalizeStyle({ border: unref(store).activeLayer === "mask" ? "2px solid #007acc" : "none" })
				}, [
					createBaseVNode("input", {
						type: "checkbox",
						class: "maskEditor_sidePanelLayerCheckbox",
						checked: maskLayerVisible.value,
						onChange: onMaskLayerVisibilityChange
					}, null, 40, _hoisted_10$1),
					createBaseVNode("div", _hoisted_11$1, [(openBlock(), createElementBlock("svg", _hoisted_12$1, [..._cache[2] || (_cache[2] = [createBaseVNode("path", {
						class: "cls-1",
						d: "M1.31,5.32v9.36c0,.55.45,1,1,1h15.38c.55,0,1-.45,1-1V5.32c0-.55-.45-1-1-1H2.31c-.55,0-1,.45-1,1ZM11.19,13.44c-2.91.94-5.57-1.72-4.63-4.63.34-1.05,1.19-1.9,2.24-2.24,2.91-.94,5.57,1.72,4.63,4.63-.34,1.05-1.19-1.9-2.24,2.24Z"
					}, null, -1)])]))]),
					createBaseVNode("button", {
						style: normalizeStyle([{ "font-size": "12px" }, { opacity: unref(store).activeLayer === "mask" ? "0.5" : "1" }]),
						disabled: unref(store).activeLayer === "mask",
						onClick: _cache[0] || (_cache[0] = ($event) => setActiveLayer("mask"))
					}, toDisplayString(unref(t)("maskEditor.activateLayer")), 13, _hoisted_13$1)
				], 4),
				createBaseVNode("span", _hoisted_14$1, toDisplayString(unref(t)("maskEditor.paintLayer")), 1),
				createBaseVNode("div", {
					class: "relative flex h-[50px] min-h-6 w-full items-center gap-2.5 rounded-[10px] bg-accent",
					style: normalizeStyle({ border: unref(store).activeLayer === "rgb" ? "2px solid #007acc" : "none" })
				}, [
					createBaseVNode("input", {
						type: "checkbox",
						class: "maskEditor_sidePanelLayerCheckbox",
						checked: paintLayerVisible.value,
						onChange: onPaintLayerVisibilityChange
					}, null, 40, _hoisted_15$1),
					_cache[3] || (_cache[3] = createBaseVNode("div", { class: "maskEditor_sidePanelLayerPreviewContainer" }, [createBaseVNode("svg", { viewBox: "0 0 20 20" }, [createBaseVNode("path", {
						class: "cls-1",
						d: "M 17 6.965 c 0 0.235 -0.095 0.47 -0.275 0.655 l -6.51 6.52 c -0.045 0.035 -0.09 0.075 -0.135 0.11 c -0.035 -0.695 -0.605 -1.24 -1.305 -1.245 c 0.035 -0.06 0.08 -0.12 0.135 -0.17 l 6.52 -6.52 c 0.36 -0.36 0.945 -0.36 1.3 0 c 0.175 0.175 0.275 0.415 0.275 0.65 Z"
					}), createBaseVNode("path", {
						class: "cls-1",
						d: "M 9.82 14.515 c 0 2.23 -3.23 1.59 -4.82 0 c 1.65 -0.235 2.375 -1.29 3.53 -1.29 c 0.715 0 1.29 0.58 1.29 1.29 Z"
					})])], -1)),
					createBaseVNode("button", {
						style: normalizeStyle([{ "font-size": "12px" }, {
							opacity: unref(store).activeLayer === "rgb" ? "0.5" : "1",
							display: showLayerButtons.value ? "block" : "none"
						}]),
						disabled: unref(store).activeLayer === "rgb",
						onClick: _cache[1] || (_cache[1] = ($event) => setActiveLayer("rgb"))
					}, toDisplayString(unref(t)("maskEditor.activateLayer")), 13, _hoisted_16$1)
				], 4),
				createBaseVNode("span", _hoisted_17$1, toDisplayString(unref(t)("maskEditor.baseImageLayer")), 1),
				createBaseVNode("div", _hoisted_18$1, [createBaseVNode("input", {
					type: "checkbox",
					class: "maskEditor_sidePanelLayerCheckbox",
					checked: baseImageLayerVisible.value,
					onChange: onBaseImageLayerVisibilityChange
				}, null, 40, _hoisted_19$1), createBaseVNode("div", _hoisted_20$1, [createBaseVNode("img", {
					class: "maskEditor_sidePanelImageLayerImage",
					src: baseImageSrc.value,
					alt: unref(t)("maskEditor.baseLayerPreview")
				}, null, 8, _hoisted_21$1)])])
			]);
		};
	}
});
//#endregion
//#region src/renderer/extensions/maskEditor/components/BrushSettingsPanel.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$9 = { class: "flex flex-col gap-3 pb-3" };
var _hoisted_2$9 = { class: "mt-2.5 text-center font-sans text-[15px] text-muted-foreground" };
var _hoisted_3$4 = { class: "flex flex-col gap-3 pb-3" };
var _hoisted_4$4 = { class: "text-left font-sans text-xs text-muted-foreground" };
var _hoisted_5$2 = { class: "flex h-[50px] w-full items-center gap-2.5 rounded-[10px] bg-accent" };
var _hoisted_6$1 = ["aria-label", "aria-pressed"];
var _hoisted_7$1 = ["aria-label", "aria-pressed"];
var _hoisted_8 = { class: "flex flex-col gap-3 pb-3" };
var _hoisted_9 = { class: "text-left font-sans text-xs text-muted-foreground" };
var _hoisted_10 = { class: "flex flex-col gap-2" };
var _hoisted_11 = { class: "flex items-center justify-between" };
var _hoisted_12 = { class: "text-left font-sans text-xs text-muted-foreground" };
var _hoisted_13 = { class: "flex flex-col gap-2" };
var _hoisted_14 = { class: "flex items-center justify-between" };
var _hoisted_15 = { class: "text-left font-sans text-xs text-muted-foreground" };
var _hoisted_16 = { class: "flex flex-col gap-2" };
var _hoisted_17 = { class: "flex items-center justify-between" };
var _hoisted_18 = { class: "text-left font-sans text-xs text-muted-foreground" };
var _hoisted_19 = { class: "flex flex-col gap-2" };
var _hoisted_20 = { class: "flex items-center justify-between" };
var _hoisted_21 = { class: "text-left font-sans text-xs text-muted-foreground" };
//#endregion
//#region src/renderer/extensions/maskEditor/components/BrushSettingsPanel.vue
var BrushSettingsPanel_default = /* @__PURE__ */ defineComponent({
	__name: "BrushSettingsPanel",
	setup(__props) {
		const { t } = useI18n();
		const store = useMaskEditorStore();
		const colorInputRef = ref();
		const brushSize = computed({
			get: () => store.brushSettings.size,
			set: (value) => store.setBrushSize(value)
		});
		const rawSliderValue = ref(null);
		const brushSizeSliderValue = computed({
			get: () => {
				if (rawSliderValue.value !== null) {
					if (Math.round(Math.pow(250, rawSliderValue.value)) === brushSize.value) return rawSliderValue.value;
				}
				return Math.log(brushSize.value) / Math.log(250);
			},
			set: (value) => {
				rawSliderValue.value = value;
				const size = Math.round(Math.pow(250, value));
				store.setBrushSize(size);
			}
		});
		const brushOpacity = computed({
			get: () => store.brushSettings.opacity,
			set: (value) => store.setBrushOpacity(value)
		});
		const brushHardness = computed({
			get: () => store.brushSettings.hardness,
			set: (value) => store.setBrushHardness(value)
		});
		const brushStepSize = computed({
			get: () => store.brushSettings.stepSize,
			set: (value) => store.setBrushStepSize(value)
		});
		const setBrushShape = (shape) => {
			store.brushSettings.type = shape;
		};
		const resetToDefault = () => {
			store.resetBrushToDefault();
		};
		onMounted(() => {
			if (colorInputRef.value) store.colorInput = colorInputRef.value;
		});
		onBeforeUnmount(() => {
			store.colorInput = null;
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$9, [
				createBaseVNode("h3", _hoisted_2$9, toDisplayString(unref(t)("maskEditor.brushSettings")), 1),
				createVNode(Button_default, {
					variant: "outline",
					size: "unset",
					class: "h-7.5 w-32 rounded-[10px] bg-background",
					onClick: resetToDefault
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(unref(t)("maskEditor.resetToDefault")), 1)]),
					_: 1
				}),
				createBaseVNode("div", _hoisted_3$4, [createBaseVNode("span", _hoisted_4$4, toDisplayString(unref(t)("maskEditor.brushShape")), 1), createBaseVNode("div", _hoisted_5$2, [createBaseVNode("button", {
					type: "button",
					"aria-label": unref(t)("maskEditor.brushShapeCircle"),
					"aria-pressed": unref(store).brushSettings.type === unref(BrushShape).Arc,
					class: normalizeClass(unref(cn$2)("ml-2 size-[35px] cursor-pointer appearance-none rounded-full border border-solid p-0 transition-colors", unref(store).brushSettings.type === unref(BrushShape).Arc ? "bg-background" : "bg-transparent hover:bg-background/60")),
					onClick: _cache[0] || (_cache[0] = ($event) => setBrushShape(unref(BrushShape).Arc))
				}, null, 10, _hoisted_6$1), createBaseVNode("button", {
					type: "button",
					"aria-label": unref(t)("maskEditor.brushShapeSquare"),
					"aria-pressed": unref(store).brushSettings.type === unref(BrushShape).Rect,
					class: normalizeClass(unref(cn$2)("size-[35px] cursor-pointer appearance-none border border-solid p-0 transition-colors", unref(store).brushSettings.type === unref(BrushShape).Rect ? "bg-background" : "bg-transparent hover:bg-background/60")),
					onClick: _cache[1] || (_cache[1] = ($event) => setBrushShape(unref(BrushShape).Rect))
				}, null, 10, _hoisted_7$1)])]),
				createBaseVNode("div", _hoisted_8, [createBaseVNode("span", _hoisted_9, toDisplayString(unref(t)("maskEditor.colorSelector")), 1), withDirectives(createBaseVNode("input", {
					ref_key: "colorInputRef",
					ref: colorInputRef,
					"onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => unref(store).rgbColor = $event),
					type: "color",
					class: "h-10 cursor-pointer rounded-md"
				}, null, 512), [[vModelText, unref(store).rgbColor]])]),
				createBaseVNode("div", _hoisted_10, [createBaseVNode("div", _hoisted_11, [createBaseVNode("span", _hoisted_12, toDisplayString(unref(t)("maskEditor.thickness")), 1), withDirectives(createBaseVNode("input", {
					"onUpdate:modelValue": _cache[3] || (_cache[3] = ($event) => brushSize.value = $event),
					"data-testid": "brush-thickness-input",
					type: "number",
					class: "w-16 rounded-md border bg-background px-2 py-1 text-center text-sm text-foreground",
					min: 1,
					max: 250,
					step: 1
				}, null, 512), [[
					vModelText,
					brushSize.value,
					void 0,
					{ number: true }
				]])]), createVNode(SliderControl_default, {
					modelValue: brushSizeSliderValue.value,
					"onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => brushSizeSliderValue.value = $event),
					class: "flex-1",
					label: "",
					min: 0,
					max: 1,
					step: .001
				}, null, 8, ["modelValue"])]),
				createBaseVNode("div", _hoisted_13, [createBaseVNode("div", _hoisted_14, [createBaseVNode("span", _hoisted_15, toDisplayString(unref(t)("maskEditor.opacity")), 1), withDirectives(createBaseVNode("input", {
					"onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => brushOpacity.value = $event),
					type: "number",
					class: "w-16 rounded-md border bg-background px-2 py-1 text-center text-sm text-foreground",
					min: 0,
					max: 1,
					step: .01
				}, null, 512), [[
					vModelText,
					brushOpacity.value,
					void 0,
					{ number: true }
				]])]), createVNode(SliderControl_default, {
					modelValue: brushOpacity.value,
					"onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => brushOpacity.value = $event),
					class: "flex-1",
					label: "",
					min: 0,
					max: 1,
					step: .01
				}, null, 8, ["modelValue"])]),
				createBaseVNode("div", _hoisted_16, [createBaseVNode("div", _hoisted_17, [createBaseVNode("span", _hoisted_18, toDisplayString(unref(t)("maskEditor.hardness")), 1), withDirectives(createBaseVNode("input", {
					"onUpdate:modelValue": _cache[7] || (_cache[7] = ($event) => brushHardness.value = $event),
					type: "number",
					class: "w-16 rounded-md border bg-background px-2 py-1 text-center text-sm text-foreground",
					min: 0,
					max: 1,
					step: .01
				}, null, 512), [[
					vModelText,
					brushHardness.value,
					void 0,
					{ number: true }
				]])]), createVNode(SliderControl_default, {
					modelValue: brushHardness.value,
					"onUpdate:modelValue": _cache[8] || (_cache[8] = ($event) => brushHardness.value = $event),
					class: "flex-1",
					label: "",
					min: 0,
					max: 1,
					step: .01
				}, null, 8, ["modelValue"])]),
				createBaseVNode("div", _hoisted_19, [createBaseVNode("div", _hoisted_20, [createBaseVNode("span", _hoisted_21, toDisplayString(unref(t)("maskEditor.stepSize")), 1), withDirectives(createBaseVNode("input", {
					"onUpdate:modelValue": _cache[9] || (_cache[9] = ($event) => brushStepSize.value = $event),
					type: "number",
					class: "w-16 rounded-md border bg-background px-2 py-1 text-center text-sm text-foreground",
					min: 1,
					max: 100,
					step: 1
				}, null, 512), [[
					vModelText,
					brushStepSize.value,
					void 0,
					{ number: true }
				]])]), createVNode(SliderControl_default, {
					modelValue: brushStepSize.value,
					"onUpdate:modelValue": _cache[10] || (_cache[10] = ($event) => brushStepSize.value = $event),
					class: "flex-1",
					label: "",
					min: 1,
					max: 100,
					step: 1
				}, null, 8, ["modelValue"])])
			]);
		};
	}
});
//#endregion
//#region src/renderer/extensions/maskEditor/components/controls/DropdownControl.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$8 = { class: "relative flex min-h-6 items-center gap-2.5" };
var _hoisted_2$8 = { class: "text-left font-sans text-xs text-muted-foreground" };
var _hoisted_3$3 = ["value"];
var _hoisted_4$3 = ["value"];
//#endregion
//#region src/renderer/extensions/maskEditor/components/controls/DropdownControl.vue
var DropdownControl_default = /* @__PURE__ */ defineComponent({
	__name: "DropdownControl",
	props: {
		label: {},
		options: {},
		modelValue: {}
	},
	emits: ["update:modelValue"],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const normalizedOptions = computed(() => {
			return props.options.map((option) => {
				if (typeof option === "string") return {
					label: option,
					value: option
				};
				return option;
			});
		});
		const onChange = (event) => {
			const value = event.target.value;
			emit("update:modelValue", value);
		};
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$8, [createBaseVNode("span", _hoisted_2$8, toDisplayString(__props.label), 1), createBaseVNode("select", {
				class: "absolute right-0 h-6 rounded-md border bg-secondary px-1.5 transition-colors duration-100 focus:outline focus:outline-ring",
				value: __props.modelValue,
				onChange
			}, [(openBlock(true), createElementBlock(Fragment, null, renderList(normalizedOptions.value, (option) => {
				return openBlock(), createElementBlock("option", {
					key: option.value,
					value: option.value
				}, toDisplayString(option.label), 9, _hoisted_4$3);
			}), 128))], 40, _hoisted_3$3)]);
		};
	}
});
//#endregion
//#region src/renderer/extensions/maskEditor/components/controls/ToggleControl.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$7 = { class: "relative flex min-h-6 items-center gap-2.5" };
var _hoisted_2$7 = { class: "text-left font-sans text-xs text-muted-foreground" };
var _hoisted_3$2 = { class: "maskEditor_sidePanelToggleContainer" };
var _hoisted_4$2 = ["checked"];
//#endregion
//#region src/renderer/extensions/maskEditor/components/controls/ToggleControl.vue
var ToggleControl_default = /* @__PURE__ */ defineComponent({
	__name: "ToggleControl",
	props: {
		label: {},
		modelValue: { type: Boolean }
	},
	emits: ["update:modelValue"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const onChange = (event) => {
			const checked = event.target.checked;
			emit("update:modelValue", checked);
		};
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$7, [createBaseVNode("span", _hoisted_2$7, toDisplayString(__props.label), 1), createBaseVNode("label", _hoisted_3$2, [createBaseVNode("input", {
				type: "checkbox",
				class: "maskEditor_sidePanelToggleCheckbox",
				checked: __props.modelValue,
				onChange
			}, null, 40, _hoisted_4$2), _cache[0] || (_cache[0] = createBaseVNode("div", { class: "maskEditor_sidePanelToggleSwitch" }, null, -1))])]);
		};
	}
});
//#endregion
//#region src/renderer/extensions/maskEditor/components/ColorSelectSettingsPanel.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$6 = { class: "flex flex-col gap-3 pb-3" };
var _hoisted_2$6 = { class: "mt-2.5 text-center font-sans text-[15px] text-muted-foreground" };
//#endregion
//#region src/renderer/extensions/maskEditor/components/ColorSelectSettingsPanel.vue
var ColorSelectSettingsPanel_default = /* @__PURE__ */ defineComponent({
	__name: "ColorSelectSettingsPanel",
	setup(__props) {
		const { t } = useI18n();
		const store = useMaskEditorStore();
		const methodOptions = Object.values(ColorComparisonMethod);
		const onToleranceChange = (value) => {
			store.setColorSelectTolerance(value);
		};
		const onSelectionOpacityChange = (value) => {
			store.setSelectionOpacity(value);
		};
		const onLivePreviewChange = (value) => {
			store.colorSelectLivePreview = value;
		};
		const onWholeImageChange = (value) => {
			store.applyWholeImage = value;
		};
		const onMethodChange = (value) => {
			store.colorComparisonMethod = value;
		};
		const onMaskBoundaryChange = (value) => {
			store.maskBoundary = value;
		};
		const onMaskToleranceChange = (value) => {
			store.setMaskTolerance(value);
		};
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$6, [
				createBaseVNode("h3", _hoisted_2$6, toDisplayString(unref(t)("maskEditor.colorSelectSettings")), 1),
				createVNode(SliderControl_default, {
					label: unref(t)("maskEditor.tolerance"),
					min: 0,
					max: 255,
					step: 1,
					"model-value": unref(store).colorSelectTolerance,
					"onUpdate:modelValue": onToleranceChange
				}, null, 8, ["label", "model-value"]),
				createVNode(SliderControl_default, {
					label: unref(t)("maskEditor.selectionOpacity"),
					min: 0,
					max: 100,
					step: 1,
					"model-value": unref(store).selectionOpacity,
					"onUpdate:modelValue": onSelectionOpacityChange
				}, null, 8, ["label", "model-value"]),
				createVNode(ToggleControl_default, {
					label: unref(t)("maskEditor.livePreview"),
					"model-value": unref(store).colorSelectLivePreview,
					"onUpdate:modelValue": onLivePreviewChange
				}, null, 8, ["label", "model-value"]),
				createVNode(ToggleControl_default, {
					label: unref(t)("maskEditor.applyToWholeImage"),
					"model-value": unref(store).applyWholeImage,
					"onUpdate:modelValue": onWholeImageChange
				}, null, 8, ["label", "model-value"]),
				createVNode(DropdownControl_default, {
					label: unref(t)("maskEditor.method"),
					options: unref(methodOptions),
					"model-value": unref(store).colorComparisonMethod,
					"onUpdate:modelValue": onMethodChange
				}, null, 8, [
					"label",
					"options",
					"model-value"
				]),
				createVNode(ToggleControl_default, {
					label: unref(t)("maskEditor.stopAtMask"),
					"model-value": unref(store).maskBoundary,
					"onUpdate:modelValue": onMaskBoundaryChange
				}, null, 8, ["label", "model-value"]),
				createVNode(SliderControl_default, {
					label: unref(t)("maskEditor.maskTolerance"),
					min: 0,
					max: 255,
					step: 1,
					"model-value": unref(store).maskTolerance,
					"onUpdate:modelValue": onMaskToleranceChange
				}, null, 8, ["label", "model-value"])
			]);
		};
	}
});
//#endregion
//#region src/renderer/extensions/maskEditor/components/PaintBucketSettingsPanel.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$5 = { class: "flex flex-col gap-3 pb-3" };
var _hoisted_2$5 = { class: "mt-2.5 text-center font-sans text-[15px] text-muted-foreground" };
//#endregion
//#region src/renderer/extensions/maskEditor/components/PaintBucketSettingsPanel.vue
var PaintBucketSettingsPanel_default = /* @__PURE__ */ defineComponent({
	__name: "PaintBucketSettingsPanel",
	setup(__props) {
		const { t } = useI18n();
		const store = useMaskEditorStore();
		const onToleranceChange = (value) => {
			store.setPaintBucketTolerance(value);
		};
		const onFillOpacityChange = (value) => {
			store.setFillOpacity(value);
		};
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$5, [
				createBaseVNode("h3", _hoisted_2$5, toDisplayString(unref(t)("maskEditor.paintBucketSettings")), 1),
				createVNode(SliderControl_default, {
					label: unref(t)("maskEditor.tolerance"),
					min: 0,
					max: 255,
					step: 1,
					"model-value": unref(store).paintBucketTolerance,
					"onUpdate:modelValue": onToleranceChange
				}, null, 8, ["label", "model-value"]),
				createVNode(SliderControl_default, {
					label: unref(t)("maskEditor.fillOpacity"),
					min: 0,
					max: 100,
					step: 1,
					"model-value": unref(store).fillOpacity,
					"onUpdate:modelValue": onFillOpacityChange
				}, null, 8, ["label", "model-value"])
			]);
		};
	}
});
//#endregion
//#region src/renderer/extensions/maskEditor/components/SettingsPanelContainer.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$4 = { class: "maskEditor_sidePanel" };
var _hoisted_2$4 = { class: "maskEditor_sidePanelContainer" };
//#endregion
//#region src/renderer/extensions/maskEditor/components/SettingsPanelContainer.vue
var SettingsPanelContainer_default = /* @__PURE__ */ defineComponent({
	__name: "SettingsPanelContainer",
	setup(__props) {
		const currentPanelComponent = computed(() => {
			const tool = useMaskEditorStore().currentTool;
			if (tool === Tools.MaskBucket) return PaintBucketSettingsPanel_default;
			else if (tool === Tools.MaskColorFill) return ColorSelectSettingsPanel_default;
			else return BrushSettingsPanel_default;
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$4, [createBaseVNode("div", _hoisted_2$4, [(openBlock(), createBlock(resolveDynamicComponent(currentPanelComponent.value)))])]);
		};
	}
});
//#endregion
//#region src/renderer/extensions/maskEditor/components/SidePanel.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$3 = { class: "flex h-full w-55 flex-col items-stretch! gap-3 overflow-y-auto bg-background px-2.5 pb-3" };
var _hoisted_2$3 = { class: "min-h-full w-full" };
//#endregion
//#region src/renderer/extensions/maskEditor/components/SidePanel.vue
var SidePanel_default = /* @__PURE__ */ defineComponent({
	__name: "SidePanel",
	props: { toolManager: {} },
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$3, [createBaseVNode("div", _hoisted_2$3, [
				createVNode(SettingsPanelContainer_default),
				_cache[0] || (_cache[0] = createBaseVNode("div", { class: "mt-6 mb-1.5 h-0.5 w-full bg-border" }, null, -1)),
				createVNode(ImageLayerSettingsPanel_default, { "tool-manager": __props.toolManager }, null, 8, ["tool-manager"])
			])]);
		};
	}
});
//#endregion
//#region src/renderer/extensions/maskEditor/components/MaskEditorToolIcon.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$2 = ["data-testid"];
var _hoisted_2$2 = ["data-testid"];
var _hoisted_3$1 = ["data-testid"];
var _hoisted_4$1 = ["data-testid"];
var _hoisted_5$1 = ["data-testid"];
//#endregion
//#region src/renderer/extensions/maskEditor/components/MaskEditorToolIcon.vue
var MaskEditorToolIcon_default = /* @__PURE__ */ defineComponent({
	__name: "MaskEditorToolIcon",
	props: { tool: {} },
	setup(__props) {
		return (_ctx, _cache) => {
			return __props.tool === unref(Tools).MaskPen ? (openBlock(), createElementBlock("svg", {
				key: 0,
				"data-testid": `icon-${__props.tool}`,
				viewBox: "0 0 44 44",
				fill: "currentColor"
			}, [..._cache[0] || (_cache[0] = [createBaseVNode("path", {
				class: "cls-1",
				d: "M10.97,15.98v14.04c0,.825.675,1.5,1.5,1.5h23.07c.825,0,1.5-.675,1.5-1.5V15.98c0-.825-.675-1.5-1.5-1.5H12.47c-.825,0-1.5.675-1.5,1.5ZM25.79,28.16c-4.365,1.41-8.355-2.58-6.945-6.945.51-1.575,1.785-2.85,3.36-3.36,4.365-1.41,8.355,2.58,6.945,6.945-.51,1.575-1.785,2.85-3.36,3.36Z"
			}, null, -1)])], 8, _hoisted_1$2)) : __props.tool === unref(Tools).Eraser ? (openBlock(), createElementBlock("svg", {
				key: 1,
				"data-testid": `icon-${__props.tool}`,
				viewBox: "0 0 44 44",
				fill: "currentColor"
			}, [..._cache[1] || (_cache[1] = [createBaseVNode("g", null, [createBaseVNode("rect", {
				class: "cls-2",
				x: "16.68",
				y: "10",
				width: "10.63",
				height: "24",
				rx: "1.16",
				ry: "1.16",
				transform: "translate(22 -9.11) rotate(45)"
			}), createBaseVNode("path", {
				class: "cls-1",
				d: "M17.27,34.27c-.42,0-.85-.16-1.17-.48l-5.88-5.88c-.31-.31-.48-.73-.48-1.17s.17-.86.48-1.17l15.34-15.34c.62-.62,1.72-.62,2.34,0l5.88,5.88c.65.65.65,1.7,0,2.34l-15.34,15.34c-.32.32-.75.48-1.17.48ZM26.73,10.73c-.18,0-.34.07-.46.19l-15.34,15.34c-.12.12-.19.29-.19.46s.07.34.19.46l5.88,5.88c.26.26.67.26.93,0l15.34-15.34c.26-.26.26-.67,0-.93l-5.88-5.88c-.12-.12-.29-.19-.46-.19Z"
			})], -1), createBaseVNode("path", {
				class: "cls-3",
				d: "M20.33,11.03h8.32c.64,0,1.16.52,1.16,1.16v15.79h-10.63v-15.79c0-.64.52-1.16,1.16-1.16Z",
				transform: "translate(20.97 -11.61) rotate(45)"
			}, null, -1)])], 8, _hoisted_2$2)) : __props.tool === unref(Tools).MaskBucket ? (openBlock(), createElementBlock("svg", {
				key: 2,
				"data-testid": `icon-${__props.tool}`,
				viewBox: "0 0 44 44",
				fill: "currentColor"
			}, [..._cache[2] || (_cache[2] = [
				createBaseVNode("path", {
					class: "cls-1",
					d: "M33.4,21.76l-11.42,11.41-.04.05c-.61.61-1.6.61-2.21,0l-8.91-8.91c-.61-.61-.61-1.6,0-2.21l.04-.05.3-.29h22.24Z"
				}, null, -1),
				createBaseVNode("path", {
					class: "cls-1",
					d: "M20.83,34.17c-.55,0-1.07-.21-1.46-.6l-8.91-8.91c-.8-.8-.8-2.11,0-2.92l11.31-11.31c.8-.8,2.11-.8,2.92,0l8.91,8.91c.39.39.6.91.6,1.46s-.21,1.07-.6,1.46l-11.31,11.31c-.39.39-.91.6-1.46.6ZM23.24,10.83c-.27,0-.54.1-.75.31l-11.31,11.31c-.41.41-.41,1.09,0,1.5l8.91,8.91c.4.4,1.1.4,1.5,0l11.31-11.31c.2-.2.31-.47.31-.75s-.11-.55-.31-.75l-8.91-8.91c-.21-.21-.48-.31-.75-.31Z"
				}, null, -1),
				createBaseVNode("path", {
					class: "cls-1",
					d: "M34.28,26.85c0,.84-.68,1.52-1.52,1.52s-1.52-.68-1.52-1.52,1.52-2.86,1.52-2.86c0,0,1.52,2.02,1.52,2.86Z"
				}, null, -1)
			])], 8, _hoisted_3$1)) : __props.tool === unref(Tools).MaskColorFill ? (openBlock(), createElementBlock("svg", {
				key: 3,
				"data-testid": `icon-${__props.tool}`,
				viewBox: "0 0 44 44",
				fill: "currentColor"
			}, [..._cache[3] || (_cache[3] = [createBaseVNode("path", {
				class: "cls-1",
				d: "M30.29,13.72c-1.09-1.1-2.85-1.09-3.94,0l-2.88,2.88-.75-.75c-.2-.19-.51-.19-.71,0-.19.2-.19.51,0,.71l1.4,1.4-9.59,9.59c-.35.36-.54.82-.54,1.32,0,.14,0,.28.05.41-.05.04-.1.08-.15.13-.39.39-.39,1.01,0,1.4.38.39,1.01.39,1.4,0,.04-.04.08-.09.11-.13.14.04.3.06.45.06.5,0,.97-.19,1.32-.55l9.59-9.59,1.38,1.38c.1.09.22.14.35.14s.26-.05.35-.14c.2-.2.2-.52,0-.71l-.71-.72,2.88-2.89c1.08-1.08,1.08-2.85-.01-3.94ZM19.43,25.82h-2.46l7.15-7.15,1.23,1.23-5.92,5.92Z"
			}, null, -1)])], 8, _hoisted_4$1)) : __props.tool === unref(Tools).PaintPen ? (openBlock(), createElementBlock("svg", {
				key: 4,
				"data-testid": `icon-${__props.tool}`,
				viewBox: "0 0 44 44",
				fill: "currentColor"
			}, [..._cache[4] || (_cache[4] = [createBaseVNode("path", {
				class: "cls-1",
				d: "M34,13.93c0,.47-.19.94-.55,1.31l-13.02,13.04c-.09.07-.18.15-.27.22-.07-1.39-1.21-2.48-2.61-2.49.07-.12.16-.24.27-.34l13.04-13.04c.72-.72,1.89-.72,2.6,0,.35.35.55.83.55,1.3Z"
			}, null, -1), createBaseVNode("path", {
				class: "cls-1",
				d: "M19.64,29.03c0,4.46-6.46,3.18-9.64,0,3.3-.47,4.75-2.58,7.06-2.58,1.43,0,2.58,1.16,2.58,2.58Z"
			}, null, -1)])], 8, _hoisted_5$1)) : createCommentVNode("", true);
		};
	}
});
//#endregion
//#region src/renderer/extensions/maskEditor/components/ToolPanel.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$1 = { class: "z-8888 flex h-full flex-col justify-between bg-background" };
var _hoisted_2$1 = { class: "flex flex-col" };
var _hoisted_3 = ["data-tool", "onClick"];
var _hoisted_4 = { class: "flex items-center justify-center" };
var _hoisted_5 = ["title"];
var _hoisted_6 = {
	"data-testid": "zoom-percentage",
	class: "text-sm"
};
var _hoisted_7 = {
	"data-testid": "zoom-dimensions",
	class: "text-xs"
};
//#endregion
//#region src/renderer/extensions/maskEditor/components/ToolPanel.vue
var ToolPanel_default = /* @__PURE__ */ defineComponent({
	__name: "ToolPanel",
	props: { toolManager: {} },
	setup(__props) {
		const { t } = useI18n();
		const store = useMaskEditorStore();
		const onToolSelect = (tool) => {
			__props.toolManager.switchTool(tool);
		};
		const currentTool = computed(() => store.currentTool);
		const zoomText = computed(() => `${Math.round(store.displayZoomRatio * 100)}%`);
		const dimensionsText = computed(() => {
			const img = store.image;
			return img ? `${img.width}x${img.height}` : " ";
		});
		const onResetZoom = () => {
			store.resetZoom();
		};
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$1, [createBaseVNode("div", _hoisted_2$1, [(openBlock(true), createElementBlock(Fragment, null, renderList(unref(allTools), (tool) => {
				return openBlock(), createElementBlock("div", {
					key: tool,
					"data-testid": "tool-button",
					"data-tool": tool,
					class: normalizeClass(unref(cn$2)("maskEditor_toolPanelContainer hover:bg-accent", currentTool.value === tool && "maskEditor_toolPanelContainerSelected")),
					onClick: ($event) => onToolSelect(tool)
				}, [createBaseVNode("div", _hoisted_4, [createVNode(MaskEditorToolIcon_default, { tool }, null, 8, ["tool"])]), _cache[0] || (_cache[0] = createBaseVNode("div", { class: "maskEditor_toolPanelIndicator" }, null, -1))], 10, _hoisted_3);
			}), 128))]), createBaseVNode("div", {
				class: "mb-2 flex cursor-pointer flex-col items-center rounded-md text-muted-foreground transition-colors duration-200 hover:bg-accent",
				title: unref(t)("maskEditor.clickToResetZoom"),
				onClick: onResetZoom
			}, [createBaseVNode("span", _hoisted_6, toDisplayString(zoomText.value), 1), createBaseVNode("span", _hoisted_7, toDisplayString(dimensionsText.value), 1)], 8, _hoisted_5)]);
		};
	}
});
//#endregion
//#region src/renderer/extensions/maskEditor/components/MaskEditorContent.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = {
	"data-testid": "mask-editor-ui",
	class: "relative z-1 flex min-h-0 flex-1 flex-col"
};
var _hoisted_2 = { class: "flex min-h-0 flex-1 overflow-hidden" };
//#endregion
//#region src/renderer/extensions/maskEditor/components/MaskEditorContent.vue
var MaskEditorContent_default = /* @__PURE__ */ defineComponent({
	__name: "MaskEditorContent",
	props: { node: {} },
	setup(__props) {
		const store = useMaskEditorStore();
		const dataStore = useMaskEditorDataStore();
		const dialogStore = useDialogStore();
		const loader = useMaskEditorLoader();
		const containerRef = ref();
		const canvasContainerRef = ref();
		const imgCanvasRef = ref();
		const maskCanvasRef = ref();
		const rgbCanvasRef = ref();
		const gpuCanvasRef = ref();
		const canvasBackgroundRef = ref();
		const toolPanelRef = ref();
		const sidePanelRef = ref();
		const initialized = ref(false);
		const keyboard = useKeyboard(containerRef);
		const panZoom = usePanAndZoom();
		const settingStore = useSettingStore();
		const brushPersistence = useBrushPersistence();
		brushPersistence.loadAndApply();
		const toolManager = useToolManager(keyboard, panZoom, {
			useDominantAxis: settingStore.get("Comfy.MaskEditor.UseDominantAxis"),
			brushAdjustmentSpeed: settingStore.get("Comfy.MaskEditor.BrushAdjustmentSpeed")
		});
		let resizeObserver = null;
		const handleDragStart = (event) => {
			if (event.ctrlKey) event.preventDefault();
		};
		const initUI = async () => {
			if (!containerRef.value) {
				console.error("[MaskEditorContent] Cannot initialize - missing required refs");
				return;
			}
			if (!imgCanvasRef.value || !maskCanvasRef.value || !rgbCanvasRef.value || !canvasContainerRef.value || !canvasBackgroundRef.value) {
				console.error("[MaskEditorContent] Cannot initialize - missing canvas refs");
				return;
			}
			store.maskCanvas = maskCanvasRef.value;
			store.rgbCanvas = rgbCanvasRef.value;
			store.imgCanvas = imgCanvasRef.value;
			store.canvasContainer = canvasContainerRef.value;
			store.canvasBackground = canvasBackgroundRef.value;
			try {
				await loader.loadFromNode(__props.node);
				const image = await useImageLoader().loadImages();
				await panZoom.initializeCanvasPanZoom(image, containerRef.value, toolPanelRef.value?.$el, sidePanelRef.value?.$el);
				store.canvasHistory.saveInitialState();
				if (toolManager.brushDrawing) {
					await toolManager.brushDrawing.initGPUResources();
					if (gpuCanvasRef.value && toolManager.brushDrawing.initPreviewCanvas) {
						gpuCanvasRef.value.width = maskCanvasRef.value.width;
						gpuCanvasRef.value.height = maskCanvasRef.value.height;
						toolManager.brushDrawing.initPreviewCanvas(gpuCanvasRef.value);
					}
				}
				initialized.value = true;
			} catch (error) {
				console.error("[MaskEditorContent] Initialization failed:", error);
				dialogStore.closeDialog();
			}
		};
		onMounted(() => {
			keyboard.addListeners();
			if (containerRef.value) {
				resizeObserver = new ResizeObserver(async () => {
					if (panZoom) await panZoom.invalidatePanZoom();
				});
				resizeObserver.observe(containerRef.value);
			}
			initUI();
		});
		onBeforeUnmount(() => {
			brushPersistence.save();
			keyboard?.removeListeners();
			if (resizeObserver) {
				resizeObserver.disconnect();
				resizeObserver = null;
			}
			store.canvasHistory.clearStates();
			store.resetState();
			dataStore.reset();
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				ref_key: "containerRef",
				ref: containerRef,
				"data-testid": "mask-editor-root",
				class: "relative flex size-full flex-col overflow-hidden",
				onContextmenu: _cache[4] || (_cache[4] = withModifiers(() => {}, ["prevent"])),
				onDragstart: handleDragStart,
				onKeydown: _cache[5] || (_cache[5] = withModifiers(() => {}, ["stop"]))
			}, [
				createBaseVNode("div", {
					id: "maskEditorCanvasContainer",
					ref_key: "canvasContainerRef",
					ref: canvasContainerRef,
					class: "absolute inset-0 z-0",
					onContextmenu: _cache[3] || (_cache[3] = withModifiers(() => {}, ["prevent"]))
				}, [
					createBaseVNode("canvas", {
						ref_key: "imgCanvasRef",
						ref: imgCanvasRef,
						class: "absolute top-0 left-0 z-0 size-full",
						onContextmenu: _cache[0] || (_cache[0] = withModifiers(() => {}, ["prevent"]))
					}, null, 544),
					createBaseVNode("canvas", {
						ref_key: "rgbCanvasRef",
						ref: rgbCanvasRef,
						class: "absolute top-0 left-0 z-10 size-full",
						onContextmenu: _cache[1] || (_cache[1] = withModifiers(() => {}, ["prevent"]))
					}, null, 544),
					createBaseVNode("canvas", {
						ref_key: "maskCanvasRef",
						ref: maskCanvasRef,
						class: "absolute top-0 left-0 z-30 size-full",
						onContextmenu: _cache[2] || (_cache[2] = withModifiers(() => {}, ["prevent"]))
					}, null, 544),
					createBaseVNode("canvas", {
						ref_key: "gpuCanvasRef",
						ref: gpuCanvasRef,
						class: normalizeClass(["pointer-events-none absolute top-0 left-0 size-full", {
							"z-20": unref(store).activeLayer === "rgb",
							"z-40": unref(store).activeLayer === "mask"
						}])
					}, null, 2),
					createBaseVNode("div", {
						ref_key: "canvasBackgroundRef",
						ref: canvasBackgroundRef,
						class: "size-full"
					}, null, 512)
				], 544),
				createVNode(LoadingOverlay_default, {
					loading: !initialized.value,
					size: "sm"
				}, null, 8, ["loading"]),
				createBaseVNode("div", _hoisted_1, [createBaseVNode("div", _hoisted_2, [
					initialized.value ? (openBlock(), createBlock(ToolPanel_default, {
						key: 0,
						ref_key: "toolPanelRef",
						ref: toolPanelRef,
						"tool-manager": unref(toolManager)
					}, null, 8, ["tool-manager"])) : createCommentVNode("", true),
					initialized.value ? (openBlock(), createBlock(PointerZone_default, {
						key: 1,
						"tool-manager": unref(toolManager),
						"pan-zoom": unref(panZoom)
					}, null, 8, ["tool-manager", "pan-zoom"])) : createCommentVNode("", true),
					initialized.value ? (openBlock(), createBlock(SidePanel_default, {
						key: 2,
						ref_key: "sidePanelRef",
						ref: sidePanelRef,
						"tool-manager": unref(toolManager)
					}, null, 8, ["tool-manager"])) : createCommentVNode("", true)
				])]),
				initialized.value ? (openBlock(), createBlock(BrushCursor_default, {
					key: 0,
					"container-ref": containerRef.value
				}, null, 8, ["container-ref"])) : createCommentVNode("", true)
			], 544);
		};
	}
});
//#endregion
export { MaskEditorContent_default as default };
