import "./rolldown-runtime-xtsTai4I.js";
import { i as useBillingOperationStore, t as useBillingContext } from "./useBillingContext-Cc-YANxo.js";
import { o as WorkspaceApiError, r as workspaceApi } from "./teamWorkspaceStore-BNm5cZOK.js";
import { B as createSlots, F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, I as createBlock, Kt as normalizeClass, L as createCommentVNode, O as Fragment, P as computed, Pt as readonly, R as createElementBlock, Rt as shallowRef, U as createVNode, Wt as unref, Yt as toDisplayString, at as onMounted, ct as openBlock, et as mergeProps, gt as useId, ot as onUnmounted, ut as renderList, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { J as RadioGroupItem_default, Y as RadioGroupRoot_default } from "./vendor-reka-ui-NRTk7aIV.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { n as useTelemetry } from "./telemetry-IkzvF0TI.js";
import { t as useToast } from "./toastStore-Dg65fRgL.js";
import { d as t } from "./i18n-BRluoVl-.js";
import { r as reportError } from "./reportError-BHgDVvfb.js";
import { t as Badge_default } from "./Badge-BUm0jxSy.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
import { t as Textarea_default } from "./Textarea-Cj9Mt-4W.js";
import { i as formatQuoteMoney } from "./checkoutQuote-BtwiXuaq.js";
import { a as CancellationStepLayout_default, i as useCancellationPlan, n as createCancelFlowReporter, r as getSubscriptionCancellationMetadata, t as CancelSubscriptionDialogContent_default } from "./CancelSubscriptionDialogContent-B4UtuXWS.js";
import { n as recordRetentionFlowEvent } from "./launchCancellationFlow-Bs_vlI9i.js";
import { n as formatCurrencyCents } from "./numberUtil-DF3CIRbK.js";
//#region src/platform/billing/subscription/utils/cancellationSurvey.ts
var CANCELLATION_REASONS = [
	"tooExpensive",
	"notUsingEnough",
	"missingFeatures",
	"switchingTools",
	"somethingElse"
];
var REASON_QUESTION_ID = "f5b2934c-a2aa-4e9d-83d2-bbb346b2a196";
var COMMENT_QUESTION_ID = "3a3166fb-c479-439b-8c8a-65dde9f2147a";
var REASON_CHOICES = {
	tooExpensive: "Too expensive",
	notUsingEnough: "Not using it enough",
	missingFeatures: "Missing features or models",
	switchingTools: "Switching to another tool",
	somethingElse: "Something else"
};
function surveyResponses({ reason, comment }) {
	const responses = {};
	if (reason) responses[REASON_QUESTION_ID] = REASON_CHOICES[reason];
	const trimmedComment = comment.trim();
	if (trimmedComment) responses[COMMENT_QUESTION_ID] = trimmedComment;
	return responses;
}
function experimentProperties(experimentVariant) {
	return experimentVariant ? { experiment_variant: experimentVariant } : {};
}
function cancellationSurveyShownEvent(options) {
	return {
		surveyId: options.surveyId,
		properties: experimentProperties(options.experimentVariant)
	};
}
function cancellationSurveyExitEvent(options) {
	const responses = surveyResponses(options.answers);
	const properties = {
		outcome: options.exit,
		...experimentProperties(options.experimentVariant)
	};
	if (Object.keys(responses).length === 0) return {
		stage: "dismissed",
		event: {
			surveyId: options.surveyId,
			properties
		}
	};
	return {
		stage: "sent",
		event: {
			surveyId: options.surveyId,
			responses,
			properties
		}
	};
}
//#endregion
//#region src/platform/billing/subscription/components/CancellationSurveyStep.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$1 = { class: "flex flex-col gap-6" };
var _hoisted_2$1 = {
	key: 0,
	class: "size-2 rounded-full bg-background"
};
var _hoisted_3$1 = { class: "flex flex-col gap-3" };
var _hoisted_4$1 = ["for"];
//#endregion
//#region src/platform/billing/subscription/components/CancellationSurveyStep.vue
var CancellationSurveyStep_default = /* @__PURE__ */ defineComponent({
	__name: "CancellationSurveyStep",
	props: {
		surveyId: {},
		experimentVariant: {},
		onExit: { type: Function }
	},
	setup(__props) {
		const telemetry = useTelemetry();
		const reason = ref();
		const comment = ref("");
		const commentId = useId();
		onMounted(() => {
			telemetry?.trackInAppSurvey("shown", cancellationSurveyShownEvent({
				surveyId: __props.surveyId,
				experimentVariant: __props.experimentVariant
			}));
		});
		function selectReason(value) {
			reason.value = CANCELLATION_REASONS.find((option) => option === value);
		}
		function exit(choice) {
			const { stage, event } = cancellationSurveyExitEvent({
				surveyId: __props.surveyId,
				answers: {
					reason: reason.value,
					comment: comment.value
				},
				exit: choice,
				experimentVariant: __props.experimentVariant
			});
			telemetry?.trackInAppSurvey(stage, event);
			__props.onExit(choice);
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(CancellationStepLayout_default, {
				title: _ctx.$t("subscription.cancelFlow.survey.title"),
				subtitle: _ctx.$t("subscription.cancelFlow.survey.subtitle"),
				"on-close": () => exit("closed")
			}, {
				actions: withCtx(() => [createVNode(Button_default, {
					variant: "textonly",
					size: "lg",
					onClick: _cache[1] || (_cache[1] = ($event) => exit("keep_plan"))
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("subscription.cancelFlow.keepPlan")), 1)]),
					_: 1
				}), createVNode(Button_default, {
					variant: "secondary",
					size: "lg",
					onClick: _cache[2] || (_cache[2] = ($event) => exit("continue_cancelling"))
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("subscription.cancelFlow.continueCancelling")), 1)]),
					_: 1
				})]),
				default: withCtx(() => [createBaseVNode("div", _hoisted_1$1, [createVNode(unref(RadioGroupRoot_default), {
					"model-value": reason.value,
					"aria-label": _ctx.$t("subscription.cancelFlow.survey.title"),
					class: "flex flex-col gap-2",
					"onUpdate:modelValue": selectReason
				}, {
					default: withCtx(() => [(openBlock(true), createElementBlock(Fragment, null, renderList(unref(CANCELLATION_REASONS), (option) => {
						return openBlock(), createBlock(unref(RadioGroupItem_default), {
							key: option,
							value: option,
							class: normalizeClass(unref(cn)("flex w-full cursor-pointer items-center gap-2 rounded-[10px] border border-border/50 bg-transparent p-2.5 text-left text-sm transition-colors hover:bg-accent focus-visible:ring-1 focus-visible:ring-ring focus-visible:outline-none", reason.value === option && "border-transparent bg-secondary"))
						}, {
							default: withCtx(() => [createBaseVNode("span", {
								class: normalizeClass(unref(cn)("flex size-4 shrink-0 items-center justify-center rounded-full border border-border/50", reason.value === option && "border-foreground bg-foreground")),
								"aria-hidden": "true"
							}, [reason.value === option ? (openBlock(), createElementBlock("span", _hoisted_2$1)) : createCommentVNode("", true)], 2), createTextVNode(" " + toDisplayString(_ctx.$t(`subscription.cancelFlow.survey.reasons.${option}`)), 1)]),
							_: 2
						}, 1032, ["value", "class"]);
					}), 128))]),
					_: 1
				}, 8, ["model-value", "aria-label"]), createBaseVNode("div", _hoisted_3$1, [createBaseVNode("label", {
					for: unref(commentId),
					class: "text-sm"
				}, toDisplayString(_ctx.$t("subscription.cancelFlow.survey.commentLabel")), 9, _hoisted_4$1), createVNode(Textarea_default, {
					id: unref(commentId),
					modelValue: comment.value,
					"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => comment.value = $event),
					class: "h-24 resize-none font-inter",
					placeholder: _ctx.$t("subscription.cancelFlow.survey.commentPlaceholder"),
					maxlength: "2000"
				}, null, 8, [
					"id",
					"modelValue",
					"placeholder"
				])])])]),
				_: 1
			}, 8, [
				"title",
				"subtitle",
				"on-close"
			]);
		};
	}
});
//#endregion
//#region src/platform/billing/subscription/utils/retentionOffer.ts
function reduceRetentionOffer(phase, event) {
	switch (event.type) {
		case "acceptRequested": return phase === "offered" || phase === "failed" || phase === "unconfirmed" ? "accepting" : phase;
		case "applied": return phase === "accepting" ? "applied" : phase;
		case "rejected": return phase === "accepting" ? "failed" : phase;
		case "declined": return phase === "accepting" ? "declined" : phase;
		case "expired": return phase === "offered" || phase === "accepting" ? "expired" : phase;
		case "unconfirmed": return phase === "accepting" ? "unconfirmed" : phase;
	}
}
function outcomeOnClose(phase) {
	switch (phase) {
		case "applied": return "retained";
		case "accepting":
		case "unconfirmed": return "pending";
		case "offered":
		case "failed":
		case "declined":
		case "expired": return "dismissed";
	}
}
function discountedAmount(amount, offer) {
	return Math.round(amount * (100 - offer.percent_off) / 100);
}
function fullPriceRenewal(periodEnd, months) {
	const start = /* @__PURE__ */ new Date(periodEnd * 1e3);
	const renewal = new Date(start);
	renewal.setUTCDate(1);
	renewal.setUTCMonth(start.getUTCMonth() + months);
	const lastDayOfMonth = new Date(Date.UTC(renewal.getUTCFullYear(), renewal.getUTCMonth() + 1, 0)).getUTCDate();
	renewal.setUTCDate(Math.min(start.getUTCDate(), lastDayOfMonth));
	return renewal;
}
//#endregion
//#region src/platform/billing/subscription/composables/useRetentionOffer.ts
function refusal(error) {
	if (!(error instanceof WorkspaceApiError) || error.status === void 0) return;
	if (error.status >= 500 && error.status !== 503) return void 0;
	switch (error.code) {
		case "RETENTION_SESSION_STALE":
		case "RETENTION_ALREADY_REDEEMED": return { type: "expired" };
		case "PREVIOUS_OPERATION_FAILED":
		case "RETENTION_NOT_ALLOWED": return { type: "declined" };
		default: return { type: "rejected" };
	}
}
async function redeem(sessionId, workspaceId) {
	try {
		const acceptance = await workspaceApi.acceptRetentionOffer(sessionId);
		if (acceptance.status === "succeeded") return { type: "applied" };
		switch ((await useBillingOperationStore().startOperation(acceptance.billing_op_id, "retention", { workspaceId })).status) {
			case "succeeded": return { type: "applied" };
			case "failed": return { type: "declined" };
			default: return { type: "unconfirmed" };
		}
	} catch (error) {
		const refused = refusal(error);
		if (refused) return refused;
		reportError(error, {
			surface: "billing",
			errorType: "failure_confirming_retention_offer"
		});
		return { type: "unconfirmed" };
	}
}
function useRetentionOffer(sessionId, workspaceId) {
	const { fetchStatus } = useBillingContext();
	const phase = shallowRef("offered");
	function dispatch(event) {
		phase.value = reduceRetentionOffer(phase.value, event);
	}
	async function refreshPlan() {
		try {
			await fetchStatus();
		} catch (error) {
			reportError(error, {
				surface: "billing",
				errorType: "error_refreshing_billing_after_retention_discount"
			});
			useToast().warning(t("subscription.retentionOffer.refreshFailed"), { duration: 8e3 });
		}
	}
	async function recordShown() {
		if (await recordRetentionFlowEvent(sessionId, "offer_shown") === "expired") dispatch({ type: "expired" });
	}
	async function accept() {
		const requested = reduceRetentionOffer(phase.value, { type: "acceptRequested" });
		if (requested === phase.value) return;
		phase.value = requested;
		const result = await redeem(sessionId, workspaceId);
		dispatch(result);
		if (result.type === "applied") await refreshPlan();
	}
	return {
		phase: readonly(phase),
		accept,
		recordShown
	};
}
//#endregion
//#region src/platform/billing/subscription/components/RetentionOfferStep.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = {
	key: 0,
	class: "flex flex-col gap-3"
};
var _hoisted_2 = { class: "flex flex-col gap-3 rounded-[14px] border border-border/50 bg-secondary/50 px-4 py-5 shadow-xs" };
var _hoisted_3 = { class: "flex items-center justify-between gap-2" };
var _hoisted_4 = { class: "m-0 text-sm font-medium" };
var _hoisted_5 = { class: "m-0 flex flex-wrap items-baseline gap-1.5 text-sm" };
var _hoisted_6 = { class: "text-[32px] leading-[1.15] font-semibold" };
var _hoisted_7 = { class: "text-muted-foreground" };
var _hoisted_8 = { class: "text-muted-foreground line-through" };
var _hoisted_9 = { class: "m-0 text-sm text-muted-foreground" };
var _hoisted_10 = { class: "m-0 text-sm text-muted-foreground" };
var _hoisted_11 = { class: "m-0 text-sm text-muted-foreground" };
var _hoisted_12 = {
	key: 1,
	class: "flex flex-col gap-5 text-sm"
};
var _hoisted_13 = { class: "flex flex-col gap-3 rounded-[14px] border border-border/50 bg-secondary/50 p-4 shadow-xs" };
var _hoisted_14 = { class: "flex flex-wrap items-center justify-between gap-2" };
var _hoisted_15 = { class: "flex items-center gap-2" };
var _hoisted_16 = { class: "flex items-center gap-2" };
var _hoisted_17 = { class: "text-muted-foreground line-through" };
var _hoisted_18 = { class: "m-0 text-muted-foreground" };
var _hoisted_19 = { class: "m-0 text-muted-foreground" };
var _hoisted_20 = {
	key: 2,
	class: "m-0 text-xs/5 text-muted-foreground"
};
//#endregion
//#region src/platform/billing/subscription/components/RetentionOfferStep.vue
var RetentionOfferStep_default = /* @__PURE__ */ defineComponent({
	__name: "RetentionOfferStep",
	props: {
		offer: {},
		subscription: {},
		sessionId: {},
		workspaceId: {},
		isScopeCurrent: { type: Function },
		onDecide: { type: Function }
	},
	setup(__props) {
		const { t, n, locale } = useI18n();
		const { planName, creditGrant, includesCustomLoRAs } = useCancellationPlan();
		const { phase, accept, recordShown } = useRetentionOffer(__props.sessionId, __props.workspaceId);
		const percent = __props.offer.percent_off;
		const months = __props.offer.duration_in_months;
		const monthlyAmount = __props.subscription.unit_amount * __props.subscription.quantity;
		const discountedMonthly = discountedAmount(monthlyAmount, __props.offer);
		function headlinePrice(cents) {
			return formatCurrencyCents(locale.value, cents, __props.subscription.currency);
		}
		function exactAmount(cents) {
			return formatQuoteMoney(cents, __props.subscription.currency, locale.value);
		}
		function formatDate(date) {
			return date.toLocaleDateString(locale.value, {
				month: "long",
				day: "numeric",
				year: "numeric"
			});
		}
		const regularPrice = computed(() => headlinePrice(monthlyAmount));
		const discountedPrice = computed(() => headlinePrice(discountedMonthly));
		const regularAmount = computed(() => exactAmount(monthlyAmount));
		const discountedMonthlyAmount = computed(() => exactAmount(discountedMonthly));
		const savings = computed(() => exactAmount((monthlyAmount - discountedMonthly) * months));
		const discountStartDate = computed(() => formatDate(/* @__PURE__ */ new Date(__props.subscription.period_end * 1e3)));
		const fullPriceDate = computed(() => formatDate(fullPriceRenewal(__props.subscription.period_end, months)));
		const keepMessage = computed(() => {
			const grant = creditGrant.value;
			if (grant?.cycle !== "monthly") return t("subscription.retentionOffer.keepEverything", { plan: planName.value });
			const named = {
				credits: n(grant.credits),
				plan: planName.value
			};
			return includesCustomLoRAs.value ? t("subscription.retentionOffer.keepCreditsAndLoRAs", named) : t("subscription.retentionOffer.keepCredits", named);
		});
		const heading = computed(() => {
			const offered = {
				title: t("subscription.retentionOffer.title"),
				subtitle: t("subscription.retentionOffer.subtitle")
			};
			return {
				offered,
				accepting: offered,
				applied: {
					title: t("subscription.retentionOffer.appliedTitle", { plan: planName.value }),
					subtitle: t("subscription.retentionOffer.appliedBody", {
						percent,
						months,
						date: discountStartDate.value
					}, months)
				},
				failed: {
					title: t("subscription.retentionOffer.failedTitle"),
					subtitle: t("subscription.retentionOffer.failedBody", { plan: planName.value })
				},
				declined: {
					title: t("subscription.retentionOffer.failedTitle"),
					subtitle: t("subscription.retentionOffer.declinedBody", { plan: planName.value })
				},
				expired: {
					title: t("subscription.retentionOffer.expiredTitle"),
					subtitle: t("subscription.retentionOffer.expiredBody")
				},
				unconfirmed: {
					title: t("subscription.retentionOffer.unconfirmedTitle"),
					subtitle: t("subscription.retentionOffer.unconfirmedBody")
				}
			}[phase.value];
		});
		onMounted(() => {
			recordShown();
		});
		function close() {
			__props.onDecide(outcomeOnClose(phase.value));
		}
		async function acceptOffer() {
			if (!__props.isScopeCurrent()) {
				useToast().warning(t("subscription.cancelDialog.workspaceChanged"));
				close();
				return;
			}
			await accept();
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(CancellationStepLayout_default, {
				title: heading.value.title,
				subtitle: heading.value.subtitle,
				"close-disabled": unref(phase) === "accepting",
				"on-close": close
			}, createSlots({
				actions: withCtx(() => [unref(phase) === "offered" || unref(phase) === "accepting" ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [createVNode(Button_default, {
					variant: "inverted",
					size: "lg",
					loading: unref(phase) === "accepting",
					onClick: acceptOffer
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("subscription.retentionOffer.accept", {
						plan: unref(planName),
						percent: unref(percent)
					})), 1)]),
					_: 1
				}, 8, ["loading"]), createVNode(Button_default, {
					variant: "secondary",
					size: "lg",
					disabled: unref(phase) === "accepting",
					onClick: _cache[0] || (_cache[0] = ($event) => __props.onDecide("continueToCancel"))
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("subscription.cancelFlow.continueCancelling")), 1)]),
					_: 1
				}, 8, ["disabled"])], 64)) : unref(phase) === "failed" ? (openBlock(), createElementBlock(Fragment, { key: 1 }, [createVNode(Button_default, {
					variant: "inverted",
					size: "lg",
					onClick: acceptOffer
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("subscription.retentionOffer.tryAgain")), 1)]),
					_: 1
				}), createVNode(Button_default, {
					variant: "secondary",
					size: "lg",
					onClick: _cache[1] || (_cache[1] = ($event) => __props.onDecide("continueToCancel"))
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("subscription.cancelFlow.continueCancelling")), 1)]),
					_: 1
				})], 64)) : unref(phase) === "declined" || unref(phase) === "expired" ? (openBlock(), createElementBlock(Fragment, { key: 2 }, [createVNode(Button_default, {
					variant: "textonly",
					size: "lg",
					onClick: close
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("subscription.cancelFlow.keepPlan")), 1)]),
					_: 1
				}), createVNode(Button_default, {
					variant: "secondary",
					size: "lg",
					onClick: _cache[2] || (_cache[2] = ($event) => __props.onDecide("continueToCancel"))
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("subscription.cancelFlow.continueCancelling")), 1)]),
					_: 1
				})], 64)) : unref(phase) === "unconfirmed" ? (openBlock(), createElementBlock(Fragment, { key: 3 }, [createVNode(Button_default, {
					variant: "inverted",
					size: "lg",
					onClick: acceptOffer
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("subscription.retentionOffer.checkAgain")), 1)]),
					_: 1
				}), createVNode(Button_default, {
					variant: "secondary",
					size: "lg",
					onClick: close
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("g.close")), 1)]),
					_: 1
				})], 64)) : (openBlock(), createBlock(Button_default, {
					key: 4,
					variant: "secondary",
					size: "lg",
					class: "w-24",
					onClick: close
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("subscription.cancelFlow.done")), 1)]),
					_: 1
				}))]),
				default: withCtx(() => [unref(phase) === "offered" || unref(phase) === "accepting" ? (openBlock(), createElementBlock("div", _hoisted_1, [createBaseVNode("div", _hoisted_2, [
					createBaseVNode("div", _hoisted_3, [createBaseVNode("p", _hoisted_4, toDisplayString(_ctx.$t("subscription.retentionOffer.stayOnPlan", { plan: unref(planName) })), 1), createVNode(Badge_default, {
						variant: "compact",
						class: "bg-foreground text-background"
					}, {
						default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("subscription.retentionOffer.percentOff", { percent: unref(percent) })), 1)]),
						_: 1
					})]),
					createBaseVNode("p", _hoisted_5, [
						createBaseVNode("span", _hoisted_6, toDisplayString(discountedPrice.value), 1),
						createBaseVNode("span", _hoisted_7, toDisplayString(_ctx.$t("subscription.retentionOffer.perMonth")), 1),
						createBaseVNode("span", _hoisted_8, toDisplayString(regularPrice.value), 1)
					]),
					createBaseVNode("p", _hoisted_9, toDisplayString(_ctx.$t("subscription.retentionOffer.term", {
						regular: regularPrice.value,
						months: unref(months)
					}, unref(months))), 1),
					_cache[4] || (_cache[4] = createBaseVNode("div", {
						class: "h-px bg-border/50",
						role: "presentation"
					}, null, -1)),
					createBaseVNode("p", _hoisted_10, toDisplayString(keepMessage.value), 1)
				]), createBaseVNode("p", _hoisted_11, toDisplayString(_ctx.$t("subscription.retentionOffer.finePrint", {
					plan: unref(planName),
					regular: regularPrice.value,
					months: unref(months)
				}, unref(months))), 1)])) : unref(phase) === "applied" ? (openBlock(), createElementBlock("div", _hoisted_12, [createBaseVNode("div", _hoisted_13, [createBaseVNode("div", _hoisted_14, [createBaseVNode("span", _hoisted_15, [createTextVNode(toDisplayString(_ctx.$t("subscription.retentionOffer.nextPayments", { months: unref(months) }, unref(months))) + " ", 1), createVNode(Badge_default, {
					variant: "compact",
					class: "bg-foreground text-background"
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("subscription.retentionOffer.appliedBadge")), 1)]),
					_: 1
				})]), createBaseVNode("span", _hoisted_16, [createBaseVNode("span", _hoisted_17, toDisplayString(regularAmount.value), 1), createBaseVNode("span", null, toDisplayString(_ctx.$t("subscription.retentionOffer.pricePerMonth", { price: discountedMonthlyAmount.value })), 1)])]), createBaseVNode("p", _hoisted_18, toDisplayString(_ctx.$t("subscription.retentionOffer.savings", {
					savings: savings.value,
					months: unref(months)
				}, unref(months))), 1)]), createBaseVNode("p", _hoisted_19, toDisplayString(_ctx.$t("subscription.retentionOffer.renewsAt", {
					regular: regularAmount.value,
					date: fullPriceDate.value
				})), 1)])) : unref(phase) === "failed" || unref(phase) === "declined" ? (openBlock(), createElementBlock("p", _hoisted_20, toDisplayString(_ctx.$t("subscription.retentionOffer.supportCode")), 1)) : createCommentVNode("", true)]),
				_: 2
			}, [unref(phase) === "applied" ? {
				name: "title-icon",
				fn: withCtx(() => [_cache[3] || (_cache[3] = createBaseVNode("i", {
					class: "icon-[lucide--circle-check-big] size-6 text-success",
					"aria-hidden": "true"
				}, null, -1))]),
				key: "0"
			} : void 0]), 1032, [
				"title",
				"subtitle",
				"close-disabled"
			]);
		};
	}
});
//#endregion
//#region src/platform/billing/subscription/components/CancellationFlowDialogContent.vue
var CancellationFlowDialogContent_default = /* @__PURE__ */ defineComponent({
	__name: "CancellationFlowDialogContent",
	props: {
		cancelAt: {},
		surveyId: {},
		flow: {},
		workspaceId: {},
		isScopeCurrent: { type: Function }
	},
	setup(__props) {
		const { t } = useI18n();
		const dialogStore = useDialogStore();
		const telemetry = useTelemetry();
		const { subscription, tier } = useBillingContext();
		const offerSession = __props.flow?.offer && __props.workspaceId ? {
			offer: __props.flow.offer,
			subscription: __props.flow.subscription,
			sessionId: __props.flow.session_id,
			workspaceId: __props.workspaceId
		} : null;
		const stepAfterSurvey = offerSession ? "offer" : "confirm";
		const step = shallowRef(__props.surveyId ? "survey" : stepAfterSurvey);
		const cancelReport = createCancelFlowReporter(telemetry, () => ({
			duration: subscription.value?.duration,
			tier: tier.value
		}));
		let keptByOffer = false;
		function cancellationMetadata() {
			return getSubscriptionCancellationMetadata({
				cancelAt: __props.cancelAt,
				duration: subscription.value?.duration,
				endDate: subscription.value?.endDate,
				tier: tier.value
			});
		}
		onMounted(() => {
			if (__props.flow) recordRetentionFlowEvent(__props.flow.session_id, "flow_opened");
			telemetry?.trackSubscriptionCancellation("flow_opened", cancellationMetadata());
			cancelReport.intent();
		});
		onUnmounted(() => {
			if (step.value === "confirm" || keptByOffer) return;
			telemetry?.trackSubscriptionCancellation("abandoned", cancellationMetadata());
			cancelReport.abandoned();
		});
		function closeFlow() {
			dialogStore.closeDialog({ key: "cancel-subscription" });
		}
		function onSurveyExit(exit) {
			if (exit === "continue_cancelling") {
				step.value = stepAfterSurvey;
				return;
			}
			closeFlow();
		}
		function onOfferDecision(outcome) {
			if (outcome === "continueToCancel") {
				step.value = "confirm";
				return;
			}
			keptByOffer = outcome === "retained" || outcome === "pending";
			if (outcome === "pending") useToast().warning(t("subscription.retentionOffer.pendingToast"), { duration: 1e4 });
			closeFlow();
		}
		return (_ctx, _cache) => {
			return step.value === "survey" && __props.surveyId ? (openBlock(), createBlock(CancellationSurveyStep_default, {
				key: 0,
				"survey-id": __props.surveyId,
				"experiment-variant": __props.flow?.experiment_variant,
				"on-exit": onSurveyExit
			}, null, 8, ["survey-id", "experiment-variant"])) : step.value === "offer" && unref(offerSession) ? (openBlock(), createBlock(RetentionOfferStep_default, mergeProps({ key: 1 }, unref(offerSession), {
				"is-scope-current": __props.isScopeCurrent,
				"on-decide": onOfferDecision
			}), null, 16, ["is-scope-current"])) : (openBlock(), createBlock(CancelSubscriptionDialogContent_default, {
				key: 2,
				"cancel-at": __props.cancelAt,
				"is-scope-current": __props.isScopeCurrent,
				"flow-already-opened": ""
			}, null, 8, ["cancel-at", "is-scope-current"]));
		};
	}
});
//#endregion
export { CancellationFlowDialogContent_default as default };
