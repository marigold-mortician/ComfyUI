import { t as Load3dViewerContent_default } from "./Load3dViewerContent-DiX-pgUx.js";
export { Load3dViewerContent_default as default };
