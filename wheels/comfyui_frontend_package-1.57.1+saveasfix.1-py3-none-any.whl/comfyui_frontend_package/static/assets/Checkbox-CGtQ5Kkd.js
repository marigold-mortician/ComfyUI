import "./rolldown-runtime-xtsTai4I.js";
import { F as createBaseVNode, G as defineComponent, I as createBlock, Kt as normalizeClass, U as createVNode, Wt as unref, ct as openBlock, dt as renderSlot, et as mergeProps, q as guardReactiveProps, qt as normalizeProps, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { Ht as CheckboxRoot_default, Mn as useForwardPropsEmits, Rr as reactiveOmit, Vt as CheckboxIndicator_default } from "./vendor-reka-ui-NRTk7aIV.js";
import { t as cn } from "./src-BHQtMnZc.js";
//#endregion
//#region src/components/ui/checkbox/Checkbox.vue
var Checkbox_default = /* @__PURE__ */ defineComponent({
	__name: "Checkbox",
	props: {
		defaultValue: {},
		modelValue: {},
		disabled: { type: Boolean },
		value: {},
		id: {},
		trueValue: {},
		falseValue: {},
		asChild: { type: Boolean },
		as: {},
		name: {},
		required: { type: Boolean },
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	},
	emits: ["update:modelValue"],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emits = __emit;
		const forwarded = useForwardPropsEmits(reactiveOmit(props, "class"), emits);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(CheckboxRoot_default), mergeProps(unref(forwarded), {
				"data-slot": "checkbox",
				class: unref(cn)("inline-flex size-4 shrink-0 cursor-pointer items-center justify-center rounded-sm border bg-transparent text-background transition-colors outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:border-primary data-[state=checked]:bg-primary data-[state=indeterminate]:border-primary data-[state=indeterminate]:bg-primary", props.class)
			}), {
				default: withCtx((slotProps) => [createVNode(unref(CheckboxIndicator_default), { class: "flex items-center justify-center" }, {
					default: withCtx(() => [renderSlot(_ctx.$slots, "default", normalizeProps(guardReactiveProps(slotProps)), () => [createBaseVNode("i", { class: normalizeClass(unref(cn)("size-3", slotProps.state === "indeterminate" ? "icon-[lucide--minus]" : "icon-[lucide--check]")) }, null, 2)])]),
					_: 2
				}, 1024)]),
				_: 3
			}, 16, ["class"]);
		};
	}
});
//#endregion
export { Checkbox_default as t };
