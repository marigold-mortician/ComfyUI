import "./rolldown-runtime-xtsTai4I.js";
//#region src/extensions/core/load3d/cameraAngle.ts
var NODE_CLASS = "CameraAngle";
var MIN_WIDTH = 360;
var MIN_HEIGHT = 480;
var cameraAngleExtension = {
	name: "Comfy.CameraAngle",
	nodeCreated(node) {
		if (node.constructor.comfyClass !== NODE_CLASS) return;
		const [width, height] = node.size;
		node.setSize([Math.max(width, MIN_WIDTH), Math.max(height, MIN_HEIGHT)]);
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.cameraAngle = window.comfyAPI.cameraAngle || {};
window.comfyAPI.cameraAngle.cameraAngleExtension = cameraAngleExtension;
//#endregion
export { cameraAngleExtension };
