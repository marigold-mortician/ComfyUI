import "./rolldown-runtime-xtsTai4I.js";
import { n as DOMException } from "./delay-Cu8bS1zn.js";
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/error/TimeoutError.mjs
/**
* An error class representing a timeout operation.
* @augments DOMException
*/
var TimeoutError = class extends DOMException {
	constructor(message = "The operation was timed out") {
		super(message);
	}
};
//#endregion
export { TimeoutError as t };
