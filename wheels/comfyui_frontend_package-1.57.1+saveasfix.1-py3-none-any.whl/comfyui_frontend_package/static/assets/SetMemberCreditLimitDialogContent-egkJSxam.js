import "./rolldown-runtime-xtsTai4I.js";
import { t as useTeamWorkspaceStore } from "./teamWorkspaceStore-BNm5cZOK.js";
import { C as vModelText, F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, I as createBlock, L as createCommentVNode, P as computed, R as createElementBlock, Tt as withDirectives, U as createVNode, Wt as unref, Yt as toDisplayString, ct as openBlock, gt as useId, wt as withCtx, x as vModelRadio } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
import { t as AppDialogPanel_default } from "./AppDialogPanel-BklaJBTn.js";
//#region src/platform/workspace/components/dialogs/SetMemberCreditLimitDialogContent.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "m-0 text-muted-foreground" };
var _hoisted_2 = { class: "flex cursor-pointer flex-col gap-2 text-muted-foreground" };
var _hoisted_3 = ["id", "name"];
var _hoisted_4 = { class: "flex flex-1 flex-col gap-2" };
var _hoisted_5 = ["for"];
var _hoisted_6 = { class: "flex h-10 items-center gap-2 rounded-lg bg-secondary px-4" };
var _hoisted_7 = ["aria-label"];
var _hoisted_8 = ["id", "name"];
var _hoisted_9 = ["for"];
var _hoisted_10 = {
	key: 0,
	class: "m-0 flex gap-1 text-credit"
};
var _hoisted_11 = {
	key: 1,
	class: "m-0 text-destructive"
};
//#endregion
//#region src/platform/workspace/components/dialogs/SetMemberCreditLimitDialogContent.vue
var SetMemberCreditLimitDialogContent_default = /* @__PURE__ */ defineComponent({
	__name: "SetMemberCreditLimitDialogContent",
	props: {
		memberId: {},
		memberName: {},
		creditsUsed: {},
		currentLimit: {}
	},
	setup(__props) {
		const dialogStore = useDialogStore();
		const workspaceStore = useTeamWorkspaceStore();
		const { n } = useI18n();
		const modeGroupName = useId();
		const mode = ref(__props.currentLimit !== null && __props.currentLimit !== void 0 ? "limited" : "unlimited");
		const limitInput = ref(__props.currentLimit?.toString() ?? "");
		const limitModel = computed({
			get: () => {
				if (!limitInput.value) return "";
				const value = Number(limitInput.value);
				return Number.isSafeInteger(value) ? n(value) : limitInput.value;
			},
			set: (value) => {
				limitInput.value = value.replace(/[^0-9]/g, "");
			}
		});
		const parsedLimit = computed(() => Number(limitInput.value));
		const hasValidLimit = computed(() => Number.isSafeInteger(parsedLimit.value) && parsedLimit.value > 0);
		const canUpdate = computed(() => mode.value === "unlimited" || hasValidLimit.value);
		const showError = computed(() => mode.value === "limited" && limitInput.value.length > 0 && !hasValidLimit.value);
		const showWarning = computed(() => mode.value === "limited" && __props.creditsUsed !== void 0 && hasValidLimit.value && parsedLimit.value <= __props.creditsUsed);
		function onClose() {
			dialogStore.closeDialog({ key: "set-member-credit-limit" });
		}
		function onUpdate() {
			if (!canUpdate.value) return;
			workspaceStore.setMemberCreditLimit(__props.memberId, mode.value === "limited" ? parsedLimit.value : null);
			onClose();
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(AppDialogPanel_default, {
				"body-class": "flex flex-col gap-6 text-sm",
				onClose
			}, {
				title: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.members.creditLimitDialog.title", { name: __props.memberName })), 1)]),
				footer: withCtx(() => [createVNode(Button_default, {
					variant: "muted-textonly",
					onClick: onClose
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("g.cancel")), 1)]),
					_: 1
				}), createVNode(Button_default, {
					variant: "secondary",
					size: "lg",
					disabled: !canUpdate.value,
					onClick: onUpdate
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.members.creditLimitDialog.update")), 1)]),
					_: 1
				}, 8, ["disabled"])]),
				default: withCtx(() => [
					createBaseVNode("p", _hoisted_1, toDisplayString(_ctx.$t("workspacePanel.members.creditLimitDialog.description")), 1),
					createBaseVNode("div", _hoisted_2, [createBaseVNode("div", {
						class: "flex items-start gap-2 rounded-lg p-2 transition-colors hover:bg-accent/30",
						onClick: _cache[3] || (_cache[3] = ($event) => mode.value = "limited")
					}, [withDirectives(createBaseVNode("input", {
						id: `${unref(modeGroupName)}-limited`,
						"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => mode.value = $event),
						type: "radio",
						name: unref(modeGroupName),
						value: "limited",
						class: "mt-0.5 size-4 appearance-none rounded-full border border-muted checked:border-3 checked:bg-white focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
					}, null, 8, _hoisted_3), [[vModelRadio, mode.value]]), createBaseVNode("span", _hoisted_4, [createBaseVNode("label", { for: `${unref(modeGroupName)}-limited` }, toDisplayString(_ctx.$t("workspacePanel.members.creditLimitDialog.limitOption")), 9, _hoisted_5), createBaseVNode("span", _hoisted_6, [_cache[6] || (_cache[6] = createBaseVNode("i", { class: "icon-[lucide--coins] size-4 shrink-0 text-credit" }, null, -1)), withDirectives(createBaseVNode("input", {
						"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => limitModel.value = $event),
						inputmode: "numeric",
						"aria-label": _ctx.$t("workspacePanel.members.creditLimitDialog.limitOption"),
						class: "w-full border-none bg-transparent text-foreground tabular-nums outline-none",
						onFocus: _cache[2] || (_cache[2] = ($event) => mode.value = "limited")
					}, null, 40, _hoisted_7), [[vModelText, limitModel.value]])])])]), createBaseVNode("div", {
						class: "flex items-center gap-2 rounded-lg p-2 transition-colors hover:bg-accent/30",
						onClick: _cache[5] || (_cache[5] = ($event) => mode.value = "unlimited")
					}, [withDirectives(createBaseVNode("input", {
						id: `${unref(modeGroupName)}-unlimited`,
						"onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => mode.value = $event),
						type: "radio",
						name: unref(modeGroupName),
						value: "unlimited",
						class: "size-4 appearance-none rounded-full border border-muted checked:border-3 checked:bg-white focus-visible:ring-2 focus-visible:ring-ring focus-visible:outline-none"
					}, null, 8, _hoisted_8), [[vModelRadio, mode.value]]), createBaseVNode("label", { for: `${unref(modeGroupName)}-unlimited` }, toDisplayString(_ctx.$t("workspacePanel.members.creditLimitDialog.noLimit")), 9, _hoisted_9)])]),
					showWarning.value ? (openBlock(), createElementBlock("p", _hoisted_10, [_cache[7] || (_cache[7] = createBaseVNode("i", { class: "mt-0.5 icon-[lucide--triangle-alert] size-4 shrink-0" }, null, -1)), createTextVNode(" " + toDisplayString(_ctx.$t("workspacePanel.members.creditLimitDialog.warning", { credits: _ctx.$n(__props.creditsUsed ?? 0) })), 1)])) : createCommentVNode("", true),
					showError.value ? (openBlock(), createElementBlock("p", _hoisted_11, toDisplayString(_ctx.$t("workspacePanel.members.creditLimitDialog.invalidLimit")), 1)) : createCommentVNode("", true)
				]),
				_: 1
			});
		};
	}
});
//#endregion
export { SetMemberCreditLimitDialogContent_default as default };
