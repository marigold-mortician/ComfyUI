import "./rolldown-runtime-xtsTai4I.js";
import { t as clamp } from "./clamp-C6J77Y5a.js";
import { i as api } from "./api-BdJmXw98.js";
import { Ft as ref, Mt as onScopeDispose, P as computed, Pt as readonly, Rt as shallowRef, bt as watch, d as defineStore, zt as toRaw } from "./vendor-vue-core-CuN1excl.js";
import { Mr as useWindowSize, ar as useEventListener, pr as useLocalStorage } from "./vendor-reka-ui-NRTk7aIV.js";
import { n as useWorkflowStore } from "./workflowStore-DP6mciq-.js";
import { n as useTelemetry } from "./telemetry-IkzvF0TI.js";
import { t as useFeatureFlags } from "./useFeatureFlags-B3zg5FdZ.js";
//#region src/platform/serverFacts/pendingServerFact.ts
/**
* Interim bridge for a server fact the API does not emit yet. It expires with
* the ticket: CI fails once the backend ticket closes, until the shipped field
* is rendered and the wrapper deleted. See ADR-API-SERVER-FACTS-0042.
*
* `Field` is inferred from the gate it fills; without one it widens to
* `string`, which no gate accepts.
*/
function pendingServerFact(_ticket, value) {
	return value;
}
//#endregion
//#region src/workbench/extensions/agent/stores/agent/creditTransitionNoticeState.ts
function reduceScopedRead(state, identity, scopedHasFunds) {
	if (state === null || state.identity !== identity || scopedHasFunds) return {
		identity,
		scopedHasFunds,
		phase: "idle"
	};
	if (state.phase === "dismissed") return {
		...state,
		scopedHasFunds
	};
	const phase = state.scopedHasFunds ? "armed" : state.phase;
	return {
		...state,
		scopedHasFunds,
		phase
	};
}
function reduceCreditTransitionNotice(state, event) {
	if (event.type === "scopedRead") return reduceScopedRead(state, event.identity, event.scopedHasFunds);
	if (state === null || state.identity !== event.identity) return state;
	switch (event.type) {
		case "shown": return state.phase === "armed" ? {
			...state,
			phase: "shown"
		} : state;
		case "dismissed": return {
			...state,
			phase: "dismissed"
		};
		default: return event;
	}
}
function isCreditTransitionNoticeShown(state, identity) {
	if (state === null || state.identity !== identity) return false;
	return state.phase === "armed" || state.phase === "shown";
}
//#endregion
//#region src/workbench/extensions/agent/stores/agent/agentPanelStore.ts
var PANEL_MIN_WIDTH = 420;
var PANEL_MAX_WIDTH = 960;
var FUNDS_RECHECK_TIMEOUT_MS = 1e4;
var OPEN_STORAGE_KEY = "Comfy.AgentPanel.open";
var DISCOVERED_STORAGE_KEY = "Comfy.AgentPanel.discovered";
var DEFAULT_ONBOARDING = {
	startup: "activationVisits",
	offerMemory: "shown",
	agentButton: "requestConsent",
	persistSkipAsRefusal: true,
	introduceBeforeSignIn: false
};
var DESKTOP_ONBOARDING = {
	startup: "lockedUntilConsent",
	offerMemory: "answered",
	agentButton: "togglePanel",
	persistSkipAsRefusal: false,
	introduceBeforeSignIn: true
};
function isLocalDesktopApp() {
	const bridge = window.__comfyDesktop2;
	if (!bridge) return false;
	return !(bridge.isRemote?.() ?? window.__comfyDesktop2Remote ?? false);
}
var useAgentPanelStore = defineStore("agentPanel", () => {
	const enabled = ref(false);
	const consentAccepted = ref(false);
	const isOpen = useLocalStorage(OPEN_STORAGE_KEY, false, { writeDefaults: false });
	/** Whether the panel has ever been shown to this user, on any visit. */
	const hasEverOpened = useLocalStorage(DISCOVERED_STORAGE_KEY, false, { writeDefaults: false });
	const gateSettled = ref(false);
	const view = shallowRef({ screen: "chat" });
	const { flags: featureFlags } = useFeatureFlags();
	const flagsSettled = computed(() => api.serverFeatureFlagsSettled.value);
	const onboarding = computed(() => pendingServerFact("BE-22051", isLocalDesktopApp() ? DESKTOP_ONBOARDING : DEFAULT_ONBOARDING));
	/** The server's `agent` feature; undefined unless its state is known. */
	const comfyAgent = computed(() => {
		const agent = featureFlags.agent;
		return agent?.state === "starting" || agent?.state === "ready" || agent?.state === "failed" ? agent : void 0;
	});
	const maximized = ref(false);
	const draggedWidth = ref(PANEL_MIN_WIDTH);
	/**
	* Width the workspace left of the panel needs: the side toolbar, plus the
	* sidebar when one is open. The layout that owns those keeps it current, so
	* the panel gives way the moment it would meet the sidebar.
	*/
	const reservedWorkspaceWidth = ref(368);
	const reportedExhaustionIdentity = ref(null);
	const reportedFreeUseExposure = ref(false);
	const reportedFreeUseImpression = ref(false);
	const fundsRechecks = ref(/* @__PURE__ */ new Map());
	const fundsRecheckTimeouts = /* @__PURE__ */ new Map();
	const fundsRecheckFinished = /* @__PURE__ */ new Map();
	let nextFundsRecheckId = 0;
	const creditTransitionNotice = shallowRef(null);
	const dismissedSelectionSignature = ref(null);
	const workflowStore = useWorkflowStore();
	const targetTracking = ref({ mode: "uninitialized" });
	const followsVisibleWorkflow = computed(() => targetTracking.value.mode === "following");
	const selectedWorkflow = computed(() => {
		const target = targetTracking.value;
		if (target.mode === "following") return workflowStore.activeWorkflow;
		return target.mode === "retained" ? target.workflow : null;
	});
	const targetUnavailable = computed(() => targetTracking.value.mode === "retained" && targetTracking.value.workflow === null && targetTracking.value.unavailable === true);
	const canRestoreWorkflow = computed(() => targetTracking.value.mode === "restoring");
	function beginWorkflowRestoration() {
		targetTracking.value = { mode: "restoring" };
	}
	function interruptHistorySelection() {
		if (view.value.screen === "history" && view.value.selection.status === "loading") view.value = {
			...view.value,
			selection: {
				status: "failed",
				id: view.value.selection.id
			}
		};
	}
	function initializeTargetTracking(hasThread) {
		if (targetTracking.value.mode !== "uninitialized") return;
		targetTracking.value = { mode: hasThread ? "restoring" : "following" };
	}
	function retainWorkflowTarget() {
		if (targetTracking.value.mode === "retained") return;
		setWorkflowTarget(selectedWorkflow.value);
	}
	function startFollowingVisibleWorkflow() {
		targetTracking.value = { mode: "following" };
	}
	function setWorkflowTarget(workflow) {
		targetTracking.value = workflow === null ? {
			mode: "retained",
			workflow: null
		} : {
			mode: "retained",
			workflow
		};
	}
	function markWorkflowTargetUnavailable() {
		targetTracking.value = {
			mode: "retained",
			workflow: null,
			unavailable: true
		};
	}
	function detachClosedTarget(workflow) {
		targetTracking.value = workflow.isTemporary ? {
			mode: "retained",
			workflow: null
		} : {
			mode: "retained",
			workflow: null,
			closedPath: workflow.path
		};
	}
	watch(() => [targetTracking.value, ...workflowStore.openWorkflows], () => {
		const target = targetTracking.value;
		if (target.mode !== "retained") return;
		if (target.workflow !== null) {
			if (!workflowStore.openWorkflows.includes(target.workflow)) detachClosedTarget(target.workflow);
		} else if (workflowStore.openWorkflows.some(({ path }) => path === target.closedPath)) setWorkflowTarget(null);
	});
	function isRetainedTarget(workflow) {
		const target = targetTracking.value;
		if (target.mode !== "retained") return false;
		return target.workflow === null ? target.closedPath === workflow.path : toRaw(target.workflow) === toRaw(workflow);
	}
	function followClosedTargetRename(oldPath, newPath) {
		const target = targetTracking.value;
		if (target.mode === "retained" && target.workflow === null && target.closedPath === oldPath) targetTracking.value = {
			mode: "retained",
			workflow: null,
			closedPath: newPath
		};
	}
	workflowStore.$onAction(({ name, args, after }) => {
		if (name === "deleteWorkflow") {
			const [workflow] = args;
			if (!workflow.isTemporary) after(() => {
				if (isRetainedTarget(workflow)) markWorkflowTargetUnavailable();
			});
		} else if (name === "renameWorkflow") {
			const [workflow] = args;
			const oldPath = workflow.path;
			after(() => followClosedTargetRename(oldPath, workflow.path));
		}
	});
	let openedAt = null;
	let teardownReported = false;
	function startOpenEpoch() {
		openedAt = Date.now();
		teardownReported = false;
		reportedFreeUseExposure.value = false;
		reportedFreeUseImpression.value = false;
	}
	const isVisible = computed(() => enabled.value && isOpen.value);
	watch(isVisible, (visible) => {
		if (!visible) {
			openedAt = null;
			return;
		}
		hasEverOpened.value = true;
		if (openedAt !== null) return;
		startOpenEpoch();
		useTelemetry()?.trackAgentPanelOpened({ source: "restored" });
	});
	const { width: windowWidth } = useWindowSize();
	/**
	* Falls below `PANEL_MIN_WIDTH` when the window leaves less room than that.
	* A panel narrower than its minimum still beats one that leaves the window.
	*/
	const maxWidth = computed(() => clamp(windowWidth.value - reservedWorkspaceWidth.value, 0, PANEL_MAX_WIDTH));
	/**
	* The rendered width. Narrowing the window clamps it; widening restores the
	* width the user asked for, so a maximized panel never leaves the viewport.
	*/
	const width = computed(() => Math.min(maxWidth.value, maximized.value ? PANEL_MAX_WIDTH : draggedWidth.value));
	const requestedWidth = computed(() => maximized.value ? PANEL_MAX_WIDTH : draggedWidth.value);
	const isOverlay = computed(() => windowWidth.value <= requestedWidth.value + reservedWorkspaceWidth.value);
	const isMaximized = computed(() => maximized.value);
	function open(source = "topbar_button") {
		if (isOpen.value) return;
		isOpen.value = true;
		startOpenEpoch();
		useTelemetry()?.trackAgentPanelOpened({ source });
	}
	function close(source) {
		if (!isOpen.value) return;
		isOpen.value = false;
		const openDurationMs = openedAt === null ? null : Date.now() - openedAt;
		openedAt = null;
		useTelemetry()?.trackAgentPanelClosed({
			source,
			open_duration_ms: openDurationMs
		});
	}
	function suppressRestoredOpen() {
		if (!isOpen.value || isVisible.value) return;
		isOpen.value = false;
		openedAt = null;
	}
	useEventListener(window, "pagehide", () => {
		if (!isVisible.value || openedAt === null || teardownReported) return;
		teardownReported = true;
		useTelemetry()?.trackAgentPanelClosed({
			source: "pagehide",
			open_duration_ms: Date.now() - openedAt
		});
	});
	useEventListener(window, "pageshow", (event) => {
		if (!event.persisted || !isVisible.value) return;
		openedAt = Date.now();
		teardownReported = false;
	});
	function toggle() {
		if (isOpen.value) close("topbar_button");
		else open();
	}
	function setReservedWorkspaceWidth(px) {
		reservedWorkspaceWidth.value = Math.max(0, px);
	}
	function setWidth(px) {
		maximized.value = false;
		draggedWidth.value = clamp(px, PANEL_MIN_WIDTH, PANEL_MAX_WIDTH);
	}
	function toggleMaximize() {
		maximized.value = !maximized.value;
		if (!maximized.value) draggedWidth.value = PANEL_MIN_WIDTH;
	}
	function dispatchCreditTransitionNotice(event) {
		const before = creditTransitionNotice.value;
		creditTransitionNotice.value = reduceCreditTransitionNotice(before, event);
		return creditTransitionNotice.value !== before;
	}
	function observeAgentScopedFunds(identity, scopedHasFunds) {
		dispatchCreditTransitionNotice({
			type: "scopedRead",
			identity,
			scopedHasFunds
		});
	}
	function claimCreditTransitionNoticeImpression(identity) {
		return dispatchCreditTransitionNotice({
			type: "shown",
			identity
		});
	}
	function dismissCreditTransitionNotice(identity) {
		dispatchCreditTransitionNotice({
			type: "dismissed",
			identity
		});
	}
	function beginFundsRecheck(identity, onFinished) {
		const id = ++nextFundsRecheckId;
		fundsRechecks.value.set(id, identity);
		if (onFinished) fundsRecheckFinished.set(id, onFinished);
		fundsRecheckTimeouts.set(id, setTimeout(() => finishFundsRecheck(id), FUNDS_RECHECK_TIMEOUT_MS));
		return id;
	}
	function finishFundsRecheck(id) {
		clearTimeout(fundsRecheckTimeouts.get(id));
		fundsRecheckTimeouts.delete(id);
		fundsRechecks.value.delete(id);
		fundsRecheckFinished.get(id)?.();
		fundsRecheckFinished.delete(id);
	}
	function cancelFundsRechecks() {
		for (const id of fundsRechecks.value.keys()) finishFundsRecheck(id);
	}
	function hasPendingFundsRecheck(identity) {
		return [...fundsRechecks.value.values()].includes(identity);
	}
	onScopeDispose(cancelFundsRechecks);
	return {
		enabled,
		consentAccepted,
		isOpen,
		isVisible,
		hasEverOpened,
		gateSettled,
		view,
		interruptHistorySelection,
		flagsSettled,
		comfyAgent,
		onboarding,
		reportedExhaustionIdentity,
		reportedFreeUseExposure,
		reportedFreeUseImpression,
		creditTransitionNotice: readonly(creditTransitionNotice),
		observeAgentScopedFunds,
		claimCreditTransitionNoticeImpression,
		dismissCreditTransitionNotice,
		beginFundsRecheck,
		finishFundsRecheck,
		cancelFundsRechecks,
		hasPendingFundsRecheck,
		width,
		requestedWidth,
		isOverlay,
		isMaximized,
		dismissedSelectionSignature,
		open,
		targetTracking,
		followsVisibleWorkflow,
		initializeTargetTracking,
		retainWorkflowTarget,
		startFollowingVisibleWorkflow,
		selectedWorkflow,
		targetUnavailable,
		markWorkflowTargetUnavailable,
		canRestoreWorkflow,
		beginWorkflowRestoration,
		setWorkflowTarget,
		toggle,
		close,
		suppressRestoredOpen,
		setWidth,
		setReservedWorkspaceWidth,
		toggleMaximize
	};
});
//#endregion
export { isCreditTransitionNoticeShown as n, pendingServerFact as r, useAgentPanelStore as t };
