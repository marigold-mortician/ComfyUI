import "./rolldown-runtime-xtsTai4I.js";
import { A as BufferGeometry, Bt as TorusGeometry, Ht as Vector2, Mt as SphereGeometry, P as CatmullRomCurve3, Q as LineBasicMaterial, U as Float32BufferAttribute, Ut as Vector3, Vt as TubeGeometry, Z as Line, _t as Plane, lt as Mesh, pt as MeshStandardMaterial, q as Group, ut as MeshBasicMaterial } from "./vendor-three-B-UiePqj.js";
import { _ as ControlsManager, d as Viewport3d, g as EventManager, h as LightingManager, n as SceneManager, t as ViewHelperManager, v as CameraManager, y as RendererView } from "./ViewHelperManager-BpbYuVKl.js";
import { t as useChainCallback } from "./useChainCallback-Bm3zfHjO.js";
//#region src/extensions/core/load3d/composables/useViewportNodeWiring.ts
function useViewportNodeWiring() {
	const wrappedWidgets = [];
	const wrappedSet = /* @__PURE__ */ new WeakSet();
	let wiredNode = null;
	let originalOnMouseEnter;
	let originalOnMouseLeave;
	let originalOnConnectionsChange;
	function wireWidgets(node, names, onChange) {
		for (const name of names) {
			const widget = node.widgets?.find((w) => w.name === name);
			if (!widget || wrappedSet.has(widget)) continue;
			wrappedSet.add(widget);
			const original = widget.callback;
			wrappedWidgets.push({
				widget,
				original
			});
			widget.callback = (value, ...rest) => {
				original?.call(widget, value, ...rest);
				onChange(widget);
			};
		}
	}
	function wireNode(node, hooks) {
		unwireNode();
		wiredNode = node;
		originalOnMouseEnter = node.onMouseEnter;
		originalOnMouseLeave = node.onMouseLeave;
		originalOnConnectionsChange = node.onConnectionsChange;
		node.onMouseEnter = useChainCallback(node.onMouseEnter, () => {
			const viewport = hooks.viewport();
			viewport?.updateStatusMouseOnNode(true);
			viewport?.refreshViewport();
		});
		node.onMouseLeave = useChainCallback(node.onMouseLeave, () => {
			hooks.viewport()?.updateStatusMouseOnNode(false);
		});
		if (hooks.onConnectionsChange) node.onConnectionsChange = useChainCallback(node.onConnectionsChange, hooks.onConnectionsChange);
	}
	function unwireNode() {
		if (!wiredNode) return;
		wiredNode.onMouseEnter = originalOnMouseEnter;
		wiredNode.onMouseLeave = originalOnMouseLeave;
		wiredNode.onConnectionsChange = originalOnConnectionsChange;
		wiredNode = null;
	}
	function unwire() {
		for (const { widget, original } of wrappedWidgets) {
			widget.callback = original;
			wrappedSet.delete(widget);
		}
		wrappedWidgets.length = 0;
		unwireNode();
	}
	return {
		wireWidgets,
		wireNode,
		unwire
	};
}
function createSceneHoverHandlers(viewport) {
	return {
		handleMouseEnter() {
			const target = viewport();
			target?.updateStatusMouseOnScene(true);
			target?.refreshViewport();
		},
		handleMouseLeave() {
			viewport()?.updateStatusMouseOnScene(false);
		}
	};
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.useViewportNodeWiring = window.comfyAPI.useViewportNodeWiring || {};
window.comfyAPI.useViewportNodeWiring.useViewportNodeWiring = useViewportNodeWiring;
window.comfyAPI.useViewportNodeWiring.createSceneHoverHandlers = createSceneHoverHandlers;
//#endregion
//#region packages/viewport3d/src/cameraInfo/handles/OrbitHandles.ts
var RING_RADIUS = 1.5;
var HANDLE_RADIUS = .08;
var GLOW_RADIUS = .12;
var TUBE_RADIUS = .025;
var ARC_PITCH_LIMIT = 85;
var ARC_SEGMENTS = 32;
var YAW_COLOR = 54527;
var PITCH_COLOR = 16738047;
var DISTANCE_COLOR = 16763904;
var BASE_GLOW_OPACITY = .25;
var HOVER_GLOW_OPACITY = .6;
var HOVER_SCALE = 1.35;
var ORBIT_HANDLE_TYPES = {
	yaw: true,
	pitch: true,
	distance: true
};
var isOrbitHandleType = (value) => Object.hasOwn(ORBIT_HANDLE_TYPES, value);
var DEG2RAD = Math.PI / 180;
function buildArcCurve({ min, max }) {
	const points = [];
	for (let deg = min; deg <= max; deg += 5) {
		const r = deg * DEG2RAD;
		points.push(new Vector3(0, RING_RADIUS * Math.sin(r), RING_RADIUS * Math.cos(r)));
	}
	return new CatmullRomCurve3(points);
}
function makeHandle(color, type) {
	const mesh = new Mesh(new SphereGeometry(HANDLE_RADIUS, 32, 32), new MeshStandardMaterial({
		color,
		emissive: color,
		emissiveIntensity: .7,
		roughness: .3,
		metalness: .2
	}));
	mesh.userData.handleType = type;
	return mesh;
}
function makeGlow(color) {
	return new Mesh(new SphereGeometry(GLOW_RADIUS, 16, 16), new MeshBasicMaterial({
		color,
		transparent: true,
		opacity: BASE_GLOW_OPACITY,
		depthWrite: false,
		blending: 2
	}));
}
var OrbitHandles = class {
	root = new Group();
	yawGroup = new Group();
	yawRing;
	pitchArc;
	distanceLine;
	distanceLineGeometry;
	yawHandle;
	pitchHandle;
	distanceHandle;
	yawHandleGlow;
	pitchHandleGlow;
	distanceHandleGlow;
	yawRingRadius;
	yawRingHeight;
	scene = null;
	disposed = false;
	constructor({ pitchLimits = {
		min: -85,
		max: ARC_PITCH_LIMIT
	}, yawRingLatitude = 0 } = {}) {
		this.root.name = "CameraInfoOrbitHandles";
		this.root.add(this.yawGroup);
		const latitude = yawRingLatitude * DEG2RAD;
		this.yawRingRadius = RING_RADIUS * Math.cos(latitude);
		this.yawRingHeight = RING_RADIUS * Math.sin(latitude);
		this.yawRing = new Mesh(new TorusGeometry(this.yawRingRadius, TUBE_RADIUS, 16, 96), new MeshBasicMaterial({
			color: YAW_COLOR,
			transparent: true,
			opacity: .55
		}));
		this.yawRing.rotation.x = Math.PI / 2;
		this.yawRing.position.y = this.yawRingHeight;
		this.root.add(this.yawRing);
		this.pitchArc = new Mesh(new TubeGeometry(buildArcCurve(pitchLimits), ARC_SEGMENTS, TUBE_RADIUS, 8, false), new MeshBasicMaterial({
			color: PITCH_COLOR,
			transparent: true,
			opacity: .55
		}));
		this.yawGroup.add(this.pitchArc);
		this.distanceLineGeometry = new BufferGeometry();
		this.distanceLineGeometry.setAttribute("position", new Float32BufferAttribute([
			0,
			0,
			0,
			0,
			0,
			1
		], 3));
		this.distanceLine = new Line(this.distanceLineGeometry, new LineBasicMaterial({
			color: DISTANCE_COLOR,
			transparent: true,
			opacity: .55
		}));
		this.yawGroup.add(this.distanceLine);
		this.yawHandle = makeHandle(YAW_COLOR, "yaw");
		this.yawHandleGlow = makeGlow(YAW_COLOR);
		this.yawHandle.add(this.yawHandleGlow);
		this.root.add(this.yawHandle);
		this.pitchHandle = makeHandle(PITCH_COLOR, "pitch");
		this.pitchHandleGlow = makeGlow(PITCH_COLOR);
		this.pitchHandle.add(this.pitchHandleGlow);
		this.yawGroup.add(this.pitchHandle);
		this.distanceHandle = makeHandle(DISTANCE_COLOR, "distance");
		this.distanceHandleGlow = makeGlow(DISTANCE_COLOR);
		this.distanceHandle.add(this.distanceHandleGlow);
		this.yawGroup.add(this.distanceHandle);
	}
	attach(scene) {
		this.scene = scene;
		scene.add(this.root);
	}
	detach() {
		if (!this.scene) return;
		this.scene.remove(this.root);
		this.scene = null;
	}
	dispose() {
		if (this.disposed) return;
		this.disposed = true;
		this.detach();
		const disposables = [
			this.yawRing.geometry,
			this.yawRing.material,
			this.pitchArc.geometry,
			this.pitchArc.material,
			this.distanceLineGeometry,
			this.distanceLine.material,
			this.yawHandle.geometry,
			this.yawHandle.material,
			this.pitchHandle.geometry,
			this.pitchHandle.material,
			this.distanceHandle.geometry,
			this.distanceHandle.material,
			this.yawHandleGlow.geometry,
			this.yawHandleGlow.material,
			this.pitchHandleGlow.geometry,
			this.pitchHandleGlow.material,
			this.distanceHandleGlow.geometry,
			this.distanceHandleGlow.material
		];
		for (const d of disposables) d.dispose();
	}
	setVisible(visible) {
		this.root.visible = visible;
	}
	isVisible() {
		return this.root.visible;
	}
	update(state) {
		const visible = state.mode === "orbit";
		this.root.visible = visible;
		if (!visible) return;
		this.root.position.set(state.target.x, state.target.y, state.target.z);
		const yawRad = state.orbit.yaw * DEG2RAD;
		const pitchRad = state.orbit.pitch * DEG2RAD;
		const cosP = Math.cos(pitchRad);
		const sinP = Math.sin(pitchRad);
		this.yawGroup.rotation.y = yawRad;
		this.yawHandle.position.set(this.yawRingRadius * Math.sin(yawRad), this.yawRingHeight, this.yawRingRadius * Math.cos(yawRad));
		this.pitchHandle.position.set(0, RING_RADIUS * sinP, RING_RADIUS * cosP);
		const endY = state.orbit.distance * sinP;
		const endZ = state.orbit.distance * cosP;
		this.distanceHandle.position.set(0, endY, endZ);
		const positions = this.distanceLineGeometry.attributes.position;
		positions.setXYZ(1, 0, endY, endZ);
		positions.needsUpdate = true;
	}
	pickableMeshes() {
		return [
			this.yawHandle,
			this.pitchHandle,
			this.distanceHandle
		];
	}
	setHovered(type) {
		const entries = [
			[
				this.yawHandle,
				this.yawHandleGlow,
				"yaw"
			],
			[
				this.pitchHandle,
				this.pitchHandleGlow,
				"pitch"
			],
			[
				this.distanceHandle,
				this.distanceHandleGlow,
				"distance"
			]
		];
		for (const [handle, glow, handleType] of entries) {
			const active = handleType === type;
			handle.scale.setScalar(active ? HOVER_SCALE : 1);
			glow.material.opacity = active ? HOVER_GLOW_OPACITY : BASE_GLOW_OPACITY;
		}
	}
	dragPlaneFor(type, state) {
		if (type === "yaw") return new Plane(new Vector3(0, 1, 0), -(state.target.y + this.yawRingHeight));
		const yawRad = state.orbit.yaw * DEG2RAD;
		const normal = new Vector3(-Math.cos(yawRad), 0, Math.sin(yawRad)).normalize();
		const targetVec = vec(state.target);
		return new Plane().setFromNormalAndCoplanarPoint(normal, targetVec);
	}
};
var vec = (v) => new Vector3(v.x, v.y, v.z);
//#endregion
//#region packages/viewport3d/src/cameraInfo/handles/handlePicking.ts
var PICK_PIXEL_RADIUS = 14;
function readHandleType(object) {
	const { handleType } = object.userData;
	return typeof handleType === "string" ? handleType : null;
}
function toScreenPx(ndcX, ndcY, canvas) {
	return new Vector2((ndcX + 1) * .5 * canvas.clientWidth, (1 - (ndcY + 1) * .5) * canvas.clientHeight);
}
function pickHandleAtPointer(raycaster, pointerNdc, camera, targets, canvas) {
	if (targets.length === 0) return null;
	raycaster.setFromCamera(pointerNdc, camera);
	const hits = raycaster.intersectObjects(targets, false);
	if (hits.length > 0) return readHandleType(hits[0].object);
	const pointerPx = toScreenPx(pointerNdc.x, pointerNdc.y, canvas);
	const world = new Vector3();
	let best = null;
	let bestDistance = PICK_PIXEL_RADIUS;
	for (const target of targets) {
		target.getWorldPosition(world);
		if (world.clone().applyMatrix4(camera.matrixWorldInverse).z >= 0) continue;
		const ndc = world.project(camera);
		const distance = toScreenPx(ndc.x, ndc.y, canvas).distanceTo(pointerPx);
		if (distance < bestDistance) {
			bestDistance = distance;
			best = readHandleType(target);
		}
	}
	return best;
}
//#endregion
//#region packages/viewport3d/src/load3d/createViewport3d.ts
function buildViewport3dDeps(container) {
	const view = new RendererView(container);
	const renderer = view.renderer;
	const eventManager = new EventManager();
	const cameraManager = new CameraManager(renderer, eventManager);
	const controlsManager = new ControlsManager(container, cameraManager.activeCamera);
	cameraManager.setControls(controlsManager.controls);
	const getActiveCamera = () => cameraManager.activeCamera;
	const getControls = () => controlsManager.controls;
	const sceneManager = new SceneManager(view, getActiveCamera, getControls, eventManager);
	return {
		view,
		eventManager,
		sceneManager,
		cameraManager,
		controlsManager,
		lightingManager: new LightingManager(sceneManager.scene, eventManager),
		viewHelperManager: new ViewHelperManager(renderer, getActiveCamera, getControls, () => cameraManager.getCameraState(), eventManager)
	};
}
function createViewport3d(container, options) {
	const viewport = new Viewport3d(container, buildViewport3dDeps(container), options);
	viewport.start();
	return viewport;
}
//#endregion
export { createSceneHoverHandlers as a, isOrbitHandleType as i, pickHandleAtPointer as n, useViewportNodeWiring as o, OrbitHandles as r, createViewport3d as t };
