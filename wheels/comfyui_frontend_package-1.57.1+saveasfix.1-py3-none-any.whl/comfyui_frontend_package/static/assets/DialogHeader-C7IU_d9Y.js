import "./rolldown-runtime-xtsTai4I.js";
import { G as defineComponent, Kt as normalizeClass, R as createElementBlock, Wt as unref, ct as openBlock, dt as renderSlot } from "./vendor-vue-core-CuN1excl.js";
import { t as cn } from "./src-BHQtMnZc.js";
//#endregion
//#region src/components/ui/dialog/DialogHeader.vue
var DialogHeader_default = /* @__PURE__ */ defineComponent({
	__name: "DialogHeader",
	props: { class: {
		type: [
			Boolean,
			null,
			String,
			Object,
			Array
		],
		default: ""
	} },
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", { class: normalizeClass(unref(cn)("flex shrink-0 items-center justify-between gap-2 px-4 pt-4 pb-2", __props.class)) }, [renderSlot(_ctx.$slots, "default")], 2);
		};
	}
});
//#endregion
export { DialogHeader_default as t };
