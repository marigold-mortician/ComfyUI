import { t as LayoutDefault_default } from "./LayoutDefault-BcUVNTNk.js";
export { LayoutDefault_default as default };
