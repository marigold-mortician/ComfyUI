import "./rolldown-runtime-xtsTai4I.js";
import { n as useDialogService } from "./dialogService-CqZr0BhP.js";
import { F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, I as createBlock, Kt as normalizeClass, L as createCommentVNode, R as createElementBlock, U as createVNode, Wt as unref, Yt as toDisplayString, ct as openBlock, ft as resolveComponent, l as useRouter, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as useToast } from "./toastStore-Dg65fRgL.js";
import { n as useCloudWebSessionStore, r as webSessionFailureMessage } from "./cloudWebSessionStore-DQXLFlJm.js";
import { t as useAuthActions } from "./useAuthActions-_rhVfmiU.js";
import { t as useCurrentUser } from "./useCurrentUser-DjJaVYwd.js";
import { t as useAuthDialogs } from "./useAuthDialogs-C9YGTip0.js";
import { t as AppSpinner_default } from "./AppSpinner-BaiBF-4S.js";
import { t as UserAvatar_default } from "./UserAvatar-CInhbC8F.js";
//#endregion
//#region src/platform/auth/session/components/SignOutEverywhereButton.vue
var SignOutEverywhereButton_default = /* @__PURE__ */ defineComponent({
	__name: "SignOutEverywhereButton",
	setup(__props) {
		const { t } = useI18n();
		const { logout } = useAuthActions();
		const webSession = useCloudWebSessionStore();
		const toast = useToast();
		const signingOut = ref(false);
		async function revokeAllSessions() {
			const result = await webSession.revokeAllSessions();
			if (result.status === "error") {
				toast.error(t("auth.signOutEverywhere.failed"), {
					description: webSessionFailureMessage(result.code),
					duration: 8e3
				});
				return false;
			}
			toast.success(t("auth.signOutEverywhere.success"), {
				description: t("auth.signOutEverywhere.successDetail"),
				duration: 5e3
			});
			return true;
		}
		async function signOutEverywhere() {
			signingOut.value = true;
			try {
				await logout({ beforeSignOut: revokeAllSessions });
			} finally {
				signingOut.value = false;
			}
		}
		return (_ctx, _cache) => {
			return unref(webSession).signedInUser ? (openBlock(), createBlock(Button_default, {
				key: 0,
				variant: "destructive-textonly",
				loading: signingOut.value,
				onClick: signOutEverywhere
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("auth.signOutEverywhere.action")), 1)]),
				_: 1
			}, 8, ["loading"])) : createCommentVNode("", true);
		};
	}
});
//#endregion
//#region src/components/dialog/content/setting/UserPanel.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "user-settings-container h-full" };
var _hoisted_2 = { class: "flex h-full flex-col" };
var _hoisted_3 = { class: "mb-2 text-2xl font-bold" };
var _hoisted_4 = {
	key: 0,
	class: "flex flex-col gap-2"
};
var _hoisted_5 = { class: "flex flex-col gap-0.5" };
var _hoisted_6 = { class: "font-medium" };
var _hoisted_7 = { class: "text-muted-foreground" };
var _hoisted_8 = { class: "flex flex-col gap-0.5" };
var _hoisted_9 = { class: "font-medium" };
var _hoisted_10 = { class: "text-muted-foreground" };
var _hoisted_11 = { class: "flex flex-col gap-0.5" };
var _hoisted_12 = { class: "font-medium" };
var _hoisted_13 = { class: "flex items-center gap-1 text-muted-foreground" };
var _hoisted_14 = {
	key: 2,
	class: "mt-4 flex flex-col gap-2"
};
var _hoisted_15 = { class: "flex flex-wrap items-center gap-2" };
var _hoisted_16 = {
	key: 1,
	class: "flex flex-col gap-4"
};
var _hoisted_17 = { class: "text-muted-foreground" };
//#endregion
//#region src/components/dialog/content/setting/UserPanel.vue
var UserPanel_default = /* @__PURE__ */ defineComponent({
	__name: "UserPanel",
	setup(__props) {
		const { t } = useI18n();
		const router = useRouter();
		const dialogService = useDialogService();
		const { showUpdatePasswordDialog } = useAuthDialogs();
		const { loading, isLoggedIn, isApiKeyLogin, isEmailProvider, needsFirebaseSignIn, userDisplayName, userEmail, userPhotoUrl, providerName, providerIcon, handleSignOut, handleSignIn } = useCurrentUser();
		async function onUpdatePassword() {
			if (!needsFirebaseSignIn.value) {
				await showUpdatePasswordDialog();
				return;
			}
			if (!await dialogService.confirm({
				title: t("auth.reauthRequired.title"),
				message: t("auth.reauthRequired.message")
			})) return;
			const { href } = router.resolve({
				name: "cloud-login",
				query: {
					switchAccount: "true",
					previousFullPath: encodeURIComponent(router.currentRoute.value.fullPath)
				}
			});
			window.location.assign(href);
		}
		return (_ctx, _cache) => {
			const _component_i18n_t = resolveComponent("i18n-t");
			return openBlock(), createElementBlock("div", _hoisted_1, [createBaseVNode("div", _hoisted_2, [
				createBaseVNode("h2", _hoisted_3, toDisplayString(_ctx.$t("userSettings.title")), 1),
				_cache[4] || (_cache[4] = createBaseVNode("div", { class: "mt-4 mb-3 border-t" }, null, -1)),
				unref(isLoggedIn) ? (openBlock(), createElementBlock("div", _hoisted_4, [
					unref(userPhotoUrl) ? (openBlock(), createBlock(UserAvatar_default, {
						key: 0,
						"photo-url": unref(userPhotoUrl),
						size: "large"
					}, null, 8, ["photo-url"])) : createCommentVNode("", true),
					createBaseVNode("div", _hoisted_5, [createBaseVNode("h3", _hoisted_6, toDisplayString(_ctx.$t("userSettings.name")), 1), createBaseVNode("div", _hoisted_7, toDisplayString(unref(userDisplayName) || _ctx.$t("userSettings.notSet")), 1)]),
					createBaseVNode("div", _hoisted_8, [createBaseVNode("h3", _hoisted_9, toDisplayString(_ctx.$t("userSettings.email")), 1), createBaseVNode("span", _hoisted_10, toDisplayString(unref(userEmail)), 1)]),
					createBaseVNode("div", _hoisted_11, [createBaseVNode("h3", _hoisted_12, toDisplayString(_ctx.$t("userSettings.provider")), 1), createBaseVNode("div", _hoisted_13, [
						createBaseVNode("i", { class: normalizeClass(unref(providerIcon)) }, null, 2),
						createTextVNode(" " + toDisplayString(unref(providerName)) + " ", 1),
						unref(isEmailProvider) ? (openBlock(), createBlock(Button_default, {
							key: 0,
							tooltip: _ctx.$t("userSettings.updatePassword"),
							variant: "muted-textonly",
							size: "icon-sm",
							"aria-label": _ctx.$t("userSettings.updatePassword"),
							onClick: onUpdatePassword
						}, {
							default: withCtx(() => [..._cache[0] || (_cache[0] = [createBaseVNode("i", { class: "pi pi-pen-to-square" }, null, -1)])]),
							_: 1
						}, 8, ["tooltip", "aria-label"])) : createCommentVNode("", true)
					])]),
					unref(loading) ? (openBlock(), createBlock(AppSpinner_default, {
						key: 1,
						class: "mt-4 size-8"
					})) : (openBlock(), createElementBlock("div", _hoisted_14, [createBaseVNode("div", _hoisted_15, [createVNode(Button_default, {
						class: "w-32",
						variant: "secondary",
						onClick: unref(handleSignOut)
					}, {
						default: withCtx(() => [_cache[1] || (_cache[1] = createBaseVNode("i", { class: "pi pi-sign-out" }, null, -1)), createTextVNode(" " + toDisplayString(_ctx.$t("auth.signOut.signOut")), 1)]),
						_: 1
					}, 8, ["onClick"]), createVNode(SignOutEverywhereButton_default)]), !unref(isApiKeyLogin) ? (openBlock(), createBlock(_component_i18n_t, {
						key: 0,
						keypath: "auth.deleteAccount.contactSupport",
						tag: "p",
						class: "text-sm text-muted-foreground"
					}, {
						email: withCtx(() => [..._cache[2] || (_cache[2] = [createBaseVNode("a", {
							href: "mailto:support@comfy.org",
							class: "underline"
						}, "support@comfy.org", -1)])]),
						_: 1
					})) : createCommentVNode("", true)]))
				])) : (openBlock(), createElementBlock("div", _hoisted_16, [createBaseVNode("p", _hoisted_17, toDisplayString(_ctx.$t("auth.login.title")), 1), createVNode(Button_default, {
					class: "w-52",
					variant: "primary",
					loading: unref(loading),
					onClick: unref(handleSignIn)
				}, {
					default: withCtx(() => [_cache[3] || (_cache[3] = createBaseVNode("i", { class: "pi pi-user" }, null, -1)), createTextVNode(" " + toDisplayString(_ctx.$t("auth.login.signInOrSignUp")), 1)]),
					_: 1
				}, 8, ["loading", "onClick"])]))
			])]);
		};
	}
});
//#endregion
export { UserPanel_default as default };
