import "./rolldown-runtime-xtsTai4I.js";
import { tt as nextTick } from "./vendor-vue-core-CuN1excl.js";
//#region src/extensions/core/load3d/cameraInfo.ts
var cameraInfoExtension = {
	name: "Comfy.CreateCameraInfo",
	async nodeCreated(node) {
		if (node.constructor.comfyClass !== "CreateCameraInfo") return;
		const [oldWidth, oldHeight] = node.size;
		node.setSize([Math.max(oldWidth, 360), Math.max(oldHeight, 480)]);
		await nextTick();
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.cameraInfo = window.comfyAPI.cameraInfo || {};
window.comfyAPI.cameraInfo.cameraInfoExtension = cameraInfoExtension;
//#endregion
export { cameraInfoExtension };
