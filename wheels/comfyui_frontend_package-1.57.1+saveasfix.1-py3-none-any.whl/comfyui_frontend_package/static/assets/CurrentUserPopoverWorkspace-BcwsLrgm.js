import "./rolldown-runtime-xtsTai4I.js";
import { t as useBillingContext, y as paymentIntentSourceForAddCreditsClick } from "./useBillingContext-Cc-YANxo.js";
import { x as useSettingsDialog } from "./dialogService-CqZr0BhP.js";
import { t as useTeamWorkspaceStore } from "./teamWorkspaceStore-BNm5cZOK.js";
import { F as createBaseVNode, G as defineComponent, H as createTextVNode, I as createBlock, L as createCommentVNode, P as computed, R as createElementBlock, U as createVNode, Wt as unref, Yt as toDisplayString, at as onMounted, ct as openBlock, p as storeToRefs, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { n as useTelemetry } from "./telemetry-IkzvF0TI.js";
import { a as isDesktopHostSignedIn, t as canDesktopHostSwitchWorkspace } from "./desktopHostSession-B3KqJnXo.js";
import { i as formatCreditsFromCents } from "./creditsUtil-DxLnYjvD.js";
import { t as useCurrentUser } from "./useCurrentUser-DjJaVYwd.js";
import { t as useBillingCapabilities } from "./useBillingCapabilities-x1h7nBmq.js";
import { t as useBillingDialogs } from "./useBillingDialogs-Bc5B2YTn.js";
import { t as BILLING_ACTION_NAME } from "./billingActionNames-DwcV6mOp.js";
import { t as useWorkspaceUI } from "./useWorkspaceUI-CALMkHxF.js";
import { t as useExternalLink } from "./useExternalLink-Cd0Jpjd8.js";
import { n as useWorkspaceDialogs, t as useSubscriptionDialog } from "./useSubscriptionDialog-C4Ac2Pav.js";
import { t as Skeleton_default } from "./Skeleton-COEG5vV3.js";
import { t as UserAvatar_default } from "./UserAvatar-CInhbC8F.js";
import { t as Popover_default } from "./Popover-Bo3qn5Dm.js";
import { t as SubscribeButton_default } from "./SubscribeButton-CWLJcr6J.js";
import { t as WorkspaceProfilePic_default } from "./WorkspaceProfilePic-BHe-oqM-.js";
import { t as WorkspaceSwitcherPopover_default } from "./WorkspaceSwitcherPopover-CF0BRp4C.js";
//#region src/platform/workspace/components/CurrentUserPopoverWorkspace.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = {
	"data-testid": "current-user-popover",
	class: "current-user-popover p-2"
};
var _hoisted_2 = { class: "mb-4 flex flex-col items-center px-0 py-3" };
var _hoisted_3 = { class: "my-0 mb-1 truncate text-base font-bold text-foreground" };
var _hoisted_4 = {
	key: 0,
	class: "my-0 truncate text-sm text-muted-foreground"
};
var _hoisted_5 = {
	key: 0,
	class: "relative"
};
var _hoisted_6 = {
	key: 0,
	class: "flex w-full items-center gap-2 rounded-lg px-4 py-2",
	"data-testid": "workspace-context-row"
};
var _hoisted_7 = { class: "truncate text-sm text-foreground" };
var _hoisted_8 = { class: "flex w-0 flex-1 items-center gap-2" };
var _hoisted_9 = { class: "truncate text-sm text-foreground" };
var _hoisted_10 = {
	key: 1,
	class: "flex items-center gap-2 px-4 py-2"
};
var _hoisted_11 = {
	key: 1,
	class: "text-base font-semibold text-foreground"
};
var _hoisted_12 = {
	key: 2,
	class: "mx-0 my-2 border-t"
};
var _hoisted_13 = { class: "flex-1 text-foreground" };
var _hoisted_14 = ["data-dd-action-name"];
var _hoisted_15 = { class: "flex-1 text-sm text-foreground" };
var _hoisted_16 = { class: "flex-1 text-sm text-foreground" };
var _hoisted_17 = { class: "flex-1 text-foreground" };
var _hoisted_18 = {
	key: 7,
	class: "mx-0 my-2 border-t"
};
var _hoisted_19 = { class: "flex-1 text-foreground" };
var _hoisted_20 = { class: "flex-1 text-foreground" };
var _hoisted_21 = { class: "flex-1 text-foreground" };
//#endregion
//#region src/platform/workspace/components/CurrentUserPopoverWorkspace.vue
var CurrentUserPopoverWorkspace_default = /* @__PURE__ */ defineComponent({
	__name: "CurrentUserPopoverWorkspace",
	props: { accountActionsOnly: {
		type: Boolean,
		default: false
	} },
	emits: ["close"],
	setup(__props, { emit: __emit }) {
		const workspaceStore = useTeamWorkspaceStore();
		const { initState, workspaceName, isInPersonalWorkspace: isPersonalWorkspace, activeWorkspace } = storeToRefs(workspaceStore);
		const { permissions, canReactivatePlan, canOpenPricingSurface } = useWorkspaceUI();
		const { canTopUp, canSubscribeSelfServe, paymentRecoveryAvailable } = useBillingCapabilities();
		const emit = __emit;
		const { buildDocsUrl, docsPaths } = useExternalLink();
		const { userDisplayName, userEmail, userPhotoUrl, handleSignOut, isApiKeyLogin } = useCurrentUser();
		const isDesktopHostWorkspaceFixed = computed(() => isDesktopHostSignedIn() && !canDesktopHostSwitchWorkspace());
		const settingsDialog = useSettingsDialog();
		const { showTopUpCreditsDialog } = useBillingDialogs();
		const { showCreateWorkspaceDialog } = useWorkspaceDialogs();
		const { billingStatus, canAccessSubscriptionFeatures, subscription, balance, isLoading, fetchBalance } = useBillingContext();
		const isCancelled = computed(() => subscription.value?.isCancelled ?? false);
		const subscriptionDialog = useSubscriptionDialog();
		const { locale } = useI18n();
		const isLoadingBalance = isLoading;
		const displayedCredits = computed(() => {
			if (initState.value !== "ready") return "";
			const cents = balance.value?.effectiveBalanceMicros ?? balance.value?.amountMicros ?? 0;
			return formatCreditsFromCents({
				cents,
				locale: locale.value,
				numberOptions: {
					minimumFractionDigits: 0,
					maximumFractionDigits: 2
				}
			});
		});
		const showPlansAndPricing = canOpenPricingSurface;
		const showLocalPlansAndCredits = computed(() => permissions.value.canManageSubscription);
		const hasDelinquentSubscription = computed(() => (billingStatus.value === "payment_failed" || billingStatus.value === "paused") && Boolean(subscription.value?.planSlug));
		const showManagePlan = computed(() => permissions.value.canManageSubscription && (canAccessSubscriptionFeatures.value || hasDelinquentSubscription.value));
		const showSubscribeAction = computed(() => false);
		const handleOpenUserSettings = () => {
			settingsDialog.show("user");
			emit("close");
		};
		const handleOpenWorkspaceSettings = () => {
			settingsDialog.show("workspace");
			emit("close");
		};
		/**
		* Plan selection stays in the app: billing-web's `/v1/pricing` has no
		* personal/team tabs, cycle toggle, or credit slider (G7), and a per-credit
		* Team plan 400s there (FE-2642). Only checkout hands off to billing-web,
		* from inside the table (`useSubscriptionCheckout`'s `handleSubscribeClick`
		* / `handleSubscribeTeamClick`).
		*/
		const handleOpenPlansAndPricing = () => {
			subscriptionDialog.showPricingTable({ reason: "avatar_menu_plans" });
			emit("close");
		};
		const handleOpenSubscriptionAction = () => {
			subscriptionDialog.showPricingTable({ reason: "avatar_menu_plans" });
			emit("close");
		};
		const handleOpenManagePlanSettings = () => {
			settingsDialog.show("workspace");
			emit("close");
		};
		const handleOpenPlanCreditsSettings = () => {
			settingsDialog.show("workspace");
			emit("close");
		};
		const handleTopUp = () => {
			useTelemetry()?.trackAddApiCreditButtonClicked({ source: "avatar_menu" });
			showTopUpCreditsDialog({ source: paymentIntentSourceForAddCreditsClick("avatar_menu") });
			emit("close");
		};
		const handleOpenPartnerNodesInfo = () => {
			window.open(buildDocsUrl(docsPaths.partnerNodesPricing, { includeLocale: true }), "_blank");
			emit("close");
		};
		const handleLogout = async () => {
			await handleSignOut();
			emit("close");
		};
		const handleCreateWorkspace = () => {
			showCreateWorkspaceDialog();
			emit("close");
		};
		onMounted(() => {
			if (!__props.accountActionsOnly) fetchBalance();
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1, [
				createBaseVNode("div", _hoisted_2, [
					createVNode(UserAvatar_default, {
						class: "mb-1",
						"photo-url": unref(userPhotoUrl),
						"icon-class": "size-6",
						size: "large"
					}, null, 8, ["photo-url"]),
					createBaseVNode("h3", _hoisted_3, toDisplayString(unref(userDisplayName) || _ctx.$t("g.user")), 1),
					unref(userEmail) ? (openBlock(), createElementBlock("p", _hoisted_4, toDisplayString(unref(userEmail)), 1)) : createCommentVNode("", true)
				]),
				!__props.accountActionsOnly ? (openBlock(), createElementBlock("div", _hoisted_5, [unref(isApiKeyLogin) || isDesktopHostWorkspaceFixed.value ? (openBlock(), createElementBlock("div", _hoisted_6, [createVNode(WorkspaceProfilePic_default, {
					class: "size-6 shrink-0 text-xs",
					"workspace-name": unref(workspaceName)
				}, null, 8, ["workspace-name"]), createBaseVNode("span", _hoisted_7, toDisplayString(unref(workspaceName)), 1)])) : (openBlock(), createBlock(Popover_default, {
					key: 1,
					side: "left",
					align: "start",
					"side-offset": 16,
					"collision-padding": 8,
					"prioritize-position": "",
					"data-testid": "workspace-switcher-panel"
				}, {
					button: withCtx(() => [createVNode(Button_default, {
						variant: "muted-textonly",
						class: "flex h-auto w-full justify-between px-4 py-2",
						tooltip: unref(workspaceName) ?? "",
						"data-testid": "workspace-switcher-trigger"
					}, {
						default: withCtx(() => [createBaseVNode("div", _hoisted_8, [createVNode(WorkspaceProfilePic_default, {
							class: "size-6 shrink-0 text-xs",
							"workspace-name": unref(workspaceName),
							"subscription-tier": unref(activeWorkspace)?.subscriptionTier
						}, null, 8, ["workspace-name", "subscription-tier"]), createBaseVNode("span", _hoisted_9, toDisplayString(unref(workspaceName)), 1)]), _cache[0] || (_cache[0] = createBaseVNode("i", { class: "pi pi-chevron-down shrink-0 text-sm text-muted-foreground" }, null, -1))]),
						_: 1
					}, 8, ["tooltip"])]),
					default: withCtx(({ close }) => [createVNode(WorkspaceSwitcherPopover_default, {
						onSelect: close,
						onCreate: ($event) => (close(), handleCreateWorkspace())
					}, null, 8, ["onSelect", "onCreate"])]),
					_: 1
				}))])) : createCommentVNode("", true),
				!__props.accountActionsOnly ? (openBlock(), createElementBlock("div", _hoisted_10, [
					_cache[2] || (_cache[2] = createBaseVNode("i", { class: "icon-[lucide--coins] text-sm text-credit" }, null, -1)),
					unref(isLoadingBalance) ? (openBlock(), createBlock(Skeleton_default, {
						key: 0,
						class: "h-5 w-16"
					})) : (openBlock(), createElementBlock("span", _hoisted_11, toDisplayString(displayedCredits.value), 1)),
					createVNode(Button_default, {
						tooltip: _ctx.$t("credits.unified.tooltip"),
						variant: "muted-textonly",
						size: "icon-sm",
						class: "mr-auto",
						"aria-label": _ctx.$t("credits.unified.tooltip"),
						"data-testid": "credits-info-button"
					}, {
						default: withCtx(() => [..._cache[1] || (_cache[1] = [createBaseVNode("i", { class: "icon-[lucide--circle-help]" }, null, -1)])]),
						_: 1
					}, 8, ["tooltip", "aria-label"]),
					unref(canTopUp) ? (openBlock(), createBlock(Button_default, {
						key: 2,
						variant: "secondary",
						size: "sm",
						"data-testid": "add-credits-button",
						"data-dd-action-name": unref(BILLING_ACTION_NAME).addCreditsPopover,
						onClick: handleTopUp
					}, {
						default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("subscription.addCredits")), 1)]),
						_: 1
					}, 8, ["data-dd-action-name"])) : unref(paymentRecoveryAvailable) ? (openBlock(), createBlock(Button_default, {
						key: 3,
						variant: "secondary",
						size: "sm",
						"data-testid": "add-credits-button",
						"data-dd-action-name": unref(BILLING_ACTION_NAME).addCreditsPopover,
						onClick: handleTopUp
					}, {
						default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("subscription.addCredits")), 1)]),
						_: 1
					}, 8, ["data-dd-action-name"])) : createCommentVNode("", true),
					showSubscribeAction.value && unref(isPersonalWorkspace) ? (openBlock(), createBlock(SubscribeButton_default, {
						key: 4,
						fluid: false,
						label: isCancelled.value ? _ctx.$t("subscription.resubscribe") : _ctx.$t("workspaceSwitcher.subscribe"),
						size: "sm",
						"button-variant": "subscribe"
					}, null, 8, ["label"])) : createCommentVNode("", true),
					showSubscribeAction.value && !unref(isPersonalWorkspace) ? (openBlock(), createBlock(Button_default, {
						key: 5,
						variant: "primary",
						size: "sm",
						onClick: handleOpenSubscriptionAction
					}, {
						default: withCtx(() => [createTextVNode(toDisplayString(isCancelled.value ? _ctx.$t("subscription.resubscribe") : _ctx.$t("workspaceSwitcher.subscribe")), 1)]),
						_: 1
					})) : createCommentVNode("", true)
				])) : createCommentVNode("", true),
				!__props.accountActionsOnly ? (openBlock(), createElementBlock("div", _hoisted_12)) : createCommentVNode("", true),
				!__props.accountActionsOnly && unref(false) && unref(showPlansAndPricing) ? (openBlock(), createElementBlock("div", {
					key: 3,
					class: "flex cursor-pointer items-center gap-2 px-4 py-2 text-sm hover:bg-accent",
					"data-testid": "plans-pricing-menu-item",
					onClick: handleOpenPlansAndPricing
				}, [_cache[3] || (_cache[3] = createBaseVNode("i", { class: "icon-[lucide--receipt-text] text-muted-foreground" }, null, -1)), createBaseVNode("span", _hoisted_13, toDisplayString(_ctx.$t("subscription.plansAndPricing")), 1)])) : createCommentVNode("", true),
				!__props.accountActionsOnly && unref(false) && showManagePlan.value ? (openBlock(), createElementBlock("button", {
					key: 4,
					type: "button",
					class: "flex w-full cursor-pointer appearance-none items-center gap-2 border-0 bg-transparent px-4 py-2 text-left hover:bg-accent focus-visible:bg-accent focus-visible:outline-none",
					"data-testid": "manage-plan-menu-item",
					"data-dd-action-name": unref(BILLING_ACTION_NAME).managePlanPopover,
					onClick: handleOpenManagePlanSettings
				}, [_cache[4] || (_cache[4] = createBaseVNode("i", { class: "icon-[lucide--credit-card] size-4 text-muted-foreground" }, null, -1)), createBaseVNode("span", _hoisted_15, toDisplayString(_ctx.$t("subscription.managePlan")), 1)], 8, _hoisted_14)) : createCommentVNode("", true),
				!__props.accountActionsOnly && showLocalPlansAndCredits.value ? (openBlock(), createElementBlock("button", {
					key: 5,
					type: "button",
					class: "flex w-full cursor-pointer appearance-none items-center gap-2 border-0 bg-transparent px-4 py-2 text-left hover:bg-accent focus-visible:bg-accent focus-visible:outline-none",
					"data-testid": "plans-credits-menu-item",
					onClick: handleOpenPlanCreditsSettings
				}, [_cache[5] || (_cache[5] = createBaseVNode("i", { class: "icon-[lucide--coins] size-4 text-muted-foreground" }, null, -1)), createBaseVNode("span", _hoisted_16, toDisplayString(_ctx.$t("subscription.plansAndCredits")), 1)])) : createCommentVNode("", true),
				!__props.accountActionsOnly ? (openBlock(), createElementBlock("div", {
					key: 6,
					class: "flex cursor-pointer items-center gap-2 px-4 py-2 text-sm hover:bg-accent",
					"data-testid": "partner-nodes-menu-item",
					onClick: handleOpenPartnerNodesInfo
				}, [_cache[6] || (_cache[6] = createBaseVNode("i", { class: "icon-[lucide--tag] text-muted-foreground" }, null, -1)), createBaseVNode("span", _hoisted_17, toDisplayString(_ctx.$t("subscription.partnerNodesCredits")), 1)])) : createCommentVNode("", true),
				!__props.accountActionsOnly ? (openBlock(), createElementBlock("div", _hoisted_18)) : createCommentVNode("", true),
				!__props.accountActionsOnly ? (openBlock(), createElementBlock("div", {
					key: 8,
					class: "flex cursor-pointer items-center gap-2 px-4 py-2 text-sm hover:bg-accent",
					"data-testid": "workspace-settings-menu-item",
					onClick: handleOpenWorkspaceSettings
				}, [_cache[7] || (_cache[7] = createBaseVNode("i", { class: "icon-[lucide--users] text-muted-foreground" }, null, -1)), createBaseVNode("span", _hoisted_19, toDisplayString(_ctx.$t("userSettings.workspaceSettings")), 1)])) : createCommentVNode("", true),
				createBaseVNode("div", {
					class: "flex cursor-pointer items-center gap-2 px-4 py-2 text-sm hover:bg-accent",
					"data-testid": "user-settings-menu-item",
					onClick: handleOpenUserSettings
				}, [_cache[8] || (_cache[8] = createBaseVNode("i", { class: "icon-[lucide--settings-2] text-muted-foreground" }, null, -1)), createBaseVNode("span", _hoisted_20, toDisplayString(_ctx.$t("userSettings.accountSettings")), 1)]),
				_cache[10] || (_cache[10] = createBaseVNode("div", { class: "mx-0 my-2 border-t" }, null, -1)),
				createBaseVNode("div", {
					class: "flex cursor-pointer items-center gap-2 px-4 py-2 text-sm hover:bg-accent",
					"data-testid": "logout-menu-item",
					onClick: handleLogout
				}, [_cache[9] || (_cache[9] = createBaseVNode("i", { class: "icon-[lucide--log-out] text-muted-foreground" }, null, -1)), createBaseVNode("span", _hoisted_21, toDisplayString(_ctx.$t("auth.signOut.signOut")), 1)])
			]);
		};
	}
});
//#endregion
export { CurrentUserPopoverWorkspace_default as default };
