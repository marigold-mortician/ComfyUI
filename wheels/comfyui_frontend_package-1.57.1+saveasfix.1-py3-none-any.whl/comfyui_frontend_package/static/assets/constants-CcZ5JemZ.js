import "./rolldown-runtime-xtsTai4I.js";
//#region packages/viewport3d/src/load3d/constants.ts
/**
* Load3D constants that don't require THREE.js
* This file can be imported without pulling in the entire THREE.js bundle
*/
var SUPPORTED_MESH_EXTENSIONS = /* @__PURE__ */ new Set([
	".gltf",
	".glb",
	".obj",
	".fbx",
	".stl"
]);
var SUPPORTED_EXTENSIONS = /* @__PURE__ */ new Set([
	...SUPPORTED_MESH_EXTENSIONS,
	".spz",
	".splat",
	".ply",
	".ksplat"
]);
var SUPPORTED_EXTENSIONS_ACCEPT = [...SUPPORTED_EXTENSIONS].join(",");
var SUPPORTED_HDRI_EXTENSIONS = /* @__PURE__ */ new Set([".hdr", ".exr"]);
var SUPPORTED_HDRI_EXTENSIONS_ACCEPT = [...SUPPORTED_HDRI_EXTENSIONS].join(",");
var LOAD3D_NONE_MODEL = "none";
var DIRECT_EXPORT_FORMATS = /* @__PURE__ */ new Set([
	"ply",
	"spz",
	"splat",
	"ksplat"
]);
var CONVERTIBLE_EXPORT_FORMAT_OPTIONS = [
	{
		label: "GLB",
		value: "glb"
	},
	{
		label: "OBJ",
		value: "obj"
	},
	{
		label: "STL",
		value: "stl"
	},
	{
		label: "FBX",
		value: "fbx"
	}
];
function getExportFormatOptions(sourceFormat) {
	const format = sourceFormat?.toLowerCase();
	if (format && DIRECT_EXPORT_FORMATS.has(format)) return [{
		label: format.toUpperCase(),
		value: format
	}];
	return CONVERTIBLE_EXPORT_FORMAT_OPTIONS;
}
//#endregion
export { SUPPORTED_HDRI_EXTENSIONS as a, getExportFormatOptions as c, SUPPORTED_EXTENSIONS_ACCEPT as i, LOAD3D_NONE_MODEL as n, SUPPORTED_HDRI_EXTENSIONS_ACCEPT as o, SUPPORTED_EXTENSIONS as r, SUPPORTED_MESH_EXTENSIONS as s, DIRECT_EXPORT_FORMATS as t };
