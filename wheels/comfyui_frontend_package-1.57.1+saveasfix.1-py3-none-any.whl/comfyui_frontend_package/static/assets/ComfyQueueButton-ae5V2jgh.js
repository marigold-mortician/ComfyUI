import "./rolldown-runtime-xtsTai4I.js";
import { t as useCommandStore } from "./commandStore-XD_i1hej.js";
import { t as useExecutionErrorStore } from "./executionErrorStore-DzGUJU_L.js";
import { n as useSettingStore } from "./settingStore-DRRi2kOn.js";
import { C as vModelText, E as withModifiers, F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, I as createBlock, Kt as normalizeClass, P as computed, T as withKeys, Tt as withDirectives, U as createVNode, Wt as unref, Yt as toDisplayString, bt as watch, ct as openBlock, p as storeToRefs, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { a as TooltipTrigger_default, o as TooltipContent_default, s as Tooltip_default, t as Button_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { n as useTelemetry } from "./telemetry-IkzvF0TI.js";
import { n as isInstantRunningMode, r as useQueueSettingsStore, t as isInstantMode } from "./queueSettingsStore-BzKxsLQU.js";
import { n as TinyChevronIcon_default, t as ButtonGroup_default } from "./ButtonGroup-BMn5mKTZ.js";
import { a as MenuRadioGroup_default, t as Menu_default } from "./Menu-iX8QWfwR.js";
import { t as useWorkspaceStore } from "./workspaceStore-CA_rc-fs.js";
//#region src/components/actionbar/BatchCountEdit.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = ["aria-label"];
var _hoisted_2 = { class: "flex h-full w-14 overflow-hidden rounded-l-lg bg-secondary" };
var _hoisted_3 = ["aria-label", "onKeydown"];
var _hoisted_4 = { class: "flex h-full w-6 flex-col" };
var minQueueCount = 1;
var inputClass = "h-full min-w-0 flex-1 border-none bg-secondary pl-1 pr-0 text-center text-sm font-normal tabular-nums text-foreground outline-none";
var stepButtonClass = "h-1/2 w-full rounded-none border-none p-0 text-muted-foreground hover:bg-accent disabled:cursor-not-allowed disabled:opacity-50";
var incrementButtonClass = "rounded-tr-none border-b border-border/50";
var decrementButtonClass = "rounded-br-none";
//#endregion
//#region src/components/actionbar/BatchCountEdit.vue
var BatchCountEdit_default = /* @__PURE__ */ defineComponent({
	__name: "BatchCountEdit",
	setup(__props) {
		const { t } = useI18n();
		const queueSettingsStore = useQueueSettingsStore();
		const { batchCount } = storeToRefs(queueSettingsStore);
		const settingStore = useSettingStore();
		const maxQueueCount = computed(() => settingStore.get("Comfy.QueueButton.BatchCountLimit"));
		const batchCountInputRef = ref(null);
		const batchCountInput = ref(String(batchCount.value));
		const isEditing = ref(false);
		const isIncrementDisabled = computed(() => batchCount.value >= maxQueueCount.value);
		const isDecrementDisabled = computed(() => batchCount.value <= minQueueCount);
		watch(batchCount, (nextBatchCount) => {
			if (!isEditing.value) batchCountInput.value = String(nextBatchCount);
		});
		const clampBatchCount = (nextBatchCount) => Math.min(Math.max(nextBatchCount, minQueueCount), maxQueueCount.value);
		const setBatchCount = (nextBatchCount) => {
			batchCount.value = clampBatchCount(nextBatchCount);
			batchCountInput.value = String(batchCount.value);
		};
		const incrementBatchCount = () => {
			setBatchCount(batchCount.value * 2);
		};
		const decrementBatchCount = () => {
			setBatchCount(Math.floor(batchCount.value / 2));
		};
		const onInputFocus = () => {
			isEditing.value = true;
		};
		const onInput = (event) => {
			const input = event.target;
			batchCountInput.value = input.value.replace(/[^0-9]/g, "");
		};
		const onInputBlur = () => {
			isEditing.value = false;
			const parsedInput = Number.parseInt(batchCountInput.value, 10);
			setBatchCount(Number.isNaN(parsedInput) ? minQueueCount : parsedInput);
		};
		const onInputEnter = () => {
			batchCountInputRef.value?.blur();
		};
		return (_ctx, _cache) => {
			return openBlock(), createBlock(Tooltip_default, null, {
				default: withCtx(() => [createVNode(TooltipTrigger_default, { "as-child": "" }, {
					default: withCtx(() => [createBaseVNode("div", {
						class: "batch-count h-full",
						"aria-label": unref(t)("menu.batchCount")
					}, [createBaseVNode("div", _hoisted_2, [withDirectives(createBaseVNode("input", {
						ref_key: "batchCountInputRef",
						ref: batchCountInputRef,
						"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => batchCountInput.value = $event),
						type: "text",
						inputmode: "numeric",
						"aria-label": unref(t)("menu.batchCount"),
						class: normalizeClass(inputClass),
						onFocus: onInputFocus,
						onInput,
						onBlur: onInputBlur,
						onKeydown: withKeys(withModifiers(onInputEnter, ["prevent"]), ["enter"])
					}, null, 40, _hoisted_3), [[vModelText, batchCountInput.value]]), createBaseVNode("div", _hoisted_4, [createVNode(Button_default, {
						variant: "secondary",
						size: "unset",
						"aria-label": unref(t)("g.increment"),
						class: normalizeClass(unref(cn)(stepButtonClass, incrementButtonClass)),
						disabled: isIncrementDisabled.value,
						onClick: incrementBatchCount
					}, {
						default: withCtx(() => [createVNode(TinyChevronIcon_default, { "rotate-up": "" })]),
						_: 1
					}, 8, [
						"aria-label",
						"class",
						"disabled"
					]), createVNode(Button_default, {
						variant: "secondary",
						size: "unset",
						"aria-label": unref(t)("g.decrement"),
						class: normalizeClass(unref(cn)(stepButtonClass, decrementButtonClass)),
						disabled: isDecrementDisabled.value,
						onClick: decrementBatchCount
					}, {
						default: withCtx(() => [createVNode(TinyChevronIcon_default)]),
						_: 1
					}, 8, [
						"aria-label",
						"class",
						"disabled"
					])])])], 8, _hoisted_1)]),
					_: 1
				}), createVNode(TooltipContent_default, { side: "bottom" }, {
					default: withCtx(() => [createTextVNode(toDisplayString(unref(t)("menu.batchCount")), 1)]),
					_: 1
				})]),
				_: 1
			});
		};
	}
});
//#endregion
//#region src/components/actionbar/ComfyRunButton/ComfyQueueButton.vue?vue&type=script&setup=true&lang.ts
var queueMenuTriggerClass = "h-full w-6 rounded-l-none rounded-r-lg border-0 border-l border-solid border-current/25 p-0";
//#endregion
//#region src/components/actionbar/ComfyRunButton/ComfyQueueButton.vue
var ComfyQueueButton_default = /* @__PURE__ */ defineComponent({
	__name: "ComfyQueueButton",
	props: { paymentRecoveryLock: { default: null } },
	emits: ["paymentRecoveryClick"],
	setup(__props, { emit: __emit }) {
		const workspaceStore = useWorkspaceStore();
		const { mode: queueMode, batchCount } = storeToRefs(useQueueSettingsStore());
		const { hasMissingError } = storeToRefs(useExecutionErrorStore());
		const { t } = useI18n();
		const emit = __emit;
		watch(() => __props.paymentRecoveryLock, (lock) => {
			if (lock) queueMode.value = "disabled";
		}, { immediate: true });
		const selectedQueueMode = computed(() => isInstantMode(queueMode.value) ? "instant-idle" : queueMode.value);
		const queueModeMenuItemLookup = computed(() => {
			const items = {
				disabled: {
					value: "disabled",
					label: t("menu.run"),
					tooltip: t("menu.disabledTooltip"),
					command: () => {
						queueMode.value = "disabled";
					}
				},
				change: {
					value: "change",
					label: `${t("menu.run")} (${t("menu.onChange")})`,
					tooltip: t("menu.onChangeTooltip"),
					command: () => {
						useTelemetry()?.trackUiButtonClicked({
							button_id: "queue_mode_option_run_on_change_selected",
							element_group: "queue"
						});
						queueMode.value = "change";
					}
				}
			};
			items["instant-idle"] = {
				value: "instant-idle",
				label: `${t("menu.run")} (${t("menu.instant")})`,
				tooltip: t("menu.instantTooltip"),
				command: () => {
					useTelemetry()?.trackUiButtonClicked({
						button_id: "queue_mode_option_run_instant_selected",
						element_group: "queue"
					});
					queueMode.value = "instant-idle";
				}
			};
			return items;
		});
		const activeQueueModeMenuItem = computed(() => {
			return queueModeMenuItemLookup.value[selectedQueueMode.value] || queueModeMenuItemLookup.value.disabled;
		});
		const queueModeMenuItems = computed(() => Object.values(queueModeMenuItemLookup.value));
		const isStopInstantAction = computed(() => isInstantRunningMode(queueMode.value));
		const queueButtonLabel = computed(() => __props.paymentRecoveryLock === "owner" ? t("subscription.paymentRecovery.ownerRunLabel") : __props.paymentRecoveryLock === "member" ? t("subscription.paymentRecovery.memberRunLabel") : isStopInstantAction.value ? t("menu.stopRunInstant") : String(activeQueueModeMenuItem.value?.label ?? ""));
		const queueButtonVariant = computed(() => __props.paymentRecoveryLock === "owner" ? "subscribe" : __props.paymentRecoveryLock === "member" ? "secondary" : isStopInstantAction.value ? "destructive" : "primary");
		const queueMenuTriggerVariant = computed(() => queueButtonVariant.value === "subscribe" ? "secondary" : queueButtonVariant.value);
		const queueMenuTriggerVariantClass = {
			destructive: "border-black/20 data-[state=open]:bg-destructive/90",
			primary: "data-[state=open]:bg-primary/90",
			secondary: "text-muted-foreground"
		};
		const iconClass = computed(() => {
			if (__props.paymentRecoveryLock) return "icon-[lucide--lock]";
			if (isStopInstantAction.value) return "icon-[lucide--square]";
			if (hasMissingError.value) return "icon-[lucide--triangle-alert]";
			if (workspaceStore.shiftDown) return "icon-[lucide--list-start]";
			if (queueMode.value === "disabled") return "icon-[lucide--play]";
			if (isInstantMode(queueMode.value)) return "icon-[lucide--fast-forward]";
			if (queueMode.value === "change") return "icon-[lucide--step-forward]";
			return "icon-[lucide--play]";
		});
		const queueButtonTooltip = computed(() => {
			if (__props.paymentRecoveryLock === "owner") return t("subscription.paymentRecovery.ownerRunTooltip");
			if (__props.paymentRecoveryLock === "member") return t("subscription.paymentRecovery.memberRunTooltip");
			if (isStopInstantAction.value) return t("menu.stopRunInstantTooltip");
			if (hasMissingError.value) return t("menu.runWorkflowMissingResources");
			if (workspaceStore.shiftDown) return t("menu.runWorkflowFront");
			return t("menu.runWorkflow");
		});
		const commandStore = useCommandStore();
		const queuePrompt = async (e) => {
			if (__props.paymentRecoveryLock) {
				emit("paymentRecoveryClick");
				return;
			}
			if (isStopInstantAction.value) {
				queueMode.value = "instant-idle";
				return;
			}
			const commandId = "shiftKey" in e && e.shiftKey ? "Comfy.QueuePromptFront" : "Comfy.QueuePrompt";
			if (isInstantMode(queueMode.value)) queueMode.value = "instant-running";
			if (batchCount.value > 1) useTelemetry()?.trackUiButtonClicked({
				button_id: "queue_run_multiple_batches_submitted",
				element_group: "queue"
			});
			await commandStore.execute(commandId, { metadata: {
				subscribe_to_run: false,
				trigger_source: "button"
			} });
		};
		return (_ctx, _cache) => {
			return openBlock(), createBlock(ButtonGroup_default, { class: "queue-button-group h-8 rounded-lg bg-secondary" }, {
				default: withCtx(() => [
					createVNode(BatchCountEdit_default),
					createVNode(Button_default, {
						tooltip: queueButtonTooltip.value,
						"tooltip-side": "bottom",
						variant: queueButtonVariant.value,
						size: "unset",
						class: normalizeClass(unref(cn)("h-full gap-1.5 rounded-l-lg rounded-r-none px-4", __props.paymentRecoveryLock ? "font-medium" : "font-light")),
						"data-testid": "queue-button",
						onClick: queuePrompt
					}, {
						default: withCtx(() => [createBaseVNode("i", {
							class: normalizeClass(unref(cn)(iconClass.value, "size-4")),
							"data-testid": "queue-button-icon"
						}, null, 2), createTextVNode(" " + toDisplayString(queueButtonLabel.value), 1)]),
						_: 1
					}, 8, [
						"tooltip",
						"variant",
						"class"
					]),
					createVNode(Menu_default, {
						side: "bottom",
						"side-offset": 4,
						class: "min-w-44"
					}, {
						trigger: withCtx(() => [createVNode(Button_default, {
							variant: queueMenuTriggerVariant.value,
							size: "unset",
							disabled: Boolean(__props.paymentRecoveryLock),
							class: normalizeClass(unref(cn)(queueMenuTriggerClass, queueMenuTriggerVariantClass[queueMenuTriggerVariant.value])),
							"aria-label": unref(t)("menu.runOptions"),
							"data-testid": "queue-mode-menu-trigger"
						}, {
							default: withCtx(() => [createVNode(TinyChevronIcon_default)]),
							_: 1
						}, 8, [
							"variant",
							"disabled",
							"class",
							"aria-label"
						])]),
						default: withCtx(() => [createVNode(MenuRadioGroup_default, {
							"model-value": selectedQueueMode.value,
							options: queueModeMenuItems.value,
							onSelect: _cache[0] || (_cache[0] = withModifiers(() => {}, ["prevent"]))
						}, null, 8, ["model-value", "options"])]),
						_: 1
					})
				]),
				_: 1
			});
		};
	}
});
//#endregion
export { ComfyQueueButton_default as t };
