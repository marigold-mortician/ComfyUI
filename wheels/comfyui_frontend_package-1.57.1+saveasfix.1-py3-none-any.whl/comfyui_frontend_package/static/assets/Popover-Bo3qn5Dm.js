import "./rolldown-runtime-xtsTai4I.js";
import { Ft as ref, G as defineComponent, Ht as toValue, I as createBlock, L as createCommentVNode, U as createVNode, Wt as unref, ct as openBlock, dt as renderSlot, et as mergeProps, wt as withCtx, yt as useTemplateRef } from "./vendor-vue-core-CuN1excl.js";
import { Dt as PopoverContent_default, Et as PopoverPortal_default, Gn as unrefElement, Tt as PopoverTrigger_default, ar as useEventListener, jt as PopoverRoot_default, kt as PopoverArrow_default } from "./vendor-reka-ui-NRTk7aIV.js";
import { t as cn } from "./src-BHQtMnZc.js";
//#region src/components/ui/popover/usePopoverViewportDismiss.ts
function usePopoverViewportDismiss(open, anchor) {
	useEventListener(() => open.value ? window : void 0, "resize", () => {
		open.value = false;
	});
	useEventListener(() => open.value ? window : void 0, "scroll", (event) => {
		if (event.target === document || event.target instanceof Window || event.target instanceof Element && event.target.contains(toValue(anchor) ?? null)) open.value = false;
	}, { capture: true });
}
//#endregion
//#region src/components/ui/Popover.vue
var Popover_default = /* @__PURE__ */ defineComponent({
	inheritAttrs: false,
	__name: "Popover",
	props: {
		to: {},
		showArrow: {
			type: Boolean,
			default: true
		}
	},
	setup(__props) {
		const open = ref(false);
		const trigger = useTemplateRef("trigger");
		usePopoverViewportDismiss(open, () => unrefElement(trigger));
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(PopoverRoot_default), {
				open: open.value,
				"onUpdate:open": _cache[0] || (_cache[0] = ($event) => open.value = $event)
			}, {
				default: withCtx(({ close }) => [createVNode(unref(PopoverTrigger_default), {
					ref_key: "trigger",
					ref: trigger,
					"as-child": ""
				}, {
					default: withCtx(() => [renderSlot(_ctx.$slots, "button")]),
					_: 3
				}, 512), (openBlock(), createBlock(unref(PopoverPortal_default), {
					key: Number(open.value),
					to: __props.to
				}, {
					default: withCtx(() => [createVNode(unref(PopoverContent_default), mergeProps({
						side: "bottom",
						"side-offset": 5,
						"collision-padding": 10
					}, _ctx.$attrs, { class: unref(cn)("z-overlay rounded-lg border border-border/50 bg-background p-2 shadow-sm will-change-[transform,opacity] data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 data-[state=open]:animate-in data-[state=open]:fade-in-0 data-[state=open]:zoom-in-95", _ctx.$attrs.class) }), {
						default: withCtx(() => [renderSlot(_ctx.$slots, "default", { close }), __props.showArrow ? (openBlock(), createBlock(unref(PopoverArrow_default), {
							key: 0,
							class: "fill-background stroke-border/50"
						})) : createCommentVNode("", true)]),
						_: 2
					}, 1040, ["class"])]),
					_: 2
				}, 1032, ["to"]))]),
				_: 3
			}, 8, ["open"]);
		};
	}
});
//#endregion
export { usePopoverViewportDismiss as n, Popover_default as t };
