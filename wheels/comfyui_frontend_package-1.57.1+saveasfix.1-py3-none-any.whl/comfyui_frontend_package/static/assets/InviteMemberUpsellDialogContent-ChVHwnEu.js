import "./rolldown-runtime-xtsTai4I.js";
import { t as useBillingContext } from "./useBillingContext-Cc-YANxo.js";
import { F as createBaseVNode, G as defineComponent, H as createTextVNode, I as createBlock, U as createVNode, Wt as unref, Yt as toDisplayString, ct as openBlock, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
import { n as useSubscriptionDialogAccess } from "./subscriptionDialogAccess-Igw8sX_b.js";
import { t as AppDialogPanel_default } from "./AppDialogPanel-BklaJBTn.js";
//#region src/platform/billing/components/dialogs/InviteMemberUpsellDialogContent.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "m-0 text-sm text-muted-foreground" };
//#endregion
//#region src/platform/billing/components/dialogs/InviteMemberUpsellDialogContent.vue
var InviteMemberUpsellDialogContent_default = /* @__PURE__ */ defineComponent({
	__name: "InviteMemberUpsellDialogContent",
	setup(__props) {
		const dialogStore = useDialogStore();
		const { canAccessSubscriptionFeatures } = useBillingContext();
		const subscriptionDialog = useSubscriptionDialogAccess();
		function onDismiss() {
			dialogStore.closeDialog({ key: "invite-member-upsell" });
		}
		function onUpgrade() {
			dialogStore.closeDialog({ key: "invite-member-upsell" });
			subscriptionDialog.show({
				planMode: "team",
				reason: "invite_member_upsell"
			});
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(AppDialogPanel_default, {
				"body-class": "flex flex-col gap-4",
				onClose: onDismiss
			}, {
				title: withCtx(() => [createTextVNode(toDisplayString(unref(canAccessSubscriptionFeatures) ? _ctx.$t("workspacePanel.inviteUpsellDialog.titleSingleSeat") : _ctx.$t("workspacePanel.inviteUpsellDialog.titleNotSubscribed")), 1)]),
				footer: withCtx(() => [createVNode(Button_default, {
					variant: "muted-textonly",
					onClick: onDismiss
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("g.cancel")), 1)]),
					_: 1
				}), createVNode(Button_default, {
					variant: "primary",
					size: "lg",
					onClick: onUpgrade
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.inviteUpsellDialog.upgradeToTeam")), 1)]),
					_: 1
				})]),
				default: withCtx(() => [createBaseVNode("p", _hoisted_1, toDisplayString(unref(canAccessSubscriptionFeatures) ? _ctx.$t("workspacePanel.inviteUpsellDialog.messageSingleSeat") : _ctx.$t("workspacePanel.inviteUpsellDialog.messageNotSubscribed")), 1)]),
				_: 1
			});
		};
	}
});
//#endregion
export { InviteMemberUpsellDialogContent_default as default };
