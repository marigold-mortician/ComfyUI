import "./rolldown-runtime-xtsTai4I.js";
import { n as useSettingStore } from "./settingStore-DRRi2kOn.js";
import { t as useTeamWorkspaceStore } from "./teamWorkspaceStore-BNm5cZOK.js";
import { Ft as ref, Ot as effectScope, P as computed, bt as watch, p as storeToRefs } from "./vendor-vue-core-CuN1excl.js";
import { Xr as whenever } from "./vendor-reka-ui-NRTk7aIV.js";
import { n as useWorkflowStore } from "./workflowStore-ChkUx7Si.js";
import { n as useTelemetry } from "./telemetry-IkzvF0TI.js";
import { r as reportError } from "./reportError-BHgDVvfb.js";
import { _ as getNodeByLocatorId } from "./graphTraversalUtil-BUK1cr2m.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
import { n as useCanvasStore } from "./canvasStore-siYzI5aT.js";
import { t as useAgentPanelStore } from "./agentPanelStore-CFwk6coW.js";
import { t as useCurrentUser } from "./useCurrentUser-DjJaVYwd.js";
import { J as useExtensionService } from "./app-C-5f0uvA.js";
import { t as useOnboardingTourStore } from "./onboardingTourStore-DL-TBMHb.js";
import { a as useAgentConsentStore, i as useAgentConsentIntroductionStore, n as CONSENT_DIALOG_KEY, r as useAgentConsent, t as useWorkflowTabActivityStore } from "./workflowTabActivityStore-BwZie-5b.js";
import { t as useFirstRunEntry } from "./firstRunEntry-DwYnxZ_v.js";
import { h as notifyRestoreMintersGraphLoadError, m as notifyRestoreMintersBeforeGraphLoad, p as notifyRestoreMintersAfterGraphConfigure, t as useAgentComposerStore, u as selectedNodeKey } from "./agentComposerStore-DTtkkFtu.js";
//#region src/workbench/extensions/agent/services/agent/workflowTabActivityTracker.ts
/**
* Keeps workflowTabActivityStore consistent with the tab strip while the
* agent panel is unmounted: activating a tab clears its unseen dot and
* closing tabs prunes stale state. Registered once from the extension
* setup, so the watchers outlive panel close and app-mode switches.
*/
function registerWorkflowTabActivityTracker(enabled) {
	const scope = effectScope(true);
	let trackerScope;
	scope.run(() => {
		const workflowStore = useWorkflowStore();
		const tabActivity = useWorkflowTabActivityStore();
		watch(enabled, (isEnabled) => {
			trackerScope?.stop();
			trackerScope = void 0;
			if (!isEnabled) {
				tabActivity.clearAgentActivity();
				return;
			}
			trackerScope = effectScope();
			trackerScope.run(() => {
				watch(() => workflowStore.activeWorkflow?.path, (path) => {
					if (path !== void 0) tabActivity.markSeen(path);
				});
				watch(() => workflowStore.openWorkflows.map((tab) => tab.path), (paths) => tabActivity.pruneClosed(paths));
			});
		}, { immediate: true });
	});
	return () => {
		trackerScope?.stop();
		scope.stop();
	};
}
//#endregion
//#region src/extensions/core/agentPanel.ts
var CONSENT_AUTO_SHOWN_PREFIX = "Comfy.AgentConsent.AutoShown";
var ACTIVATION_VISITS_STORAGE_KEY = "Comfy.AgentPanel.activationVisits";
var AUTOMATIC_ACTIVATION_VISITS = 2;
function claimAutomaticActivationVisit() {
	try {
		const storedVisits = Number(localStorage.getItem(ACTIVATION_VISITS_STORAGE_KEY) ?? 0);
		const priorVisits = Number.isSafeInteger(storedVisits) && storedVisits >= 0 ? storedVisits : 0;
		if (priorVisits >= AUTOMATIC_ACTIVATION_VISITS) return false;
		localStorage.setItem(ACTIVATION_VISITS_STORAGE_KEY, String(priorVisits + 1));
		return true;
	} catch {
		return false;
	}
}
function automaticActivationVisitsComplete() {
	try {
		const storedVisits = Number(localStorage.getItem(ACTIVATION_VISITS_STORAGE_KEY) ?? 0);
		return Number.isSafeInteger(storedVisits) ? storedVisits >= AUTOMATIC_ACTIVATION_VISITS : false;
	} catch {
		return true;
	}
}
function automaticConsentOfferScope({ activationOpenedPanel, panelOpen, userId, workspaceId, workspaceSwitching }, onMissingScope, onActivatedPanel) {
	if (!userId || !workspaceId || workspaceSwitching) {
		onMissingScope();
		return null;
	}
	if (activationOpenedPanel && panelOpen) {
		onActivatedPanel();
		return null;
	}
	return [userId, workspaceId];
}
function writeAutoShown(key, shown) {
	try {
		localStorage.setItem(key, String(shown));
		return true;
	} catch {
		return false;
	}
}
function wasAutoShown(key) {
	try {
		return localStorage.getItem(key) === "true";
	} catch {
		return false;
	}
}
function prepareAutoShow(key) {
	try {
		if (localStorage.getItem(key) === "true") return "already_offered";
		return writeAutoShown(key, false) ? "ready" : "storage_unavailable";
	} catch {
		return "storage_unavailable";
	}
}
var registered = false;
function registerAgentPanelExtension() {
	if (registered) return;
	useExtensionService().registerExtension({
		name: "Comfy.AgentPanel",
		beforeLoadGraph() {
			notifyRestoreMintersBeforeGraphLoad();
			useCanvasStore().stopNodePicking();
		},
		afterLoadGraph(app) {
			const composer = useAgentComposerStore();
			if (composer.nodeScope !== useWorkflowStore().activeWorkflow?.instanceId) return;
			composer.setNodes(composer.nodes.flatMap((reference) => {
				const node = getNodeByLocatorId(app.rootGraph, selectedNodeKey(reference));
				return node ? [{
					...reference,
					title: node.title
				}] : [];
			}));
		},
		onGraphLoadError() {
			notifyRestoreMintersGraphLoadError();
		},
		afterConfigureGraph() {
			notifyRestoreMintersAfterGraphConfigure();
		},
		setup() {
			const agentPanelStore = useAgentPanelStore();
			const consentStore = useAgentConsentStore();
			const introductionStore = useAgentConsentIntroductionStore();
			const { enabled } = storeToRefs(agentPanelStore);
			const workspaceStore = useTeamWorkspaceStore();
			const { resolvedUserInfo, isLoggedIn, isAuthInitialized } = useCurrentUser();
			const { withConsent } = useAgentConsent();
			const { firstRunHoldsScreen, whenStartupDecided } = useFirstRunEntry();
			const onboardingTourStore = useOnboardingTourStore();
			const dialogStore = useDialogStore();
			registerWorkflowTabActivityTracker(enabled);
			watch(() => consentStore.accepted, (value) => {
				agentPanelStore.consentAccepted = value;
			}, {
				immediate: true,
				flush: "sync"
			});
			const screenBusyReason = () => onboardingTourStore.activeTour !== null ? "tour_active" : dialogStore.dialogStack.length > 0 ? "dialog_open" : null;
			const screenHolder = () => firstRunHoldsScreen.value ? "first_run_screen" : screenBusyReason();
			const screenIsClear = computed(() => screenHolder() === null);
			const reportedWithheld = /* @__PURE__ */ new Set();
			const withholdOffer = (reason, userId = resolvedUserInfo.value?.id, workspaceId = workspaceStore.activeWorkspaceId) => {
				if (!userId || !workspaceId) return;
				if (wasAutoShown(`${CONSENT_AUTO_SHOWN_PREFIX}.${userId}.${workspaceId}`)) return;
				const key = `${userId}.${workspaceId}:${reason}`;
				if (reportedWithheld.has(key)) return;
				reportedWithheld.add(key);
				useTelemetry()?.trackAgentConsentNotOffered({ reason });
			};
			const offerHeld = ref(false);
			const holdOffer = (reason, userId, workspaceId) => {
				withholdOffer(reason, userId, workspaceId);
				offerHeld.value = true;
			};
			const dropHold = () => {
				offerHeld.value = false;
			};
			const reportedExits = /* @__PURE__ */ new Set();
			const reportOfferExit = (exit, stage) => {
				const retryArmed = offerHeld.value;
				const key = `${stage}:${exit}:${retryArmed}`;
				if (reportedExits.has(key)) return;
				reportedExits.add(key);
				useTelemetry()?.trackAgentConsentOfferExited({
					exit,
					stage,
					retry_armed: retryArmed
				});
			};
			const consentCardSeenIn = /* @__PURE__ */ new Set();
			let lockedStartupOpened = false;
			let activationOpenedPanel = false;
			whenever(() => dialogStore.isDialogOpen(CONSENT_DIALOG_KEY), () => {
				const { scope } = introductionStore;
				if (scope) consentCardSeenIn.add(scope);
			});
			function introductionOwed() {
				const { scope } = introductionStore;
				return scope !== null && !introductionStore.hasResponded(scope);
			}
			const offerEligible = () => agentPanelStore.enabled && (agentPanelStore.onboarding.introduceBeforeSignIn ? isAuthInitialized.value : isLoggedIn.value) && !introductionStore.isContinuingSignIn && (agentPanelStore.onboarding.offerMemory !== "answered" || introductionOwed()) && !consentStore.isChecking && !consentStore.accepted;
			const offerIneligibility = () => !agentPanelStore.onboarding.introduceBeforeSignIn && !isLoggedIn.value ? "signed_out" : consentStore.isChecking ? "consent_unresolved" : consentStore.accepted ? "consent_already_accepted" : null;
			const missingScopeExit = (userId) => workspaceStore.isSwitching ? "workspace_switching" : !userId ? "account_unresolved" : "workspace_unresolved";
			function prepareConsentCard(candidateUserId, offeredWorkspaceId) {
				const held = screenHolder();
				if (held) {
					holdOffer(held, candidateUserId, offeredWorkspaceId ?? void 0);
					return false;
				}
				if (agentPanelStore.onboarding.startup !== "lockedUntilConsent") return true;
				if (!agentPanelStore.enabled) return false;
				if (!agentPanelStore.isOpen) agentPanelStore.open("automatic_consent");
				return true;
			}
			function claimOneShotOffer(candidateUserId, offeredWorkspaceId) {
				const offerScope = automaticConsentOfferScope({
					activationOpenedPanel,
					panelOpen: agentPanelStore.isOpen,
					userId: candidateUserId,
					workspaceId: offeredWorkspaceId,
					workspaceSwitching: workspaceStore.isSwitching
				}, () => reportOfferExit(missingScopeExit(candidateUserId), "offer"), () => {
					reportOfferExit("activation_opened_panel", "offer");
					dropHold();
				});
				if (!offerScope) return null;
				const [userId, workspaceId] = offerScope;
				const key = `${CONSENT_AUTO_SHOWN_PREFIX}.${userId}.${workspaceId}`;
				const autoShow = prepareAutoShow(key);
				if (autoShow === "ready") return key;
				if (autoShow === "storage_unavailable") withholdOffer(autoShow);
				else reportOfferExit("already_offered", "offer");
				dropHold();
				return null;
			}
			let autoShowInFlight = false;
			function finishAutomaticOffer(offeredIdentity) {
				autoShowInFlight = false;
				if (consentStore.identity !== offeredIdentity) loadConsentIfEligible();
				else if (offerHeld.value && screenIsClear.value) loadConsentIfEligible();
			}
			const offerConsentUnprompted = () => {
				if (autoShowInFlight) {
					reportOfferExit("offer_in_flight", "offer");
					return;
				}
				if (!offerEligible()) {
					const ineligible = offerIneligibility();
					if (ineligible) reportOfferExit(ineligible, "offer");
					if (consentStore.accepted) dropHold();
					return;
				}
				const { scope } = introductionStore;
				if (scope && consentCardSeenIn.has(scope)) {
					reportOfferExit("card_already_seen", "offer");
					dropHold();
					return;
				}
				const held = screenHolder();
				if (held) {
					holdOffer(held);
					return;
				}
				const candidateUserId = resolvedUserInfo.value?.id;
				const offeredWorkspaceId = workspaceStore.activeWorkspaceId;
				const { offerMemory, startup } = agentPanelStore.onboarding;
				const key = offerMemory === "shown" ? claimOneShotOffer(candidateUserId, offeredWorkspaceId) : null;
				if (offerMemory === "shown" && key === null) return;
				const offeredIdentity = consentStore.identity;
				autoShowInFlight = true;
				dropHold();
				if (startup === "activationVisits") agentPanelStore.suppressRestoredOpen();
				withConsent("first_load", () => {
					if (!agentPanelStore.enabled || startup === "activationVisits" && automaticActivationVisitsComplete() || agentPanelStore.isOpen) return;
					agentPanelStore.open("automatic_consent");
				}, {
					onShown: () => {
						if (key) writeAutoShown(key, true);
					},
					canShow: () => prepareConsentCard(candidateUserId, offeredWorkspaceId)
				}).finally(() => finishAutomaticOffer(offeredIdentity));
			};
			function prepareLockedStartup() {
				if (!agentPanelStore.enabled || !isAuthInitialized.value || consentStore.isChecking || consentStore.accepted) return false;
				const held = screenHolder();
				if (held) {
					holdOffer(held);
					return false;
				}
				if (lockedStartupOpened) return true;
				lockedStartupOpened = true;
				if (!agentPanelStore.isOpen) agentPanelStore.open("activation");
				return true;
			}
			function prepareStartupPanel() {
				if (agentPanelStore.onboarding.startup === "lockedUntilConsent") return prepareLockedStartup();
				if (!automaticActivationVisitsComplete() || agentPanelStore.isOpen) return true;
				reportOfferExit("activation_window_complete", "startup");
				dropHold();
				return false;
			}
			const offerWhenStartupDecided = () => {
				whenStartupDecided().then((decided) => {
					if (agentPanelStore.onboarding.persistSkipAsRefusal && useSettingStore().get("Comfy.AgentPanel.ConsentOfferDeclined")) {
						reportOfferExit("consent_declined", "startup");
						dropHold();
						return;
					}
					if (!decided) {
						if (offerEligible()) withholdOffer("boot_undecided");
						else {
							const ineligible = offerIneligibility();
							if (ineligible) reportOfferExit(ineligible, "startup");
						}
						return;
					}
					if (!prepareStartupPanel()) return;
					offerConsentUnprompted();
				}).catch((error) => {
					reportOfferExit("startup_probe_failed", "startup");
					reportError(error, {
						surface: "agent",
						errorType: "agent_consent_auto_offer_failure"
					});
				});
			};
			let activationPending = false;
			let activationOffered = false;
			const openWhenStartupDecided = () => {
				if (agentPanelStore.onboarding.startup !== "activationVisits" || !agentPanelStore.enabled || activationPending || activationOffered) return;
				activationPending = true;
				whenStartupDecided().then((decided) => {
					if (decided && agentPanelStore.enabled) {
						activationOffered = true;
						if (claimAutomaticActivationVisit() && !agentPanelStore.isOpen) {
							agentPanelStore.open("activation");
							activationOpenedPanel = true;
						}
					}
				}).catch((error) => {
					reportError(error, {
						surface: "agent",
						errorType: "agent_panel_activation_failure"
					});
				}).finally(() => {
					activationPending = false;
				});
			};
			const loadConsentIfEligible = () => {
				const { introduceBeforeSignIn } = agentPanelStore.onboarding;
				if (!agentPanelStore.enabled || introduceBeforeSignIn && !isAuthInitialized.value) return;
				if (introduceBeforeSignIn && !isLoggedIn.value) {
					offerWhenStartupDecided();
					return;
				}
				if (!resolvedUserInfo.value) return;
				const identity = consentStore.identity;
				consentStore.load().then((isAccepted) => {
					if (identity !== consentStore.identity) return;
					if (isAccepted) {
						reportOfferExit("consent_already_accepted", "load");
						dropHold();
					} else offerWhenStartupDecided();
				}).catch((error) => {
					reportOfferExit("consent_read_failed", "load");
					reportError(error, {
						surface: "agent",
						errorType: "agent_consent_setting_load_failure"
					});
				});
			};
			watch([
				() => resolvedUserInfo.value?.id,
				() => consentStore.identity,
				() => isAuthInitialized.value
			], loadConsentIfEligible);
			whenever(() => offerHeld.value && screenIsClear.value, () => {
				loadConsentIfEligible();
			});
			setupFlagGate(loadConsentIfEligible, openWhenStartupDecided);
		}
	});
	registered = true;
}
function setupFlagGate(loadConsentIfEligible, openWhenStartupDecided) {
	const agentPanelStore = useAgentPanelStore();
	watch(() => [agentPanelStore.comfyAgent?.state === "ready", agentPanelStore.comfyAgent], ([enabled]) => {
		agentPanelStore.enabled = enabled;
		loadConsentIfEligible();
		openWhenStartupDecided();
		if (!enabled) useCanvasStore().stopNodePicking();
	}, { immediate: true });
	watch(() => agentPanelStore.flagsSettled, (settled) => {
		agentPanelStore.gateSettled = settled;
	}, { immediate: true });
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.agentPanel = window.comfyAPI.agentPanel || {};
window.comfyAPI.agentPanel.registerAgentPanelExtension = registerAgentPanelExtension;
//#endregion
export { registerAgentPanelExtension };
