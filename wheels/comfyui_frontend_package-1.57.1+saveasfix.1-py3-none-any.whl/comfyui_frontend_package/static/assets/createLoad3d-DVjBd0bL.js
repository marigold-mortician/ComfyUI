import { r as __name } from "./rolldown-runtime-xtsTai4I.js";
import { $ as LineSegments, A as BufferGeometry, At as SkinnedMesh, C as AnimationMixer, Ct as PropertyBinding, D as Box3, E as Bone, Et as SRGBColorSpace, F as Color, Ft as Sprite, H as FileLoader, Ht as Vector2, It as SpriteMaterial, K as GridHelper, Lt as Texture, Q as LineBasicMaterial, Rt as TextureLoader, St as PointsMaterial, T as BasicDepthPacking, Ut as Vector3, V as Euler, X as Light, Z as Line, _ as clone, a as STLLoader, at as MaterialLoader, b as PMREMGenerator, c as FBXLoader, ct as Matrix4, d as GLTFExporter, dt as MeshDepthMaterial, f as RGBELoader, ft as MeshNormalMaterial, ht as OrthographicCamera, i as PLYLoader, it as Material, j as Camera, jt as Sphere, k as BufferAttribute, kt as SkeletonHelper, l as STLExporter, lt as Mesh, m as TransformControls, mt as Object3D, n as SparkRenderer, nt as Loader, o as MTLLoader, p as EXRLoader, pt as MeshStandardMaterial, q as Group, r as SplatMesh, rt as LoopRepeat, s as GLTFLoader, tt as LinearSRGBColorSpace, u as OBJExporter, ut as MeshBasicMaterial, wt as Quaternion, xt as Points } from "./vendor-three-B-UiePqj.js";
import { _ as ControlsManager, a as faceSizesFor, c as readFbxPolygons, d as Viewport3d, f as computeLetterboxedViewport, g as EventManager, h as LightingManager, i as QuadWireframeOverlay, l as isBinaryFbx, m as zlibSync, n as SceneManager, o as registerFaceSizes, p as isLoad3dActive, r as QuadWireframeManager, s as matchFbxPolygons, t as ViewHelperManager, u as positionAttributeOf, v as CameraManager, y as RendererView } from "./ViewHelperManager-BpbYuVKl.js";
import { t as DIRECT_EXPORT_FORMATS } from "./constants-CcZ5JemZ.js";
//#region packages/viewport3d/src/load3d/AnimationManager.ts
var AnimationManager = class {
	currentAnimation = null;
	animationActions = [];
	animationClips = [];
	selectedAnimationIndex = 0;
	isAnimationPlaying = false;
	animationSpeed = 1;
	eventManager;
	constructor(eventManager) {
		this.eventManager = eventManager;
	}
	init() {}
	dispose() {
		if (this.currentAnimation) {
			this.animationActions.forEach((action) => {
				action.stop();
			});
			this.currentAnimation = null;
		}
		this.animationActions = [];
		this.animationClips = [];
		this.selectedAnimationIndex = 0;
		this.isAnimationPlaying = false;
		this.animationSpeed = 1;
		this.eventManager.emitEvent("animationListChange", []);
	}
	setupModelAnimations(model, originalModel) {
		if (this.currentAnimation) {
			this.currentAnimation.stopAllAction();
			this.animationActions = [];
		}
		let animations = [];
		if (model.animations.length > 0) animations = model.animations;
		else if (originalModel && "animations" in originalModel && Array.isArray(originalModel.animations)) animations = originalModel.animations;
		if (animations.length > 0) {
			this.animationClips = animations;
			this.currentAnimation = new AnimationMixer(model);
			if (this.animationClips.length > 0) this.updateSelectedAnimation(0);
		} else this.animationClips = [];
		this.updateAnimationList();
	}
	updateAnimationList() {
		let updatedAnimationList = [];
		if (this.animationClips.length > 0) updatedAnimationList = this.animationClips.map((clip, index) => ({
			name: clip.name || `Animation ${index + 1}`,
			index
		}));
		this.eventManager.emitEvent("animationListChange", updatedAnimationList);
	}
	setAnimationSpeed(speed) {
		this.animationSpeed = speed;
		this.animationActions.forEach((action) => {
			action.setEffectiveTimeScale(speed);
		});
	}
	updateSelectedAnimation(index) {
		if (!this.currentAnimation || index >= this.animationClips.length) {
			console.warn("Invalid animation update request");
			return;
		}
		this.animationActions.forEach((action) => {
			action.stop();
		});
		this.currentAnimation.stopAllAction();
		this.animationActions = [];
		this.selectedAnimationIndex = index;
		const clip = this.animationClips[index];
		const action = this.currentAnimation.clipAction(clip);
		action.setEffectiveTimeScale(this.animationSpeed);
		action.reset();
		action.clampWhenFinished = false;
		action.loop = LoopRepeat;
		if (this.isAnimationPlaying) action.play();
		else {
			action.play();
			action.paused = true;
		}
		this.animationActions = [action];
		this.eventManager.emitEvent("animationProgressChange", {
			progress: 0,
			currentTime: 0,
			duration: clip.duration
		});
	}
	toggleAnimation(play) {
		if (!this.currentAnimation || this.animationActions.length === 0) {
			console.warn("No animation to toggle");
			return;
		}
		this.isAnimationPlaying = play ?? !this.isAnimationPlaying;
		this.animationActions.forEach((action) => {
			if (this.isAnimationPlaying) {
				action.paused = false;
				if (action.time === 0 || action.time === action.getClip().duration) action.reset();
			} else action.paused = true;
		});
	}
	update(delta) {
		if (this.currentAnimation && this.isAnimationPlaying) {
			this.currentAnimation.update(delta);
			if (this.animationActions.length > 0) {
				const action = this.animationActions[0];
				const clip = action.getClip();
				const progress = action.time / clip.duration * 100;
				this.eventManager.emitEvent("animationProgressChange", {
					progress,
					currentTime: action.time,
					duration: clip.duration
				});
			}
		}
	}
	getAnimationTime() {
		if (this.animationActions.length === 0) return 0;
		return this.animationActions[0].time;
	}
	getAnimationDuration() {
		if (this.animationActions.length === 0) return 0;
		return this.animationActions[0].getClip().duration;
	}
	setAnimationTime(time) {
		if (this.animationActions.length === 0) return;
		const duration = this.getAnimationDuration();
		const clampedTime = Math.max(0, Math.min(time, duration));
		const wasPaused = this.animationActions.map((action) => action.paused);
		this.animationActions.forEach((action) => {
			action.paused = false;
			action.time = clampedTime;
		});
		if (this.currentAnimation) {
			this.currentAnimation.setTime(clampedTime);
			this.currentAnimation.update(0);
		}
		this.animationActions.forEach((action, i) => {
			action.paused = wasPaused[i];
		});
		this.eventManager.emitEvent("animationProgressChange", {
			progress: clampedTime / duration * 100,
			currentTime: clampedTime,
			duration
		});
	}
	reset() {}
};
//#endregion
//#region packages/viewport3d/src/load3d/GizmoManager.ts
var OFF_SCREEN_POINTER_NDC = {
	x: 10,
	y: 10
};
var GizmoManager = class {
	transformControls = null;
	targetObject = null;
	initialPosition = new Vector3();
	initialRotation = new Euler();
	initialScale = new Vector3(1, 1, 1);
	enabled = false;
	activeCamera;
	mode = "translate";
	scene;
	interactionElement;
	orbitControls;
	onTransformChange;
	getPointerNdc;
	constructor(scene, interactionElement, orbitControls, getActiveCamera, onTransformChange) {
		this.scene = scene;
		this.interactionElement = interactionElement;
		this.orbitControls = orbitControls;
		this.activeCamera = getActiveCamera();
		this.onTransformChange = onTransformChange;
	}
	init() {
		this.transformControls = new TransformControls(this.activeCamera, this.interactionElement);
		this.transformControls.addEventListener("dragging-changed", (event) => {
			this.orbitControls.enabled = !event.value;
			if (!event.value && this.onTransformChange) this.onTransformChange();
		});
		this.installPointerNdcOverride();
		const helper = this.transformControls.getHelper();
		helper.name = "GizmoTransformControls";
		helper.renderOrder = 999;
		this.scene.add(helper);
	}
	setPointerNdcSource(getPointerNdc) {
		this.getPointerNdc = getPointerNdc;
	}
	installPointerNdcOverride() {
		if (!this.transformControls) return;
		const transformControls = this.transformControls;
		const controls = transformControls;
		const original = controls._getPointer;
		if (typeof original !== "function") {
			console.warn("TransformControls no longer exposes _getPointer; letterbox-aware gizmo pointer mapping is disabled.");
			return;
		}
		controls._getPointer = (event) => {
			if (!this.getPointerNdc) return original.call(transformControls, event);
			const ndc = this.getPointerNdc(event.clientX, event.clientY);
			if (!ndc || !ndc.inside && !transformControls.dragging) return {
				...OFF_SCREEN_POINTER_NDC,
				button: event.button
			};
			return {
				x: ndc.x,
				y: ndc.y,
				button: event.button
			};
		};
	}
	setupForModel(model) {
		if (!this.transformControls) return;
		this.ensureHelperInScene();
		this.transformControls.detach();
		this.transformControls.enabled = false;
		this.targetObject = model;
		this.initialPosition.copy(model.position);
		this.initialRotation.copy(model.rotation);
		this.initialScale.copy(model.scale);
		if (this.enabled) {
			this.transformControls.attach(model);
			this.transformControls.setMode(this.mode);
			this.transformControls.enabled = true;
		}
	}
	detach() {
		this.enabled = false;
		if (this.transformControls) {
			this.transformControls.detach();
			this.transformControls.enabled = false;
		}
		this.targetObject = null;
	}
	setEnabled(enabled) {
		this.enabled = enabled;
		if (!this.transformControls) return;
		this.ensureHelperInScene();
		if (enabled && this.targetObject) {
			this.transformControls.attach(this.targetObject);
			this.transformControls.setMode(this.mode);
			this.transformControls.enabled = true;
		} else {
			this.transformControls.detach();
			this.transformControls.enabled = false;
		}
	}
	ensureHelperInScene() {
		if (!this.transformControls) return;
		const helper = this.transformControls.getHelper();
		if (!helper.parent) this.scene.add(helper);
	}
	removeFromScene() {
		if (!this.transformControls) return;
		const helper = this.transformControls.getHelper();
		if (helper.parent) helper.parent.remove(helper);
	}
	isEnabled() {
		return this.enabled;
	}
	updateCamera(camera) {
		this.activeCamera = camera;
		if (this.transformControls) this.transformControls.camera = camera;
	}
	setMode(mode) {
		this.mode = mode;
		if (this.transformControls) this.transformControls.setMode(mode);
	}
	getMode() {
		return this.mode;
	}
	reset() {
		if (!this.targetObject) return;
		this.targetObject.position.copy(this.initialPosition);
		this.targetObject.rotation.copy(this.initialRotation);
		this.targetObject.scale.copy(this.initialScale);
		this.onTransformChange?.();
	}
	applyTransform(position, rotation, scale) {
		if (!this.targetObject) return;
		this.targetObject.position.set(position.x, position.y, position.z);
		this.targetObject.rotation.set(rotation.x, rotation.y, rotation.z);
		if (scale) this.targetObject.scale.set(scale.x, scale.y, scale.z);
	}
	applyModelTransform(transform) {
		if (!this.targetObject) return;
		this.targetObject.position.set(transform.position.x, transform.position.y, transform.position.z);
		this.targetObject.quaternion.set(transform.quaternion.x, transform.quaternion.y, transform.quaternion.z, transform.quaternion.w);
		this.targetObject.scale.set(transform.scale.x, transform.scale.y, transform.scale.z);
		this.onTransformChange?.();
	}
	getInitialTransform() {
		return {
			position: {
				x: this.initialPosition.x,
				y: this.initialPosition.y,
				z: this.initialPosition.z
			},
			rotation: {
				x: this.initialRotation.x,
				y: this.initialRotation.y,
				z: this.initialRotation.z
			},
			scale: {
				x: this.initialScale.x,
				y: this.initialScale.y,
				z: this.initialScale.z
			}
		};
	}
	getTransform() {
		if (!this.targetObject) return {
			position: {
				x: 0,
				y: 0,
				z: 0
			},
			rotation: {
				x: 0,
				y: 0,
				z: 0
			},
			scale: {
				x: 1,
				y: 1,
				z: 1
			}
		};
		return {
			position: {
				x: this.targetObject.position.x,
				y: this.targetObject.position.y,
				z: this.targetObject.position.z
			},
			rotation: {
				x: this.targetObject.rotation.x,
				y: this.targetObject.rotation.y,
				z: this.targetObject.rotation.z
			},
			scale: {
				x: this.targetObject.scale.x,
				y: this.targetObject.scale.y,
				z: this.targetObject.scale.z
			}
		};
	}
	getModelInfo() {
		const object = this.targetObject;
		if (!object) return null;
		return {
			position: {
				x: object.position.x,
				y: object.position.y,
				z: object.position.z
			},
			quaternion: {
				x: object.quaternion.x,
				y: object.quaternion.y,
				z: object.quaternion.z,
				w: object.quaternion.w
			},
			scale: {
				x: object.scale.x,
				y: object.scale.y,
				z: object.scale.z
			}
		};
	}
	dispose() {
		if (this.transformControls) {
			const helper = this.transformControls.getHelper();
			this.scene.remove(helper);
			this.transformControls.detach();
			this.transformControls.dispose();
			this.transformControls = null;
		}
		this.targetObject = null;
	}
};
//#endregion
//#region packages/viewport3d/src/load3d/HDRIManager.ts
function getFilenameExtension(url) {
	const queryString = url.split("?")[1];
	if (queryString) {
		const filename = new URLSearchParams(queryString).get("filename");
		if (filename) return filename.split(".").pop()?.toLowerCase();
	}
	return url.split("?")[0].split(".").pop()?.toLowerCase();
}
var HDRIManager = class {
	scene;
	viewState;
	pmremGenerator;
	eventManager;
	hdriTexture = null;
	envMapTarget = null;
	_isEnabled = false;
	_showAsBackground = false;
	_intensity = 1;
	get isEnabled() {
		return this._isEnabled;
	}
	get showAsBackground() {
		return this._showAsBackground;
	}
	get intensity() {
		return this._intensity;
	}
	constructor(scene, renderer, viewState, eventManager) {
		this.scene = scene;
		this.viewState = viewState;
		this.pmremGenerator = new PMREMGenerator(renderer);
		this.pmremGenerator.compileEquirectangularShader();
		this.eventManager = eventManager;
	}
	async loadHDRI(url) {
		const ext = getFilenameExtension(url);
		let newTexture;
		if (ext === "exr") newTexture = await new Promise((resolve, reject) => {
			new EXRLoader().load(url, resolve, void 0, reject);
		});
		else newTexture = await new Promise((resolve, reject) => {
			new RGBELoader().load(url, resolve, void 0, reject);
		});
		newTexture.mapping = 303;
		const newEnvMapTarget = this.pmremGenerator.fromEquirectangular(newTexture);
		this.hdriTexture?.dispose();
		this.envMapTarget?.dispose();
		this.hdriTexture = newTexture;
		this.envMapTarget = newEnvMapTarget;
		if (this._isEnabled) this.applyToScene();
	}
	setEnabled(enabled) {
		this._isEnabled = enabled;
		if (enabled) {
			if (this.envMapTarget) this.applyToScene();
		} else this.removeFromScene();
	}
	setShowAsBackground(show) {
		this._showAsBackground = show;
		if (this._isEnabled && this.envMapTarget) this.applyToScene();
	}
	setIntensity(intensity) {
		this._intensity = intensity;
		if (this._isEnabled) this.scene.environmentIntensity = intensity;
	}
	applyToScene() {
		const envMap = this.envMapTarget?.texture;
		if (!envMap) return;
		this.scene.environment = envMap;
		this.scene.environmentIntensity = this._intensity;
		this.scene.background = this._showAsBackground ? this.hdriTexture : null;
		this.viewState.toneMapping = 4;
		this.viewState.toneMappingExposure = 1;
		this.eventManager.emitEvent("hdriChange", {
			enabled: this._isEnabled,
			showAsBackground: this._showAsBackground
		});
	}
	removeFromScene() {
		this.scene.environment = null;
		if (this.scene.background === this.hdriTexture) this.scene.background = null;
		this.viewState.toneMapping = 0;
		this.viewState.toneMappingExposure = 1;
		this.eventManager.emitEvent("hdriChange", {
			enabled: false,
			showAsBackground: this._showAsBackground
		});
	}
	clearResources() {
		this.removeFromScene();
		this.hdriTexture?.dispose();
		this.envMapTarget?.dispose();
		this.hdriTexture = null;
		this.envMapTarget = null;
	}
	clear() {
		this.clearResources();
		this._isEnabled = false;
	}
	dispose() {
		this.clearResources();
		this.pmremGenerator.dispose();
	}
};
"B".charCodeAt(0);
"C".charCodeAt(0);
"Z".charCodeAt(0);
"Y".charCodeAt(0);
"I".charCodeAt(0);
"L".charCodeAt(0);
"F".charCodeAt(0);
"D".charCodeAt(0);
"R".charCodeAt(0);
"S".charCodeAt(0);
"i".charCodeAt(0);
"l".charCodeAt(0);
"f".charCodeAt(0);
"d".charCodeAt(0);
"b".charCodeAt(0);
"c".charCodeAt(0);
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/core/FBXElem.js
var TEXT_ENCODER$2 = new TextEncoder();
var ELEMS_ALWAYS_BLOCK_SENTINEL = /* @__PURE__ */ new Set(["AnimationStack", "AnimationLayer"]);
/**
* A single node in the FBX binary tree.
*
* Construct with `new FBXElem(id)` where `id` is an ASCII string ≤ 255 bytes.
* Add typed properties via the `add*` methods and child nodes via `addChild`.
*
* Two-phase write: `_calcOffsets()` resolves end-offsets; `_write()` emits bytes.
* Use the top-level `encodeBinaryFBX()` helper instead of calling these directly.
*/
var FBXElem = class FBXElem {
	id;
	_idBytes;
	propsType;
	propsData;
	elems;
	_endOffset;
	_propsLength;
	constructor(id) {
		this.id = id;
		this._idBytes = TEXT_ENCODER$2.encode(id);
		if (this._idBytes.length > 255) throw new RangeError(`FBX node id too long: ${this._idBytes.length} UTF-8 bytes (max 255). id=${JSON.stringify(id)}`);
		this.propsType = [];
		this.propsData = [];
		this.elems = [];
		this._endOffset = -1;
		this._propsLength = -1;
	}
	addChild(elem) {
		this.elems.push(elem);
		return elem;
	}
	/** Create + add a child by id, optionally seeding props. */
	addEmpty(id) {
		return this.addChild(new FBXElem(id));
	}
	addBool(v) {
		this.propsType.push(66);
		this.propsData.push(new Uint8Array([v ? 1 : 0]));
	}
	addChar(byte) {
		this.propsType.push(67);
		this.propsData.push(new Uint8Array([byte & 255]));
	}
	addInt8(v) {
		const b = /* @__PURE__ */ new ArrayBuffer(1);
		new DataView(b).setInt8(0, v);
		this.propsType.push(90);
		this.propsData.push(new Uint8Array(b));
	}
	addInt16(v) {
		const b = /* @__PURE__ */ new ArrayBuffer(2);
		new DataView(b).setInt16(0, v, true);
		this.propsType.push(89);
		this.propsData.push(new Uint8Array(b));
	}
	addInt32(v) {
		const b = /* @__PURE__ */ new ArrayBuffer(4);
		new DataView(b).setInt32(0, v, true);
		this.propsType.push(73);
		this.propsData.push(new Uint8Array(b));
	}
	addInt64(v) {
		const b = /* @__PURE__ */ new ArrayBuffer(8);
		new DataView(b).setBigInt64(0, typeof v === "bigint" ? v : BigInt(v), true);
		this.propsType.push(76);
		this.propsData.push(new Uint8Array(b));
	}
	addFloat32(v) {
		const b = /* @__PURE__ */ new ArrayBuffer(4);
		new DataView(b).setFloat32(0, v, true);
		this.propsType.push(70);
		this.propsData.push(new Uint8Array(b));
	}
	addFloat64(v) {
		const b = /* @__PURE__ */ new ArrayBuffer(8);
		new DataView(b).setFloat64(0, v, true);
		this.propsType.push(68);
		this.propsData.push(new Uint8Array(b));
	}
	/** Raw bytes property (FBX type tag 'R'). */
	addBytes(u8) {
		const out = new Uint8Array(4 + u8.byteLength);
		new DataView(out.buffer).setUint32(0, u8.byteLength, true);
		out.set(u8, 4);
		this.propsType.push(82);
		this.propsData.push(out);
	}
	/** String property (FBX type tag 'S'). FBX strings are length-prefixed bytes. */
	addString(str) {
		const bytes = typeof str === "string" ? TEXT_ENCODER$2.encode(str) : str;
		const out = new Uint8Array(4 + bytes.byteLength);
		new DataView(out.buffer).setUint32(0, bytes.byteLength, true);
		out.set(bytes, 4);
		this.propsType.push(83);
		this.propsData.push(out);
	}
	/** Internal: encode a typed-array payload into FBX array prop format. */
	_addArray(typeTag, elementCount, rawBytes) {
		const uncompressed = new Uint8Array(rawBytes);
		let encoding;
		let body;
		if (uncompressed.byteLength > 128) {
			const compressed = zlibSync(uncompressed, { level: 1 });
			encoding = 1;
			body = compressed;
		} else {
			encoding = 0;
			body = uncompressed;
		}
		const out = new Uint8Array(12 + body.byteLength);
		const dv = new DataView(out.buffer);
		dv.setUint32(0, elementCount, true);
		dv.setUint32(4, encoding, true);
		dv.setUint32(8, body.byteLength, true);
		out.set(body, 12);
		this.propsType.push(typeTag);
		this.propsData.push(out);
	}
	addBoolArray(arr) {
		const u8 = arr instanceof Uint8Array ? arr : Uint8Array.from(arr, (x) => x ? 1 : 0);
		this._addArray(98, u8.length, u8);
	}
	addByteArray(arr) {
		const u8 = arr instanceof Uint8Array ? arr : Uint8Array.from(arr);
		this._addArray(99, u8.length, u8);
	}
	addInt32Array(arr) {
		const ta = arr instanceof Int32Array ? arr : Int32Array.from(arr);
		this._addArray(105, ta.length, ta.buffer.slice(ta.byteOffset, ta.byteOffset + ta.byteLength));
	}
	addInt64Array(arr) {
		const ta = arr instanceof BigInt64Array ? arr : BigInt64Array.from(arr, (x) => typeof x === "bigint" ? x : BigInt(x));
		this._addArray(108, ta.length, ta.buffer.slice(ta.byteOffset, ta.byteOffset + ta.byteLength));
	}
	addFloat32Array(arr) {
		const ta = arr instanceof Float32Array ? arr : Float32Array.from(arr);
		this._addArray(102, ta.length, ta.buffer.slice(ta.byteOffset, ta.byteOffset + ta.byteLength));
	}
	addFloat64Array(arr) {
		const ta = arr instanceof Float64Array ? arr : Float64Array.from(arr);
		this._addArray(100, ta.length, ta.buffer.slice(ta.byteOffset, ta.byteOffset + ta.byteLength));
	}
	/**
	* Recursively compute end offsets.
	* `ctx` carries the version-dependent meta + sentinel sizes.
	* `isLast` indicates whether this elem is the last sibling at its level.
	*/
	_calcOffsets(offset, isLast, ctx) {
		offset += ctx.metaSize;
		offset += 1 + this._idBytes.length;
		let propsLength = 0;
		for (let i = 0; i < this.propsData.length; i++) propsLength += 1 + this.propsData[i].byteLength;
		this._propsLength = propsLength;
		offset += propsLength;
		offset = this._calcOffsetsChildren(offset, isLast, ctx);
		this._endOffset = offset;
		return offset;
	}
	_calcOffsetsChildren(offset, isLast, ctx) {
		if (this.elems.length > 0) {
			const last = this.elems.length - 1;
			for (let i = 0; i < this.elems.length; i++) offset = this.elems[i]._calcOffsets(offset, i === last, ctx);
			offset += ctx.sentinelSize;
		} else if (this.propsData.length === 0 && !isLast || ELEMS_ALWAYS_BLOCK_SENTINEL.has(this.id)) offset += ctx.sentinelSize;
		return offset;
	}
	/** Emit bytes into the BinaryWriter. */
	_write(bw, isLast, ctx) {
		if (this._endOffset < 0 || this._propsLength < 0) throw new Error("_calcOffsets must run before _write");
		if (ctx.use64) {
			bw.writeU64(BigInt(this._endOffset));
			bw.writeU64(BigInt(this.propsData.length));
			bw.writeU64(BigInt(this._propsLength));
		} else {
			bw.writeU32(this._endOffset);
			bw.writeU32(this.propsData.length);
			bw.writeU32(this._propsLength);
		}
		bw.writeU8(this._idBytes.length);
		bw.writeBytes(this._idBytes);
		for (let i = 0; i < this.propsData.length; i++) {
			bw.writeU8(this.propsType[i]);
			bw.writeBytes(this.propsData[i]);
		}
		this._writeChildren(bw, isLast, ctx);
		if (bw.tell() !== this._endOffset) throw new Error(`FBXElem ${this.id}: end offset mismatch (expected ${this._endOffset}, got ${bw.tell()})`);
	}
	_writeChildren(bw, isLast, ctx) {
		if (this.elems.length > 0) {
			const last = this.elems.length - 1;
			for (let i = 0; i < this.elems.length; i++) this.elems[i]._write(bw, i === last, ctx);
			bw.writeZeros(ctx.sentinelSize);
		} else if (this.propsData.length === 0 && !isLast || ELEMS_ALWAYS_BLOCK_SENTINEL.has(this.id)) bw.writeZeros(ctx.sentinelSize);
	}
};
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/core/BinaryWriter.js
/**
* Little-endian binary stream writer backed by a growing ArrayBuffer.
*/
var TEXT_ENCODER$1 = new TextEncoder();
var BinaryWriter = class {
	_buf;
	_view;
	_u8;
	_offset;
	constructor(initialCapacity = 4096) {
		this._buf = new ArrayBuffer(initialCapacity);
		this._view = new DataView(this._buf);
		this._u8 = new Uint8Array(this._buf);
		this._offset = 0;
	}
	get length() {
		return this._offset;
	}
	tell() {
		return this._offset;
	}
	_ensure(n) {
		const need = this._offset + n;
		if (need <= this._buf.byteLength) return;
		let cap = this._buf.byteLength;
		while (cap < need) cap *= 2;
		const nb = new ArrayBuffer(cap);
		new Uint8Array(nb).set(this._u8);
		this._buf = nb;
		this._view = new DataView(nb);
		this._u8 = new Uint8Array(nb);
	}
	writeU8(v) {
		this._ensure(1);
		this._view.setUint8(this._offset, v);
		this._offset += 1;
	}
	writeI8(v) {
		this._ensure(1);
		this._view.setInt8(this._offset, v);
		this._offset += 1;
	}
	writeU16(v) {
		this._ensure(2);
		this._view.setUint16(this._offset, v, true);
		this._offset += 2;
	}
	writeI16(v) {
		this._ensure(2);
		this._view.setInt16(this._offset, v, true);
		this._offset += 2;
	}
	writeU32(v) {
		this._ensure(4);
		this._view.setUint32(this._offset, v, true);
		this._offset += 4;
	}
	writeI32(v) {
		this._ensure(4);
		this._view.setInt32(this._offset, v, true);
		this._offset += 4;
	}
	writeF32(v) {
		this._ensure(4);
		this._view.setFloat32(this._offset, v, true);
		this._offset += 4;
	}
	writeF64(v) {
		this._ensure(8);
		this._view.setFloat64(this._offset, v, true);
		this._offset += 8;
	}
	writeU64(v) {
		this._ensure(8);
		this._view.setBigUint64(this._offset, typeof v === "bigint" ? v : BigInt(v), true);
		this._offset += 8;
	}
	writeI64(v) {
		this._ensure(8);
		this._view.setBigInt64(this._offset, typeof v === "bigint" ? v : BigInt(v), true);
		this._offset += 8;
	}
	/** Append raw bytes (Uint8Array). */
	writeBytes(u8) {
		this._ensure(u8.byteLength);
		this._u8.set(u8, this._offset);
		this._offset += u8.byteLength;
	}
	/** Append a UTF-8 encoded string with no length prefix. */
	writeUtf8(str) {
		this.writeBytes(TEXT_ENCODER$1.encode(str));
	}
	/** Fill N zero bytes. */
	writeZeros(n) {
		this._ensure(n);
		this._u8.fill(0, this._offset, this._offset + n);
		this._offset += n;
	}
	/** Return a tightly-sized Uint8Array view of the written bytes. */
	toUint8Array() {
		return this._u8.slice(0, this._offset);
	}
	/** Return a tightly-sized ArrayBuffer. */
	toArrayBuffer() {
		return this.toUint8Array().buffer;
	}
};
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/core/encodeBinary.js
var TEXT_ENCODER = new TextEncoder();
var HEAD_MAGIC = new Uint8Array([
	75,
	97,
	121,
	100,
	97,
	114,
	97,
	32,
	70,
	66,
	88,
	32,
	66,
	105,
	110,
	97,
	114,
	121,
	32,
	32,
	0,
	26,
	0
]);
var TIME_ID = TEXT_ENCODER.encode("1970-01-01 10:00:00:000");
var FILE_ID = new Uint8Array([
	40,
	179,
	42,
	235,
	182,
	36,
	204,
	194,
	191,
	200,
	176,
	42,
	169,
	43,
	252,
	241
]);
var FOOT_ID = new Uint8Array([
	250,
	188,
	171,
	9,
	208,
	200,
	212,
	102,
	177,
	118,
	251,
	131,
	28,
	247,
	38,
	126
]);
var TAIL_MAGIC = new Uint8Array([
	248,
	90,
	140,
	106,
	222,
	245,
	217,
	126,
	236,
	233,
	12,
	227,
	117,
	143,
	41,
	11
]);
function versionContext(version) {
	if (version < 7500) return {
		use64: false,
		metaSize: 12,
		sentinelSize: 13
	};
	return {
		use64: true,
		metaSize: 24,
		sentinelSize: 25
	};
}
/**
* Overwrite FileId and CreationTime properties on direct children of `root` with
* fixed-value placeholders, so the file passes CRC even though we are
* not computing time-based CRCs.
*
* No-op if either element is missing.
*/
function applyTimeHack(root) {
	let patched = 0;
	for (const elem of root.elems) {
		if (elem.id === "FileId") {
			elem.propsType = [];
			elem.propsData = [];
			elem.addBytes(FILE_ID);
			patched++;
		} else if (elem.id === "CreationTime") {
			elem.propsType = [];
			elem.propsData = [];
			elem.addString(TIME_ID);
			patched++;
		}
		if (patched === 2) break;
	}
}
/**
* Serialize an FBXElem root tree to a binary FBX file buffer.
*
* `root` MUST be an FBXElem with an empty id (acts as an anonymous container of
* top-level sections like FBXHeaderExtension, GlobalSettings, Documents, ...).
*
* Returns a Uint8Array.
*/
function encodeBinaryFBX(root, { version = 7400 } = {}) {
	if (!(root instanceof FBXElem)) throw new TypeError("root must be an FBXElem");
	if (root.id !== "") throw new Error("root FBXElem must have an empty id");
	applyTimeHack(root);
	const ctx = versionContext(version);
	const bw = new BinaryWriter(65536);
	bw.writeBytes(HEAD_MAGIC);
	bw.writeU32(version);
	root._calcOffsetsChildren(bw.tell(), false, ctx);
	root._writeChildren(bw, false, ctx);
	bw.writeBytes(FOOT_ID);
	bw.writeZeros(4);
	const ofs = bw.tell();
	let pad = (ofs + 15 & -16) - ofs;
	if (pad === 0) pad = 16;
	bw.writeZeros(pad);
	bw.writeU32(version);
	bw.writeZeros(120);
	bw.writeBytes(TAIL_MAGIC);
	return bw.toUint8Array();
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/core/uid.js
/**
* Stable string-key → 64-bit FBX UID generator with collision-resistant caching.
*
* FBX UIDs are signed int64. We keep generated values below 2^63
* and resolve collisions by linear probing.
*/
var FNV_OFFSET = 14695981039346656037n;
var FNV_PRIME = 1099511628211n;
var I64_MAX = (1n << 63n) - 1n;
var SHRINK_MOD = 1000000000n;
/** FNV-1a hash over UTF-8 bytes of `s`, returned as BigInt in [0, 2^64). */
function fnv1a64(s) {
	let h = FNV_OFFSET;
	const bytes = new TextEncoder().encode(s);
	for (let i = 0; i < bytes.length; i++) {
		h ^= BigInt(bytes[i]);
		h = h * FNV_PRIME & 18446744073709551615n;
	}
	return h;
}
var UidRegistry = class {
	_keyToUid;
	_uidToKey;
	constructor() {
		this._keyToUid = /* @__PURE__ */ new Map();
		this._uidToKey = /* @__PURE__ */ new Map();
	}
	/**
	* Return a stable 64-bit UID for `key`. Two calls with the same string
	* return the same UID. Different strings get different UIDs (collisions
	* resolved by linear probing).
	*
	* @param {string} key
	* @returns {bigint}
	*/
	get(key) {
		const cached = this._keyToUid.get(key);
		if (cached !== void 0) return cached;
		let uid = fnv1a64(key);
		if (uid > I64_MAX) uid &= I64_MAX;
		if (uid > SHRINK_MOD) {
			const shrunk = uid % SHRINK_MOD;
			if (!this._uidToKey.has(shrunk)) uid = shrunk;
		}
		while (this._uidToKey.has(uid)) {
			uid = uid >= 1n << 62n ? uid - 1n : uid + 1n;
			if (uid < 0n || uid > I64_MAX) throw new Error(`Unable to allocate FBX UID for key "${key}"`);
		}
		this._keyToUid.set(key, uid);
		this._uidToKey.set(uid, key);
		return uid;
	}
	/** Reverse lookup (debugging). */
	keyOf(uid) {
		return this._uidToKey.get(uid);
	}
	/** Number of allocated UIDs. */
	get size() {
		return this._keyToUid.size;
	}
};
var TYPE_TAG = {
	scene: "Scene",
	object: "Object",
	mesh: "Mesh",
	geometry: "Geometry",
	material: "Material",
	texture: "Texture",
	video: "Video",
	light: "Light",
	camera: "Camera",
	bone: "Bone",
	armature: "Armature",
	skeleton: "Skeleton",
	animstack: "AnimStack",
	animlayer: "AnimLayer",
	animcurvenode: "AnimCurveNode",
	animcurve: "AnimCurve"
};
/** Stable string key for an arbitrary scene entity. `id` is usually `object.uuid`. */
function entityKey(typeName, id) {
	return `B${TYPE_TAG[typeName] ?? typeName}#${id}`;
}
function geometryKey(objectUuid) {
	return `${entityKey("mesh", objectUuid)}|Geometry`;
}
function materialKey(materialUuid) {
	return entityKey("material", materialUuid);
}
function textureKey(textureUuid) {
	return entityKey("texture", textureUuid);
}
function videoKey(textureUuid) {
	return `${entityKey("texture", textureUuid)}|Video`;
}
function modelKey(objectUuid) {
	return entityKey("object", objectUuid);
}
function boneKey(armatureUuid, boneUuid) {
	return `${entityKey("armature", armatureUuid)}|${entityKey("bone", boneUuid)}`;
}
function boneAttrKey(armatureUuid, boneUuid) {
	return `${boneKey(armatureUuid, boneUuid)}|Data`;
}
function skinDeformerKey(armatureUuid, meshUuid) {
	return `${entityKey("armature", armatureUuid)}|${entityKey("mesh", meshUuid)}|DeformerSkin`;
}
function clusterKey(armatureUuid, meshUuid, boneUuid) {
	return `${entityKey("armature", armatureUuid)}|${entityKey("mesh", meshUuid)}|${entityKey("bone", boneUuid)}|SubDeformerCluster`;
}
function bindPoseKey(objectUuid, meshUuid) {
	return `${entityKey("object", objectUuid)}|${entityKey("mesh", meshUuid)}|BindPose`;
}
function animStackKey(clipUuid) {
	return `${entityKey("animstack", clipUuid)}`;
}
function animLayerKey(clipUuid) {
	return `${entityKey("animstack", clipUuid)}|Layer`;
}
function animCurveNodeKey(clipUuid, targetUuid, propName) {
	return `${animLayerKey(clipUuid)}|${entityKey("animcurvenode", targetUuid)}|${propName}`;
}
function animCurveKey(clipUuid, targetUuid, propName, axis) {
	return `${animCurveNodeKey(clipUuid, targetUuid, propName)}|${axis}`;
}
var documentKey = (name) => `__FBX_Document__${name}`;
var blendShapeDeformerKey = (geometryUuid) => `${entityKey("geometry", geometryUuid)}|BlendShape`;
var blendShapeChannelKey = (geometryUuid, channelIndex, channelName) => `${entityKey("geometry", geometryUuid)}|BlendShapeChannel|${channelIndex}|${channelName}`;
var shapeGeometryKey = (geometryUuid, channelIndex, channelName) => `${entityKey("geometry", geometryUuid)}|Shape|${channelIndex}|${channelName}`;
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/core/elemHelpers.js
/**
* Every helper returns the created FBXElem so callers can chain or attach children.
*/
function single(parent, name, addFn) {
	const e = new FBXElem(name);
	addFn(e);
	parent.addChild(e);
	return e;
}
var elemEmpty = (parent, name) => parent.addEmpty(name);
var elemDataSingleChar = (p, n, v) => single(p, n, (e) => e.addChar(v));
var elemDataSingleInt32 = (p, n, v) => single(p, n, (e) => e.addInt32(v));
var elemDataSingleInt64 = (p, n, v) => single(p, n, (e) => e.addInt64(v));
var elemDataSingleFloat64 = (p, n, v) => single(p, n, (e) => e.addFloat64(v));
var elemDataSingleBytes = (p, n, v) => single(p, n, (e) => e.addBytes(v));
var elemDataSingleString = (p, n, v) => single(p, n, (e) => e.addString(v));
var elemDataSingleInt32Array = (p, n, v) => single(p, n, (e) => e.addInt32Array(v));
var elemDataSingleInt64Array = (p, n, v) => single(p, n, (e) => e.addInt64Array(v));
var elemDataSingleFloat32Array = (p, n, v) => single(p, n, (e) => e.addFloat32Array(v));
var elemDataSingleFloat64Array = (p, n, v) => single(p, n, (e) => e.addFloat64Array(v));
/**
* Encode a (name, class) pair as a single FBX object-id string.
*
* Mirrors `fbx_utils.py: fbx_name_class` (line 1891) which joins with the
* `\x00\x01` separator. The leading null is significant: FBXLoader's binary
* reader (`BinaryReader.getString`, FBXLoader.js:4265-4266) truncates at the
* first null, so on import `attrName` becomes the bare name and the class
* suffix is silently dropped. Maya / Unreal honor the full separator.
*/
function fbxNameClass(name, cls) {
	return `${name}\x00\x01${cls}`;
}
var F64 = "addFloat64";
var I32 = "addInt32";
var I64 = "addInt64";
var STR = "addString";
/** @type {Record<string, [string, string, ...string[]]>} */
var PTYPES = {
	p_bool: [
		"bool",
		"",
		I32
	],
	p_integer: [
		"int",
		"Integer",
		I32
	],
	p_ulonglong: [
		"ULongLong",
		"",
		I64
	],
	p_double: [
		"double",
		"Number",
		F64
	],
	p_number: [
		"Number",
		"",
		F64
	],
	p_enum: [
		"enum",
		"",
		I32
	],
	p_vector_3d: [
		"Vector3D",
		"Vector",
		F64,
		F64,
		F64
	],
	p_vector: [
		"Vector",
		"",
		F64,
		F64,
		F64
	],
	p_color_rgb: [
		"ColorRGB",
		"Color",
		F64,
		F64,
		F64
	],
	p_color: [
		"Color",
		"",
		F64,
		F64,
		F64
	],
	p_string: [
		"KString",
		"",
		STR
	],
	p_string_url: [
		"KString",
		"Url",
		STR
	],
	p_timestamp: [
		"KTime",
		"Time",
		I64
	],
	p_datetime: [
		"DateTime",
		"",
		STR
	],
	p_object: ["object", ""],
	p_compound: ["Compound", ""],
	p_lcl_translation: [
		"Lcl Translation",
		"",
		F64,
		F64,
		F64
	],
	p_lcl_rotation: [
		"Lcl Rotation",
		"",
		F64,
		F64,
		F64
	],
	p_lcl_scaling: [
		"Lcl Scaling",
		"",
		F64,
		F64,
		F64
	],
	p_visibility: [
		"Visibility",
		"",
		F64
	],
	p_visibility_inheritance: [
		"Visibility Inheritance",
		"",
		I32
	],
	p_roll: [
		"Roll",
		"",
		F64
	],
	p_opticalcenterx: [
		"OpticalCenterX",
		"",
		F64
	],
	p_opticalcentery: [
		"OpticalCenterY",
		"",
		F64
	],
	p_fov: [
		"FieldOfView",
		"",
		F64
	],
	p_fov_x: [
		"FieldOfViewX",
		"",
		F64
	],
	p_fov_y: [
		"FieldOfViewY",
		"",
		F64
	]
};
function flagsStr(animatable, animated, custom) {
	if (animatable) {
		if (animated) return custom ? "A+U" : "A+";
		if (custom) return "A+U";
		return "A";
	}
	if (custom) return "U";
	return "";
}
function writeOneProp(propsElem, ptypeDef, name, value, flags) {
	const p = new FBXElem("P");
	p.addString(name);
	p.addString(ptypeDef[0]);
	p.addString(ptypeDef[1]);
	p.addString(flags);
	const adders = ptypeDef.slice(2);
	if (adders.length === 1) {
		if (ptypeDef[0] === "object") {} else p[adders[0]](value);
	} else if (adders.length > 1) for (let i = 0; i < adders.length; i++) p[adders[i]](value[i]);
	propsElem.addChild(p);
	return p;
}
/** Add a `Properties70` child to `elem` and return it. */
function elemProperties(elem) {
	return elem.addEmpty("Properties70");
}
/**
* Write a single property record into a Properties70 element.
* @param {FBXElem} propsElem - the Properties70 element
* @param {string} ptype      - one of PTYPES keys (e.g. 'p_double')
* @param {string} name       - FBX property name (e.g. 'Lcl Translation')
* @param {*} value           - scalar or [x,y,z]
*/
function elemPropsSet(propsElem, ptype, name, value, { animatable = false, animated = false, custom = false } = {}) {
	const def = PTYPES[ptype];
	if (!def) throw new Error(`Unknown ptype: ${ptype}`);
	writeOneProp(propsElem, def, name, value, flagsStr(animatable, animated, custom));
}
/**
* @typedef {Object} TemplateEntry
* @property {*} value
* @property {string} ptype
* @property {boolean} animatable
*/
/**
* @typedef {Object} TemplateDef
* @property {string} typeName       e.g. 'Model'
* @property {string} propTypeName   e.g. 'FbxNode'
* @property {Record<string, TemplateEntry>} properties
*/
/** Build a per-instance "working copy" of a template's properties. */
function templateInit(templates, typeName) {
	const tmpl = templates && templates.get ? templates.get(typeName) : null;
	if (!tmpl) return {};
	const out = {};
	for (const [name, entry] of Object.entries(tmpl.properties)) out[name] = {
		...entry,
		written: false
	};
	return out;
}
/**
* Write a per-instance P record. three.js FBXLoader reads per-instance
* Properties70 directly without consulting Definitions templates for
* fallback (FBXLoader.js:1346 et al.), so a skipped property that matches
* our template default would silently regress on round-trip (e.g.
* CastShadows=true matching default true → skipped → FBXLoader defaults
* false).
*/
function templateSet(working, propsElem, ptype, name, value, { animatable = false, animated = false } = {}) {
	const def = PTYPES[ptype];
	if (!def) throw new Error(`Unknown ptype: ${ptype}`);
	const tmpl = working[name];
	if (tmpl) {
		writeOneProp(propsElem, def, name, value, flagsStr(tmpl.animatable, animated, false));
		tmpl.written = true;
	} else writeOneProp(propsElem, def, name, value, flagsStr(animatable, animated, false));
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/core/templates.js
/**
* FBX PropertyTemplate default tables.
*
* Each builder returns a "template definition" describing what defaults a given
* FBX object type carries. The Definitions section emits these as
* `ObjectType` → `PropertyTemplate` records; per-instance prop writers consult
* them via `templateSet` to skip values that already match the defaults.
*
* Builder signature: `(settings?, overrides?) -> TemplateDef`
* Each TemplateDef carries a `users` count we'll bump as we attach instances.
*/
var P = (value, ptype, animatable = false) => ({
	value,
	ptype,
	animatable
});
function applyOverrides(props, overrides) {
	if (!overrides) return props;
	return {
		...props,
		...overrides
	};
}
function make(typeName, propTypeName, properties) {
	return {
		typeName,
		propTypeName,
		properties,
		users: 0,
		_written: false
	};
}
function globalSettingsTemplate(settings, overrides) {
	return make("GlobalSettings", "", applyOverrides({}, overrides));
}
function modelTemplate(settings, overrides) {
	return make("Model", "FbxNode", applyOverrides({
		"QuaternionInterpolate": P(0, "p_enum"),
		"RotationOffset": P([
			0,
			0,
			0
		], "p_vector_3d"),
		"RotationPivot": P([
			0,
			0,
			0
		], "p_vector_3d"),
		"ScalingOffset": P([
			0,
			0,
			0
		], "p_vector_3d"),
		"ScalingPivot": P([
			0,
			0,
			0
		], "p_vector_3d"),
		"TranslationActive": P(false, "p_bool"),
		"TranslationMin": P([
			0,
			0,
			0
		], "p_vector_3d"),
		"TranslationMax": P([
			0,
			0,
			0
		], "p_vector_3d"),
		"TranslationMinX": P(false, "p_bool"),
		"TranslationMinY": P(false, "p_bool"),
		"TranslationMinZ": P(false, "p_bool"),
		"TranslationMaxX": P(false, "p_bool"),
		"TranslationMaxY": P(false, "p_bool"),
		"TranslationMaxZ": P(false, "p_bool"),
		"RotationOrder": P(0, "p_enum"),
		"RotationSpaceForLimitOnly": P(false, "p_bool"),
		"RotationStiffnessX": P(0, "p_double"),
		"RotationStiffnessY": P(0, "p_double"),
		"RotationStiffnessZ": P(0, "p_double"),
		"AxisLen": P(10, "p_double"),
		"PreRotation": P([
			0,
			0,
			0
		], "p_vector_3d"),
		"PostRotation": P([
			0,
			0,
			0
		], "p_vector_3d"),
		"RotationActive": P(false, "p_bool"),
		"RotationMin": P([
			0,
			0,
			0
		], "p_vector_3d"),
		"RotationMax": P([
			0,
			0,
			0
		], "p_vector_3d"),
		"RotationMinX": P(false, "p_bool"),
		"RotationMinY": P(false, "p_bool"),
		"RotationMinZ": P(false, "p_bool"),
		"RotationMaxX": P(false, "p_bool"),
		"RotationMaxY": P(false, "p_bool"),
		"RotationMaxZ": P(false, "p_bool"),
		"InheritType": P(0, "p_enum"),
		"ScalingActive": P(false, "p_bool"),
		"ScalingMin": P([
			0,
			0,
			0
		], "p_vector_3d"),
		"ScalingMax": P([
			1,
			1,
			1
		], "p_vector_3d"),
		"ScalingMinX": P(false, "p_bool"),
		"ScalingMinY": P(false, "p_bool"),
		"ScalingMinZ": P(false, "p_bool"),
		"ScalingMaxX": P(false, "p_bool"),
		"ScalingMaxY": P(false, "p_bool"),
		"ScalingMaxZ": P(false, "p_bool"),
		"GeometricTranslation": P([
			0,
			0,
			0
		], "p_vector_3d"),
		"GeometricRotation": P([
			0,
			0,
			0
		], "p_vector_3d"),
		"GeometricScaling": P([
			1,
			1,
			1
		], "p_vector_3d"),
		"MinDampRangeX": P(0, "p_double"),
		"MinDampRangeY": P(0, "p_double"),
		"MinDampRangeZ": P(0, "p_double"),
		"MaxDampRangeX": P(0, "p_double"),
		"MaxDampRangeY": P(0, "p_double"),
		"MaxDampRangeZ": P(0, "p_double"),
		"MinDampStrengthX": P(0, "p_double"),
		"MinDampStrengthY": P(0, "p_double"),
		"MinDampStrengthZ": P(0, "p_double"),
		"MaxDampStrengthX": P(0, "p_double"),
		"MaxDampStrengthY": P(0, "p_double"),
		"MaxDampStrengthZ": P(0, "p_double"),
		"PreferedAngleX": P(0, "p_double"),
		"PreferedAngleY": P(0, "p_double"),
		"PreferedAngleZ": P(0, "p_double"),
		"LookAtProperty": P(null, "p_object"),
		"UpVectorProperty": P(null, "p_object"),
		"Show": P(true, "p_bool"),
		"NegativePercentShapeSupport": P(true, "p_bool"),
		"DefaultAttributeIndex": P(-1, "p_integer"),
		"Freeze": P(false, "p_bool"),
		"LODBox": P(false, "p_bool"),
		"Lcl Translation": P([
			0,
			0,
			0
		], "p_lcl_translation", true),
		"Lcl Rotation": P([
			0,
			0,
			0
		], "p_lcl_rotation", true),
		"Lcl Scaling": P([
			1,
			1,
			1
		], "p_lcl_scaling", true),
		"Visibility": P(1, "p_visibility", true),
		"Visibility Inheritance": P(1, "p_visibility_inheritance")
	}, overrides));
}
function nullTemplate(settings, overrides) {
	return make("NodeAttribute", "FbxNull", applyOverrides({
		"Color": P([
			.8,
			.8,
			.8
		], "p_color_rgb"),
		"Size": P(100, "p_double"),
		"Look": P(1, "p_enum")
	}, overrides));
}
function lightTemplate(settings, overrides) {
	const gscale = settings?.globalScale ?? 1;
	return make("NodeAttribute", "FbxLight", applyOverrides({
		"LightType": P(0, "p_enum"),
		"CastLight": P(true, "p_bool"),
		"Color": P([
			1,
			1,
			1
		], "p_color", true),
		"Intensity": P(100, "p_number", true),
		"Exposure": P(0, "p_number", true),
		"DecayType": P(2, "p_enum"),
		"DecayStart": P(30 * gscale, "p_double"),
		"CastShadows": P(true, "p_bool"),
		"ShadowColor": P([
			0,
			0,
			0
		], "p_color", true),
		"AreaLightShape": P(0, "p_enum")
	}, overrides));
}
function cameraTemplate(settings, overrides) {
	return make("NodeAttribute", "FbxCamera", applyOverrides({
		"Color": P([
			.8,
			.8,
			.8
		], "p_color_rgb"),
		"Position": P([
			0,
			0,
			-50
		], "p_vector", true),
		"UpVector": P([
			0,
			1,
			0
		], "p_vector", true),
		"InterestPosition": P([
			0,
			0,
			0
		], "p_vector", true),
		"Roll": P(0, "p_roll", true),
		"OpticalCenterX": P(0, "p_opticalcenterx", true),
		"OpticalCenterY": P(0, "p_opticalcentery", true),
		"BackgroundColor": P([
			.63,
			.63,
			.63
		], "p_color", true),
		"TurnTable": P(0, "p_number", true),
		"DisplayTurnTableIcon": P(false, "p_bool"),
		"UseMotionBlur": P(false, "p_bool"),
		"UseRealTimeMotionBlur": P(true, "p_bool"),
		"Motion Blur Intensity": P(1, "p_number", true),
		"AspectRatioMode": P(0, "p_enum"),
		"AspectWidth": P(320, "p_double"),
		"AspectHeight": P(200, "p_double"),
		"PixelAspectRatio": P(1, "p_double"),
		"FilmOffsetX": P(0, "p_number", true),
		"FilmOffsetY": P(0, "p_number", true),
		"FilmWidth": P(.816, "p_double"),
		"FilmHeight": P(.612, "p_double"),
		"FilmAspectRatio": P(1.3333333333333333, "p_double"),
		"FilmSqueezeRatio": P(1, "p_double"),
		"FilmFormatIndex": P(0, "p_enum"),
		"PreScale": P(1, "p_number", true),
		"FilmTranslateX": P(0, "p_number", true),
		"FilmTranslateY": P(0, "p_number", true),
		"FilmRollPivotX": P(0, "p_number", true),
		"FilmRollPivotY": P(0, "p_number", true),
		"FilmRollValue": P(0, "p_number", true),
		"FilmRollOrder": P(0, "p_enum"),
		"ApertureMode": P(2, "p_enum"),
		"GateFit": P(0, "p_enum"),
		"FieldOfView": P(25.114999771118164, "p_fov", true),
		"FieldOfViewX": P(40, "p_fov_x", true),
		"FieldOfViewY": P(40, "p_fov_y", true),
		"FocalLength": P(34.89327621672628, "p_number", true),
		"CameraFormat": P(0, "p_enum"),
		"UseFrameColor": P(false, "p_bool"),
		"FrameColor": P([
			.3,
			.3,
			.3
		], "p_color_rgb"),
		"ShowName": P(true, "p_bool"),
		"ShowInfoOnMoving": P(true, "p_bool"),
		"ShowGrid": P(true, "p_bool"),
		"ShowOpticalCenter": P(false, "p_bool"),
		"ShowAzimut": P(true, "p_bool"),
		"ShowTimeCode": P(false, "p_bool"),
		"ShowAudio": P(false, "p_bool"),
		"AudioColor": P([
			0,
			1,
			0
		], "p_vector_3d"),
		"NearPlane": P(10, "p_double"),
		"FarPlane": P(4e3, "p_double"),
		"AutoComputeClipPanes": P(false, "p_bool"),
		"ViewCameraToLookAt": P(true, "p_bool"),
		"ViewFrustumNearFarPlane": P(false, "p_bool"),
		"ViewFrustumBackPlaneMode": P(2, "p_enum"),
		"BackPlaneDistance": P(4e3, "p_number", true),
		"BackPlaneDistanceMode": P(1, "p_enum"),
		"ViewFrustumFrontPlaneMode": P(2, "p_enum"),
		"FrontPlaneDistance": P(10, "p_number", true),
		"FrontPlaneDistanceMode": P(1, "p_enum"),
		"LockMode": P(false, "p_bool"),
		"LockInterestNavigation": P(false, "p_bool"),
		"FitImage": P(false, "p_bool"),
		"Crop": P(false, "p_bool"),
		"Center": P(true, "p_bool"),
		"KeepRatio": P(true, "p_bool"),
		"BackgroundAlphaTreshold": P(.5, "p_double"),
		"ShowBackplate": P(true, "p_bool"),
		"BackPlaneOffsetX": P(0, "p_number", true),
		"BackPlaneOffsetY": P(0, "p_number", true),
		"BackPlaneRotation": P(0, "p_number", true),
		"BackPlaneScaleX": P(1, "p_number", true),
		"BackPlaneScaleY": P(1, "p_number", true),
		"Background Texture": P(null, "p_object"),
		"FrontPlateFitImage": P(true, "p_bool"),
		"FrontPlateCrop": P(false, "p_bool"),
		"FrontPlateCenter": P(true, "p_bool"),
		"FrontPlateKeepRatio": P(true, "p_bool"),
		"Foreground Opacity": P(1, "p_double"),
		"ShowFrontplate": P(true, "p_bool"),
		"FrontPlaneOffsetX": P(0, "p_number", true),
		"FrontPlaneOffsetY": P(0, "p_number", true),
		"FrontPlaneRotation": P(0, "p_number", true),
		"FrontPlaneScaleX": P(1, "p_number", true),
		"FrontPlaneScaleY": P(1, "p_number", true),
		"Foreground Texture": P(null, "p_object"),
		"DisplaySafeArea": P(false, "p_bool"),
		"DisplaySafeAreaOnRender": P(false, "p_bool"),
		"SafeAreaDisplayStyle": P(1, "p_enum"),
		"SafeAreaAspectRatio": P(1.3333333333333333, "p_double"),
		"Use2DMagnifierZoom": P(false, "p_bool"),
		"2D Magnifier Zoom": P(100, "p_number", true),
		"2D Magnifier X": P(50, "p_number", true),
		"2D Magnifier Y": P(50, "p_number", true),
		"CameraProjectionType": P(0, "p_enum"),
		"OrthoZoom": P(1, "p_double"),
		"UseRealTimeDOFAndAA": P(false, "p_bool"),
		"UseDepthOfField": P(false, "p_bool"),
		"FocusSource": P(0, "p_enum"),
		"FocusAngle": P(3.5, "p_double"),
		"FocusDistance": P(200, "p_double"),
		"UseAntialiasing": P(false, "p_bool"),
		"AntialiasingIntensity": P(.77777, "p_double"),
		"AntialiasingMethod": P(0, "p_enum"),
		"UseAccumulationBuffer": P(false, "p_bool"),
		"FrameSamplingCount": P(7, "p_integer"),
		"FrameSamplingType": P(1, "p_enum")
	}, overrides));
}
function boneTemplate(settings, overrides) {
	return make("NodeAttribute", "LimbNode", applyOverrides({}, overrides));
}
function geometryTemplate(settings, overrides) {
	return make("Geometry", "FbxMesh", applyOverrides({
		"Color": P([
			.8,
			.8,
			.8
		], "p_color_rgb"),
		"BBoxMin": P([
			0,
			0,
			0
		], "p_vector_3d"),
		"BBoxMax": P([
			0,
			0,
			0
		], "p_vector_3d"),
		"Primary Visibility": P(true, "p_bool"),
		"Casts Shadows": P(true, "p_bool"),
		"Receive Shadows": P(true, "p_bool")
	}, overrides));
}
function materialTemplate(settings, overrides) {
	return make("Material", "FbxSurfacePhong", applyOverrides({
		"ShadingModel": P("Phong", "p_string"),
		"MultiLayer": P(false, "p_bool"),
		"EmissiveColor": P([
			0,
			0,
			0
		], "p_color", true),
		"EmissiveFactor": P(1, "p_number", true),
		"AmbientColor": P([
			.2,
			.2,
			.2
		], "p_color", true),
		"AmbientFactor": P(1, "p_number", true),
		"DiffuseColor": P([
			.8,
			.8,
			.8
		], "p_color", true),
		"DiffuseFactor": P(1, "p_number", true),
		"TransparentColor": P([
			0,
			0,
			0
		], "p_color", true),
		"TransparencyFactor": P(0, "p_number", true),
		"Opacity": P(1, "p_number", true),
		"NormalMap": P([
			0,
			0,
			0
		], "p_vector_3d"),
		"Bump": P([
			0,
			0,
			0
		], "p_vector_3d"),
		"BumpFactor": P(1, "p_double"),
		"DisplacementColor": P([
			0,
			0,
			0
		], "p_color_rgb"),
		"DisplacementFactor": P(1, "p_double"),
		"VectorDisplacementColor": P([
			0,
			0,
			0
		], "p_color_rgb"),
		"VectorDisplacementFactor": P(1, "p_double"),
		"SpecularColor": P([
			.2,
			.2,
			.2
		], "p_color", true),
		"SpecularFactor": P(1, "p_number", true),
		"Shininess": P(20, "p_number", true),
		"ShininessExponent": P(20, "p_number", true),
		"ReflectionColor": P([
			0,
			0,
			0
		], "p_color", true),
		"ReflectionFactor": P(1, "p_number", true)
	}, overrides));
}
function textureTemplate(settings, overrides) {
	return make("Texture", "FbxFileTexture", applyOverrides({
		"TextureTypeUse": P(0, "p_enum"),
		"AlphaSource": P(2, "p_enum"),
		"Texture alpha": P(1, "p_double"),
		"PremultiplyAlpha": P(true, "p_bool"),
		"CurrentTextureBlendMode": P(1, "p_enum"),
		"CurrentMappingType": P(0, "p_enum"),
		"UVSet": P("default", "p_string"),
		"WrapModeU": P(0, "p_enum"),
		"WrapModeV": P(0, "p_enum"),
		"UVSwap": P(false, "p_bool"),
		"Translation": P([
			0,
			0,
			0
		], "p_vector_3d"),
		"Rotation": P([
			0,
			0,
			0
		], "p_vector_3d"),
		"Scaling": P([
			1,
			1,
			1
		], "p_vector_3d"),
		"TextureRotationPivot": P([
			0,
			0,
			0
		], "p_vector_3d"),
		"TextureScalingPivot": P([
			0,
			0,
			0
		], "p_vector_3d"),
		"UseMaterial": P(false, "p_bool"),
		"UseMipMap": P(false, "p_bool")
	}, overrides));
}
function videoTemplate(settings, overrides) {
	return make("Video", "FbxVideo", applyOverrides({
		"Width": P(0, "p_integer"),
		"Height": P(0, "p_integer"),
		"Path": P("", "p_string_url"),
		"AccessMode": P(0, "p_enum"),
		"StartFrame": P(0, "p_integer"),
		"StopFrame": P(0, "p_integer"),
		"Offset": P(0, "p_timestamp"),
		"PlaySpeed": P(0, "p_double"),
		"FreeRunning": P(false, "p_bool"),
		"Loop": P(false, "p_bool"),
		"InterlaceMode": P(0, "p_enum"),
		"ImageSequence": P(false, "p_bool"),
		"ImageSequenceOffset": P(0, "p_integer"),
		"FrameRate": P(0, "p_double"),
		"LastFrame": P(0, "p_integer")
	}, overrides));
}
function poseTemplate(settings, overrides) {
	return make("Pose", "", applyOverrides({}, overrides));
}
function deformerTemplate(settings, overrides) {
	return make("Deformer", "", applyOverrides({}, overrides));
}
function animStackTemplate(settings, overrides) {
	return make("AnimationStack", "FbxAnimStack", applyOverrides({
		"Description": P("", "p_string"),
		"LocalStart": P(0, "p_timestamp"),
		"LocalStop": P(0, "p_timestamp"),
		"ReferenceStart": P(0, "p_timestamp"),
		"ReferenceStop": P(0, "p_timestamp")
	}, overrides));
}
function animLayerTemplate(settings, overrides) {
	return make("AnimationLayer", "FbxAnimLayer", applyOverrides({
		"Weight": P(100, "p_number", true),
		"Mute": P(false, "p_bool"),
		"Solo": P(false, "p_bool"),
		"Lock": P(false, "p_bool"),
		"Color": P([
			.8,
			.8,
			.8
		], "p_color_rgb"),
		"BlendMode": P(0, "p_enum"),
		"RotationAccumulationMode": P(0, "p_enum"),
		"ScaleAccumulationMode": P(0, "p_enum"),
		"BlendModeBypass": P(0, "p_ulonglong")
	}, overrides));
}
function animCurveNodeTemplate(settings, overrides) {
	return make("AnimationCurveNode", "FbxAnimCurveNode", applyOverrides({ "d": P(null, "p_compound") }, overrides));
}
function animCurveTemplate(settings, overrides) {
	return make("AnimationCurve", "", applyOverrides({}, overrides));
}
/**
* Bundle all templates a scene might need into a Map keyed by typeName,
* preserving grouping behaviour: when multiple subtypes share a
* typeName (NodeAttribute = Null/Light/Camera/LimbNode), the one with the most
* users wins template selection.
*/
var TemplateBundle = class {
	_byType;
	_byKey;
	constructor() {
		this._byType = /* @__PURE__ */ new Map();
		this._byKey = /* @__PURE__ */ new Map();
	}
	/**
	* Register a template. If one with the same (typeName, propTypeName) already
	* exists, that one is returned (so its `.users` can be incremented).
	*/
	register(template) {
		const k = `${template.typeName}|${template.propTypeName}`;
		const existing = this._byKey.get(k);
		if (existing) return existing;
		this._byKey.set(k, template);
		const arr = this._byType.get(template.typeName) ?? [];
		arr.push(template);
		this._byType.set(template.typeName, arr);
		return template;
	}
	/**
	* For each typeName, pick the dominant subtype's properties.
	* Returns a Map<typeName, { totalUsers, dominant: template }> so the
	* Definitions builder knows what to emit.
	*/
	resolved() {
		const out = /* @__PURE__ */ new Map();
		for (const [typeName, arr] of this._byType) {
			let total = 0;
			let dominant = arr[0];
			let bestUsers = -1;
			let bestPropCount = -1;
			for (const t of arr) {
				total += t.users;
				const propCount = Object.keys(t.properties).length;
				if (t.users > bestUsers || t.users === bestUsers && propCount > bestPropCount) {
					bestUsers = t.users;
					bestPropCount = propCount;
					dominant = t;
				}
			}
			out.set(typeName, {
				totalUsers: total,
				dominant
			});
		}
		return out;
	}
	/** Look up the per-type dominant template, used by per-instance property writers. */
	get(typeName) {
		const arr = this._byType.get(typeName);
		if (!arr || arr.length === 0) return null;
		let dominant = arr[0];
		let bestUsers = -1;
		let bestPropCount = -1;
		for (const t of arr) {
			const propCount = Object.keys(t.properties).length;
			if (t.users > bestUsers || t.users === bestUsers && propCount > bestPropCount) {
				bestUsers = t.users;
				bestPropCount = propCount;
				dominant = t;
			}
		}
		return dominant;
	}
	/** Sum of all per-template users — fills `Definitions/Count`. */
	totalUsers() {
		let n = 0;
		for (const t of this._byKey.values()) n += t.users;
		return n;
	}
};
var FBX_HEADER_VERSION = 1003;
var FBX_ANIM_KEY_VERSION = 4008;
var FBX_KTIME = 46186158000n;
/**
* Axis-pair → (UpAxis, FrontAxis, CoordAxis) encoding used in GlobalSettings.
* Each entry is `[axis, sign]`; axis is 0=X, 1=Y, 2=Z. Right-handed only.
* Mirrors fbx_utils.py: RIGHT_HAND_AXES.
*/
var RIGHT_HAND_AXES = {
	"X|-Y": {
		up: [0, 1],
		front: [1, 1],
		coord: [2, 1]
	},
	"X|Y": {
		up: [0, 1],
		front: [1, -1],
		coord: [2, -1]
	},
	"X|-Z": {
		up: [0, 1],
		front: [2, 1],
		coord: [1, -1]
	},
	"X|Z": {
		up: [0, 1],
		front: [2, -1],
		coord: [1, 1]
	},
	"-X|-Y": {
		up: [0, -1],
		front: [1, 1],
		coord: [2, -1]
	},
	"-X|Y": {
		up: [0, -1],
		front: [1, -1],
		coord: [2, 1]
	},
	"-X|-Z": {
		up: [0, -1],
		front: [2, 1],
		coord: [1, 1]
	},
	"-X|Z": {
		up: [0, -1],
		front: [2, -1],
		coord: [1, -1]
	},
	"Y|-X": {
		up: [1, 1],
		front: [0, 1],
		coord: [2, -1]
	},
	"Y|X": {
		up: [1, 1],
		front: [0, -1],
		coord: [2, 1]
	},
	"Y|-Z": {
		up: [1, 1],
		front: [2, 1],
		coord: [0, 1]
	},
	"Y|Z": {
		up: [1, 1],
		front: [2, -1],
		coord: [0, -1]
	},
	"-Y|-X": {
		up: [1, -1],
		front: [0, 1],
		coord: [2, 1]
	},
	"-Y|X": {
		up: [1, -1],
		front: [0, -1],
		coord: [2, -1]
	},
	"-Y|-Z": {
		up: [1, -1],
		front: [2, 1],
		coord: [0, -1]
	},
	"-Y|Z": {
		up: [1, -1],
		front: [2, -1],
		coord: [0, 1]
	},
	"Z|-X": {
		up: [2, 1],
		front: [0, 1],
		coord: [1, 1]
	},
	"Z|X": {
		up: [2, 1],
		front: [0, -1],
		coord: [1, -1]
	},
	"Z|-Y": {
		up: [2, 1],
		front: [1, 1],
		coord: [0, -1]
	},
	"Z|Y": {
		up: [2, 1],
		front: [1, -1],
		coord: [0, 1]
	},
	"-Z|-X": {
		up: [2, -1],
		front: [0, 1],
		coord: [1, -1]
	},
	"-Z|X": {
		up: [2, -1],
		front: [0, -1],
		coord: [1, 1]
	},
	"-Z|-Y": {
		up: [2, -1],
		front: [1, 1],
		coord: [0, 1]
	},
	"-Z|Y": {
		up: [2, -1],
		front: [1, -1],
		coord: [0, -1]
	}
};
/** FBX TimeMode enum values keyed by an approximate framerate. */
var FBX_FRAMERATES = [
	{
		fps: -1,
		mode: 14
	},
	{
		fps: 120,
		mode: 1
	},
	{
		fps: 100,
		mode: 2
	},
	{
		fps: 60,
		mode: 3
	},
	{
		fps: 50,
		mode: 4
	},
	{
		fps: 48,
		mode: 5
	},
	{
		fps: 30,
		mode: 6
	},
	{
		fps: 30 / 1.001,
		mode: 9
	},
	{
		fps: 25,
		mode: 10
	},
	{
		fps: 24,
		mode: 11
	},
	{
		fps: 24 / 1.001,
		mode: 13
	},
	{
		fps: 96,
		mode: 15
	},
	{
		fps: 72,
		mode: 16
	},
	{
		fps: 60 / 1.001,
		mode: 17
	}
];
var APP_VENDOR = "Comfy Org";
var APP_NAME = "@comfyorg/fbx-exporter-three";
var APP_VERSION = "1.0.0";
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/builders/header.js
/**
* Emit FBXHeaderExtension, FileId, CreationTime, Creator, GlobalSettings,
* Documents and References.
*/
function creatorString(settings) {
	if (settings && typeof settings.creator === "string" && settings.creator) return settings.creator;
	return `${APP_NAME} - ${APP_VERSION}`;
}
function fpsToMode(fps) {
	for (const entry of FBX_FRAMERATES) if (entry.fps > 0 && Math.abs(entry.fps - fps) < 1e-4) return entry.mode;
	return 14;
}
/**
* @param {object} ctx
* @param {object} ctx.root        FBXElem root container
* @param {object} ctx.settings    user options
* @param {string} ctx.sceneName   scene name (becomes the FBX Document name)
* @param {object} ctx.uidRegistry UidRegistry for document UID allocation
*/
function writeHeaderSection({ root, settings, sceneName = "Scene" }) {
	const headerExt = elemEmpty(root, "FBXHeaderExtension");
	elemDataSingleInt32(headerExt, "FBXHeaderVersion", FBX_HEADER_VERSION);
	elemDataSingleInt32(headerExt, "FBXVersion", settings.version ?? 7400);
	elemDataSingleInt32(headerExt, "EncryptionType", 0);
	const ts = elemEmpty(headerExt, "CreationTimeStamp");
	elemDataSingleInt32(ts, "Version", 1e3);
	elemDataSingleInt32(ts, "Year", 1970);
	elemDataSingleInt32(ts, "Month", 1);
	elemDataSingleInt32(ts, "Day", 1);
	elemDataSingleInt32(ts, "Hour", 0);
	elemDataSingleInt32(ts, "Minute", 0);
	elemDataSingleInt32(ts, "Second", 0);
	elemDataSingleInt32(ts, "Millisecond", 0);
	elemDataSingleString(headerExt, "Creator", creatorString(settings));
	const sceneInfo = elemDataSingleString(headerExt, "SceneInfo", fbxNameClass("GlobalInfo", "SceneInfo"));
	sceneInfo.addString("UserData");
	elemDataSingleString(sceneInfo, "Type", "UserData");
	elemDataSingleInt32(sceneInfo, "Version", 100);
	const meta = elemEmpty(sceneInfo, "MetaData");
	elemDataSingleInt32(meta, "Version", 100);
	for (const k of [
		"Title",
		"Subject",
		"Author",
		"Keywords",
		"Revision",
		"Comment"
	]) elemDataSingleString(meta, k, "");
	const sceneProps = elemProperties(sceneInfo);
	elemPropsSet(sceneProps, "p_string_url", "DocumentUrl", "/foobar.fbx");
	elemPropsSet(sceneProps, "p_string_url", "SrcDocumentUrl", "/foobar.fbx");
	for (const group of ["Original", "LastSaved"]) {
		elemPropsSet(sceneProps, "p_compound", group);
		elemPropsSet(sceneProps, "p_string", `${group}|ApplicationVendor`, APP_VENDOR);
		elemPropsSet(sceneProps, "p_string", `${group}|ApplicationName`, APP_NAME);
		elemPropsSet(sceneProps, "p_string", `${group}|ApplicationVersion`, APP_VERSION);
		elemPropsSet(sceneProps, "p_datetime", `${group}|DateTime_GMT`, "01/01/1970 00:00:00.000");
	}
	elemDataSingleBytes(root, "FileId", /* @__PURE__ */ new Uint8Array(16));
	elemDataSingleString(root, "CreationTime", "1970-01-01 10:00:00:000");
	elemDataSingleString(root, "Creator", creatorString(settings));
	writeGlobalSettings(root, settings);
	writeDocuments(root, sceneName);
	elemEmpty(root, "References");
}
function writeGlobalSettings(root, settings) {
	const gs = elemEmpty(root, "GlobalSettings");
	elemDataSingleInt32(gs, "Version", 1e3);
	const axes = RIGHT_HAND_AXES[`${settings.axisUp ?? "Y"}|${settings.axisForward ?? "Z"}`] ?? RIGHT_HAND_AXES["Y|Z"];
	const unitScale = settings.unitScale ?? 1;
	const fps = settings.fps ?? 24;
	const props = elemProperties(gs);
	elemPropsSet(props, "p_integer", "UpAxis", axes.up[0]);
	elemPropsSet(props, "p_integer", "UpAxisSign", axes.up[1]);
	elemPropsSet(props, "p_integer", "FrontAxis", axes.front[0]);
	elemPropsSet(props, "p_integer", "FrontAxisSign", axes.front[1]);
	elemPropsSet(props, "p_integer", "CoordAxis", axes.coord[0]);
	elemPropsSet(props, "p_integer", "CoordAxisSign", axes.coord[1]);
	elemPropsSet(props, "p_integer", "OriginalUpAxis", -1);
	elemPropsSet(props, "p_integer", "OriginalUpAxisSign", 1);
	elemPropsSet(props, "p_double", "UnitScaleFactor", unitScale);
	elemPropsSet(props, "p_double", "OriginalUnitScaleFactor", unitScale);
	elemPropsSet(props, "p_color_rgb", "AmbientColor", [
		0,
		0,
		0
	]);
	elemPropsSet(props, "p_string", "DefaultCamera", "Producer Perspective");
	elemPropsSet(props, "p_enum", "TimeMode", fpsToMode(fps));
	elemPropsSet(props, "p_timestamp", "TimeSpanStart", 0n);
	elemPropsSet(props, "p_timestamp", "TimeSpanStop", FBX_KTIME);
	elemPropsSet(props, "p_double", "CustomFrameRate", fps);
}
function writeDocuments(root, sceneName) {
	const docs = elemEmpty(root, "Documents");
	elemDataSingleInt32(docs, "Count", 1);
	const doc = elemDataSingleInt64(docs, "Document", simpleHashI64(documentKey(sceneName)));
	doc.addString(sceneName);
	doc.addString(sceneName);
	const props = elemProperties(doc);
	elemPropsSet(props, "p_object", "SourceObject");
	elemPropsSet(props, "p_string", "ActiveAnimStackName", "");
	elemDataSingleInt64(doc, "RootNode", 0n);
}
function simpleHashI64(s) {
	let h = 14695981039346656037n;
	const prime = 1099511628211n;
	for (let i = 0; i < s.length; i++) {
		h ^= BigInt(s.charCodeAt(i));
		h = h * prime & 18446744073709551615n;
	}
	return h & (1n << 63n) - 1n;
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/builders/definitions.js
/**
* Emit the `Definitions` section: one `ObjectType` per scene-used type, each
* carrying a `PropertyTemplate` with that type's default property values.
*
* Mirrors `export_fbx_bin.py: fbx_definitions_elements` +
* `fbx_utils.py: fbx_templates_generate`.
*/
/**
* @param {object} ctx
* @param {object} ctx.root
* @param {import('../core/templates.js').TemplateBundle} ctx.templates
*/
function writeDefinitionsSection({ root, templates }) {
	const defs = elemEmpty(root, "Definitions");
	elemDataSingleInt32(defs, "Version", 100);
	elemDataSingleInt32(defs, "Count", templates.totalUsers());
	for (const [typeName, { totalUsers, dominant }] of templates.resolved()) {
		const objType = elemDataSingleString(defs, "ObjectType", typeName);
		elemDataSingleInt32(objType, "Count", totalUsers);
		dominant._written = true;
		if (!dominant.propTypeName || Object.keys(dominant.properties).length === 0) continue;
		const props = elemProperties(elemDataSingleString(objType, "PropertyTemplate", dominant.propTypeName));
		for (const [name, entry] of Object.entries(dominant.properties)) try {
			elemPropsSet(props, entry.ptype, name, entry.value, { animatable: entry.animatable });
		} catch (err) {
			console.warn(`Failed to write template prop ${typeName}.${name}: ${err.message}`);
		}
	}
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/builders/connections.js
/**
* Emit the `Connections` section.
*/
/**
* @param {object} ctx
* @param {FBXElem} ctx.root
* @param {Array<[string, bigint, bigint, string?]>} ctx.connections
*/
function writeConnectionsSection({ root, connections }) {
	const conns = elemEmpty(root, "Connections");
	if (connections.length === 0) {
		const stub = conns.addEmpty("C");
		stub.addString("OO");
		stub.addInt64(0n);
		stub.addInt64(0n);
		return;
	}
	for (const [cType, src, dst, propName] of connections) {
		const c = conns.addEmpty("C");
		c.addString(cType);
		c.addInt64(src);
		c.addInt64(dst);
		if (propName != null) c.addString(propName);
	}
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/data/transforms.js
/**
* Coordinate space / unit scaling helpers.
*
* Two responsibilities:
*
*  1. Resolve a `preset` (`'unity' | 'unreal' | 'blender' | 'maya' | 'threejs'`)
*     into concrete `axisUp` / `axisForward` / `unitScale` /
*     `bakeSpaceTransform` settings. Three.js itself uses Y-up + Z-forward
*     (same as Blender / Maya / Unity defaults). Only Unreal needs a different
*     axis convention (Z-up, X-forward).
*
*  2. Compute the `globalMatrix` that maps three.js coordinates to the
*     target axis convention, plus its inverse-transposed companion for
*     normal vectors.
*
* When `bakeSpaceTransform: true`, the matrix is applied to vertex positions
* + normals during geometry export. Object transforms keep
* their original local TRS — only the geometry data shifts.
*
* When `bakeSpaceTransform: false`, the FBX file's GlobalSettings UpAxis /
* FrontAxis / CoordAxis fields tell importers how to re-orient; vertices
* stay in three.js's coordinate space. This is the lighter-touch option but
* less portable (some importers ignore the axis fields).
*/
/**
* Tool-specific export presets. Picks the right axis conventions for
* common targets so users don't memorise the FBX encoding.
*
* - threejs: identity output (Y-up Z-forward, meters). Matches three.js
*   FBXLoader's expectations for clean round-trip.
* - unity:   same as threejs (Unity defaults to Y-up Z-forward and the
*   FBX importer respects file axes).
* - unreal:  Z-up + X-forward (Unreal's native convention). bake disabled
*   so the file declares axes in GlobalSettings and Unreal's own importer
*   handles the rotation. See "About bakeSpaceTransform" below.
* - blender: Y-up Z-forward. unitScale=100 because Blender stores meters
*   but the FBX spec expects centimeters as the canonical unit.
* - maya:    same as blender.
*
* Each preset is the DEFAULT; user-provided `axisUp` / `axisForward` /
* `unitScale` / `bakeSpaceTransform` in options override the preset.
*
* About bakeSpaceTransform — known limitations:
*   When bake=true, ONLY Vertices and Normals are pre-multiplied by
*   globalMatrix. Object Lcl transforms, Cluster matrices, animation
*   curves, and light/camera transforms are NOT baked. This means bake=true
*   produces an internally INCONSISTENT file for any scene with non-
*   origin object placement, skinning, animation, or lights/cameras.
*
*   For most workflows, leave bake=false: the FBX file declares its axes
*   in GlobalSettings.UpAxis/FrontAxis/CoordAxis and modern importers
*   (Unity, Unreal, Blender, Maya) respect them. The flag is kept as an
*   opt-in for the narrow "single mesh, no transforms" Unreal asset case.
*/
var PRESETS = {
	threejs: {
		axisUp: "Y",
		axisForward: "Z",
		unitScale: 1,
		bakeSpaceTransform: false
	},
	unity: {
		axisUp: "Y",
		axisForward: "Z",
		unitScale: 1,
		bakeSpaceTransform: false
	},
	unreal: {
		axisUp: "Z",
		axisForward: "X",
		unitScale: 1,
		bakeSpaceTransform: false
	},
	blender: {
		axisUp: "Y",
		axisForward: "Z",
		unitScale: 100,
		bakeSpaceTransform: false
	},
	maya: {
		axisUp: "Y",
		axisForward: "Z",
		unitScale: 100,
		bakeSpaceTransform: false
	}
};
/**
* Apply a preset's defaults to a settings object. Explicit option values
* always win over the preset; absent (undefined) keys fall through to the
* preset value.
*
* If no `preset` is named, the 'threejs' preset is used as the fallback so
* unset axis/unit keys land on sane Y-up Z-forward / scale=1 defaults.
*/
function resolvePreset(settings) {
	settings = settings || {};
	const presetName = settings.preset || "threejs";
	const preset = PRESETS[presetName];
	if (!preset) {
		console.warn(`fbx-exporter-three: unknown preset "${presetName}" — using as-is`);
		return { ...settings };
	}
	const merged = { ...preset };
	for (const k of Object.keys(settings)) if (settings[k] !== void 0) merged[k] = settings[k];
	return merged;
}
var AXIS_VECS = {
	"X": [
		1,
		0,
		0
	],
	"-X": [
		-1,
		0,
		0
	],
	"Y": [
		0,
		1,
		0
	],
	"-Y": [
		0,
		-1,
		0
	],
	"Z": [
		0,
		0,
		1
	],
	"-Z": [
		0,
		0,
		-1
	]
};
/**
* Build a rotation matrix that maps three.js's (Y-up, -Z-forward) axes to
* the FBX file's chosen (axisUp, axisForward) axes.
*/
function buildAxisMatrix(axisUp, axisForward) {
	const up = AXIS_VECS[axisUp];
	const fwd = AXIS_VECS[axisForward];
	if (!up || !fwd) throw new Error(`buildAxisMatrix: invalid axes axisUp=${axisUp} axisForward=${axisForward}`);
	const right = [
		up[1] * fwd[2] - up[2] * fwd[1],
		up[2] * fwd[0] - up[0] * fwd[2],
		up[0] * fwd[1] - up[1] * fwd[0]
	];
	const m = new Matrix4();
	m.set(right[0], up[0], fwd[0], 0, right[1], up[1], fwd[1], 0, right[2], up[2], fwd[2], 0, 0, 0, 0, 1);
	return m;
}
/**
* Resolve a settings bag into a full `transformContext`:
*   - `globalMatrix`: axis + scale matrix to apply if bakeSpaceTransform
*   - `globalMatrixInvTransposed`: for normals (translation stripped + normalized)
*   - `bake`: whether vertex/normal data should be pre-multiplied
*   - `unitScale`: the resolved UnitScaleFactor to write into GlobalSettings
*/
function buildTransformContext(settings) {
	const axisUp = settings.axisUp ?? "Y";
	const axisForward = settings.axisForward ?? "Z";
	const unitScale = settings.unitScale ?? 1;
	const bake = settings.bakeSpaceTransform === true;
	const globalMatrix = buildAxisMatrix(axisUp, axisForward);
	if (bake && unitScale !== 1) {
		const scaled = new Matrix4().makeScale(unitScale, unitScale, unitScale);
		globalMatrix.premultiply(scaled);
	}
	const invT = transposeMatrix4(new Matrix4().copy(globalMatrix).invert());
	invT.elements[12] = invT.elements[13] = invT.elements[14] = 0;
	return {
		axisUp,
		axisForward,
		unitScale,
		bake,
		globalMatrix,
		globalMatrixInvTransposed: invT,
		isIdentity: bake ? matrixIsIdentity(globalMatrix) : true
	};
}
function transposeMatrix4(m) {
	const e = m.elements;
	const t = new Matrix4();
	t.set(e[0], e[1], e[2], e[3], e[4], e[5], e[6], e[7], e[8], e[9], e[10], e[11], e[12], e[13], e[14], e[15]);
	return t;
}
function matrixIsIdentity(m) {
	const e = m.elements;
	for (let i = 0; i < 16; i++) {
		const expected = i === 0 || i === 5 || i === 10 || i === 15 ? 1 : 0;
		if (Math.abs(e[i] - expected) > 1e-9) return false;
	}
	return true;
}
/**
* In-place apply a Matrix4 (rotation + uniform/non-uniform scale) to a
* flat XYZ Float64 vertex buffer. Matrix is column-major Matrix4.elements.
*/
function bakeVertices(verts, matrix) {
	const e = matrix.elements;
	for (let i = 0; i < verts.length; i += 3) {
		const x = verts[i];
		const y = verts[i + 1];
		const z = verts[i + 2];
		verts[i] = e[0] * x + e[4] * y + e[8] * z + e[12];
		verts[i + 1] = e[1] * x + e[5] * y + e[9] * z + e[13];
		verts[i + 2] = e[2] * x + e[6] * y + e[10] * z + e[14];
	}
}
/**
* In-place apply a Matrix4's rotation (3x3 upper-left) to a flat XYZ Float64
* normal buffer. Caller passes the INVERSE-TRANSPOSED matrix (build via
* buildTransformContext). Optionally normalises if the source matrix had
* scale.
*/
function bakeNormals(normals, invTransposed) {
	const e = invTransposed.elements;
	for (let i = 0; i < normals.length; i += 3) {
		const x = normals[i];
		const y = normals[i + 1];
		const z = normals[i + 2];
		let nx = e[0] * x + e[4] * y + e[8] * z;
		let ny = e[1] * x + e[5] * y + e[9] * z;
		let nz = e[2] * x + e[6] * y + e[10] * z;
		const len = Math.hypot(nx, ny, nz);
		if (len > 1e-12) {
			nx /= len;
			ny /= len;
			nz /= len;
		}
		normals[i] = nx;
		normals[i + 1] = ny;
		normals[i + 2] = nz;
	}
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/builders/objects/geometry.js
/**
* BufferGeometry → FBX `Geometry` node.
*
* Specialised for three.js geometry, which:
*   - is always tessellated as triangles (no n-gons),
*   - stores attributes in flat typed arrays,
*   - optionally has an index buffer; without one, position is per-vertex
*     in draw order.
*
* The output layout matches three.js FBXLoader (genGeometry / parseGeoNode):
*   - Vertices            float64[]
*   - PolygonVertexIndex  int32[]  (every 3rd index XOR -1 → face terminator)
*   - Edges               int32[]  (loop indices, empty for our case is fine)
*   - GeometryVersion     124
*   - LayerElementNormal     ByPolygonVertex / IndexToDirect
*   - LayerElementUV[]       ByPolygonVertex / IndexToDirect (uv, uv1, uv2, uv3)
*   - LayerElementColor      ByPolygonVertex / IndexToDirect
*   - LayerElementMaterial   AllSame / IndexToDirect (single material) or
*                            ByPolygon / IndexToDirect (multi-material via groups)
*   - Layer                  TOC referencing the elements above
*/
/**
* Read a vertex attribute as a flat Float32Array of length `count * itemSize`.
*
* Three paths:
*   - Plain BufferAttribute with `normalized === false` → fastest, `.array`
*     is usable directly (we still return it without copying for read-only
*     downstream consumers; callers copy to Float64 before mutating).
*   - Plain BufferAttribute with `normalized === true` (e.g. Uint8 vertex
*     colors packed 0..255) → use `getX/Y/Z/W` which applies the proper
*     denormalize (BufferAttribute.js:389-405, math/MathUtils.denormalize).
*   - InterleavedBufferAttribute (`.array` doesn't exist; data lives on
*     `.data` with an offset) → `getX/Y/Z/W` is the only correct accessor.
*/
function readAttributeFlat(attr, itemSize = attr.itemSize) {
	if (!(attr.isInterleavedBufferAttribute || attr.normalized === true)) return attr.array;
	const count = attr.count;
	const out = new Float32Array(count * itemSize);
	for (let i = 0; i < count; i++) {
		const base = i * itemSize;
		if (itemSize >= 1) out[base] = attr.getX(i);
		if (itemSize >= 2) out[base + 1] = attr.getY(i);
		if (itemSize >= 3) out[base + 2] = attr.getZ(i);
		if (itemSize >= 4) out[base + 3] = attr.getW(i);
	}
	return out;
}
/**
* Build a flat array of vertex indices in draw order from a BufferGeometry.
*
* Three.js stores either:
*   - indexed geometry (geometry.index is non-null) → use index.array directly,
*   - non-indexed geometry → indices are [0, 1, 2, 3, ...].
*
* The returned array has one entry per "loop" (corner). It is in groups of 3
* because three.js draws triangles.
*/
function loopVertexIndices(geometry) {
	if (geometry.index) return Int32Array.from(geometry.index.array);
	const n = geometry.attributes.position.count;
	const out = new Int32Array(n);
	for (let i = 0; i < n; i++) out[i] = i;
	return out;
}
/**
* For a triangle list, return the per-polygon loop_start array:
*   [0, 3, 6, ...] of length (numLoops / 3).
*/
function polygonLoopStarts(numLoops) {
	const polys = numLoops / 3;
	if (!Number.isInteger(polys)) throw new Error(`Loop count ${numLoops} is not a multiple of 3 — non-triangular geometry not supported`);
	const t_ls = new Int32Array(polys);
	for (let i = 0; i < polys; i++) t_ls[i] = i * 3;
	return t_ls;
}
/**
* Apply face-terminator sign-flip: XOR -1 on the last loop index of
* every face. (export_fbx_bin.py:1031-1033). For triangles that means every
* 3rd element (index 2, 5, 8, ...) gets `^= -1`.
*/
function applyFaceTerminator(t_pvi, t_ls) {
	for (let i = 1; i < t_ls.length; i++) t_pvi[t_ls[i] - 1] ^= -1;
	t_pvi[t_pvi.length - 1] ^= -1;
}
/**
* "Expand" a per-vertex (indexed) attribute to a per-loop (corner) array.
* If the geometry is non-indexed, the attribute is already per-loop and we
* just return it as a flat Float32Array.
*
* Handles both BufferAttribute (plain `.array`) and InterleavedBufferAttribute
* (must be read via getX/Y/Z/W).
*/
function attributeToPerLoop(geometry, attr, itemSize) {
	const numLoops = geometry.index ? geometry.index.count : geometry.attributes.position.count;
	const src = readAttributeFlat(attr, itemSize);
	if (!geometry.index) return src;
	const out = new Float32Array(numLoops * itemSize);
	const idx = geometry.index.array;
	for (let i = 0; i < numLoops; i++) {
		const base = idx[i] * itemSize;
		const dst = i * itemSize;
		for (let k = 0; k < itemSize; k++) out[dst + k] = src[base + k];
	}
	return out;
}
/**
* @param {object} ctx
* @param {object} ctx.parent       FBXElem to attach the Geometry node to (usually Objects)
* @param {BufferGeometry} ctx.geometry
* @param {bigint} ctx.uid
* @param {string} ctx.name
* @param {import('../../core/templates.js').TemplateBundle} ctx.templates
* @param {number} ctx.materialSlotCount  number of unique FBX materials linked to this mesh
* @param {Array<{ start: number, count: number, materialIndex: number }>} ctx.groups
*        Forwarded from the Mesh; we use it to emit LayerElementMaterial when > 1 slot.
* @param {number[]} [ctx.slotRemap]  Maps `mesh.material[i]` index → FBX-side
*        material slot, accounting for duplicate Material instances being
*        deduped on export.
*/
function writeGeometry(ctx) {
	const { parent, geometry, uid, name, templates, materialSlotCount = 0, groups = [], slotRemap, transformCtx } = ctx;
	const bake = transformCtx && transformCtx.bake && !transformCtx.isIdentity;
	const geom = parent.addEmpty("Geometry");
	geom.addInt64(uid);
	geom.addString(fbxNameClass(name || "Geometry", "Geometry"));
	geom.addString("Mesh");
	templateInit(templates, "Geometry");
	elemProperties(geom);
	elemDataSingleInt32(geom, "GeometryVersion", 124);
	const pos = geometry.attributes.position;
	if (!pos) throw new Error(`Geometry "${name}" has no position attribute`);
	const posFlat = readAttributeFlat(pos, 3);
	const verts = new Float64Array(posFlat.length);
	for (let i = 0; i < posFlat.length; i++) verts[i] = posFlat[i];
	if (bake) bakeVertices(verts, transformCtx.globalMatrix);
	elemDataSingleFloat64Array(geom, "Vertices", verts);
	const t_lvi = loopVertexIndices(geometry);
	const t_ls = polygonLoopStarts(t_lvi.length);
	const t_pvi = new Int32Array(t_lvi);
	applyFaceTerminator(t_pvi, t_ls);
	elemDataSingleInt32Array(geom, "PolygonVertexIndex", t_pvi);
	elemDataSingleInt32Array(geom, "Edges", /* @__PURE__ */ new Int32Array(0));
	let wroteNormals = false;
	if (geometry.attributes.normal) {
		writeNormalLayer(geom, geometry, bake ? transformCtx : null);
		wroteNormals = true;
	}
	let wroteColors = false;
	if (geometry.attributes.color) {
		writeColorLayer(geom, geometry);
		wroteColors = true;
	}
	const uvSets = [];
	for (const uvName of [
		"uv",
		"uv1",
		"uv2",
		"uv3"
	]) if (geometry.attributes[uvName]) uvSets.push(uvName);
	uvSets.forEach((uvName, i) => writeUVLayer(geom, geometry, uvName, i));
	let wroteMaterial = false;
	if (materialSlotCount > 0) {
		writeMaterialLayer(geom, geometry, materialSlotCount, groups, slotRemap);
		wroteMaterial = true;
	}
	const layer0 = elemDataSingleInt32(geom, "Layer", 0);
	elemDataSingleInt32(layer0, "Version", 100);
	if (wroteNormals) addLayerEntry(layer0, "LayerElementNormal", 0);
	if (wroteColors) addLayerEntry(layer0, "LayerElementColor", 0);
	if (uvSets.length) addLayerEntry(layer0, "LayerElementUV", 0);
	if (wroteMaterial) addLayerEntry(layer0, "LayerElementMaterial", 0);
	for (let i = 1; i < uvSets.length; i++) {
		const layerN = elemDataSingleInt32(geom, "Layer", i);
		elemDataSingleInt32(layerN, "Version", 100);
		addLayerEntry(layerN, "LayerElementUV", i);
	}
}
function addLayerEntry(layer, typeName, typedIndex) {
	const e = elemEmpty(layer, "LayerElement");
	elemDataSingleString(e, "Type", typeName);
	elemDataSingleInt32(e, "TypedIndex", typedIndex);
}
function writeNormalLayer(geom, geometry, bakeCtx) {
	const layer = elemDataSingleInt32(geom, "LayerElementNormal", 0);
	elemDataSingleInt32(layer, "Version", 101);
	elemDataSingleString(layer, "Name", "");
	elemDataSingleString(layer, "MappingInformationType", "ByPolygonVertex");
	elemDataSingleString(layer, "ReferenceInformationType", "IndexToDirect");
	const perLoop = attributeToPerLoop(geometry, geometry.attributes.normal, 3);
	const t_normal = new Float64Array(perLoop.length);
	for (let i = 0; i < perLoop.length; i++) t_normal[i] = perLoop[i];
	if (bakeCtx) bakeNormals(t_normal, bakeCtx.globalMatrixInvTransposed);
	elemDataSingleFloat64Array(layer, "Normals", t_normal);
	const n = t_normal.length / 3;
	const idx = new Int32Array(n);
	for (let i = 0; i < n; i++) idx[i] = i;
	elemDataSingleInt32Array(layer, "NormalsIndex", idx);
}
function writeUVLayer(geom, geometry, attrName, layerIndex) {
	const layer = elemDataSingleInt32(geom, "LayerElementUV", layerIndex);
	elemDataSingleInt32(layer, "Version", 101);
	elemDataSingleString(layer, "Name", attrName === "uv" ? "UVMap" : attrName);
	elemDataSingleString(layer, "MappingInformationType", "ByPolygonVertex");
	elemDataSingleString(layer, "ReferenceInformationType", "IndexToDirect");
	const perLoop = attributeToPerLoop(geometry, geometry.attributes[attrName], 2);
	const t_uv = new Float64Array(perLoop.length);
	for (let i = 0; i < perLoop.length; i++) t_uv[i] = perLoop[i];
	elemDataSingleFloat64Array(layer, "UV", t_uv);
	const n = t_uv.length / 2;
	const idx = new Int32Array(n);
	for (let i = 0; i < n; i++) idx[i] = i;
	elemDataSingleInt32Array(layer, "UVIndex", idx);
}
/**
* LayerElementColor — ByPolygonVertex + IndexToDirect with 4 components.
* three.js color attributes can be 3 or 4 components; we always emit RGBA.
*/
function writeColorLayer(geom, geometry) {
	const layer = elemDataSingleInt32(geom, "LayerElementColor", 0);
	elemDataSingleInt32(layer, "Version", 101);
	elemDataSingleString(layer, "Name", "Col");
	elemDataSingleString(layer, "MappingInformationType", "ByPolygonVertex");
	elemDataSingleString(layer, "ReferenceInformationType", "IndexToDirect");
	const attr = geometry.attributes.color;
	const itemSize = attr.itemSize;
	const perLoop = attributeToPerLoop(geometry, attr, itemSize);
	const numLoops = perLoop.length / itemSize;
	const t_color = new Float64Array(numLoops * 4);
	for (let i = 0; i < numLoops; i++) {
		const src = i * itemSize;
		const dst = i * 4;
		t_color[dst] = perLoop[src];
		t_color[dst + 1] = perLoop[src + 1];
		t_color[dst + 2] = perLoop[src + 2];
		t_color[dst + 3] = itemSize >= 4 ? perLoop[src + 3] : 1;
	}
	elemDataSingleFloat64Array(layer, "Colors", t_color);
	const idx = new Int32Array(numLoops);
	for (let i = 0; i < numLoops; i++) idx[i] = i;
	elemDataSingleInt32Array(layer, "ColorIndex", idx);
}
/**
* LayerElementMaterial — mirrors export_fbx_bin.py:1467-1517.
*  - Single material slot → AllSame + IndexToDirect + Materials=[0]
*  - Multiple slots → ByPolygon + IndexToDirect + per-polygon material indices
*
* `groups` is the three.js BufferGeometry.groups array; each group is
* { start, count, materialIndex } referring to loop indices.
*/
function writeMaterialLayer(geom, geometry, materialSlotCount, groups, slotRemap) {
	const layer = elemDataSingleInt32(geom, "LayerElementMaterial", 0);
	elemDataSingleInt32(layer, "Version", 101);
	elemDataSingleString(layer, "Name", "");
	if (materialSlotCount <= 1 || groups.length === 0) {
		elemDataSingleString(layer, "MappingInformationType", "AllSame");
		elemDataSingleString(layer, "ReferenceInformationType", "IndexToDirect");
		elemDataSingleInt32Array(layer, "Materials", new Int32Array([0]));
		return;
	}
	const numPolys = (geometry.index ? geometry.index.count : geometry.attributes.position.count) / 3;
	const t_pm = new Int32Array(numPolys);
	const remap = slotRemap || identityRemap(materialSlotCount);
	const remapAt = (meshIdx) => {
		if (meshIdx < 0 || meshIdx >= remap.length) return 0;
		const fbxIdx = remap[meshIdx];
		return fbxIdx >= 0 && fbxIdx < materialSlotCount ? fbxIdx : 0;
	};
	for (const g of groups) {
		const polyStart = Math.floor(g.start / 3);
		const polyCount = Math.floor(g.count / 3);
		const fbxIdx = remapAt(g.materialIndex);
		for (let i = 0; i < polyCount; i++) t_pm[polyStart + i] = fbxIdx;
	}
	elemDataSingleString(layer, "MappingInformationType", "ByPolygon");
	elemDataSingleString(layer, "ReferenceInformationType", "IndexToDirect");
	elemDataSingleInt32Array(layer, "Materials", t_pm);
}
function identityRemap(n) {
	const out = new Array(n);
	for (let i = 0; i < n; i++) out[i] = i;
	return out;
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/builders/objects/model.js
/**
* Object3D → FBX `Model` node + optional `NodeAttribute` for "Null" empties.
*
* Property writes use the template-aware writer so values that match the
* default in Definitions are omitted from the per-instance Properties70.
*/
var RAD_TO_DEG$2 = 180 / Math.PI;
/**
* Emit `Object3D.userData` entries as user-defined Properties70 P records.
* Type mapping is best-effort since JS values don't carry an FBX ptype:
*   - boolean        → p_bool
*   - integer Number → p_integer
*   - finite Number  → p_double
*   - string         → p_string
*   - [num,num,num]  → p_vector_3d
*   - anything else  → JSON-stringified p_string
*
* Keys are written verbatim (FBX P-record name field).
*/
function writeUserDataProps(propsElem, userData) {
	if (!userData || typeof userData !== "object") return;
	for (const key of Object.keys(userData)) {
		const value = userData[key];
		if (value === void 0 || value === null) continue;
		if (typeof value === "boolean") elemPropsSet(propsElem, "p_bool", key, value ? 1 : 0, { custom: true });
		else if (typeof value === "number" && Number.isFinite(value)) elemPropsSet(propsElem, Number.isInteger(value) ? "p_integer" : "p_double", key, value, { custom: true });
		else if (typeof value === "string") elemPropsSet(propsElem, "p_string", key, value, { custom: true });
		else if (Array.isArray(value) && value.length === 3 && value.every((v) => typeof v === "number" && Number.isFinite(v))) elemPropsSet(propsElem, "p_vector_3d", key, value, { custom: true });
		else try {
			elemPropsSet(propsElem, "p_string", key, JSON.stringify(value), { custom: true });
		} catch {}
	}
}
var _euler$1 = new Euler();
var _pos = new Vector3();
var _quat$1 = new Quaternion();
var _scale = new Vector3();
/**
* Decompose an object's authoritative local transform into TRS.
*
* `object.matrix` is the single source of truth after SceneCollector calls
* `input.updateMatrixWorld(true)`:
*  - For `matrixAutoUpdate === true` (the default), updateMatrixWorld also
*    calls updateMatrix(), so `matrix` reflects current PQS.
*  - For `matrixAutoUpdate === false`, updateMatrix() is skipped
*    (Object3D.js:1167), so `matrix` is whatever the user set directly.
*    `position/quaternion/scale` may be stale (e.g. defaults).
*
* GLTFExporter handles this divergence by emitting `nodeDef.matrix` when not
* auto-update; FBX has no matrix mode, so we MUST decompose to TRS.
*/
function decomposeLocal(object) {
	object.matrix.decompose(_pos, _quat$1, _scale);
	return {
		pos: _pos,
		quat: _quat$1,
		scale: _scale
	};
}
/**
* Convert a three.js Quaternion to an Euler triple in degrees that, when
* re-interpreted with three.js Euler order 'ZYX', reconstructs the same
* rotation.
*
* Why 'ZYX' rather than 'XYZ': FBX's `RotationOrder=0` is "EulerXYZ" (intrinsic
* X-Y-Z, equivalent to extrinsic Z-Y-X). FBXLoader maps `RotationOrder=0` to
* three.js Euler order `'ZYX'` (see FBXLoader.js:4514 — the table notes
* `'ZYX', // -> XYZ extrinsic`). For round-trip correctness, our export must
* emit angles in that same convention.
*
* Template default `RotationOrder=0` (templates.js: modelTemplate) keeps the
* FBX-side reading aligned.
*/
function quaternionToLclRotationDeg(quaternion) {
	_euler$1.setFromQuaternion(quaternion, "ZYX");
	return [
		_euler$1.x * RAD_TO_DEG$2,
		_euler$1.y * RAD_TO_DEG$2,
		_euler$1.z * RAD_TO_DEG$2
	];
}
/**
* Choose the FBX subtype string written as the Model's third property.
*
* Light / Camera / Bone subtypes only work when there's a matching
* NodeAttribute::<Subtype> attached — otherwise FBXLoader takes the wrong
* code path (e.g. createCamera reads window.innerWidth in Node).
* AmbientLight has no FBX equivalent so we collapse it to Null.
*/
function modelSubtypeFor$1(object) {
	if (object.isMesh) return "Mesh";
	if (object.isBone) return "LimbNode";
	if (object.isLight && !object.isAmbientLight) return "Light";
	if (object.isCamera) return "Camera";
	return "Null";
}
__name(modelSubtypeFor$1, "modelSubtypeFor");
/**
* Write a single Model node.
*
* @param {object} ctx
* @param {FBXElem} ctx.parent   `Objects` container
* @param {Object3D} ctx.object
* @param {bigint} ctx.uid
* @param {TemplateBundle} ctx.templates
*/
function writeModel({ parent, object, uid, templates, overrideTranslation, overrideMatrix, hasLookAtTarget, customProperties }) {
	const subtype = modelSubtypeFor$1(object);
	const model = parent.addEmpty("Model");
	model.addInt64(uid);
	model.addString(fbxNameClass(object.name || subtype, "Model"));
	model.addString(subtype);
	elemDataSingleInt32(model, "Version", 232);
	const tmpl = templateInit(templates, "Model");
	const props = elemProperties(model);
	let t;
	let quat;
	let s;
	if (overrideMatrix) {
		const _p = new Vector3();
		const _q = new Quaternion();
		const _s = new Vector3();
		overrideMatrix.decompose(_p, _q, _s);
		t = _p;
		quat = _q;
		s = _s;
	} else ({pos: t, quat, scale: s} = decomposeLocal(object));
	const rot = quaternionToLclRotationDeg(quat);
	templateSet(tmpl, props, "p_lcl_translation", "Lcl Translation", overrideTranslation ? overrideTranslation : [
		t.x,
		t.y,
		t.z
	], { animatable: true });
	templateSet(tmpl, props, "p_lcl_rotation", "Lcl Rotation", rot, { animatable: true });
	templateSet(tmpl, props, "p_lcl_scaling", "Lcl Scaling", [
		s.x,
		s.y,
		s.z
	], { animatable: true });
	templateSet(tmpl, props, "p_visibility", "Visibility", object.visible ? 1 : 0);
	templateSet(tmpl, props, "p_integer", "DefaultAttributeIndex", 0);
	templateSet(tmpl, props, "p_enum", "InheritType", 1);
	if (hasLookAtTarget) templateSet(tmpl, props, "p_object", "LookAtProperty", null);
	if (customProperties) writeUserDataProps(props, object.userData);
	elemDataSingleInt32(model, "MultiLayer", 0);
	elemDataSingleInt32(model, "MultiTake", 0);
	elemDataSingleChar(model, "Shading", 1);
	elemDataSingleString(model, "Culling", "CullingOff");
}
/**
* Write a `NodeAttribute` node for an Object3D / Group ("Null" empty).
*/
function writeNullAttribute({ parent, name, uid, templates }) {
	const node = parent.addEmpty("NodeAttribute");
	node.addInt64(uid);
	node.addString(fbxNameClass(name || "Null", "NodeAttribute"));
	node.addString("Null");
	elemDataSingleString(node, "TypeFlags", "Null");
	templateInit(templates, "NodeAttribute");
	elemProperties(node);
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/builders/objects/material.js
/**
* three.js Material → FBX `Material` node (FbxSurfacePhong).
*
* Output properties (names match what FBXLoader.parseParameters reads):
*   ShadingModel       'Phong'
*   DiffuseColor       color (sRGB)
*   DiffuseFactor      1.0
*   EmissiveColor      emissive
*   EmissiveFactor     emissiveIntensity (default 1)
*   AmbientColor       (0,0,0)
*   AmbientFactor      0.0
*   TransparentColor   color
*   TransparencyFactor 1 - alpha
*   Opacity            alpha
*   NormalMap          (0,0,0) placeholder
*   BumpFactor         bump scale
*   SpecularColor      color
*   SpecularFactor     specular / 2
*   Shininess          ((1 - roughness) * 10) ^ 2
*   ShininessExponent  same
*   ReflectionColor    color
*   ReflectionFactor   metallic
*/
/**
* Pull a normalized PBR-ish description from any three.js material.
*/
function readMaterialParams(material) {
	const out = {
		baseColor: [
			.8,
			.8,
			.8
		],
		emissiveColor: [
			0,
			0,
			0
		],
		emissiveStrength: 1,
		metallic: 0,
		roughness: .5,
		specular: .5,
		alpha: 1,
		normalmapStrength: 1
	};
	if (material.color) out.baseColor = [
		material.color.r,
		material.color.g,
		material.color.b
	];
	if (material.emissive) out.emissiveColor = [
		material.emissive.r,
		material.emissive.g,
		material.emissive.b
	];
	if ("emissiveIntensity" in material) out.emissiveStrength = material.emissiveIntensity;
	if ("metalness" in material) out.metallic = material.metalness;
	if ("roughness" in material) out.roughness = material.roughness;
	if ("opacity" in material) out.alpha = material.opacity;
	if ("normalScale" in material && material.normalScale) out.normalmapStrength = material.normalScale.x;
	if (material.isMeshPhongMaterial) {
		const sh = typeof material.shininess === "number" ? material.shininess : 30;
		out.roughness = Math.max(0, 1 - Math.sqrt(Math.max(0, sh)) / 10);
		if (material.specular && typeof material.specular.r === "number") out.specular = material.specular.r;
	}
	return out;
}
/**
* @param {object} ctx
* @param {FBXElem} ctx.parent
* @param {Material} ctx.material
* @param {bigint}  ctx.uid
* @param {TemplateBundle} ctx.templates
*/
function writeMaterial({ parent, material, uid, templates }) {
	const ma = readMaterialParams(material);
	const node = parent.addEmpty("Material");
	node.addInt64(uid);
	node.addString(fbxNameClass(material.name || "Material", "Material"));
	node.addString("");
	elemDataSingleInt32(node, "Version", 102);
	elemDataSingleString(node, "ShadingModel", "Phong");
	elemDataSingleInt32(node, "MultiLayer", 0);
	const tmpl = templateInit(templates, "Material");
	const props = elemProperties(node);
	templateSet(tmpl, props, "p_string", "ShadingModel", "Phong");
	templateSet(tmpl, props, "p_color", "DiffuseColor", ma.baseColor);
	templateSet(tmpl, props, "p_number", "DiffuseFactor", 1);
	templateSet(tmpl, props, "p_color", "EmissiveColor", ma.emissiveColor);
	templateSet(tmpl, props, "p_number", "EmissiveFactor", ma.emissiveStrength);
	templateSet(tmpl, props, "p_color", "AmbientColor", [
		0,
		0,
		0
	]);
	templateSet(tmpl, props, "p_number", "AmbientFactor", 0);
	if (ma.alpha < 1e-5 || ma.alpha > .99999) {
		const c = 1 - ma.alpha;
		templateSet(tmpl, props, "p_color", "TransparentColor", [
			c,
			c,
			c
		]);
	} else templateSet(tmpl, props, "p_color", "TransparentColor", ma.baseColor);
	templateSet(tmpl, props, "p_number", "TransparencyFactor", 1 - ma.alpha);
	templateSet(tmpl, props, "p_number", "Opacity", ma.alpha);
	templateSet(tmpl, props, "p_vector_3d", "NormalMap", [
		0,
		0,
		0
	]);
	templateSet(tmpl, props, "p_double", "BumpFactor", ma.normalmapStrength);
	templateSet(tmpl, props, "p_color", "SpecularColor", ma.baseColor);
	templateSet(tmpl, props, "p_number", "SpecularFactor", ma.specular / 2);
	const shin = (1 - ma.roughness) * 10;
	const shinSq = shin * shin;
	templateSet(tmpl, props, "p_number", "Shininess", shinSq);
	templateSet(tmpl, props, "p_number", "ShininessExponent", shinSq);
	templateSet(tmpl, props, "p_color", "ReflectionColor", ma.baseColor);
	templateSet(tmpl, props, "p_number", "ReflectionFactor", ma.metallic);
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/builders/objects/bone.js
/**
* Bone → FBX `NodeAttribute` (LimbNode) node.
*
* (the "Bones data" sub-loop). Each Bone has:
*   - NodeAttribute uid (separate from the Model uid),
*   - subtype "LimbNode",
*   - TypeFlags "Skeleton",
*   - Properties70 from the Bone template (only `Size` is set per-instance;
*     finalize emits anything else from the template).
*
* The Bone's own Model is written by writeModel (model.js) — the LimbNode
* subtype is selected there.
*/
var BONE_RADIUS_SCALE = 33;
/**
* @param {object} ctx
* @param {FBXElem} ctx.parent       Objects container
* @param {Bone}    ctx.bone         three.js Bone instance
* @param {bigint}  ctx.attrUid      this NodeAttribute's allocated uid
* @param {TemplateBundle} ctx.templates
*/
function writeBoneAttribute({ parent, bone, attrUid, templates }) {
	const node = parent.addEmpty("NodeAttribute");
	node.addInt64(attrUid);
	node.addString(fbxNameClass(bone.name || "Bone", "NodeAttribute"));
	node.addString("LimbNode");
	elemDataSingleString(node, "TypeFlags", "Skeleton");
	templateSet(templateInit(templates, "NodeAttribute"), elemProperties(node), "p_double", "Size", BONE_RADIUS_SCALE);
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/builders/objects/skin.js
/**
* SkinnedMesh → FBX skinning nodes.
*
*   1. `Deformer (Skin)`   — one per SkinnedMesh; holds skin metadata.
*   2. `Deformer (Cluster)` (a.k.a. SubDeformer) — one per bone per skin;
*       carries per-vertex Indexes/Weights and the bind-time bone transforms.
*   3. `Pose (BindPose)`   — one per SkinnedMesh; PoseNode subtree pinning the
*       mesh + each bone's world matrix at bind time.
*
* Matrix encoding: FBX stores 4×4 matrices as a flat 16-element float64 array
* in COLUMN-MAJOR order. three.js's `Matrix4.elements` is already column-major
* (Matrix4.js docstring), so we write `.elements` verbatim — no transpose.
*/
function mat4ToFloat64Array(matrix4) {
	const out = /* @__PURE__ */ new Float64Array(16);
	for (let i = 0; i < 16; i++) out[i] = matrix4.elements[i];
	return out;
}
var _IDENTITY_MATRIX_FLAT = new Float64Array(new Matrix4().identity().elements);
/**
* Write the Skin Deformer + per-bone Cluster nodes for one SkinnedMesh.
*
* @param {object} ctx
* @param {FBXElem} ctx.parent       Objects container
* @param {Object}  ctx.skin         SceneCollector skin entry (deformerUid, clusters[])
* @param {string}  ctx.armatureName  Name to embed in the Deformer attrName
*/
function writeSkinDeformer({ parent, skin, armatureName = "Armature" }) {
	const skinNode = parent.addEmpty("Deformer");
	skinNode.addInt64(skin.deformerUid);
	skinNode.addString(fbxNameClass(armatureName, "Deformer"));
	skinNode.addString("Skin");
	elemDataSingleInt32(skinNode, "Version", 101);
	elemDataSingleFloat64(skinNode, "Link_DeformAcuracy", 50);
	for (const cluster of skin.clusters) writeCluster(parent, cluster, skin);
}
/**
* Each Cluster is a Deformer node with attrType="Cluster". Its parent in the
* Connections graph is the Skin Deformer.
*/
function writeCluster(parent, cluster, skin) {
	const clusterNode = parent.addEmpty("Deformer");
	clusterNode.addInt64(cluster.clusterUid);
	clusterNode.addString(fbxNameClass(cluster.bone.name || "Bone", "SubDeformer"));
	clusterNode.addString("Cluster");
	elemDataSingleInt32(clusterNode, "Version", 100);
	const userData = elemEmpty(clusterNode, "UserData");
	userData.addString("");
	userData.addString("");
	if (cluster.indices.length > 0) {
		elemDataSingleInt32Array(clusterNode, "Indexes", Int32Array.from(cluster.indices));
		elemDataSingleFloat64Array(clusterNode, "Weights", Float64Array.from(cluster.weights));
	}
	elemDataSingleFloat64Array(clusterNode, "Transform", mat4ToFloat64Array(cluster.transform));
	elemDataSingleFloat64Array(clusterNode, "TransformLink", mat4ToFloat64Array(cluster.transformLink));
	elemDataSingleFloat64Array(clusterNode, "TransformAssociateModel", _IDENTITY_MATRIX_FLAT);
}
/**
* Write the BindPose record for a SkinnedMesh.
*
* The BindPose lists every Model (mesh + bones) along with its world matrix
* at the bind moment. FBXLoader's parsePoseNodes (FBXLoader.js:1611) reads
* this as a fallback bind pose for bones not in a cluster — for our purposes
* it's a courtesy to other DCC tools.
*/
function writeBindPose({ parent, skin, meshUid, meshName }) {
	const pose = parent.addEmpty("Pose");
	pose.addInt64(skin.bindPoseUid);
	pose.addString(fbxNameClass(meshName || "BindPose", "Pose"));
	pose.addString("BindPose");
	elemDataSingleString(pose, "Type", "BindPose");
	elemDataSingleInt32(pose, "Version", 100);
	elemDataSingleInt32(pose, "NbPoseNodes", 1 + skin.clusters.length);
	const meshPose = elemEmpty(pose, "PoseNode");
	elemDataSingleInt64(meshPose, "Node", meshUid);
	elemDataSingleFloat64Array(meshPose, "Matrix", mat4ToFloat64Array(skin.bindMatrix));
	for (const cluster of skin.clusters) {
		const bonePose = elemEmpty(pose, "PoseNode");
		elemDataSingleInt64(bonePose, "Node", cluster.boneEntry.uid);
		elemDataSingleFloat64Array(bonePose, "Matrix", mat4ToFloat64Array(cluster.transformLink));
	}
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/builders/objects/animation.js
/**
* Emit AnimationStack / AnimationLayer / AnimationCurveNode / AnimationCurve
* nodes, plus their OO / OP connections.
*
* Per stack, we emit:
*   AnimationStack (uid)            — Properties70.LocalStart/Stop/ReferenceStart/Stop (KTime)
*   AnimationLayer (uid)            — one per stack
*   AnimationCurveNode (uid×K)      — one per (target, property), Properties70 has d|X/d|Y/d|Z initial values
*   AnimationCurve (uid×3K)         — one per axis, KeyTime / KeyValueFloat / KeyAttrFlags
*
* Connections (OO + OP):
*   OO  AnimLayer → AnimStack
*   OO  AnimCurveNode → AnimLayer
*   OP  AnimCurveNode → Model   relationship: "Lcl Translation" / "Lcl Rotation" / "Lcl Scaling"
*   OP  AnimCurve → AnimCurveNode  relationship: "d|X" / "d|Y" / "d|Z"
*/
var KEY_ATTR_FLAGS = 24836;
var KEY_ATTR_DATAFLOAT = [
	0,
	0,
	9419963346924634e-45,
	0
];
/**
* @param {object} ctx
* @param {FBXElem} ctx.parent       Objects container
* @param {object[]} ctx.stacks      output of animationCollector.buildAnimationPlan
* @param {TemplateBundle} ctx.templates
*/
function writeAnimationNodes({ parent, stacks, templates }) {
	for (const stack of stacks) writeStack(parent, stack, templates);
}
function writeStack(parent, stack, templates) {
	const stackNode = parent.addEmpty("AnimationStack");
	stackNode.addInt64(stack.stackUid);
	stackNode.addString(fbxNameClass(stack.name, "AnimStack"));
	stackNode.addString("");
	const stackTmpl = templateInit(templates, "AnimationStack");
	const stackProps = elemProperties(stackNode);
	templateSet(stackTmpl, stackProps, "p_timestamp", "LocalStart", stack.start);
	templateSet(stackTmpl, stackProps, "p_timestamp", "LocalStop", stack.stop);
	templateSet(stackTmpl, stackProps, "p_timestamp", "ReferenceStart", stack.start);
	templateSet(stackTmpl, stackProps, "p_timestamp", "ReferenceStop", stack.stop);
	const layerNode = parent.addEmpty("AnimationLayer");
	layerNode.addInt64(stack.layerUid);
	layerNode.addString(fbxNameClass(stack.name, "AnimLayer"));
	layerNode.addString("");
	for (const cn of stack.curveNodes) writeCurveNode(parent, cn, templates);
}
function writeCurveNode(parent, cn, templates) {
	const nodeElem = parent.addEmpty("AnimationCurveNode");
	nodeElem.addInt64(cn.curveNodeUid);
	nodeElem.addString(fbxNameClass(cn.attrName, "AnimCurveNode"));
	nodeElem.addString("");
	const cnTmpl = templateInit(templates, "AnimationCurveNode");
	const cnProps = elemProperties(nodeElem);
	for (const curve of cn.curves) templateSet(cnTmpl, cnProps, "p_number", `d|${curve.axis}`, curve.defaultValue, { animatable: true });
	for (const curve of cn.curves) writeCurve(parent, curve);
}
function writeCurve(parent, curve) {
	const c = parent.addEmpty("AnimationCurve");
	c.addInt64(curve.uid);
	c.addString(fbxNameClass("", "AnimCurve"));
	c.addString("");
	elemDataSingleFloat64(c, "Default", curve.defaultValue);
	elemDataSingleInt32(c, "KeyVer", FBX_ANIM_KEY_VERSION);
	elemDataSingleInt64Array(c, "KeyTime", curve.times);
	elemDataSingleFloat32Array(c, "KeyValueFloat", curve.values);
	elemDataSingleInt32Array(c, "KeyAttrFlags", new Int32Array([KEY_ATTR_FLAGS]));
	elemDataSingleFloat32Array(c, "KeyAttrDataFloat", new Float32Array(KEY_ATTR_DATAFLOAT));
	elemDataSingleInt32Array(c, "KeyAttrRefCount", new Int32Array([curve.times.length]));
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/data/animationCollector.js
/**
* Collect three.js AnimationClip[] from a scene and turn them into the FBX
* `AnimStack → AnimLayer → AnimCurveNode → AnimCurve` structure.
*
* The output is a plan, not bytes. Bytes are emitted by builders/objects/
* animation.js using these structures.
*/
var RAD_TO_DEG$1 = 180 / Math.PI;
var _euler = new Euler();
var _quat = new Quaternion();
function secondsToKTime(seconds) {
	if (!Number.isFinite(seconds)) return 0n;
	return BigInt(Math.round(seconds * 1e6)) * FBX_KTIME / 1000000n;
}
var KINDS = {
	position: {
		attrName: "T",
		fbxProp: "Lcl Translation",
		axes: [
			"X",
			"Y",
			"Z"
		]
	},
	scale: {
		attrName: "S",
		fbxProp: "Lcl Scaling",
		axes: [
			"X",
			"Y",
			"Z"
		]
	},
	quaternion: {
		attrName: "R",
		fbxProp: "Lcl Rotation",
		axes: [
			"X",
			"Y",
			"Z"
		]
	},
	morphTargetInfluences: {
		attrName: "DeformPercent",
		fbxProp: "DeformPercent",
		axes: ["DeformPercent"]
	}
};
/**
* Gather every AnimationClip in the scene without duplicates.
*
* three.js stores clips in different places depending on the loader:
* - GLTFLoader puts them on the imported scene (root.animations).
* - FBXLoader stores them on the returned Group (root.animations).
* - Manual code sometimes attaches them to specific objects.
*
* We walk the whole tree and dedupe by reference.
*/
function collectAnimationClips(input) {
	const seen = /* @__PURE__ */ new Set();
	const out = [];
	function visit(obj) {
		if (Array.isArray(obj.animations)) {
			for (const clip of obj.animations) if (clip && !seen.has(clip)) {
				seen.add(clip);
				out.push(clip);
			}
		}
	}
	visit(input);
	input.traverse((o) => {
		if (o !== input) visit(o);
	});
	return out;
}
/**
* Build the per-clip animation plan.
*
* @param {object} ctx
* @param {Object3D}        ctx.root        scene root
* @param {AnimationClip[]} ctx.clips
* @param {UidRegistry}     ctx.uids
* @param {TemplateBundle}  ctx.templates
* @param {object}          ctx.settings
* @param {object[]}        [ctx.meshes]    SceneCollector mesh entries — used
*                                          to resolve `Mesh.morphTargetInfluences[N]`
*                                          tracks back to the right
*                                          BlendShapeChannel UID.
* @returns {object[]} stacks
*/
function buildAnimationPlan({ root, clips, uids, templates, settings, meshes = [] }) {
	const stacks = [];
	if (!clips || clips.length === 0) return stacks;
	const nodeMap = /* @__PURE__ */ new Map();
	root.traverse((o) => {
		if (o.name) nodeMap.set(o.name, o);
	});
	for (const clip of clips) {
		const stack = buildStackPlan({
			clip,
			root,
			nodeMap,
			uids,
			templates,
			meshes
		});
		if (stack) stacks.push(stack);
	}
	return stacks;
}
function buildStackPlan({ clip, root, nodeMap, uids, templates, meshes }) {
	const stackKey = animStackKey(clip.uuid || clip.name);
	const stackUid = uids.get(stackKey);
	const layerKey = animLayerKey(clip.uuid || clip.name);
	const layerUid = uids.get(layerKey);
	const groups = /* @__PURE__ */ new Map();
	for (const track of clip.tracks) {
		const parsed = PropertyBinding.parseTrackName(track.name);
		if (!parsed.nodeName) continue;
		const node = nodeMap.get(parsed.nodeName) || PropertyBinding.findNode(root, parsed.nodeName);
		if (!node) continue;
		const kind = KINDS[parsed.propertyName];
		if (!kind) continue;
		if (parsed.propertyName === "morphTargetInfluences" && parsed.propertyIndex == null) {
			const N = track.getValueSize();
			const TArr = track.values.constructor;
			for (let mi = 0; mi < N; mi++) {
				const sliceValues = new TArr(track.times.length);
				for (let k = 0; k < track.times.length; k++) sliceValues[k] = track.values[k * N + mi];
				const groupKey = `${node.uuid}|morphTargetInfluences[${mi}]`;
				groups.set(groupKey, {
					node,
					kind,
					propertyName: "morphTargetInfluences",
					propertyIndex: String(mi),
					track: {
						times: track.times,
						values: sliceValues
					}
				});
			}
			continue;
		}
		const indexSuffix = parsed.propertyIndex != null ? `[${parsed.propertyIndex}]` : "";
		const groupKey = `${node.uuid}|${parsed.propertyName}${indexSuffix}`;
		let group = groups.get(groupKey);
		if (!group) {
			group = {
				node,
				kind,
				propertyName: parsed.propertyName,
				propertyIndex: parsed.propertyIndex,
				track: null
			};
			groups.set(groupKey, group);
		}
		group.track = track;
	}
	if (groups.size === 0) return null;
	let durationSec = 0;
	for (const g of groups.values()) {
		if (g.track.times.length === 0) continue;
		const last = g.track.times[g.track.times.length - 1];
		if (last > durationSec) durationSec = last;
	}
	const curveNodes = [];
	for (const g of groups.values()) {
		const cn = buildCurveNode({
			group: g,
			clip,
			uids,
			templates,
			meshes
		});
		if (cn) curveNodes.push(cn);
	}
	templates.register(animStackTemplate({})).users += 1;
	templates.register(animLayerTemplate({})).users += 1;
	return {
		stackKey,
		stackUid,
		layerKey,
		layerUid,
		name: clip.name || "AnimStack",
		start: 0n,
		stop: secondsToKTime(durationSec),
		curveNodes
	};
}
function buildCurveNode({ group, clip, uids, templates, meshes }) {
	const { node, kind, propertyName, propertyIndex, track } = group;
	const axes = kind.axes;
	const keySuffix = propertyIndex != null ? `[${propertyIndex}]` : "";
	const nodeUid = uids.get(animCurveNodeKey(clip.uuid || clip.name, node.uuid, `${propertyName}${keySuffix}`));
	let perAxisValues;
	if (propertyName === "quaternion") perAxisValues = bakeQuaternionToEulerDegrees(track.values);
	else if (propertyName === "morphTargetInfluences") {
		perAxisValues = [[]];
		for (let i = 0; i < track.times.length; i++) perAxisValues[0].push(track.values[i] * 100);
	} else {
		perAxisValues = [
			[],
			[],
			[]
		];
		for (let i = 0; i < track.times.length; i++) {
			perAxisValues[0].push(track.values[i * 3]);
			perAxisValues[1].push(track.values[i * 3 + 1]);
			perAxisValues[2].push(track.values[i * 3 + 2]);
		}
	}
	let resolvedTargetUid = null;
	if (propertyName === "morphTargetInfluences") {
		const meshEntry = meshes.find((m) => m.object === node);
		if (!meshEntry || !meshEntry.morph) return null;
		const channel = meshEntry.morph.channels[parseInt(propertyIndex, 10)];
		if (!channel) return null;
		resolvedTargetUid = channel.channelUid;
	}
	const ktimes = new BigInt64Array(track.times.length);
	for (let i = 0; i < track.times.length; i++) ktimes[i] = secondsToKTime(track.times[i]);
	const curves = [];
	for (let ax = 0; ax < axes.length; ax++) {
		const curveUid = uids.get(animCurveKey(clip.uuid || clip.name, node.uuid, `${propertyName}${keySuffix}`, axes[ax]));
		templates.register(animCurveTemplate({})).users += 1;
		curves.push({
			uid: curveUid,
			axis: axes[ax],
			defaultValue: perAxisValues[ax][0] ?? 0,
			times: ktimes,
			values: Float32Array.from(perAxisValues[ax])
		});
	}
	templates.register(animCurveNodeTemplate({})).users += 1;
	return {
		targetUid: resolvedTargetUid,
		targetNode: node,
		fbxProp: kind.fbxProp,
		attrName: kind.attrName,
		curveNodeUid: nodeUid,
		curves
	};
}
/**
* Bake a flat quaternion array to per-axis Euler-degree arrays, ensuring
* continuity across keyframes (no 360° jumps that would otherwise cause
* FBXLoader's interpolation to spin the bone unnecessarily).
*
* Uses ZYX order to match the FBX RotationOrder=0 → three.js 'ZYX'
* mapping used in model.js.
*/
function bakeQuaternionToEulerDegrees(quatValues) {
	const n = quatValues.length / 4;
	const xs = new Array(n);
	const ys = new Array(n);
	const zs = new Array(n);
	let prev = [
		0,
		0,
		0
	];
	for (let i = 0; i < n; i++) {
		_quat.set(quatValues[i * 4], quatValues[i * 4 + 1], quatValues[i * 4 + 2], quatValues[i * 4 + 3]);
		_euler.setFromQuaternion(_quat, "ZYX");
		const triple = [
			_euler.x * RAD_TO_DEG$1,
			_euler.y * RAD_TO_DEG$1,
			_euler.z * RAD_TO_DEG$1
		];
		if (i > 0) unrollEuler(prev, triple);
		xs[i] = triple[0];
		ys[i] = triple[1];
		zs[i] = triple[2];
		prev = triple;
	}
	return [
		xs,
		ys,
		zs
	];
}
/**
* In-place adjust `curr` so its components are within 180° of `prev` —
* this picks the equivalent Euler representation that keeps the curve
* continuous. Important because Euler decomposition is non-unique; without
* unrolling, a quaternion that crosses the antipode produces a 360° spike
* in one axis that interpolates incorrectly.
*/
function unrollEuler(prev, curr) {
	for (let k = 0; k < 3; k++) {
		while (curr[k] - prev[k] > 180) curr[k] -= 360;
		while (curr[k] - prev[k] < -180) curr[k] += 360;
	}
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/builders/objects/morph.js
/**
* Emit BlendShape Deformer + BlendShapeChannel SubDeformers + Geometry(Shape)
* nodes for morph targets on a mesh.
*
* For each mesh with morphs we produce:
*   - 1 Deformer (BlendShape)                       — top-level
*   - N Deformer (BlendShapeChannel) (SubDeformer)  — one per morph target
*   - N Geometry (Shape)                            — delta geometry per target
*
* Connections (handled in SceneCollector pass 2):
*   OO  BlendShape         → base Geometry
*   OO  BlendShapeChannel  → BlendShape
*   OO  ShapeGeometry      → BlendShapeChannel
*/
/**
* @param {object} ctx
* @param {FBXElem} ctx.parent       Objects container
* @param {object}  ctx.morphPlan    output of morphCollector.collectMorph
* @param {TemplateBundle} ctx.templates
*/
function writeMorph({ parent, morphPlan, templates }) {
	const meshName = morphPlan.mesh.name || "BlendShape";
	for (const channel of morphPlan.channels) writeShapeGeometry(parent, channel, templates);
	const shapeDef = parent.addEmpty("Deformer");
	shapeDef.addInt64(morphPlan.blendShapeUid);
	shapeDef.addString(fbxNameClass(meshName, "Deformer"));
	shapeDef.addString("BlendShape");
	elemDataSingleInt32(shapeDef, "Version", 100);
	for (const channel of morphPlan.channels) writeChannel(parent, channel, templates);
}
function writeShapeGeometry(parent, channel, templates) {
	const geom = parent.addEmpty("Geometry");
	geom.addInt64(channel.shapeGeomUid);
	geom.addString(fbxNameClass(channel.name, "Geometry"));
	geom.addString("Shape");
	templateInit(templates, "Geometry");
	elemProperties(geom);
	elemDataSingleInt32(geom, "Version", 100);
	elemDataSingleInt32Array(geom, "Indexes", channel.indices);
	elemDataSingleFloat64Array(geom, "Vertices", channel.deltas);
}
function writeChannel(parent, channel, templates) {
	const ch = parent.addEmpty("Deformer");
	ch.addInt64(channel.channelUid);
	ch.addString(fbxNameClass(channel.name, "SubDeformer"));
	ch.addString("BlendShapeChannel");
	elemDataSingleInt32(ch, "Version", 100);
	elemDataSingleFloat64(ch, "DeformPercent", channel.deformPercent);
	const fullWeights = new Float64Array(channel.indices.length);
	fullWeights.fill(100);
	elemDataSingleFloat64Array(ch, "FullWeights", fullWeights);
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/data/morphCollector.js
/**
* Detect morph targets on a three.js Mesh and build the FBX-side BlendShape
* plan: one `BlendShape` Deformer per mesh, one `BlendShapeChannel`
* SubDeformer per morph target, one `Geometry (Shape)` per channel.
*
* Three.js stores morphs as `geometry.morphAttributes.position` (an array of
* BufferAttributes, one per channel). `geometry.morphTargetsRelative` flags
* whether they are deltas (true, common) or absolute positions (false).
* FBX requires delta values; we convert if needed.
*
* `mesh.morphTargetDictionary` (set by GLTFLoader or manually) maps channel
* name → index.
*/
/**
* @param {object} ctx
* @param {Mesh}    ctx.mesh
* @param {UidRegistry}    ctx.uids
* @param {TemplateBundle} ctx.templates
* @returns {?object} morphPlan or null if the mesh has no morphs
*/
function collectMorph({ mesh, uids, templates }) {
	const geom = mesh.geometry;
	const morphPos = geom.morphAttributes && geom.morphAttributes.position;
	if (!morphPos || morphPos.length === 0) return null;
	const base = geom.attributes.position;
	if (!base) return null;
	const relative = geom.morphTargetsRelative === true;
	const blendShapeUid = uids.get(blendShapeDeformerKey(geom.uuid));
	templates.register(deformerTemplate({})).users += 1;
	const dict = mesh.morphTargetDictionary;
	const nameByIndex = new Array(morphPos.length);
	if (dict) for (const [k, v] of Object.entries(dict)) nameByIndex[v] = k;
	for (let i = 0; i < morphPos.length; i++) if (!nameByIndex[i]) nameByIndex[i] = `morph_${i}`;
	const channels = [];
	const baseFlat = readBaseFlat(base);
	const numVerts = base.count;
	const influences = mesh.morphTargetInfluences;
	for (let i = 0; i < morphPos.length; i++) {
		const attr = morphPos[i];
		const name = nameByIndex[i];
		const channelUid = uids.get(blendShapeChannelKey(geom.uuid, i, name));
		const shapeGeomUid = uids.get(shapeGeometryKey(geom.uuid, i, name));
		templates.register(deformerTemplate({})).users += 1;
		templates.register(geometryTemplate({})).users += 1;
		const deltas = computeDeltas(attr, baseFlat, numVerts, relative);
		const indices = new Int32Array(numVerts);
		for (let v = 0; v < numVerts; v++) indices[v] = v;
		const deformPercent = (Array.isArray(influences) && i < influences.length ? influences[i] : 0) * 100;
		channels.push({
			index: i,
			name,
			channelUid,
			shapeGeomUid,
			deltas,
			indices,
			deformPercent
		});
	}
	return {
		mesh,
		geometry: geom,
		blendShapeUid,
		channels
	};
}
/**
* Read the base position attribute into a flat Float32Array. Uses getX/Y/Z
* to handle Interleaved + normalized attributes (matches geometry.js).
*/
function readBaseFlat(attr) {
	const n = attr.count;
	const out = new Float32Array(n * 3);
	if (attr.isInterleavedBufferAttribute || attr.normalized) for (let i = 0; i < n; i++) {
		out[i * 3] = attr.getX(i);
		out[i * 3 + 1] = attr.getY(i);
		out[i * 3 + 2] = attr.getZ(i);
	}
	else out.set(attr.array.subarray(0, n * 3));
	return out;
}
/**
* Compute per-vertex delta values (morph - base, or just morph if already
* stored as deltas).
*
* three.js morph rendering uses the formula:
*   v_final = v_base + Σ(weight × morphAttr[i])      when morphTargetsRelative === true
*   v_final = v_base + Σ(weight × (morphAttr[i] - v_base))  when relative === false
*
* FBX always expects deltas in the shape's Vertices array (FBXLoader.js:2408
* does `morphPositions[idx] = morphPositionsSparse[i]` then renders with
* morphTargetsRelative = true), so we normalise both inputs to deltas.
*/
function computeDeltas(morphAttr, baseFlat, n, relative) {
	const out = new Float64Array(n * 3);
	const isAccessor = morphAttr.isInterleavedBufferAttribute || morphAttr.normalized;
	if (relative) {
		if (isAccessor) for (let i = 0; i < n; i++) {
			out[i * 3] = morphAttr.getX(i);
			out[i * 3 + 1] = morphAttr.getY(i);
			out[i * 3 + 2] = morphAttr.getZ(i);
		}
		else {
			const src = morphAttr.array;
			for (let k = 0; k < n * 3; k++) out[k] = src[k];
		}
	} else if (isAccessor) for (let i = 0; i < n; i++) {
		out[i * 3] = morphAttr.getX(i) - baseFlat[i * 3];
		out[i * 3 + 1] = morphAttr.getY(i) - baseFlat[i * 3 + 1];
		out[i * 3 + 2] = morphAttr.getZ(i) - baseFlat[i * 3 + 2];
	}
	else {
		const src = morphAttr.array;
		for (let i = 0; i < n; i++) {
			out[i * 3] = src[i * 3] - baseFlat[i * 3];
			out[i * 3 + 1] = src[i * 3 + 1] - baseFlat[i * 3 + 1];
			out[i * 3 + 2] = src[i * 3 + 2] - baseFlat[i * 3 + 2];
		}
	}
	return out;
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/builders/objects/light.js
/**
* three.js Light → FBX `NodeAttribute::Light`.
*
* Supported types:
*   - PointLight        → FBX Point         (LightType=0)
*   - DirectionalLight  → FBX Directional   (LightType=1)
*   - SpotLight         → FBX Spot          (LightType=2)
* HemisphereLight is mapped to Directional.
* AmbientLight and RectAreaLight fall through to type 0 with a console warning;
* three.js FBXLoader doesn't support Area on import anyway.
*
* FBXLoader.js:1232-1351 reads these specific fields:
*   LightType   → switch (Point/Directional/Spot/default)
*   Color       → sRGB → working color (ColorManagement)
*   Intensity   → × 1/100 (we multiply by 100 here for symmetric round-trip)
*   FarAttenuationEnd → PointLight.distance / SpotLight.distance
*   OuterAngle  → SpotLight.angle (degrees → radians)
*   InnerAngle  → with OuterAngle, computes penumbra = 1 - inner/outer
*   CastShadows → light.castShadow
*/
var RAD_TO_DEG = 180 / Math.PI;
var FBX_LIGHT_POINT = 0;
var FBX_LIGHT_DIRECTIONAL = 1;
var FBX_LIGHT_SPOT = 2;
var FBX_LIGHT_AREA = 3;
function lightTypeFor(light) {
	if (light.isDirectionalLight) return FBX_LIGHT_DIRECTIONAL;
	if (light.isSpotLight) return FBX_LIGHT_SPOT;
	if (light.isPointLight) return FBX_LIGHT_POINT;
	if (light.isHemisphereLight) return FBX_LIGHT_DIRECTIONAL;
	if (light.isRectAreaLight) return FBX_LIGHT_AREA;
	return FBX_LIGHT_POINT;
}
/**
* @param {object} ctx
* @param {FBXElem} ctx.parent
* @param {Light}   ctx.light
* @param {bigint}  ctx.attrUid
* @param {TemplateBundle} ctx.templates
*/
function writeLightAttribute({ parent, light, attrUid, templates }) {
	const node = parent.addEmpty("NodeAttribute");
	node.addInt64(attrUid);
	node.addString(fbxNameClass(light.name || "Light", "NodeAttribute"));
	node.addString("Light");
	elemDataSingleInt32(node, "GeometryVersion", 124);
	const tmpl = templateInit(templates, "NodeAttribute");
	const props = elemProperties(node);
	templateSet(tmpl, props, "p_enum", "LightType", lightTypeFor(light));
	templateSet(tmpl, props, "p_bool", "CastLight", !light.isAmbientLight);
	const color = light.color || {
		r: 1,
		g: 1,
		b: 1
	};
	templateSet(tmpl, props, "p_color", "Color", [
		color.r,
		color.g,
		color.b
	], { animatable: true });
	templateSet(tmpl, props, "p_number", "Intensity", (light.intensity ?? 1) * 100, { animatable: true });
	templateSet(tmpl, props, "p_enum", "DecayType", 2);
	templateSet(tmpl, props, "p_double", "DecayStart", 25);
	templateSet(tmpl, props, "p_bool", "CastShadows", light.castShadow === true);
	templateSet(tmpl, props, "p_color", "ShadowColor", [
		0,
		0,
		0
	], { animatable: true });
	if (light.isSpotLight) {
		const outerDeg = (light.angle ?? Math.PI / 3) * RAD_TO_DEG;
		const innerDeg = outerDeg * (1 - Math.min(1, Math.max(0, light.penumbra ?? 0)));
		templateSet(tmpl, props, "p_double", "OuterAngle", outerDeg);
		templateSet(tmpl, props, "p_double", "InnerAngle", innerDeg);
	}
	if (light.isPointLight || light.isSpotLight) {
		const dist = light.distance ?? 0;
		templateSet(tmpl, props, "p_double", "FarAttenuationEnd", dist);
		templateSet(tmpl, props, "p_bool", "EnableFarAttenuation", dist > 0);
	}
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/builders/objects/camera.js
/**
* three.js Camera → FBX `NodeAttribute::Camera`.
*
* Supported types:
*   PerspectiveCamera   → CameraProjectionType=0
*   OrthographicCamera  → CameraProjectionType=1  (FBXLoader logs a warning
*                                                  and falls back to Object3D;
*                                                  Maya / Unreal handle it.)
*
* FBXLoader.js:1140-1227 reads:
*   CameraProjectionType   → 0 perspective / 1 orthographic
*   NearPlane              → near / 1000   ← three.js FBXLoader quirk
*   FarPlane               → far  / 1000   ← same quirk
*   AspectWidth / Height   → aspect = w/h
*   FieldOfView            → fov (degrees, used directly)
*   FocalLength            → camera.setFocalLength()
*
* On the near/far division: FBXLoader hardcodes /1000, presumably assuming
* the file is in millimeters. We written values are
* `near × settings.unitScale`. Three.js → FBX → three.js round-trip of
* near/far is off by 1/(1000/unitScale), a known three.js FBXLoader issue.
*/
180 / Math.PI;
/**
* @param {object}      ctx
* @param {FBXElem}     ctx.parent
* @param {Camera}      ctx.camera
* @param {bigint}      ctx.attrUid
* @param {TemplateBundle} ctx.templates
* @param {object}      [ctx.settings]
*/
function writeCameraAttribute({ parent, camera, attrUid, templates, settings = {} }) {
	const node = parent.addEmpty("NodeAttribute");
	node.addInt64(attrUid);
	node.addString(fbxNameClass(camera.name || "Camera", "NodeAttribute"));
	node.addString("Camera");
	const tmpl = templateInit(templates, "NodeAttribute");
	const props = elemProperties(node);
	const isOrtho = camera.isOrthographicCamera === true;
	templateSet(tmpl, props, "p_enum", "CameraProjectionType", isOrtho ? 1 : 0);
	const aspect = camera.aspect ?? 16 / 9;
	const aspectW = settings.cameraAspectWidth ?? 1920;
	const aspectH = aspectW / aspect;
	templateSet(tmpl, props, "p_enum", "AspectRatioMode", 2);
	templateSet(tmpl, props, "p_double", "AspectWidth", aspectW);
	templateSet(tmpl, props, "p_double", "AspectHeight", aspectH);
	templateSet(tmpl, props, "p_double", "PixelAspectRatio", 1);
	const fovY = camera.fov ?? 50;
	const fovX = fovY * aspect;
	templateSet(tmpl, props, "p_fov", "FieldOfView", fovY, { animatable: true });
	templateSet(tmpl, props, "p_fov_x", "FieldOfViewX", fovX, { animatable: true });
	templateSet(tmpl, props, "p_fov_y", "FieldOfViewY", fovY, { animatable: true });
	templateSet(tmpl, props, "p_double", "FocalLength", camera.getFocalLength ? camera.getFocalLength() : 35, { animatable: true });
	const unitScale = settings.unitScale ?? 1;
	const near = (camera.near ?? .1) * unitScale;
	const far = (camera.far ?? 2e3) * unitScale;
	templateSet(tmpl, props, "p_double", "NearPlane", near);
	templateSet(tmpl, props, "p_double", "FarPlane", far);
	templateSet(tmpl, props, "p_enum", "BackPlaneDistanceMode", 1);
	templateSet(tmpl, props, "p_double", "BackPlaneDistance", far, { animatable: true });
	if (isOrtho) templateSet(tmpl, props, "p_double", "OrthoZoom", (camera.right ?? 1) - (camera.left ?? -1));
	elemDataSingleString(node, "TypeFlags", "Camera");
	elemDataSingleInt32(node, "GeometryVersion", 124);
	emitVecChild(node, "Position", [
		0,
		0,
		0
	]);
	emitVecChild(node, "Up", [
		0,
		1,
		0
	]);
	emitVecChild(node, "LookAt", [
		0,
		0,
		-1
	]);
	elemDataSingleInt32(node, "ShowInfoOnMoving", 1);
	elemDataSingleInt32(node, "ShowAudio", 0);
	emitVecChild(node, "AudioColor", [
		0,
		1,
		0
	]);
	elemDataSingleFloat64(node, "CameraOrthoZoom", 1);
}
function emitVecChild(parent, name, [x, y, z]) {
	const e = parent.addEmpty(name);
	e.addFloat64(x);
	e.addFloat64(y);
	e.addFloat64(z);
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/builders/objects/texture.js
/**
* Emit FBX `Texture` + `Video` nodes for a three.js Texture.
*
* Texture node carries UV transform, wrap modes and the filename hint
* FBXLoader uses to pick a TextureLoader. Video node carries the actual
* `Content` bytes when embedded.
*
* Connection direction (handled in textureCollector / SceneCollector):
*   OO  Video   → Texture   (FBXLoader.loadTexture reads `connections.get(tex.id).children[0]`)
*   OP  Texture → Material  (relationship name picks the material slot)
*/
var THREE_REPEAT_WRAPPING = 1e3;
var THREE_MIRRORED_REPEAT = 1002;
function fbxWrapModeFor(threeWrap) {
	if (threeWrap === THREE_REPEAT_WRAPPING || threeWrap === THREE_MIRRORED_REPEAT) return 0;
	return 1;
}
/**
* @param {object} ctx
* @param {FBXElem} ctx.parent
* @param {object}  ctx.textureEntry  output of textureCollector.collectTextures
* @param {TemplateBundle} ctx.templates
*/
function writeTexture({ parent, textureEntry, templates }) {
	const tex = textureEntry.texture;
	const fileName = textureEntry.fileName;
	const identityName = tex.name || `texture_${textureEntry.texUid}`;
	const node = parent.addEmpty("Texture");
	node.addInt64(textureEntry.texUid);
	node.addString(fbxNameClass(identityName, "Texture"));
	node.addString("");
	elemDataSingleString(node, "Type", "TextureVideoClip");
	elemDataSingleInt32(node, "Version", 202);
	elemDataSingleString(node, "TextureName", fbxNameClass(identityName, "Texture"));
	elemDataSingleString(node, "Media", fbxNameClass(identityName, "Video"));
	elemDataSingleString(node, "FileName", fileName);
	elemDataSingleString(node, "RelativeFilename", fileName);
	const tmpl = templateInit(templates, "Texture");
	const props = elemProperties(node);
	templateSet(tmpl, props, "p_enum", "AlphaSource", textureEntry.imageBytes != null ? 2 : 0);
	templateSet(tmpl, props, "p_bool", "PremultiplyAlpha", false);
	templateSet(tmpl, props, "p_enum", "CurrentMappingType", 0);
	templateSet(tmpl, props, "p_enum", "WrapModeU", fbxWrapModeFor(tex.wrapS));
	templateSet(tmpl, props, "p_enum", "WrapModeV", fbxWrapModeFor(tex.wrapT));
	const off = tex.offset || {
		x: 0,
		y: 0
	};
	const rep = tex.repeat || {
		x: 1,
		y: 1
	};
	const rot = tex.rotation ?? 0;
	templateSet(tmpl, props, "p_vector_3d", "Translation", [
		off.x,
		off.y,
		0
	]);
	templateSet(tmpl, props, "p_vector_3d", "Rotation", [
		0,
		0,
		-rot
	]);
	templateSet(tmpl, props, "p_vector_3d", "Scaling", [
		rep.x,
		rep.y,
		1
	]);
	templateSet(tmpl, props, "p_bool", "UseMaterial", true);
	templateSet(tmpl, props, "p_bool", "UseMipMap", false);
}
/**
* Emit the Video node carrying (optionally) the embedded image bytes.
*/
function writeVideo({ parent, textureEntry, templates }) {
	const fileName = textureEntry.fileName;
	const imageBytes = textureEntry.imageBytes;
	const identityName = textureEntry.texture.name || `texture_${textureEntry.vidUid}`;
	const node = parent.addEmpty("Video");
	node.addInt64(textureEntry.vidUid);
	node.addString(fbxNameClass(identityName, "Video"));
	node.addString("Clip");
	elemDataSingleString(node, "Type", "Clip");
	templateSet(templateInit(templates, "Video"), elemProperties(node), "p_string_url", "Path", fileName);
	elemDataSingleInt32(node, "UseMipMap", 0);
	elemDataSingleString(node, "Filename", fileName);
	elemDataSingleString(node, "RelativeFilename", fileName);
	if (imageBytes != null) elemDataSingleBytes(node, "Content", imageBytes);
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/data/textureEncoder.js
/**
* Minimal PNG encoder + canvas-based fallback for converting three.js
* textures into bytes that FBX can embed.
*
* Why custom: GLTFExporter uses HTMLCanvasElement.toBlob, which is browser-
* only. Our exporter has to also work in Node for tests. DataTexture
* (raw pixels in a Uint8Array) is the only thing we can reliably encode in
* Node without a JSDOM/canvas-node setup, so we write a tiny PNG encoder
* for that path. Browser textures (HTMLImageElement / ImageBitmap / canvas
* sources) still go through the canvas path.
*/
var PNG_SIGNATURE = new Uint8Array([
	137,
	80,
	78,
	71,
	13,
	10,
	26,
	10
]);
var _crcTable = null;
function ensureCrcTable() {
	if (_crcTable) return _crcTable;
	const t = /* @__PURE__ */ new Uint32Array(256);
	for (let n = 0; n < 256; n++) {
		let c = n;
		for (let k = 0; k < 8; k++) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
		t[n] = c >>> 0;
	}
	_crcTable = t;
	return t;
}
function crc32(buf) {
	const t = ensureCrcTable();
	let crc = 4294967295;
	for (let i = 0; i < buf.length; i++) crc = (t[(crc ^ buf[i]) & 255] ^ crc >>> 8) >>> 0;
	return (crc ^ 4294967295) >>> 0;
}
function writeChunk(type, data) {
	const typeBytes = new TextEncoder().encode(type);
	if (typeBytes.length !== 4) throw new Error(`PNG chunk type must be 4 bytes, got ${type}`);
	const out = new Uint8Array(8 + data.length + 4);
	const dv = new DataView(out.buffer);
	dv.setUint32(0, data.length, false);
	out.set(typeBytes, 4);
	out.set(data, 8);
	const crcBuf = new Uint8Array(4 + data.length);
	crcBuf.set(typeBytes, 0);
	crcBuf.set(data, 4);
	dv.setUint32(8 + data.length, crc32(crcBuf), false);
	return out;
}
function concat(buffers) {
	let n = 0;
	for (const b of buffers) n += b.length;
	const out = new Uint8Array(n);
	let offset = 0;
	for (const b of buffers) {
		out.set(b, offset);
		offset += b.length;
	}
	return out;
}
/**
* Encode an RGBA8 pixel buffer to a PNG bytes blob.
*
* Input: `rgba` is a Uint8Array of length `width × height × 4` with
* row-major layout (row 0 at the top — same convention as the canvas
* 2D context and three.js `DataTexture.image.data` when `flipY === false`).
*/
function encodeRGBA8PNG(rgba, width, height) {
	if (rgba.length !== width * height * 4) throw new Error(`PNG: expected ${width * height * 4} RGBA bytes, got ${rgba.length}`);
	const stride = width * 4;
	const raw = new Uint8Array(height * (1 + stride));
	for (let y = 0; y < height; y++) {
		raw[y * (1 + stride)] = 0;
		raw.set(rgba.subarray(y * stride, (y + 1) * stride), y * (1 + stride) + 1);
	}
	const idat = zlibSync(raw, { level: 6 });
	const ihdr = /* @__PURE__ */ new Uint8Array(13);
	const ihdrView = new DataView(ihdr.buffer);
	ihdrView.setUint32(0, width, false);
	ihdrView.setUint32(4, height, false);
	ihdr[8] = 8;
	ihdr[9] = 6;
	ihdr[10] = 0;
	ihdr[11] = 0;
	ihdr[12] = 0;
	return concat([
		PNG_SIGNATURE,
		writeChunk("IHDR", ihdr),
		writeChunk("IDAT", idat),
		writeChunk("IEND", /* @__PURE__ */ new Uint8Array(0))
	]);
}
/**
* Encode any three.js Texture to PNG bytes.
*
* @returns {Promise<{ bytes: Uint8Array, extension: string }>}
*/
async function encodeTexture(texture) {
	if (texture.isDataTexture || texture.image && texture.image.data instanceof Uint8Array) {
		const { data, width, height } = texture.image;
		if (data.length !== width * height * 4) throw new Error(`DataTexture must be RGBAFormat / UnsignedByteType for PNG embedding (got data ${data.length} bytes for ${width}×${height}; expected ${width * height * 4})`);
		return {
			bytes: encodeRGBA8PNG(data, width, height),
			extension: "png"
		};
	}
	const src = texture.image;
	if (!src) throw new Error("Texture has no image source");
	if (typeof OffscreenCanvas !== "undefined") {
		const w = src.width || src.naturalWidth || 0;
		const h = src.height || src.naturalHeight || 0;
		if (!w || !h) throw new Error(`Texture image has zero size (${w}×${h})`);
		const canvas = new OffscreenCanvas(w, h);
		canvas.getContext("2d").drawImage(src, 0, 0);
		const blob = await canvas.convertToBlob({ type: "image/png" });
		return {
			bytes: new Uint8Array(await blob.arrayBuffer()),
			extension: "png"
		};
	}
	if (typeof document !== "undefined") {
		const w = src.width || src.naturalWidth || 0;
		const h = src.height || src.naturalHeight || 0;
		if (!w || !h) throw new Error(`Texture image has zero size (${w}×${h})`);
		const canvas = document.createElement("canvas");
		canvas.width = w;
		canvas.height = h;
		canvas.getContext("2d").drawImage(src, 0, 0);
		return await new Promise((resolve, reject) => {
			canvas.toBlob(async (blob) => {
				if (!blob) return reject(/* @__PURE__ */ new Error("canvas.toBlob returned null"));
				resolve({
					bytes: new Uint8Array(await blob.arrayBuffer()),
					extension: "png"
				});
			}, "image/png");
		});
	}
	throw new Error("Cannot encode texture: not a DataTexture and no canvas API available. In Node, use THREE.DataTexture; in browser, ensure canvas is supported.");
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/data/textureCollector.js
/**
* Detect textures on three.js materials and build a plan of FBX
* Texture + Video records to emit.
*
* Three.js material slot → FBX property name mapping is derived from
* FBXLoader.parseParameters (FBXLoader.js:668-723) — we round-trip with
* the same names the loader recognises.
*
* Texture encoding is asynchronous (canvas.toBlob is async) so this module
* exposes two phases:
*   - collectTextures(...)        synchronous: detect, allocate UIDs, build
*                                  connections.
*   - encodeTextures(plan)        async: fills in the per-texture image
*                                  bytes by calling textureEncoder.encodeTexture.
*/
var TEXTURE_SLOTS = {
	map: "DiffuseColor",
	emissiveMap: "EmissiveColor",
	normalMap: "NormalMap",
	bumpMap: "Bump",
	alphaMap: "TransparentColor",
	specularMap: "SpecularColor",
	aoMap: "Maya|TEX_ao_map",
	displacementMap: "DisplacementColor",
	envMap: "ReflectionColor"
};
/**
* Synchronously detect every texture used by `materials` and allocate the
* FBX-side UIDs + connections. The texture-image bytes are filled in later
* by `encodeTextures` (async).
*
* @param {object} ctx
* @param {Map<Material, {uid: bigint}>} ctx.materials  output of SceneCollector
* @param {UidRegistry}    ctx.uids
* @param {TemplateBundle} ctx.templates
* @param {Array<[string, bigint, bigint, string?]>} ctx.connections
* @returns {object} plan — `{ textures: Map<Texture, entry> }`
*/
function collectTextures({ materials, uids, templates, connections }) {
	/** @type {Map<Texture, {texUid, vidUid, slotName, materials, image?, extension?, name}>} */
	const textures = /* @__PURE__ */ new Map();
	for (const [material, matEntry] of materials) for (const slot of Object.keys(TEXTURE_SLOTS)) {
		const tex = material[slot];
		if (!tex || !tex.isTexture) continue;
		let entry = textures.get(tex);
		if (!entry) {
			const tName = tex.name || `texture_${textures.size}`;
			entry = {
				texUid: uids.get(textureKey(tex.uuid)),
				vidUid: uids.get(videoKey(tex.uuid)),
				texture: tex,
				slotName: slot,
				fileName: `${sanitizeFilename(tName)}.png`,
				imageBytes: null,
				extension: "png"
			};
			textures.set(tex, entry);
			templates.register(textureTemplate({})).users += 1;
			templates.register(videoTemplate({})).users += 1;
			connections.push([
				"OO",
				entry.vidUid,
				entry.texUid
			]);
		}
		const fbxProp = TEXTURE_SLOTS[slot];
		connections.push([
			"OP",
			entry.texUid,
			matEntry.uid,
			fbxProp
		]);
	}
	return { textures };
}
/**
* Asynchronously encode every texture in the plan. Run before passing the
* plan to writeFBX so the Video Content bytes are populated.
*/
async function encodeTextures(plan) {
	if (!plan || !plan.textures) return;
	await Promise.all([...plan.textures.values()].map(async (entry) => {
		try {
			const result = await encodeTexture(entry.texture);
			entry.imageBytes = result.bytes;
			entry.extension = result.extension;
			if (entry.fileName && !entry.fileName.endsWith(`.${entry.extension}`)) entry.fileName = entry.fileName.replace(/\.[^.]+$/, "") + "." + entry.extension;
		} catch (err) {
			console.warn(`fbx-exporter-three: failed to embed texture "${entry.texture.name || "<unnamed>"}": ${err.message}`);
			entry.imageBytes = null;
		}
	}));
}
function sanitizeFilename(name) {
	return String(name).replace(/[^a-zA-Z0-9_\-]/g, "_");
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/data/SceneCollector.js
/**
* Walk a three.js scene, classify each object into FBX entity categories,
* dedupe shared BufferGeometry / Material instances, allocate UIDs, register
* template users, and build the OO/OP connection graph.
*/
var _tmpBoneWorld = new Matrix4();
new Matrix4();
var _tmpClusterTransform = new Matrix4();
function modelSubtypeFor(object) {
	if (object.isBone) return "LimbNode";
	if (object.isMesh) return "Mesh";
	if (object.isLight && !object.isAmbientLight) return "Light";
	if (object.isCamera) return "Camera";
	return "Null";
}
function isExportableNode(object, settings) {
	if (object.isScene) return false;
	if (settings && settings.onlyVisible && object.visible === false) return false;
	if (settings && typeof settings.objectFilter === "function" && settings.objectFilter(object) === false) return false;
	return true;
}
/**
* Build the export plan for `input`. Caller owns the result; pass it through
* to the builders.
*/
function collectScene(input, settings = {}) {
	settings = resolvePreset(settings);
	const transformCtx = buildTransformContext(settings);
	if (transformCtx.bake && !transformCtx.isIdentity && !settings._suppressBakeWarning) {
		let unsafe = false;
		input.traverse((o) => {
			if (unsafe || o.isScene) return;
			if (o.isSkinnedMesh || o.isLight || o.isCamera) {
				unsafe = true;
				return;
			}
			if (o.isMesh && (o.position.lengthSq() > 1e-12 || o.quaternion.x ** 2 + o.quaternion.y ** 2 + o.quaternion.z ** 2 > 1e-12)) unsafe = true;
		});
		if (unsafe) console.warn("fbx-exporter-three: bakeSpaceTransform=true currently bakes only Vertices+Normals. The scene contains object transforms / skinning / animation / lights / cameras whose matrices will NOT be baked, leaving the output file internally inconsistent. Pass { bakeSpaceTransform: false } unless your scene is a single mesh at the origin.");
	}
	const uids = new UidRegistry();
	const templates = new TemplateBundle();
	const meshes = [];
	const empties = [];
	const lights = [];
	const cameras = [];
	const lightTargets = [];
	const bones = /* @__PURE__ */ new Map();
	const skins = [];
	const geometries = /* @__PURE__ */ new Map();
	const materials = /* @__PURE__ */ new Map();
	const connections = [];
	input.updateMatrixWorld(true);
	templates.register(globalSettingsTemplate(settings)).users = 1;
	input.traverse((object) => {
		if (!isExportableNode(object, settings)) return;
		const subtype = modelSubtypeFor(object);
		const objUid = uids.get(modelKey(object.uuid));
		templates.register(modelTemplate(settings)).users += 1;
		if (subtype === "Mesh") {
			const geomEntry = ensureGeometry(object.geometry);
			const { entries: matEntries, slotRemap } = collectMaterials(object);
			const meshEntry = {
				object,
				uid: objUid,
				geometry: object.geometry,
				geomUid: geomEntry.uid,
				materials: matEntries,
				slotRemap,
				skin: null,
				morph: null
			};
			meshes.push(meshEntry);
			if (object.isSkinnedMesh && object.skeleton && object.skeleton.bones.length > 0) meshEntry.skin = collectSkin(object);
			meshEntry.morph = collectMorph({
				mesh: object,
				uids,
				templates
			});
		} else if (subtype === "LimbNode") ensureBone(object);
		else if (subtype === "Light") {
			const attrUid = uids.get(`${entityKey("object", object.uuid)}|NodeAttr|Light`);
			templates.register(lightTemplate(settings)).users += 1;
			let targetUid = null;
			if ((object.isDirectionalLight || object.isSpotLight) && object.target) targetUid = ensureLightTarget(object.target);
			lights.push({
				object,
				uid: objUid,
				attrUid,
				targetUid
			});
		} else if (subtype === "Camera") {
			const attrUid = uids.get(`${entityKey("object", object.uuid)}|NodeAttr|Camera`);
			templates.register(cameraTemplate(settings)).users += 1;
			cameras.push({
				object,
				uid: objUid,
				attrUid
			});
		} else {
			const attrUid = uids.get(`${entityKey("object", object.uuid)}|NodeAttr|Null`);
			templates.register(nullTemplate(settings)).users += 1;
			empties.push({
				object,
				uid: objUid,
				nodeAttrUid: attrUid
			});
		}
	});
	const traversedUids = /* @__PURE__ */ new Set();
	input.traverse((object) => {
		if (!isExportableNode(object, settings)) return;
		const childUid = uids.get(modelKey(object.uuid));
		traversedUids.add(childUid);
		let parentUid = 0n;
		if (object.parent && isExportableNode(object.parent, settings)) parentUid = uids.get(modelKey(object.parent.uuid));
		connections.push([
			"OO",
			childUid,
			parentUid
		]);
	});
	for (const [bone, entry] of bones) {
		if (traversedUids.has(entry.uid)) continue;
		let parentUid = 0n;
		if (bone.parent && isExportableNode(bone.parent, settings)) {
			const pUid = uids.get(modelKey(bone.parent.uuid));
			if (traversedUids.has(pUid) || bones.has(bone.parent)) parentUid = pUid;
		}
		connections.push([
			"OO",
			entry.uid,
			parentUid
		]);
	}
	for (const e of empties) connections.push([
		"OO",
		e.nodeAttrUid,
		e.uid
	]);
	for (const [, entry] of bones) connections.push([
		"OO",
		entry.attrUid,
		entry.uid
	]);
	for (const e of lights) connections.push([
		"OO",
		e.attrUid,
		e.uid
	]);
	for (const e of cameras) connections.push([
		"OO",
		e.attrUid,
		e.uid
	]);
	for (const t of lightTargets) {
		if (traversedUids.has(t.uid)) continue;
		t.auxiliary = true;
		t.nodeAttrUid = uids.get(`${entityKey("object", t.target.uuid)}|NodeAttr|Null`);
		templates.register(nullTemplate(settings)).users += 1;
		templates.register(modelTemplate(settings)).users += 1;
		connections.push([
			"OO",
			t.nodeAttrUid,
			t.uid
		]);
		connections.push([
			"OO",
			t.uid,
			0n
		]);
	}
	for (const l of lights) if (l.targetUid != null) connections.push([
		"OP",
		l.targetUid,
		l.uid,
		"LookAtProperty"
	]);
	for (const m of meshes) connections.push([
		"OO",
		m.geomUid,
		m.uid
	]);
	for (const m of meshes) for (const matEntry of m.materials) connections.push([
		"OO",
		matEntry.uid,
		m.uid
	]);
	for (const m of meshes) {
		if (!m.skin) continue;
		connections.push([
			"OO",
			m.skin.deformerUid,
			m.geomUid
		]);
		for (const c of m.skin.clusters) {
			connections.push([
				"OO",
				c.clusterUid,
				m.skin.deformerUid
			]);
			connections.push([
				"OO",
				c.boneEntry.uid,
				c.clusterUid
			]);
		}
	}
	for (const m of meshes) {
		if (!m.morph) continue;
		connections.push([
			"OO",
			m.morph.blendShapeUid,
			m.geomUid
		]);
		for (const channel of m.morph.channels) {
			connections.push([
				"OO",
				channel.channelUid,
				m.morph.blendShapeUid
			]);
			connections.push([
				"OO",
				channel.shapeGeomUid,
				channel.channelUid
			]);
		}
	}
	const textures = collectTextures({
		materials,
		uids,
		templates,
		connections
	});
	let clips;
	if (settings.includeAnimations === false) clips = [];
	else if (settings.animations) clips = settings.animations;
	else clips = collectAnimationClips(input);
	const animStacks = buildAnimationPlan({
		root: input,
		clips,
		uids,
		templates,
		settings,
		meshes
	});
	for (const stack of animStacks) for (const cn of stack.curveNodes) if (cn.targetUid == null) cn.targetUid = uids.get(modelKey(cn.targetNode.uuid));
	for (const stack of animStacks) {
		connections.push([
			"OO",
			stack.layerUid,
			stack.stackUid
		]);
		for (const cn of stack.curveNodes) {
			connections.push([
				"OO",
				cn.curveNodeUid,
				stack.layerUid
			]);
			connections.push([
				"OP",
				cn.curveNodeUid,
				cn.targetUid,
				cn.fbxProp
			]);
			for (const curve of cn.curves) connections.push([
				"OP",
				curve.uid,
				cn.curveNodeUid,
				`d|${curve.axis}`
			]);
		}
	}
	return {
		settings,
		uids,
		templates,
		meshes,
		empties,
		bones,
		skins,
		geometries,
		materials,
		lights,
		cameras,
		lightTargets,
		textures,
		animStacks,
		connections,
		rootInput: input,
		transformCtx
	};
	function ensureGeometry(geometry) {
		let entry = geometries.get(geometry);
		if (entry) {
			entry.refCount++;
			return entry;
		}
		const key = geometryKey(geometry.uuid);
		const uid = uids.get(key);
		templates.register(geometryTemplate(settings)).users += 1;
		entry = {
			uid,
			key,
			refCount: 1
		};
		geometries.set(geometry, entry);
		return entry;
	}
	function ensureLightTarget(target) {
		const existing = lightTargets.find((t) => t.target === target);
		if (existing) return existing.uid;
		const uid = uids.get(modelKey(target.uuid));
		lightTargets.push({
			target,
			uid,
			nodeAttrUid: null,
			auxiliary: false
		});
		return uid;
	}
	function ensureBone(bone) {
		let entry = bones.get(bone);
		if (entry) return entry;
		const uid = uids.get(modelKey(bone.uuid));
		const attrUid = uids.get(boneAttrKey(bone.uuid, bone.uuid));
		templates.register(boneTemplate(settings)).users += 1;
		entry = {
			uid,
			attrUid
		};
		bones.set(bone, entry);
		return entry;
	}
	function collectSkin(skinnedMesh) {
		const skeleton = skinnedMesh.skeleton;
		const skeletonBones = skeleton.bones;
		const boneInverses = skeleton.boneInverses;
		const bindMatrix = skinnedMesh.bindMatrix;
		const deformerUid = uids.get(skinDeformerKey(skinnedMesh.uuid, skinnedMesh.geometry.uuid));
		const bindPoseUid = uids.get(bindPoseKey(skinnedMesh.uuid, skinnedMesh.geometry.uuid));
		templates.register(deformerTemplate(settings)).users += 1;
		templates.register(poseTemplate(settings)).users += 1;
		const bindWorldByBone = /* @__PURE__ */ new Map();
		for (let i = 0; i < skeletonBones.length; i++) {
			const b = skeletonBones[i];
			if (b && !bindWorldByBone.has(b)) bindWorldByBone.set(b, new Matrix4().copy(boneInverses[i]).invert());
		}
		for (const bone of skeletonBones) {
			if (!bone) continue;
			const entry = ensureBone(bone);
			if (entry.bindLocalMatrix) continue;
			const bw = bindWorldByBone.get(bone);
			const parent = bone.parent;
			let parentBindWorld;
			if (parent && bindWorldByBone.has(parent)) parentBindWorld = bindWorldByBone.get(parent);
			else if (parent) parentBindWorld = parent.matrixWorld;
			entry.bindLocalMatrix = parentBindWorld ? new Matrix4().copy(parentBindWorld).invert().multiply(bw) : bw.clone();
		}
		const clusters = [];
		for (let i = 0; i < skeletonBones.length; i++) {
			const bone = skeletonBones[i];
			if (!bone) continue;
			const boneEntry = ensureBone(bone);
			const cKey = clusterKey(skinnedMesh.uuid, skinnedMesh.geometry.uuid, bone.uuid);
			const cUid = uids.get(cKey);
			templates.register(deformerTemplate(settings)).users += 1;
			const { indices, weights } = sliceBoneInfluences(skinnedMesh.geometry, i);
			_tmpBoneWorld.copy(boneInverses[i]).invert();
			_tmpClusterTransform.copy(boneInverses[i]).multiply(bindMatrix);
			clusters.push({
				boneIdx: i,
				bone,
				boneEntry,
				clusterUid: cUid,
				clusterKey: cKey,
				indices,
				weights,
				transform: _tmpClusterTransform.clone(),
				transformLink: _tmpBoneWorld.clone()
			});
		}
		const skinEntry = {
			skinnedMesh,
			deformerUid,
			bindPoseUid,
			bindMatrix: bindMatrix.clone(),
			clusters
		};
		skins.push(skinEntry);
		return skinEntry;
	}
	function collectMaterials(mesh) {
		const raw = mesh.material;
		const list = Array.isArray(raw) ? raw : raw ? [raw] : [];
		const entries = [];
		const firstFbxIndexForMaterial = /* @__PURE__ */ new Map();
		const slotRemap = new Array(list.length);
		let fbxIdx = 0;
		for (let i = 0; i < list.length; i++) {
			const mat = list[i];
			if (!mat) {
				slotRemap[i] = 0;
				continue;
			}
			const cached = firstFbxIndexForMaterial.get(mat);
			if (cached !== void 0) {
				slotRemap[i] = cached;
				continue;
			}
			let entry = materials.get(mat);
			if (!entry) {
				const key = materialKey(mat.uuid);
				const uid = uids.get(key);
				templates.register(materialTemplate(settings)).users += 1;
				entry = {
					uid,
					key,
					refCount: 0
				};
				materials.set(mat, entry);
			}
			entry.refCount++;
			firstFbxIndexForMaterial.set(mat, fbxIdx);
			slotRemap[i] = fbxIdx;
			entries.push({
				material: mat,
				uid: entry.uid,
				slot: fbxIdx
			});
			fbxIdx++;
		}
		return {
			entries,
			slotRemap
		};
	}
}
/**
* For a given bone index `bi`, sweep the geometry's skinIndex/skinWeight
* attributes and collect every (vertex, weight) pair where the bone is one
* of that vertex's 4 influences and weight > 0.
*/
function sliceBoneInfluences(geometry, boneIdx) {
	const idxAttr = geometry.attributes.skinIndex;
	const wAttr = geometry.attributes.skinWeight;
	if (!idxAttr || !wAttr) return {
		indices: [],
		weights: []
	};
	const count = idxAttr.count;
	const indices = [];
	const weights = [];
	for (let v = 0; v < count; v++) for (let k = 0; k < 4; k++) {
		if ((k === 0 ? idxAttr.getX(v) : k === 1 ? idxAttr.getY(v) : k === 2 ? idxAttr.getZ(v) : idxAttr.getW(v)) !== boneIdx) continue;
		const w = k === 0 ? wAttr.getX(v) : k === 1 ? wAttr.getY(v) : k === 2 ? wAttr.getZ(v) : wAttr.getW(v);
		if (w > 0) {
			indices.push(v);
			weights.push(w);
		}
	}
	return {
		indices,
		weights
	};
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/FBXWriter.js
/**
* Pipeline orchestrator — produces a complete FBX `FBXElem` tree from a
* collected SceneData, then hands it to `encodeBinaryFBX`.
*
* Drives the per-section builders in order:
*   1. fbx_header_elements      → header.js
*   2. fbx_documents_elements   → header.js (writeDocuments)
*   3. fbx_references_elements  → header.js
*   4. fbx_definitions_elements → definitions.js
*   5. fbx_objects_elements     → builders/objects/*
*   6. fbx_connections_elements → connections.js
*   7. fbx_takes_elements       → empty Takes stub
*/
var _tmpWorldPos = new Vector3();
/**
* @param {ReturnType<import('./data/SceneCollector.js').collectScene>} sceneData
* @returns {Uint8Array}
*/
function writeFBX(sceneData) {
	const { settings, templates, meshes, empties, bones, lights, cameras, lightTargets, materials, textures, animStacks, connections, rootInput } = sceneData;
	const version = settings.version ?? 7400;
	const root = new FBXElem("");
	writeHeaderSection({
		root,
		settings: {
			...settings,
			version
		},
		sceneName: rootInput.name || "Scene"
	});
	writeDefinitionsSection({
		root,
		templates
	});
	const objectsElem = root.addEmpty("Objects");
	for (const e of empties) writeNullAttribute({
		parent: objectsElem,
		name: e.object.name,
		uid: e.nodeAttrUid,
		templates
	});
	for (const [bone, entry] of bones) writeBoneAttribute({
		parent: objectsElem,
		bone,
		attrUid: entry.attrUid,
		templates
	});
	for (const l of lights) writeLightAttribute({
		parent: objectsElem,
		light: l.object,
		attrUid: l.attrUid,
		templates
	});
	for (const c of cameras) writeCameraAttribute({
		parent: objectsElem,
		camera: c.object,
		attrUid: c.attrUid,
		templates,
		settings
	});
	if (lightTargets) for (const t of lightTargets) {
		if (!t.auxiliary) continue;
		writeNullAttribute({
			parent: objectsElem,
			name: t.target.name || "Light Target",
			uid: t.nodeAttrUid,
			templates
		});
	}
	const writtenGeometries = /* @__PURE__ */ new Set();
	for (const m of meshes) {
		if (writtenGeometries.has(m.geomUid)) continue;
		writtenGeometries.add(m.geomUid);
		writeGeometry({
			parent: objectsElem,
			geometry: m.geometry,
			uid: m.geomUid,
			name: m.geometry.name || m.object.name,
			templates,
			materialSlotCount: m.materials.length,
			groups: m.geometry.groups || [],
			slotRemap: m.slotRemap,
			transformCtx: sceneData.transformCtx
		});
	}
	const writtenModelUids = /* @__PURE__ */ new Set();
	const lightsWithTarget = /* @__PURE__ */ new Set();
	for (const l of lights) if (l.targetUid != null) lightsWithTarget.add(l.object);
	const exportUserData = !!settings.customProperties;
	rootInput.traverse((object) => {
		if (object.isScene) return;
		const meshEntry = meshes.find((mm) => mm.object === object);
		const emptyEntry = empties.find((ee) => ee.object === object);
		const lightEntry = lights.find((le) => le.object === object);
		const cameraEntry = cameras.find((ce) => ce.object === object);
		const boneEntry = bones.get(object);
		const uid = meshEntry?.uid ?? emptyEntry?.uid ?? lightEntry?.uid ?? cameraEntry?.uid ?? boneEntry?.uid;
		if (uid == null) return;
		const overrideMatrix = boneEntry?.bindLocalMatrix || void 0;
		writeModel({
			parent: objectsElem,
			object,
			uid,
			templates,
			hasLookAtTarget: lightsWithTarget.has(object),
			overrideMatrix,
			customProperties: exportUserData
		});
		writtenModelUids.add(uid);
	});
	if (lightTargets) for (const t of lightTargets) {
		if (!t.auxiliary) continue;
		t.target.updateMatrixWorld(true);
		t.target.getWorldPosition(_tmpWorldPos);
		writeModel({
			parent: objectsElem,
			object: t.target,
			uid: t.uid,
			templates,
			overrideTranslation: [
				_tmpWorldPos.x,
				_tmpWorldPos.y,
				_tmpWorldPos.z
			]
		});
		writtenModelUids.add(t.uid);
	}
	for (const [bone, entry] of bones) {
		if (writtenModelUids.has(entry.uid)) continue;
		writeModel({
			parent: objectsElem,
			object: bone,
			uid: entry.uid,
			templates
		});
	}
	for (const [material, entry] of materials) writeMaterial({
		parent: objectsElem,
		material,
		uid: entry.uid,
		templates
	});
	if (textures && textures.textures) {
		for (const [, entry] of textures.textures) writeTexture({
			parent: objectsElem,
			textureEntry: entry,
			templates
		});
		for (const [, entry] of textures.textures) writeVideo({
			parent: objectsElem,
			textureEntry: entry,
			templates
		});
	}
	writeAnimationNodes({
		parent: objectsElem,
		stacks: animStacks,
		templates
	});
	for (const m of meshes) {
		if (!m.morph) continue;
		writeMorph({
			parent: objectsElem,
			morphPlan: m.morph,
			templates
		});
	}
	for (const m of meshes) {
		if (!m.skin) continue;
		writeBindPose({
			parent: objectsElem,
			skin: m.skin,
			meshUid: m.uid,
			meshName: m.object.name
		});
		writeSkinDeformer({
			parent: objectsElem,
			skin: m.skin,
			armatureName: m.object.name || "Armature"
		});
	}
	writeConnectionsSection({
		root,
		connections
	});
	root.addEmpty("Takes").addEmpty("Current").addString("");
	return encodeBinaryFBX(root, { version });
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+fbx-exporter-three@1.0.1_@types+three@0.186.0_three@0.186.1/node_modules/@comfyorg/fbx-exporter-three/dist/FBXExporter.js
/**
* Public exporter facade — public API + plugin hook surface in the style of
* three.js's GLTFExporter (examples/jsm/exporters/GLTFExporter.js: class
* GLTFExporter at line 104).
*
* Usage:
*   const exporter = new FBXExporter();
*   const bytes = await exporter.parseAsync(scene, options);
*   fs.writeFileSync('out.fbx', bytes);
*
* Sync vs async — parseSync works for scenes with no textures OR with
* DataTextures only (our PNG encoder is synchronous). HTMLImageElement /
* ImageBitmap / canvas-backed Textures require the async `canvas.toBlob`
* pipeline; use parseAsync (or pass `options.embedTextures: false` to
* skip).
*/
var DEFAULT_OPTIONS = {
	version: 7400,
	fps: 24,
	embedTextures: true
};
var FBXExporter = class {
	pluginCallbacks = [];
	/** GLTFExporter-style plugin registration. */
	register(callback) {
		if (!this.pluginCallbacks.includes(callback)) this.pluginCallbacks.push(callback);
		return this;
	}
	unregister(callback) {
		const i = this.pluginCallbacks.indexOf(callback);
		if (i !== -1) this.pluginCallbacks.splice(i, 1);
		return this;
	}
	/**
	* Synchronous parse. Texture embedding only works for DataTextures
	* (encoded via the inline PNG encoder). HTMLImage / canvas textures must
	* go through parseAsync.
	*/
	parseSync(input, options = {}) {
		const settings = {
			...DEFAULT_OPTIONS,
			...options
		};
		const sceneData = collectScene(input, settings);
		if (settings.embedTextures !== false) encodeTexturesSyncOnly(sceneData);
		for (const cb of this.pluginCallbacks) cb(sceneData);
		return writeFBX(sceneData);
	}
	parse(input, onDone, onError, options) {
		this.parseAsync(input, options).then(onDone, onError ?? ((e) => {
			throw e;
		}));
	}
	/** Asynchronous parse — waits for canvas-based texture encodings. */
	async parseAsync(input, options = {}) {
		const settings = {
			...DEFAULT_OPTIONS,
			...options
		};
		const sceneData = collectScene(input, settings);
		if (settings.embedTextures !== false && sceneData.textures) await encodeTextures(sceneData.textures);
		for (const cb of this.pluginCallbacks) cb(sceneData);
		return writeFBX(sceneData);
	}
};
/**
* Synchronous variant of encodeTextures — only handles DataTextures. Any
* texture that would need canvas (HTMLImage / ImageBitmap / etc.) is left
* unencoded with a console warning.
*/
function encodeTexturesSyncOnly(sceneData) {
	if (!sceneData.textures || !sceneData.textures.textures) return;
	for (const [, entry] of sceneData.textures.textures) {
		const tex = entry.texture;
		if (tex.isDataTexture || tex.image && tex.image.data instanceof Uint8Array) try {
			const { data, width, height } = tex.image;
			entry.imageBytes = encodeRGBA8PNG(data, width, height);
			entry.extension = "png";
		} catch (err) {
			console.warn(`fbx-exporter-three: failed to encode DataTexture "${tex.name || "<unnamed>"}": ${err.message}`);
		}
		else console.warn(`fbx-exporter-three: skipping embed of texture "${tex.name || "<unnamed>"}" — parseSync only handles DataTextures. Use parseAsync to embed HTMLImage / canvas-backed textures.`);
	}
}
//#endregion
//#region packages/viewport3d/src/load3d/downloadBlob.ts
/** Starts a browser download of `blob` under `filename`. */
function downloadBlob(filename, blob) {
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = filename;
	link.style.display = "none";
	document.body.appendChild(link);
	link.click();
	document.body.removeChild(link);
	queueMicrotask(() => URL.revokeObjectURL(url));
}
//#endregion
//#region packages/viewport3d/src/load3d/ModelExporter.ts
var ModelExporter = class ModelExporter {
	static detectFormatFromURL(url) {
		try {
			const filenameParam = new URLSearchParams(url.split("?")[1]).get("filename");
			if (filenameParam) return filenameParam.split(".").pop()?.toLowerCase() || null;
		} catch (e) {
			console.error("Error parsing URL:", e);
		}
		return null;
	}
	static canUseDirectURL(url, format) {
		if (!url) return false;
		const urlFormat = ModelExporter.detectFormatFromURL(url);
		if (!urlFormat) return false;
		return urlFormat.toLowerCase() === format.toLowerCase();
	}
	static async downloadFromURL(url, desiredFilename) {
		const response = await fetch(url);
		if (!response.ok) throw new Error(`Failed to download file (HTTP ${response.status})`);
		downloadBlob(desiredFilename, await response.blob());
	}
	static async exportGLB(model, filename = "model.glb", originalURL) {
		if (originalURL && ModelExporter.canUseDirectURL(originalURL, "glb")) return ModelExporter.downloadFromURL(originalURL, filename);
		const exporter = new GLTFExporter();
		await new Promise((resolve) => setTimeout(resolve, 50));
		const result = await new Promise((resolve, reject) => {
			exporter.parse(model, (gltf) => {
				resolve(gltf);
			}, (error) => {
				reject(error);
			}, { binary: true });
		});
		await new Promise((resolve) => setTimeout(resolve, 50));
		ModelExporter.saveArrayBuffer(result, filename);
	}
	static async exportOBJ(model, filename = "model.obj", originalURL) {
		if (originalURL && ModelExporter.canUseDirectURL(originalURL, "obj")) return ModelExporter.downloadFromURL(originalURL, filename);
		const exporter = new OBJExporter();
		await new Promise((resolve) => setTimeout(resolve, 50));
		const result = exporter.parse(model);
		await new Promise((resolve) => setTimeout(resolve, 50));
		ModelExporter.saveString(result, filename);
	}
	static async exportFBX(model, filename = "model.fbx", originalURL) {
		if (originalURL && ModelExporter.canUseDirectURL(originalURL, "fbx")) return ModelExporter.downloadFromURL(originalURL, filename);
		const exporter = new FBXExporter();
		await new Promise((resolve) => setTimeout(resolve, 50));
		const bytes = await exporter.parseAsync(model);
		await new Promise((resolve) => setTimeout(resolve, 50));
		ModelExporter.saveArrayBuffer(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength), filename);
	}
	static async exportSTL(model, filename = "model.stl", originalURL) {
		if (originalURL && ModelExporter.canUseDirectURL(originalURL, "stl")) return ModelExporter.downloadFromURL(originalURL, filename);
		const exporter = new STLExporter();
		await new Promise((resolve) => setTimeout(resolve, 50));
		const result = exporter.parse(model);
		await new Promise((resolve) => setTimeout(resolve, 50));
		ModelExporter.saveString(result, filename);
	}
	static async exportDirect(originalURL, filename, format) {
		if (!originalURL) throw new Error(`No source file available to export as ${format}`);
		return ModelExporter.downloadFromURL(originalURL, filename);
	}
	static saveArrayBuffer(buffer, filename) {
		downloadBlob(filename, new Blob([buffer], { type: "application/octet-stream" }));
	}
	static saveString(text, filename) {
		downloadBlob(filename, new Blob([text], { type: "text/plain" }));
	}
};
//#endregion
//#region packages/viewport3d/src/load3d/ModelAdapter.ts
var DEFAULT_MODEL_CAPABILITIES = {
	fitToViewer: true,
	requiresMaterialRebuild: false,
	gizmoTransform: true,
	lighting: true,
	exportable: true,
	materialModes: [
		"original",
		"clay",
		"normal",
		"wireframe"
	],
	fitTargetSize: 5
};
var createAdapterRef = () => ({
	current: null,
	capabilities: null
});
async function fetchModelData(fetchApi, path, filename, signal) {
	const response = await fetchApi("/" + path.replace(/^api\//, "") + encodeURIComponent(filename), { signal });
	if (!response.ok) throw new Error(`Failed to fetch model: ${response.status}`);
	return response.arrayBuffer();
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+quad-wireframe-three@0.1.0_three@0.186.1/node_modules/@comfyorg/quad-wireframe-three/dist/gltf/ngonEncoding.js
var FB_NGON_ENCODING = "FB_ngon_encoding";
function hasNgonEncoding(object) {
	return object.userData?.gltfExtensions?.[FB_NGON_ENCODING] !== void 0;
}
function ngonEncodedFaceSizes(geometry) {
	const index = geometry.index?.array;
	const cornerCount = index ? index.length : positionAttributeOf(geometry).count;
	const triangleCount = Math.floor(cornerCount / 3);
	const sizes = [];
	let anchor = -1;
	for (let t = 0; t < triangleCount; t++) {
		const first = index ? index[t * 3] : t * 3;
		if (first === anchor) sizes[sizes.length - 1]++;
		else {
			anchor = first;
			sizes.push(3);
		}
	}
	return Uint32Array.from(sizes);
}
//#endregion
//#region packages/viewport3d/src/load3d/quadWireframe/adoptClonedModel.ts
function meshesOf(root) {
	const meshes = [];
	root.traverse((child) => {
		if (child instanceof Mesh) meshes.push(child);
	});
	return meshes;
}
function adoptClonedModel(clone, source, sourceOriginals, cloneOriginals) {
	const overlays = [];
	clone.traverse((child) => {
		if (child instanceof QuadWireframeOverlay) overlays.push(child);
	});
	for (const overlay of overlays) overlay.removeFromParent();
	const sourceMeshes = meshesOf(source);
	meshesOf(clone).forEach((mesh, i) => {
		const original = sourceOriginals.get(sourceMeshes[i]) ?? mesh.material;
		mesh.material = original;
		cloneOriginals?.set(mesh, original);
	});
}
//#endregion
//#region packages/viewport3d/src/load3d/cameraFromMatrices.ts
function computeCameraFromMatrices(extrinsics, intrinsics) {
	assertMatrixShape(extrinsics, 4, 4, "extrinsics");
	assertMatrixShape(intrinsics, 3, 3, "intrinsics");
	const r00 = extrinsics[0][0];
	const r01 = extrinsics[0][1];
	const r02 = extrinsics[0][2];
	const r10 = extrinsics[1][0];
	const r11 = extrinsics[1][1];
	const r12 = extrinsics[1][2];
	const r20 = extrinsics[2][0];
	const r21 = extrinsics[2][1];
	const r22 = extrinsics[2][2];
	const tx = extrinsics[0][3];
	const ty = extrinsics[1][3];
	const tz = extrinsics[2][3];
	const posX = -(r00 * tx + r10 * ty + r20 * tz);
	const posY = -(r01 * tx + r11 * ty + r21 * tz);
	const posZ = -(r02 * tx + r12 * ty + r22 * tz);
	const targetX = posX + r20;
	const targetY = posY + r21;
	const targetZ = posZ + r22;
	const fy = intrinsics[1][1];
	const cy = intrinsics[1][2];
	if (!Number.isFinite(fy) || fy === 0) throw new Error(`intrinsics[1][1] (fy) must be a non-zero finite number, got ${fy}`);
	const fovYDegrees = 2 * Math.atan(cy / fy) * 180 / Math.PI;
	return {
		position: [
			posX,
			-posY,
			-posZ
		],
		target: [
			targetX,
			-targetY,
			-targetZ
		],
		fovYDegrees
	};
}
function assertMatrixShape(matrix, rows, cols, name) {
	if (matrix.length !== rows) throw new Error(`${name} must be ${rows}x${cols}, got ${matrix.length} rows`);
	for (let i = 0; i < rows; i++) if (matrix[i].length !== cols) throw new Error(`${name} row ${i} must have ${cols} columns, got ${matrix[i].length}`);
}
//#endregion
//#region packages/viewport3d/src/load3d/Load3d.ts
function positionThumbnailCamera(camera, box) {
	const size = box.getSize(new Vector3());
	const center = box.getCenter(new Vector3());
	const distance = Math.max(size.x, size.y, size.z) * 1.5;
	camera.position.set(center.x + distance * .7, center.y + distance * .5, center.z + distance * .7);
	camera.lookAt(center);
	camera.updateProjectionMatrix();
}
var Load3d = class extends Viewport3d {
	hdriManager;
	loaderManager;
	modelManager;
	recordingManager;
	animationManager;
	gizmoManager;
	adapterRef;
	resolveImageURL;
	configurationCleanup;
	loadingPromise = null;
	_loadGeneration = 0;
	hasLoadedModel = false;
	thumbnailCaptureQueue = Promise.resolve();
	constructor(container, deps, options = {}) {
		super(container, deps, options);
		this.hdriManager = deps.hdriManager;
		this.loaderManager = deps.loaderManager;
		this.modelManager = deps.modelManager;
		this.recordingManager = deps.recordingManager;
		this.animationManager = deps.animationManager;
		this.gizmoManager = deps.gizmoManager;
		this.adapterRef = deps.adapterRef;
		this.resolveImageURL = deps.resolveImageURL;
		this.loaderManager.init();
		this.animationManager.init();
		this.gizmoManager.setPointerNdcSource((clientX, clientY) => this.clientPointToNdc(clientX, clientY));
		this.gizmoManager.init();
		this.eventManager.addEventListener("modelReady", () => {
			if (this.adapterRef.current?.kind !== "splat") return;
			this.repaintWhenSparkPaintable();
		});
		this.start();
	}
	async repaintWhenSparkPaintable() {
		const sortComplete = this.sceneManager.awaitNextSparkDirty();
		this.forceRender();
		await sortComplete;
		this.forceRender();
	}
	getLoaderManager() {
		return this.loaderManager;
	}
	getModelManager() {
		return this.modelManager;
	}
	getRecordingManager() {
		return this.recordingManager;
	}
	getGizmoManager() {
		return this.gizmoManager;
	}
	tickPerFrame(delta) {
		this.animationManager.update(delta);
		super.tickPerFrame(delta);
	}
	isActive() {
		return isLoad3dActive({
			mouseOnNode: this.STATUS_MOUSE_ON_NODE,
			mouseOnScene: this.STATUS_MOUSE_ON_SCENE,
			mouseOnViewer: this.STATUS_MOUSE_ON_VIEWER,
			recording: this.isRecording(),
			initialRenderDone: this.INITIAL_RENDER_DONE,
			animationPlaying: this.animationManager.isAnimationPlaying
		});
	}
	async exportModel(format) {
		if (!this.modelManager.currentModel) throw new Error("No model to export");
		const exportMessage = `Exporting as ${format.toUpperCase()}...`;
		this.eventManager.emitEvent("exportLoadingStart", exportMessage);
		const filename = `${this.modelManager.originalFileName || "model"}.${format}`;
		const originalURL = this.modelManager.originalURL;
		if (DIRECT_EXPORT_FORMATS.has(format)) {
			try {
				if (this.getSourceFormat() !== format) throw new Error(`Cannot export ${format} without converting from the loaded ${this.getSourceFormat() ?? "unknown"} source`);
				await ModelExporter.exportDirect(originalURL, filename, format);
			} catch (error) {
				console.error(`Error exporting model as ${format}:`, error);
				throw error;
			} finally {
				this.eventManager.emitEvent("exportLoadingEnd", null);
			}
			return;
		}
		const source = this.modelManager.currentModel;
		const savedPos = source.position.clone();
		const savedRot = source.rotation.clone();
		const savedScale = source.scale.clone();
		source.position.set(0, 0, 0);
		source.rotation.set(0, 0, 0);
		source.scale.set(1, 1, 1);
		source.updateMatrixWorld(true);
		try {
			const original = this.modelManager.originalModel;
			const clipsFromOriginal = original && "animations" in original && Array.isArray(original.animations) ? original.animations : [];
			const clips = source.animations.length ? source.animations : clipsFromOriginal;
			const model = format === "fbx" ? Object.assign(clone(source), { animations: clips }) : source.clone();
			adoptClonedModel(model, source, this.modelManager.originalMaterials);
			await new Promise((resolve) => setTimeout(resolve, 10));
			switch (format) {
				case "glb":
					await ModelExporter.exportGLB(model, filename, originalURL);
					break;
				case "obj":
					await ModelExporter.exportOBJ(model, filename, originalURL);
					break;
				case "stl":
					await ModelExporter.exportSTL(model, filename, originalURL);
					break;
				case "fbx":
					await ModelExporter.exportFBX(model, filename, originalURL);
					break;
				default: throw new Error(`Unsupported export format: ${format}`);
			}
			await new Promise((resolve) => setTimeout(resolve, 10));
		} catch (error) {
			console.error(`Error exporting model as ${format}:`, error);
			throw error;
		} finally {
			source.position.copy(savedPos);
			source.rotation.copy(savedRot);
			source.scale.copy(savedScale);
			source.updateMatrixWorld(true);
			this.eventManager.emitEvent("exportLoadingEnd", null);
		}
	}
	getSourceFormat() {
		const url = this.modelManager.originalURL;
		if (!url) return null;
		return ModelExporter.detectFormatFromURL(url);
	}
	onActiveCameraChanged() {
		this.gizmoManager.updateCamera(this.cameraManager.activeCamera);
	}
	setFOV(fov) {
		this.cameraManager.setFOV(fov);
		this.forceRender();
	}
	setBackgroundColor(color) {
		this.sceneManager.setBackgroundColor(color);
		this.forceRender();
	}
	toggleGrid(showGrid) {
		this.sceneManager.toggleGrid(showGrid);
		this.forceRender();
	}
	setLightIntensity(intensity) {
		this.lightingManager.setLightIntensity(intensity);
		this.forceRender();
	}
	async setBackgroundImage(uploadPath) {
		await this.sceneManager.setBackgroundImage(uploadPath, uploadPath && this.resolveImageURL(uploadPath));
		if (this.sceneManager.backgroundTexture && this.sceneManager.backgroundMesh) {
			const containerWidth = this.domElement.clientWidth;
			const containerHeight = this.domElement.clientHeight;
			if (this.shouldMaintainAspectRatio()) {
				const { width, height } = computeLetterboxedViewport({
					width: containerWidth,
					height: containerHeight
				}, this.targetAspectRatio);
				this.sceneManager.updateBackgroundSize(this.sceneManager.backgroundTexture, this.sceneManager.backgroundMesh, width, height);
			} else this.sceneManager.updateBackgroundSize(this.sceneManager.backgroundTexture, this.sceneManager.backgroundMesh, containerWidth, containerHeight);
		}
		this.forceRender();
	}
	removeBackgroundImage() {
		this.sceneManager.removeBackgroundImage();
		this.forceRender();
	}
	setBackgroundRenderMode(mode) {
		this.sceneManager.setBackgroundRenderMode(mode);
		this.forceRender();
	}
	setCameraFromMatrices(extrinsics, intrinsics) {
		const { position, target, fovYDegrees } = computeCameraFromMatrices(extrinsics, intrinsics);
		const current = this.cameraManager.getCameraState();
		this.setCameraState({
			position: new Vector3(position[0], position[1], position[2]),
			target: new Vector3(target[0], target[1], target[2]),
			zoom: current.zoom,
			cameraType: current.cameraType
		});
		this.setFOV(fovYDegrees);
	}
	getCurrentModel() {
		return this.modelManager.currentModel;
	}
	setMaterialMode(mode) {
		this.modelManager.setMaterialMode(mode);
		this.forceRender();
	}
	get currentLoadGeneration() {
		return this._loadGeneration;
	}
	async loadModel(url, originalFileName, options) {
		this._loadGeneration += 1;
		const loadGeneration = this._loadGeneration;
		const previousLoad = this.loadingPromise;
		const acceptedLoad = (async () => {
			try {
				await previousLoad;
			} catch {}
			let outcome;
			try {
				outcome = await this._loadModelInternal(url, originalFileName, options);
			} finally {
				if (loadGeneration !== this._loadGeneration) this.clearModelState();
			}
			return loadGeneration === this._loadGeneration ? outcome : "cancelled";
		})();
		this.loadingPromise = acceptedLoad;
		try {
			return await acceptedLoad;
		} finally {
			if (this.loadingPromise === acceptedLoad) this.loadingPromise = null;
		}
	}
	async whenLoadIdle() {
		let last = null;
		while (this.loadingPromise && this.loadingPromise !== last) {
			last = this.loadingPromise;
			try {
				await last;
			} catch {}
		}
	}
	async _loadModelInternal(url, originalFileName, options) {
		const shouldRetainView = this.hasLoadedModel;
		const savedCameraState = shouldRetainView ? this.cameraManager.getCameraState() : null;
		if (!shouldRetainView) {
			this.cameraManager.reset();
			this.controlsManager.reset();
		}
		this.gizmoManager.detach();
		this.modelManager.clearModel();
		this.animationManager.dispose();
		this.hasLoadedModel = false;
		const outcome = await this.loaderManager.loadModel(url, originalFileName, options);
		if (outcome !== "loaded") return outcome;
		if (this.modelManager.currentModel) {
			this.animationManager.setupModelAnimations(this.modelManager.currentModel, this.modelManager.originalModel);
			this.hasLoadedModel = true;
		}
		if (savedCameraState) {
			if (savedCameraState.cameraType !== this.cameraManager.getCurrentCameraType()) this.toggleCamera(savedCameraState.cameraType);
			this.cameraManager.setCameraState(savedCameraState);
		}
		this.handleResize();
		return outcome;
	}
	isSplatModel() {
		return this.adapterRef.current?.kind === "splat";
	}
	isPlyModel() {
		return this.adapterRef.current?.kind === "pointCloud";
	}
	getCurrentModelCapabilities() {
		return this.adapterRef.capabilities ?? DEFAULT_MODEL_CAPABILITIES;
	}
	clearModel() {
		this._loadGeneration += 1;
		this.clearModelState();
	}
	clearModelState() {
		this.animationManager.dispose();
		this.gizmoManager.detach();
		this.modelManager.clearModel();
		this.adapterRef.current = null;
		this.hasLoadedModel = false;
		this.forceRender();
	}
	setUpDirection(direction) {
		this.modelManager.setUpDirection(direction);
		this.forceRender();
	}
	async loadHDRI(url) {
		await this.hdriManager.loadHDRI(url);
		this.forceRender();
	}
	setHDRIEnabled(enabled) {
		this.hdriManager.setEnabled(enabled);
		this.lightingManager.setHDRIMode(enabled);
		this.forceRender();
	}
	setHDRIAsBackground(show) {
		this.hdriManager.setShowAsBackground(show);
		this.forceRender();
	}
	setHDRIIntensity(intensity) {
		this.hdriManager.setIntensity(intensity);
		this.forceRender();
	}
	clearHDRI() {
		this.hdriManager.clear();
		this.lightingManager.setHDRIMode(false);
		this.forceRender();
	}
	emitModelReady() {
		this.eventManager.emitEvent("modelReady", null);
	}
	captureScene(width, height) {
		this.gizmoManager.removeFromScene();
		return this.sceneManager.captureScene(width, height).finally(() => {
			this.gizmoManager.ensureHelperInScene();
		});
	}
	async startRecording() {
		this.viewHelperManager.visibleViewHelper(false);
		return this.recordingManager.startRecording(this.targetWidth, this.targetHeight);
	}
	stopRecording() {
		this.viewHelperManager.visibleViewHelper(true);
		this.recordingManager.stopRecording();
		this.eventManager.emitEvent("recordingStatusChange", false);
	}
	isRecording() {
		return this.recordingManager.getIsRecording();
	}
	getRecordingDuration() {
		return this.recordingManager.getRecordingDuration();
	}
	getRecordingData() {
		return this.recordingManager.getRecordingData();
	}
	exportRecording(filename) {
		this.recordingManager.exportRecording(filename);
	}
	clearRecording() {
		this.recordingManager.clearRecording();
	}
	setAnimationSpeed(speed) {
		this.animationManager.setAnimationSpeed(speed);
	}
	updateSelectedAnimation(index) {
		this.animationManager.updateSelectedAnimation(index);
	}
	toggleAnimation(play) {
		this.animationManager.toggleAnimation(play);
	}
	hasAnimations() {
		return this.animationManager.animationClips.length > 0;
	}
	hasSkeleton() {
		return this.modelManager.hasSkeleton();
	}
	setShowSkeleton(show) {
		this.modelManager.setShowSkeleton(show);
		this.forceRender();
	}
	getShowSkeleton() {
		return this.modelManager.showSkeleton;
	}
	getAnimationTime() {
		return this.animationManager.getAnimationTime();
	}
	getAnimationDuration() {
		return this.animationManager.getAnimationDuration();
	}
	setAnimationTime(time) {
		this.animationManager.setAnimationTime(time);
		this.forceRender();
	}
	captureThumbnail(width = 256, height = 256) {
		const capture = this.thumbnailCaptureQueue.then(() => this.captureThumbnailNow(width, height));
		this.thumbnailCaptureQueue = capture.catch(() => {});
		return capture;
	}
	async captureThumbnailNow(width, height) {
		if (!this.modelManager.currentModel) throw new Error("No model loaded for thumbnail capture");
		const savedState = this.cameraManager.getCameraState();
		const savedCameraType = this.cameraManager.getCurrentCameraType();
		const savedGridVisible = this.sceneManager.gridHelper.visible;
		try {
			this.sceneManager.gridHelper.visible = false;
			if (savedCameraType !== "perspective") this.cameraManager.toggleCamera("perspective");
			const box = this.modelManager.getCurrentBounds() ?? new Box3().setFromObject(this.modelManager.currentModel);
			positionThumbnailCamera(this.cameraManager.perspectiveCamera, box);
			this.controlsManager.controls.target.copy(box.getCenter(new Vector3()));
			this.controlsManager.controls.update();
			if (this.isSplatModel()) await this.sceneManager.whenSplatsSorted(this.cameraManager.perspectiveCamera);
			return (await this.captureScene(width, height)).scene;
		} finally {
			this.sceneManager.gridHelper.visible = savedGridVisible;
			if (savedCameraType !== "perspective") this.cameraManager.toggleCamera(savedCameraType);
			this.cameraManager.setCameraState(savedState);
			this.controlsManager.controls.update();
			this.forceRender();
		}
	}
	setGizmoEnabled(enabled) {
		if (enabled && !this.getCurrentModelCapabilities().gizmoTransform) return;
		this.gizmoManager.setEnabled(enabled);
		this.forceRender();
	}
	setGizmoMode(mode) {
		if (!this.getCurrentModelCapabilities().gizmoTransform) return;
		this.gizmoManager.setMode(mode);
		this.forceRender();
	}
	resetGizmoTransform() {
		if (!this.getCurrentModelCapabilities().gizmoTransform) return;
		this.gizmoManager.reset();
		this.forceRender();
	}
	applyGizmoTransform(position, rotation, scale) {
		if (!this.getCurrentModelCapabilities().gizmoTransform) return;
		this.gizmoManager.applyTransform(position, rotation, scale);
		this.forceRender();
	}
	applyModelTransform(transform) {
		if (!this.getCurrentModelCapabilities().gizmoTransform) return;
		this.gizmoManager.applyModelTransform(transform);
		this.forceRender();
	}
	getGizmoTransform() {
		return this.gizmoManager.getTransform();
	}
	getModelInfo() {
		return this.gizmoManager.getModelInfo();
	}
	fitToViewer() {
		this.modelManager.fitToViewer();
		this.forceRender();
	}
	centerCameraOnModel() {
		const bounds = this.modelManager.getCurrentBounds();
		if (!bounds || bounds.isEmpty()) return;
		const center = bounds.getCenter(new Vector3());
		const camera = this.cameraManager.activeCamera;
		const controls = this.controlsManager.controls;
		const offset = center.clone().sub(camera.position);
		camera.position.add(offset);
		controls.target.add(offset);
		camera.updateMatrixWorld(true);
		controls.update();
		this.forceRender();
	}
	setConfigurationCleanup(cleanup) {
		this.clearConfigurationCleanup();
		this.configurationCleanup = cleanup;
	}
	clearConfigurationCleanup() {
		this.configurationCleanup?.();
		this.configurationCleanup = void 0;
	}
	disposeManagers() {
		this.clearConfigurationCleanup();
		super.disposeManagers();
		this.hdriManager.dispose();
		this.loaderManager.dispose();
		this.modelManager.dispose();
		this.adapterRef.current = null;
		this.recordingManager.dispose();
		this.animationManager.dispose();
		this.gizmoManager.dispose();
	}
};
//#endregion
//#region node_modules/.pnpm/wwobjloader2@6.2.1_three@0.186.1/node_modules/wwobjloader2/dist/OBJLoader2Parser.js
var OBJLoader2Parser = class {
	logging;
	usedBefore = false;
	contentRef = "";
	legacyMode = false;
	materialNames = /* @__PURE__ */ new Set();
	modelName = "noname";
	materialPerSmoothingGroup = false;
	useOAsMesh = false;
	useIndices = false;
	disregardNormals = false;
	vertices = [];
	colors = [];
	normals = [];
	uvs = [];
	rawMesh;
	inputObjectCount = 1;
	outputObjectCount = 1;
	globalCounts;
	constructor() {
		this.logging = this.buildDefaultLogging();
		this.rawMesh = this.buildDefaultRawMesh();
		this.globalCounts = this.buildDefaultGlobalsCount();
	}
	buildDefaultLogging() {
		return {
			enabled: false,
			debug: false
		};
	}
	buildDefaultRawMesh() {
		return {
			objectName: "",
			groupName: "",
			activeMtlName: "",
			mtllibName: "",
			faceType: -1,
			subGroups: /* @__PURE__ */ new Map(),
			subGroupInUse: void 0,
			smoothingGroup: {
				splitMaterials: false,
				normalized: -1,
				real: -1
			},
			counts: {
				doubleIndicesCount: 0,
				faceCount: 0,
				mtlCount: 0,
				smoothingGroupCount: 0
			}
		};
	}
	buildDefaultGlobalsCount() {
		return {
			vertices: 0,
			faces: 0,
			doubleIndicesCount: 0,
			lineByte: 0,
			currentByte: 0,
			totalBytes: 0
		};
	}
	setBulkConfig(config) {
		this.materialPerSmoothingGroup = config.materialPerSmoothingGroup;
		this.useOAsMesh = config.useOAsMesh;
		this.useIndices = config.useIndices;
		this.disregardNormals = config.disregardNormals;
		this.modelName = config.modelName;
		this.materialNames = config.materialNames;
	}
	/**
	* Enable or disable logging in general (except warn and error), plus enable or disable debug logging.
	*
	* @param {boolean} enabled True or false.
	* @param {boolean} debug True or false.
	*/
	setLogging(enabled, debug) {
		this.logging.enabled = enabled === true;
		this.logging.debug = debug === true;
	}
	setMaterialNames(materialNames) {
		this.materialNames = materialNames;
	}
	isLoggingEnabled() {
		return this.logging.enabled;
	}
	isDebugLoggingEnabled() {
		return this.logging.enabled && this.logging.debug;
	}
	/**
	*
	* @returns if parser was used before
	*/
	isUsedBefore() {
		return this.usedBefore;
	}
	configure() {
		this.usedBefore = true;
		this.pushSmoothingGroup("1");
		if (this.logging.enabled) (this.materialNames.size > 0 ? "\n	materialNames:\n		- " + Array.from(this.materialNames).join("\n		- ") : "\n	materialNames: None") + this.materialPerSmoothingGroup + this.useOAsMesh + this.useIndices + this.disregardNormals;
	}
	/**
	* Parse the provided arraybuffer
	*
	* @param {Uint8Array} arrayBuffer OBJ data as Uint8Array
	*/
	execute(arrayBuffer) {
		if (this.logging.enabled);
		this.configure();
		const arrayBufferView = new Uint8Array(arrayBuffer);
		this.contentRef = arrayBufferView;
		const length = arrayBufferView.byteLength;
		this.globalCounts.totalBytes = length;
		const buffer = new Array(128);
		let bufferPointer = 0;
		let slashesCount = 0;
		let word = "";
		let currentByte = 0;
		for (let code; currentByte < length; currentByte++) {
			code = arrayBufferView[currentByte];
			switch (code) {
				case 32:
					if (word.length > 0) buffer[bufferPointer++] = word;
					word = "";
					break;
				case 47:
					if (word.length > 0) buffer[bufferPointer++] = word;
					slashesCount++;
					word = "";
					break;
				case 10:
					this.processLine(buffer, bufferPointer, slashesCount, word, currentByte);
					word = "";
					bufferPointer = 0;
					slashesCount = 0;
					break;
				case 13: break;
				default: word += String.fromCharCode(code);
			}
		}
		this.processLine(buffer, bufferPointer, slashesCount, word, currentByte);
		this.finalizeParsing();
		if (this.logging.enabled);
	}
	/**
	* Parse the provided text
	*
	* @param {string} text OBJ data as string
	*/
	executeLegacy(text) {
		if (this.logging.enabled);
		this.configure();
		this.legacyMode = true;
		this.contentRef = text;
		const length = text.length;
		this.globalCounts.totalBytes = length;
		const buffer = new Array(128);
		let bufferPointer = 0;
		let slashesCount = 0;
		let word = "";
		let currentByte = 0;
		for (let char; currentByte < length; currentByte++) {
			char = text[currentByte];
			switch (char) {
				case " ":
					if (word.length > 0) buffer[bufferPointer++] = word;
					word = "";
					break;
				case "/":
					if (word.length > 0) buffer[bufferPointer++] = word;
					slashesCount++;
					word = "";
					break;
				case "\n":
					this.processLine(buffer, bufferPointer, slashesCount, word, currentByte);
					word = "";
					bufferPointer = 0;
					slashesCount = 0;
					break;
				case "\r": break;
				default: word += char;
			}
		}
		this.processLine(buffer, bufferPointer, slashesCount, word, currentByte);
		this.finalizeParsing();
		if (this.logging.enabled);
	}
	processLine(buffer, bufferPointer, slashesCount, word, currentByte) {
		this.globalCounts.lineByte = this.globalCounts.currentByte;
		this.globalCounts.currentByte = currentByte;
		if (bufferPointer < 1) return;
		if (word.length > 0) buffer[bufferPointer++] = word;
		const reconstructString = (content, legacyMode, start, stop) => {
			let line = "";
			if (stop > start) {
				let i;
				if (legacyMode) for (i = start; i < stop; i++) line += content[i];
				else for (i = start; i < stop; i++) line += String.fromCharCode(content[i]);
				line = line.trim();
			}
			return line;
		};
		let bufferLength;
		let length;
		let i;
		const lineDesignation = buffer[0];
		switch (lineDesignation) {
			case "v":
				this.vertices.push(parseFloat(buffer[1]));
				this.vertices.push(parseFloat(buffer[2]));
				this.vertices.push(parseFloat(buffer[3]));
				if (bufferPointer > 4) {
					const color = new Color();
					color.setRGB(parseFloat(buffer[4]), parseFloat(buffer[5]), parseFloat(buffer[6])).convertSRGBToLinear();
					this.colors.push(color.r);
					this.colors.push(color.g);
					this.colors.push(color.b);
				}
				break;
			case "vt":
				this.uvs.push(parseFloat(buffer[1]));
				this.uvs.push(parseFloat(buffer[2]));
				break;
			case "vn":
				this.normals.push(parseFloat(buffer[1]));
				this.normals.push(parseFloat(buffer[2]));
				this.normals.push(parseFloat(buffer[3]));
				break;
			case "f":
				bufferLength = bufferPointer - 1;
				if (slashesCount === 0) {
					this.checkFaceType(0);
					for (i = 2, length = bufferLength; i < length; i++) {
						this.buildFace(buffer[1]);
						this.buildFace(buffer[i]);
						this.buildFace(buffer[i + 1]);
					}
				} else if (bufferLength === slashesCount * 2) {
					this.checkFaceType(1);
					for (i = 3, length = bufferLength - 2; i < length; i += 2) {
						this.buildFace(buffer[1], buffer[2]);
						this.buildFace(buffer[i], buffer[i + 1]);
						this.buildFace(buffer[i + 2], buffer[i + 3]);
					}
				} else if (bufferLength * 2 === slashesCount * 3) {
					this.checkFaceType(2);
					for (i = 4, length = bufferLength - 3; i < length; i += 3) {
						this.buildFace(buffer[1], buffer[2], buffer[3]);
						this.buildFace(buffer[i], buffer[i + 1], buffer[i + 2]);
						this.buildFace(buffer[i + 3], buffer[i + 4], buffer[i + 5]);
					}
				} else {
					this.checkFaceType(3);
					for (i = 3, length = bufferLength - 2; i < length; i += 2) {
						this.buildFace(buffer[1], void 0, buffer[2]);
						this.buildFace(buffer[i], void 0, buffer[i + 1]);
						this.buildFace(buffer[i + 2], void 0, buffer[i + 3]);
					}
				}
				break;
			case "l":
			case "p":
				bufferLength = bufferPointer - 1;
				if (bufferLength === slashesCount * 2) {
					this.checkFaceType(4);
					for (i = 1, length = bufferLength + 1; i < length; i += 2) this.buildFace(buffer[i], buffer[i + 1]);
				} else {
					this.checkFaceType(lineDesignation === "l" ? 5 : 6);
					for (i = 1, length = bufferLength + 1; i < length; i++) this.buildFace(buffer[i]);
				}
				break;
			case "s":
				this.pushSmoothingGroup(buffer[1]);
				break;
			case "g":
				this.processCompletedMesh();
				this.rawMesh.groupName = reconstructString(this.contentRef, this.legacyMode, this.globalCounts.lineByte + 2, this.globalCounts.currentByte);
				break;
			case "o":
				if (this.useOAsMesh) this.processCompletedMesh();
				this.rawMesh.objectName = reconstructString(this.contentRef, this.legacyMode, this.globalCounts.lineByte + 2, this.globalCounts.currentByte);
				break;
			case "mtllib":
				this.rawMesh.mtllibName = reconstructString(this.contentRef, this.legacyMode, this.globalCounts.lineByte + 7, this.globalCounts.currentByte);
				break;
			case "usemtl":
				const mtlName = reconstructString(this.contentRef, this.legacyMode, this.globalCounts.lineByte + 7, this.globalCounts.currentByte);
				if (mtlName !== "" && this.rawMesh.activeMtlName !== mtlName) {
					this.rawMesh.activeMtlName = mtlName;
					this.rawMesh.counts.mtlCount++;
					this.checkSubGroup();
				}
		}
	}
	pushSmoothingGroup(smoothingGroup) {
		let smoothingGroupInt = parseInt(smoothingGroup);
		if (isNaN(smoothingGroupInt)) smoothingGroupInt = smoothingGroup === "off" ? 0 : 1;
		const smoothCheck = this.rawMesh.smoothingGroup.normalized;
		this.rawMesh.smoothingGroup.normalized = this.rawMesh.smoothingGroup.splitMaterials ? smoothingGroupInt : smoothingGroupInt === 0 ? 0 : 1;
		this.rawMesh.smoothingGroup.real = smoothingGroupInt;
		if (smoothCheck !== smoothingGroupInt) {
			this.rawMesh.counts.smoothingGroupCount++;
			this.checkSubGroup();
		}
	}
	/**
	* Expanded faceTypes include all four face types, both line types and the point type
	* faceType = 0: "f vertex ..."
	* faceType = 1: "f vertex/uv ..."
	* faceType = 2: "f vertex/uv/normal ..."
	* faceType = 3: "f vertex//normal ..."
	* faceType = 4: "l vertex/uv ..." or "l vertex ..."
	* faceType = 5: "l vertex ..."
	* faceType = 6: "p vertex ..."
	*/
	checkFaceType(faceType) {
		if (this.rawMesh.faceType !== faceType) {
			this.processCompletedMesh();
			this.rawMesh.faceType = faceType;
			this.checkSubGroup();
		}
	}
	checkSubGroup() {
		const index = `${this.rawMesh.activeMtlName}|${this.rawMesh.smoothingGroup.normalized}`;
		this.rawMesh.subGroupInUse = this.rawMesh.subGroups.get(index);
		if (!this.rawMesh.subGroupInUse) {
			this.rawMesh.subGroupInUse = {
				index,
				objectName: this.rawMesh.objectName,
				groupName: this.rawMesh.groupName,
				materialName: this.rawMesh.activeMtlName,
				smoothingGroup: this.rawMesh.smoothingGroup.normalized,
				vertices: [],
				indexMappingsCount: 0,
				indexMappings: /* @__PURE__ */ new Map(),
				indices: [],
				colors: [],
				uvs: [],
				normals: []
			};
			this.rawMesh.subGroups.set(index, this.rawMesh.subGroupInUse);
		}
	}
	buildFace(faceIndexV, faceIndexU, faceIndexN) {
		const subGroupInUse = this.rawMesh.subGroupInUse;
		const updateSubGroupInUse = () => {
			const faceIndexVi = parseInt(faceIndexV);
			let indexPointerV = 3 * (faceIndexVi > 0 ? faceIndexVi - 1 : faceIndexVi + this.vertices.length / 3);
			let indexPointerC = this.colors.length > 0 ? indexPointerV : null;
			const vertices = subGroupInUse.vertices;
			vertices.push(this.vertices[indexPointerV++]);
			vertices.push(this.vertices[indexPointerV++]);
			vertices.push(this.vertices[indexPointerV]);
			if (indexPointerC !== null) {
				const colors = subGroupInUse.colors;
				colors.push(this.colors[indexPointerC++]);
				colors.push(this.colors[indexPointerC++]);
				colors.push(this.colors[indexPointerC]);
			}
			if (faceIndexU) {
				const faceIndexUi = parseInt(faceIndexU);
				let indexPointerU = 2 * (faceIndexUi > 0 ? faceIndexUi - 1 : faceIndexUi + this.uvs.length / 2);
				const uvs = subGroupInUse.uvs;
				uvs.push(this.uvs[indexPointerU++]);
				uvs.push(this.uvs[indexPointerU]);
			}
			if (faceIndexN && !this.disregardNormals) {
				const faceIndexNi = parseInt(faceIndexN);
				let indexPointerN = 3 * (faceIndexNi > 0 ? faceIndexNi - 1 : faceIndexNi + this.normals.length / 3);
				const normals = subGroupInUse.normals;
				normals.push(this.normals[indexPointerN++]);
				normals.push(this.normals[indexPointerN++]);
				normals.push(this.normals[indexPointerN]);
			}
		};
		if (this.useIndices) {
			if (this.disregardNormals) faceIndexN = void 0;
			const mappingName = faceIndexV + (faceIndexU ? "_" + faceIndexU : "_n") + (faceIndexN ? "_" + faceIndexN : "_n");
			let indicesPointer = subGroupInUse.indexMappings.get(mappingName);
			if (indicesPointer === void 0 || indicesPointer === null) {
				indicesPointer = this.rawMesh.subGroupInUse.vertices.length / 3;
				updateSubGroupInUse();
				subGroupInUse.indexMappings.set(mappingName, indicesPointer);
				subGroupInUse.indexMappingsCount++;
			} else this.rawMesh.counts.doubleIndicesCount++;
			subGroupInUse.indices.push(indicesPointer);
		} else updateSubGroupInUse();
		this.rawMesh.counts.faceCount++;
	}
	createRawMeshReport(inputObjectCount) {
		return `Input Object number: ${inputObjectCount}
	Object name: ${this.rawMesh.objectName}
	Group name: ${this.rawMesh.groupName}
	Mtllib name: ${this.rawMesh.mtllibName}
	Vertex count: ${this.vertices.length / 3}
	Normal count: ${this.normals.length / 3}
	UV count: ${this.uvs.length / 2}
	SmoothingGroup count: ${this.rawMesh.counts.smoothingGroupCount}
	Material count: ${this.rawMesh.counts.mtlCount}
	Real MeshOutputGroup count: ${this.rawMesh.subGroups.size}`;
	}
	/**
	* Clear any empty subGroup and calculate absolute vertex, normal and uv counts
	*/
	finalizeRawMesh() {
		const meshOutputGroupTemp = [];
		let meshOutputGroup;
		let absoluteVertexCount = 0;
		let absoluteIndexMappingsCount = 0;
		let absoluteIndexCount = 0;
		let absoluteColorCount = 0;
		let absoluteNormalCount = 0;
		let absoluteUvCount = 0;
		let indices;
		for (const entry of this.rawMesh.subGroups.entries()) {
			meshOutputGroup = this.rawMesh.subGroups.get(entry[0]);
			if (meshOutputGroup && meshOutputGroup.vertices.length > 0) {
				indices = meshOutputGroup.indices;
				if (indices.length > 0 && absoluteIndexMappingsCount > 0) for (let i = 0; i < indices.length; i++) indices[i] = indices[i] + absoluteIndexMappingsCount;
				meshOutputGroupTemp.push(meshOutputGroup);
				absoluteVertexCount += meshOutputGroup.vertices.length;
				absoluteIndexMappingsCount += meshOutputGroup.indexMappingsCount;
				absoluteIndexCount += meshOutputGroup.indices.length;
				absoluteColorCount += meshOutputGroup.colors.length;
				absoluteUvCount += meshOutputGroup.uvs.length;
				absoluteNormalCount += meshOutputGroup.normals.length;
			}
		}
		if (meshOutputGroupTemp.length > 0) return {
			name: this.rawMesh.groupName !== "" ? this.rawMesh.groupName : this.rawMesh.objectName,
			subGroups: meshOutputGroupTemp,
			absoluteVertexCount,
			absoluteIndexCount,
			absoluteColorCount,
			absoluteNormalCount,
			absoluteUvCount,
			faceCount: this.rawMesh.counts.faceCount,
			doubleIndicesCount: this.rawMesh.counts.doubleIndicesCount
		};
		else return;
	}
	processCompletedMesh() {
		const result = this.finalizeRawMesh();
		if (result) {
			if (this.colors.length > 0 && this.colors.length !== this.vertices.length) this._onError("Vertex Colors were detected, but vertex count and color count do not match!");
			if (this.logging.enabled && this.logging.debug) this.createRawMeshReport(this.inputObjectCount);
			this.inputObjectCount++;
			const preparedMesh = this.createPreparedMesh(result);
			this._onAssetAvailable(preparedMesh);
			const progressBytesPercent = this.globalCounts.currentByte / this.globalCounts.totalBytes;
			this._onProgress("Completed [o: " + this.rawMesh.objectName + " g:" + this.rawMesh.groupName + "] Total progress: " + (progressBytesPercent * 100).toFixed(2) + "%");
			this.resetRawMesh();
			return true;
		}
		return false;
	}
	resetRawMesh() {
		this.rawMesh.subGroups = /* @__PURE__ */ new Map();
		this.rawMesh.subGroupInUse = void 0;
		this.rawMesh.smoothingGroup.normalized = -1;
		this.rawMesh.smoothingGroup.real = -1;
		this.pushSmoothingGroup("1");
		this.rawMesh.counts.doubleIndicesCount = 0;
		this.rawMesh.counts.faceCount = 0;
		this.rawMesh.counts.mtlCount = 0;
		this.rawMesh.counts.smoothingGroupCount = 0;
	}
	/**
	* SubGroups are transformed to too intermediate format that is forwarded to the MeshReceiver.
	* It is ensured that SubGroups only contain objects with vertices (no need to check).
	*
	* @param result
	*/
	createPreparedMesh(result) {
		const meshOutputGroups = result.subGroups;
		this.globalCounts.vertices += result.absoluteVertexCount / 3;
		this.globalCounts.faces += result.faceCount;
		this.globalCounts.doubleIndicesCount += result.doubleIndicesCount;
		if (result.absoluteVertexCount <= 0) throw new Error(`Invalid vertex count: ${result.absoluteVertexCount}`);
		const vertexFA = new Float32Array(result.absoluteVertexCount);
		const indexUA = result.absoluteIndexCount > 0 ? new Uint32Array(result.absoluteIndexCount) : null;
		const colorFA = result.absoluteColorCount > 0 ? new Float32Array(result.absoluteColorCount) : null;
		const normalFA = result.absoluteNormalCount > 0 ? new Float32Array(result.absoluteNormalCount) : null;
		const uvFA = result.absoluteUvCount > 0 ? new Float32Array(result.absoluteUvCount) : null;
		let meshOutputGroup;
		let vertexFAOffset = 0;
		let indexUAOffset = 0;
		let colorFAOffset = 0;
		let normalFAOffset = 0;
		let uvFAOffset = 0;
		const geometryGroups = [];
		let materialGroupOffset = 0;
		let materialGroupLength = 0;
		const createMultiMaterial = meshOutputGroups.length > 1;
		const multiMaterial = [];
		const haveVertexColors = colorFA !== null;
		let materialIndex = 0;
		const materialMetaInfo = {
			materialCloneInstructions: [],
			materialName: "",
			multiMaterialNames: /* @__PURE__ */ new Map(),
			modelName: this.modelName,
			geometryType: this.rawMesh.faceType < 4 ? 0 : this.rawMesh.faceType === 6 ? 2 : 1
		};
		for (const oodIndex in meshOutputGroups) {
			if (!Object.prototype.hasOwnProperty.call(meshOutputGroups, oodIndex)) continue;
			meshOutputGroup = meshOutputGroups[oodIndex];
			let materialName;
			const materialNameOrg = meshOutputGroup.materialName;
			const flatShading = meshOutputGroup.smoothingGroup === 0;
			if (this.rawMesh.faceType < 4) {
				materialName = materialNameOrg;
				if (haveVertexColors) materialName += "_vertexColor";
				if (flatShading) materialName += "_flat";
			} else materialName = this.rawMesh.faceType === 6 ? "defaultPointMaterial" : "defaultLineMaterial";
			materialMetaInfo.materialName = materialName;
			const haveMaterialOrg = this.materialNames.has(materialNameOrg);
			const haveMaterial = this.materialNames.has(materialName);
			const useDefaultMaterial = !haveMaterialOrg && !haveMaterial;
			const cloneMaterial = useDefaultMaterial ? false : !haveMaterial;
			if (useDefaultMaterial) {
				materialName = haveVertexColors ? "defaultVertexColorMaterial" : "defaultMaterial";
				if (this.logging.enabled) "" + meshOutputGroup.objectName + meshOutputGroup.groupName + materialNameOrg + materialName;
				materialMetaInfo.materialName = materialName;
			}
			if (cloneMaterial) {
				const materialCloneInstruction = {
					materialNameOrg,
					materialProperties: {
						name: materialName,
						vertexColors: haveVertexColors ? 2 : 0,
						flatShading
					}
				};
				materialMetaInfo.materialCloneInstructions.push(materialCloneInstruction);
			}
			if (createMultiMaterial) {
				materialGroupLength = this.useIndices ? meshOutputGroup.indices.length : meshOutputGroup.vertices.length / 3;
				geometryGroups.push({
					materialGroupOffset,
					materialGroupLength,
					materialIndex
				});
				multiMaterial[materialIndex] = materialName;
				materialMetaInfo.multiMaterialNames.set(materialIndex, materialName);
				materialGroupOffset += materialGroupLength;
				materialIndex++;
			}
			if (vertexFA !== null) {
				vertexFA.set(meshOutputGroup.vertices, vertexFAOffset);
				vertexFAOffset += meshOutputGroup.vertices.length;
			}
			if (indexUA !== null) {
				indexUA.set(meshOutputGroup.indices, indexUAOffset);
				indexUAOffset += meshOutputGroup.indices.length;
			}
			if (colorFA !== null) {
				colorFA.set(meshOutputGroup.colors, colorFAOffset);
				colorFAOffset += meshOutputGroup.colors.length;
			}
			if (normalFA !== null) {
				normalFA.set(meshOutputGroup.normals, normalFAOffset);
				normalFAOffset += meshOutputGroup.normals.length;
			}
			if (uvFA !== null) {
				uvFA.set(meshOutputGroup.uvs, uvFAOffset);
				uvFAOffset += meshOutputGroup.uvs.length;
			}
			if (this.logging.enabled && this.logging.debug) {
				let materialIndexLine = "";
				if (materialIndex > 0) materialIndexLine = "\n		materialIndex: " + materialIndex;
				"" + this.outputObjectCount + meshOutputGroup.groupName + meshOutputGroup.index + this.rawMesh.faceType + meshOutputGroup.materialName + meshOutputGroup.smoothingGroup + materialIndexLine + meshOutputGroup.objectName + meshOutputGroup.vertices.length / 3 + meshOutputGroup.indices.length + meshOutputGroup.colors.length / 3 + meshOutputGroup.uvs.length / 2 + meshOutputGroup.normals.length / 3;
			}
		}
		this.outputObjectCount++;
		return {
			meshName: result.name,
			vertexFA,
			normalFA,
			uvFA,
			colorFA,
			indexUA,
			createMultiMaterial,
			geometryGroups,
			multiMaterial,
			materialMetaInfo,
			progress: this.globalCounts.currentByte / this.globalCounts.totalBytes
		};
	}
	finalizeParsing() {
		if (this.logging.enabled) "" + this.outputObjectCount;
		if (this.processCompletedMesh() && this.logging.enabled) "" + this.globalCounts.vertices + this.globalCounts.faces + this.globalCounts.doubleIndicesCount;
		this._onLoad();
	}
	/**
	* Announce parse progress feedback which is logged to the console.
	* @private
	*
	* @param {string} text Textual description of the event
	*/
	_onProgress(text) {
		if (this.logging.enabled && this.logging.debug) {}
	}
	/**
	* Announce error feedback which is logged as error message.
	* @private
	*
	* @param {String} errorMessage The event containing the error
	*/
	_onError(errorMessage) {
		if (this.logging.enabled && this.logging.debug) console.error(errorMessage);
	}
	/**
	* Hook for alteration or transfer to main when parser is run in worker
	*
	* @param {Mesh} _mesh
	* @param {object} _materialMetaInfo
	*/
	_onAssetAvailable(_mesh, _materialMetaInfo) {}
	_onLoad() {}
};
//#endregion
//#region node_modules/.pnpm/wtd-three-ext@3.0.0_three@0.186.1/node_modules/wtd-three-ext/dist/MaterialUtils.js
/**
* Static functions useful in the context of handling materials.
*/
var MaterialUtils = class MaterialUtils {
	/**
	* Adds the provided material to the provided map of materials if the material does not exists.
	* Use force override existing material.
	*
	* @param {Map<string, Material>} materialsObject
	* @param {string} materialName
	* @param {Material} material
	* @param {boolean} force Enforce addition of provided material
	* @param {boolean} [log] Log messages to the console
	*/
	static addMaterial(materialsObject, materialName, material, force, log) {
		let existingMaterial;
		material.name = materialName;
		if (!force) {
			existingMaterial = materialsObject.get(materialName);
			if (existingMaterial) {
				if (existingMaterial.uuid !== existingMaterial.uuid) {
					if (log) "" + existingMaterial.name + existingMaterial.uuid + material.uuid;
				}
			} else {
				materialsObject.set(materialName, material);
				if (log) "" + materialName;
			}
		} else {
			materialsObject.set(materialName, material);
			if (log) "" + materialName;
		}
	}
	/**
	* Transforms the named materials object to an object with named jsonified materials.
	*
	* @param {Map<string, Material>}
	* @returns {Map<string, unknown>} Map of Materials in JSON representation
	*/
	static getMaterialsJSON(materialsObject) {
		const materialsJSON = /* @__PURE__ */ new Map();
		for (const entry of materialsObject.entries()) if (typeof entry[1].toJSON === "function") materialsJSON.set(entry[0], entry[1].toJSON());
		return materialsJSON;
	}
	/**
	* Clones a material according the provided instructions.
	*
	* @param {Map<string, Material>} materials
	* @param {MaterialCloneInstructionsType} materialCloneInstruction
	* @param {boolean} [log]
	*/
	static cloneMaterial(materials, materialCloneInstruction, log) {
		if (materialCloneInstruction) {
			let materialNameOrg = materialCloneInstruction.materialNameOrg;
			materialNameOrg = materialNameOrg !== void 0 && materialNameOrg !== null ? materialNameOrg : "";
			const materialOrg = materials.get(materialNameOrg);
			if (materialOrg) {
				const material = materialOrg.clone();
				Object.assign(material, materialCloneInstruction.materialProperties);
				MaterialUtils.addMaterial(materials, materialCloneInstruction.materialProperties.name, material, true, log);
				return material;
			} else if (log) "" + materialNameOrg;
		}
	}
};
//#endregion
//#region node_modules/.pnpm/wtd-three-ext@3.0.0_three@0.186.1/node_modules/wtd-three-ext/dist/MaterialStore.js
/**
* Helper class around an object storing materials by name.
* Optionally, create and store default materials.
*/
var MaterialStore = class {
	materials;
	/**
	* Creates a new {@link MaterialStore}.
	* @param {boolean} createDefaultMaterials
	*/
	constructor(createDefaultMaterials) {
		this.materials = /* @__PURE__ */ new Map();
		if (createDefaultMaterials) {
			const defaultMaterial = new MeshStandardMaterial({ color: 14479871 });
			defaultMaterial.name = "defaultMaterial";
			const defaultVertexColorMaterial = new MeshStandardMaterial({ color: 14479871 });
			defaultVertexColorMaterial.name = "defaultVertexColorMaterial";
			defaultVertexColorMaterial.vertexColors = true;
			const defaultLineMaterial = new LineBasicMaterial();
			defaultLineMaterial.name = "defaultLineMaterial";
			const defaultPointMaterial = new PointsMaterial({ size: .1 });
			defaultPointMaterial.name = "defaultPointMaterial";
			this.materials.set(defaultMaterial.name, defaultMaterial);
			this.materials.set(defaultVertexColorMaterial.name, defaultVertexColorMaterial);
			this.materials.set(defaultLineMaterial.name, defaultLineMaterial);
			this.materials.set(defaultPointMaterial.name, defaultPointMaterial);
		}
	}
	/**
	* Set materials loaded by any supplier of an Array of {@link Material}.
	*
	* @param {Map<string, Material>} newMaterials Object with named {@link Material}
	* @param {boolean} forceOverrideExisting boolean Override existing material
	*/
	addMaterials(newMaterials, forceOverrideExisting) {
		if (newMaterials && newMaterials !== null && newMaterials.size > 0) for (const entry of newMaterials.entries()) MaterialUtils.addMaterial(this.materials, entry[0], entry[1], forceOverrideExisting === true);
	}
	addMaterialsFromObject(newMaterials, forceOverrideExisting) {
		if (newMaterials && newMaterials !== null && Object.keys(newMaterials).length > 0) for (const [k, v] of Object.entries(newMaterials)) MaterialUtils.addMaterial(this.materials, k, v, forceOverrideExisting === true);
	}
	getMaterials() {
		return this.materials;
	}
	getMaterial(materialName) {
		return this.materials.get(materialName);
	}
	clearMaterials() {
		this.materials.clear();
	}
};
//#endregion
//#region node_modules/.pnpm/wtd-core@3.0.0/node_modules/wtd-core/dist/WorkerTaskWorker.js
var WorkerTaskCommandRequest;
(function(WorkerTaskCommandRequest) {
	WorkerTaskCommandRequest["INIT"] = "init";
	WorkerTaskCommandRequest["INIT_CHANNEL"] = "initChannel";
	WorkerTaskCommandRequest["INTERMEDIATE"] = "intermediate";
	WorkerTaskCommandRequest["EXECUTE"] = "execute";
	WorkerTaskCommandRequest["INTERCOM_INIT"] = "interComInit";
	WorkerTaskCommandRequest["INTERCOM_INTERMEDIATE"] = "interComIntermediate";
	WorkerTaskCommandRequest["INTERCOM_EXECUTE"] = "interComExecute";
})(WorkerTaskCommandRequest || (WorkerTaskCommandRequest = {}));
var WorkerTaskCommandResponse;
(function(WorkerTaskCommandResponse) {
	WorkerTaskCommandResponse["INIT_COMPLETE"] = "initComplete";
	WorkerTaskCommandResponse["INIT_CHANNEL_COMPLETE"] = "initChannelComplete";
	WorkerTaskCommandResponse["INTERMEDIATE_CONFIRM"] = "intermediateConfirm";
	WorkerTaskCommandResponse["EXECUTE_COMPLETE"] = "executeComplete";
	WorkerTaskCommandResponse["INTERCOM_INIT_COMPLETE"] = "interComInitComplete";
	WorkerTaskCommandResponse["INTERCOM_INTERMEDIATE_CONFIRM"] = "interComIntermediateConfirm";
	WorkerTaskCommandResponse["INTERCOM_EXECUTE_COMPLETE"] = "interComExecuteComplete";
})(WorkerTaskCommandResponse || (WorkerTaskCommandResponse = {}));
//#endregion
//#region node_modules/.pnpm/wtd-core@3.0.0/node_modules/wtd-core/dist/offscreen/OffscreenWorker.js
var OffscreenWorkerCommandRequest;
(function(OffscreenWorkerCommandRequest) {
	OffscreenWorkerCommandRequest["INIT_OFFSCREEN_CANVAS"] = "initOffscreenCanvas";
	OffscreenWorkerCommandRequest["PROXY_START"] = "proxyStart";
	OffscreenWorkerCommandRequest["PROXY_EVENT"] = "proxyEvent";
	OffscreenWorkerCommandRequest["RESIZE"] = "resize";
})(OffscreenWorkerCommandRequest || (OffscreenWorkerCommandRequest = {}));
var OffscreenWorkerCommandResponse;
(function(OffscreenWorkerCommandResponse) {
	OffscreenWorkerCommandResponse["INIT_OFFSCREEN_CANVAS_COMPLETE"] = "initOffscreenCanvasComplete";
	OffscreenWorkerCommandResponse["PROXY_START_COMPLETE"] = "proxyStartComplete";
	OffscreenWorkerCommandResponse["PROXY_EVENT_COMPLETE"] = "proxyEventComplete";
	OffscreenWorkerCommandResponse["RESIZE_COMPLETE"] = "resizeComplete";
})(OffscreenWorkerCommandResponse || (OffscreenWorkerCommandResponse = {}));
//#endregion
//#region node_modules/.pnpm/wtd-core@3.0.0/node_modules/wtd-core/dist/Payload.js
var PayloadRegister = class {
	static handler = /* @__PURE__ */ new Map();
};
//#endregion
//#region node_modules/.pnpm/wtd-core@3.0.0/node_modules/wtd-core/dist/WorkerTaskMessage.js
var WorkerTaskMessage = class WorkerTaskMessage {
	cmd = "unknown";
	uuid = "unknown";
	name = "unnamed";
	workerId = 0;
	progress = 0;
	payloads = [];
	constructor(config) {
		this.cmd = config?.cmd ?? this.cmd;
		this.name = config?.name ?? this.name;
		this.workerId = config?.workerId ?? this.workerId;
		this.progress = config?.progress ?? this.progress;
	}
	addPayload(payloads) {
		if (!payloads) return;
		if (Array.isArray(payloads)) this.payloads = this.payloads.concat(payloads);
		else this.payloads.push(payloads);
	}
	static createNew(message) {
		return new WorkerTaskMessage(message);
	}
	static createEmpty() {
		return WorkerTaskMessage.createNew({});
	}
	static createFromExisting(message, options) {
		const wtm = WorkerTaskMessage.createNew(message);
		wtm.uuid = message.uuid;
		if (options?.overrideCmd) wtm.cmd = options.overrideCmd;
		if (options?.overrideUuid) wtm.uuid = options.overrideUuid;
		return wtm;
	}
	static pack(payloads, cloneBuffers) {
		const transferables = [];
		if (payloads) for (const payload of payloads) PayloadRegister.handler.get(payload.$type)?.pack(payload, transferables, cloneBuffers === true);
		return transferables;
	}
	static unpack(rawMessage, cloneBuffers) {
		const instance = WorkerTaskMessage.createFromExisting(rawMessage, { overrideUuid: rawMessage.uuid });
		if (rawMessage.payloads) for (const payload of rawMessage.payloads) {
			const handler = PayloadRegister.handler.get(payload.$type);
			instance.addPayload(handler?.unpack(payload, cloneBuffers === true));
		}
		return instance;
	}
	static fromPayload(payloads, cmd) {
		const wtm = WorkerTaskMessage.createNew({ cmd });
		wtm.addPayload(payloads);
		return wtm;
	}
};
//#endregion
//#region node_modules/.pnpm/wtd-core@3.0.0/node_modules/wtd-core/dist/WorkerTask.js
var WorkerTask = class {
	taskName;
	workerId;
	workerConfig;
	verbose = false;
	worker;
	executing = false;
	executionCounter = 0;
	awaitAnswers = /* @__PURE__ */ new Map();
	constructor(config) {
		this.taskName = config.taskName;
		this.workerId = config.workerId;
		this.workerConfig = config.workerConfig;
		this.verbose = config.verbose === true;
	}
	isWorkerExecuting() {
		return this.executing;
	}
	markExecuting(executing) {
		this.executing = executing;
	}
	getWorker() {
		return this.worker;
	}
	connectWorker() {
		if (this.worker) throw new Error("Worker already created. Aborting...");
		if (this.workerConfig.$type === "WorkerConfigDirect") this.worker = this.workerConfig.worker;
		else if (this.workerConfig.$type === "WorkerConfigParams") {
			if (this.workerConfig.url) {
				if (this.workerConfig.blob) this.worker = new Worker(this.workerConfig.url);
				else this.worker = new Worker(this.workerConfig.url.href, { type: this.workerConfig.workerType });
			}
		}
		if (!this.worker) throw new Error("No valid worker configuration was supplied. Aborting...");
		this.worker.onmessage = (async (answer) => {
			const wtm = answer.data;
			if (wtm.cmd) this.awaitAnswers.get(wtm.uuid ?? "unknown")?.forEach((handler) => {
				if (handler.name === wtm.cmd) {
					if (handler.log === true) `${wtm.cmd}${wtm.name ?? "unknown"}${wtm.uuid}`;
					for (const resolve of handler.resolve) resolve(wtm);
					if (handler.endExecution === true) this.markExecuting(false);
					if (handler.remove === true) this.awaitAnswers.delete(wtm.uuid);
				}
			});
			else console.error(`Received: unknown message: ${wtm}`);
		});
		this.worker.onerror = (async (answer) => {
			`${answer.error}`;
			Promise.reject(answer);
			this.markExecuting(false);
		});
	}
	async initWorker(def) {
		return new Promise((resolve, reject) => {
			if (!this.worker) {
				reject(/* @__PURE__ */ new Error("No worker is available. Aborting..."));
				this.markExecuting(false);
			} else {
				if (this.verbose) `${this.taskName}`;
				const message = def.message;
				message.cmd = WorkerTaskCommandRequest.INIT;
				const transferablesToWorker = this.handleTransferables(def);
				this.updateAwaitHandlers(message, [{
					name: WorkerTaskCommandResponse.INIT_COMPLETE,
					resolve: [resolve],
					reject,
					remove: true,
					log: this.verbose
				}]);
				this.worker?.postMessage(message, transferablesToWorker);
			}
		});
	}
	async executeWorker(def) {
		return new Promise((resolve, reject) => {
			if (!this.worker) {
				reject(/* @__PURE__ */ new Error("No worker is available. Aborting..."));
				this.markExecuting(false);
			} else {
				this.markExecuting(true);
				const message = def.message;
				message.cmd = WorkerTaskCommandRequest.EXECUTE;
				const transferablesToWorker = this.handleTransferables(def);
				const awaitHandlers = [];
				const resolveFuncs = [];
				if (def.onComplete) resolveFuncs.push(def.onComplete);
				resolveFuncs.push(resolve);
				awaitHandlers.push({
					name: WorkerTaskCommandResponse.EXECUTE_COMPLETE,
					resolve: resolveFuncs,
					reject,
					remove: true,
					endExecution: true,
					log: this.verbose
				});
				if (typeof def.onIntermediateConfirm === "function") awaitHandlers.push({
					name: WorkerTaskCommandResponse.INTERMEDIATE_CONFIRM,
					resolve: [def.onIntermediateConfirm],
					reject,
					remove: false,
					log: this.verbose
				});
				this.updateAwaitHandlers(message, awaitHandlers);
				this.worker.postMessage(message, transferablesToWorker);
			}
		});
	}
	/**
	* This is only possible if the worker is available.
	*/
	sentMessage(def) {
		return new Promise((resolve, reject) => {
			if (this.checkWorker(reject)) {
				const message = def.message;
				if (message.cmd === "unknown" || message.cmd.length === 0) throw new Error("No command provided. Aborting...");
				const transferablesToWorker = this.handleTransferables(def);
				if (def.awaitAnswer === true) {
					if (!def.answer) {
						reject(/* @__PURE__ */ new Error("No answer name provided. Aborting..."));
						return;
					}
					this.updateAwaitHandlers(message, [{
						name: def.answer,
						resolve: [resolve],
						reject,
						remove: true,
						log: this.verbose
					}]);
				}
				this.worker?.postMessage(message, transferablesToWorker);
				if (!def.awaitAnswer) resolve(WorkerTaskMessage.createEmpty());
			}
		});
	}
	updateAwaitHandlers(wtm, awaitHandlers) {
		wtm.workerId = this.workerId;
		wtm.uuid = this.buildUuid();
		this.awaitAnswers.set(wtm.uuid, awaitHandlers);
	}
	buildUuid() {
		return `${this.workerId}_${this.executionCounter++}_${Math.floor(Math.random() * 1e8)}`;
	}
	handleTransferables(def) {
		let transferablesToWorker = [];
		if (def.transferables) {
			if (def.copyTransferables === true) for (const transferable of def.transferables) transferablesToWorker.push(transferable.slice(0));
			else transferablesToWorker = def.transferables;
		}
		return transferablesToWorker;
	}
	checkWorker(reject) {
		if (!this.worker) {
			reject(/* @__PURE__ */ new Error("No worker is available. Aborting..."));
			this.markExecuting(false);
			return false;
		}
		return true;
	}
	dispose() {
		this.worker?.terminate();
	}
	printAwaitAnswers() {
		`${this.taskName}`;
		this.awaitAnswers;
	}
};
//#endregion
//#region node_modules/.pnpm/wtd-core@3.0.0/node_modules/wtd-core/dist/utilities.js
var fillTransferables = (buffers, transferables, cloneBuffers) => {
	for (const buffer of buffers) {
		const potentialClone = cloneBuffers ? buffer.slice(0) : buffer;
		const outputBuffer = potentialClone.buffer;
		if (outputBuffer) transferables.push(outputBuffer);
		else transferables.push(potentialClone);
	}
};
//#endregion
//#region node_modules/.pnpm/wtd-core@3.0.0/node_modules/wtd-core/dist/DataPayload.js
var DataPayload = class {
	$type = "DataPayload";
	message = {
		buffers: /* @__PURE__ */ new Map(),
		params: {}
	};
	progress = 0;
};
var DataPayloadHandler = class {
	pack(payload, transferables, cloneBuffers) {
		const dp = payload;
		if (dp.message.buffers) fillTransferables(dp.message.buffers?.values(), transferables, cloneBuffers);
		return transferables;
	}
	unpack(transportObject, cloneBuffers) {
		const dp = transportObject;
		const dtp = Object.assign(new DataPayload(), transportObject);
		if (dp.message.buffers) {
			for (const [name, buffer] of dp.message.buffers.entries()) if (dtp.message.buffers) dtp.message.buffers.set(name, cloneBuffers ? buffer.slice(0) : buffer);
		}
		return dtp;
	}
};
PayloadRegister.handler.set("DataPayload", new DataPayloadHandler());
//#endregion
//#region node_modules/.pnpm/wtd-three-ext@3.0.0_three@0.186.1/node_modules/wtd-three-ext/dist/MaterialsPayload.js
var MaterialsPayload = class {
	$type = "MaterialsPayload";
	message = {
		buffers: /* @__PURE__ */ new Map(),
		params: {},
		materials: /* @__PURE__ */ new Map(),
		materialsJson: /* @__PURE__ */ new Map(),
		multiMaterialNames: /* @__PURE__ */ new Map(),
		cloneInstructions: []
	};
	/**
	* Set an object containing named materials.
	* @param {Map<string, Material>} materials
	*/
	setMaterials(materials) {
		for (const [k, v] of materials.entries()) this.message.materials.set(k, v);
	}
	/**
	* Removes all textures and null values from all materials
	*/
	cleanMaterials() {
		const clonedMaterials = /* @__PURE__ */ new Map();
		for (const material of this.message.materials.values()) if (typeof material.clone === "function") {
			const clonedMaterial = material.clone();
			clonedMaterials.set(clonedMaterial.name, this.cleanMaterial(clonedMaterial));
		}
		this.message.materials = clonedMaterials;
	}
	cleanMaterial(material) {
		const objToAlter = material;
		for (const [k, v] of Object.entries(objToAlter)) if ((v instanceof Texture || v === null) && Object.prototype.hasOwnProperty.call(material, k)) objToAlter[k] = void 0;
		return material;
	}
	/**
	* Tell whether a multi-material was defined
	* @return {boolean}
	*/
	hasMultiMaterial() {
		return this.message.multiMaterialNames.size > 0;
	}
	/**
	* Returns a single material if it is defined or null.
	* @return {Material|null}
	*/
	getSingleMaterial() {
		return this.message.materials.size > 0 ? this.message.materials.values().next().value : void 0;
	}
	/**
	* Adds contained material or multi-material the provided materials object or it clones and adds new materials according clone instructions.
	*
	* @param {Map<string, Material>} materials
	* @param {boolean} log
	*
	* @return {Material|Material[]|undefined}
	*/
	processMaterialTransport(materials, log) {
		for (const cloneInstruction of this.message.cloneInstructions) MaterialUtils.cloneMaterial(materials, cloneInstruction, log);
		if (this.hasMultiMaterial()) {
			const outputMaterials = [];
			for (const [k, v] of this.message.multiMaterialNames.entries()) {
				const mat = materials.get(v);
				if (mat) outputMaterials[k] = mat;
			}
			return outputMaterials;
		} else {
			const singleMaterial = this.getSingleMaterial();
			if (singleMaterial) {
				const outputMaterial = materials.get(singleMaterial.name);
				return outputMaterial ? outputMaterial : singleMaterial;
			}
		}
	}
};
var MaterialsPayloadHandler = class {
	pack(payload, transferables, cloneBuffers) {
		const mp = payload;
		if (mp.message.buffers) fillTransferables(mp.message.buffers.values(), transferables, cloneBuffers);
		mp.message.materialsJson = MaterialUtils.getMaterialsJSON(mp.message.materials);
		return transferables;
	}
	unpack(transportObject, cloneBuffers) {
		const mp = transportObject;
		const materialsPayload = Object.assign(new MaterialsPayload(), transportObject);
		new DataPayloadHandler().unpack(mp, cloneBuffers);
		for (const [k, v] of mp.message.multiMaterialNames.entries()) materialsPayload.message.multiMaterialNames.set(k, v);
		const materialLoader = new MaterialLoader();
		for (const [k, v] of mp.message.materialsJson.entries()) materialsPayload.message.materials.set(k, materialLoader.parse(v));
		return materialsPayload;
	}
};
PayloadRegister.handler.set("MaterialsPayload", new MaterialsPayloadHandler());
//#endregion
//#region node_modules/.pnpm/wtd-three-ext@3.0.0_three@0.186.1/node_modules/wtd-three-ext/dist/MeshPayload.js
var GeometryType;
(function(GeometryType) {
	GeometryType[GeometryType["MESH"] = 0] = "MESH";
	GeometryType[GeometryType["LINE"] = 1] = "LINE";
	GeometryType[GeometryType["POINT"] = 2] = "POINT";
})(GeometryType || (GeometryType = {}));
var MeshPayload = class {
	$type = "MeshPayload";
	message = {
		params: {},
		buffers: /* @__PURE__ */ new Map(),
		geometryType: GeometryType.MESH,
		bufferGeometry: new BufferGeometry(),
		meshName: ""
	};
	/**
	* Set the {@link BufferGeometry} and geometry type that can be used when a mesh is created.
	*
	* @param {BufferGeometry} bufferGeometry
	* @param {number} geometryType [0=Mesh|1=LineSegments|2=Points]
	*/
	setBufferGeometry(bufferGeometry, geometryType) {
		this.message.bufferGeometry = bufferGeometry;
		this.message.geometryType = geometryType;
	}
	/**
	* Sets the mesh and the geometry type [0=Mesh|1=LineSegments|2=Points]
	* @param {Mesh} mesh
	* @param {number} geometryType
	*/
	setMesh(mesh, geometryType) {
		this.message.meshName = mesh.name;
		this.setBufferGeometry(mesh.geometry, geometryType);
	}
};
var MeshPayloadHandler = class {
	pack(payload, transferables, cloneBuffers) {
		const mp = payload;
		if (mp.message.buffers) {
			packGeometryBuffers(cloneBuffers, mp.message.bufferGeometry, mp.message.buffers);
			fillTransferables(mp.message.buffers.values(), transferables, cloneBuffers);
		}
		return transferables;
	}
	unpack(transportObject, cloneBuffers) {
		const mp = transportObject;
		const meshPayload = Object.assign(new MeshPayload(), mp);
		if (meshPayload.message.bufferGeometry) meshPayload.message.bufferGeometry = reconstructBuffer(cloneBuffers, meshPayload.message.bufferGeometry);
		return meshPayload;
	}
};
var packGeometryBuffers = (cloneBuffers, bufferGeometry, buffers) => {
	if (!(bufferGeometry instanceof BufferGeometry)) return;
	const vertexBA = bufferGeometry.getAttribute("position");
	const normalBA = bufferGeometry.getAttribute("normal");
	const uvBA = bufferGeometry.getAttribute("uv");
	const colorBA = bufferGeometry.getAttribute("color");
	const skinIndexBA = bufferGeometry.getAttribute("skinIndex");
	const skinWeightBA = bufferGeometry.getAttribute("skinWeight");
	const indexBA = bufferGeometry.getIndex();
	addAttributeToBuffers("position", vertexBA, cloneBuffers, buffers);
	addAttributeToBuffers("normal", normalBA, cloneBuffers, buffers);
	addAttributeToBuffers("uv", uvBA, cloneBuffers, buffers);
	addAttributeToBuffers("color", colorBA, cloneBuffers, buffers);
	addAttributeToBuffers("skinIndex", skinIndexBA, cloneBuffers, buffers);
	addAttributeToBuffers("skinWeight", skinWeightBA, cloneBuffers, buffers);
	addAttributeToBuffers("index", indexBA, cloneBuffers, buffers);
};
var addAttributeToBuffers = (name, input, cloneBuffer, buffers) => {
	if (input && input !== null) {
		const typedArray = input.array;
		buffers.set(name, cloneBuffer ? typedArray.slice(0) : typedArray);
	}
};
var reconstructBuffer = (cloneBuffers, transferredGeometry) => {
	const bufferGeometry = new BufferGeometry();
	if (!transferredGeometry) return bufferGeometry;
	else if (transferredGeometry instanceof BufferGeometry) return transferredGeometry;
	if (transferredGeometry.attributes) {
		const attr = transferredGeometry.attributes;
		assignAttributeFromTransfered(bufferGeometry, attr.position, "position", cloneBuffers);
		assignAttributeFromTransfered(bufferGeometry, attr.normal, "normal", cloneBuffers);
		assignAttributeFromTransfered(bufferGeometry, attr.uv, "uv", cloneBuffers);
		assignAttributeFromTransfered(bufferGeometry, attr.color, "color", cloneBuffers);
		assignAttributeFromTransfered(bufferGeometry, attr.skinIndex, "skinIndex", cloneBuffers);
		assignAttributeFromTransfered(bufferGeometry, attr.skinWeight, "skinWeight", cloneBuffers);
	}
	if (transferredGeometry.index !== null) {
		const indexAttr = transferredGeometry.index;
		if (indexAttr) {
			const indexBuffer = cloneBuffers ? indexAttr.array.slice(0) : indexAttr.array;
			bufferGeometry.setIndex(new BufferAttribute(indexBuffer, indexAttr.itemSize, indexAttr.normalized));
		}
	}
	const boundingBox = transferredGeometry.boundingBox;
	if (boundingBox !== null) bufferGeometry.boundingBox = Object.assign(new Box3(), boundingBox);
	const boundingSphere = transferredGeometry.boundingSphere;
	if (boundingSphere !== null) bufferGeometry.boundingSphere = Object.assign(new Sphere(), boundingSphere);
	bufferGeometry.uuid = transferredGeometry.uuid;
	bufferGeometry.name = transferredGeometry.name;
	bufferGeometry.groups = transferredGeometry.groups;
	bufferGeometry.drawRange = transferredGeometry.drawRange;
	bufferGeometry.userData = transferredGeometry.userData;
	return bufferGeometry;
};
var assignAttributeFromTransfered = (bufferGeometry, input, attrName, cloneBuffer) => {
	if (input) {
		const arrayLike = cloneBuffer ? input.array.slice(0) : input.array;
		bufferGeometry.setAttribute(attrName, new BufferAttribute(arrayLike, input.itemSize, input.normalized));
	}
};
PayloadRegister.handler.set("MeshPayload", new MeshPayloadHandler());
//#endregion
//#region node_modules/.pnpm/wwobjloader2@6.2.1_three@0.186.1/node_modules/wwobjloader2/dist/OBJLoader2.js
/**
* Creates a new OBJLoader2. Use it to load OBJ data from files or to parse OBJ data from arraybuffer or text.
*
* @param {LoadingManager} [manager] The loadingManager for the loader to use. Default is {@link LoadingManager}
* @constructor
*/
var OBJLoader2 = class OBJLoader2 extends Loader {
	static OBJLOADER2_VERSION = "6.0.0";
	parser = new OBJLoader2Parser();
	baseObject3d = new Object3D();
	materialStore = new MaterialStore(true);
	materialPerSmoothingGroup = false;
	useOAsMesh = false;
	useIndices = false;
	disregardNormals = false;
	modelName = "noname";
	callbacks;
	/**
	*
	* @param {LoadingManager} [manager]
	*/
	constructor(manager) {
		super(manager);
		this.callbacks = {
			onLoad: void 0,
			onError: void 0,
			onProgress: void 0,
			onMeshAlter: void 0
		};
	}
	/**
	* Enable or disable logging in general (except warn and error), plus enable or disable debug logging.
	*
	* @param {boolean} enabled True or false.
	* @param {boolean} debug True or false.
	*
	* @return {OBJLoader2}
	*/
	setLogging(enabled, debug) {
		this.parser.setLogging(enabled, debug);
		return this;
	}
	/**
	* Tells whether a material shall be created per smoothing group.
	*
	* @param {boolean} materialPerSmoothingGroup=false
	* @return {OBJLoader2}
	*/
	setMaterialPerSmoothingGroup(materialPerSmoothingGroup) {
		this.materialPerSmoothingGroup = materialPerSmoothingGroup === true;
		return this;
	}
	/**
	* Usually 'o' is meta-information and does not result in creation of new meshes, but mesh creation on occurrence of "o" can be enforced.
	*
	* @param {boolean} useOAsMesh=false
	* @return {OBJLoader2}
	*/
	setUseOAsMesh(useOAsMesh) {
		this.useOAsMesh = useOAsMesh === true;
		return this;
	}
	/**
	* Instructs loaders to create indexed {@link BufferGeometry}.
	*
	* @param {boolean} useIndices=false
	* @return {OBJLoader2}
	*/
	setUseIndices(useIndices) {
		this.useIndices = useIndices === true;
		return this;
	}
	/**
	* Tells whether normals should be completely disregarded and regenerated.
	*
	* @param {boolean} disregardNormals=false
	* @return {OBJLoader2}
	*/
	setDisregardNormals(disregardNormals) {
		this.disregardNormals = disregardNormals === true;
		return this;
	}
	/**
	* Set the name of the model.
	*
	* @param {string} modelName
	* @return {OBJLoader2}
	*/
	setModelName(modelName) {
		if (modelName.length > 0) this.modelName = modelName;
		return this;
	}
	/**
	* Returns the name of the models
	* @return {String}
	*/
	getModelName() {
		return this.modelName;
	}
	/**
	* Set the node where the loaded objects will be attached directly.
	*
	* @param {Object3D} baseObject3d Object already attached to scenegraph where new meshes will be attached to
	* @return {OBJLoader2}
	*/
	setBaseObject3d(baseObject3d) {
		this.baseObject3d = baseObject3d;
		return this;
	}
	/**
	* Clears materials object and sets the new ones.
	*
	* @param {Object} materials Object with named materials
	* @return {OBJLoader2}
	*/
	setMaterials(materials) {
		this.materialStore.addMaterialsFromObject(materials, false);
		return this;
	}
	/**
	* Register a function that is called when parsing was completed.
	*
	* @param {CallbackOnLoadType} onLoad
	* @return {OBJLoader2}
	*/
	setCallbackOnLoad(onLoad) {
		this.callbacks.onLoad = onLoad;
		return this;
	}
	/**
	* Register a function that is used to report overall processing progress.
	*
	* @param {CallbackOnProgressMessageType} onProgress
	* @return {OBJLoader2}
	*/
	setCallbackOnProgress(onProgress) {
		this.callbacks.onProgress = onProgress;
		return this;
	}
	/**
	* Register an error handler function that is called if errors occur. It can decide to just log or to throw an exception.
	*
	* @param {CallbackOnErrorMessageType} onError
	* @return {OBJLoader2}
	*/
	setCallbackOnError(onError) {
		this.callbacks.onError = onError;
		return this;
	}
	/**
	* Register a function that is called once a single mesh is available and it could be altered by the supplied function.
	*
	* @param {CallbackOnMeshAlterType} onMeshAlter
	* @return {OBJLoader2}
	*/
	setCallbackOnMeshAlter(onMeshAlter) {
		this.callbacks.onMeshAlter = onMeshAlter;
		return this;
	}
	/**
	* Use this convenient method to load a file at the given URL. By default the fileLoader uses an ArrayBuffer.
	*
	* @param {string}  url A string containing the path/URL of the file to be loaded.
	* @param {FileLoaderOnLoadType} [onLoad] A function to be called after loading is successfully completed. The function receives loaded Object3D as an argument.
	* @param {FileLoaderOnProgressType} [onProgress] A function to be called while the loading is in progress. The argument will be the XMLHttpRequest instance, which contains total and Integer bytes.
	* @param {FileLoaderOnErrorType} [onError] A function to be called if an error occurs during loading. The function receives the error as an argument.
	* @param {OnMeshAlterType} [onMeshAlter] Called after every single mesh is made available by the parser
	*/
	load(url, onLoad, onProgress, onError, onMeshAlter) {
		if (!(onLoad instanceof Function)) {
			const badOnLoadError = /* @__PURE__ */ new Error("onLoad is not a function! Aborting...");
			this._onError(badOnLoadError);
			throw badOnLoadError;
		} else this.setCallbackOnLoad(onLoad);
		if (!onError || !(onError instanceof Function)) onError = (errorEvent) => {
			if (Object.hasOwn(errorEvent, "currentTarget")) {
				const errorMessage = "Error occurred while downloading!\nurl: " + errorEvent.currentTarget;
				this._onError(new Error(errorMessage));
			}
		};
		if (url === void 0) onError(new ErrorEvent("An invalid url was provided. Unable to continue!"));
		let urlFull = "";
		try {
			urlFull = new URL(url).href;
		} catch (error) {
			urlFull = new URL(url, window.location.href).href;
		}
		let filename = urlFull;
		const urlParts = urlFull.split("/");
		if (urlParts.length > 2) {
			filename = urlParts[urlParts.length - 1];
			const urlPartsPath = urlParts.slice(0, urlParts.length - 1).join("/") + "/";
			if (urlPartsPath !== void 0) this.path = urlPartsPath;
		}
		if (!onProgress || !(onProgress instanceof Function)) {
			let numericalValueRef = 0;
			let numericalValue = 0;
			onProgress = (event) => {
				if (!event.lengthComputable) return;
				numericalValue = event.loaded / event.total;
				if (numericalValue > numericalValueRef) {
					numericalValueRef = numericalValue;
					const output = `Download of "${url}": ${(numericalValue * 100).toFixed(2)}%`;
					this._onProgress(output);
				}
			};
		}
		if (onMeshAlter) this.setCallbackOnMeshAlter(onMeshAlter);
		const fileLoaderOnLoad = (content) => {
			this.parse(content);
		};
		const fileLoader = new FileLoader(this.manager);
		fileLoader.setPath(this.path || this.resourcePath);
		fileLoader.setResponseType("arraybuffer");
		fileLoader.load(filename, fileLoaderOnLoad, onProgress, onError);
	}
	/**
	* Overrides the implementation of THREE.Loader, so it supports onMeshAlter.
	*
	* @param {string}  url A string containing the path/URL of the file to be loaded.
	* @param {FileLoaderOnProgressType} [onProgress] A function to be called while the loading is in progress. The argument will be the XMLHttpRequest instance, which contains total and Integer bytes.
	* @param {CallbackOnMeshAlterType} [onMeshAlter] Called after every single mesh is made available by the parser url
	* @returns Promise
	*/
	loadAsync(url, onProgress, onMeshAlter) {
		return new Promise((resolve, reject) => {
			this.load(url, resolve, onProgress, reject, onMeshAlter);
		});
	}
	/**
	* Parses OBJ data synchronously from arraybuffer or string and returns the {@link Object3D}.
	*
	* @param {ArrayBuffer|string} content OBJ data as Uint8Array or String
	* @return {Object3D}
	*/
	parse(objToParse) {
		if (this.parser.isLoggingEnabled()) {
			"" + OBJLoader2.OBJLOADER2_VERSION;
			"" + this.modelName;
		}
		if (objToParse instanceof ArrayBuffer) {
			if (this.parser.isLoggingEnabled()) {}
			this.configure();
			this.parser.execute(objToParse);
		} else if (typeof objToParse === "string") {
			if (this.parser.isLoggingEnabled()) {}
			this.configure();
			this.parser.executeLegacy(objToParse);
		} else this._onError(/* @__PURE__ */ new Error("Provided objToParse was neither of type String nor Uint8Array! Aborting..."));
		if (this.parser.isLoggingEnabled()) "" + this.modelName;
		return this.baseObject3d;
	}
	configure() {
		this.parser.setBulkConfig({
			materialPerSmoothingGroup: this.materialPerSmoothingGroup,
			useOAsMesh: this.useOAsMesh,
			useIndices: this.useIndices,
			disregardNormals: this.disregardNormals,
			modelName: this.modelName,
			materialNames: new Set(Array.from(this.materialStore.getMaterials().keys()))
		});
		this.parser._onAssetAvailable = (preparedMesh) => {
			const mesh = OBJLoader2.buildThreeMesh(preparedMesh, this.materialStore.getMaterials(), this.parser.isDebugLoggingEnabled());
			if (mesh) {
				this._onMeshAlter(mesh, preparedMesh.materialMetaInfo);
				this.baseObject3d.add(mesh);
			}
		};
		this.parser._onLoad = () => {
			this._onLoad();
		};
		this.printCallbackConfig();
	}
	printCallbackConfig() {
		if (this.parser.isLoggingEnabled()) {
			let printedConfig = "OBJLoader2 callback configuration:";
			if (this.callbacks.onProgress !== null) printedConfig += `\n\tcallbacks.onProgress: ${this.callbacks.onProgress?.name ?? void 0}`;
			if (this.callbacks.onError !== null) printedConfig += `\n\tcallbacks.onError: ${this.callbacks.onError?.name ?? void 0}`;
			if (this.callbacks.onMeshAlter !== null) printedConfig += `\n\tcallbacks.onMeshAlter: ${this.callbacks.onMeshAlter?.name ?? void 0}`;
			if (this.callbacks.onLoad !== null) printedConfig += `\n\tcallbacks.onLoad: ${this.callbacks.onLoad?.name ?? void 0}`;
		}
	}
	static buildThreeMesh({ meshName, vertexFA, normalFA, uvFA, colorFA, indexUA, createMultiMaterial, geometryGroups, multiMaterial, materialMetaInfo }, materials, debugLogging) {
		const geometry = new BufferGeometry();
		geometry.setAttribute("position", new BufferAttribute(vertexFA, 3, false));
		if (normalFA !== null) geometry.setAttribute("normal", new BufferAttribute(normalFA, 3, false));
		if (uvFA !== null) geometry.setAttribute("uv", new BufferAttribute(uvFA, 2, false));
		if (colorFA !== null) geometry.setAttribute("color", new BufferAttribute(colorFA, 3, false));
		if (indexUA !== null) geometry.setIndex(new BufferAttribute(indexUA, 1, false));
		if (geometryGroups.length > 0) for (const geometryGroup of geometryGroups) geometry.addGroup(geometryGroup.materialGroupOffset, geometryGroup.materialGroupLength, geometryGroup.materialIndex);
		if (normalFA === null) geometry.computeVertexNormals();
		let material;
		if (materialMetaInfo.materialCloneInstructions.length > 0) for (const materialCloneInstruction of materialMetaInfo.materialCloneInstructions) material = MaterialUtils.cloneMaterial(materials, materialCloneInstruction, debugLogging);
		else material = materials.get(materialMetaInfo.materialName);
		const realMultiMaterials = [];
		if (createMultiMaterial) for (let i = 0; i < multiMaterial.length; i++) {
			const currentMultiMaterial = materials.get(multiMaterial[i]);
			if (currentMultiMaterial) realMultiMaterials[i] = currentMultiMaterial;
		}
		let mesh;
		const appliedMaterial = createMultiMaterial ? realMultiMaterials : material;
		if (materialMetaInfo.geometryType === 0) mesh = new Mesh(geometry, appliedMaterial);
		else if (materialMetaInfo.geometryType === 1) mesh = new LineSegments(geometry, appliedMaterial);
		else mesh = new Points(geometry, appliedMaterial);
		if (mesh) mesh.name = meshName;
		return mesh;
	}
	_onProgress(text) {
		if (this.callbacks.onProgress) this.callbacks.onProgress(text);
		else this.parser._onProgress(text);
	}
	_onError(error) {
		if (this.callbacks.onError) this.callbacks.onError(error);
		else this.parser._onError(error.message);
	}
	_onMeshAlter(mesh, _materialMetaInfo) {
		if (this.callbacks.onMeshAlter) this.callbacks.onMeshAlter(mesh, this.baseObject3d);
	}
	_onLoad() {
		if (this.callbacks.onLoad) this.callbacks.onLoad(this.baseObject3d);
	}
};
//#endregion
//#region node_modules/.pnpm/wwobjloader2@6.2.1_three@0.186.1/node_modules/wwobjloader2/dist/OBJLoader2Parallel.js
/**
* Creates a new OBJLoader2Parallel. Use it to load OBJ data from files or to parse OBJ data from arraybuffer.
* It extends {@link OBJLoader2} with the capability to run the parser in a web worker.
*
* @param [LoadingManager] manager The loadingManager for the loader to use. Default is {@link LoadingManager}
* @constructor
*/
var OBJLoader2Parallel = class OBJLoader2Parallel extends OBJLoader2 {
	static OBJLOADER2_PARALLEL_VERSION = OBJLoader2.OBJLOADER2_VERSION;
	static DEFAULT_DEV_MODULE_WORKER_PATH = "./worker/OBJLoader2Worker.js";
	static DEFAULT_DEV_STANDARD_WORKER_PATH = "../lib/worker/OBJLoader2WorkerClassic.js";
	static DEFAULT_PROD_MODULE_WORKER_PATH = "./worker/OBJLoader2WorkerModule.js";
	static DEFAULT_PROD_STANDARD_WORKER_PATH = "./worker/OBJLoader2WorkerClassic.js";
	static TASK_NAME = "OBJLoader2Worker";
	moduleWorker = true;
	workerUrl = OBJLoader2Parallel.getModuleWorkerDefaultUrl();
	terminateWorkerOnLoad = false;
	workerTask;
	/**
	*
	* @param {LoadingManager} [manager]
	*/
	constructor(manager) {
		super(manager);
	}
	/**
	* Set whether jsm modules in workers should be used. This requires browser support
	* which is availableminall major browser apart from Firefox.
	*
	* @param {boolean} moduleWorker If the worker is a module or a standard worker
	* @param {URL} workerUrl Provide complete worker URL otherwise relative path to this module may not be correct
	* @return {OBJLoader2Parallel}
	*/
	setWorkerUrl(moduleWorker, workerUrl) {
		this.moduleWorker = moduleWorker === true;
		this.workerUrl = workerUrl;
		return this;
	}
	static getModuleWorkerDefaultUrl() {
		return new URL(OBJLoader2Parallel.DEFAULT_PROD_MODULE_WORKER_PATH, import.meta.url);
	}
	static getStandardWorkerDefaultUrl() {
		return new URL(OBJLoader2Parallel.DEFAULT_PROD_STANDARD_WORKER_PATH, import.meta.url);
	}
	/**
	* Request termination of worker once parser is finished.
	*
	* @param {boolean} terminateWorkerOnLoad True or false.
	* @return {OBJLoader2Parallel}
	*/
	setTerminateWorkerOnLoad(terminateWorkerOnLoad) {
		this.terminateWorkerOnLoad = terminateWorkerOnLoad === true;
		return this;
	}
	/**
	* See {@link OBJLoader2.load}
	*/
	load(url, onLoad, onProgress, onError, onMeshAlter) {
		const interceptOnLoad = (object3d) => {
			if (object3d.name === "OBJLoader2ParallelDummy") {
				if (this.parser.isDebugLoggingEnabled()) {}
			} else if (onLoad) onLoad(object3d);
			else throw new Error("\"onLoad\" callback was not provided. Aborting...");
		};
		OBJLoader2.prototype.load.call(this, url, interceptOnLoad, onProgress, onError, onMeshAlter);
	}
	/**
	* See {@link OBJLoader2.parse}
	* The callback onLoad needs to be set to be able to receive the content if used in parallel mode.
	*/
	parse(objToParse) {
		if (this.parser.isLoggingEnabled()) "" + OBJLoader2Parallel.OBJLOADER2_PARALLEL_VERSION;
		this.printCallbackConfig();
		this.initWorkerParse(objToParse);
		const dummy = new Object3D();
		dummy.name = "OBJLoader2ParallelDummy";
		return dummy;
	}
	async initWorkerParse(objToParse) {
		this.workerTask = new WorkerTask({
			taskName: OBJLoader2Parallel.TASK_NAME,
			workerId: 1,
			workerConfig: {
				$type: "WorkerConfigParams",
				workerType: this.moduleWorker ? "module" : "classic",
				blob: false,
				url: this.workerUrl
			},
			verbose: this.parser.isDebugLoggingEnabled()
		});
		try {
			await this.initWorker();
			if (this.parser.isDebugLoggingEnabled()) {}
			this.executeWorker(objToParse);
		} catch (e) {
			console.error(e);
		}
	}
	/**
	* Provide instructions on what is to be contained in the worker.
	*
	* @return {Promise<void>}
	* @private
	*/
	initWorker() {
		const dataPayload = new DataPayload();
		dataPayload.message.params = { logging: {
			enabled: this.parser.isLoggingEnabled(),
			debug: this.parser.isDebugLoggingEnabled()
		} };
		this.workerTask.connectWorker();
		return this.workerTask.initWorker({ message: WorkerTaskMessage.fromPayload(dataPayload) });
	}
	async executeWorker(objToParse) {
		const execMessage = WorkerTaskMessage.createEmpty();
		const dataPayload = new DataPayload();
		dataPayload.message.params = {
			modelName: this.modelName,
			useIndices: this.useIndices,
			disregardNormals: this.disregardNormals,
			materialPerSmoothingGroup: this.materialPerSmoothingGroup,
			useOAsMesh: this.useOAsMesh,
			logging: {
				enabled: this.parser.isLoggingEnabled(),
				debug: this.parser.isDebugLoggingEnabled()
			}
		};
		dataPayload.message.buffers?.set("modelData", objToParse);
		dataPayload.message.params.materialNames = new Set(Array.from(this.materialStore.getMaterials().keys()));
		execMessage.addPayload(dataPayload);
		const transferables = WorkerTaskMessage.pack(execMessage.payloads, false);
		try {
			await this.workerTask?.executeWorker({
				message: execMessage,
				onIntermediateConfirm: (message) => {
					this.onWorkerMessage(message);
				},
				onComplete: (message) => {
					this.onWorkerMessage(message);
					if (this.terminateWorkerOnLoad) this.workerTask.dispose();
				},
				transferables
			});
		} catch (e) {
			console.error(e);
		}
	}
	/**
	*
	* @param {Mesh} mesh
	* @param {object} materialMetaInfo
	*/
	onWorkerMessage(message) {
		const wtm = WorkerTaskMessage.unpack(message, false);
		if (wtm.cmd === WorkerTaskCommandResponse.INTERMEDIATE_CONFIRM) {
			const dataPayload = wtm.payloads.length === 1 ? wtm.payloads[0] : void 0;
			if (dataPayload && dataPayload.message.params) {
				const preparedMesh = dataPayload.message.params.preparedMesh;
				const mesh = OBJLoader2.buildThreeMesh(preparedMesh, this.materialStore.getMaterials(), this.parser.isDebugLoggingEnabled());
				if (mesh) {
					this._onMeshAlter(mesh, preparedMesh.materialMetaInfo);
					this.baseObject3d.add(mesh);
				}
			} else console.error("Received intermediate message without a proper payload");
		} else if (wtm.cmd === WorkerTaskCommandResponse.EXECUTE_COMPLETE) this._onLoad();
		else console.error(`Received unknown command: ${wtm.cmd}`);
	}
};
//#endregion
//#region node_modules/.pnpm/wwobjloader2@6.2.1_three@0.186.1/node_modules/wwobjloader2/dist/MtlObjBridge.js
var MtlObjBridge = class MtlObjBridge {
	link(processResult, assetLoader) {
		if (typeof assetLoader.setMaterials === "function") assetLoader.setMaterials(MtlObjBridge.addMaterialsFromMtlLoader(processResult));
	}
	/**
	* Returns the array instance of {@link Material}.
	*
	* @param {MTLLoader.MaterialCreator} materialCreator instance of MTLLoader
	*/
	static addMaterialsFromMtlLoader(materialCreator) {
		materialCreator.preload();
		return materialCreator.materials;
	}
};
//#endregion
//#region node_modules/.pnpm/wwobjloader2@6.2.1_three@0.186.1/node_modules/wwobjloader2/lib/worker/OBJLoader2WorkerModule.js?url
var OBJLoader2WorkerModule_default = "" + new URL("OBJLoader2WorkerModule-DTMpvldF.js", import.meta.url).href;
//#endregion
//#region packages/viewport3d/src/load3d/MeshModelAdapter.ts
var MeshModelAdapter = class {
	kind = "mesh";
	extensions = [
		"stl",
		"fbx",
		"obj",
		"gltf",
		"glb"
	];
	capabilities = {
		fitToViewer: true,
		requiresMaterialRebuild: false,
		gizmoTransform: true,
		lighting: true,
		exportable: true,
		materialModes: [
			"original",
			"clay",
			"normal",
			"wireframe"
		],
		fitTargetSize: 5
	};
	gltfLoader = new GLTFLoader();
	mtlLoader = new MTLLoader();
	fbxLoader = new FBXLoader();
	stlLoader = new STLLoader();
	async load(ctx, path, filename, fetchBytes) {
		const extension = filename.split(".").pop()?.toLowerCase();
		const object = await (extension === "stl" ? this.loadSTL(ctx, path, fetchBytes) : extension === "fbx" ? this.loadFBX(ctx, path, fetchBytes) : extension === "obj" ? this.loadOBJ(ctx, path, filename, fetchBytes) : extension === "gltf" || extension === "glb" ? this.loadGLTF(ctx, path, fetchBytes) : Promise.resolve(null));
		return object ? {
			object,
			capabilities: this.capabilities
		} : null;
	}
	async loadSTL(ctx, path, fetchBytes) {
		this.stlLoader.setPath(path);
		const geometry = this.stlLoader.parse(await fetchBytes());
		ctx.setOriginalModel(geometry);
		geometry.computeVertexNormals();
		const mesh = new Mesh(geometry, ctx.standardMaterial);
		const group = new Group();
		group.add(mesh);
		return group;
	}
	async loadFBX(ctx, path, fetchBytes) {
		this.fbxLoader.setPath(path);
		const bytes = await fetchBytes();
		const fbxModel = this.fbxLoader.parse(bytes, path);
		ctx.setOriginalModel(fbxModel);
		const polygons = isBinaryFbx(bytes) ? readFbxPolygons(bytes) : [];
		fbxModel.traverse((child) => {
			if (child instanceof Mesh) {
				ctx.registerOriginalMaterial(child, child.material);
				if (child instanceof SkinnedMesh) child.frustumCulled = false;
				const faceSizes = matchFbxPolygons(polygons, child.geometry);
				if (faceSizes) registerFaceSizes(child.geometry, faceSizes);
			}
		});
		return fbxModel;
	}
	async loadOBJ(ctx, path, filename, fetchBytes) {
		const objLoader = new OBJLoader2Parallel();
		objLoader.setWorkerUrl(true, new URL(OBJLoader2WorkerModule_default, import.meta.url));
		objLoader.setTerminateWorkerOnLoad(true);
		objLoader.setBaseObject3d(new Object3D());
		if (ctx.materialMode === "original") try {
			this.mtlLoader.setPath(path);
			const mtlFileName = filename.replace(/\.obj$/i, ".mtl");
			const materials = await this.mtlLoader.loadAsync(mtlFileName);
			materials.preload();
			const materialsFromMtl = MtlObjBridge.addMaterialsFromMtlLoader(materials);
			objLoader.setMaterials(materialsFromMtl);
		} catch {
			console.warn("No MTL file found or error loading it, continuing without materials");
		}
		const model = await this.parseOBJ(objLoader, await fetchBytes());
		model.traverse((child) => {
			if (child instanceof Mesh) ctx.registerOriginalMaterial(child, child.material);
		});
		return model;
	}
	parseOBJ(objLoader, bytes) {
		return new Promise((resolve, reject) => {
			objLoader.setCallbackOnLoad(resolve);
			objLoader.parse(bytes.slice(0));
			rejectOnWorkerFailure(objLoader, reject);
		});
	}
	async loadGLTF(ctx, path, fetchBytes) {
		this.gltfLoader.setPath(path);
		const gltf = await this.gltfLoader.parseAsync(await fetchBytes(), path);
		ctx.setOriginalModel(gltf);
		gltf.scene.traverse((child) => {
			if (child instanceof Mesh) {
				child.geometry.computeVertexNormals();
				ctx.registerOriginalMaterial(child, child.material);
				if (child instanceof SkinnedMesh) child.frustumCulled = false;
				if (hasNgonEncoding(child)) registerFaceSizes(child.geometry, ngonEncodedFaceSizes(child.geometry));
			}
		});
		return gltf.scene;
	}
};
function rejectOnWorkerFailure(objLoader, reject) {
	const worker = objLoader.workerTask?.getWorker();
	if (!worker) return;
	const fail = (reason) => {
		worker.terminate();
		reject(reason);
	};
	worker.addEventListener("error", (event) => fail(event.error ?? new Error(event.message)));
	const postMessage = worker.postMessage.bind(worker);
	worker.postMessage = ((message, transfer) => {
		try {
			postMessage(message, transfer);
		} catch (error) {
			fail(error);
			throw error;
		}
	});
}
//#endregion
//#region packages/viewport3d/src/load3d/loader/ply.ts
function parsePLYHeader(lines) {
	let vertexCount = 0;
	let headerEndLine = 0;
	let hasColor = false;
	let xIndex = -1;
	let yIndex = -1;
	let zIndex = -1;
	let redIndex = -1;
	let greenIndex = -1;
	let blueIndex = -1;
	let propertyIndex = 0;
	for (let i = 0; i < lines.length; i++) {
		const line = lines[i].trim();
		if (line.startsWith("element vertex")) vertexCount = parseInt(line.split(/\s+/)[2]);
		else if (line.startsWith("property")) {
			const parts = line.split(/\s+/);
			const propName = parts[parts.length - 1];
			if (propName === "x") xIndex = propertyIndex;
			else if (propName === "y") yIndex = propertyIndex;
			else if (propName === "z") zIndex = propertyIndex;
			else if (propName === "red") {
				hasColor = true;
				redIndex = propertyIndex;
			} else if (propName === "green") greenIndex = propertyIndex;
			else if (propName === "blue") blueIndex = propertyIndex;
			propertyIndex++;
		} else if (line === "end_header") {
			headerEndLine = i;
			break;
		}
	}
	if (vertexCount === 0 || xIndex < 0 || yIndex < 0 || zIndex < 0) return null;
	return {
		vertexCount,
		hasColor,
		propertyIndices: {
			x: xIndex,
			y: yIndex,
			z: zIndex,
			red: redIndex,
			green: greenIndex,
			blue: blueIndex
		},
		headerEndLine
	};
}
function parsePLYVertices(lines, header) {
	const { vertexCount, hasColor, propertyIndices, headerEndLine } = header;
	const { x: xIndex, y: yIndex, z: zIndex } = propertyIndices;
	const { red: redIndex, green: greenIndex, blue: blueIndex } = propertyIndices;
	const positions = new Float32Array(vertexCount * 3);
	const colors = hasColor ? new Float32Array(vertexCount * 3) : null;
	let vertexIndex = 0;
	for (let i = headerEndLine + 1; i < lines.length && vertexIndex < vertexCount; i++) {
		const line = lines[i].trim();
		if (!line) continue;
		const parts = line.split(/\s+/);
		if (parts.length < 3) continue;
		const posIndex = vertexIndex * 3;
		positions[posIndex] = parseFloat(parts[xIndex]);
		positions[posIndex + 1] = parseFloat(parts[yIndex]);
		positions[posIndex + 2] = parseFloat(parts[zIndex]);
		if (hasColor && colors && redIndex >= 0 && greenIndex >= 0 && blueIndex >= 0) {
			if (parts.length > Math.max(redIndex, greenIndex, blueIndex)) {
				colors[posIndex] = parseInt(parts[redIndex]) / 255;
				colors[posIndex + 1] = parseInt(parts[greenIndex]) / 255;
				colors[posIndex + 2] = parseInt(parts[blueIndex]) / 255;
			}
		}
		vertexIndex++;
	}
	return {
		positions,
		colors,
		vertexCount: vertexIndex
	};
}
/**
* Parse ASCII PLY data from an ArrayBuffer
* Returns positions and colors as typed arrays
*/
function parseASCIIPLY(arrayBuffer) {
	const lines = new TextDecoder().decode(arrayBuffer).split("\n");
	const header = parsePLYHeader(lines);
	if (!header) return null;
	return parsePLYVertices(lines, header);
}
/**
* Check if PLY data is in ASCII format
*/
function isPLYAsciiFormat(arrayBuffer) {
	return new TextDecoder().decode(arrayBuffer.slice(0, 500)).includes("format ascii");
}
var PLY_HEADER_SCAN_BYTES = 65536;
var GAUSSIAN_SPLAT_PROPERTIES = [
	"scale_0",
	"scale_1",
	"scale_2",
	"rot_0",
	"rot_1",
	"rot_2",
	"rot_3"
];
function readPLYHeaderLines(arrayBuffer) {
	const lines = new TextDecoder("latin1").decode(arrayBuffer.slice(0, PLY_HEADER_SCAN_BYTES)).split("\n").map((line) => line.trim());
	const end = lines.indexOf("end_header");
	if (lines[0] !== "ply" || end < 0) return null;
	return lines.slice(0, end);
}
function vertexPropertyNames(headerLines) {
	const names = /* @__PURE__ */ new Set();
	let inVertexElement = false;
	for (const line of headerLines) {
		const parts = line.split(/\s+/);
		if (parts[0] === "element") inVertexElement = parts[1] === "vertex";
		else if (inVertexElement && parts[0] === "property") names.add(parts[parts.length - 1]);
	}
	return names;
}
function isGaussianSplatPLY(arrayBuffer) {
	const headerLines = readPLYHeaderLines(arrayBuffer);
	if (!headerLines) return false;
	if (headerLines.some((line) => line.startsWith("format ascii"))) return false;
	const properties = vertexPropertyNames(headerLines);
	return GAUSSIAN_SPLAT_PROPERTIES.every((name) => properties.has(name));
}
//#endregion
//#region packages/viewport3d/src/load3d/loader/FastPLYLoader.ts
/**
* Fast ASCII PLY Loader
* Optimized for simple ASCII PLY files with position and color data
* 4-5x faster than Three.js PLYLoader for ASCII files
*/
var FastPLYLoader = class {
	parse(arrayBuffer) {
		const plyData = parseASCIIPLY(arrayBuffer);
		if (!plyData) throw new Error("Failed to parse PLY data");
		const geometry = new BufferGeometry();
		geometry.setAttribute("position", new BufferAttribute(plyData.positions, 3));
		if (plyData.colors) geometry.setAttribute("color", new BufferAttribute(plyData.colors, 3));
		return geometry;
	}
};
//#endregion
//#region packages/viewport3d/src/load3d/PointCloudModelAdapter.ts
var POINT_CLOUD_CAPABILITIES = {
	fitToViewer: true,
	requiresMaterialRebuild: true,
	gizmoTransform: false,
	lighting: true,
	exportable: true,
	materialModes: [
		"original",
		"pointCloud",
		"normal",
		"wireframe"
	],
	fitTargetSize: 5
};
var PointCloudModelAdapter = class {
	getPLYEngine;
	kind = "pointCloud";
	extensions = ["ply"];
	capabilities = POINT_CLOUD_CAPABILITIES;
	plyLoader = new PLYLoader();
	fastPlyLoader = new FastPLYLoader();
	constructor(getPLYEngine) {
		this.getPLYEngine = getPLYEngine;
	}
	async load(ctx, path, _filename, fetchBytes) {
		const arrayBuffer = await fetchBytes();
		const plyGeometry = isPLYAsciiFormat(arrayBuffer) && this.getPLYEngine() === "fastply" ? this.fastPlyLoader.parse(arrayBuffer) : (this.plyLoader.setPath(path), this.plyLoader.parse(arrayBuffer));
		ctx.setOriginalModel(plyGeometry);
		plyGeometry.computeVertexNormals();
		const hasVertexColors = plyGeometry.hasAttribute("color");
		const hasFaces = (plyGeometry.index?.count ?? 0) > 0;
		return {
			object: ctx.materialMode === "pointCloud" || !hasFaces ? buildPointsGroup(ctx, plyGeometry, hasVertexColors) : buildMeshGroup(ctx, plyGeometry, hasVertexColors),
			capabilities: hasFaces ? POINT_CLOUD_CAPABILITIES : {
				...POINT_CLOUD_CAPABILITIES,
				materialModes: ["pointCloud"]
			}
		};
	}
};
function buildPointsGroup(ctx, geometry, hasVertexColors) {
	geometry.computeBoundingSphere();
	if (geometry.boundingSphere) {
		const { center, radius } = geometry.boundingSphere;
		geometry.translate(-center.x, -center.y, -center.z);
		if (radius > 0) {
			const scale = 1 / radius;
			geometry.scale(scale, scale, scale);
		}
	}
	const pointMaterial = hasVertexColors ? new PointsMaterial({
		size: .005,
		vertexColors: true,
		sizeAttenuation: true
	}) : new PointsMaterial({
		size: .005,
		color: 13421772,
		sizeAttenuation: true
	});
	const points = new Points(geometry, pointMaterial);
	ctx.registerOriginalMaterial(points, pointMaterial);
	const group = new Group();
	group.add(points);
	return group;
}
function buildMeshGroup(ctx, geometry, hasVertexColors) {
	const material = hasVertexColors ? new MeshStandardMaterial({
		vertexColors: true,
		metalness: 0,
		roughness: .5,
		side: 2
	}) : ctx.standardMaterial.clone();
	if (!hasVertexColors && material instanceof MeshStandardMaterial) material.side = 2;
	const mesh = new Mesh(geometry, material);
	ctx.registerOriginalMaterial(mesh, material);
	const group = new Group();
	group.add(mesh);
	return group;
}
function buildPointCloudForMaterialMode(originalGeometry, mode, standardMaterial, originalMaterials) {
	const geometry = originalGeometry.clone();
	const hasVertexColors = geometry.hasAttribute("color");
	const ctx = {
		setOriginalModel: () => {},
		registerOriginalMaterial: (mesh, material) => originalMaterials.set(mesh, material),
		standardMaterial,
		materialMode: mode
	};
	if (mode === "pointCloud") return buildPointsGroup(ctx, geometry, hasVertexColors);
	const group = buildMeshGroup(ctx, geometry, hasVertexColors);
	if (mode === "normal" || mode === "wireframe") {
		const mesh = group.children[0];
		mesh.material = mode === "normal" ? new MeshNormalMaterial({
			flatShading: false,
			side: 2
		}) : new MeshBasicMaterial({
			color: 16777215,
			wireframe: true
		});
	}
	return group;
}
//#endregion
//#region packages/viewport3d/src/load3d/SplatModelAdapter.ts
var SplatModelAdapter = class {
	kind = "splat";
	extensions = [
		"spz",
		"splat",
		"ksplat",
		"ply"
	];
	capabilities = {
		fitToViewer: true,
		requiresMaterialRebuild: false,
		gizmoTransform: true,
		lighting: false,
		exportable: true,
		materialModes: [],
		fitTargetSize: 20
	};
	async matches(extension, fetchBytes) {
		if (extension !== "ply") return true;
		return isGaussianSplatPLY(await fetchBytes());
	}
	async load(ctx, _path, filename, fetchBytes) {
		const arrayBuffer = await fetchBytes();
		const splatMesh = new SplatMesh({
			fileBytes: arrayBuffer,
			fileName: filename
		});
		await splatMesh.initialized;
		splatMesh.quaternion.set(1, 0, 0, 0);
		ctx.setOriginalModel(splatMesh);
		const splatGroup = new Group();
		splatGroup.add(splatMesh);
		return {
			object: splatGroup,
			capabilities: this.capabilities
		};
	}
	computeBounds(model) {
		const splat = model.children[0];
		if (!(splat instanceof SplatMesh)) return null;
		splat.updateWorldMatrix(true, false);
		return splat.getBoundingBox(false).clone().applyMatrix4(splat.matrixWorld);
	}
	disposeModel(model) {
		model.traverse((child) => {
			if (child instanceof SplatMesh) child.dispose();
		});
	}
	defaultCameraPose() {
		return {
			size: new Vector3(5, 5, 5),
			center: new Vector3(0, 2.5, 0)
		};
	}
};
//#endregion
//#region packages/viewport3d/src/load3d/SceneModelManager.ts
function isResourceRenderable(object) {
	return object instanceof Mesh || object instanceof Points || object instanceof Line;
}
function disposeObject3D(object, preservedMaterials, preservedTextures = /* @__PURE__ */ new Set()) {
	const preserved = preservedMaterials instanceof Material ? /* @__PURE__ */ new Set([preservedMaterials]) : preservedMaterials;
	object.traverse((child) => {
		if (!isResourceRenderable(child)) return;
		child.geometry.dispose();
		const materials = Array.isArray(child.material) ? child.material : [child.material];
		for (const material of materials) {
			if (preserved.has(material)) continue;
			for (const [, texture] of materialTextures(material)) if (!preservedTextures.has(texture)) texture.dispose();
			material.dispose();
		}
	});
}
function materialTextures(material) {
	return Object.entries(material).filter((entry) => entry[1] instanceof Texture);
}
function cloneMaterialResources(material) {
	const clone = material.clone();
	for (const [property, texture] of materialTextures(clone)) if (!Reflect.set(clone, property, texture.clone())) throw new TypeError(`Unable to clone material resource ${property}`);
	return clone;
}
/** Give a cloned renderable graph independent ownership of GPU resources. */
function cloneObject3DResources(object) {
	object.traverse((child) => {
		if (!isResourceRenderable(child)) return;
		const geometry = child.geometry.clone();
		const faceSizes = faceSizesFor(child.geometry);
		if (faceSizes) registerFaceSizes(geometry, faceSizes);
		child.geometry = geometry;
		child.material = Array.isArray(child.material) ? child.material.map(cloneMaterialResources) : cloneMaterialResources(child.material);
	});
}
var SceneModelManager = class {
	currentModel = null;
	originalModel = null;
	originalRotation = null;
	currentUpDirection = "original";
	materialMode = "original";
	originalMaterials = /* @__PURE__ */ new WeakMap();
	normalMaterial;
	standardMaterial;
	wireframeMaterial;
	occluderMaterial;
	depthMaterial;
	clayMaterial;
	originalFileName = null;
	originalURL = null;
	appliedTexture = null;
	ownsAppliedTexture = true;
	textureLoader;
	skeletonHelper = null;
	showSkeleton = false;
	scene;
	viewState;
	eventManager;
	activeCamera;
	setupCamera;
	setupGizmo;
	getCurrentCapabilities;
	getBoundsFromAdapter;
	disposeModelViaAdapter;
	getDefaultCameraPose;
	quadWireframe = new QuadWireframeManager();
	get preservedMaterials() {
		return /* @__PURE__ */ new Set([
			this.normalMaterial,
			this.standardMaterial,
			this.wireframeMaterial,
			this.depthMaterial,
			this.clayMaterial,
			this.occluderMaterial
		]);
	}
	constructor(scene, viewState, eventManager, getActiveCamera, setupCamera, setupGizmo, getCurrentCapabilities = () => DEFAULT_MODEL_CAPABILITIES, getBoundsFromAdapter = () => null, disposeModelViaAdapter = () => {}, getDefaultCameraPose = () => null) {
		this.scene = scene;
		this.viewState = viewState;
		this.eventManager = eventManager;
		this.activeCamera = getActiveCamera();
		this.setupCamera = setupCamera;
		this.textureLoader = new TextureLoader();
		this.setupGizmo = setupGizmo;
		this.getCurrentCapabilities = getCurrentCapabilities;
		this.getBoundsFromAdapter = getBoundsFromAdapter;
		this.disposeModelViaAdapter = disposeModelViaAdapter;
		this.getDefaultCameraPose = getDefaultCameraPose;
		this.normalMaterial = new MeshNormalMaterial({
			flatShading: false,
			side: 2,
			normalScale: new Vector2(1, 1),
			transparent: false,
			opacity: 1
		});
		this.wireframeMaterial = new MeshBasicMaterial({
			color: 16777215,
			wireframe: true,
			transparent: false,
			opacity: 1
		});
		this.occluderMaterial = new MeshBasicMaterial({
			colorWrite: false,
			side: 2,
			polygonOffset: true,
			polygonOffsetFactor: 1,
			polygonOffsetUnits: 1
		});
		this.depthMaterial = new MeshDepthMaterial({
			depthPacking: BasicDepthPacking,
			side: 2
		});
		this.depthMaterial.onBeforeCompile = (shader) => {
			shader.uniforms.cameraType = { value: this.activeCamera instanceof OrthographicCamera ? 1 : 0 };
			shader.fragmentShader = `
                uniform float cameraType;
                ${shader.fragmentShader}
              `;
			shader.fragmentShader = shader.fragmentShader.replace(/gl_FragColor\s*=\s*vec4\(\s*vec3\(\s*1.0\s*-\s*fragCoordZ\s*\)\s*,\s*opacity\s*\)\s*;/, `
                  float depth = 1.0 - fragCoordZ;
                  if (cameraType > 0.5) {
                    depth = pow(depth, 400.0);
                  } else {
                    depth = pow(depth, 0.6);
                  }
                  gl_FragColor = vec4(vec3(depth), opacity);
                `);
		};
		this.depthMaterial.customProgramCacheKey = () => {
			return this.activeCamera instanceof OrthographicCamera ? "ortho" : "persp";
		};
		this.standardMaterial = this.createSTLMaterial();
		this.clayMaterial = new MeshStandardMaterial({
			color: 8947848,
			metalness: 0,
			roughness: .9,
			flatShading: false,
			side: 2
		});
	}
	init() {}
	dispose() {
		this.clearModel();
		this.quadWireframe.dispose();
		this.normalMaterial.dispose();
		this.standardMaterial.dispose();
		this.wireframeMaterial.dispose();
		this.occluderMaterial.dispose();
		this.depthMaterial.dispose();
		this.clayMaterial.dispose();
	}
	createSTLMaterial() {
		return new MeshStandardMaterial({
			color: 8421504,
			metalness: .1,
			roughness: .8,
			flatShading: false,
			side: 2
		});
	}
	borrowAppliedTexture(texture, takeOwnership = false) {
		if (this.ownsAppliedTexture) this.appliedTexture?.dispose();
		[this.appliedTexture, this.ownsAppliedTexture] = [texture, takeOwnership];
	}
	appliedTexturesToPreserve() {
		return this.ownsAppliedTexture || !this.appliedTexture ? /* @__PURE__ */ new Set() : /* @__PURE__ */ new Set([this.appliedTexture]);
	}
	removeAllMainModelsFromScene() {
		this.quadWireframe.clear();
		const oldMainModels = [];
		this.scene.traverse((obj) => {
			if (obj.name === "MainModel") oldMainModels.push(obj);
		});
		oldMainModels.forEach((oldModel) => {
			this.restoreOriginalMaterials(oldModel);
			disposeObject3D(oldModel, this.preservedMaterials, this.appliedTexturesToPreserve());
			this.disposeModelViaAdapter(oldModel);
			this.scene.remove(oldModel);
		});
	}
	restoreOriginalMaterials(model) {
		const preserved = this.preservedMaterials;
		model.traverse((child) => {
			if (!(child instanceof Mesh)) return;
			const original = this.originalMaterials.get(child);
			if (!original || original === child.material) return;
			const replaced = Array.isArray(child.material) ? child.material : [child.material];
			for (const material of replaced) if (!preserved.has(material)) material.dispose();
			child.material = original;
		});
	}
	rebuildForMaterialMode(mode) {
		if (!(this.originalModel instanceof BufferGeometry)) return;
		this.removeAllMainModelsFromScene();
		this.currentModel = null;
		const newModel = buildPointCloudForMaterialMode(this.originalModel, mode, this.standardMaterial, this.originalMaterials);
		newModel.name = "MainModel";
		if (mode !== "pointCloud") {
			const box = new Box3().setFromObject(newModel);
			const size = box.getSize(new Vector3());
			const center = box.getCenter(new Vector3());
			const maxDim = Math.max(size.x, size.y, size.z);
			const scale = this.getCurrentCapabilities().fitTargetSize / maxDim;
			newModel.scale.multiplyScalar(scale);
			box.setFromObject(newModel);
			box.getCenter(center);
			box.getSize(size);
			newModel.position.set(-center.x, -box.min.y, -center.z);
		}
		this.scene.add(newModel);
		this.currentModel = newModel;
		this.eventManager.emitEvent("materialModeChange", mode);
	}
	setMaterialMode(mode) {
		if (!this.currentModel || mode === this.materialMode) return;
		this.materialMode = mode;
		if (this.getCurrentCapabilities().requiresMaterialRebuild) {
			this.rebuildForMaterialMode(mode);
			return;
		}
		if (mode === "depth") this.viewState.outputColorSpace = LinearSRGBColorSpace;
		else this.viewState.outputColorSpace = SRGBColorSpace;
		this.currentModel.visible = true;
		this.currentModel.traverse((child) => {
			if (child instanceof Mesh) switch (mode) {
				case "depth":
					if (!this.originalMaterials.has(child)) this.originalMaterials.set(child, child.material);
					child.material = this.depthMaterial;
					break;
				case "normal":
					if (!this.originalMaterials.has(child)) this.originalMaterials.set(child, child.material);
					child.material = this.normalMaterial;
					break;
				case "wireframe":
					if (!this.originalMaterials.has(child)) this.originalMaterials.set(child, child.material);
					child.material = this.wireframeMaterial;
					break;
				case "clay":
					if (!this.originalMaterials.has(child)) this.originalMaterials.set(child, child.material);
					child.material = this.clayMaterial;
					break;
				case "original":
				case "pointCloud": {
					const originalMaterial = this.originalMaterials.get(child);
					if (originalMaterial) child.material = originalMaterial;
					else if (this.appliedTexture) child.material = new MeshStandardMaterial({
						map: this.appliedTexture,
						metalness: .1,
						roughness: .8,
						side: 2
					});
					else child.material = this.standardMaterial;
					break;
				}
			}
		});
		this.syncQuadWireframe(mode);
		this.eventManager.emitEvent("materialModeChange", mode);
	}
	clearQuadWireframe() {
		this.quadWireframe.clear();
	}
	syncQuadWireframe(mode) {
		if (mode !== "wireframe") {
			this.quadWireframe.hide();
			return;
		}
		if (!this.currentModel) return;
		for (const mesh of this.quadWireframe.show(this.currentModel)) mesh.material = this.occluderMaterial;
	}
	setupModelMaterials(model) {
		model.traverse((child) => {
			if (child instanceof Mesh) this.originalMaterials.set(child, child.material);
		});
		this.setMaterialMode("original");
	}
	disposeCurrentModel() {
		const model = this.currentModel;
		if (!model) return;
		const appliedTextures = this.appliedTexture ? /* @__PURE__ */ new Set([this.appliedTexture]) : /* @__PURE__ */ new Set();
		this.quadWireframe.clear();
		this.scene.remove(model);
		this.restoreOriginalMaterials(model);
		disposeObject3D(model, this.preservedMaterials, appliedTextures);
		this.disposeModelViaAdapter(model);
		const { originalFileName, originalURL } = this;
		this.reset();
		this.originalFileName = originalFileName;
		this.originalURL = originalURL;
	}
	clearModel() {
		this.quadWireframe.clear();
		const objectsToRemove = [];
		for (const object of Array.from(this.scene.children)) if (!(object instanceof GridHelper || object instanceof Light || object instanceof Camera || object instanceof SparkRenderer || object.name === "GizmoTransformControls")) objectsToRemove.push(object);
		objectsToRemove.forEach((obj) => {
			this.scene.remove(obj);
			this.restoreOriginalMaterials(obj);
			disposeObject3D(obj, this.preservedMaterials, this.appliedTexturesToPreserve());
			this.disposeModelViaAdapter(obj);
		});
		this.reset();
	}
	reset() {
		this.currentModel = null;
		this.originalModel = null;
		this.originalRotation = null;
		this.currentUpDirection = "original";
		this.setMaterialMode("original");
		this.originalFileName = null;
		this.originalURL = null;
		if (this.appliedTexture && this.ownsAppliedTexture) this.appliedTexture.dispose();
		this.appliedTexture = null;
		this.ownsAppliedTexture = true;
		if (this.skeletonHelper) {
			this.scene.remove(this.skeletonHelper);
			this.skeletonHelper.dispose();
			this.skeletonHelper = null;
		}
		this.showSkeleton = false;
		this.originalMaterials = /* @__PURE__ */ new WeakMap();
	}
	hasSkeleton() {
		if (!this.currentModel) return false;
		let found = false;
		this.currentModel.traverse((child) => {
			if (child instanceof SkinnedMesh) found = true;
		});
		return found;
	}
	setShowSkeleton(show) {
		this.showSkeleton = show;
		if (show) {
			if (!this.skeletonHelper && this.currentModel) {
				const rootBones = [];
				const skinnedMeshes = [];
				this.currentModel.traverse((child) => {
					if (child instanceof Bone && !(child.parent instanceof Bone)) rootBones.push(child);
					else if (child instanceof SkinnedMesh) skinnedMeshes.push(child);
				});
				const skeletonRoot = rootBones.at(0) ?? skinnedMeshes.at(0);
				if (skeletonRoot) {
					this.skeletonHelper = new SkeletonHelper(skeletonRoot);
					this.scene.add(this.skeletonHelper);
				}
			} else if (this.skeletonHelper) this.skeletonHelper.visible = true;
		} else if (this.skeletonHelper) this.skeletonHelper.visible = false;
		this.eventManager.emitEvent("skeletonVisibilityChange", show);
	}
	addModelToScene(model) {
		this.currentModel = model;
		model.name = "MainModel";
		this.scene.add(this.currentModel);
	}
	computeWorldBounds(model) {
		return this.getBoundsFromAdapter(model) ?? new Box3().setFromObject(model);
	}
	getCurrentBounds() {
		if (!this.currentModel) return null;
		return this.computeWorldBounds(this.currentModel);
	}
	async setupModel(model) {
		this.currentModel = model;
		model.name = "MainModel";
		if (!this.getCurrentCapabilities().fitToViewer) {
			const pose = this.getDefaultCameraPose();
			if (pose) {
				this.scene.add(model);
				this.setupCamera(pose.size, pose.center);
				return;
			}
		}
		this.scene.add(model);
		const pendingMaterialMode = this.materialMode;
		this.setupModelMaterials(model);
		if (pendingMaterialMode !== "original") this.setMaterialMode(pendingMaterialMode);
		const validModes = this.getCurrentCapabilities().materialModes;
		if (validModes.length > 0 && !validModes.includes(this.materialMode)) {
			this.materialMode = validModes[0];
			this.eventManager.emitEvent("materialModeChange", this.materialMode);
		}
		if (this.currentUpDirection !== "original") this.setUpDirection(this.currentUpDirection);
		const box = this.computeWorldBounds(model);
		const size = box.getSize(new Vector3());
		const center = box.getCenter(new Vector3());
		this.setupCamera(size, center);
		this.setupGizmo(model);
	}
	fitToViewer() {
		if (!this.currentModel || !this.getCurrentCapabilities().fitToViewer) return;
		const model = this.currentModel;
		model.scale.set(1, 1, 1);
		model.position.set(0, 0, 0);
		model.rotation.set(0, 0, 0);
		const box = this.computeWorldBounds(model);
		const size = box.getSize(new Vector3());
		const center = box.getCenter(new Vector3());
		const maxDim = Math.max(size.x, size.y, size.z);
		if (maxDim === 0) return;
		const scale = this.getCurrentCapabilities().fitTargetSize / maxDim;
		model.scale.set(scale, scale, scale);
		const scaledBox = this.computeWorldBounds(model);
		scaledBox.getCenter(center);
		scaledBox.getSize(size);
		model.position.set(-center.x, -scaledBox.min.y, -center.z);
		this.originalRotation = null;
		if (this.currentUpDirection !== "original") this.setUpDirection(this.currentUpDirection);
		const newBox = this.computeWorldBounds(model);
		const newSize = newBox.getSize(new Vector3());
		const newCenter = newBox.getCenter(new Vector3());
		this.setupCamera(newSize, newCenter);
		this.setupGizmo(model);
	}
	setOriginalModel(model) {
		this.originalModel = model;
	}
	setUpDirection(direction) {
		if (!this.currentModel) return;
		const directionChanged = this.currentUpDirection !== direction;
		this.originalRotation ??= this.currentModel.rotation.clone();
		this.currentUpDirection = direction;
		this.currentModel.rotation.copy(this.originalRotation);
		switch (direction) {
			case "original": break;
			case "-x":
				this.currentModel.rotation.z = Math.PI / 2;
				break;
			case "+x":
				this.currentModel.rotation.z = -Math.PI / 2;
				break;
			case "-y":
				this.currentModel.rotation.x = Math.PI;
				break;
			case "+y": break;
			case "-z":
				this.currentModel.rotation.x = Math.PI / 2;
				break;
			case "+z": this.currentModel.rotation.x = -Math.PI / 2;
		}
		this.eventManager.emitEvent("upDirectionChange", direction);
		if (directionChanged) this.setupGizmo(this.currentModel);
	}
};
//#endregion
//#region packages/viewport3d/src/load3d/LoaderManager.ts
function isNotFoundError(error) {
	if (!(error instanceof Error)) return false;
	if ("response" in error && typeof error.response === "object" && error.response !== null && "status" in error.response && error.response.status === 404) return true;
	return /\b404\b/.test(error.message);
}
/**
* Default adapter set: mesh + splat + pointCloud. Each adapter declares the
* file extensions it owns. For shared extensions (.ply), the adapter with an
* async `matches()` tiebreaker is tried first; the unconditional adapter acts
* as the fallback — so SplatModelAdapter precedes PointCloudModelAdapter.
*/
function defaultAdapters(host) {
	return [
		new MeshModelAdapter(),
		new SplatModelAdapter(),
		new PointCloudModelAdapter(host.getPLYEngine)
	];
}
var LoaderManager = class {
	modelManager;
	eventManager;
	host;
	adapters;
	adapterRef;
	currentLoadId = 0;
	disposed = false;
	constructor(modelManager, eventManager, host, adapters, adapterRef) {
		this.modelManager = modelManager;
		this.eventManager = eventManager;
		this.host = host;
		this.adapters = adapters ? [...adapters] : defaultAdapters(host);
		this.adapterRef = adapterRef ?? createAdapterRef();
	}
	getCurrentAdapter() {
		return this.adapterRef.current;
	}
	init() {
		this.disposed = false;
	}
	dispose() {
		this.disposed = true;
		this.currentLoadId += 1;
	}
	async loadModel(url, originalFileName, options) {
		if (this.disposed) return "cancelled";
		const loadId = ++this.currentLoadId;
		try {
			this.eventManager.emitEvent("modelLoadingStart", null);
			this.modelManager.clearModel();
			this.adapterRef.current = null;
			this.adapterRef.capabilities = null;
			this.modelManager.originalURL = url;
			const fileExtension = this.setOriginalFileName(url, originalFileName);
			if (!fileExtension) {
				if (options?.silent) throw new TypeError("Unknown model file type");
				this.eventManager.emitEvent("modelLoadingEnd", null);
				return "unknown-type";
			}
			const result = await this.loadModelInternal(url, fileExtension, loadId, options?.silent, options?.signal);
			if (options?.signal?.aborted) return this.cancelAbandonedLoad(result, loadId);
			return await this.publishLoadResult(result, loadId, fileExtension, options?.silent);
		} catch (error) {
			if (options?.signal?.aborted) return this.cancelAbandonedLoad(null, loadId);
			return this.handleLoadError(error, loadId, options);
		}
	}
	/**
	* Parsers ignore the signal, so an aborted load can still resolve — and
	* `loadId` does not catch it when the caller starts no newer load.
	*/
	cancelAbandonedLoad(result, loadId) {
		if (result) this.disposeLoadResult(result);
		if (loadId === this.currentLoadId) this.eventManager.emitEvent("modelLoadingEnd", null);
		return "cancelled";
	}
	async publishLoadResult(result, loadId, fileExtension, silent) {
		if (loadId !== this.currentLoadId) {
			if (result) this.disposeLoadResult(result);
			return "cancelled";
		}
		if (!result && silent) throw new TypeError(`No model was produced for type: ${fileExtension}`);
		if (result) {
			this.adapterRef.current = result.adapter;
			this.adapterRef.capabilities = result.capabilities;
			await this.modelManager.setupModel(result.object);
			if (loadId !== this.currentLoadId) return "cancelled";
		}
		this.eventManager.emitEvent("modelLoadingEnd", null);
		return result ? "loaded" : "empty";
	}
	setOriginalFileName(url, originalFileName) {
		if (originalFileName) {
			this.modelManager.originalFileName = originalFileName.split("/").pop()?.split(".")[0] || "model";
			return originalFileName.split(".").pop()?.toLowerCase();
		}
		const filename = new URLSearchParams(url.split("?")[1]).get("filename");
		this.modelManager.originalFileName = filename ? filename.split(".")[0] || "model" : "model";
		return filename?.split(".").pop()?.toLowerCase();
	}
	handleLoadError(error, loadId, options) {
		if (loadId !== this.currentLoadId) return "cancelled";
		this.eventManager.emitEvent("modelLoadingEnd", null);
		if (options?.silent) throw error;
		console.error("Error loading model:", error);
		return isNotFoundError(error) ? "not-found" : "failed";
	}
	disposeLoadResult(result) {
		result.adapter.disposeModel?.(result.object);
		disposeObject3D(result.object, this.modelManager.standardMaterial);
	}
	async pickAdapter(extension, fetchBytes) {
		const candidates = this.adapters.filter((a) => a.extensions.includes(extension));
		for (const adapter of candidates) {
			if (!adapter.matches) return adapter;
			if (await adapter.matches(extension, fetchBytes)) return adapter;
		}
		return null;
	}
	createLoadContext(loadId, signal) {
		const mm = this.modelManager;
		const isCurrent = () => loadId === this.currentLoadId && !signal?.aborted;
		return {
			setOriginalModel: (model) => {
				if (isCurrent()) mm.setOriginalModel(model);
			},
			registerOriginalMaterial: (mesh, material) => {
				if (isCurrent()) mm.originalMaterials.set(mesh, material);
			},
			get standardMaterial() {
				return mm.standardMaterial;
			},
			get materialMode() {
				return mm.materialMode;
			}
		};
	}
	async loadModelInternal(url, fileExtension, loadId, silent, signal) {
		const params = new URLSearchParams(url.split("?")[1]);
		const filename = params.get("filename");
		if (!filename) {
			if (!silent) console.error("Missing filename in URL:", url);
			return null;
		}
		const requestedType = params.get("type");
		const loadRootFolder = requestedType === "output" || requestedType === "temp" ? requestedType : "input";
		const subfolder = params.get("subfolder") ?? "";
		const path = "api/view?type=" + loadRootFolder + "&subfolder=" + encodeURIComponent(subfolder) + "&filename=";
		let bytesPromise = null;
		const fetchBytes = () => bytesPromise ??= fetchModelData(this.host.fetchApi, path, filename, signal);
		const adapter = await this.pickAdapter(fileExtension, fetchBytes);
		if (!adapter) return null;
		if (this.disposed) return null;
		const loadResult = await adapter.load(this.createLoadContext(loadId, signal), path, filename, fetchBytes);
		return loadResult ? {
			object: loadResult.object,
			capabilities: loadResult.capabilities,
			adapter
		} : null;
	}
};
//#endregion
//#region packages/viewport3d/src/load3d/RecordingManager.ts
var RecordingManager = class {
	mediaRecorder = null;
	recordedChunks = [];
	isRecording = false;
	recordingStream = null;
	recordingIndicator = null;
	scene;
	sourceCanvas;
	eventManager;
	recordingStartTime = 0;
	recordingDuration = 0;
	recordingCanvas = null;
	recordingContext = null;
	animationFrameId = null;
	constructor(scene, sourceCanvas, eventManager) {
		this.scene = scene;
		this.sourceCanvas = sourceCanvas;
		this.eventManager = eventManager;
		this.setupRecordingIndicator();
	}
	setupRecordingIndicator() {
		const map = new TextureLoader().load("data:image/svg+xml;base64," + btoa(`<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64">
        <circle cx="32" cy="32" r="24" fill="#4CAF50" opacity="0.8" />
        <circle cx="32" cy="32" r="16" fill="#2E7D32" opacity="0.8" />
      </svg>`));
		const material = new SpriteMaterial({
			map,
			transparent: true,
			depthTest: false,
			depthWrite: false
		});
		this.recordingIndicator = new Sprite(material);
		this.recordingIndicator.scale.set(.5, .5, .5);
		this.recordingIndicator.position.set(-.8, .8, 0);
		this.recordingIndicator.visible = false;
		this.scene.add(this.recordingIndicator);
	}
	async startRecording(targetWidth, targetHeight) {
		if (this.isRecording) return;
		try {
			const sourceCanvas = this.sourceCanvas;
			const sourceWidth = sourceCanvas.width;
			const sourceHeight = sourceCanvas.height;
			const recordWidth = targetWidth || sourceWidth;
			const recordHeight = targetHeight || sourceHeight;
			this.recordingCanvas = document.createElement("canvas");
			this.recordingCanvas.width = recordWidth;
			this.recordingCanvas.height = recordHeight;
			this.recordingContext = this.recordingCanvas.getContext("2d", { alpha: false });
			if (!this.recordingContext) throw new Error("Failed to get 2D context for recording canvas");
			const sourceAspectRatio = sourceWidth / sourceHeight;
			const targetAspectRatio = recordWidth / recordHeight;
			let sx = 0;
			let sy = 0;
			let sw = sourceWidth;
			let sh = sourceHeight;
			if (Math.abs(sourceAspectRatio - targetAspectRatio) > .01) {
				if (sourceAspectRatio > targetAspectRatio) {
					sw = sourceHeight * targetAspectRatio;
					sx = (sourceWidth - sw) / 2;
				} else {
					sh = sourceWidth / targetAspectRatio;
					sy = (sourceHeight - sh) / 2;
				}
			}
			const captureFrame = () => {
				if (!this.isRecording || !this.recordingContext) return;
				this.recordingContext.drawImage(sourceCanvas, sx, sy, sw, sh, 0, 0, recordWidth, recordHeight);
				this.animationFrameId = requestAnimationFrame(captureFrame);
			};
			this.recordingStream = this.recordingCanvas.captureStream(30);
			this.mediaRecorder = new MediaRecorder(this.recordingStream, {
				mimeType: "video/webm;codecs=vp9",
				videoBitsPerSecond: 5e6
			});
			this.recordedChunks = [];
			this.mediaRecorder.ondataavailable = (event) => {
				if (event.data.size > 0) this.recordedChunks.push(event.data);
			};
			this.mediaRecorder.onstop = () => {
				this.recordingIndicator.visible = false;
				this.isRecording = false;
				this.recordingStream = null;
				if (this.animationFrameId !== null) {
					cancelAnimationFrame(this.animationFrameId);
					this.animationFrameId = null;
				}
				this.eventManager.emitEvent("recordingStopped", {
					duration: this.recordingDuration,
					hasRecording: this.recordedChunks.length > 0
				});
			};
			if (this.recordingIndicator) this.recordingIndicator.visible = true;
			this.mediaRecorder.start(100);
			this.isRecording = true;
			this.recordingStartTime = Date.now();
			captureFrame();
			this.eventManager.emitEvent("recordingStarted", null);
		} catch (error) {
			console.error("Error starting recording:", error);
			this.eventManager.emitEvent("recordingError", error);
		}
	}
	stopRecording() {
		if (!this.isRecording || !this.mediaRecorder) return;
		this.recordingDuration = (Date.now() - this.recordingStartTime) / 1e3;
		if (this.animationFrameId !== null) {
			cancelAnimationFrame(this.animationFrameId);
			this.animationFrameId = null;
		}
		this.mediaRecorder.stop();
		if (this.recordingStream) this.recordingStream.getTracks().forEach((track) => track.stop());
		this.recordingCanvas = null;
		this.recordingContext = null;
	}
	getIsRecording() {
		return this.isRecording;
	}
	hasRecording() {
		return this.recordedChunks.length > 0;
	}
	getRecordingDuration() {
		return this.recordingDuration;
	}
	getRecordingData() {
		if (this.recordedChunks.length !== 0) {
			const blob = new Blob(this.recordedChunks, { type: "video/webm" });
			return URL.createObjectURL(blob);
		}
		return null;
	}
	exportRecording(filename = "scene-recording.mp4") {
		if (this.recordedChunks.length === 0) {
			this.eventManager.emitEvent("recordingError", /* @__PURE__ */ new Error("No recording available to export"));
			return;
		}
		this.eventManager.emitEvent("exportingRecording", null);
		try {
			downloadBlob(filename, new Blob(this.recordedChunks, { type: "video/webm" }));
			this.eventManager.emitEvent("recordingExported", null);
		} catch (error) {
			console.error("Error exporting recording:", error);
			this.eventManager.emitEvent("recordingError", error);
		}
	}
	clearRecording() {
		this.recordedChunks = [];
		this.recordingDuration = 0;
		this.eventManager.emitEvent("recordingCleared", null);
	}
	dispose() {
		if (this.animationFrameId !== null) {
			cancelAnimationFrame(this.animationFrameId);
			this.animationFrameId = null;
		}
		this.stopRecording();
		this.clearRecording();
		this.recordingCanvas = null;
		this.recordingContext = null;
		if (this.recordingIndicator) {
			this.scene.remove(this.recordingIndicator);
			this.recordingIndicator.material.map?.dispose();
			this.recordingIndicator.material.dispose();
		}
	}
};
//#endregion
//#region packages/viewport3d/src/load3d/createLoad3d.ts
function buildLoad3dDeps(container, host) {
	const view = new RendererView(container);
	const renderer = view.renderer;
	const eventManager = new EventManager();
	const adapterRef = createAdapterRef();
	const cameraManager = new CameraManager(renderer, eventManager);
	const controlsManager = new ControlsManager(container, cameraManager.activeCamera);
	cameraManager.setControls(controlsManager.controls);
	const getActiveCamera = () => cameraManager.activeCamera;
	const getControls = () => controlsManager.controls;
	const sceneManager = new SceneManager(view, getActiveCamera, getControls, eventManager);
	const lightingManager = new LightingManager(sceneManager.scene, eventManager);
	const hdriManager = new HDRIManager(sceneManager.scene, renderer, view.state, eventManager);
	const viewHelperManager = new ViewHelperManager(renderer, getActiveCamera, getControls, () => cameraManager.getCameraState(), eventManager);
	const modelManager = new SceneModelManager(sceneManager.scene, view.state, eventManager, getActiveCamera, (size, center) => cameraManager.setupForModel(size, center), (model) => gizmoManager.setupForModel(model), () => adapterRef.capabilities ?? DEFAULT_MODEL_CAPABILITIES, (model) => adapterRef.current?.computeBounds?.(model) ?? null, (model) => adapterRef.current?.disposeModel?.(model), () => adapterRef.current?.defaultCameraPose?.() ?? null);
	const loaderManager = new LoaderManager(modelManager, eventManager, host, void 0, adapterRef);
	const recordingManager = new RecordingManager(sceneManager.scene, view.canvas, eventManager);
	const animationManager = new AnimationManager(eventManager);
	const gizmoManager = new GizmoManager(sceneManager.scene, container, controlsManager.controls, getActiveCamera, () => {
		const transform = gizmoManager.getTransform();
		eventManager.emitEvent("gizmoTransformChange", {
			...transform,
			enabled: gizmoManager.isEnabled(),
			mode: gizmoManager.getMode()
		});
	});
	return {
		view,
		eventManager,
		sceneManager,
		cameraManager,
		controlsManager,
		lightingManager,
		hdriManager,
		viewHelperManager,
		loaderManager,
		modelManager,
		recordingManager,
		animationManager,
		gizmoManager,
		adapterRef,
		resolveImageURL: host.resolveImageURL
	};
}
function createLoad3d(container, host, options) {
	return new Load3d(container, buildLoad3dDeps(container, host), options);
}
//#endregion
export { cloneObject3DResources as n, adoptClonedModel as r, createLoad3d as t };
