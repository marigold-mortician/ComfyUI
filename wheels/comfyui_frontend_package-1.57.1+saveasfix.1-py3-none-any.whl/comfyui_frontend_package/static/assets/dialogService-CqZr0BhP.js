import "./rolldown-runtime-xtsTai4I.js";
import { t as useCommandStore } from "./commandStore-XD_i1hej.js";
import { a as isArguments } from "./iteratee-D-xtYlr8.js";
import { t as noop } from "./noop-CsGmlYWz.js";
import { n as useSettingStore } from "./settingStore-DRRi2kOn.js";
import { M as isBuffer, N as isTypedArray, P as isPrimitive, j as getSymbols, t as cloneDeep } from "./cloneDeep-BX7AjX4w.js";
import { t as isPlainObject$1 } from "./isPlainObject-6prWdO5v.js";
import { o as isUnsafeProperty } from "./get-Bk-Y8oEe.js";
import { n as isArrayLike } from "./isObject-BDwzDI3k.js";
import { i as api, n as PromptExecutionError } from "./api-BdJmXw98.js";
import { F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, I as createBlock, Kt as normalizeClass, L as createCommentVNode, O as Fragment, P as computed, R as createElementBlock, T as withKeys, Tt as withDirectives, U as createVNode, Wt as unref, Yt as toDisplayString, at as onMounted, b as vModelCheckbox, ct as openBlock, dt as renderSlot, ft as resolveComponent, ut as renderList, w as vShow, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { n as useApp, r as isTypedArray$1 } from "./appInstance-CiT6CpGM.js";
import { n as useTelemetry } from "./telemetry-IkzvF0TI.js";
import { bt as zPromptErrorResponse } from "./zod.gen-DzuaBm8H.js";
import { t as useToast } from "./toastStore-Dg65fRgL.js";
import { d as t, f as te, l as st } from "./i18n-BRluoVl-.js";
import { r as reportError } from "./reportError-BHgDVvfb.js";
import { t as assert } from "./assert--qJvwrYk.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
import { t as DialogTitle_default } from "./DialogTitle-CWOHHLwH.js";
import { t as useCopyToClipboard } from "./useCopyToClipboard-DUbSOtYA.js";
import { t as useSystemStatsStore } from "./systemStatsStore-DAY0RqGT.js";
import { t as Input_default } from "./Input-12QxL1XI.js";
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/math/sumBy.mjs
/**
* Calculates the sum of an array of numbers when applying
* the `getValue` function to each element.
*
* If the array is empty, this function returns `0`.
*
* @template T - The type of elements in the array.
* @param items - An array to calculate the sum.
* @param getValue - A function that selects a numeric value from each element.
*   It receives the element and its zero‑based index in the array.
* @returns The sum of all the numbers as determined by the `getValue` function.
*
* @example
* sumBy([{ a: 1 }, { a: 2 }, { a: 3 }], (x, i) => x.a * i); // Returns: 8
* sumBy([], () => 1); // Returns: 0
*/
function sumBy(items, getValue) {
	let result = 0;
	for (let i = 0; i < items.length; i++) result += getValue(items[i], i);
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/object/clone.mjs
/**
* Creates a shallow clone of the given object.
*
* @template T - The type of the object.
* @param obj - The object to clone.
* @returns A shallow clone of the given object.
*
* @example
* // Clone a primitive value
* const num = 29;
* const clonedNum = clone(num);
* console.log(clonedNum); // 29
* console.log(clonedNum === num); // true
*
* @example
* // Clone an array
* const arr = [1, 2, 3];
* const clonedArr = clone(arr);
* console.log(clonedArr); // [1, 2, 3]
* console.log(clonedArr === arr); // false
*
* @example
* // Clone an object
* const obj = { a: 1, b: 'es-toolkit', c: [1, 2, 3] };
* const clonedObj = clone(obj);
* console.log(clonedObj); // { a: 1, b: 'es-toolkit', c: [1, 2, 3] }
* console.log(clonedObj === obj); // false
*/
function clone(obj) {
	if (isPrimitive(obj)) return obj;
	if (Array.isArray(obj) || isTypedArray(obj) || obj instanceof ArrayBuffer || typeof SharedArrayBuffer !== "undefined" && obj instanceof SharedArrayBuffer) return obj.slice(0);
	const prototype = Object.getPrototypeOf(obj);
	if (prototype == null) return Object.assign(Object.create(prototype), obj);
	const Constructor = prototype.constructor;
	if (obj instanceof Date || obj instanceof Map || obj instanceof Set) return new Constructor(obj);
	if (obj instanceof RegExp) {
		const newRegExp = new Constructor(obj);
		newRegExp.lastIndex = obj.lastIndex;
		return newRegExp;
	}
	if (obj instanceof DataView) return new Constructor(obj.buffer.slice(0));
	if (obj instanceof Error) {
		let newError;
		if (obj instanceof AggregateError) newError = new Constructor(obj.errors, obj.message, { cause: obj.cause });
		else newError = new Constructor(obj.message, { cause: obj.cause });
		newError.stack = obj.stack;
		Object.assign(newError, obj);
		return newError;
	}
	if (typeof File !== "undefined" && obj instanceof File) return new Constructor([obj], obj.name, {
		type: obj.type,
		lastModified: obj.lastModified
	});
	if (typeof obj === "object") return Object.assign(Object.create(prototype), obj);
	return obj;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isPlainObject.mjs
/**
* Checks if a given value is a plain object.
*
* A plain object is an object created by the `{}` literal, `new Object()`, or
* `Object.create(null)`.
*
* This function also handles objects with custom
* `Symbol.toStringTag` properties.
*
* `Symbol.toStringTag` is a built-in symbol that a constructor can use to customize the
* default string description of objects.
*
* @param [object] - The value to check.
* @returns True if the value is a plain object, otherwise false.
*
* @example
* console.log(isPlainObject({})); // true
* console.log(isPlainObject([])); // false
* console.log(isPlainObject(null)); // false
* console.log(isPlainObject(Object.create(null))); // true
* console.log(isPlainObject(new Map())); // false
*/
function isPlainObject(object) {
	if (typeof object !== "object") return false;
	if (object == null) return false;
	if (Object.getPrototypeOf(object) === null) return true;
	if (Object.prototype.toString.call(object) !== "[object Object]") {
		const tag = object[Symbol.toStringTag];
		if (tag == null) return false;
		if (!Object.getOwnPropertyDescriptor(object, Symbol.toStringTag)?.writable) return false;
		return object.toString() === `[object ${tag}]`;
	}
	let proto = object;
	while (Object.getPrototypeOf(proto) !== null) proto = Object.getPrototypeOf(proto);
	return Object.getPrototypeOf(object) === proto;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isObjectLike.mjs
/**
* Checks if the given value is object-like.
*
* A value is object-like if its type is object and it is not null.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to an object-like value.
*
* @param value - The value to test if it is an object-like.
* @returns `true` if the value is an object-like, `false` otherwise.
*
* @example
* const value1 = { a: 1 };
* const value2 = [1, 2, 3];
* const value3 = 'abc';
* const value4 = () => {};
* const value5 = null;
*
* console.log(isObjectLike(value1)); // true
* console.log(isObjectLike(value2)); // true
* console.log(isObjectLike(value3)); // false
* console.log(isObjectLike(value4)); // false
* console.log(isObjectLike(value5)); // false
*/
function isObjectLike(value) {
	return typeof value === "object" && value !== null;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isArrayLikeObject.mjs
/**
* Checks if the given value is a non-primitive, array-like object.
*
* @param value The value to check.
* @returns `true` if the value is a non-primitive, array-like object, `false` otherwise.
*
* @example
* isArrayLikeObject([1, 2, 3]); // true
* isArrayLikeObject({ 0: 'a', length: 1 }); // true
* isArrayLikeObject('abc'); // false
* isArrayLikeObject(()=>{}); // false
*/
function isArrayLikeObject(value) {
	return isObjectLike(value) && isArrayLike(value);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/mergeWith.mjs
/**
* Merges the properties of one or more source objects into the target object using a customizer function.
*
* This function performs a deep merge, recursively merging nested objects and arrays.
* If a property in the source object is an array or object and the corresponding property in the target object is also an array or object, they will be merged.
* If a property in the source object is `undefined`, it will not overwrite a defined property in the target object.
*
* You can provide a custom `merge` function to control how properties are merged. The `merge` function is called for each property that is being merged and receives the following arguments:
*
* - `targetValue`: The current value of the property in the target object.
* - `sourceValue`: The value of the property in the source object.
* - `key`: The key of the property being merged.
* - `target`: The target object.
* - `source`: The source object.
* - `stack`: A `Map` used to keep track of objects that have already been processed to handle circular references.
*
* The `merge` function should return the value to be set in the target object. If it returns `undefined`, a default deep merge will be applied for arrays and objects.
*
* The function can handle multiple source objects and will merge them all into the target object.
*
* @param object - The target object into which the source object properties will be merged. This object is modified in place.
* @param otherArgs - Additional source objects to merge into the target object, including the custom `merge` function.
* @returns The updated target object with properties from the source object(s) merged in.
*
* @example
* const target = { a: 1, b: 2 };
* const source = { b: 3, c: 4 };
*
* mergeWith(target, source, (targetValue, sourceValue) => {
*   if (typeof targetValue === 'number' && typeof sourceValue === 'number') {
*     return targetValue + sourceValue;
*   }
* });
* // Returns { a: 1, b: 5, c: 4 }
* @example
* const target = { a: [1], b: [2] };
* const source = { a: [3], b: [4] };
*
* const result = mergeWith(target, source, (objValue, srcValue) => {
*   if (Array.isArray(objValue)) {
*     return objValue.concat(srcValue);
*   }
* });
*
* expect(result).toEqual({ a: [1, 3], b: [2, 4] });
*/
function mergeWith(object, ...otherArgs) {
	const sources = otherArgs.slice(0, -1);
	const merge = otherArgs[otherArgs.length - 1];
	let result = object;
	for (let i = 0; i < sources.length; i++) {
		const source = sources[i];
		result = mergeWithDeep(result, source, merge, /* @__PURE__ */ new Map());
	}
	return result;
}
function mergeWithDeep(target, source, merge, stack) {
	if (isPrimitive(target)) target = Object(target);
	if (source == null || typeof source !== "object") return target;
	if (stack.has(source)) return clone(stack.get(source));
	stack.set(source, target);
	if (Array.isArray(source)) {
		source = source.slice();
		for (let i = 0; i < source.length; i++) source[i] = source[i] ?? void 0;
	}
	const sourceKeys = [...Object.keys(source), ...getSymbols(source)];
	for (let i = 0; i < sourceKeys.length; i++) {
		const key = sourceKeys[i];
		if (isUnsafeProperty(key)) continue;
		let sourceValue = source[key];
		let targetValue = target[key];
		if (isArguments(sourceValue)) sourceValue = { ...sourceValue };
		if (isArguments(targetValue)) targetValue = { ...targetValue };
		if (isBuffer(sourceValue)) sourceValue = cloneDeep(sourceValue);
		if (Array.isArray(sourceValue)) if (Array.isArray(targetValue)) {
			const cloned = [];
			const targetKeys = Reflect.ownKeys(targetValue);
			for (let i = 0; i < targetKeys.length; i++) {
				const targetKey = targetKeys[i];
				cloned[targetKey] = targetValue[targetKey];
			}
			targetValue = cloned;
		} else if (isArrayLikeObject(targetValue)) {
			const cloned = [];
			for (let i = 0; i < targetValue.length; i++) cloned[i] = targetValue[i];
			targetValue = cloned;
		} else targetValue = [];
		const merged = merge(targetValue, sourceValue, key, target, source, stack);
		if (merged !== void 0) target[key] = merged;
		else if (Array.isArray(sourceValue)) target[key] = mergeWithDeep(targetValue, sourceValue, merge, stack);
		else if (isObjectLike(targetValue) && isObjectLike(sourceValue) && (isPlainObject(targetValue) || isPlainObject(sourceValue) || isTypedArray$1(targetValue) || isTypedArray$1(sourceValue))) target[key] = mergeWithDeep(targetValue, sourceValue, merge, stack);
		else if (targetValue == null && isPlainObject(sourceValue)) target[key] = mergeWithDeep({}, sourceValue, merge, stack);
		else if (targetValue == null && isTypedArray$1(sourceValue)) target[key] = cloneDeep(sourceValue);
		else if (targetValue === void 0 || sourceValue !== void 0) target[key] = sourceValue;
	}
	return target;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/merge.mjs
/**
* Merges the properties of one or more source objects into the target object.
*
* This function performs a deep merge, recursively merging nested objects and arrays.
* If a property in the source object is an array or object and the corresponding property in the target object is also an array or object, they will be merged.
* If a property in the source object is `undefined`, it will not overwrite a defined property in the target object.
*
* The function can handle multiple source objects and will merge them all into the target object.
*
* @param object - The target object into which the source object properties will be merged. This object is modified in place.
* @param sources - The source objects whose properties will be merged into the target object.
* @returns The updated target object with properties from the source object(s) merged in.
*
* @example
* const target = { a: 1, b: { x: 1, y: 2 } };
* const source = { b: { y: 3, z: 4 }, c: 5 };
*
* const result = merge(target, source);
* console.log(result);
* // Output: { a: 1, b: { x: 1, y: 3, z: 4 }, c: 5 }
*
* @example
* const target = { a: [1, 2], b: { x: 1 } };
* const source = { a: [3], b: { y: 2 } };
*
* const result = merge(target, source);
* console.log(result);
* // Output: { a: [3], b: { x: 1, y: 2 } }
*
* @example
* const target = { a: null };
* const source = { a: [1, 2, 3] };
*
* const result = merge(target, source);
* console.log(result);
* // Output: { a: [1, 2, 3] }
*/
function merge(object, ...sources) {
	return mergeWith(object, ...sources, noop);
}
//#endregion
//#region src/utils/executionErrorUtil.ts
function isCloudValidationError(value) {
	return value !== null && typeof value === "object" && ("error" in value || "node_errors" in value);
}
/**
* Extracts a prompt validation response embedded in an exception message string.
*
* Cloud example `exception_message`:
*   "Failed to send prompt request: ... 400: {\"error\":{...},\"node_errors\":{...}}"
*
* This function finds the first '{' and parses the trailing JSON.
*/
function tryExtractValidationError(exceptionMessage) {
	const jsonStart = exceptionMessage.indexOf("{");
	const jsonEnd = exceptionMessage.lastIndexOf("}");
	if (jsonStart === -1 || jsonEnd === -1) return null;
	try {
		const parsed = JSON.parse(exceptionMessage.substring(jsonStart, jsonEnd + 1));
		return isCloudValidationError(parsed) ? parsed : null;
	} catch {
		return null;
	}
}
function normalizePromptError(error) {
	if (error !== null && typeof error === "object") return {
		type: "type" in error && typeof error.type === "string" ? error.type : "error",
		message: "message" in error && typeof error.message === "string" ? error.message : "",
		details: "details" in error && typeof error.details === "string" ? error.details : ""
	};
	return typeof error === "string" ? {
		type: "error",
		message: error,
		details: ""
	} : null;
}
function isMissingNodePromptError(promptError) {
	return promptError?.type === "missing_node_type";
}
/**
* Classifies an embedded cloud validation error from `exception_message`
* as either node-level errors or a prompt-level error.
*
* Returns `null` if the message does not contain a recognizable validation error.
*/
function classifyCloudValidationError(exceptionMessage) {
	const extracted = tryExtractValidationError(exceptionMessage);
	if (!extracted) return null;
	const { error, node_errors } = extracted;
	if (node_errors && Object.keys(node_errors).length > 0) return {
		kind: "nodeErrors",
		nodeErrors: node_errors
	};
	const promptError = normalizePromptError(error);
	return promptError ? {
		kind: "promptError",
		promptError
	} : null;
}
function errorsForSlot(errors, slotName) {
	return errors.filter((error) => error.extra_info?.input_name === slotName);
}
function hasErrorForSlot(errors, slotName) {
	return errors.some((error) => error.extra_info?.input_name === slotName);
}
/**
* Error types that can be resolved automatically when the user changes a
* widget value or establishes a connection, without requiring a re-run.
*
* When adding new types, review {@link isValueStillOutOfRange} to ensure
* the new type does not require range validation before auto-clearing.
*/
var SIMPLE_ERROR_TYPES = /* @__PURE__ */ new Set([
	"value_bigger_than_max",
	"value_smaller_than_min",
	"value_not_in_list",
	"required_input_missing"
]);
var INPUT_LEVEL_VALIDATION_ERROR_TYPES = /* @__PURE__ */ new Set([
	"required_input_missing",
	"bad_linked_input",
	"return_type_mismatch",
	"invalid_input_type",
	"value_smaller_than_min",
	"value_bigger_than_max",
	"value_not_in_list",
	"custom_validation_failed",
	"exception_during_inner_validation"
]);
var NODE_LEVEL_VALIDATION_ERROR_TYPES = /* @__PURE__ */ new Set([
	"PARTNER_NODE_DISABLED",
	"exception_during_validation",
	"dependency_cycle"
]);
/** Decodes the `[type, { min, max, ... }]` tuple the backend attaches to range errors. */
function getInputConfigBounds(error) {
	const config = error.extra_info?.input_config;
	if (!Array.isArray(config)) return {};
	const bounds = config[1];
	if (!bounds || typeof bounds !== "object") return {};
	const { min, max } = bounds;
	return {
		min,
		max
	};
}
function isImageNotLoadedValidationError(error) {
	return error.type === "custom_validation_failed" && /invalid image file|\[errno 21\].*is a directory/i.test([error.message, error.details].filter(Boolean).join("\n"));
}
function isNodeLevelValidationError(error) {
	return !INPUT_LEVEL_VALIDATION_ERROR_TYPES.has(error.type) || isImageNotLoadedValidationError(error);
}
/**
* Returns true if `value` still violates a recorded range constraint.
* Pass errors already filtered to the target widget (by `input_name`).
* `options` should contain the widget's configured `min` / `max`.
*
* Returns true (keeps the error) when a bound is unknown (`undefined`).
*/
function isValueStillOutOfRange(value, errors, options) {
	const hasMaxError = errors.some((e) => e.type === "value_bigger_than_max");
	const hasMinError = errors.some((e) => e.type === "value_smaller_than_min");
	return hasMaxError && (options.max === void 0 || value > options.max) || hasMinError && (options.min === void 0 || value < options.min);
}
//#endregion
//#region src/platform/settings/composables/useSettingsDialog.ts
var DIALOG_KEY = "global-settings";
var settingDialogComponent;
/**
* The settings dialog subtree opens the settings dialog itself (billing
* stores, top-up dialogs, confirmation content), so the composable cannot
* import the component without an import cycle. The app shell registers it.
*/
function registerSettingDialogComponent(component) {
	settingDialogComponent = component;
}
function useSettingsDialog() {
	const dialogStore = useDialogStore();
	function hide() {
		dialogStore.closeDialog({ key: DIALOG_KEY });
	}
	function show(panel, settingId) {
		if (!settingDialogComponent) {
			reportError(/* @__PURE__ */ new Error("Setting dialog component is not registered"), {
				errorType: "failure_opening_settings_dialog",
				surface: "platform"
			});
			return;
		}
		dialogStore.showDialog({
			key: DIALOG_KEY,
			component: settingDialogComponent,
			props: {
				onClose: hide,
				...panel ? { defaultPanel: panel } : {},
				...settingId ? { scrollToSettingId: settingId } : {}
			},
			dialogComponentProps: {
				headless: true,
				closable: true
			}
		});
	}
	function showAbout() {
		show("about");
	}
	return {
		show,
		hide,
		showAbout
	};
}
//#endregion
//#region src/components/dialog/content/ConfirmationDialogContent.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$3 = { class: "m-2 mt-4 flex flex-col gap-6 wrap-break-word whitespace-pre-wrap" };
var _hoisted_2$3 = {
	key: 0,
	class: "m-0 mt-2 flex flex-col gap-2 pl-4"
};
var _hoisted_3$1 = {
	key: 1,
	role: "status",
	class: "mt-2 flex items-start gap-2 text-sm text-muted-foreground"
};
var _hoisted_4$1 = { class: "flex shrink-0 flex-wrap justify-end gap-4" };
var _hoisted_5$1 = {
	key: 0,
	class: "flex flex-col gap-1"
};
var _hoisted_6$1 = { class: "flex gap-4" };
var _hoisted_7 = { for: "doNotAskAgain" };
//#endregion
//#region src/components/dialog/content/ConfirmationDialogContent.vue
var ConfirmationDialogContent_default = /* @__PURE__ */ defineComponent({
	__name: "ConfirmationDialogContent",
	props: {
		message: {},
		type: {},
		onConfirm: { type: Function },
		itemList: {},
		hint: {},
		denyLabel: {},
		confirmLabel: {}
	},
	setup(__props) {
		const props = __props;
		const { t } = useI18n();
		const onCancel = () => useDialogStore().closeDialog();
		function openBlueprintOverwriteSetting() {
			useDialogStore().closeDialog();
			useSettingsDialog().show(void 0, "Comfy.Workflow.WarnBlueprintOverwrite");
		}
		const doNotAskAgain = ref(false);
		const onDeny = () => {
			props.onConfirm(false);
			useDialogStore().closeDialog();
		};
		const onConfirm = () => {
			if (props.type === "overwriteBlueprint" && doNotAskAgain.value) useSettingStore().set("Comfy.Workflow.WarnBlueprintOverwrite", false);
			props.onConfirm(true);
			useDialogStore().closeDialog();
		};
		return (_ctx, _cache) => {
			const _component_i18n_t = resolveComponent("i18n-t");
			return openBlock(), createElementBlock("section", _hoisted_1$3, [createBaseVNode("div", null, [
				createBaseVNode("span", null, toDisplayString(__props.message), 1),
				__props.itemList?.length ? (openBlock(), createElementBlock("ul", _hoisted_2$3, [(openBlock(true), createElementBlock(Fragment, null, renderList(__props.itemList, (item) => {
					return openBlock(), createElementBlock("li", { key: item }, toDisplayString(item), 1);
				}), 128))])) : createCommentVNode("", true),
				__props.hint ? (openBlock(), createElementBlock("div", _hoisted_3$1, [_cache[1] || (_cache[1] = createBaseVNode("i", {
					class: "pi pi-info-circle mt-0.5",
					"aria-hidden": "true"
				}, null, -1)), createBaseVNode("span", null, toDisplayString(__props.hint), 1)])) : createCommentVNode("", true)
			]), createBaseVNode("div", _hoisted_4$1, [
				__props.type === "overwriteBlueprint" ? (openBlock(), createElementBlock("div", _hoisted_5$1, [createBaseVNode("div", _hoisted_6$1, [withDirectives(createBaseVNode("input", {
					id: "doNotAskAgain",
					"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => doNotAskAgain.value = $event),
					type: "checkbox",
					class: "size-4 cursor-pointer"
				}, null, 512), [[vModelCheckbox, doNotAskAgain.value]]), createBaseVNode("label", _hoisted_7, toDisplayString(unref(t)("missingModelsDialog.doNotAskAgain")), 1)]), doNotAskAgain.value ? (openBlock(), createBlock(_component_i18n_t, {
					key: 0,
					keypath: "missingModelsDialog.reEnableInSettings",
					tag: "span",
					class: "ml-8 text-sm text-muted-foreground"
				}, {
					link: withCtx(() => [createVNode(Button_default, {
						variant: "muted-textonly",
						class: "p-0 text-sm underline hover:bg-transparent",
						onClick: openBlueprintOverwriteSetting
					}, {
						default: withCtx(() => [createTextVNode(toDisplayString(unref(t)("missingModelsDialog.reEnableInSettingsLink")), 1)]),
						_: 1
					})]),
					_: 1
				})) : createCommentVNode("", true)])) : createCommentVNode("", true),
				__props.type !== "info" && __props.type !== "dirtyClose" ? (openBlock(), createBlock(Button_default, {
					key: 1,
					variant: "secondary",
					autofocus: "",
					onClick: onCancel
				}, {
					default: withCtx(() => [_cache[2] || (_cache[2] = createBaseVNode("i", { class: "pi pi-undo" }, null, -1)), createTextVNode(" " + toDisplayString(_ctx.$t("g.cancel")), 1)]),
					_: 1
				})) : createCommentVNode("", true),
				__props.type === "default" ? (openBlock(), createBlock(Button_default, {
					key: 2,
					variant: "primary",
					onClick: onConfirm
				}, {
					default: withCtx(() => [_cache[3] || (_cache[3] = createBaseVNode("i", { class: "pi pi-check" }, null, -1)), createTextVNode(" " + toDisplayString(_ctx.$t("g.confirm")), 1)]),
					_: 1
				})) : __props.type === "delete" ? (openBlock(), createBlock(Button_default, {
					key: 3,
					variant: "destructive",
					onClick: onConfirm
				}, {
					default: withCtx(() => [_cache[4] || (_cache[4] = createBaseVNode("i", { class: "pi pi-trash" }, null, -1)), createTextVNode(" " + toDisplayString(_ctx.$t("g.delete")), 1)]),
					_: 1
				})) : __props.type === "overwrite" || __props.type === "overwriteBlueprint" ? (openBlock(), createBlock(Button_default, {
					key: 4,
					variant: "destructive",
					onClick: onConfirm
				}, {
					default: withCtx(() => [_cache[5] || (_cache[5] = createBaseVNode("i", { class: "pi pi-save" }, null, -1)), createTextVNode(" " + toDisplayString(_ctx.$t("g.overwrite")), 1)]),
					_: 1
				})) : __props.type === "dirtyClose" ? (openBlock(), createElementBlock(Fragment, { key: 5 }, [createVNode(Button_default, {
					variant: "secondary",
					onClick: onDeny
				}, {
					default: withCtx(() => [_cache[6] || (_cache[6] = createBaseVNode("i", { class: "pi pi-times" }, null, -1)), createTextVNode(" " + toDisplayString(__props.denyLabel ?? _ctx.$t("g.no")), 1)]),
					_: 1
				}), createVNode(Button_default, {
					autofocus: "",
					onClick: onConfirm
				}, {
					default: withCtx(() => [_cache[7] || (_cache[7] = createBaseVNode("i", { class: "pi pi-save" }, null, -1)), createTextVNode(" " + toDisplayString(__props.confirmLabel ?? _ctx.$t("g.save")), 1)]),
					_: 1
				})], 64)) : __props.type === "reinstall" ? (openBlock(), createBlock(Button_default, {
					key: 6,
					variant: "destructive",
					onClick: onConfirm
				}, {
					default: withCtx(() => [_cache[8] || (_cache[8] = createBaseVNode("i", { class: "pi pi-eraser" }, null, -1)), createTextVNode(" " + toDisplayString(_ctx.$t("desktopMenu.reinstall")), 1)]),
					_: 1
				})) : __props.type === "info" ? (openBlock(), createBlock(Button_default, {
					key: 7,
					variant: "primary",
					onClick: onCancel
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("g.ok")), 1)]),
					_: 1
				})) : (openBlock(), createBlock(Button_default, {
					key: 8,
					variant: "primary",
					onClick: onCancel
				}, {
					default: withCtx(() => [_cache[9] || (_cache[9] = createBaseVNode("i", { class: "pi pi-times" }, null, -1)), createTextVNode(" " + toDisplayString(_ctx.$t("g.close")), 1)]),
					_: 1
				}))
			])]);
		};
	}
});
//#endregion
//#region src/components/common/NoResultsPlaceholder.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$2 = { class: "flex flex-col items-center bg-(--surface-ground) text-center" };
var _hoisted_2$2 = {
	key: 0,
	class: "mb-2 text-foreground"
};
//#endregion
//#region src/components/common/NoResultsPlaceholder.vue
var NoResultsPlaceholder_default = /* @__PURE__ */ defineComponent({
	__name: "NoResultsPlaceholder",
	props: {
		class: {},
		icon: {},
		title: {},
		message: {},
		textClass: {},
		buttonIcon: {},
		buttonLabel: {},
		buttonVariant: {}
	},
	emits: ["action"],
	setup(__props) {
		const props = __props;
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", { class: normalizeClass(unref(cn)("h-full p-8", props.class)) }, [createBaseVNode("div", _hoisted_1$2, [
				__props.icon ? (openBlock(), createElementBlock("i", {
					key: 0,
					class: normalizeClass(unref(cn)(__props.icon, "mb-4 text-5xl"))
				}, null, 2)) : createCommentVNode("", true),
				renderSlot(_ctx.$slots, "title", {}, () => [__props.title ? (openBlock(), createElementBlock("h3", _hoisted_2$2, toDisplayString(__props.title), 1)) : createCommentVNode("", true)]),
				createBaseVNode("p", { class: normalizeClass(unref(cn)("mb-4 text-center whitespace-pre-line", __props.textClass)) }, toDisplayString(__props.message), 3),
				__props.buttonLabel ? (openBlock(), createBlock(Button_default, {
					key: 1,
					variant: __props.buttonVariant ?? "textonly",
					onClick: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("action"))
				}, {
					default: withCtx(() => [__props.buttonIcon ? (openBlock(), createElementBlock("i", {
						key: 0,
						class: normalizeClass(__props.buttonIcon)
					}, null, 2)) : createCommentVNode("", true), createTextVNode(" " + toDisplayString(__props.buttonLabel), 1)]),
					_: 1
				}, 8, ["variant"])) : createCommentVNode("", true)
			])], 2);
		};
	}
});
//#endregion
//#region src/components/dialog/content/error/FindIssueButton.vue
var FindIssueButton_default = /* @__PURE__ */ defineComponent({
	__name: "FindIssueButton",
	props: {
		errorMessage: {},
		repoOwner: {},
		repoName: {}
	},
	setup(__props) {
		const props = __props;
		const queryString = computed(() => props.errorMessage + " is:issue");
		function openGitHubIssues() {
			useTelemetry()?.trackUiButtonClicked({
				button_id: "error_dialog_find_existing_issues_clicked",
				element_group: "error_dialog"
			});
			const query = encodeURIComponent(queryString.value);
			const url = `https://github.com/${props.repoOwner}/${props.repoName}/issues?q=${query}`;
			window.open(url, "_blank");
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(Button_default, {
				"data-testid": "error-dialog-find-issues",
				variant: "secondary",
				onClick: openGitHubIssues
			}, {
				default: withCtx(() => [_cache[0] || (_cache[0] = createBaseVNode("i", { class: "pi pi-github" }, null, -1)), createTextVNode(" " + toDisplayString(_ctx.$t("g.findIssues")), 1)]),
				_: 1
			});
		};
	}
});
//#endregion
//#region src/platform/workflowErrors/errorCatalog/catalogIds.ts
var MISSING_CONNECTION_CATALOG_ID = "missing_connection";
var UNKNOWN_VALIDATION_ERROR_CATALOG_ID = "unknown_validation_error";
var EXECUTION_FAILED_CATALOG_ID = "execution_failed";
var IMAGE_NOT_LOADED_CATALOG_ID = "image_not_loaded";
var OUT_OF_MEMORY_CATALOG_ID = "out_of_memory";
var CONTENT_BLOCKED_CATALOG_ID = "content_blocked";
var ACCESS_REQUIRED_CATALOG_ID = "access_required";
var MODEL_ACCESS_ERROR_CATALOG_ID = "model_access_error";
var INVALID_CLIP_INPUT_CATALOG_ID = "invalid_clip_input";
var INVALID_PROMPT_CATALOG_ID = "invalid_prompt";
var INVALID_WORKFLOW_REQUEST_CATALOG_ID = "invalid_workflow_request";
var INSUFFICIENT_CREDITS_CATALOG_ID = "insufficient_credits";
var WORKSPACE_INSUFFICIENT_CREDITS_CATALOG_ID = "workspace_insufficient_credits";
var SUBSCRIPTION_REQUIRED_CATALOG_ID = "subscription_required";
var SUBSCRIPTION_UPGRADE_REQUIRED_CATALOG_ID = "subscription_upgrade_required";
var MODEL_DOWNLOAD_FAILED_CATALOG_ID = "model_download_failed";
var UNEXPECTED_SERVICE_ERROR_CATALOG_ID = "unexpected_service_error";
var REQUEST_FAILED_CATALOG_ID = "request_failed";
var RUN_START_FAILED_CATALOG_ID = "run_start_failed";
var RUN_ENDED_UNEXPECTEDLY_CATALOG_ID = "run_ended_unexpectedly";
var SIGN_IN_REQUIRED_CATALOG_ID = "sign_in_required";
var RATE_LIMITED_CATALOG_ID = "rate_limited";
var TIMEOUT_CATALOG_ID = "timeout";
var GENERATION_STALLED_CATALOG_ID = "generation_stalled";
var PREPROCESSING_FAILED_CATALOG_ID = "preprocessing_failed";
var PREPROCESSING_TIMEOUT_CATALOG_ID = "preprocessing_timeout";
var SERVER_CRASHED_CATALOG_ID = "server_crashed";
var SERVER_BUSY_CATALOG_ID = "server_busy";
//#endregion
//#region src/platform/workflowErrors/errorCatalog/catalogI18n.ts
function translateCatalogMessage(key, fallback, params) {
	if (te(key)) return params ? t(key, params, { escapeParameter: false }) : t(key);
	if (!params) return fallback;
	return fallback.replace(/\{(\w+)\}/g, (match, paramName) => {
		const value = params[paramName];
		return value === void 0 ? match : String(value);
	});
}
function translateOptionalCatalogMessage(key, fallback, params) {
	if (te(key)) return params ? t(key, params, { escapeParameter: false }) : t(key);
	return fallback?.trim() ? fallback : void 0;
}
function normalizeNodeName(nodeDisplayName) {
	return nodeDisplayName?.trim() || translateCatalogMessage("errorCatalog.fallbacks.nodeName", "This node");
}
//#endregion
//#region src/platform/workflowErrors/errorCatalog/runtimeErrorCopy.ts
function resolveRuntimeCatalogCopy(catalogId, fallbackMessage, context, options = {}) {
	const keyPrefix = `errorCatalog.runtimeErrors.${catalogId}`;
	const nodeName = normalizeNodeName(context.nodeDisplayName);
	const params = {
		nodeName,
		...options.params
	};
	const resolveMessage = (suffix, fallback = fallbackMessage) => translateCatalogMessage(`${keyPrefix}.${suffix}`, fallback, params);
	const displayMessage = resolveMessage("message");
	const result = {
		catalogId,
		displayTitle: resolveMessage("title"),
		displayMessage
	};
	if (options.includeToast !== false) {
		result.toastTitle = resolveMessage("toastTitle");
		result.toastMessage = resolveMessage("toastMessage");
	}
	const displayDetails = translateOptionalCatalogMessage(`${keyPrefix}.details`, options.detailsFallback, params);
	if (displayDetails) result.displayDetails = displayDetails;
	if (options.includeItemLabel) result.displayItemLabel = resolveMessage("itemLabel", nodeName);
	return result;
}
//#endregion
//#region src/platform/workflowErrors/errorCatalog/runtimeErrorMatcher.ts
var INSUFFICIENT_CREDITS_MESSAGES = /* @__PURE__ */ new Set(["Payment Required: Please add credits to your account to use this node."]);
var WORKSPACE_INSUFFICIENT_CREDITS_MESSAGES = /* @__PURE__ */ new Set(["Payment Required: Please add credits to your workspace to continue.", "Insufficient credits to queue workflows"]);
var SUBSCRIPTION_REQUIRED_MESSAGES = /* @__PURE__ */ new Set([
	"Workspace has no active subscription. Please subscribe to a plan to continue.",
	"User has no active subscription. Please subscribe to a plan to continue.",
	"Subscription required to queue workflows"
]);
var SUBSCRIPTION_UPGRADE_REQUIRED_PREFIX = "the following private models require a subscription upgrade:";
var TIMEOUT_MESSAGES = /* @__PURE__ */ new Set(["Job execution time exceeded maximum limit"]);
var GENERATION_STALLED_MESSAGES = /* @__PURE__ */ new Set(["Job went too long without making any progress", "Job has stagnated"]);
var SERVER_CRASHED_MESSAGES = /* @__PURE__ */ new Set([
	"RIP to the server your workflow was running on.",
	"Inference service restarted, terminating job",
	"Job stuck in erroring state, forcing terminal transition",
	"Job was previously marked as lost and has now been acknowledged by inference service"
]);
var SERVER_BUSY_MESSAGES = /* @__PURE__ */ new Set([
	"Failed to enqueue job for processing",
	"Executor is busy with another job",
	"Servers are busy. Please try again later."
]);
var INVALID_WORKFLOW_REQUEST_MESSAGES = /* @__PURE__ */ new Set([
	"The workflow request is invalid.",
	"Invalid job: missing workflow",
	"Invalid workflow: missing 'prompt' field",
	"Invalid workflow: 'prompt' field must be an object"
]);
var ACCESS_REQUIRED_MESSAGE = "This run requires access that is not available for the current account.";
var MODEL_ACCESS_ERROR_MESSAGE = "One or more required models could not be accessed.";
var UNEXPECTED_SERVICE_ERROR_MESSAGE = "Unexpected service error.";
var REQUEST_FAILED_MESSAGE = "The request failed before the run could complete.";
var RUN_START_FAILED_MESSAGE = "The run could not be started.";
var RUN_ENDED_UNEXPECTEDLY_MESSAGE = "The run ended unexpectedly.";
var SIGN_IN_REQUIRED_MESSAGE = "Unauthorized: Please login first to use this node.";
var RATE_LIMITED_PREFIX = "Rate Limit Exceeded:";
var CORE_OOM_TIP = "This error means you ran out of memory on your GPU.";
var CORE_OOM_ALLOCATION_PREFIX = "Allocation on device";
var CLOUD_OOM_PREFIX = "Workflow execution failed due to insufficient memory (OOM).";
var ERRNO_DIRECTORY_MESSAGE = "[Errno 21] Is a directory:";
var INVALID_CLIP_INPUT_PREFIX = "ERROR: clip input is invalid: None";
var PROMPT_TOO_SHORT_MESSAGE = "Field 'prompt' cannot be shorter than 1 characters; was 0 characters long.";
var PROMPT_EMPTY_MESSAGE = "Field 'prompt' cannot be empty.";
var PREPROCESSING_FAILED_MESSAGE = "Preprocessing failed";
var PREPROCESSING_TIMEOUT_MESSAGES = /* @__PURE__ */ new Set(["Preprocessing timed out", "Preprocessing timed out."]);
var MODEL_DOWNLOAD_PANIC_PREFIX = "internal error during model download:";
var GENERATED_VIDEO_REJECTED_MESSAGE = "Generated video rejected by content moderation.";
var GENERATED_CONTENT_REJECTED_MESSAGE = "Generated content was rejected by a safety check.";
var SAFETY_CHECK_MESSAGE = "Prompt or Initial Image failed the safety checks.";
var CONTENT_POLICY_VIOLATION_MESSAGE = "The generated image was flagged for content policy violation.";
var CONTENT_MODERATION_FLAGGED_PREFIX = "Your request was flagged by our content moderation system";
var GOOGLE_RAI_FILTERED_PREFIX = "Content filtered by Google's Responsible AI practices";
var GOOGLE_RAI_BLOCKED_PREFIX = "Content blocked by Google's Responsible AI filters";
var START_FAILED_PREFIXES = ["Failed to start WebSocket client:", "Failed to get ComfyUI generation ID:"];
var REQUEST_FAILED_PREFIXES = ["Failed to send prompt request:"];
var SERVER_CRASHED_PREFIXES = [
	"Workflow execution was interrupted due to ComfyUI process restart.",
	"Job execution interrupted: server shutdown.",
	"Failed to clear queue and restart failed:",
	"WebSocket failed to reconnect after restart:"
];
var PREPROCESSING_FAILED_PREFIXES = ["Preprocessing failed:", "Failed to complete preparation:"];
function catalogMatch(catalogId, options = {}) {
	return {
		catalogId,
		...options
	};
}
function catalogMatchWithMessageFallback(catalogId, message) {
	return catalogMatch(catalogId, { detailsFallback: message });
}
function isOutOfMemoryError(info) {
	const message = info.exceptionMessage;
	return info.exceptionType === "OOMError" || message.includes(CORE_OOM_TIP) || message.includes(CORE_OOM_ALLOCATION_PREFIX) || message.includes(CLOUD_OOM_PREFIX) || message.includes("CUDA out of memory") || message.includes("GPU out of memory");
}
function isImageNotLoadedError(info, message) {
	return info.exceptionType === "ImageDownloadError" || info.exceptionType === "IsADirectoryError" && message.includes(ERRNO_DIRECTORY_MESSAGE);
}
function getSubscriptionUpgradeDetails(message) {
	return message.slice(60).trim();
}
function isContentBlockedError(message) {
	return message.includes(GENERATED_VIDEO_REJECTED_MESSAGE) || message.includes(GENERATED_CONTENT_REJECTED_MESSAGE) || message.includes(SAFETY_CHECK_MESSAGE) || message.includes(CONTENT_POLICY_VIOLATION_MESSAGE) || message.startsWith(CONTENT_MODERATION_FLAGGED_PREFIX) || message.startsWith(GOOGLE_RAI_FILTERED_PREFIX) || message.startsWith(GOOGLE_RAI_BLOCKED_PREFIX);
}
function startsWithAny(message, prefixes) {
	return prefixes.some((prefix) => message.startsWith(prefix));
}
function hasEmbeddedApiErrorPayload(message) {
	return /request returned error status \d{3}:\s*\{/.test(message);
}
function isSubscriptionUpgradeMessage(message) {
	return message.toLowerCase().startsWith(SUBSCRIPTION_UPGRADE_REQUIRED_PREFIX) && getSubscriptionUpgradeDetails(message).length > 0;
}
var RUNTIME_MATCH_RULES = [
	{
		matches: isImageNotLoadedError,
		resolve: (_info, message) => catalogMatchWithMessageFallback(IMAGE_NOT_LOADED_CATALOG_ID, message)
	},
	{
		matches: isOutOfMemoryError,
		resolve: (_info, message) => catalogMatchWithMessageFallback(OUT_OF_MEMORY_CATALOG_ID, message)
	},
	{
		matches: (_info, message) => message.startsWith(INVALID_CLIP_INPUT_PREFIX),
		resolve: (_info, message) => catalogMatchWithMessageFallback(INVALID_CLIP_INPUT_CATALOG_ID, message)
	},
	{
		matches: (_info, message) => message.includes(PROMPT_TOO_SHORT_MESSAGE) || message.includes(PROMPT_EMPTY_MESSAGE),
		resolve: () => catalogMatch(INVALID_PROMPT_CATALOG_ID)
	},
	{
		matches: (info, message) => info.exceptionType === "ValidationError" && INVALID_WORKFLOW_REQUEST_MESSAGES.has(message),
		resolve: () => catalogMatch(INVALID_WORKFLOW_REQUEST_CATALOG_ID)
	},
	{
		matches: (_info, message) => WORKSPACE_INSUFFICIENT_CREDITS_MESSAGES.has(message),
		resolve: () => catalogMatch(WORKSPACE_INSUFFICIENT_CREDITS_CATALOG_ID)
	},
	{
		matches: (info, message) => info.exceptionType === "InsufficientFundsError" || info.exceptionType === "insufficient_credits" || INSUFFICIENT_CREDITS_MESSAGES.has(message),
		resolve: () => catalogMatch(INSUFFICIENT_CREDITS_CATALOG_ID)
	},
	{
		matches: (info, message) => info.exceptionType === "InactiveSubscriptionError" || SUBSCRIPTION_REQUIRED_MESSAGES.has(message),
		resolve: () => catalogMatch(SUBSCRIPTION_REQUIRED_CATALOG_ID)
	},
	{
		matches: (_info, message) => isSubscriptionUpgradeMessage(message),
		resolve: (_info, message) => {
			return catalogMatch(SUBSCRIPTION_UPGRADE_REQUIRED_CATALOG_ID, {
				params: { modelNames: getSubscriptionUpgradeDetails(message) },
				detailsFallback: message
			});
		}
	},
	{
		matches: (info, message) => info.exceptionType === "AccessRequired" || message === ACCESS_REQUIRED_MESSAGE,
		resolve: () => catalogMatch(ACCESS_REQUIRED_CATALOG_ID)
	},
	{
		matches: (info, message) => info.exceptionType === "ModelAccessError" || message === MODEL_ACCESS_ERROR_MESSAGE,
		resolve: () => catalogMatch(MODEL_ACCESS_ERROR_CATALOG_ID)
	},
	{
		matches: (_info, message) => message.includes(SIGN_IN_REQUIRED_MESSAGE),
		resolve: () => catalogMatch(SIGN_IN_REQUIRED_CATALOG_ID)
	},
	{
		matches: (_info, message) => message.startsWith(RATE_LIMITED_PREFIX),
		resolve: (_info, message) => catalogMatchWithMessageFallback(RATE_LIMITED_CATALOG_ID, message)
	},
	{
		matches: (info, message) => info.exceptionType === "PreprocessingTimeout" || PREPROCESSING_TIMEOUT_MESSAGES.has(message),
		resolve: () => catalogMatch(PREPROCESSING_TIMEOUT_CATALOG_ID)
	},
	{
		matches: (_info, message) => message === PREPROCESSING_FAILED_MESSAGE || startsWithAny(message, PREPROCESSING_FAILED_PREFIXES),
		resolve: (_info, message) => message === PREPROCESSING_FAILED_MESSAGE ? catalogMatch(PREPROCESSING_FAILED_CATALOG_ID) : catalogMatchWithMessageFallback(PREPROCESSING_FAILED_CATALOG_ID, message)
	},
	{
		matches: (info, message) => info.exceptionType === "PanicError" && message.startsWith(MODEL_DOWNLOAD_PANIC_PREFIX),
		resolve: (_info, message) => catalogMatchWithMessageFallback(MODEL_DOWNLOAD_FAILED_CATALOG_ID, message)
	},
	{
		matches: (_info, message) => isContentBlockedError(message),
		resolve: (_info, message) => catalogMatchWithMessageFallback(CONTENT_BLOCKED_CATALOG_ID, message)
	},
	{
		matches: (_info, message) => startsWithAny(message, START_FAILED_PREFIXES),
		resolve: (_info, message) => catalogMatchWithMessageFallback(RUN_START_FAILED_CATALOG_ID, message)
	},
	{
		matches: (_info, message) => startsWithAny(message, REQUEST_FAILED_PREFIXES) && !hasEmbeddedApiErrorPayload(message),
		resolve: (_info, message) => catalogMatchWithMessageFallback(REQUEST_FAILED_CATALOG_ID, message)
	},
	{
		matches: (_info, message) => message === RUN_START_FAILED_MESSAGE,
		resolve: () => catalogMatch(RUN_START_FAILED_CATALOG_ID)
	},
	{
		matches: (_info, message) => message === RUN_ENDED_UNEXPECTEDLY_MESSAGE,
		resolve: () => catalogMatch(RUN_ENDED_UNEXPECTEDLY_CATALOG_ID)
	},
	{
		matches: (info, message) => info.exceptionType === "PanicError" && message.startsWith("panic during job execution:"),
		resolve: (_info, message) => catalogMatchWithMessageFallback(RUN_ENDED_UNEXPECTEDLY_CATALOG_ID, message)
	},
	{
		matches: (_info, message) => TIMEOUT_MESSAGES.has(message),
		resolve: () => catalogMatch(TIMEOUT_CATALOG_ID)
	},
	{
		matches: (_info, message) => GENERATION_STALLED_MESSAGES.has(message),
		resolve: () => catalogMatch(GENERATION_STALLED_CATALOG_ID)
	},
	{
		matches: (_info, message) => SERVER_CRASHED_MESSAGES.has(message),
		resolve: () => catalogMatch(SERVER_CRASHED_CATALOG_ID)
	},
	{
		matches: (_info, message) => startsWithAny(message, SERVER_CRASHED_PREFIXES),
		resolve: (_info, message) => catalogMatchWithMessageFallback(SERVER_CRASHED_CATALOG_ID, message)
	},
	{
		matches: (_info, message) => SERVER_BUSY_MESSAGES.has(message),
		resolve: () => catalogMatch(SERVER_BUSY_CATALOG_ID)
	},
	{
		matches: (info, message) => info.exceptionType === "UnexpectedServiceError" || message === UNEXPECTED_SERVICE_ERROR_MESSAGE,
		resolve: () => catalogMatch(UNEXPECTED_SERVICE_ERROR_CATALOG_ID)
	},
	{
		matches: (info, message) => message === REQUEST_FAILED_MESSAGE || info.exceptionType === "RequestError" && !hasEmbeddedApiErrorPayload(message),
		resolve: (_info, message) => message === REQUEST_FAILED_MESSAGE ? catalogMatch(REQUEST_FAILED_CATALOG_ID) : catalogMatchWithMessageFallback(REQUEST_FAILED_CATALOG_ID, message)
	}
];
function resolveRuntimeCatalogMatch(info) {
	const message = info.exceptionMessage.trim();
	for (const rule of RUNTIME_MATCH_RULES) if (rule.matches(info, message)) return rule.resolve(info, message);
}
//#endregion
//#region src/platform/workflowErrors/errorCatalog/executionErrorResolver.ts
function resolveExecutionErrorMessage(error, context) {
	const exceptionMessage = error.exception_message.trim();
	const match = resolveRuntimeCatalogMatch({
		exceptionType: error.exception_type,
		exceptionMessage
	});
	if (!match) return resolveRuntimeCatalogCopy(EXECUTION_FAILED_CATALOG_ID, error.exception_message, context, { includeItemLabel: true });
	return resolveRuntimeCatalogCopy(match.catalogId, error.exception_message, context, {
		includeItemLabel: true,
		params: match.params,
		detailsFallback: match.detailsFallback
	});
}
//#endregion
//#region src/platform/workflowErrors/errorCatalog/promptErrorResolver.ts
var KNOWN_PROMPT_ERROR_TYPES = /* @__PURE__ */ new Set([
	"prompt_no_outputs",
	"no_prompt",
	"server_error",
	"missing_node_type",
	"prompt_outputs_failed_validation",
	"agent_api_failed",
	"op_rejected",
	"prefix_abort",
	"guard_trip",
	"apply_failed"
]);
function getPromptExceptionMessage(error) {
	const message = error.message.trim();
	const prefixedType = `${error.type}: `;
	return message.startsWith(prefixedType) ? message.slice(prefixedType.length).trim() : message;
}
function resolvePromptErrorMessage(error, context) {
	const promptExceptionMessage = getPromptExceptionMessage(error);
	const runtimeMatch = resolveRuntimeCatalogMatch({
		exceptionType: error.type,
		exceptionMessage: promptExceptionMessage
	});
	if (runtimeMatch) return resolveRuntimeCatalogCopy(runtimeMatch.catalogId, promptExceptionMessage || error.message, context, {
		includeToast: false,
		params: runtimeMatch.params,
		detailsFallback: runtimeMatch.detailsFallback
	});
	if (!KNOWN_PROMPT_ERROR_TYPES.has(error.type)) return {};
	const errorTypeKey = error.type === "server_error" ? context.isCloud ? "server_error_cloud" : "server_error_local" : error.type;
	return {
		displayTitle: translateCatalogMessage(`errorCatalog.promptErrors.${errorTypeKey}.title`, error.message),
		displayMessage: st(`errorCatalog.promptErrors.${errorTypeKey}.desc`, error.message)
	};
}
//#endregion
//#region src/platform/workflowErrors/errorCatalog/validationErrorResolver.ts
var REQUIRED_INPUT_MISSING_TYPE = "required_input_missing";
var DEFAULT_COPY_KEYS = {
	detailsKey: "details",
	toastMessageKey: "toastMessage"
};
var VALUE_SPECIFIC_COPY_RULES = {
	return_type_mismatch: {
		requiredParams: ["expectedType", "receivedType"],
		suffix: "WithTypes"
	},
	invalid_input_type: {
		requiredParams: ["receivedValue", "expectedType"],
		suffix: "WithValue"
	},
	value_smaller_than_min: {
		requiredParams: ["receivedValue", "minValue"],
		suffix: "WithValue"
	},
	value_bigger_than_max: {
		requiredParams: ["receivedValue", "maxValue"],
		suffix: "WithValue"
	},
	value_not_in_list: {
		requiredParams: ["receivedValue"],
		suffix: "WithValue"
	}
};
var NODE_LEVEL_VALIDATION_ERROR_RULES = Object.fromEntries(Array.from(NODE_LEVEL_VALIDATION_ERROR_TYPES, (type) => [type, {
	catalogId: type,
	itemLabel: "node"
}]));
var VALIDATION_ERROR_RULES = {
	...Object.fromEntries(Array.from(INPUT_LEVEL_VALIDATION_ERROR_TYPES, (type) => [type, {
		catalogId: type,
		itemLabel: "nodeInput"
	}])),
	[REQUIRED_INPUT_MISSING_TYPE]: {
		catalogId: MISSING_CONNECTION_CATALOG_ID,
		itemLabel: "nodeInput"
	},
	...NODE_LEVEL_VALIDATION_ERROR_RULES
};
var IMAGE_NOT_LOADED_VALIDATION_RULE = {
	catalogId: IMAGE_NOT_LOADED_CATALOG_ID,
	itemLabel: "node",
	copyKeys: DEFAULT_COPY_KEYS
};
var UNKNOWN_VALIDATION_ERROR_RULE = {
	catalogId: UNKNOWN_VALIDATION_ERROR_CATALOG_ID,
	itemLabel: "node"
};
function getInputName(error) {
	return (error.extra_info?.input_name)?.trim() || translateCatalogMessage("errorCatalog.fallbacks.inputName", "unknown input");
}
function nodeInputItemLabel(nodeName, inputName) {
	return `${nodeName} - ${inputName}`;
}
function formatDependencyCycleDetails(details) {
	return details.replace(/\s*->\s*/g, " to ");
}
function formatCatalogValue(value) {
	if (value === void 0 || value === null) return void 0;
	if (typeof value === "string") return value;
	if (typeof value === "number" || typeof value === "boolean") return String(value);
	try {
		return JSON.stringify(value);
	} catch {
		return;
	}
}
function getInputConfigValue(error, key) {
	return formatCatalogValue(getInputConfigBounds(error)[key]);
}
function getInputConfigType(error) {
	const inputConfig = error.extra_info?.input_config;
	if (!Array.isArray(inputConfig)) return void 0;
	return formatCatalogValue(inputConfig[0]);
}
function getValidationParams(error, nodeName, inputName) {
	const params = {
		nodeName,
		inputName
	};
	const receivedValue = formatCatalogValue(error.extra_info?.received_value);
	const receivedType = formatCatalogValue(error.extra_info?.received_type);
	const expectedType = getInputConfigType(error);
	const minValue = getInputConfigValue(error, "min");
	const maxValue = getInputConfigValue(error, "max");
	if (receivedValue !== void 0) params.receivedValue = receivedValue;
	if (receivedType !== void 0) params.receivedType = receivedType;
	if (expectedType !== void 0) params.expectedType = expectedType;
	if (minValue !== void 0) params.minValue = minValue;
	if (maxValue !== void 0) params.maxValue = maxValue;
	return params;
}
function hasParams(params, keys) {
	return keys.every((key) => Object.hasOwn(params, key));
}
function getValueSpecificCopyKeys(errorType, params) {
	const rule = getValueSpecificRule(errorType);
	if (!rule || !hasParams(params, rule.requiredParams)) return DEFAULT_COPY_KEYS;
	return {
		detailsKey: `details${rule.suffix}`,
		toastMessageKey: `toastMessage${rule.suffix}`
	};
}
function getValueSpecificRule(errorType) {
	return VALUE_SPECIFIC_COPY_RULES[errorType];
}
function getRawDetailsCopyKeys(error) {
	return error.details?.trim() ? {
		detailsKey: "detailsWithRawDetails",
		toastMessageKey: "toastMessageWithRawDetails"
	} : DEFAULT_COPY_KEYS;
}
function getRawDetailsOnlyCopyKeys(error) {
	if (!error.details?.trim()) return DEFAULT_COPY_KEYS;
	return {
		detailsKey: "detailsWithRawDetails",
		toastMessageKey: "toastMessage"
	};
}
function getValidationCopyKeys(error, params) {
	if (error.type === "exception_during_validation" || error.type === "exception_during_inner_validation") return getRawDetailsCopyKeys(error);
	if (error.type === "custom_validation_failed") return getRawDetailsOnlyCopyKeys(error);
	if (error.type === "dependency_cycle") return getRawDetailsOnlyCopyKeys(error);
	return getValueSpecificCopyKeys(error.type, params);
}
function resolveValidationCatalogCopy(error, context, localeKey, rule) {
	const nodeName = normalizeNodeName(context.nodeDisplayName);
	const inputName = getInputName(error);
	const trimmedDetails = error.details?.trim() ?? "";
	const rawDetails = error.type === "dependency_cycle" ? formatDependencyCycleDetails(trimmedDetails) : trimmedDetails;
	const params = {
		...getValidationParams(error, nodeName, inputName),
		errorType: error.type || "unknown",
		rawDetails
	};
	const keyPrefix = `errorCatalog.validationErrors.${localeKey}`;
	const titleFallback = error.message || error.type;
	const itemLabelFallback = rule.itemLabel === "node" ? nodeName : nodeInputItemLabel(nodeName, inputName);
	const copyKeys = rule.copyKeys ?? getValidationCopyKeys(error, params);
	return {
		catalogId: rule.catalogId,
		displayTitle: translateCatalogMessage(`${keyPrefix}.title`, titleFallback, params),
		displayMessage: translateCatalogMessage(`${keyPrefix}.message`, error.message, params),
		displayDetails: translateOptionalCatalogMessage(`${keyPrefix}.${copyKeys.detailsKey}`, error.details, params),
		displayItemLabel: translateCatalogMessage(`${keyPrefix}.itemLabel`, itemLabelFallback, params),
		toastTitle: translateCatalogMessage(`${keyPrefix}.toastTitle`, titleFallback, params),
		toastMessage: translateCatalogMessage(`${keyPrefix}.${copyKeys.toastMessageKey}`, error.message, params)
	};
}
function resolveNodeValidationErrorMessage(error, context) {
	if (isImageNotLoadedValidationError(error)) return resolveValidationCatalogCopy(error, context, "image_not_loaded", IMAGE_NOT_LOADED_VALIDATION_RULE);
	const rule = getValidationRule(error.type);
	if (!rule) return resolveValidationCatalogCopy(error, context, "unknown_validation_error", {
		...UNKNOWN_VALIDATION_ERROR_RULE,
		copyKeys: getRawDetailsOnlyCopyKeys(error)
	});
	return resolveValidationCatalogCopy(error, context, error.type, rule);
}
function getValidationRule(type) {
	return VALIDATION_ERROR_RULES[type];
}
//#endregion
//#region src/platform/workflowErrors/missingMedia/missingMediaGrouping.ts
function getMissingMediaReferences(groups) {
	return groups.flatMap((group) => group.items.flatMap((mediaItem) => mediaItem.referencingNodes.map((nodeRef) => ({
		mediaItem,
		nodeRef
	}))));
}
function countMissingMediaReferences(groups) {
	return sumBy(groups, (group) => sumBy(group.items, (item) => item.referencingNodes.length));
}
//#endregion
//#region src/platform/workflowErrors/missingModel/missingModelGrouping.ts
var UNSUPPORTED = Symbol("unsupported");
function countMissingModels(groups) {
	return sumBy(groups, (group) => group.models.length);
}
function groupMissingModelCandidates(candidates, isCloud) {
	if (!candidates?.length) return [];
	const map = /* @__PURE__ */ new Map();
	for (const candidate of candidates) {
		const groupKey = candidate.isAssetSupported || !isCloud ? candidate.directory || null : UNSUPPORTED;
		const existing = map.get(groupKey);
		if (existing) existing.candidates.push(candidate);
		else map.set(groupKey, {
			candidates: [candidate],
			isAssetSupported: candidate.isAssetSupported
		});
	}
	return Array.from(map.entries()).sort(([dirA], [dirB]) => {
		if (dirA === UNSUPPORTED) return 1;
		if (dirB === UNSUPPORTED) return -1;
		if (dirA === null) return 1;
		if (dirB === null) return -1;
		return dirA.localeCompare(dirB);
	}).map(([key, { candidates: groupCandidates, isAssetSupported }]) => ({
		directory: typeof key === "string" ? key : null,
		models: groupCandidatesByName(groupCandidates),
		isAssetSupported
	}));
}
function groupCandidatesByName(candidates) {
	const map = /* @__PURE__ */ new Map();
	for (const c of candidates) {
		const existing = map.get(c.name);
		if (existing) {
			if (c.nodeId) existing.referencingNodes.push({
				nodeId: c.nodeId,
				widgetName: c.widgetName
			});
		} else map.set(c.name, {
			name: c.name,
			representative: c,
			referencingNodes: c.nodeId ? [{
				nodeId: c.nodeId,
				widgetName: c.widgetName
			}] : []
		});
	}
	return Array.from(map.values());
}
//#endregion
//#region src/platform/workflowErrors/errorCatalog/missingErrorResolver.ts
function formatNodeTypeName(nodeType) {
	const trimmed = nodeType.trim();
	if (!trimmed) return null;
	return trimmed.replace(/[_-]+/g, " ").replace(/([A-Z]+)([A-Z][a-z])/g, "$1 $2").replace(/([a-z0-9])([A-Z])/g, "$1 $2").replace(/\s+/g, " ").trim();
}
function getNodeTypeLabel(nodeType) {
	return typeof nodeType === "string" ? nodeType : nodeType.type;
}
function getDistinctNodeTypeLabels(nodeTypes) {
	const labels = /* @__PURE__ */ new Set();
	for (const nodeType of nodeTypes) labels.add(getNodeTypeLabel(nodeType));
	return Array.from(labels);
}
function isMissingNodeType(nodeType) {
	return typeof nodeType === "string" || !nodeType.isReplaceable;
}
/**
* On a developer-platform deployment (FE-2434) the editor's nodes and models
* are its Release's, so a message names the deployment instead of Cloud.
* Null on Comfy Cloud and outside Cloud.
*/
function deploymentMessage(source, key, fallback, params = {}) {
	if (!source.deploymentLabel) return null;
	return translateCatalogMessage(key, fallback, {
		...params,
		deployment: source.deploymentLabel
	});
}
function resolveMissingNodeDisplayMessage(source) {
	const onDeployment = deploymentMessage(source, "errorCatalog.missingErrors.missing_node.displayMessageDeployment", "These nodes aren't on {deployment}. Replace them, or pick a deployment that has them.");
	if (onDeployment) return onDeployment;
	return translateCatalogMessage(source.isCloud ? "errorCatalog.missingErrors.missing_node.displayMessageCloud" : "errorCatalog.missingErrors.missing_node.displayMessageOss", source.isCloud ? "Required custom nodes aren't supported on Cloud. Replace them with supported nodes." : "Install missing packs to use this workflow.");
}
function resolveMissingNodeToastTitle(source) {
	const labels = getDistinctNodeTypeLabels(source.nodeTypes.filter(isMissingNodeType));
	const [firstLabel] = labels;
	if (labels.length === 1 && firstLabel) {
		const onDeployment = deploymentMessage(source, "errorCatalog.missingErrors.missing_node.toastTitleOneDeployment", "{nodeType} isn't on {deployment}", { nodeType: firstLabel });
		if (onDeployment) return onDeployment;
		return translateCatalogMessage(source.isCloud ? "errorCatalog.missingErrors.missing_node.toastTitleOneCloud" : "errorCatalog.missingErrors.missing_node.toastTitleOneOss", source.isCloud ? "{nodeType} isn't available on Cloud" : "Missing node: {nodeType}", { nodeType: firstLabel });
	}
	const onDeployment = deploymentMessage(source, "errorCatalog.missingErrors.missing_node.toastTitleManyDeployment", "Nodes aren't on {deployment}");
	if (onDeployment) return onDeployment;
	return translateCatalogMessage(source.isCloud ? "errorCatalog.missingErrors.missing_node.toastTitleManyCloud" : "errorCatalog.missingErrors.missing_node.toastTitleManyOss", source.isCloud ? "Nodes aren't available on Cloud" : "Missing nodes");
}
function resolveMissingNodeToastMessage(source) {
	const count = getDistinctNodeTypeLabels(source.nodeTypes.filter(isMissingNodeType)).length || source.count;
	if (count === 1) {
		const onDeployment = deploymentMessage(source, "errorCatalog.missingErrors.missing_node.toastMessageOneDeployment", "Replace this node, or pick a deployment that has it.");
		if (onDeployment) return onDeployment;
		return translateCatalogMessage(source.isCloud ? "errorCatalog.missingErrors.missing_node.toastMessageOneCloud" : "errorCatalog.missingErrors.missing_node.toastMessageOneOss", source.isCloud ? "This node isn't supported on Cloud." : "This workflow uses a custom node that isn't installed. Install it from the registry or replace the node.");
	}
	const onDeployment = deploymentMessage(source, "errorCatalog.missingErrors.missing_node.toastMessageManyDeployment", "Replace these nodes, or pick a deployment that has them.");
	if (onDeployment) return onDeployment;
	return translateCatalogMessage(source.isCloud ? "errorCatalog.missingErrors.missing_node.toastMessageManyCloud" : "errorCatalog.missingErrors.missing_node.toastMessageManyOss", source.isCloud ? "This workflow uses nodes that aren't supported on Cloud." : "{count} nodes require missing node packs.", { count });
}
function isSwapNodeType(nodeType) {
	return typeof nodeType !== "string" && nodeType.isReplaceable === true;
}
function getSwapNodeTypes(source) {
	return source.nodeTypes.filter(isSwapNodeType);
}
function resolveSwapNodeToastTitle(source) {
	const labels = getDistinctNodeTypeLabels(getSwapNodeTypes(source));
	const [firstLabel] = labels;
	if (labels.length === 1 && firstLabel) return translateCatalogMessage("errorCatalog.missingErrors.swap_nodes.toastTitleOne", "{nodeType} can be replaced", { nodeType: firstLabel });
	return translateCatalogMessage("errorCatalog.missingErrors.swap_nodes.toastTitleMany", "Nodes can be replaced");
}
function resolveSwapNodeToastMessage(source) {
	const nodeTypes = getSwapNodeTypes(source);
	const labels = getDistinctNodeTypeLabels(nodeTypes);
	const [firstNodeType] = nodeTypes;
	if (labels.length === 1 && firstNodeType.replacement?.new_node_id) return translateCatalogMessage("errorCatalog.missingErrors.swap_nodes.toastMessageOne", "Replace it with {replacementNodeType} from the error panel.", { replacementNodeType: firstNodeType.replacement.new_node_id });
	return translateCatalogMessage("errorCatalog.missingErrors.swap_nodes.toastMessageMany", "{count} node types can be replaced with compatible alternatives.", { count: labels.length || source.count });
}
function resolveSwapNodeDisplayMessage() {
	return translateCatalogMessage("errorCatalog.missingErrors.swap_nodes.displayMessage", "Some nodes can be replaced with alternatives");
}
function getMissingModelCount(source) {
	return countMissingModels(source.groups) || source.count;
}
function resolveMissingModelDisplayMessage(source) {
	const onDeployment = deploymentMessage(source, "errorCatalog.missingErrors.missing_model.displayMessageDeployment", "These models aren't on {deployment}. Open the node to choose one it has.");
	if (onDeployment) return onDeployment;
	return translateCatalogMessage(source.isCloud ? "errorCatalog.missingErrors.missing_model.displayMessageCloud" : "errorCatalog.missingErrors.missing_model.displayMessageOss", source.isCloud ? "Import a model, or open the node to replace it." : "Download a model, or open the node to replace it.");
}
function resolveMissingModelToastTitle(source) {
	const firstModel = source.groups.flatMap((group) => group.models).at(0);
	const count = getMissingModelCount(source);
	if (count === 1 && firstModel) return resolveOneMissingModelToastTitle(source, firstModel.name);
	return resolveManyMissingModelsToastTitle(source, count);
}
function resolveOneMissingModelToastTitle(source, modelName) {
	const onDeployment = deploymentMessage(source, "errorCatalog.missingErrors.missing_model.toastTitleOneDeployment", "{modelName} isn't on {deployment}", { modelName });
	if (onDeployment) return onDeployment;
	return translateCatalogMessage(source.isCloud ? "errorCatalog.missingErrors.missing_model.toastTitleOneCloud" : "errorCatalog.missingErrors.missing_model.toastTitleOneOss", source.isCloud ? "{modelName} isn't available on Cloud" : "{modelName} is missing", { modelName });
}
function resolveManyMissingModelsToastTitle(source, count) {
	if (count > 1) {
		const onDeployment = deploymentMessage(source, "errorCatalog.missingErrors.missing_model.toastTitleManyDeployment", "Models aren't on {deployment}");
		if (onDeployment) return onDeployment;
	}
	const useCloudPluralTitle = source.isCloud && count > 1;
	return translateCatalogMessage(useCloudPluralTitle ? "errorCatalog.missingErrors.missing_model.toastTitleManyCloud" : "errorCatalog.missingErrors.missing_model.toastTitleMany", useCloudPluralTitle ? "Models aren't available on Cloud" : "Missing models");
}
function getMissingModelNodeName(model) {
	return formatNodeTypeName(model.representative.nodeType) ?? translateCatalogMessage("errorCatalog.fallbacks.nodeName", "This node");
}
function resolveMissingModelToastMessage(source) {
	const firstModel = source.groups.flatMap((group) => group.models).at(0);
	const count = getMissingModelCount(source);
	if (!firstModel || count !== 1) {
		const onDeployment = deploymentMessage(source, "errorCatalog.missingErrors.missing_model.toastMessageManyDeployment", "Choose different models, or pick a deployment that has them.");
		if (onDeployment) return onDeployment;
		return translateCatalogMessage(source.isCloud ? "errorCatalog.missingErrors.missing_model.toastMessageManyCloud" : "errorCatalog.missingErrors.missing_model.toastMessageManyOss", source.isCloud ? "Some models aren't supported. Choose different ones." : "{count} model files are missing.", { count });
	}
	const onDeployment = deploymentMessage(source, "errorCatalog.missingErrors.missing_model.toastMessageOneDeployment", "Choose a different model, or pick a deployment that has it.");
	if (onDeployment) return onDeployment;
	if (source.isCloud) return translateCatalogMessage("errorCatalog.missingErrors.missing_model.toastMessageOneCloud", "This model isn't supported. Choose a different one.");
	return translateCatalogMessage("errorCatalog.missingErrors.missing_model.toastMessageOneOss", "{nodeName} is missing a required model file.", { nodeName: getMissingModelNodeName(firstModel) });
}
function getMissingMediaItems(source) {
	return source.groups.flatMap((group) => group.items);
}
function getMissingMediaNodeName(item) {
	return formatNodeTypeName(item.representative.nodeType);
}
function resolveMissingMediaDisplayMessage() {
	return translateCatalogMessage("errorCatalog.missingErrors.missing_media.displayMessage", "A required media input has no file selected.");
}
function resolveMissingMediaItemLabel(source) {
	return { displayItemLabel: translateCatalogMessage("errorCatalog.missingErrors.missing_media.itemLabel", "{nodeName} - {inputName}", {
		nodeName: normalizeNodeName(source.nodeDisplayName || formatNodeTypeName(source.nodeType ?? "") || void 0),
		inputName: source.widgetName?.trim() || translateCatalogMessage("errorCatalog.fallbacks.inputName", "unknown input")
	}) };
}
function resolveMissingMediaToastTitle(source) {
	if (countMissingMediaReferences(source.groups) !== 1) return translateCatalogMessage("errorCatalog.missingErrors.missing_media.toastTitleMany", "Missing media inputs");
	return translateCatalogMessage("errorCatalog.missingErrors.missing_media.toastTitleOne", "Media input missing");
}
function resolveMissingMediaToastMessage(source) {
	const firstItem = getMissingMediaItems(source).at(0);
	if (!firstItem || countMissingMediaReferences(source.groups) !== 1) return translateCatalogMessage("errorCatalog.missingErrors.missing_media.toastMessageMany", "Please select the missing media inputs before running this workflow.");
	return translateCatalogMessage("errorCatalog.missingErrors.missing_media.toastMessageWithNode", "{nodeName} is missing a required media file.", { nodeName: getMissingMediaNodeName(firstItem) ?? translateCatalogMessage("errorCatalog.fallbacks.nodeName", "This node") });
}
function resolveMissingErrorMessage(source) {
	switch (source.kind) {
		case "missing_node": return {
			catalogId: "missing_node",
			displayTitle: source.isCloud && !source.deploymentLabel ? st("rightSidePanel.missingNodePacks.unsupportedTitle", "Unsupported Node Packs") : st("rightSidePanel.missingNodePacks.title", "Missing Node Packs"),
			displayMessage: resolveMissingNodeDisplayMessage(source),
			toastTitle: resolveMissingNodeToastTitle(source),
			toastMessage: resolveMissingNodeToastMessage(source)
		};
		case "swap_nodes": return {
			catalogId: "swap_nodes",
			displayTitle: st("nodeReplacement.swapNodesTitle", "Swap Nodes"),
			displayMessage: resolveSwapNodeDisplayMessage(),
			toastTitle: resolveSwapNodeToastTitle(source),
			toastMessage: resolveSwapNodeToastMessage(source)
		};
		case "missing_model": return {
			catalogId: "missing_model",
			displayTitle: st("rightSidePanel.missingModels.missingModelsTitle", "Missing Models"),
			displayMessage: resolveMissingModelDisplayMessage(source),
			toastTitle: resolveMissingModelToastTitle(source),
			toastMessage: resolveMissingModelToastMessage(source)
		};
		case "missing_media": return {
			catalogId: "missing_media",
			displayTitle: st("rightSidePanel.missingMedia.missingMediaTitle", "Missing Inputs"),
			displayMessage: resolveMissingMediaDisplayMessage(),
			toastTitle: resolveMissingMediaToastTitle(source),
			toastMessage: resolveMissingMediaToastMessage(source)
		};
	}
}
//#endregion
//#region src/platform/workflowErrors/errorCatalog/errorMessageResolver.ts
function resolveRunErrorMessage(source) {
	switch (source.kind) {
		case "node_validation": return resolveNodeValidationErrorMessage(source.error, { nodeDisplayName: source.nodeDisplayName });
		case "prompt": return resolvePromptErrorMessage(source.error, { isCloud: source.isCloud });
		case "execution": return resolveExecutionErrorMessage(source.error, { nodeDisplayName: source.nodeDisplayName });
	}
}
//#endregion
//#region src/utils/errorReportUtil.ts
/**
* Generate a report for an error.
* @param error - The error to report.
* @returns The report.
*/
function generateErrorReport(error) {
	const MAX_JSON_LENGTH = 2e4;
	const workflowJSONString = JSON.stringify(error.workflow);
	const workflowText = workflowJSONString.length > MAX_JSON_LENGTH ? "Workflow too large. Please manually upload the workflow from local file system." : workflowJSONString;
	const systemStats = error.systemStats;
	return `
# ComfyUI Error Report
## Error Details
- **Node ID:** ${error.nodeId || "N/A"}
- **Node Type:** ${error.nodeType || "N/A"}
- **Exception Type:** ${error.exceptionType || "N/A"}
- **Exception Message:** ${error.exceptionMessage || "N/A"}
## Stack Trace
\`\`\`
${error.traceback || "No stack trace available"}
\`\`\`
## System Information
- **ComfyUI Version:** ${systemStats.system.comfyui_version}
- **Arguments:** ${systemStats.system.argv.join(" ")}
- **OS:** ${systemStats.system.os}
- **Python Version:** ${systemStats.system.python_version}
- **Embedded Python:** ${systemStats.system.embedded_python}
- **PyTorch Version:** ${systemStats.system.pytorch_version}
## Devices
${systemStats.devices.map((device) => `
- **Name:** ${device.name}
  - **Type:** ${device.type}
  - **VRAM Total:** ${device.vram_total}
  - **VRAM Free:** ${device.vram_free}
  - **Torch VRAM Total:** ${device.torch_vram_total}
  - **Torch VRAM Free:** ${device.torch_vram_free}
`).join("\n")}
## Logs
\`\`\`
${typeof error.serverLogs === "string" ? error.serverLogs : JSON.stringify(error.serverLogs, null, 2)}
\`\`\`
## Attached Workflow
Please make sure that workflow does not contain any sensitive information such as API keys or passwords.
\`\`\`
${workflowText}
\`\`\`

## Additional Context
(Please add any additional context or steps to reproduce the error here)
`;
}
//#endregion
//#region src/components/dialog/content/ErrorDialogContent.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$1 = {
	"data-testid": "error-dialog",
	class: "comfy-error-report flex flex-col gap-4"
};
var _hoisted_2$1 = { class: "font-bold" };
var _hoisted_3 = { class: "flex justify-center gap-2" };
var _hoisted_4 = { class: "h-[400px] w-full max-w-[80vw] overflow-auto" };
var _hoisted_5 = { class: "wrap-break-word whitespace-pre-wrap" };
var _hoisted_6 = { class: "flex justify-end gap-4" };
var repoOwner = "comfyanonymous";
var repoName = "ComfyUI";
//#endregion
//#region src/components/dialog/content/ErrorDialogContent.vue
var ErrorDialogContent_default = /* @__PURE__ */ defineComponent({
	__name: "ErrorDialogContent",
	props: {
		errorSources: { default: () => [] },
		error: {}
	},
	setup(__props) {
		const reportContent = ref("");
		const reportOpen = ref(false);
		/**
		* Open the error report content and track telemetry.
		*/
		const showReport = () => {
			useTelemetry()?.trackUiButtonClicked({
				button_id: "error_dialog_show_report_clicked",
				element_group: "error_dialog"
			});
			reportOpen.value = true;
		};
		const toast = useToast();
		const { t } = useI18n();
		const systemStatsStore = useSystemStatsStore();
		const telemetry = useTelemetry();
		const resolvedErrors = computed(() => __props.errorSources.map((source) => {
			const resolved = resolveRunErrorMessage(source);
			const rawMessage = source.kind === "execution" ? source.error.exception_message : resolved.displayMessage ? source.error.details : [source.error.message, source.error.details].filter(Boolean).join(": ");
			return {
				title: resolved.displayTitle,
				message: [
					source.kind === "node_validation" ? resolved.displayItemLabel : void 0,
					resolved.displayMessage,
					resolved.displayDetails ?? rawMessage
				].filter(Boolean).join("\n")
			};
		}));
		const title = computed(() => {
			const displayTitle = [
				resolvedErrors.value[0]?.title,
				__props.error.nodeType,
				__props.error.exceptionType
			].find((candidate) => candidate?.trim()) || t("errorDialog.defaultTitle");
			if (__props.errorSources[0]?.kind !== "execution") return displayTitle;
			const nodeTitle = __props.error.nodeType?.trim() ? __props.error.nodeType : displayTitle;
			return __props.error.nodeId ? `${nodeTitle} (#${__props.error.nodeId})` : nodeTitle;
		});
		const message = computed(() => resolvedErrors.value.map((resolved) => resolved.message).filter(Boolean).join("\n\n") || __props.error.exceptionMessage);
		/**
		* Open contact support flow from error dialog and track telemetry.
		*/
		const showContactSupport = async () => {
			telemetry?.trackHelpResourceClicked({
				resource_type: "help_feedback",
				is_external: true,
				source: "error_dialog"
			});
			await useCommandStore().execute("Comfy.ContactSupport");
		};
		onMounted(async () => {
			if (!systemStatsStore.systemStats) await systemStatsStore.refetchSystemStats();
			try {
				const logs = await api.getLogs();
				reportContent.value = generateErrorReport({
					systemStats: systemStatsStore.systemStats,
					serverLogs: logs,
					workflow: useApp().rootGraph.serialize(),
					exceptionType: __props.error.exceptionType,
					exceptionMessage: __props.error.exceptionMessage,
					traceback: __props.error.traceback,
					nodeId: __props.error.nodeId,
					nodeType: __props.error.nodeType
				});
			} catch (error) {
				console.error("Error fetching logs:", error);
				toast.error(t("g.error"), { description: t("toastMessages.failedToFetchLogs") });
			}
		});
		const { copyToClipboard } = useCopyToClipboard();
		const copyReportToClipboard = async () => {
			await copyToClipboard(reportContent.value);
		};
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$1, [
				createVNode(NoResultsPlaceholder_default, {
					class: "pb-0",
					icon: "pi pi-exclamation-circle",
					message: message.value,
					"text-class": "break-words max-w-[60vw]"
				}, {
					title: withCtx(() => [createVNode(DialogTitle_default, {
						as: "h3",
						class: "mb-2 text-[1.17em] font-bold"
					}, {
						default: withCtx(() => [createTextVNode(toDisplayString(title.value), 1)]),
						_: 1
					})]),
					_: 1
				}, 8, ["message"]),
				__props.error.extensionFile ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
					createBaseVNode("span", null, toDisplayString(unref(t)("errorDialog.extensionFileHint")) + ":", 1),
					_cache[0] || (_cache[0] = createBaseVNode("br", null, null, -1)),
					createBaseVNode("span", _hoisted_2$1, toDisplayString(__props.error.extensionFile), 1)
				], 64)) : createCommentVNode("", true),
				createBaseVNode("div", _hoisted_3, [withDirectives(createVNode(Button_default, {
					"data-testid": "error-dialog-show-report",
					variant: "textonly",
					onClick: showReport
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("g.showReport")), 1)]),
					_: 1
				}, 512), [[vShow, !reportOpen.value]]), withDirectives(createVNode(Button_default, {
					"data-testid": "error-dialog-contact-support",
					variant: "textonly",
					onClick: showContactSupport
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("issueReport.helpFix")), 1)]),
					_: 1
				}, 512), [[vShow, !reportOpen.value]])]),
				reportOpen.value ? (openBlock(), createElementBlock(Fragment, { key: 1 }, [
					_cache[1] || (_cache[1] = createBaseVNode("hr", { class: "border-t border-border/50" }, null, -1)),
					createBaseVNode("div", _hoisted_4, [createBaseVNode("pre", _hoisted_5, toDisplayString(reportContent.value), 1)]),
					_cache[2] || (_cache[2] = createBaseVNode("hr", { class: "border-t border-border/50" }, null, -1))
				], 64)) : createCommentVNode("", true),
				createBaseVNode("div", _hoisted_6, [createVNode(FindIssueButton_default, {
					"error-message": __props.error.exceptionMessage,
					"repo-owner": repoOwner,
					"repo-name": repoName
				}, null, 8, ["error-message"]), reportOpen.value ? (openBlock(), createBlock(Button_default, {
					key: 0,
					"data-testid": "error-dialog-copy-report",
					onClick: copyReportToClipboard
				}, {
					default: withCtx(() => [_cache[3] || (_cache[3] = createBaseVNode("i", { class: "pi pi-copy" }, null, -1)), createTextVNode(" " + toDisplayString(_ctx.$t("g.copyToClipboard")), 1)]),
					_: 1
				})) : createCommentVNode("", true)])
			]);
		};
	}
});
//#endregion
//#region src/components/dialog/content/PromptDialogContent.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "prompt-dialog-content flex flex-col gap-2 pt-8" };
var _hoisted_2 = { class: "flex flex-col gap-1 text-sm text-muted-foreground" };
//#endregion
//#region src/components/dialog/content/PromptDialogContent.vue
var PromptDialogContent_default = /* @__PURE__ */ defineComponent({
	__name: "PromptDialogContent",
	props: {
		message: {},
		defaultValue: {},
		onConfirm: { type: Function },
		placeholder: {}
	},
	setup(__props) {
		const inputValue = ref(__props.defaultValue);
		function handleConfirm() {
			__props.onConfirm(inputValue.value);
			useDialogStore().closeDialog();
		}
		const inputRef = ref();
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1, [createBaseVNode("label", _hoisted_2, [createTextVNode(toDisplayString(__props.message) + " ", 1), createVNode(Input_default, {
				ref_key: "inputRef",
				ref: inputRef,
				modelValue: inputValue.value,
				"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => inputValue.value = $event),
				type: "text",
				placeholder: __props.placeholder,
				autofocus: "",
				onKeyup: withKeys(handleConfirm, ["enter"]),
				onFocus: _cache[1] || (_cache[1] = ($event) => inputRef.value?.selectAll())
			}, null, 8, ["modelValue", "placeholder"])]), createVNode(Button_default, { onClick: handleConfirm }, {
				default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("g.confirm")), 1)]),
				_: 1
			})]);
		};
	}
});
//#endregion
//#region src/services/dialogService.ts
var GLOBAL_PROMPT_KEY = "global-prompt";
function getCatalogPromptError(value) {
	if (typeof value === "string") return {
		type: "error",
		message: value,
		details: ""
	};
	if (!isPlainObject$1(value)) return null;
	const { type = "error", message = "", details = "" } = value;
	return typeof type === "string" && typeof message === "string" && typeof details === "string" ? {
		type,
		message,
		details
	} : null;
}
function getPromptErrorSources(response) {
	const parsed = zPromptErrorResponse.safeParse(response);
	if (!parsed.success) return [];
	const promptError = getCatalogPromptError(parsed.data.error);
	const nodeErrors = isPlainObject$1(parsed.data.node_errors) ? parsed.data.node_errors : {};
	return [...promptError ? [{
		kind: "prompt",
		error: promptError,
		isCloud: false
	}] : [], ...Object.entries(nodeErrors).flatMap(([nodeId, value]) => {
		if (!isPlainObject$1(value)) return [];
		const node = value;
		return (Array.isArray(node.errors) ? node.errors : []).flatMap((value) => {
			if (!isPlainObject$1(value)) return [];
			const error = getCatalogPromptError(value);
			if (!error) return [];
			const extraInfo = isPlainObject$1(value.extra_info) ? value.extra_info : {};
			return [{
				kind: "node_validation",
				error: {
					...error,
					extra_info: {
						...extraInfo,
						input_name: typeof extraInfo.input_name === "string" ? extraInfo.input_name : void 0
					}
				},
				nodeDisplayName: typeof node.class_type === "string" ? `${node.class_type} (#${nodeId})` : `#${nodeId}`
			}];
		});
	})];
}
function formatDialogError(error) {
	try {
		return error.toString();
	} catch (cause) {
		if (!(error instanceof PromptExecutionError)) throw cause;
		return JSON.stringify(error.response);
	}
}
var promptTails = /* @__PURE__ */ new Map();
function enqueuePrompt(key, show) {
	const result = (promptTails.get(key) ?? Promise.resolve()).then(() => new Promise(show));
	const settled = result.then(() => void 0, () => void 0);
	promptTails.set(key, settled);
	settled.then(() => {
		if (promptTails.get(key) === settled) promptTails.delete(key);
	});
	return result;
}
var useDialogService = () => {
	const dialogStore = useDialogStore();
	function showExecutionErrorDialog(executionError) {
		const validationSources = getPromptErrorSources(tryExtractValidationError(executionError.exception_message));
		const props = {
			errorSources: validationSources.length ? validationSources : [{
				kind: "execution",
				error: executionError,
				nodeDisplayName: executionError.node_type ?? ""
			}],
			error: {
				exceptionType: executionError.exception_type,
				exceptionMessage: executionError.exception_message,
				nodeId: executionError.node_id?.toString(),
				nodeType: executionError.node_type ?? void 0,
				traceback: executionError.traceback?.join("\n") ?? "",
				reportType: "graphExecutionError"
			}
		};
		dialogStore.showDialog({
			key: "global-execution-error",
			component: ErrorDialogContent_default,
			props,
			dialogComponentProps: {
				size: "lg",
				onClose: () => {
					useTelemetry()?.trackUiButtonClicked({
						button_id: "error_dialog_closed",
						element_group: "error_dialog"
					});
				}
			}
		});
	}
	function parseError(error) {
		const filename = "fileName" in error ? error.fileName : error.stack?.match(/(\/extensions\/.*\.js)/)?.[1];
		const extensionFile = filename ? filename.substring(filename.indexOf("/extensions/")) : void 0;
		return {
			errorMessage: formatDialogError(error),
			stackTrace: error.stack,
			extensionFile
		};
	}
	/**
	* Show a error dialog to the user when an error occurs.
	* @param error The error to show
	* @param options The options for the dialog
	*/
	function showErrorDialog(error, options = {}) {
		const errorProps = error instanceof Error ? parseError(error) : { errorMessage: String(error) };
		const props = {
			errorSources: error instanceof PromptExecutionError ? getPromptErrorSources(error.response) : void 0,
			error: {
				exceptionType: options.title ?? "Unknown Error",
				exceptionMessage: errorProps.errorMessage,
				extensionFile: errorProps.extensionFile,
				traceback: errorProps.stackTrace ?? t("errorDialog.noStackTrace"),
				reportType: options.reportType
			}
		};
		dialogStore.showDialog({
			key: "global-error",
			component: ErrorDialogContent_default,
			props,
			dialogComponentProps: {
				size: "lg",
				onClose: () => {
					useTelemetry()?.trackUiButtonClicked({
						button_id: "error_dialog_closed",
						element_group: "error_dialog"
					});
				}
			}
		});
	}
	async function prompt({ title, message, defaultValue = "", placeholder }) {
		return enqueuePrompt(GLOBAL_PROMPT_KEY, (resolve) => {
			dialogStore.showDialog({
				key: GLOBAL_PROMPT_KEY,
				title,
				component: PromptDialogContent_default,
				props: {
					message,
					defaultValue,
					onConfirm: (value) => {
						resolve(value);
					},
					placeholder
				},
				dialogComponentProps: {
					size: "md",
					onRemoved: () => {
						resolve(null);
					}
				}
			});
		});
	}
	/**
	* @returns `true` if the user confirms the dialog,
	* `false` if denied (e.g. no in yes/no/cancel), or
	* `null` if the dialog is cancelled or closed
	*/
	async function confirm({ title, message, type = "default", itemList = [], hint, denyLabel, confirmLabel, key = GLOBAL_PROMPT_KEY }) {
		const show = (resolve) => {
			const options = {
				key,
				title,
				component: ConfirmationDialogContent_default,
				props: {
					message,
					type,
					itemList,
					onConfirm: resolve,
					hint,
					denyLabel,
					confirmLabel
				},
				dialogComponentProps: {
					size: "md",
					onRemoved: () => resolve(null)
				}
			};
			dialogStore.showDialog(options);
		};
		return enqueuePrompt(key, show);
	}
	/**
	* Shows a dialog from a third party extension.
	* @param options - The dialog options.
	* @param options.key - The dialog key.
	* @param options.title - The dialog title.
	* @param options.headerComponent - The dialog header component.
	* @param options.footerComponent - The dialog footer component.
	* @param options.component - The dialog component.
	* @param options.props - The dialog props.
	* @returns The dialog instance and a function to close the dialog.
	*/
	function showExtensionDialog(options) {
		return {
			dialog: dialogStore.showExtensionDialog(options),
			closeDialog: () => dialogStore.closeDialog({ key: options.key })
		};
	}
	function showLayoutDialog(options) {
		const layoutDefaultProps = {
			headless: true,
			closable: true
		};
		return dialogStore.showDialog({
			...options,
			dialogComponentProps: merge(layoutDefaultProps, options.dialogComponentProps || {})
		});
	}
	function showSmallLayoutDialog(options) {
		const { dialogComponentProps: callerProps, ...rest } = options;
		return dialogStore.showDialog({
			...rest,
			dialogComponentProps: {
				closable: true,
				flush: true,
				size: "fit",
				...callerProps
			}
		});
	}
	return {
		showExecutionErrorDialog,
		showErrorDialog,
		prompt,
		confirm,
		showExtensionDialog,
		showLayoutDialog,
		showSmallLayoutDialog
	};
};
var extensionDialogService;
function registerExtensionDialogService(service) {
	extensionDialogService = service;
}
function useExtensionDialogService() {
	assert(extensionDialogService, "Extension dialog service accessed before registerExtensionDialogService");
	return extensionDialogService;
}
//#endregion
export { isValueStillOutOfRange as A, classifyCloudValidationError as C, isImageNotLoadedValidationError as D, hasErrorForSlot as E, isObjectLike as F, isPlainObject as I, sumBy as L, merge as M, mergeWith as N, isMissingNodePromptError as O, isArrayLikeObject as P, SIMPLE_ERROR_TYPES as S, getInputConfigBounds as T, WORKSPACE_INSUFFICIENT_CREDITS_CATALOG_ID as _, resolveRunErrorMessage as a, registerSettingDialogComponent as b, countMissingModels as c, getMissingMediaReferences as d, resolveRuntimeCatalogMatch as f, SUBSCRIPTION_UPGRADE_REQUIRED_CATALOG_ID as g, SUBSCRIPTION_REQUIRED_CATALOG_ID as h, generateErrorReport as i, normalizePromptError as j, isNodeLevelValidationError as k, groupMissingModelCandidates as l, SIGN_IN_REQUIRED_CATALOG_ID as m, useDialogService as n, resolveMissingErrorMessage as o, INSUFFICIENT_CREDITS_CATALOG_ID as p, useExtensionDialogService as r, resolveMissingMediaItemLabel as s, registerExtensionDialogService as t, countMissingMediaReferences as u, NoResultsPlaceholder_default as v, errorsForSlot as w, useSettingsDialog as x, ConfirmationDialogContent_default as y };
