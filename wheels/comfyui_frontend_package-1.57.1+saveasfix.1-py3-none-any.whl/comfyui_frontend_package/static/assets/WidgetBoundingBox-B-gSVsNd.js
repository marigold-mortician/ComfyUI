import { t as WidgetBoundingBox_default } from "./WidgetBoundingBox-C-GCOEs8.js";
export { WidgetBoundingBox_default as default };
