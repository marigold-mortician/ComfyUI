import "./rolldown-runtime-xtsTai4I.js";
import { F as createBaseVNode, G as defineComponent, H as createTextVNode, P as computed, R as createElementBlock, U as createVNode, Wt as unref, Yt as toDisplayString, at as onMounted, ct as openBlock, rt as onBeforeUnmount, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
import { n as BOUNDING_BOXES_HEADER_ACTIONS_ID, t as BoundingBoxesEditor_default } from "./BoundingBoxesEditor-DG3cE7k7.js";
import { t as locateWidgetNode } from "./widgetHistoryScope-DLmWjnnJ.js";
import { t as DialogClose_default } from "./DialogClose-dPzCXguP.js";
//#region src/components/boundingBoxes/BoundingBoxesDialogContent.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$1 = { class: "flex min-h-0 flex-1 flex-col" };
//#endregion
//#region src/components/boundingBoxes/BoundingBoxesDialogContent.vue
var BoundingBoxesDialogContent_default = /* @__PURE__ */ defineComponent({
	__name: "BoundingBoxesDialogContent",
	props: {
		nodeId: {},
		widget: {},
		close: { type: Function }
	},
	setup(__props) {
		const location = locateWidgetNode(__props.widget, __props.nodeId);
		const graph = location?.graph;
		const node = location ? graph?.getNodeById(location.nodeId) : void 0;
		const liveWidget = node?.widgets?.find((w) => w.name === __props.widget.name);
		const listeners = new AbortController();
		graph?.rootGraph.events.addEventListener("configuring", __props.close, { signal: listeners.signal });
		graph?.events.addEventListener("node:removed", ({ detail }) => {
			if (detail.node === node) __props.close();
		}, { signal: listeners.signal });
		onMounted(() => {
			if (!liveWidget) __props.close();
		});
		onBeforeUnmount(() => listeners.abort());
		const modelValue = computed({
			get: () => {
				const value = liveWidget?.value;
				return Array.isArray(value) ? value : [];
			},
			set: (boxes) => __props.widget.callback?.(boxes)
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$1, [createVNode(BoundingBoxesEditor_default, {
				modelValue: modelValue.value,
				"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => modelValue.value = $event),
				"node-id": __props.nodeId,
				widget: __props.widget,
				fullscreen: ""
			}, null, 8, [
				"modelValue",
				"node-id",
				"widget"
			])]);
		};
	}
});
//#endregion
//#region src/components/boundingBoxes/BoundingBoxesDialogHeader.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "flex w-full items-center justify-between gap-2 border-b p-2" };
var _hoisted_2 = { class: "flex items-center gap-2" };
var _hoisted_3 = { class: "m-0 text-sm font-semibold" };
var _hoisted_4 = { class: "flex items-center gap-2" };
var _hoisted_5 = ["id"];
//#endregion
//#region src/components/boundingBoxes/BoundingBoxesDialogHeader.vue
var BoundingBoxesDialogHeader_default = /* @__PURE__ */ defineComponent({
	__name: "BoundingBoxesDialogHeader",
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1, [createBaseVNode("div", _hoisted_2, [_cache[0] || (_cache[0] = createBaseVNode("i", { class: "icon-[lucide--square-dashed] size-4" }, null, -1)), createBaseVNode("h3", _hoisted_3, toDisplayString(_ctx.$t("boundingBoxes.editorTitle")), 1)]), createBaseVNode("div", _hoisted_4, [createBaseVNode("div", {
				id: unref(BOUNDING_BOXES_HEADER_ACTIONS_ID),
				class: "flex items-center gap-2",
				role: "group"
			}, null, 8, _hoisted_5), createVNode(DialogClose_default, { "aria-label": _ctx.$t("g.close") }, {
				default: withCtx(() => [createVNode(Button_default, {
					variant: "outline",
					size: "md"
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("g.close")) + " ", 1), _cache[1] || (_cache[1] = createBaseVNode("i", { class: "icon-[lucide--x] size-4" }, null, -1))]),
					_: 1
				})]),
				_: 1
			}, 8, ["aria-label"])])]);
		};
	}
});
//#endregion
//#region src/components/boundingBoxes/boundingBoxesDialog.ts
var BOUNDING_BOXES_DIALOG_KEY = "global-bounding-boxes-editor";
var boundingBoxesDialogProps = {
	flush: true,
	size: "full",
	maximizable: false,
	maximized: true,
	closable: true,
	showCloseButton: false,
	dismissOnPointerDownOutside: false
};
function openBoundingBoxesDialog(nodeId, widget) {
	useDialogStore().showDialog({
		key: BOUNDING_BOXES_DIALOG_KEY,
		headerComponent: BoundingBoxesDialogHeader_default,
		component: BoundingBoxesDialogContent_default,
		props: {
			nodeId,
			widget,
			close: () => useDialogStore().closeDialog({ key: BOUNDING_BOXES_DIALOG_KEY })
		},
		dialogComponentProps: boundingBoxesDialogProps
	});
}
//#endregion
export { openBoundingBoxesDialog };
