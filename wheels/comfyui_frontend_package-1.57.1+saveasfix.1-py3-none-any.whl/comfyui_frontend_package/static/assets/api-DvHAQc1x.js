import { i as api } from "./api-BdJmXw98.js";
export { api };
