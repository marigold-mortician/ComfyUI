import "./rolldown-runtime-xtsTai4I.js";
import { t as useExecutionErrorStore } from "./executionErrorStore-MSMBxScr.js";
import { n as useSettingStore } from "./settingStore-DRRi2kOn.js";
import { _ as WORKSPACE_INSUFFICIENT_CREDITS_CATALOG_ID, f as resolveRuntimeCatalogMatch, g as SUBSCRIPTION_UPGRADE_REQUIRED_CATALOG_ID, h as SUBSCRIPTION_REQUIRED_CATALOG_ID, m as SIGN_IN_REQUIRED_CATALOG_ID, p as INSUFFICIENT_CREDITS_CATALOG_ID } from "./dialogService-CqZr0BhP.js";
import { i as retainSharedObjectUrl, r as releaseSharedObjectUrl, t as useNodeOutputStore } from "./nodeOutputStore-DmbNgTmp.js";
import { i as api } from "./api-BdJmXw98.js";
import { Ft as ref, P as computed, Pt as readonly, Rt as shallowRef, bt as watch, d as defineStore } from "./vendor-vue-core-CuN1excl.js";
import { Nr as createEventHook } from "./vendor-reka-ui-NRTk7aIV.js";
import { n as useWorkflowStore } from "./workflowStore-DP6mciq-.js";
import { n as useApp } from "./appInstance-CiT6CpGM.js";
import { n as useTelemetry } from "./telemetry-IkzvF0TI.js";
import { r as reportError } from "./reportError-BHgDVvfb.js";
import { J as tryNormalizeNodeExecutionId, i as executionIdToNodeLocatorId } from "./graphTraversalUtil-BUK1cr2m.js";
import { a as useAppMode, s as isAppModeValue } from "./canvasStore-Dnz7OWvY.js";
//#region src/platform/workflowErrors/errorCatalog/accountPreconditionRouting.ts
var CATALOG_ID_TO_PRECONDITION = /* @__PURE__ */ new Map([
	[SIGN_IN_REQUIRED_CATALOG_ID, "sign_in"],
	[SUBSCRIPTION_REQUIRED_CATALOG_ID, "subscription"],
	[SUBSCRIPTION_UPGRADE_REQUIRED_CATALOG_ID, "subscription"],
	[INSUFFICIENT_CREDITS_CATALOG_ID, "credits"],
	[WORKSPACE_INSUFFICIENT_CREDITS_CATALOG_ID, "credits"]
]);
function preconditionForCatalogId(catalogId) {
	if (!catalogId) return void 0;
	return CATALOG_ID_TO_PRECONDITION.get(catalogId);
}
function resolveAccountPrecondition(info) {
	return preconditionForCatalogId(resolveRuntimeCatalogMatch(info)?.catalogId);
}
//#endregion
//#region src/stores/jobPreviewStore.ts
var useJobPreviewStore = defineStore("jobPreview", () => {
	const settingStore = useSettingStore();
	const nodePreviewsByPromptId = ref({});
	const previewMethod = computed(() => settingStore.get("Comfy.Execution.PreviewMethod"));
	const isPreviewEnabled = computed(() => previewMethod.value !== "none");
	const previewsByPromptId = computed(() => {
		const result = {};
		for (const [k, v] of Object.entries(nodePreviewsByPromptId.value)) result[k] = v.url;
		return result;
	});
	function setPreviewUrl(promptId, url, nodeId) {
		if (!promptId || !isPreviewEnabled.value) return;
		const current = nodePreviewsByPromptId.value[promptId];
		if (promptId in nodePreviewsByPromptId.value) {
			if (current.url === url) return;
			releaseSharedObjectUrl(current.url);
		}
		retainSharedObjectUrl(url);
		nodePreviewsByPromptId.value = {
			...nodePreviewsByPromptId.value,
			[promptId]: {
				url,
				nodeId
			}
		};
	}
	function clearPreview(promptId) {
		if (!promptId) return;
		if (!(promptId in nodePreviewsByPromptId.value)) return;
		const current = nodePreviewsByPromptId.value[promptId];
		releaseSharedObjectUrl(current.url);
		const next = { ...nodePreviewsByPromptId.value };
		delete next[promptId];
		nodePreviewsByPromptId.value = next;
	}
	function clearAllPreviews() {
		for (const { url } of Object.values(nodePreviewsByPromptId.value)) releaseSharedObjectUrl(url);
		nodePreviewsByPromptId.value = {};
	}
	watch(isPreviewEnabled, (enabled) => {
		if (!enabled) clearAllPreviews();
	});
	return {
		nodePreviewsByPromptId: readonly(nodePreviewsByPromptId),
		previewsByPromptId,
		isPreviewEnabled,
		setPreviewUrl,
		clearPreview,
		clearAllPreviews
	};
});
//#endregion
//#region src/utils/rafBatch.ts
function createRafBatch(run) {
	let rafId = null;
	const schedule = () => {
		if (rafId != null) return;
		rafId = requestAnimationFrame(() => {
			rafId = null;
			run();
		});
	};
	const cancel = () => {
		if (rafId != null) {
			cancelAnimationFrame(rafId);
			rafId = null;
		}
	};
	const flush = () => {
		if (rafId == null) return;
		cancelAnimationFrame(rafId);
		rafId = null;
		run();
	};
	const isScheduled = () => rafId != null;
	return {
		schedule,
		cancel,
		flush,
		isScheduled
	};
}
/**
* Last-write-wins RAF coalescer. Buffers the latest value and applies it
* on the next animation frame, coalescing multiple pushes into a single
* reactive update.
*
* Pass a `label` to emit `performance.mark` events in dev mode so the
* batching benefit is visible in the browser profiler under that name.
*/
function createRafCoalescer(apply, label) {
	let hasPending = false;
	let pendingValue;
	let droppedCount = 0;
	const batch = createRafBatch(() => {
		if (!hasPending) return;
		const value = pendingValue;
		droppedCount = 0;
		hasPending = false;
		pendingValue = void 0;
		apply(value);
	});
	const push = (value) => {
		if (hasPending) droppedCount++;
		pendingValue = value;
		hasPending = true;
		batch.schedule();
	};
	const cancel = () => {
		droppedCount = 0;
		hasPending = false;
		pendingValue = void 0;
		batch.cancel();
	};
	return {
		push,
		cancel,
		isScheduled: batch.isScheduled
	};
}
//#endregion
//#region src/stores/executionStore.ts
var defaultWorkflowExecutionIntent = { trigger_source: "unknown" };
function buildExecutionNodeLookup(promptOutput) {
	return Object.fromEntries(Object.entries(promptOutput).map(([executionId, node]) => [executionId, {
		title: node._meta?.title ?? node.class_type,
		type: node.class_type
	}]));
}
/**
* Maximum number of job entries retained in {@link nodeProgressStatesByJob}.
* When exceeded, the oldest entries (by insertion order) are evicted to
* prevent unbounded memory growth in long-running sessions.
*/
var MAX_PROGRESS_JOBS = 1e3;
var WORKFLOW_STATUS_I18N_KEYS = {
	running: "g.running",
	completed: "g.completed",
	failed: "g.failed"
};
var useExecutionStore = defineStore("execution", () => {
	const workflowStore = useWorkflowStore();
	const executionErrorStore = useExecutionErrorStore();
	const { mode, isAppMode } = useAppMode();
	const clientId = ref(null);
	const activeJobId = ref(null);
	const queuedJobs = ref({});
	const jobReset = createEventHook();
	const nodeProgressStates = ref({});
	const nodeProgressStatesByJob = ref({});
	/**
	* Map of job ID to workflow ID for quick lookup across the app.
	*/
	const jobIdToWorkflowId = ref(/* @__PURE__ */ new Map());
	/**
	* Map of job ID to workflow file path in the current session.
	* Only populated for jobs that are queued in this browser tab.
	*/
	const jobIdToSessionWorkflowPath = shallowRef(/* @__PURE__ */ new Map());
	const jobIdToWorkflowInstanceId = /* @__PURE__ */ new Map();
	const initializingJobIds = ref(/* @__PURE__ */ new Set());
	const workflowStatus = shallowRef(/* @__PURE__ */ new Map());
	const jobIdToWorkflow = /* @__PURE__ */ new Map();
	const pendingWorkflowStatusByJobId = /* @__PURE__ */ new Map();
	const pendingExecutionErrorsByJobId = /* @__PURE__ */ new Map();
	function bufferPendingWorkflowStatus(jobId, update) {
		const existing = pendingWorkflowStatusByJobId.get(jobId);
		const executionStartedAt = update.executionStartedAt ?? queuedJobs.value[jobId]?.executionStartedAt ?? existing?.executionStartedAt;
		pendingWorkflowStatusByJobId.delete(jobId);
		pendingWorkflowStatusByJobId.set(jobId, {
			...update,
			...executionStartedAt !== void 0 && { executionStartedAt }
		});
		while (pendingWorkflowStatusByJobId.size > MAX_PROGRESS_JOBS) {
			const oldest = pendingWorkflowStatusByJobId.keys().next().value;
			if (oldest === void 0) break;
			pendingWorkflowStatusByJobId.delete(oldest);
		}
	}
	function bufferPendingExecutionError(error) {
		const jobId = error.detail.prompt_id;
		pendingExecutionErrorsByJobId.delete(jobId);
		pendingExecutionErrorsByJobId.set(jobId, error);
		while (pendingExecutionErrorsByJobId.size > MAX_PROGRESS_JOBS) {
			const oldest = pendingExecutionErrorsByJobId.keys().next().value;
			if (oldest === void 0) break;
			pendingExecutionErrorsByJobId.delete(oldest);
		}
	}
	function mutateStatus(mutator) {
		const next = new Map(workflowStatus.value);
		mutator(next);
		workflowStatus.value = next;
	}
	function applyWorkflowStatus(workflow, status) {
		if (!workflowStore.isOpen(workflow)) return;
		mutateStatus((m) => m.set(workflow, status));
	}
	function trackExecutionOutcome(jobId, { status, endTime, failureReason }) {
		if (status === "running" || endTime === void 0) return;
		if (!(jobId in queuedJobs.value)) return;
		const queuedJob = queuedJobs.value[jobId];
		const startTime = queuedJob.startTime;
		const workflowExecutionIntent = queuedJob.workflowExecutionIntent;
		if (queuedJob.outcomeTracked || startTime === void 0 || workflowExecutionIntent === void 0) return;
		queuedJob.outcomeTracked = true;
		const metadata = {
			startTime,
			...workflowExecutionIntent,
			...queuedJob.submissionAcceptedAt !== void 0 && { submissionAcceptedAt: queuedJob.submissionAcceptedAt },
			...queuedJob.executionStartedAt !== void 0 && { executionStartedAt: queuedJob.executionStartedAt },
			endTime,
			...queuedJob.workflowContext && { workflowContext: queuedJob.workflowContext }
		};
		const telemetry = useTelemetry();
		if (status === "completed") {
			telemetry?.trackExecutionOutcome({
				...metadata,
				success: true,
				failureReason: ""
			});
			return;
		}
		telemetry?.trackExecutionOutcome({
			...metadata,
			success: false,
			failureReason: failureReason ?? "execution_failed"
		});
	}
	function setWorkflowStatus(jobId, update) {
		const workflow = jobIdToWorkflow.get(jobId);
		if (!workflow) {
			bufferPendingWorkflowStatus(jobId, update);
			return;
		}
		if (update.showStatus !== false) applyWorkflowStatus(workflow, update.status);
		trackExecutionOutcome(jobId, update);
	}
	function clearWorkflowStatus(workflow) {
		if (!workflowStatus.value.has(workflow)) return;
		mutateStatus((m) => m.delete(workflow));
	}
	function getWorkflowStatus(workflow) {
		if (!workflow) return void 0;
		return workflowStatus.value.get(workflow);
	}
	watch(() => workflowStore.openWorkflows, (openWorkflows) => {
		if (workflowStatus.value.size === 0) return;
		const openSet = new Set(openWorkflows);
		const filtered = new Map([...workflowStatus.value].filter(([w]) => openSet.has(w)));
		if (filtered.size !== workflowStatus.value.size) workflowStatus.value = filtered;
	});
	/**
	* Cache for executionIdToNodeLocatorId lookups.
	* Avoids redundant graph traversals during a single execution run.
	* Cleared at execution start and end to ensure fresh graph state.
	*/
	const executionIdToLocatorCache = /* @__PURE__ */ new Map();
	function cachedExecutionIdToLocator(executionId) {
		if (executionIdToLocatorCache.has(executionId)) return executionIdToLocatorCache.get(executionId);
		const locatorId = executionIdToNodeLocatorId(useApp().rootGraph, executionId);
		executionIdToLocatorCache.set(executionId, locatorId);
		return locatorId;
	}
	const mergeExecutionProgressStates = (currentState, newState) => {
		if (currentState === void 0) return newState;
		const mergedState = { ...currentState };
		if (mergedState.state === "error") return mergedState;
		else if (newState.state === "running") {
			const newPerc = newState.max > 0 ? newState.value / newState.max : 0;
			const oldPerc = mergedState.max > 0 ? mergedState.value / mergedState.max : 0;
			if (mergedState.state !== "running" || oldPerc === 0 || newPerc < oldPerc) {
				mergedState.value = newState.value;
				mergedState.max = newState.max;
			}
			mergedState.state = "running";
		}
		return mergedState;
	};
	const nodeLocationProgressStates = computed(() => {
		const result = {};
		const states = nodeProgressStates.value;
		for (const state of Object.values(states)) {
			const parts = String(state.display_node_id).split(":");
			for (let i = 0; i < parts.length; i++) {
				const locatorId = cachedExecutionIdToLocator(parts.slice(0, i + 1).join(":"));
				if (!locatorId) continue;
				result[locatorId] = mergeExecutionProgressStates(result[locatorId], state);
			}
		}
		return result;
	});
	const executingNodeIds = computed(() => {
		return Object.entries(nodeProgressStates.value).filter(([_, state]) => state.state === "running").map(([nodeId, _]) => nodeId);
	});
	const executingNodeId = computed(() => {
		return executingNodeIds.value[0] ?? null;
	});
	const uniqueExecutingNodeIdStrings = computed(() => new Set(executingNodeIds.value.map(String)));
	const executingNode = computed(() => {
		if (!executingNodeId.value) return null;
		return activeJob.value?.nodeLookup?.[executingNodeId.value] ?? null;
	});
	const _executingNodeProgress = ref(null);
	const executingNodeProgress = computed(() => _executingNodeProgress.value ? _executingNodeProgress.value.value / _executingNodeProgress.value.max : null);
	const activeJob = computed(() => queuedJobs.value[activeJobId.value ?? ""]);
	const totalNodesToExecute = computed(() => {
		if (!activeJob.value) return 0;
		return Object.values(activeJob.value.nodes).length;
	});
	const isIdle = computed(() => !activeJobId.value);
	const nodesExecuted = computed(() => {
		if (!activeJob.value) return 0;
		return Object.values(activeJob.value.nodes).filter(Boolean).length;
	});
	const executionProgress = computed(() => {
		if (!activeJob.value) return 0;
		const total = totalNodesToExecute.value;
		const done = nodesExecuted.value;
		return total > 0 ? done / total : 0;
	});
	function bindExecutionEvents() {
		api.addEventListener("notification", handleNotification);
		api.addEventListener("execution_start", handleExecutionStart);
		api.addEventListener("execution_cached", handleExecutionCached);
		api.addEventListener("execution_interrupted", handleExecutionInterrupted);
		api.addEventListener("execution_success", handleExecutionSuccess);
		api.addEventListener("executed", handleExecuted);
		api.addEventListener("executing", handleExecuting);
		api.addEventListener("progress", handleProgress);
		api.addEventListener("progress_state", handleProgressState);
		api.addEventListener("status", handleStatus);
		api.addEventListener("execution_error", handleExecutionError);
	}
	function unbindExecutionEvents() {
		api.removeEventListener("notification", handleNotification);
		api.removeEventListener("execution_start", handleExecutionStart);
		api.removeEventListener("execution_cached", handleExecutionCached);
		api.removeEventListener("execution_interrupted", handleExecutionInterrupted);
		api.removeEventListener("execution_success", handleExecutionSuccess);
		api.removeEventListener("executed", handleExecuted);
		api.removeEventListener("executing", handleExecuting);
		api.removeEventListener("progress", handleProgress);
		api.removeEventListener("progress_state", handleProgressState);
		api.removeEventListener("status", handleStatus);
		api.removeEventListener("execution_error", handleExecutionError);
		if (workflowStatus.value.size > 0) workflowStatus.value = /* @__PURE__ */ new Map();
		pendingWorkflowStatusByJobId.clear();
		pendingExecutionErrorsByJobId.clear();
		jobIdToWorkflow.clear();
		cancelPendingProgressUpdates();
	}
	/**
	* Whether frames for this job may paint the active workflow's canvas.
	* Jobs whose owner is unknown are admitted unless another job is active.
	*/
	function belongsToActiveWorkflow(jobId) {
		if (!jobId) return true;
		const ownerInstanceId = jobIdToWorkflowInstanceId.get(jobId);
		const activeInstanceId = workflowStore.activeWorkflow?.instanceId;
		if (ownerInstanceId && activeInstanceId) return ownerInstanceId === activeInstanceId;
		return !activeJobId.value || jobId === activeJobId.value;
	}
	function handleExecutionStart(e) {
		const jobId = e.detail.prompt_id;
		queuedJobs.value[jobId] ??= { nodes: {} };
		clearInitializationByJobId(jobId);
		if (!jobIdToSessionWorkflowPath.value.has(jobId)) {
			const workflow = queuedJobs.value[jobId]?.workflow;
			if (workflow) ensureSessionWorkflowPath(jobId, workflow.path, workflow.instanceId);
		}
		queuedJobs.value[jobId].executionStartedAt ??= performance.now();
		setWorkflowStatus(jobId, {
			status: "running",
			executionStartedAt: queuedJobs.value[jobId].executionStartedAt
		});
		if (!belongsToActiveWorkflow(jobId)) {
			reportAmbiguousExecutionStartRejection(jobId);
			return;
		}
		executionIdToLocatorCache.clear();
		executionErrorStore.clearExecutionStartErrors(runErrorKeyForJob(jobId));
		activeJobId.value = jobId;
	}
	function reportAmbiguousExecutionStartRejection(jobId) {
		if (jobIdToWorkflowInstanceId.get(jobId)) return;
		reportError(/* @__PURE__ */ new Error("execution_start rejected for a job with no known owner"), {
			surface: "graph",
			errorType: "warning_rejecting_unowned_execution_start",
			level: "warning",
			context: {
				jobId,
				activeJobId: activeJobId.value,
				hasOwnWorkflowRecord: !!queuedJobs.value[jobId]?.workflow,
				activeWorkflowInstanceId: workflowStore.activeWorkflow?.instanceId
			}
		});
	}
	function handleExecutionCached(e) {
		const jobId = e.detail.prompt_id;
		if (!(jobId in queuedJobs.value)) return;
		for (const n of e.detail.nodes) queuedJobs.value[jobId].nodes[n] = true;
	}
	function handleExecutionInterrupted(e) {
		const jobId = e.detail.prompt_id;
		pendingExecutionErrorsByJobId.delete(jobId);
		setWorkflowStatus(jobId, {
			status: "failed",
			endTime: performance.now(),
			failureReason: "execution_interrupted",
			showStatus: false
		});
		const workflow = jobIdToWorkflow.get(jobId);
		if (workflow) clearWorkflowStatus(workflow);
		if (activeJobId.value) clearInitializationByJobId(activeJobId.value);
		resetExecutionState(jobId);
	}
	function handleExecuted(e) {
		const jobId = e.detail.prompt_id;
		if (!(jobId in queuedJobs.value)) return;
		queuedJobs.value[jobId].nodes[e.detail.node] = true;
	}
	function handleExecutionSuccess(e) {
		const jobId = e.detail.prompt_id;
		pendingExecutionErrorsByJobId.delete(jobId);
		setWorkflowStatus(jobId, {
			status: "completed",
			endTime: performance.now()
		});
		const queuedJob = queuedJobs.value[jobId];
		const telemetry = useTelemetry();
		if (jobId in queuedJobs.value) {
			telemetry?.trackExecutionSuccess({ jobId });
			if (queuedJob.shareId) telemetry?.trackSharedWorkflowRun({
				job_id: jobId,
				share_id: queuedJob.shareId,
				view_mode: queuedJob.viewMode ?? mode.value,
				is_app_mode: queuedJob.isAppMode ?? isAppMode.value
			});
		}
		resetExecutionState(jobId);
	}
	function handleExecuting(e) {
		pendingProgressByJob.clear();
		progressCoalescer.cancel();
		if (e.detail == null) {
			pendingProgressStatesByJob.clear();
			progressStateCoalescer.cancel();
		}
		_executingNodeProgress.value = null;
		if (!activeJob.value) return;
		if (e.detail == null) activeJobId.value = null;
	}
	/**
	* Evicts the oldest entries from {@link nodeProgressStatesByJob} when the
	* map exceeds {@link MAX_PROGRESS_JOBS}, preventing unbounded memory
	* growth in long-running sessions.
	*
	* Relies on ES2015+ object key insertion order: the first keys returned
	* by `Object.keys` are the oldest entries.
	*
	* @example
	* ```ts
	* // Given 105 entries, evicts the 5 oldest:
	* evictOldProgressJobs()
	* Object.keys(nodeProgressStatesByJob.value).length // => 100
	* ```
	*/
	function evictOldProgressJobs() {
		const current = nodeProgressStatesByJob.value;
		const keys = Object.keys(current);
		if (keys.length <= 1e3) return;
		const pruned = {};
		const keysToKeep = keys.slice(keys.length - MAX_PROGRESS_JOBS);
		for (const key of keysToKeep) pruned[key] = current[key];
		nodeProgressStatesByJob.value = pruned;
	}
	const pendingProgressStatesByJob = /* @__PURE__ */ new Map();
	const progressStateCoalescer = createRafCoalescer(() => {
		const updates = [...pendingProgressStatesByJob.values()];
		pendingProgressStatesByJob.clear();
		for (const detail of updates) applyProgressState(detail);
	}, "raf:progress_state");
	function handleProgressState(e) {
		const jobId = e.detail.prompt_id;
		pendingProgressStatesByJob.delete(jobId);
		pendingProgressStatesByJob.set(jobId, e.detail);
		progressStateCoalescer.push(null);
	}
	function revokeStartedNodePreviews(nodes, previousForJob) {
		const { revokePreviewsByExecutionId } = useNodeOutputStore();
		for (const nodeId in nodes) {
			if (nodes[nodeId].state !== "running" || nodeId in previousForJob) continue;
			const executionId = tryNormalizeNodeExecutionId(nodeId);
			if (executionId) revokePreviewsByExecutionId(executionId);
		}
	}
	function applyProgressState(detail) {
		const { nodes, prompt_id: jobId } = detail;
		const isOwned = belongsToActiveWorkflow(jobId);
		if (isOwned) revokeStartedNodePreviews(nodes, nodeProgressStatesByJob.value[jobId] ?? {});
		nodeProgressStatesByJob.value = {
			...nodeProgressStatesByJob.value,
			[jobId]: nodes
		};
		evictOldProgressJobs();
		if (!isOwned) return;
		nodeProgressStates.value = nodes;
		if (executingNodeId.value) {
			const nodeState = Object.hasOwn(nodes, executingNodeId.value) ? nodes[executingNodeId.value] : void 0;
			if (!nodeState) return;
			_executingNodeProgress.value = {
				value: nodeState.value,
				max: nodeState.max,
				prompt_id: nodeState.prompt_id,
				node: nodeState.display_node_id || nodeState.node_id
			};
		}
	}
	const pendingProgressByJob = /* @__PURE__ */ new Map();
	const progressCoalescer = createRafCoalescer(() => {
		const updates = [...pendingProgressByJob.values()];
		pendingProgressByJob.clear();
		for (const detail of updates) {
			if (activeJobId.value && detail.prompt_id !== activeJobId.value) continue;
			_executingNodeProgress.value = detail;
		}
	}, "raf:progress");
	function handleProgress(e) {
		const jobId = e.detail.prompt_id;
		pendingProgressByJob.delete(jobId);
		pendingProgressByJob.set(jobId, e.detail);
		progressCoalescer.push(null);
	}
	function cancelPendingProgressUpdates(jobId) {
		if (!jobId) {
			pendingProgressByJob.clear();
			pendingProgressStatesByJob.clear();
			progressCoalescer.cancel();
			progressStateCoalescer.cancel();
			return;
		}
		pendingProgressByJob.delete(jobId);
		pendingProgressStatesByJob.delete(jobId);
		if (pendingProgressByJob.size === 0) progressCoalescer.cancel();
		if (pendingProgressStatesByJob.size === 0) progressStateCoalescer.cancel();
	}
	function handleStatus() {
		if (api.clientId) {
			clientId.value = api.clientId;
			api.removeEventListener("status", handleStatus);
		}
	}
	/**
	* Queue and history polling supply a workflow id but no path, so the open
	* workflow carrying that root graph provides it. Two open workflows can share
	* a root graph id — an imported copy of one already on screen — and those runs
	* belong to different error buckets, so an ambiguous match resolves to
	* nothing rather than the wrong workflow.
	*/
	function openWorkflowPathForGraph(graphId) {
		const matches = workflowStore.openWorkflows.filter((w) => (w.activeState?.id ?? w.initialState?.id) === graphId);
		return matches.length === 1 ? matches[0].path : void 0;
	}
	/**
	* Run-error key of the workflow that produced `jobId`, for filing its errors
	* against that workflow rather than whichever one is currently on screen.
	*
	* `jobIdToWorkflow` only covers jobs queued by this browser session and is
	* purged the moment a run ends, so `jobIdToWorkflowId` — also populated from
	* queue and history polling — backs it up for jobs from a previous page load.
	*
	* `null` means the job cannot be attributed to one known workflow, so
	* recording is suppressed rather than assigning it to whichever workflow is
	* currently visible.
	*/
	function runErrorKeyForJob(jobId) {
		const workflow = jobIdToWorkflow.get(jobId);
		const graphId = workflow?.activeState?.id ?? workflow?.initialState?.id ?? jobIdToWorkflowId.value.get(jobId);
		if (graphId === void 0) return null;
		const path = workflow?.path ?? jobIdToSessionWorkflowPath.value.get(jobId) ?? openWorkflowPathForGraph(graphId);
		if (path === void 0) return null;
		return executionErrorStore.runErrorKey(graphId, path);
	}
	function handleExecutionError(e) {
		const endTime = performance.now();
		const runErrorKey = runErrorKeyForJob(e.detail.prompt_id);
		if (runErrorKey === null) {
			bufferPendingExecutionError({
				detail: e.detail,
				endTime
			});
			resetExecutionState(e.detail.prompt_id);
			return;
		}
		processExecutionError(e.detail, runErrorKey, endTime);
	}
	function processExecutionError(detail, runErrorKey, endTime) {
		setWorkflowStatus(detail.prompt_id, {
			status: "failed",
			endTime,
			failureReason: "execution_failed",
			showStatus: false
		});
		useTelemetry()?.trackExecutionError({
			jobId: detail.prompt_id,
			nodeId: String(detail.node_id),
			nodeType: detail.node_type,
			error: detail.exception_message
		});
		if (handleAccountPreconditionError(detail)) return;
		if (handleServiceLevelError(detail, runErrorKey)) {
			executionErrorStore.showExecutionError(detail, runErrorKey);
			return;
		}
		setWorkflowStatus(detail.prompt_id, {
			status: "failed",
			endTime,
			failureReason: "execution_failed"
		});
		executionErrorStore.recordExecutionError(detail, runErrorKey);
		executionErrorStore.showExecutionError(detail, runErrorKey);
		clearInitializationByJobId(detail.prompt_id);
		resetExecutionState(detail.prompt_id);
	}
	function handleAccountPreconditionError(detail) {
		if (!resolveAccountPrecondition({
			exceptionType: detail.exception_type,
			exceptionMessage: detail.exception_message
		})) return false;
		const workflow = jobIdToWorkflow.get(detail.prompt_id);
		if (workflow) clearWorkflowStatus(workflow);
		clearInitializationByJobId(detail.prompt_id);
		resetExecutionState(detail.prompt_id);
		return true;
	}
	function handleServiceLevelError(detail, runErrorKey) {
		const { node_id: nodeId } = detail;
		if (nodeId !== null && nodeId !== void 0 && String(nodeId) !== "") return false;
		clearInitializationByJobId(detail.prompt_id);
		resetExecutionState(detail.prompt_id);
		executionErrorStore.recordPromptError({
			type: detail.exception_type || "error",
			message: detail.exception_type ? `${detail.exception_type}: ${detail.exception_message}` : detail.exception_message || "",
			details: detail.traceback?.join("\n") ?? ""
		}, runErrorKey);
		return true;
	}
	/**
	* Notification handler used for frontend/cloud initialization tracking.
	* Marks a job as initializing when cloud notifies it is waiting for a machine.
	*/
	function handleNotification(e) {
		const payload = e.detail;
		const text = payload.value || "";
		const id = payload.id ? payload.id : "";
		if (!id) return;
		if (text.includes("Waiting for a machine")) {
			const next = new Set(initializingJobIds.value);
			next.add(id);
			initializingJobIds.value = next;
		}
	}
	function clearInitializationByJobId(jobId) {
		if (!jobId) return;
		if (!initializingJobIds.value.has(jobId)) return;
		const next = new Set(initializingJobIds.value);
		next.delete(jobId);
		initializingJobIds.value = next;
	}
	function clearInitializationByJobIds(jobIds) {
		if (!jobIds.length) return;
		const current = initializingJobIds.value;
		const toRemove = jobIds.filter((id) => current.has(id));
		if (!toRemove.length) return;
		const next = new Set(current);
		for (const id of toRemove) next.delete(id);
		initializingJobIds.value = next;
	}
	function reconcileInitializingJobs(activeJobIds) {
		clearInitializationByJobIds([...initializingJobIds.value].filter((id) => !activeJobIds.has(id)));
	}
	/**
	* Clears the active job if the server's queue snapshot doesn't list it.
	* Used after WS reconnect to recover from stale state when a job finished
	* during the disconnect window.
	*/
	function clearActiveJobIfStale(activeJobIds) {
		const id = activeJobId.value;
		if (id && !activeJobIds.has(id)) resetExecutionState(id);
	}
	/** Stops following queued jobs that ended without a terminal frame. */
	function forgetFinishedJobs(jobIds) {
		for (const jobId of jobIds) {
			if (jobId === activeJobId.value || !(jobId in queuedJobs.value)) continue;
			forgetJob(jobId);
		}
	}
	function forgetJob(jobId) {
		const progress = { ...nodeProgressStatesByJob.value };
		delete progress[jobId];
		nodeProgressStatesByJob.value = progress;
		useJobPreviewStore().clearPreview(jobId);
		jobIdToWorkflow.delete(jobId);
		if (jobId in queuedJobs.value) jobReset.trigger(queuedJobs.value[jobId]);
		delete queuedJobs.value[jobId];
		cancelPendingProgressUpdates(jobId);
	}
	function isJobInitializing(jobId) {
		if (!jobId) return false;
		return initializingJobIds.value.has(String(jobId));
	}
	/**
	* Reset execution-related state after a run completes or is stopped.
	*/
	function resetExecutionState(jobIdParam) {
		const jobId = jobIdParam ?? activeJobId.value ?? null;
		const runErrorKey = jobId ? runErrorKeyForJob(jobId) : void 0;
		if (jobId) forgetJob(jobId);
		else cancelPendingProgressUpdates();
		if (!activeJobId.value || jobId === activeJobId.value) {
			executionIdToLocatorCache.clear();
			nodeProgressStates.value = {};
			activeJobId.value = null;
			_executingNodeProgress.value = null;
		}
		executionErrorStore.clearPromptError(runErrorKey);
	}
	function storeJob({ nodes, id, promptOutput, startTime, submissionAcceptedAt, workflow, mode, workflowContext, workflowExecutionIntent = defaultWorkflowExecutionIntent }) {
		queuedJobs.value[id] ??= { nodes: {} };
		const queuedJob = queuedJobs.value[id];
		queuedJob.nodes = {
			...nodes.reduce((p, n) => {
				p[n] = false;
				return p;
			}, {}),
			...queuedJob.nodes
		};
		queuedJob.nodeLookup = buildExecutionNodeLookup(promptOutput);
		queuedJob.startTime = startTime;
		queuedJob.submissionAcceptedAt = submissionAcceptedAt;
		queuedJob.workflowContext = workflowContext;
		queuedJob.workflowExecutionIntent = workflowExecutionIntent;
		queuedJob.shareId = workflow.shareId;
		queuedJob.viewMode = mode;
		queuedJob.isAppMode = isAppModeValue(mode);
		registerJobOwner(id, workflow);
	}
	/** Routes a job's frames and outputs to `workflow`, including jobs queued elsewhere. */
	function registerJobOwner(id, workflow) {
		queuedJobs.value[id] ??= { nodes: {} };
		const queuedJob = queuedJobs.value[id];
		queuedJob.workflow = workflow;
		jobIdToWorkflow.set(id, workflow);
		const wid = workflow.activeState?.id ?? workflow.initialState?.id;
		if (wid) jobIdToWorkflowId.value.set(id, wid);
		if (workflow.path) ensureSessionWorkflowPath(id, workflow.path, workflow.instanceId);
		flushPendingWorkflowStatus(id, workflow);
		flushPendingExecutionError(id);
		if (queuedJob.executionStartedAt !== void 0) adoptActiveWorkflowJob();
	}
	function flushPendingExecutionError(jobId) {
		const pending = pendingExecutionErrorsByJobId.get(jobId);
		if (!pending) return;
		const runErrorKey = runErrorKeyForJob(jobId);
		if (runErrorKey === null) return;
		pendingExecutionErrorsByJobId.delete(jobId);
		processExecutionError(pending.detail, runErrorKey, pending.endTime);
	}
	function flushPendingWorkflowStatus(jobId, workflow) {
		const pending = pendingWorkflowStatusByJobId.get(jobId);
		if (pending === void 0 || !workflow) return;
		pendingWorkflowStatusByJobId.delete(jobId);
		queuedJobs.value[jobId].executionStartedAt = pending.executionStartedAt;
		if (pending.status === "running" && workflowStatus.value.has(workflow)) return;
		if (pending.showStatus !== false) applyWorkflowStatus(workflow, pending.status);
		trackExecutionOutcome(jobId, pending);
		if (pending.status === "running" || activeJobId.value === jobId) return;
		delete queuedJobs.value[jobId];
		jobIdToWorkflow.delete(jobId);
	}
	const MAX_SESSION_PATH_ENTRIES = 4e3;
	function ensureSessionWorkflowPath(jobId, path, workflowInstanceId) {
		if (workflowInstanceId) jobIdToWorkflowInstanceId.set(jobId, workflowInstanceId);
		if (jobIdToSessionWorkflowPath.value.get(jobId) === path) return;
		const next = new Map(jobIdToSessionWorkflowPath.value);
		next.set(jobId, path);
		while (next.size > MAX_SESSION_PATH_ENTRIES) {
			const oldest = next.keys().next().value;
			if (oldest !== void 0) {
				next.delete(oldest);
				jobIdToWorkflowInstanceId.delete(oldest);
			} else break;
		}
		jobIdToSessionWorkflowPath.value = next;
	}
	function rewriteSessionWorkflowPaths(workflowInstanceId, newPath) {
		let next;
		for (const [jobId, path] of jobIdToSessionWorkflowPath.value) {
			if (path === newPath) continue;
			if (jobIdToWorkflowInstanceId.get(jobId) !== workflowInstanceId) continue;
			next ??= new Map(jobIdToSessionWorkflowPath.value);
			next.set(jobId, newPath);
		}
		if (next) jobIdToSessionWorkflowPath.value = next;
	}
	workflowStore.onWorkflowRenamed((workflow) => rewriteSessionWorkflowPaths(workflow.instanceId, workflow.path));
	/**
	* Register or update a mapping from job ID to workflow ID.
	*/
	function registerJobWorkflowIdMapping(jobId, workflowId) {
		if (!jobId || !workflowId) return;
		jobIdToWorkflowId.value.set(jobId, workflowId);
		flushPendingExecutionError(jobId);
	}
	/**
	* Convert a NodeLocatorId to an execution context ID
	* @param locatorId The NodeLocatorId
	* @returns The execution ID or null if conversion fails
	*/
	const nodeLocatorIdToExecutionId = (locatorId) => {
		return workflowStore.nodeLocatorIdToNodeExecutionId(locatorId);
	};
	const runningJobIds = computed(() => {
		const result = [];
		for (const [pid, nodes] of Object.entries(nodeProgressStatesByJob.value)) if (Object.values(nodes).some((n) => n.state === "running")) result.push(pid);
		return result;
	});
	const runningWorkflowCount = computed(() => runningJobIds.value.length);
	function adoptActiveWorkflowJob() {
		const ownedJobId = Object.keys(queuedJobs.value).filter((jobId) => queuedJobs.value[jobId].executionStartedAt !== void 0).findLast(belongsToActiveWorkflow);
		executionIdToLocatorCache.clear();
		if (!ownedJobId) {
			nodeProgressStates.value = {};
			return;
		}
		activeJobId.value = ownedJobId;
		nodeProgressStates.value = nodeProgressStatesByJob.value[ownedJobId] ?? {};
		if (_executingNodeProgress.value?.prompt_id !== ownedJobId) _executingNodeProgress.value = null;
	}
	watch(() => workflowStore.activeWorkflow, adoptActiveWorkflowJob);
	return {
		isIdle,
		clientId,
		activeJobId,
		queuedJobs,
		executingNodeId,
		executingNodeIds,
		activeJob,
		totalNodesToExecute,
		nodesExecuted,
		executionProgress,
		executingNode,
		executingNodeProgress,
		nodeProgressStates,
		nodeLocationProgressStates,
		nodeProgressStatesByJob,
		runningJobIds,
		runningWorkflowCount,
		initializingJobIds,
		belongsToActiveWorkflow,
		isActiveWorkflowRunning: computed(() => {
			if (!activeJobId.value) return false;
			const path = workflowStore.activeWorkflow?.path;
			if (!path) return false;
			return jobIdToSessionWorkflowPath.value.get(activeJobId.value) === path;
		}),
		isJobInitializing,
		clearInitializationByJobId,
		clearInitializationByJobIds,
		reconcileInitializingJobs,
		clearActiveJobIfStale,
		forgetFinishedJobs,
		bindExecutionEvents,
		unbindExecutionEvents,
		onJobReset: jobReset.on,
		storeJob,
		registerJobOwner,
		registerJobWorkflowIdMapping,
		uniqueExecutingNodeIdStrings,
		_executingNodeProgress,
		nodeLocatorIdToExecutionId,
		jobIdToWorkflowId,
		jobIdToSessionWorkflowPath,
		ensureSessionWorkflowPath,
		getWorkflowStatus,
		clearWorkflowStatus
	};
});
//#endregion
export { resolveAccountPrecondition as a, useJobPreviewStore as i, useExecutionStore as n, createRafBatch as r, WORKFLOW_STATUS_I18N_KEYS as t };
