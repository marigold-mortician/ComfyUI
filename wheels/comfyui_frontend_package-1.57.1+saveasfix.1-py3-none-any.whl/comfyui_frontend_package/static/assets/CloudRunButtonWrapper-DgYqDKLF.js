import "./rolldown-runtime-xtsTai4I.js";
import { t as useBillingContext } from "./useBillingContext-uo5ceiak.js";
import { G as defineComponent, I as createBlock, P as computed, Wt as unref, ct as openBlock } from "./vendor-vue-core-CuN1excl.js";
import { ar as useEventListener } from "./vendor-reka-ui-NRTk7aIV.js";
import { t as ComfyQueueButton_default } from "./ComfyQueueButton-ae5V2jgh.js";
import { d as isSalesManagedTier } from "./tierPricing-Dm5JzLf8.js";
import { t as useBillingCapabilities } from "./useBillingCapabilities-x1h7nBmq.js";
import { t as SubscribeToRun_default } from "./SubscribeToRun-r53CXfib.js";
import { n as usePaymentRecoveryDialog } from "./usePaymentRecoveryDialog-CK1xdYr3.js";
//#endregion
//#region src/components/actionbar/ComfyRunButton/CloudRunButtonWrapper.vue
var CloudRunButtonWrapper_default = /* @__PURE__ */ defineComponent({
	__name: "CloudRunButtonWrapper",
	setup(__props) {
		const { showsSubscribeToRunPrompt, subscription, fetchStatus, fetchBalance } = useBillingContext();
		const { canRunWorkflows } = useBillingCapabilities();
		const { paymentRecoveryLock, refreshCapabilities, showPaymentRecoveryDialog } = usePaymentRecoveryDialog();
		const isSalesManagedPlan = computed(() => isSalesManagedTier(subscription.value?.tier));
		let billingRefreshRequest = null;
		let refreshBillingOnFocus = false;
		function refreshOnReturn() {
			refreshBillingOnFocus = true;
		}
		function refreshStaleBillingState() {
			if (billingRefreshRequest || !refreshBillingOnFocus && (!showsSubscribeToRunPrompt.value || paymentRecoveryLock.value)) return;
			refreshBillingOnFocus = false;
			billingRefreshRequest = Promise.allSettled([
				fetchStatus(),
				fetchBalance(),
				refreshCapabilities()
			]).then(() => void 0);
			billingRefreshRequest.finally(() => {
				billingRefreshRequest = null;
			});
		}
		useEventListener(window, "focus", refreshStaleBillingState);
		useEventListener(document, "visibilitychange", () => {
			if (document.visibilityState === "visible") refreshStaleBillingState();
		});
		return (_ctx, _cache) => {
			return unref(canRunWorkflows) ? (openBlock(), createBlock(ComfyQueueButton_default, {
				key: 0,
				"payment-recovery-lock": null,
				onPaymentRecoveryClick: _cache[0] || (_cache[0] = ($event) => unref(showPaymentRecoveryDialog)(refreshOnReturn))
			})) : !unref(showsSubscribeToRunPrompt) || unref(paymentRecoveryLock) || isSalesManagedPlan.value ? (openBlock(), createBlock(ComfyQueueButton_default, {
				key: 1,
				"payment-recovery-lock": unref(paymentRecoveryLock),
				onPaymentRecoveryClick: _cache[1] || (_cache[1] = ($event) => unref(showPaymentRecoveryDialog)(refreshOnReturn))
			}, null, 8, ["payment-recovery-lock"])) : (openBlock(), createBlock(SubscribeToRun_default, { key: 2 }));
		};
	}
});
//#endregion
export { CloudRunButtonWrapper_default as default };
