import "./rolldown-runtime-xtsTai4I.js";
import { cn as stripGraphPrefix, ln as useWidgetValueStore, vn as widgetId } from "./litegraph-DsPnoImk.js";
import { y as resolveNode } from "./litegraphUtil-8EMdlR16.js";
import { t as useNodeOutputStore } from "./nodeOutputStore-Dec5oA1b.js";
import { i as api } from "./api-BdJmXw98.js";
import { $ as mergeModels, E as withModifiers, F as createBaseVNode, G as defineComponent, I as createBlock, Kt as normalizeClass, L as createCommentVNode, P as computed, R as createElementBlock, U as createVNode, Wt as unref, _t as useModel, ct as openBlock, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { n as useWorkflowStore } from "./workflowStore-ChkUx7Si.js";
import { t as useToast } from "./toastStore-Dg65fRgL.js";
import { t as useCopyToClipboard } from "./useCopyToClipboard-DUbSOtYA.js";
import { n as useCanvasStore } from "./canvasStore-siYzI5aT.js";
import { n as downloadFile } from "./downloadUtil-PDRccee-.js";
import { t as renderMarkdownToHtml } from "./markdownRendererUtil-BJj2U6Nd.js";
import { t as Textarea_default } from "./Textarea-Cj9Mt-4W.js";
import { t as WidgetInputBaseClass } from "./layout-Bxs_E5v0.js";
import { t as SanitizedHtml_default } from "./SanitizedHtml-kTDIrh6X.js";
//#region src/renderer/extensions/vueNodes/widgets/components/WidgetTextPreview.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "widget-text-preview group relative w-full" };
var _hoisted_2 = { class: "invisible absolute top-1.5 right-1.5 z-10 flex gap-1 group-focus-within:visible group-hover:visible" };
var MODE_WIDGET_NAME = "preview_mode";
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/components/WidgetTextPreview.vue
var WidgetTextPreview_default = /* @__PURE__ */ defineComponent({
	__name: "WidgetTextPreview",
	props: /*@__PURE__*/ mergeModels({
		widget: {},
		nodeId: {}
	}, {
		"modelValue": { default: "" },
		"modelModifiers": {}
	}),
	emits: ["update:modelValue"],
	setup(__props) {
		const modelValue = useModel(__props, "modelValue");
		const { t } = useI18n();
		const { copyToClipboard } = useCopyToClipboard();
		const canvasStore = useCanvasStore();
		const widgetValueStore = useWidgetValueStore();
		const nodeOutputStore = useNodeOutputStore();
		const { nodeToNodeLocatorId } = useWorkflowStore();
		const localNodeId = computed(() => __props.nodeId === void 0 ? null : stripGraphPrefix(__props.nodeId));
		const showMarkdown = computed(() => {
			const graphId = canvasStore.canvas?.graph?.rootGraph.id;
			if (!graphId || localNodeId.value === null) return false;
			return widgetValueStore.getWidget(widgetId(graphId, localNodeId.value, MODE_WIDGET_NAME))?.value === true;
		});
		const renderedMarkdown = computed(() => showMarkdown.value ? renderMarkdownToHtml(modelValue.value || "") : "");
		const savedFile = computed(() => {
			if (__props.nodeId === void 0) return void 0;
			const node = resolveNode(__props.nodeId);
			if (!node) return void 0;
			return nodeOutputStore.nodeOutputs[nodeToNodeLocatorId(node)]?.files?.[0];
		});
		const downloadUrl = computed(() => {
			const file = savedFile.value;
			if (!file?.filename) return void 0;
			const params = new URLSearchParams({
				filename: file.filename,
				subfolder: file.subfolder ?? "",
				type: file.type ?? "output"
			});
			return api.apiURL(`/view?${params}`);
		});
		function handleCopy() {
			copyToClipboard(modelValue.value);
		}
		function handleDownload() {
			if (!downloadUrl.value) return;
			try {
				downloadFile(downloadUrl.value, savedFile.value?.filename);
			} catch {
				useToast().error(t("g.error"), { description: t("g.failedToDownloadFile") });
			}
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1, [createBaseVNode("div", _hoisted_2, [createVNode(Button_default, {
				variant: "textonly",
				size: "icon",
				class: "hover:bg-foreground/10",
				title: _ctx.$t("g.copyToClipboard"),
				"aria-label": _ctx.$t("g.copyToClipboard"),
				onClick: handleCopy,
				onPointerdownCapture: _cache[0] || (_cache[0] = withModifiers(() => {}, ["stop"]))
			}, {
				default: withCtx(() => [..._cache[5] || (_cache[5] = [createBaseVNode("i", { class: "icon-[lucide--copy] size-4 text-foreground" }, null, -1)])]),
				_: 1
			}, 8, ["title", "aria-label"]), downloadUrl.value ? (openBlock(), createBlock(Button_default, {
				key: 0,
				variant: "textonly",
				size: "icon",
				class: "hover:bg-foreground/10",
				title: _ctx.$t("g.download"),
				"aria-label": _ctx.$t("g.download"),
				onClick: handleDownload,
				onPointerdownCapture: _cache[1] || (_cache[1] = withModifiers(() => {}, ["stop"]))
			}, {
				default: withCtx(() => [..._cache[6] || (_cache[6] = [createBaseVNode("i", { class: "icon-[lucide--download] size-4 text-foreground" }, null, -1)])]),
				_: 1
			}, 8, ["title", "aria-label"])) : createCommentVNode("", true)]), showMarkdown.value ? (openBlock(), createBlock(SanitizedHtml_default, {
				key: 0,
				class: "comfy-markdown-content size-full min-h-[60px] overflow-y-auto rounded-lg text-sm",
				"data-capture-wheel": "true",
				role: "textarea",
				"aria-label": __props.widget.name,
				"aria-readonly": "true",
				html: renderedMarkdown.value
			}, null, 8, ["aria-label", "html"])) : (openBlock(), createBlock(Textarea_default, {
				key: 1,
				"model-value": modelValue.value,
				readonly: "",
				"aria-label": __props.widget.name,
				class: normalizeClass(unref(cn)(unref(WidgetInputBaseClass), "size-full resize-none font-mono text-(length:--comfy-textarea-font-size) leading-normal", "overflow-y-auto")),
				"data-capture-wheel": "true",
				onPointerdownCapture: _cache[2] || (_cache[2] = withModifiers(() => {}, ["stop"])),
				onPointermoveCapture: _cache[3] || (_cache[3] = withModifiers(() => {}, ["stop"])),
				onPointerupCapture: _cache[4] || (_cache[4] = withModifiers(() => {}, ["stop"]))
			}, null, 8, [
				"model-value",
				"aria-label",
				"class"
			]))]);
		};
	}
});
//#endregion
export { WidgetTextPreview_default as t };
