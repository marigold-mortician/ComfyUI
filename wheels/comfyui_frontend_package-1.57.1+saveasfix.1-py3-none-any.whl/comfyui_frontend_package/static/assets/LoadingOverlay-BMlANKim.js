import "./rolldown-runtime-xtsTai4I.js";
import { F as createBaseVNode, G as defineComponent, I as createBlock, Kt as normalizeClass, L as createCommentVNode, P as computed, R as createElementBlock, Wt as unref, Yt as toDisplayString, ct as openBlock, dt as renderSlot, h as Transition, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { t as cn } from "./src-BHQtMnZc.js";
//#region src/components/common/LoadingOverlay.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = {
	key: 0,
	class: "absolute inset-0 z-50 flex items-center justify-center bg-background/50",
	"data-testid": "loading-overlay"
};
var _hoisted_2 = { class: "flex flex-col items-center" };
var _hoisted_3 = { class: "grid place-items-center" };
var _hoisted_4 = { class: "col-start-1 row-start-1" };
var _hoisted_5 = {
	key: 0,
	class: "mt-4 text-lg text-foreground"
};
//#endregion
//#region src/components/common/LoadingOverlay.vue
var LoadingOverlay_default = /* @__PURE__ */ defineComponent({
	__name: "LoadingOverlay",
	props: {
		loading: { type: Boolean },
		loadingMessage: {},
		size: { default: "md" }
	},
	setup(__props) {
		const spinnerSizeClass = computed(() => {
			switch (__props.size) {
				case "sm": return "h-6 w-6 border-2";
				default: return "h-12 w-12 border-4";
			}
		});
		return (_ctx, _cache) => {
			return openBlock(), createBlock(Transition, { name: "fade" }, {
				default: withCtx(() => [__props.loading ? (openBlock(), createElementBlock("div", _hoisted_1, [createBaseVNode("div", _hoisted_2, [createBaseVNode("div", _hoisted_3, [createBaseVNode("div", { class: normalizeClass(unref(cn)("col-start-1 row-start-1 animate-spin rounded-full border-muted-foreground border-t-foreground", spinnerSizeClass.value)) }, null, 2), createBaseVNode("div", _hoisted_4, [renderSlot(_ctx.$slots, "default")])]), __props.loadingMessage ? (openBlock(), createElementBlock("div", _hoisted_5, toDisplayString(__props.loadingMessage), 1)) : createCommentVNode("", true)])])) : createCommentVNode("", true)]),
				_: 3
			});
		};
	}
});
//#endregion
export { LoadingOverlay_default as t };
