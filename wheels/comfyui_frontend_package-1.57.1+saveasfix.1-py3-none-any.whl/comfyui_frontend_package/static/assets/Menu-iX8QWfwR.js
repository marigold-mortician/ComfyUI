import "./rolldown-runtime-xtsTai4I.js";
import { $ as mergeModels, At as isRef, B as createSlots, F as createBaseVNode, G as defineComponent, H as createTextVNode, Ht as toValue, I as createBlock, Jt as normalizeStyle, Kt as normalizeClass, L as createCommentVNode, O as Fragment, P as computed, R as createElementBlock, U as createVNode, Wt as unref, Yt as toDisplayString, _t as useModel, ct as openBlock, dt as renderSlot, et as mergeProps, ft as resolveComponent, pt as resolveDynamicComponent, q as guardReactiveProps, qt as normalizeProps, rt as onBeforeUnmount, ut as renderList, wt as withCtx, z as createPropsRestProxy } from "./vendor-vue-core-CuN1excl.js";
import { Ct as DropdownMenuRoot_default, Mn as useForwardPropsEmits, Nn as useForwardProps, St as DropdownMenuContent_default, Vn as createReusableTemplate, _t as DropdownMenuRadioGroup_default, ar as useEventListener, dt as DropdownMenuTrigger_default, ft as DropdownMenuSubTrigger_default, gt as DropdownMenuRadioItem_default, ht as DropdownMenuSeparator_default, mt as DropdownMenuSub_default, pt as DropdownMenuSubContent_default, vt as DropdownMenuPortal_default, wt as DropdownMenuCheckboxItem_default, xt as DropdownMenuItem_default, yt as DropdownMenuLabel_default } from "./vendor-reka-ui-NRTk7aIV.js";
import { n as TextTooltip_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { n as menuContentClass, r as menuItemClass } from "./menuStyles-BC25qUwO.js";
import { t as Badge_default } from "./Badge-BUm0jxSy.js";
import { t as Switch_default } from "./Switch-CDfqeaPZ.js";
//#endregion
//#region src/components/ui/menu/MenuContent.vue
var MenuContent_default = /* @__PURE__ */ defineComponent({
	__name: "MenuContent",
	props: {
		forceMount: { type: Boolean },
		loop: { type: Boolean },
		memoDependencies: {},
		side: {},
		sideOffset: {},
		sideFlip: { type: Boolean },
		align: {},
		alignOffset: {},
		alignFlip: { type: Boolean },
		avoidCollisions: { type: Boolean },
		collisionBoundary: {},
		collisionPadding: {},
		arrowPadding: {},
		hideShiftedArrow: { type: Boolean },
		sticky: {},
		hideWhenDetached: { type: Boolean },
		positionStrategy: {},
		updatePositionStrategy: {},
		disableUpdateOnLayoutShift: { type: Boolean },
		prioritizePosition: { type: Boolean },
		reference: {},
		asChild: { type: Boolean },
		as: {},
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] },
		width: { default: "default" },
		maxHeight: { default: "available" }
	},
	emits: [
		"escapeKeyDown",
		"pointerDownOutside",
		"focusOutside",
		"interactOutside",
		"openAutoFocus",
		"closeAutoFocus"
	],
	setup(__props, { emit: __emit }) {
		const restProps = createPropsRestProxy(__props, [
			"class",
			"width",
			"maxHeight"
		]);
		const forwarded = useForwardPropsEmits(restProps, __emit);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(DropdownMenuContent_default), mergeProps(unref(forwarded), { class: unref(cn)(unref(menuContentClass), __props.width === "trigger" && "w-(--reka-dropdown-menu-trigger-width) min-w-0 overflow-hidden", __props.width === "compact" && "w-max min-w-46.5", __props.maxHeight === "available" && "max-h-(--reka-dropdown-menu-content-available-height)", __props.maxHeight === "compact" && "max-h-64", __props.maxHeight === "viewport" && "max-h-[min(40vh,var(--reka-dropdown-menu-content-available-height))]", __props.class) }), {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
				_: 3
			}, 16, ["class"]);
		};
	}
});
//#endregion
//#region src/utils/mouseDownUtil.ts
var whileMouseDown = (elementOrEvent, callback, interval = 30) => {
	const element = elementOrEvent instanceof HTMLElement ? elementOrEvent : elementOrEvent.target;
	let iteration = 0;
	const intervalId = setInterval(() => {
		callback(iteration++);
	}, interval);
	const dispose = () => {
		clearInterval(intervalId);
		disposeGlobal();
		disposeLocal();
	};
	const disposeGlobal = useEventListener(document, "mouseup", dispose);
	const disposeLocal = useEventListener(element, "mouseup", dispose);
	return { dispose };
};
//#endregion
//#region src/components/ui/menu/MenuAction.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$2 = {
	key: 0,
	"aria-disabled": "true"
};
//#endregion
//#region src/components/ui/menu/MenuAction.vue
var MenuAction_default = /* @__PURE__ */ defineComponent({
	__name: "MenuAction",
	props: {
		allowCommandless: {
			type: Boolean,
			default: false
		},
		item: {}
	},
	emits: ["select", "activate"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const [DefineItem, ReuseItem] = createReusableTemplate();
		const disabled = computed(() => toValue(__props.item.disabled) === true);
		const focusableDisabled = computed(() => disabled.value && __props.item.focusableWhenDisabled === true);
		const unfocusable = computed(() => disabled.value ? !__props.item.focusableWhenDisabled : !__props.item.command && !__props.allowCommandless);
		let pointerRepeating = false;
		let stopRepeating;
		onBeforeUnmount(() => stopRepeating?.());
		function mouseDown(event) {
			if (event.button !== 0 || toValue(__props.item.disabled) || !__props.item.command || __props.item.pressAndHoldInterval === void 0) return;
			stopRepeating?.();
			pointerRepeating = false;
			const { dispose } = whileMouseDown(event, () => {
				const firstRepeat = !pointerRepeating;
				pointerRepeating = true;
				__props.item.command?.({
					originalEvent: event,
					item: __props.item
				});
				if (firstRepeat) emit("activate", __props.item);
			}, __props.item.pressAndHoldInterval);
			stopRepeating = dispose;
		}
		function select(event) {
			if (disabled.value || !__props.item.command) {
				event.preventDefault();
				return;
			}
			if (pointerRepeating) {
				pointerRepeating = false;
				event.preventDefault();
				return;
			}
			if (__props.item.checked !== void 0) event.preventDefault();
			__props.item.command({
				originalEvent: event,
				item: __props.item
			});
			emit("activate", __props.item);
			if (event.defaultPrevented) return;
			if (__props.item.pressAndHoldInterval !== void 0) {
				event.preventDefault();
				return;
			}
			emit("select");
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock(Fragment, null, [createVNode(unref(DefineItem), null, {
				default: withCtx(() => [(openBlock(), createBlock(resolveDynamicComponent(__props.item.checked === void 0 ? unref(DropdownMenuItem_default) : unref(DropdownMenuCheckboxItem_default)), {
					"aria-label": toValue(__props.item.label),
					"aria-description": toValue(__props.item.description),
					disabled: unfocusable.value,
					"as-child": focusableDisabled.value,
					class: normalizeClass(unref(cn)(unref(menuItemClass), __props.item.variant === "destructive" && "text-destructive", focusableDisabled.value && "opacity-50", toValue(__props.item.class))),
					"model-value": toValue(__props.item.checked),
					onMousedown: mouseDown,
					onKeydownCapture: _cache[0] || (_cache[0] = ($event) => isRef(pointerRepeating) ? pointerRepeating.value = false : pointerRepeating = false),
					onSelect: select
				}, {
					default: withCtx(() => [focusableDisabled.value ? (openBlock(), createElementBlock("div", _hoisted_1$2, [renderSlot(_ctx.$slots, "default")])) : renderSlot(_ctx.$slots, "default", {}, void 0, void 0, 1)]),
					_: 3
				}, 40, [
					"aria-label",
					"aria-description",
					"disabled",
					"as-child",
					"class",
					"model-value"
				]))]),
				_: 3
			}), __props.item.tooltip ? (openBlock(), createBlock(TextTooltip_default, {
				key: 0,
				text: __props.item.tooltip,
				side: "right"
			}, {
				default: withCtx(() => [createVNode(unref(ReuseItem))]),
				_: 1
			}, 8, ["text"])) : (openBlock(), createBlock(unref(ReuseItem), { key: 1 }))], 64);
		};
	}
});
//#endregion
//#region src/components/common/OverlayIcon.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$1 = { class: "relative inline-flex size-[1em] items-center justify-center" };
//#endregion
//#region src/components/common/OverlayIcon.vue
var OverlayIcon_default = /* @__PURE__ */ defineComponent({
	__name: "OverlayIcon",
	props: {
		mainIcon: {},
		subIcon: {},
		positionX: { default: "right" },
		positionY: { default: "bottom" },
		offsetX: { default: 0 },
		offsetY: { default: 0 },
		subIconScale: { default: .6 }
	},
	setup(__props) {
		const textShadow = [
			`-1px -1px 0 rgba(0, 0, 0, 0.7)`,
			`1px -1px 0 rgba(0, 0, 0, 0.7)`,
			`-1px 1px 0 rgba(0, 0, 0, 0.7)`,
			`1px 1px 0 rgba(0, 0, 0, 0.7)`,
			`-1px 0 0 rgba(0, 0, 0, 0.7)`,
			`1px 0 0 rgba(0, 0, 0, 0.7)`,
			`0 -1px 0 rgba(0, 0, 0, 0.7)`,
			`0 1px 0 rgba(0, 0, 0, 0.7)`
		].join(", ");
		const subIconStyle = computed(() => ({
			fontSize: `${__props.subIconScale}em`,
			textShadow,
			...__props.offsetX !== 0 && { [__props.positionX === "left" ? "left" : "right"]: `${__props.offsetX}px` },
			...__props.offsetY !== 0 && { [__props.positionY === "top" ? "top" : "bottom"]: `${__props.offsetY}px` }
		}));
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("span", _hoisted_1$1, [createBaseVNode("i", { class: normalizeClass([__props.mainIcon, "text-[1em]"]) }, null, 2), createBaseVNode("i", {
				class: normalizeClass(unref(cn)(__props.subIcon, "pointer-events-none absolute leading-none", __props.positionX === "left" ? "left-0" : "right-0", __props.positionY === "top" ? "top-0" : "bottom-0")),
				style: normalizeStyle(subIconStyle.value)
			}, null, 6)]);
		};
	}
});
//#endregion
//#region src/components/ui/menu/MenuItemContent.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "min-w-0 flex-1" };
var _hoisted_2 = { class: "block truncate" };
var _hoisted_3 = {
	key: 0,
	class: "block max-w-64 text-xs whitespace-normal text-muted-foreground"
};
var _hoisted_4 = {
	key: 4,
	"data-testid": "menu-item-submenu-indicator",
	class: "ml-auto icon-[lucide--chevron-right] size-4"
};
var _hoisted_5 = {
	key: 7,
	class: "ml-auto rounded-sm border bg-secondary p-1 text-xs text-nowrap text-muted-foreground"
};
//#endregion
//#region src/components/ui/menu/MenuItemContent.vue
var MenuItemContent_default = /* @__PURE__ */ defineComponent({
	__name: "MenuItemContent",
	props: {
		hasSubmenu: { type: Boolean },
		item: {}
	},
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock(Fragment, null, [
				__props.item.overlayIcon ? (openBlock(), createBlock(OverlayIcon_default, normalizeProps(mergeProps({ key: 0 }, __props.item.overlayIcon)), null, 16)) : __props.item.icon ? (openBlock(), createElementBlock("i", {
					key: 1,
					class: normalizeClass(unref(cn)(__props.item.icon, "size-4 shrink-0"))
				}, null, 2)) : createCommentVNode("", true),
				createBaseVNode("span", _hoisted_1, [createBaseVNode("span", _hoisted_2, toDisplayString(toValue(__props.item.label)), 1), __props.item.description ? (openBlock(), createElementBlock("span", _hoisted_3, toDisplayString(toValue(__props.item.description)), 1)) : createCommentVNode("", true)]),
				__props.item.trailingIcon ? (openBlock(), createElementBlock("i", {
					key: 2,
					class: normalizeClass(unref(cn)(__props.item.trailingIcon, "ml-auto size-4"))
				}, null, 2)) : createCommentVNode("", true),
				__props.item.badge ? (openBlock(), createBlock(Badge_default, {
					key: 3,
					variant: "pill",
					severity: "default",
					class: "ml-3 px-1.5 uppercase"
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(__props.item.badge), 1)]),
					_: 1
				})) : createCommentVNode("", true),
				__props.hasSubmenu ? (openBlock(), createElementBlock("i", _hoisted_4)) : __props.item.presentation === "switch" ? (openBlock(), createBlock(Switch_default, {
					key: 5,
					"model-value": toValue(__props.item.checked),
					class: "pointer-events-none ml-4",
					"aria-hidden": "true",
					readonly: "",
					tabindex: "-1"
				}, null, 8, ["model-value"])) : __props.item.checked !== void 0 ? (openBlock(), createElementBlock("i", {
					key: 6,
					"data-testid": "menu-item-indicator",
					class: normalizeClass(unref(cn)("ml-auto icon-[lucide--check] size-4", !toValue(__props.item.checked) && "invisible"))
				}, null, 2)) : createCommentVNode("", true),
				!__props.hasSubmenu && toValue(__props.item.shortcut) ? (openBlock(), createElementBlock("span", _hoisted_5, toDisplayString(toValue(__props.item.shortcut)), 1)) : createCommentVNode("", true)
			], 64);
		};
	}
});
//#endregion
//#region src/components/ui/menu/MenuSeparator.vue
var MenuSeparator_default = /* @__PURE__ */ defineComponent({
	__name: "MenuSeparator",
	props: {
		asChild: { type: Boolean },
		as: {},
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	},
	setup(__props) {
		const restProps = createPropsRestProxy(__props, ["class"]);
		const forwarded = useForwardProps(restProps);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(DropdownMenuSeparator_default), mergeProps(unref(forwarded), { class: unref(cn)("my-1 h-px bg-border/50", __props.class) }), null, 16, ["class"]);
		};
	}
});
//#endregion
//#region src/components/ui/menu/MenuRadioItem.vue
var MenuRadioItem_default = /* @__PURE__ */ defineComponent({
	__name: "MenuRadioItem",
	props: {
		value: {},
		disabled: { type: Boolean },
		textValue: {},
		asChild: { type: Boolean },
		as: {},
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	},
	emits: ["select"],
	setup(__props, { emit: __emit }) {
		const restProps = createPropsRestProxy(__props, ["class"]);
		const forwarded = useForwardPropsEmits(restProps, __emit);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(DropdownMenuRadioItem_default), mergeProps(unref(forwarded), { class: unref(cn)(unref(menuItemClass), "w-full", __props.class) }), {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
				_: 3
			}, 16, ["class"]);
		};
	}
});
//#endregion
//#region src/components/ui/menu/MenuRadioGroup.vue
var MenuRadioGroup_default = /* @__PURE__ */ defineComponent({
	__name: "MenuRadioGroup",
	props: /*@__PURE__*/ mergeModels({ options: {} }, {
		"modelValue": { required: true },
		"modelModifiers": {}
	}),
	emits: /*@__PURE__*/ mergeModels(["select"], ["update:modelValue"]),
	setup(__props, { emit: __emit }) {
		const selected = useModel(__props, "modelValue");
		const emit = __emit;
		const [DefineItem, ReuseItem] = createReusableTemplate({ props: { option: {
			type: Object,
			required: true
		} } });
		function select(option, event) {
			selected.value = option.value;
			option.command?.();
			emit("select", event);
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock(Fragment, null, [createVNode(unref(DefineItem), null, {
				default: withCtx(({ option }) => [createVNode(MenuRadioItem_default, {
					value: option.value,
					onSelect: ($event) => select(option, $event)
				}, {
					default: withCtx(() => [createVNode(MenuItemContent_default, {
						item: {
							label: option.label,
							icon: option.icon,
							checked: selected.value === option.value
						},
						"has-submenu": false
					}, null, 8, ["item"])]),
					_: 2
				}, 1032, ["value", "onSelect"])]),
				_: 1
			}), createVNode(unref(DropdownMenuRadioGroup_default), { "model-value": selected.value }, {
				default: withCtx(() => [(openBlock(true), createElementBlock(Fragment, null, renderList(__props.options, (option) => {
					return openBlock(), createElementBlock(Fragment, { key: option.value }, [option.tooltip ? (openBlock(), createBlock(TextTooltip_default, {
						key: 0,
						text: option.tooltip,
						side: "right"
					}, {
						default: withCtx(() => [createVNode(unref(ReuseItem), { option }, null, 8, ["option"])]),
						_: 2
					}, 1032, ["text"])) : (openBlock(), createBlock(unref(ReuseItem), {
						key: 1,
						option
					}, null, 8, ["option"]))], 64);
				}), 128))]),
				_: 1
			}, 8, ["model-value"])], 64);
		};
	}
});
//#endregion
//#region src/components/ui/menu/MenuSubContent.vue
var MenuSubContent_default = /* @__PURE__ */ defineComponent({
	__name: "MenuSubContent",
	props: {
		forceMount: { type: Boolean },
		loop: { type: Boolean },
		memoDependencies: {},
		sideOffset: {},
		sideFlip: { type: Boolean },
		alignOffset: {},
		alignFlip: { type: Boolean },
		avoidCollisions: { type: Boolean },
		collisionBoundary: {},
		collisionPadding: {},
		arrowPadding: {},
		hideShiftedArrow: { type: Boolean },
		sticky: {},
		hideWhenDetached: { type: Boolean },
		positionStrategy: {},
		updatePositionStrategy: {},
		disableUpdateOnLayoutShift: { type: Boolean },
		prioritizePosition: { type: Boolean },
		reference: {},
		asChild: { type: Boolean },
		as: {},
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] },
		width: { default: "default" },
		maxHeight: { default: "available" }
	},
	emits: [
		"escapeKeyDown",
		"pointerDownOutside",
		"focusOutside",
		"interactOutside",
		"entryFocus",
		"openAutoFocus",
		"closeAutoFocus"
	],
	setup(__props, { emit: __emit }) {
		const restProps = createPropsRestProxy(__props, [
			"class",
			"width",
			"maxHeight"
		]);
		const forwarded = useForwardPropsEmits(restProps, __emit);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(DropdownMenuSubContent_default), mergeProps(unref(forwarded), { class: unref(cn)(unref(menuContentClass), __props.width === "compact" && "min-w-46.5", __props.maxHeight === "available" && "max-h-(--reka-dropdown-menu-content-available-height)", __props.maxHeight === "compact" && "max-h-64", __props.class) }), {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
				_: 3
			}, 16, ["class"]);
		};
	}
});
//#endregion
//#region src/components/ui/menu/MenuSubTrigger.vue
var MenuSubTrigger_default = /* @__PURE__ */ defineComponent({
	__name: "MenuSubTrigger",
	props: {
		graceDuration: {},
		disabled: { type: Boolean },
		textValue: {},
		asChild: { type: Boolean },
		as: {},
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	},
	setup(__props) {
		const restProps = createPropsRestProxy(__props, ["class"]);
		const forwarded = useForwardProps(restProps);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(DropdownMenuSubTrigger_default), mergeProps(unref(forwarded), { class: unref(cn)(unref(menuItemClass), __props.class) }), {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
				_: 3
			}, 16, ["class"]);
		};
	}
});
//#endregion
//#region src/components/ui/menu/MenuSubmenu.vue
var MenuSubmenu_default = /* @__PURE__ */ defineComponent({
	__name: "MenuSubmenu",
	props: { item: {} },
	setup(__props) {
		const disabled = computed(() => toValue(__props.item.disabled) || (__props.item.items ?? __props.item.radioGroup.options).length === 0);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(DropdownMenuSub_default), null, {
				default: withCtx(({ open }) => [createVNode(MenuSubTrigger_default, {
					"aria-label": toValue(__props.item.label),
					disabled: disabled.value,
					class: normalizeClass(toValue(__props.item.class))
				}, {
					default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
					_: 3
				}, 8, [
					"aria-label",
					"disabled",
					"class"
				]), (openBlock(), createBlock(unref(DropdownMenuPortal_default), { key: Number(open) }, {
					default: withCtx(() => [createVNode(MenuSubContent_default, {
						"side-offset": 2,
						"align-offset": -5
					}, {
						default: withCtx(() => [__props.item.items ? renderSlot(_ctx.$slots, "content", { items: __props.item.items }, void 0, void 0, 0) : (openBlock(), createBlock(MenuRadioGroup_default, {
							key: 1,
							"model-value": toValue(__props.item.radioGroup.value),
							options: __props.item.radioGroup.options
						}, null, 8, ["model-value", "options"]))]),
						_: 3
					})]),
					_: 3
				}))]),
				_: 3
			});
		};
	}
});
//#endregion
//#region src/components/ui/menu/MenuItems.vue
var MenuItems_default = /* @__PURE__ */ defineComponent({
	name: "MenuItems",
	__name: "MenuItems",
	props: {
		items: {},
		itemContent: { type: Function }
	},
	emits: ["select", "activate"],
	setup(__props, { emit: __emit }) {
		const [DefineItemContent, ReuseItemContent] = createReusableTemplate();
		const emit = __emit;
		const visibleItems = computed(() => __props.items.filter((item) => toValue(item.visible) !== false));
		return (_ctx, _cache) => {
			const _component_MenuItems = resolveComponent("MenuItems", true);
			return openBlock(), createElementBlock(Fragment, null, [createVNode(unref(DefineItemContent), null, {
				default: withCtx(({ item, hasSubmenu }) => [__props.itemContent ? (openBlock(), createBlock(resolveDynamicComponent(__props.itemContent), normalizeProps(mergeProps({ key: 0 }, {
					item,
					hasSubmenu
				})), null, 16)) : renderSlot(_ctx.$slots, "item", {
					item,
					hasSubmenu
				}, () => [createVNode(MenuItemContent_default, {
					item,
					"has-submenu": hasSubmenu
				}, null, 8, ["item", "has-submenu"])], void 0, 1)]),
				_: 3
			}), (openBlock(true), createElementBlock(Fragment, null, renderList(visibleItems.value, (item, index) => {
				return openBlock(), createElementBlock(Fragment, { key: item.key ?? toValue(item.label) ?? index }, [item.separator ? (openBlock(), createBlock(MenuSeparator_default, { key: 0 })) : item.items || item.radioGroup ? (openBlock(), createBlock(MenuSubmenu_default, {
					key: 1,
					item
				}, {
					content: withCtx(({ items: childItems }) => [createVNode(_component_MenuItems, {
						items: childItems,
						"item-content": __props.itemContent ?? _ctx.$slots.item,
						onSelect: _cache[0] || (_cache[0] = ($event) => emit("select")),
						onActivate: _cache[1] || (_cache[1] = ($event) => emit("activate", $event))
					}, null, 8, ["items", "item-content"])]),
					default: withCtx(() => [createVNode(unref(ReuseItemContent), {
						item,
						"has-submenu": true
					}, null, 8, ["item"])]),
					_: 2
				}, 1032, ["item"])) : (openBlock(), createBlock(MenuAction_default, {
					key: 2,
					item,
					"allow-commandless": Boolean(__props.itemContent ?? _ctx.$slots.item),
					onSelect: _cache[2] || (_cache[2] = ($event) => emit("select")),
					onActivate: _cache[3] || (_cache[3] = ($event) => emit("activate", $event))
				}, {
					default: withCtx(() => [createVNode(unref(ReuseItemContent), {
						item,
						"has-submenu": false
					}, null, 8, ["item"])]),
					_: 2
				}, 1032, ["item", "allow-commandless"]))], 64);
			}), 128))], 64);
		};
	}
});
//#endregion
//#region src/components/ui/menu/Menu.vue
var Menu_default = /* @__PURE__ */ defineComponent({
	inheritAttrs: false,
	__name: "Menu",
	props: /*@__PURE__*/ mergeModels({
		items: { default: () => [] },
		label: {},
		modal: {
			type: Boolean,
			default: true
		},
		to: {},
		align: { default: "start" },
		collisionPadding: {},
		side: {},
		sideOffset: { default: 2 }
	}, {
		"open": {
			type: Boolean,
			default: false
		},
		"openModifiers": {}
	}),
	emits: /*@__PURE__*/ mergeModels(["activate"], ["update:open"]),
	setup(__props, { emit: __emit }) {
		const open = useModel(__props, "open");
		const emit = __emit;
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(DropdownMenuRoot_default), {
				open: open.value,
				"onUpdate:open": _cache[2] || (_cache[2] = ($event) => open.value = $event),
				modal: __props.modal
			}, {
				default: withCtx(() => [createVNode(unref(DropdownMenuTrigger_default), { "as-child": "" }, {
					default: withCtx(() => [renderSlot(_ctx.$slots, "trigger", { open: open.value })]),
					_: 3
				}), (openBlock(), createBlock(unref(DropdownMenuPortal_default), {
					key: Number(open.value),
					to: __props.to
				}, {
					default: withCtx(() => [createVNode(MenuContent_default, mergeProps({
						align: __props.align,
						"collision-padding": __props.collisionPadding,
						side: __props.side,
						"side-offset": __props.sideOffset
					}, _ctx.$attrs, { class: _ctx.$attrs.class }), {
						default: withCtx(() => [__props.label ? (openBlock(), createBlock(unref(DropdownMenuLabel_default), {
							key: 0,
							class: "px-3 py-1.5 text-xs font-semibold text-muted-foreground"
						}, {
							default: withCtx(() => [createTextVNode(toDisplayString(__props.label), 1)]),
							_: 1
						})) : createCommentVNode("", true), renderSlot(_ctx.$slots, "default", {}, () => [createVNode(MenuItems_default, {
							items: __props.items,
							onSelect: _cache[0] || (_cache[0] = ($event) => open.value = false),
							onActivate: _cache[1] || (_cache[1] = ($event) => emit("activate", $event))
						}, createSlots({ _: 2 }, [_ctx.$slots.item ? {
							name: "item",
							fn: withCtx((slotProps) => [renderSlot(_ctx.$slots, "item", normalizeProps(guardReactiveProps(slotProps)))]),
							key: "0"
						} : void 0]), 1032, ["items"])])]),
						_: 3
					}, 16, [
						"align",
						"collision-padding",
						"side",
						"side-offset",
						"class"
					])]),
					_: 3
				}, 8, ["to"]))]),
				_: 3
			}, 8, ["open", "modal"]);
		};
	}
});
//#endregion
export { MenuRadioGroup_default as a, MenuItemContent_default as c, MenuSubContent_default as i, MenuContent_default as l, MenuItems_default as n, MenuRadioItem_default as o, MenuSubTrigger_default as r, MenuSeparator_default as s, Menu_default as t };
