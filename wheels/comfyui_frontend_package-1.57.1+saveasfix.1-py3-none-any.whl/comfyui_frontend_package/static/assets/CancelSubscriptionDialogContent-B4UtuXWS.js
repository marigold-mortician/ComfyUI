import "./rolldown-runtime-xtsTai4I.js";
import { A as useBillingRouting, t as useBillingContext } from "./useBillingContext-Cc-YANxo.js";
import { F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, I as createBlock, Kt as normalizeClass, L as createCommentVNode, O as Fragment, P as computed, R as createElementBlock, U as createVNode, Wt as unref, Yt as toDisplayString, at as onMounted, bt as watch, ct as openBlock, dt as renderSlot, ot as onUnmounted, ut as renderList, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { Kr as useThrottleFn, Un as defaultWindow, ar as useEventListener } from "./vendor-reka-ui-NRTk7aIV.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { n as useTelemetry } from "./telemetry-IkzvF0TI.js";
import { t as useToast } from "./toastStore-Dg65fRgL.js";
import { t as getErrorMessage } from "./errorUtil-DoQyAUQC.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
import { t as DialogTitle_default } from "./DialogTitle-CWOHHLwH.js";
import { m as toTierKey, s as getTierFeatures } from "./tierPricing-Dm5JzLf8.js";
import { l as categorizeBillingApiError } from "./useAuthActions-CFn_-tF2.js";
import { t as useBillingCapabilities } from "./useBillingCapabilities-x1h7nBmq.js";
import { t as useWorkspaceUI } from "./useWorkspaceUI-CALMkHxF.js";
import { n as toCurrentTier, t as toBillingCycle } from "./billingPlanTelemetry-CgeXQYDa.js";
import { t as getPlanCreditGrant } from "./planCreditGrant-DHIjEmw5.js";
import { t as useWorkspaceTierLabel } from "./useWorkspaceTierLabel-CvZFdEik.js";
import { o as parseIsoDateSafe } from "./dateTimeUtil-Dbo04jgD.js";
//#region src/platform/billing/subscription/components/CancellationStepLayout.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$1 = { class: "relative flex min-h-0 w-[min(32rem,calc(100vw-2rem))] flex-col gap-6 overflow-y-auto rounded-2xl border bg-background p-8" };
var _hoisted_2$1 = { class: "flex flex-col gap-5" };
var _hoisted_3$1 = { class: "flex flex-col gap-2 pr-8" };
var _hoisted_4$1 = {
	key: 0,
	class: "m-0 text-sm text-muted-foreground"
};
var _hoisted_5$1 = { class: "flex flex-wrap items-center justify-end gap-2" };
//#endregion
//#region src/platform/billing/subscription/components/CancellationStepLayout.vue
var CancellationStepLayout_default = /* @__PURE__ */ defineComponent({
	__name: "CancellationStepLayout",
	props: {
		title: {},
		subtitle: {},
		closeDisabled: {
			type: Boolean,
			default: false
		},
		onClose: { type: Function }
	},
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("section", _hoisted_1$1, [
				createVNode(Button_default, {
					variant: "muted-textonly",
					size: "icon",
					class: "absolute top-4 right-4",
					"aria-label": _ctx.$t("g.close"),
					disabled: __props.closeDisabled,
					onClick: __props.onClose
				}, {
					default: withCtx(() => [..._cache[0] || (_cache[0] = [createBaseVNode("i", {
						class: "icon-[lucide--x] size-4",
						"aria-hidden": "true"
					}, null, -1)])]),
					_: 1
				}, 8, [
					"aria-label",
					"disabled",
					"onClick"
				]),
				createBaseVNode("div", _hoisted_2$1, [createBaseVNode("header", _hoisted_3$1, [createVNode(DialogTitle_default, { class: "m-0 flex items-center gap-2 text-2xl" }, {
					default: withCtx(() => [createTextVNode(toDisplayString(__props.title) + " ", 1), renderSlot(_ctx.$slots, "title-icon")]),
					_: 3
				}), __props.subtitle ? (openBlock(), createElementBlock("p", _hoisted_4$1, toDisplayString(__props.subtitle), 1)) : createCommentVNode("", true)]), renderSlot(_ctx.$slots, "default")]),
				createBaseVNode("footer", _hoisted_5$1, [renderSlot(_ctx.$slots, "actions")])
			]);
		};
	}
});
//#endregion
//#region src/platform/billing/subscription/composables/useCancellationPlan.ts
function useCancellationPlan() {
	const { t } = useI18n();
	const { tier, subscription, currentTeamCreditStop } = useBillingContext();
	const { formatTierName } = useWorkspaceTierLabel();
	return {
		planName: computed(() => formatTierName(tier.value, false) || t("subscription.cancelFlow.genericPlanName")),
		creditGrant: computed(() => getPlanCreditGrant({
			tier: tier.value,
			duration: subscription.value?.duration,
			teamMonthlyCredits: currentTeamCreditStop.value?.credits_monthly
		})),
		includesCustomLoRAs: computed(() => {
			const tierKey = tier.value ? toTierKey(tier.value) : null;
			return tierKey ? getTierFeatures(tierKey).customLoRAs : false;
		})
	};
}
//#endregion
//#region src/platform/billing/subscription/utils/subscriptionCancellationTelemetry.ts
function getSubscriptionCancellationMetadata({ cancelAt, duration, endDate, tier }) {
	const effectiveEndDate = cancelAt ?? endDate;
	return {
		source: "cancel_plan_menu",
		current_tier: tier?.toLowerCase(),
		...duration ? { cycle: duration === "ANNUAL" ? "yearly" : "monthly" } : {},
		...effectiveEndDate ? { end_date: effectiveEndDate } : {}
	};
}
/**
* Reports a cancel flow as billing events. Once the customer confirms, the flow
* is no longer abandoned. While a confirmed cancel is expected to become an
* operation, its `billing.operation.*` events also own any failure, so `failed`
* is reported only for a flow that has no operation expected.
*/
function createCancelFlowReporter(telemetry, getPlan, options = {}) {
	let confirmed = options.confirmed ?? false;
	let operationFollows = false;
	const plan = () => {
		const { duration, tier } = getPlan();
		return {
			current_tier: toCurrentTier(tier),
			cycle: toBillingCycle(duration)
		};
	};
	return {
		intent() {
			telemetry?.trackBillingEvent({
				operation: "cancel",
				stage: "intent",
				outcome: "pending",
				...plan()
			});
		},
		confirmed(options) {
			confirmed = true;
			operationFollows = options.operationFollows;
		},
		abandoned() {
			if (confirmed) return;
			telemetry?.trackBillingEvent({
				operation: "cancel",
				stage: "abandoned",
				outcome: "pending",
				...plan()
			});
		},
		failed(failureCategory) {
			if (operationFollows) return;
			telemetry?.trackBillingEvent({
				operation: "cancel",
				stage: "failed",
				outcome: "failure",
				failure_category: failureCategory,
				...plan()
			});
		}
	};
}
//#endregion
//#region src/platform/billing/subscription/components/CancelSubscriptionDialogContent.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = {
	key: 0,
	class: "m-0 text-sm/5 text-muted-foreground",
	role: "status"
};
var _hoisted_2 = { class: "m-0 text-sm/5 text-muted-foreground" };
var _hoisted_3 = { class: "m-0 text-sm/5" };
var _hoisted_4 = { class: "m-0 grid list-none grid-cols-2 gap-2 p-0" };
var _hoisted_5 = { class: "text-sm" };
var _hoisted_6 = { class: "text-xs text-muted-foreground" };
//#endregion
//#region src/platform/billing/subscription/components/CancelSubscriptionDialogContent.vue
var CancelSubscriptionDialogContent_default = /* @__PURE__ */ defineComponent({
	__name: "CancelSubscriptionDialogContent",
	props: {
		cancelAt: {},
		flowAlreadyOpened: {
			type: Boolean,
			default: false
		},
		flowAlreadyConfirmed: {
			type: Boolean,
			default: false
		},
		isScopeCurrent: {
			type: Function,
			default: () => true
		}
	},
	setup(__props) {
		const { t, n } = useI18n();
		const dialogStore = useDialogStore();
		const toast = useToast();
		const { cancelSubscription, fetchStatus, subscription, tier } = useBillingContext();
		const { shouldUseWorkspaceBilling } = useBillingRouting();
		const { canCancel } = useBillingCapabilities();
		const { permissions } = useWorkspaceUI();
		const { planName, creditGrant } = useCancellationPlan();
		const telemetry = useTelemetry();
		const isLoading = ref(false);
		const didCancelSucceed = ref(false);
		const isAwaitingStripe = ref(false);
		let lastCancelled = null;
		let cancelObserved = false;
		const didScopeAbort = ref(false);
		const cancelReport = createCancelFlowReporter(telemetry, () => ({
			duration: subscription.value?.duration,
			tier: tier.value
		}), { confirmed: __props.flowAlreadyConfirmed });
		function cancellationMetadata() {
			return getSubscriptionCancellationMetadata({
				cancelAt: __props.cancelAt,
				duration: subscription.value?.duration,
				endDate: subscription.value?.endDate,
				tier: tier.value
			});
		}
		onMounted(() => {
			if (__props.flowAlreadyOpened) return;
			telemetry?.trackSubscriptionCancellation("flow_opened", cancellationMetadata());
			cancelReport.intent();
		});
		function reportAbandoned() {
			telemetry?.trackSubscriptionCancellation("abandoned", cancellationMetadata());
			cancelReport.abandoned();
		}
		let unmounted = false;
		onUnmounted(() => {
			unmounted = true;
			if (didCancelSucceed.value || didScopeAbort.value || isLoading.value) return;
			reportAbandoned();
		});
		const formattedEndDate = computed(() => {
			const date = parseIsoDateSafe(__props.cancelAt ?? subscription.value?.endDate ?? subscription.value?.renewalDate);
			if (!date) return t("subscription.cancelDialog.endOfBillingPeriod");
			return date.toLocaleDateString("en-US", {
				month: "long",
				day: "numeric",
				year: "numeric"
			});
		});
		const description = computed(() => t("subscription.cancelFlow.confirm.description", {
			plan: planName.value,
			date: formattedEndDate.value
		}));
		function creditsTitle() {
			const grant = creditGrant.value;
			if (!grant) return t("subscription.cancelFlow.confirm.features.credits.generic");
			const named = { credits: n(grant.credits) };
			return grant.cycle === "yearly" ? t("subscription.cancelFlow.confirm.features.credits.yearly", named) : t("subscription.cancelFlow.confirm.features.credits.monthly", named);
		}
		const lostFeatures = computed(() => {
			return [
				{
					key: "gpus",
					icon: "icon-[lucide--cpu]",
					title: t("subscription.cancelFlow.confirm.features.gpus.title"),
					description: t("subscription.cancelFlow.confirm.features.gpus.description")
				},
				{
					key: "models",
					icon: "icon-[lucide--layers]",
					title: t("subscription.cancelFlow.confirm.features.models.title"),
					description: t("subscription.cancelFlow.confirm.features.models.description")
				},
				{
					key: "customNodes",
					icon: "icon-[lucide--blocks]",
					title: t("subscription.cancelFlow.confirm.features.customNodes.title"),
					description: t("subscription.cancelFlow.confirm.features.customNodes.description")
				},
				{
					key: "credits",
					icon: "icon-[lucide--coins]",
					title: creditsTitle(),
					description: t("subscription.cancelFlow.confirm.features.credits.description")
				}
			];
		});
		function completeObservedCancel() {
			if (!cancelObserved || didCancelSucceed.value) return;
			if (!__props.isScopeCurrent()) return abortForScopeChange();
			didCancelSucceed.value = true;
			isAwaitingStripe.value = false;
			telemetry?.trackSubscriptionCancellation("confirmed", cancellationMetadata());
			cancelReport.confirmed({ operationFollows: false });
		}
		watch(() => subscription.value ? !!subscription.value.isCancelled : null, (cancelled) => {
			if (cancelled === null) return;
			if (cancelled && lastCancelled === false) cancelObserved = true;
			if (!cancelled) cancelObserved = false;
			lastCancelled = cancelled;
			if (cancelObserved && isAwaitingStripe.value) completeObservedCancel();
		});
		const refreshOnFocus = useThrottleFn(() => {
			if (isAwaitingStripe.value) fetchStatus().catch(() => {});
		}, 1e4);
		useEventListener(defaultWindow, "focus", () => void refreshOnFocus());
		const isClosingBlocked = computed(() => isLoading.value && !didCancelSucceed.value);
		function onClose() {
			if (isClosingBlocked.value) return;
			dialogStore.closeDialog({ key: "cancel-subscription" });
		}
		function abortForScopeChange() {
			didScopeAbort.value = true;
			toast.warning(t("subscription.cancelDialog.workspaceChanged"));
			dialogStore.closeDialog({ key: "cancel-subscription" });
		}
		function lacksWorkspaceCancelPermission() {
			return shouldUseWorkspaceBilling.value && !permissions.value.canManageSubscriptionLifecycle;
		}
		function reportCancelFailure(error) {
			if (!shouldUseWorkspaceBilling.value) {
				telemetry?.trackSubscriptionCancellation("failed", cancellationMetadata());
				cancelReport.confirmed({ operationFollows: false });
				cancelReport.failed(categorizeBillingApiError(error));
			}
			toast.error(t("subscription.cancelDialog.failed"), { description: getErrorMessage(error) ?? t("g.unknownError") });
			isLoading.value = false;
		}
		function reportWorkspaceConfirmed() {
			telemetry?.trackSubscriptionCancellation("confirmed", cancellationMetadata());
			cancelReport.confirmed({ operationFollows: true });
		}
		function awaitStripeCancel() {
			if (unmounted) return reportAbandoned();
			isAwaitingStripe.value = true;
			isLoading.value = false;
			completeObservedCancel();
		}
		async function finishWorkspaceCancel() {
			didCancelSucceed.value = true;
			try {
				await fetchStatus();
			} catch {}
			isLoading.value = false;
		}
		function handleCancelError(error) {
			if (!__props.isScopeCurrent()) return abortForScopeChange();
			reportCancelFailure(error);
		}
		async function finishCancel(rail, confirmedBeforeCall) {
			if (!__props.isScopeCurrent()) return abortForScopeChange();
			if (rail === "legacy") return awaitStripeCancel();
			if (!confirmedBeforeCall) reportWorkspaceConfirmed();
			await finishWorkspaceCancel();
		}
		async function onConfirmCancel() {
			if (!__props.isScopeCurrent()) return abortForScopeChange();
			if (lacksWorkspaceCancelPermission()) return;
			const confirmedBeforeCall = shouldUseWorkspaceBilling.value;
			if (confirmedBeforeCall) reportWorkspaceConfirmed();
			lastCancelled = subscription.value ? !!subscription.value.isCancelled : null;
			cancelObserved = false;
			isLoading.value = true;
			let rail;
			try {
				rail = await cancelSubscription(__props.isScopeCurrent);
			} catch (error) {
				return handleCancelError(error);
			}
			await finishCancel(rail, confirmedBeforeCall);
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(CancellationStepLayout_default, {
				title: didCancelSucceed.value ? _ctx.$t("subscription.cancelFlow.cancelled.title") : _ctx.$t("subscription.cancelFlow.confirm.title"),
				subtitle: didCancelSucceed.value ? description.value : void 0,
				"close-disabled": isClosingBlocked.value,
				"on-close": onClose
			}, {
				actions: withCtx(() => [didCancelSucceed.value ? (openBlock(), createBlock(Button_default, {
					key: 0,
					variant: "secondary",
					size: "lg",
					class: "w-24",
					onClick: onClose
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("subscription.cancelFlow.done")), 1)]),
					_: 1
				})) : isAwaitingStripe.value ? (openBlock(), createBlock(Button_default, {
					key: 1,
					variant: "secondary",
					size: "lg",
					onClick: onClose
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("g.close")), 1)]),
					_: 1
				})) : (openBlock(), createElementBlock(Fragment, { key: 2 }, [createVNode(Button_default, {
					variant: "textonly",
					size: "lg",
					disabled: isLoading.value,
					onClick: onClose
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("subscription.cancelFlow.keepPlan")), 1)]),
					_: 1
				}, 8, ["disabled"]), createVNode(Button_default, {
					variant: "destructive",
					size: "lg",
					loading: isLoading.value,
					onClick: onConfirmCancel
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("subscription.cancelFlow.confirm.cancelPlan")), 1)]),
					_: 1
				}, 8, ["loading"])], 64))]),
				default: withCtx(() => [isAwaitingStripe.value ? (openBlock(), createElementBlock("p", _hoisted_1, toDisplayString(_ctx.$t("subscription.cancelDialog.finishOnStripe")), 1)) : !didCancelSucceed.value ? (openBlock(), createElementBlock(Fragment, { key: 1 }, [
					createBaseVNode("p", _hoisted_2, toDisplayString(description.value), 1),
					createBaseVNode("p", _hoisted_3, toDisplayString(_ctx.$t("subscription.cancelFlow.confirm.loseAccess", { date: formattedEndDate.value })), 1),
					createBaseVNode("ul", _hoisted_4, [(openBlock(true), createElementBlock(Fragment, null, renderList(lostFeatures.value, (feature) => {
						return openBlock(), createElementBlock("li", {
							key: feature.key,
							class: "flex flex-col gap-1.5 rounded-[10px] border border-border/50 bg-secondary/50 p-3"
						}, [
							createBaseVNode("i", {
								class: normalizeClass(unref(cn)(feature.icon, "size-4 text-foreground")),
								"aria-hidden": "true"
							}, null, 2),
							createBaseVNode("span", _hoisted_5, toDisplayString(feature.title), 1),
							createBaseVNode("span", _hoisted_6, toDisplayString(feature.description), 1)
						]);
					}), 128))])
				], 64)) : createCommentVNode("", true)]),
				_: 1
			}, 8, [
				"title",
				"subtitle",
				"close-disabled"
			]);
		};
	}
});
//#endregion
export { CancellationStepLayout_default as a, useCancellationPlan as i, createCancelFlowReporter as n, getSubscriptionCancellationMetadata as r, CancelSubscriptionDialogContent_default as t };
