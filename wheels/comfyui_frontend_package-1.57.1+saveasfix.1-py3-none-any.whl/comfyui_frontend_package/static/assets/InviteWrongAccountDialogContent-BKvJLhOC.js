import "./rolldown-runtime-xtsTai4I.js";
import { _ as capturePreservedQuery, g as PRESERVED_QUERY_NAMESPACES } from "./teamWorkspaceStore-BNm5cZOK.js";
import { F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, I as createBlock, U as createVNode, Wt as unref, Yt as toDisplayString, ct as openBlock, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
import { r as useAuthStore } from "./authStore-D2cL6XhN.js";
import { t as useAuthActions } from "./useAuthActions-_rhVfmiU.js";
import { t as AppDialogPanel_default } from "./AppDialogPanel-BklaJBTn.js";
//#region src/platform/workspace/components/dialogs/InviteWrongAccountDialogContent.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "m-0 text-sm text-muted-foreground" };
//#endregion
//#region src/platform/workspace/components/dialogs/InviteWrongAccountDialogContent.vue
var InviteWrongAccountDialogContent_default = /* @__PURE__ */ defineComponent({
	__name: "InviteWrongAccountDialogContent",
	props: { inviteToken: {} },
	setup(__props) {
		const authStore = useAuthStore();
		const authActions = useAuthActions();
		const dialogStore = useDialogStore();
		const loading = ref(false);
		function onDismiss() {
			dialogStore.closeDialog({ key: "invite-wrong-account" });
		}
		async function onSwitchAccount() {
			loading.value = true;
			try {
				capturePreservedQuery(PRESERVED_QUERY_NAMESPACES.INVITE, { invite: __props.inviteToken }, ["invite"]);
				await authActions.logout();
			} finally {
				loading.value = false;
			}
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(AppDialogPanel_default, { onClose: onDismiss }, {
				title: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.inviteLinks.wrongAccountTitle")), 1)]),
				footer: withCtx(() => [createVNode(Button_default, {
					variant: "muted-textonly",
					onClick: onDismiss
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.inviteLinks.invalidDismiss")), 1)]),
					_: 1
				}), createVNode(Button_default, {
					variant: "secondary",
					size: "lg",
					loading: loading.value,
					onClick: onSwitchAccount
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.inviteLinks.switchAccount")), 1)]),
					_: 1
				}, 8, ["loading"])]),
				default: withCtx(() => [createBaseVNode("p", _hoisted_1, toDisplayString(unref(authStore).userEmail ? _ctx.$t("workspacePanel.inviteLinks.wrongAccountBody", { email: unref(authStore).userEmail }) : _ctx.$t("workspacePanel.inviteLinks.wrongAccountBodyGeneric")), 1)]),
				_: 1
			});
		};
	}
});
//#endregion
export { InviteWrongAccountDialogContent_default as default };
