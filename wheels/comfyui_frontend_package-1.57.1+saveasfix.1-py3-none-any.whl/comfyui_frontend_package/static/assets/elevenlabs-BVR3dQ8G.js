//#region packages/design-system/src/icons/elevenlabs.svg?raw
var elevenlabs_default = "<svg fill=\"currentColor\" fill-rule=\"evenodd\" height=\"1em\" style=\"line-height:1\" viewBox=\"0 0 24 24\" width=\"1em\" xmlns=\"http://www.w3.org/2000/svg\"><title>ElevenLabs</title><path d=\"M5 0h5v24H5V0zM14 0h5v24h-5V0z\"></path></svg>";
//#endregion
export { elevenlabs_default as default };
