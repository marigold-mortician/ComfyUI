import "./rolldown-runtime-xtsTai4I.js";
import { F as createBaseVNode, G as defineComponent, H as createTextVNode, I as createBlock, U as createVNode, Wt as unref, Yt as toDisplayString, ct as openBlock, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
import { n as SSO_REQUIRED_DIALOG_KEY } from "./ssoRequiredDialogKey-DRv9w9ql.js";
import { t as AppDialogPanel_default } from "./AppDialogPanel-BklaJBTn.js";
import { t as useContinueWithSso } from "./useContinueWithSso-CiwLRs1U.js";
//#region src/platform/auth/sso/SsoRequiredDialogContent.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "m-0 p-4 text-sm text-muted-foreground" };
//#endregion
//#region src/platform/auth/sso/SsoRequiredDialogContent.vue
var SsoRequiredDialogContent_default = /* @__PURE__ */ defineComponent({
	__name: "SsoRequiredDialogContent",
	props: {
		email: {},
		returnTo: {},
		organizationId: {}
	},
	setup(__props) {
		const { t } = useI18n();
		const dialogStore = useDialogStore();
		const { knownEmail, leaving, continueWithSso } = useContinueWithSso(() => ({
			email: __props.email,
			returnTo: __props.returnTo,
			organizationId: __props.organizationId
		}));
		function dismiss() {
			dialogStore.closeDialog({ key: SSO_REQUIRED_DIALOG_KEY });
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(AppDialogPanel_default, {
				unpadded: "",
				onClose: dismiss
			}, {
				title: withCtx(() => [createTextVNode(toDisplayString(unref(t)("auth.sso.required.title")), 1)]),
				footer: withCtx(() => [createVNode(Button_default, {
					variant: "muted-textonly",
					onClick: dismiss
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(unref(t)("auth.sso.required.dismiss")), 1)]),
					_: 1
				}), createVNode(Button_default, {
					variant: "secondary",
					size: "lg",
					autofocus: "",
					loading: unref(leaving),
					onClick: unref(continueWithSso)
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(unref(t)("auth.sso.continueWithSso")), 1)]),
					_: 1
				}, 8, ["loading", "onClick"])]),
				default: withCtx(() => [createBaseVNode("p", _hoisted_1, toDisplayString(unref(knownEmail) ? unref(t)("auth.sso.required.bodyWithEmail", { email: unref(knownEmail) }) : unref(t)("auth.sso.required.body")), 1)]),
				_: 1
			});
		};
	}
});
//#endregion
export { SsoRequiredDialogContent_default as default };
