import "./rolldown-runtime-xtsTai4I.js";
import { $ as LineSegments, A as BufferGeometry, At as SkinnedMesh, Dt as Scene, Et as SRGBColorSpace, F as Color, Ht as Vector2, K as GridHelper, Lt as Texture, Q as LineBasicMaterial, R as DirectionalLight, Rt as TextureLoader, S as AmbientLight, U as Float32BufferAttribute, Ut as Vector3, Wt as Vector4, ft as MeshNormalMaterial, gt as PerspectiveCamera, h as OrbitControls, ht as OrthographicCamera, it as Material, lt as Mesh, n as SparkRenderer, t as ViewHelper, ut as MeshBasicMaterial, vt as PlaneGeometry, wt as Quaternion, zt as Timer } from "./vendor-three-B-UiePqj.js";
import { a as ensureSharedHighPrecisionTarget, i as ensureRendererSize, n as applyRendererViewState, o as resolveHighPrecisionTarget, r as createRendererViewState, s as createHighPrecisionTarget, t as acquireSharedRenderer } from "./sharedWebGLRenderer-BSlxZGp0.js";
import { t as delay } from "./delay-Cu8bS1zn.js";
//#region packages/viewport3d/src/three/RendererView.ts
var RendererView = class {
	renderer;
	canvas;
	state = createRendererViewState();
	width = 1;
	height = 1;
	context;
	handle;
	resizeObserver = null;
	outputTarget = null;
	outputWidth = 1;
	outputHeight = 1;
	constructor(container) {
		this.canvas = document.createElement("canvas");
		this.canvas.classList.add("absolute", "inset-0", "h-full", "w-full", "outline-none");
		const context = this.canvas.getContext("2d");
		if (!context) throw new Error("Failed to create 2D context for 3D view");
		this.context = context;
		this.handle = acquireSharedRenderer();
		this.renderer = this.handle.renderer;
		container.appendChild(this.canvas);
	}
	setSize(width, height) {
		this.width = Math.max(1, Math.round(width));
		this.height = Math.max(1, Math.round(height));
		if (this.canvas.width !== this.width) this.canvas.width = this.width;
		if (this.canvas.height !== this.height) this.canvas.height = this.height;
		ensureRendererSize(this.renderer, this.width, this.height);
	}
	beginRender(highPrecision = false) {
		ensureRendererSize(this.renderer, this.width, this.height);
		applyRendererViewState(this.renderer, this.state);
		this.bindOutput(highPrecision ? ensureSharedHighPrecisionTarget(this.width, this.height) : null, this.width, this.height);
	}
	bindOutput(target, width, height) {
		this.outputTarget = target;
		this.outputWidth = width;
		this.outputHeight = height;
		if (target) target.texture.colorSpace = this.state.outputColorSpace;
		this.renderer.setRenderTarget(target);
		this.setViewport(0, 0, width, height);
		this.setScissor(0, 0, width, height);
		this.setScissorTest(false);
	}
	resolveOutput() {
		if (!this.outputTarget) return;
		resolveHighPrecisionTarget(this.renderer, this.outputTarget, this.outputWidth, this.outputHeight);
		this.outputTarget = null;
	}
	setViewport(x, y, width, height) {
		this.renderer.setViewport(x, y, width, height);
		this.outputTarget?.viewport.set(x, y, width, height);
	}
	getViewport(target) {
		return this.renderer.getViewport(target);
	}
	setScissor(x, y, width, height) {
		this.renderer.setScissor(x, y, width, height);
		this.outputTarget?.scissor.set(x, y, width, height);
	}
	setScissorTest(enabled) {
		this.renderer.setScissorTest(enabled);
		if (this.outputTarget) this.outputTarget.scissorTest = enabled;
	}
	blit() {
		this.resolveOutput();
		const source = this.renderer.domElement;
		this.context.globalCompositeOperation = "copy";
		this.context.drawImage(source, 0, source.height - this.height, this.width, this.height, 0, 0, this.width, this.height);
	}
	observeResize(target, onResize) {
		if (typeof ResizeObserver === "undefined") return;
		this.resizeObserver?.disconnect();
		this.resizeObserver = new ResizeObserver(() => onResize());
		this.resizeObserver.observe(target);
	}
	dispose() {
		this.resizeObserver?.disconnect();
		this.resizeObserver = null;
		this.canvas.remove();
		this.handle.release();
	}
};
//#endregion
//#region packages/viewport3d/src/load3d/CameraManager.ts
function resolveIncomingCustomUp(state) {
	if (state.useCustomUp === void 0) return null;
	const storedUp = state.customUp ? new Vector3(state.customUp.x, state.customUp.y, state.customUp.z) : null;
	if (storedUp && storedUp.lengthSq() > 0) return storedUp;
	if (!state.useCustomUp || !state.quaternion) return null;
	const q = new Quaternion(state.quaternion.x, state.quaternion.y, state.quaternion.z, state.quaternion.w);
	if (q.lengthSq() === 0) q.identity();
	return new Vector3(0, 1, 0).applyQuaternion(q);
}
var CameraManager = class {
	perspectiveCamera;
	orthographicCamera;
	activeCamera;
	eventManager;
	controls = null;
	customUp = null;
	usingCustomUp = false;
	DEFAULT_DISTANCE = 10;
	DEFAULT_LOOK_AT = 0;
	DEFAULT_CAMERA = {
		near: .01,
		far: 1e4
	};
	DEFAULT_PERSPECTIVE_CAMERA = {
		fov: 35,
		aspect: 1
	};
	DEFAULT_FRUSTUM_SIZE = 10;
	DEFAULT_ORTHOGRAPHIC_CAMERA = {
		left: -this.DEFAULT_FRUSTUM_SIZE / 2,
		right: this.DEFAULT_FRUSTUM_SIZE / 2,
		top: this.DEFAULT_FRUSTUM_SIZE / 2,
		bottom: -this.DEFAULT_FRUSTUM_SIZE / 2
	};
	constructor(_renderer, eventManager) {
		this.eventManager = eventManager;
		this.perspectiveCamera = new PerspectiveCamera(this.DEFAULT_PERSPECTIVE_CAMERA.fov, this.DEFAULT_PERSPECTIVE_CAMERA.aspect, this.DEFAULT_CAMERA.near, this.DEFAULT_CAMERA.far);
		this.orthographicCamera = new OrthographicCamera(this.DEFAULT_ORTHOGRAPHIC_CAMERA.left, this.DEFAULT_ORTHOGRAPHIC_CAMERA.right, this.DEFAULT_ORTHOGRAPHIC_CAMERA.top, this.DEFAULT_ORTHOGRAPHIC_CAMERA.bottom, this.DEFAULT_CAMERA.near, this.DEFAULT_CAMERA.far);
		this.reset();
		this.activeCamera = this.perspectiveCamera;
	}
	init() {}
	dispose() {}
	setControls(controls) {
		this.controls = controls;
		controls.addEventListener("end", () => {
			this.eventManager.emitEvent("cameraChanged", this.getCameraState());
		});
	}
	getCurrentCameraType() {
		return this.activeCamera === this.perspectiveCamera ? "perspective" : "orthographic";
	}
	toggleCamera(cameraType) {
		const oldCamera = this.activeCamera;
		const position = oldCamera.position.clone();
		const rotation = oldCamera.rotation.clone();
		const up = oldCamera.up.clone();
		const target = this.controls?.target.clone() || new Vector3();
		const oldZoom = oldCamera instanceof OrthographicCamera ? oldCamera.zoom : oldCamera.zoom;
		if (!cameraType) this.activeCamera = oldCamera === this.perspectiveCamera ? this.orthographicCamera : this.perspectiveCamera;
		else {
			this.activeCamera = cameraType === "perspective" ? this.perspectiveCamera : this.orthographicCamera;
			if (oldCamera === this.activeCamera) return;
		}
		this.activeCamera.position.copy(position);
		this.activeCamera.rotation.copy(rotation);
		this.activeCamera.up.copy(up);
		if (this.activeCamera instanceof OrthographicCamera) {
			this.activeCamera.zoom = oldZoom;
			this.activeCamera.updateProjectionMatrix();
		} else if (this.activeCamera instanceof PerspectiveCamera) {
			this.activeCamera.zoom = oldZoom;
			this.activeCamera.updateProjectionMatrix();
		}
		if (this.controls) {
			this.controls.object = this.activeCamera;
			this.controls.target.copy(target);
			this.controls.update();
		}
		this.eventManager.emitEvent("cameraTypeChange", cameraType);
	}
	setFOV(fov) {
		if (this.activeCamera === this.perspectiveCamera) {
			this.perspectiveCamera.fov = fov;
			this.perspectiveCamera.updateProjectionMatrix();
		}
		this.eventManager.emitEvent("fovChange", fov);
	}
	getCameraState() {
		const { x, y, z, w } = this.activeCamera.quaternion;
		const activeCamera = this.activeCamera;
		return {
			position: this.activeCamera.position.clone(),
			target: this.controls?.target.clone() || new Vector3(),
			zoom: this.activeCamera instanceof OrthographicCamera ? this.activeCamera.zoom : this.activeCamera.zoom,
			cameraType: this.getCurrentCameraType(),
			quaternion: {
				x,
				y,
				z,
				w
			},
			...this.customUp !== null && {
				useCustomUp: this.usingCustomUp,
				customUp: {
					x: this.customUp.x,
					y: this.customUp.y,
					z: this.customUp.z
				}
			},
			fov: this.perspectiveCamera.fov,
			aspect: this.perspectiveCamera.aspect,
			near: activeCamera.near,
			far: activeCamera.far,
			frustum: {
				left: this.orthographicCamera.left,
				right: this.orthographicCamera.right,
				top: this.orthographicCamera.top,
				bottom: this.orthographicCamera.bottom
			}
		};
	}
	setCameraState(state) {
		if (state.cameraType !== this.getCurrentCameraType()) this.toggleCamera(state.cameraType);
		this.activeCamera.position.copy(state.position);
		this.controls?.target.copy(state.target);
		if (state.fov !== void 0 && this.activeCamera instanceof PerspectiveCamera) this.activeCamera.fov = state.fov;
		if (this.activeCamera instanceof OrthographicCamera) {
			this.activeCamera.zoom = state.zoom;
			this.activeCamera.updateProjectionMatrix();
		} else if (this.activeCamera instanceof PerspectiveCamera) {
			this.activeCamera.zoom = state.zoom;
			this.activeCamera.updateProjectionMatrix();
		}
		const incomingUp = resolveIncomingCustomUp(state);
		if (incomingUp) {
			this.customUp = incomingUp;
			this.usingCustomUp = state.useCustomUp === true;
			this.activeCamera.up.copy(this.usingCustomUp ? incomingUp : new Vector3(0, 1, 0));
			this.eventManager.emitEvent("cameraUpStateChange", {
				hasCustomUp: true,
				usingCustomUp: this.usingCustomUp
			});
		} else if (this.customUp !== null) {
			this.customUp = null;
			this.usingCustomUp = false;
			this.activeCamera.up.set(0, 1, 0);
			this.eventManager.emitEvent("cameraUpStateChange", {
				hasCustomUp: false,
				usingCustomUp: false
			});
		}
		this.controls?.update();
	}
	setUseCustomUp(use) {
		if (use && !this.customUp) return;
		if (use === this.usingCustomUp) return;
		const target = use && this.customUp ? this.customUp : new Vector3(0, 1, 0);
		this.activeCamera.up.copy(target);
		this.usingCustomUp = use;
		this.controls?.update();
		this.eventManager.emitEvent("cameraUpStateChange", {
			hasCustomUp: this.customUp !== null,
			usingCustomUp: this.usingCustomUp
		});
	}
	handleResize(width, height) {
		const aspect = width / height;
		this.updateAspectRatio(aspect);
	}
	updateAspectRatio(aspect) {
		if (this.activeCamera === this.perspectiveCamera) {
			this.perspectiveCamera.aspect = aspect;
			this.perspectiveCamera.updateProjectionMatrix();
		} else {
			const frustumSize = 10;
			this.orthographicCamera.left = -10 * aspect / 2;
			this.orthographicCamera.right = frustumSize * aspect / 2;
			this.orthographicCamera.top = frustumSize / 2;
			this.orthographicCamera.bottom = -5;
			this.orthographicCamera.updateProjectionMatrix();
		}
	}
	setupForModel(size, center = new Vector3(0, size.y / 2, 0)) {
		const maxDim = Math.max(size.x, size.y, size.z);
		const distance = Math.max(size.x, size.z) * 2;
		const height = center.y + maxDim;
		this.perspectiveCamera.position.set(center.x + distance, height, center.z + distance);
		this.orthographicCamera.position.set(center.x + distance, height, center.z + distance);
		if (this.activeCamera === this.perspectiveCamera) {
			this.perspectiveCamera.lookAt(center);
			this.perspectiveCamera.updateProjectionMatrix();
		} else {
			const frustumSize = maxDim * 2;
			const aspect = this.perspectiveCamera.aspect;
			this.orthographicCamera.left = -frustumSize * aspect / 2;
			this.orthographicCamera.right = frustumSize * aspect / 2;
			this.orthographicCamera.top = frustumSize / 2;
			this.orthographicCamera.bottom = -frustumSize / 2;
			this.orthographicCamera.lookAt(center);
			this.orthographicCamera.updateProjectionMatrix();
		}
		this.controls?.target.copy(center);
		this.controls?.update();
	}
	reset() {
		this.perspectiveCamera.position.set(this.DEFAULT_DISTANCE, this.DEFAULT_DISTANCE, this.DEFAULT_DISTANCE);
		this.orthographicCamera.position.set(this.DEFAULT_DISTANCE, this.DEFAULT_DISTANCE, this.DEFAULT_DISTANCE);
		this.perspectiveCamera.lookAt(this.DEFAULT_LOOK_AT, this.DEFAULT_LOOK_AT, this.DEFAULT_LOOK_AT);
		this.orthographicCamera.lookAt(this.DEFAULT_LOOK_AT, this.DEFAULT_LOOK_AT, this.DEFAULT_LOOK_AT);
		this.perspectiveCamera.updateProjectionMatrix();
		this.orthographicCamera.updateProjectionMatrix();
	}
};
//#endregion
//#region packages/viewport3d/src/load3d/ControlsManager.ts
var ControlsManager = class {
	controls;
	constructor(interactionElement, camera) {
		this.controls = new OrbitControls(camera, interactionElement);
		this.controls.enableDamping = true;
	}
	init() {}
	dispose() {
		this.controls.dispose();
	}
	handleResize() {}
	update() {
		this.controls.update();
	}
	updateCamera(camera) {
		const position = this.controls.object.position.clone();
		const target = this.controls.target.clone();
		this.controls.object = camera;
		this.controls.target = target;
		camera.position.copy(position);
		this.controls.update();
	}
	detach() {
		this.controls.enabled = false;
	}
	attach() {
		this.controls.enabled = true;
	}
	reset() {
		this.controls.target.set(0, 0, 0);
		this.controls.update();
	}
};
//#endregion
//#region packages/viewport3d/src/load3d/EventManager.ts
var EventManager = class {
	listeners = {};
	addEventListener(event, callback) {
		(this.listeners[event] ??= []).push(callback);
	}
	removeEventListener(event, callback) {
		this.listeners[event] = this.listeners[event]?.filter((cb) => cb !== callback);
	}
	emitEvent(event, data) {
		this.listeners[event]?.forEach((callback) => callback(data));
	}
};
//#endregion
//#region packages/viewport3d/src/load3d/LightingManager.ts
var LightingManager = class {
	lights = [];
	currentIntensity = 3;
	scene;
	eventManager;
	lightMultipliers = /* @__PURE__ */ new Map();
	constructor(scene, eventManager) {
		this.scene = scene;
		this.eventManager = eventManager;
	}
	init() {
		this.setupLights();
	}
	dispose() {
		this.lights.forEach((light) => {
			this.scene.remove(light);
		});
		this.lights = [];
		this.lightMultipliers.clear();
	}
	setupLights() {
		const addLight = (light, multiplier) => {
			this.scene.add(light);
			this.lights.push(light);
			this.lightMultipliers.set(light, multiplier);
		};
		addLight(new AmbientLight(16777215, .5), .5);
		const mainLight = new DirectionalLight(16777215, .8);
		mainLight.position.set(0, 10, 10);
		addLight(mainLight, .8);
		const backLight = new DirectionalLight(16777215, .5);
		backLight.position.set(0, 10, -10);
		addLight(backLight, .5);
		const leftFillLight = new DirectionalLight(16777215, .3);
		leftFillLight.position.set(-10, 0, 0);
		addLight(leftFillLight, .3);
		const rightFillLight = new DirectionalLight(16777215, .3);
		rightFillLight.position.set(10, 0, 0);
		addLight(rightFillLight, .3);
		const bottomLight = new DirectionalLight(16777215, .2);
		bottomLight.position.set(0, -10, 0);
		addLight(bottomLight, .2);
	}
	setLightIntensity(intensity) {
		this.currentIntensity = intensity;
		this.lights.forEach((light) => {
			light.intensity = intensity * (this.lightMultipliers.get(light) ?? 1);
		});
		this.eventManager.emitEvent("lightIntensityChange", intensity);
	}
	setHDRIMode(hdriActive) {
		this.lights.forEach((light) => {
			light.visible = !hdriActive;
		});
	}
	reset() {}
};
//#endregion
//#region node_modules/.pnpm/fflate@0.8.3/node_modules/fflate/esm/browser.js
var u8 = Uint8Array;
var u16 = Uint16Array;
var i32 = Int32Array;
var fleb = new u8([
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	1,
	1,
	1,
	1,
	2,
	2,
	2,
	2,
	3,
	3,
	3,
	3,
	4,
	4,
	4,
	4,
	5,
	5,
	5,
	5,
	0,
	0,
	0,
	0
]);
var fdeb = new u8([
	0,
	0,
	0,
	0,
	1,
	1,
	2,
	2,
	3,
	3,
	4,
	4,
	5,
	5,
	6,
	6,
	7,
	7,
	8,
	8,
	9,
	9,
	10,
	10,
	11,
	11,
	12,
	12,
	13,
	13,
	0,
	0
]);
var clim = new u8([
	16,
	17,
	18,
	0,
	8,
	7,
	9,
	6,
	10,
	5,
	11,
	4,
	12,
	3,
	13,
	2,
	14,
	1,
	15
]);
var freb = function(eb, start) {
	var b = new u16(31);
	for (var i = 0; i < 31; ++i) b[i] = start += 1 << eb[i - 1];
	var r = new i32(b[30]);
	for (var i = 1; i < 30; ++i) for (var j = b[i]; j < b[i + 1]; ++j) r[j] = j - b[i] << 5 | i;
	return {
		b,
		r
	};
};
var _a = freb(fleb, 2);
var fl = _a.b;
var revfl = _a.r;
fl[28] = 258, revfl[258] = 28;
var _b = freb(fdeb, 0);
var fd = _b.b;
var revfd = _b.r;
var rev = new u16(32768);
for (var i = 0; i < 32768; ++i) {
	var x = (i & 43690) >> 1 | (i & 21845) << 1;
	x = (x & 52428) >> 2 | (x & 13107) << 2;
	x = (x & 61680) >> 4 | (x & 3855) << 4;
	rev[i] = ((x & 65280) >> 8 | (x & 255) << 8) >> 1;
}
var hMap = (function(cd, mb, r) {
	var s = cd.length;
	var i = 0;
	var l = new u16(mb);
	for (; i < s; ++i) if (cd[i]) ++l[cd[i] - 1];
	var le = new u16(mb);
	for (i = 1; i < mb; ++i) le[i] = le[i - 1] + l[i - 1] << 1;
	var co;
	if (r) {
		co = new u16(1 << mb);
		var rvb = 15 - mb;
		for (i = 0; i < s; ++i) if (cd[i]) {
			var sv = i << 4 | cd[i];
			var r_1 = mb - cd[i];
			var v = le[cd[i] - 1]++ << r_1;
			for (var m = v | (1 << r_1) - 1; v <= m; ++v) co[rev[v] >> rvb] = sv;
		}
	} else {
		co = new u16(s);
		for (i = 0; i < s; ++i) if (cd[i]) co[i] = rev[le[cd[i] - 1]++] >> 15 - cd[i];
	}
	return co;
});
var flt = new u8(288);
for (var i = 0; i < 144; ++i) flt[i] = 8;
for (var i = 144; i < 256; ++i) flt[i] = 9;
for (var i = 256; i < 280; ++i) flt[i] = 7;
for (var i = 280; i < 288; ++i) flt[i] = 8;
var fdt = new u8(32);
for (var i = 0; i < 32; ++i) fdt[i] = 5;
var flm = /*#__PURE__*/ hMap(flt, 9, 0);
var flrm = /*#__PURE__*/ hMap(flt, 9, 1);
var fdm = /*#__PURE__*/ hMap(fdt, 5, 0);
var fdrm = /*#__PURE__*/ hMap(fdt, 5, 1);
var max = function(a) {
	var m = a[0];
	for (var i = 1; i < a.length; ++i) if (a[i] > m) m = a[i];
	return m;
};
var bits = function(d, p, m) {
	var o = p / 8 | 0;
	return (d[o] | d[o + 1] << 8) >> (p & 7) & m;
};
var bits16 = function(d, p) {
	var o = p / 8 | 0;
	return (d[o] | d[o + 1] << 8 | d[o + 2] << 16) >> (p & 7);
};
var shft = function(p) {
	return (p + 7) / 8 | 0;
};
var slc = function(v, s, e) {
	if (s == null || s < 0) s = 0;
	if (e == null || e > v.length) e = v.length;
	return new u8(v.subarray(s, e));
};
var ec = [
	"unexpected EOF",
	"invalid block type",
	"invalid length/literal",
	"invalid distance",
	"stream finished",
	"no stream handler",
	,
	"no callback",
	"invalid UTF-8 data",
	"extra field too long",
	"date not in range 1980-2099",
	"filename too long",
	"stream finishing",
	"invalid zip data"
];
var err = function(ind, msg, nt) {
	var e = new Error(msg || ec[ind]);
	e.code = ind;
	if (Error.captureStackTrace) Error.captureStackTrace(e, err);
	if (!nt) throw e;
	return e;
};
var inflt = function(dat, st, buf, dict) {
	var sl = dat.length;
	var dl = dict ? dict.length : 0;
	if (!sl || st.f && !st.l) return buf || new u8(0);
	var noBuf = !buf;
	var resize = noBuf || st.i != 2;
	var noSt = st.i;
	if (noBuf) buf = new u8(sl * 3);
	var cbuf = function(l) {
		var bl = buf.length;
		if (l > bl) {
			var nbuf = new u8(Math.max(bl * 2, l));
			nbuf.set(buf);
			buf = nbuf;
		}
	};
	var final = st.f || 0;
	var pos = st.p || 0;
	var bt = st.b || 0;
	var lm = st.l;
	var dm = st.d;
	var lbt = st.m;
	var dbt = st.n;
	var tbts = sl * 8;
	do {
		if (!lm) {
			final = bits(dat, pos, 1);
			var type = bits(dat, pos + 1, 3);
			pos += 3;
			if (!type) {
				var s = shft(pos) + 4;
				var l = dat[s - 4] | dat[s - 3] << 8;
				var t = s + l;
				if (t > sl) {
					if (noSt) err(0);
					break;
				}
				if (resize) cbuf(bt + l);
				buf.set(dat.subarray(s, t), bt);
				st.b = bt += l, st.p = pos = t * 8, st.f = final;
				continue;
			} else if (type == 1) lm = flrm, dm = fdrm, lbt = 9, dbt = 5;
			else if (type == 2) {
				var hLit = bits(dat, pos, 31) + 257;
				var hcLen = bits(dat, pos + 10, 15) + 4;
				var tl = hLit + bits(dat, pos + 5, 31) + 1;
				pos += 14;
				var ldt = new u8(tl);
				var clt = new u8(19);
				for (var i = 0; i < hcLen; ++i) clt[clim[i]] = bits(dat, pos + i * 3, 7);
				pos += hcLen * 3;
				var clb = max(clt);
				var clbmsk = (1 << clb) - 1;
				var clm = hMap(clt, clb, 1);
				for (var i = 0; i < tl;) {
					var r = clm[bits(dat, pos, clbmsk)];
					pos += r & 15;
					var s = r >> 4;
					if (s < 16) ldt[i++] = s;
					else {
						var c = 0;
						var n = 0;
						if (s == 16) n = 3 + bits(dat, pos, 3), pos += 2, c = ldt[i - 1];
						else if (s == 17) n = 3 + bits(dat, pos, 7), pos += 3;
						else if (s == 18) n = 11 + bits(dat, pos, 127), pos += 7;
						while (n--) ldt[i++] = c;
					}
				}
				var lt = ldt.subarray(0, hLit);
				var dt = ldt.subarray(hLit);
				lbt = max(lt);
				dbt = max(dt);
				lm = hMap(lt, lbt, 1);
				dm = hMap(dt, dbt, 1);
			} else err(1);
			if (pos > tbts) {
				if (noSt) err(0);
				break;
			}
		}
		if (resize) cbuf(bt + 131072);
		var lms = (1 << lbt) - 1;
		var dms = (1 << dbt) - 1;
		var lpos = pos;
		for (;; lpos = pos) {
			var c = lm[bits16(dat, pos) & lms];
			var sym = c >> 4;
			pos += c & 15;
			if (pos > tbts) {
				if (noSt) err(0);
				break;
			}
			if (!c) err(2);
			if (sym < 256) buf[bt++] = sym;
			else if (sym == 256) {
				lpos = pos, lm = null;
				break;
			} else {
				var add = sym - 254;
				if (sym > 264) {
					var i = sym - 257;
					var b = fleb[i];
					add = bits(dat, pos, (1 << b) - 1) + fl[i];
					pos += b;
				}
				var d = dm[bits16(dat, pos) & dms];
				var dsym = d >> 4;
				if (!d) err(3);
				pos += d & 15;
				var dt = fd[dsym];
				if (dsym > 3) {
					var b = fdeb[dsym];
					dt += bits16(dat, pos) & (1 << b) - 1, pos += b;
				}
				if (pos > tbts) {
					if (noSt) err(0);
					break;
				}
				if (resize) cbuf(bt + 131072);
				var end = bt + add;
				if (bt < dt) {
					var shift = dl - dt;
					var dend = Math.min(dt, end);
					if (shift + bt < 0) err(3);
					for (; bt < dend; ++bt) buf[bt] = dict[shift + bt];
				}
				for (; bt < end; ++bt) buf[bt] = buf[bt - dt];
			}
		}
		st.l = lm, st.p = lpos, st.b = bt, st.f = final;
		if (lm) final = 1, st.m = lbt, st.d = dm, st.n = dbt;
	} while (!final);
	return bt != buf.length && noBuf ? slc(buf, 0, bt) : buf.subarray(0, bt);
};
var wbits = function(d, p, v) {
	v <<= p & 7;
	var o = p / 8 | 0;
	d[o] |= v;
	d[o + 1] |= v >> 8;
};
var wbits16 = function(d, p, v) {
	v <<= p & 7;
	var o = p / 8 | 0;
	d[o] |= v;
	d[o + 1] |= v >> 8;
	d[o + 2] |= v >> 16;
};
var hTree = function(d, mb) {
	var t = [];
	for (var i = 0; i < d.length; ++i) if (d[i]) t.push({
		s: i,
		f: d[i]
	});
	var s = t.length;
	var t2 = t.slice();
	if (!s) return {
		t: et,
		l: 0
	};
	if (s == 1) {
		var v = new u8(t[0].s + 1);
		v[t[0].s] = 1;
		return {
			t: v,
			l: 1
		};
	}
	t.sort(function(a, b) {
		return a.f - b.f;
	});
	t.push({
		s: -1,
		f: 25001
	});
	var l = t[0];
	var r = t[1];
	var i0 = 0;
	var i1 = 1;
	var i2 = 2;
	t[0] = {
		s: -1,
		f: l.f + r.f,
		l,
		r
	};
	while (i1 != s - 1) {
		l = t[t[i0].f < t[i2].f ? i0++ : i2++];
		r = t[i0 != i1 && t[i0].f < t[i2].f ? i0++ : i2++];
		t[i1++] = {
			s: -1,
			f: l.f + r.f,
			l,
			r
		};
	}
	var maxSym = t2[0].s;
	for (var i = 1; i < s; ++i) if (t2[i].s > maxSym) maxSym = t2[i].s;
	var tr = new u16(maxSym + 1);
	var mbt = ln(t[i1 - 1], tr, 0);
	if (mbt > mb) {
		var i = 0;
		var dt = 0;
		var lft = mbt - mb;
		var cst = 1 << lft;
		t2.sort(function(a, b) {
			return tr[b.s] - tr[a.s] || a.f - b.f;
		});
		for (; i < s; ++i) {
			var i2_1 = t2[i].s;
			if (tr[i2_1] > mb) {
				dt += cst - (1 << mbt - tr[i2_1]);
				tr[i2_1] = mb;
			} else break;
		}
		dt >>= lft;
		while (dt > 0) {
			var i2_2 = t2[i].s;
			if (tr[i2_2] < mb) dt -= 1 << mb - tr[i2_2]++ - 1;
			else ++i;
		}
		for (; i >= 0 && dt; --i) {
			var i2_3 = t2[i].s;
			if (tr[i2_3] == mb) {
				--tr[i2_3];
				++dt;
			}
		}
		mbt = mb;
	}
	return {
		t: new u8(tr),
		l: mbt
	};
};
var ln = function(n, l, d) {
	return n.s == -1 ? Math.max(ln(n.l, l, d + 1), ln(n.r, l, d + 1)) : l[n.s] = d;
};
var lc = function(c) {
	var s = c.length;
	while (s && !c[--s]);
	var cl = new u16(++s);
	var cli = 0;
	var cln = c[0];
	var cls = 1;
	var w = function(v) {
		cl[cli++] = v;
	};
	for (var i = 1; i <= s; ++i) if (c[i] == cln && i != s) ++cls;
	else {
		if (!cln && cls > 2) {
			for (; cls > 138; cls -= 138) w(32754);
			if (cls > 2) {
				w(cls > 10 ? cls - 11 << 5 | 28690 : cls - 3 << 5 | 12305);
				cls = 0;
			}
		} else if (cls > 3) {
			w(cln), --cls;
			for (; cls > 6; cls -= 6) w(8304);
			if (cls > 2) w(cls - 3 << 5 | 8208), cls = 0;
		}
		while (cls--) w(cln);
		cls = 1;
		cln = c[i];
	}
	return {
		c: cl.subarray(0, cli),
		n: s
	};
};
var clen = function(cf, cl) {
	var l = 0;
	for (var i = 0; i < cl.length; ++i) l += cf[i] * cl[i];
	return l;
};
var wfblk = function(out, pos, dat) {
	var s = dat.length;
	var o = shft(pos + 2);
	out[o] = s & 255;
	out[o + 1] = s >> 8;
	out[o + 2] = out[o] ^ 255;
	out[o + 3] = out[o + 1] ^ 255;
	for (var i = 0; i < s; ++i) out[o + i + 4] = dat[i];
	return (o + 4 + s) * 8;
};
var wblk = function(dat, out, final, syms, lf, df, eb, li, bs, bl, p) {
	wbits(out, p++, final);
	++lf[256];
	var _a = hTree(lf, 15);
	var dlt = _a.t;
	var mlb = _a.l;
	var _b = hTree(df, 15);
	var ddt = _b.t;
	var mdb = _b.l;
	var _c = lc(dlt);
	var lclt = _c.c;
	var nlc = _c.n;
	var _d = lc(ddt);
	var lcdt = _d.c;
	var ndc = _d.n;
	var lcfreq = new u16(19);
	for (var i = 0; i < lclt.length; ++i) ++lcfreq[lclt[i] & 31];
	for (var i = 0; i < lcdt.length; ++i) ++lcfreq[lcdt[i] & 31];
	var _e = hTree(lcfreq, 7);
	var lct = _e.t;
	var mlcb = _e.l;
	var nlcc = 19;
	for (; nlcc > 4 && !lct[clim[nlcc - 1]]; --nlcc);
	var flen = bl + 5 << 3;
	var ftlen = clen(lf, flt) + clen(df, fdt) + eb;
	var dtlen = clen(lf, dlt) + clen(df, ddt) + eb + 14 + 3 * nlcc + clen(lcfreq, lct) + 2 * lcfreq[16] + 3 * lcfreq[17] + 7 * lcfreq[18];
	if (bs >= 0 && flen <= ftlen && flen <= dtlen) return wfblk(out, p, dat.subarray(bs, bs + bl));
	var lm;
	var ll;
	var dm;
	var dl;
	wbits(out, p, 1 + (dtlen < ftlen)), p += 2;
	if (dtlen < ftlen) {
		lm = hMap(dlt, mlb, 0), ll = dlt, dm = hMap(ddt, mdb, 0), dl = ddt;
		var llm = hMap(lct, mlcb, 0);
		wbits(out, p, nlc - 257);
		wbits(out, p + 5, ndc - 1);
		wbits(out, p + 10, nlcc - 4);
		p += 14;
		for (var i = 0; i < nlcc; ++i) wbits(out, p + 3 * i, lct[clim[i]]);
		p += 3 * nlcc;
		var lcts = [lclt, lcdt];
		for (var it = 0; it < 2; ++it) {
			var clct = lcts[it];
			for (var i = 0; i < clct.length; ++i) {
				var len = clct[i] & 31;
				wbits(out, p, llm[len]), p += lct[len];
				if (len > 15) wbits(out, p, clct[i] >> 5 & 127), p += clct[i] >> 12;
			}
		}
	} else lm = flm, ll = flt, dm = fdm, dl = fdt;
	for (var i = 0; i < li; ++i) {
		var sym = syms[i];
		if (sym > 255) {
			var len = sym >> 18 & 31;
			wbits16(out, p, lm[len + 257]), p += ll[len + 257];
			if (len > 7) wbits(out, p, sym >> 23 & 31), p += fleb[len];
			var dst = sym & 31;
			wbits16(out, p, dm[dst]), p += dl[dst];
			if (dst > 3) wbits16(out, p, sym >> 5 & 8191), p += fdeb[dst];
		} else wbits16(out, p, lm[sym]), p += ll[sym];
	}
	wbits16(out, p, lm[256]);
	return p + ll[256];
};
var deo = /*#__PURE__*/ new i32([
	65540,
	131080,
	131088,
	131104,
	262176,
	1048704,
	1048832,
	2114560,
	2117632
]);
var et = /*#__PURE__*/ new u8(0);
var dflt = function(dat, lvl, plvl, pre, post, st) {
	var s = st.z || dat.length;
	var o = new u8(pre + s + 5 * (1 + Math.ceil(s / 7e3)) + post);
	var w = o.subarray(pre, o.length - post);
	var lst = st.l;
	var pos = (st.r || 0) & 7;
	if (lvl) {
		if (pos) w[0] = st.r >> 3;
		var opt = deo[lvl - 1];
		var n = opt >> 13;
		var c = opt & 8191;
		var msk_1 = (1 << plvl) - 1;
		var prev = st.p || new u16(32768);
		var head = st.h || new u16(msk_1 + 1);
		var bs1_1 = Math.ceil(plvl / 3);
		var bs2_1 = 2 * bs1_1;
		var hsh = function(i) {
			return (dat[i] ^ dat[i + 1] << bs1_1 ^ dat[i + 2] << bs2_1) & msk_1;
		};
		var syms = new i32(25e3);
		var lf = new u16(288);
		var df = new u16(32);
		var lc_1 = 0;
		var eb = 0;
		var i = st.i || 0;
		var li = 0;
		var wi = st.w || 0;
		var bs = 0;
		for (; i + 2 < s; ++i) {
			var hv = hsh(i);
			var imod = i & 32767;
			var pimod = head[hv];
			prev[imod] = pimod;
			head[hv] = imod;
			if (wi <= i) {
				var rem = s - i;
				if ((lc_1 > 7e3 || li > 24576) && (rem > 423 || !lst)) {
					pos = wblk(dat, w, 0, syms, lf, df, eb, li, bs, i - bs, pos);
					li = lc_1 = eb = 0, bs = i;
					for (var j = 0; j < 286; ++j) lf[j] = 0;
					for (var j = 0; j < 30; ++j) df[j] = 0;
				}
				var l = 2;
				var d = 0;
				var ch_1 = c;
				var dif = imod - pimod & 32767;
				if (rem > 2 && hv == hsh(i - dif)) {
					var maxn = Math.min(n, rem) - 1;
					var maxd = Math.min(32767, i);
					var ml = Math.min(258, rem);
					while (dif <= maxd && --ch_1 && imod != pimod) {
						if (dat[i + l] == dat[i + l - dif]) {
							var nl = 0;
							for (; nl < ml && dat[i + nl] == dat[i + nl - dif]; ++nl);
							if (nl > l) {
								l = nl, d = dif;
								if (nl > maxn) break;
								var mmd = Math.min(dif, nl - 2);
								var md = 0;
								for (var j = 0; j < mmd; ++j) {
									var ti = i - dif + j & 32767;
									var cd = ti - prev[ti] & 32767;
									if (cd > md) md = cd, pimod = ti;
								}
							}
						}
						imod = pimod, pimod = prev[imod];
						dif += imod - pimod & 32767;
					}
				}
				if (d) {
					syms[li++] = 268435456 | revfl[l] << 18 | revfd[d];
					var lin = revfl[l] & 31;
					var din = revfd[d] & 31;
					eb += fleb[lin] + fdeb[din];
					++lf[257 + lin];
					++df[din];
					wi = i + l;
					++lc_1;
				} else {
					syms[li++] = dat[i];
					++lf[dat[i]];
				}
			}
		}
		for (i = Math.max(i, wi); i < s; ++i) {
			syms[li++] = dat[i];
			++lf[dat[i]];
		}
		pos = wblk(dat, w, lst, syms, lf, df, eb, li, bs, i - bs, pos);
		if (!lst) {
			st.r = pos & 7 | w[pos / 8 | 0] << 3;
			pos -= 7;
			st.h = head, st.p = prev, st.i = i, st.w = wi;
		}
	} else {
		for (var i = st.w || 0; i < s + lst; i += 65535) {
			var e = i + 65535;
			if (e >= s) {
				w[pos / 8 | 0] = lst;
				e = s;
			}
			pos = wfblk(w, pos + 1, dat.subarray(i, e));
		}
		st.i = s;
	}
	return slc(o, 0, pre + shft(pos) + post);
};
var adler = function() {
	var a = 1;
	var b = 0;
	return {
		p: function(d) {
			var n = a;
			var m = b;
			var l = d.length | 0;
			for (var i = 0; i != l;) {
				var e = Math.min(i + 2655, l);
				for (; i < e; ++i) m += n += d[i];
				n = (n & 65535) + 15 * (n >> 16), m = (m & 65535) + 15 * (m >> 16);
			}
			a = n, b = m;
		},
		d: function() {
			a %= 65521, b %= 65521;
			return (a & 255) << 24 | (a & 65280) << 8 | (b & 255) << 8 | b >> 8;
		}
	};
};
var dopt = function(dat, opt, pre, post, st) {
	if (!st) {
		st = { l: 1 };
		if (opt.dictionary) {
			var dict = opt.dictionary.subarray(-32768);
			var newDat = new u8(dict.length + dat.length);
			newDat.set(dict);
			newDat.set(dat, dict.length);
			dat = newDat;
			st.w = dict.length;
		}
	}
	return dflt(dat, opt.level == null ? 6 : opt.level, opt.mem == null ? st.l ? Math.ceil(Math.max(8, Math.min(13, Math.log(dat.length))) * 1.5) : 20 : 12 + opt.mem, pre, post, st);
};
var wbytes = function(d, b, v) {
	for (; v; ++b) d[b] = v, v >>>= 8;
};
var zlh = function(c, o) {
	var lv = o.level;
	var fl = lv == 0 ? 0 : lv < 6 ? 1 : lv == 9 ? 3 : 2;
	c[0] = 120, c[1] = fl << 6 | (o.dictionary && 32);
	c[1] |= 31 - (c[0] << 8 | c[1]) % 31;
	if (o.dictionary) {
		var h = adler();
		h.p(o.dictionary);
		wbytes(c, 2, h.d());
	}
};
var zls = function(d, dict) {
	if ((d[0] & 15) != 8 || d[0] >> 4 > 7 || (d[0] << 8 | d[1]) % 31) err(6, "invalid zlib data");
	if ((d[1] >> 5 & 1) == +!dict) err(6, "invalid zlib data: " + (d[1] & 32 ? "need" : "unexpected") + " dictionary");
	return (d[1] >> 3 & 4) + 2;
};
/**
* Compress data with Zlib
* @param data The data to compress
* @param opts The compression options
* @returns The zlib-compressed version of the data
*/
function zlibSync(data, opts) {
	if (!opts) opts = {};
	var a = adler();
	a.p(data);
	var d = dopt(data, opts, opts.dictionary ? 6 : 2, 4);
	return zlh(d, opts), wbytes(d, d.length - 4, a.d()), d;
}
function unzlibSync(data, opts) {
	return inflt(data.subarray(zls(data, opts && opts.dictionary), -4), { i: 2 }, opts && opts.out, opts && opts.dictionary);
}
var td = typeof TextDecoder != "undefined" && /*#__PURE__*/ new TextDecoder();
try {
	td.decode(et, { stream: true });
} catch (e) {}
//#endregion
//#region packages/viewport3d/src/load3d/load3dContextMenuGuard.ts
function exceedsClickThreshold(start, end, threshold) {
	return (end.x - start.x) ** 2 + (end.y - start.y) ** 2 > threshold ** 2;
}
function attachContextMenuGuard(target, onMenu, { isDisabled = () => false, dragThreshold = 5 } = {}) {
	const abort = new AbortController();
	const { signal } = abort;
	let start = {
		x: 0,
		y: 0
	};
	let moved = false;
	target.addEventListener("mousedown", (e) => {
		if (e.button === 2) {
			start = {
				x: e.clientX,
				y: e.clientY
			};
			moved = false;
		}
	}, { signal });
	target.addEventListener("mousemove", (e) => {
		if (e.buttons === 2 && exceedsClickThreshold(start, {
			x: e.clientX,
			y: e.clientY
		}, dragThreshold)) moved = true;
	}, { signal });
	target.addEventListener("contextmenu", (e) => {
		if (isDisabled()) return;
		const wasDragging = moved || exceedsClickThreshold(start, {
			x: e.clientX,
			y: e.clientY
		}, dragThreshold);
		moved = false;
		if (wasDragging) return;
		e.preventDefault();
		e.stopPropagation();
		onMenu(e);
	}, { signal });
	return () => abort.abort();
}
//#endregion
//#region packages/viewport3d/src/load3d/load3dRenderLoop.ts
function startRenderLoop({ tick, isActive }) {
	let frameId = null;
	const loop = () => {
		frameId = requestAnimationFrame(loop);
		if (!isActive()) return;
		tick();
	};
	loop();
	return { stop() {
		if (frameId !== null) {
			cancelAnimationFrame(frameId);
			frameId = null;
		}
	} };
}
//#endregion
//#region packages/viewport3d/src/load3d/load3dViewport.ts
/** Linearly maps `value` from [min, max] to [0, 1]; 0 when min equals max. */
function normalize(value, min, max) {
	return max === min ? 0 : (value - min) / (max - min);
}
function denormalize(normalized, min, max) {
	return min + normalized * (max - min);
}
function computeLetterboxedViewport(container, targetAspectRatio) {
	if (container.width / container.height > targetAspectRatio) {
		const height = container.height;
		const width = height * targetAspectRatio;
		return {
			offsetX: (container.width - width) / 2,
			offsetY: 0,
			width,
			height
		};
	}
	const width = container.width;
	const height = width / targetAspectRatio;
	return {
		offsetX: 0,
		offsetY: (container.height - height) / 2,
		width,
		height
	};
}
function clientPointToLetterboxNdc(normalizedX, normalizedY, container, targetAspectRatio) {
	const toNdc = (localX, localY) => ({
		x: denormalize(localX, -1, 1),
		y: -denormalize(localY, -1, 1),
		inside: localX >= 0 && localX <= 1 && localY >= 0 && localY <= 1
	});
	if (targetAspectRatio === null) return toNdc(normalizedX, normalizedY);
	const { offsetX, offsetY, width, height } = computeLetterboxedViewport(container, targetAspectRatio);
	if (width <= 0 || height <= 0) return null;
	return toNdc(normalize(normalizedX * container.width, offsetX, offsetX + width), normalize(normalizedY * container.height, offsetY, offsetY + height));
}
function computeLetterboxBars(container, viewport) {
	if (viewport.offsetX >= 1) return [{
		x: 0,
		y: 0,
		width: viewport.offsetX,
		height: container.height
	}, {
		x: viewport.offsetX + viewport.width,
		y: 0,
		width: container.width - viewport.offsetX - viewport.width,
		height: container.height
	}];
	if (viewport.offsetY >= 1) return [{
		x: 0,
		y: 0,
		width: container.width,
		height: viewport.offsetY
	}, {
		x: 0,
		y: viewport.offsetY + viewport.height,
		width: container.width,
		height: container.height - viewport.offsetY - viewport.height
	}];
	return [];
}
function isLoad3dActive(flags) {
	return flags.mouseOnNode || flags.mouseOnScene || flags.mouseOnViewer || flags.recording || !flags.initialRenderDone || flags.animationPlaying;
}
//#endregion
//#region packages/viewport3d/src/load3d/Viewport3d.ts
var LETTERBOX_CLEAR_COLOR = 657930;
var LETTERBOX_DIM_OPACITY = .5;
function supportsViewOffset(camera) {
	return camera instanceof PerspectiveCamera || camera instanceof OrthographicCamera;
}
function createLetterboxDimmer() {
	const geometry = new PlaneGeometry(2, 2);
	const material = new MeshBasicMaterial({
		color: 0,
		transparent: true,
		opacity: LETTERBOX_DIM_OPACITY,
		depthTest: false,
		depthWrite: false
	});
	const scene = new Scene();
	scene.add(new Mesh(geometry, material));
	return {
		scene,
		camera: new OrthographicCamera(-1, 1, 1, -1, -1, 1),
		geometry,
		material
	};
}
var VIEW_HELPER_SIZE = 128;
var Viewport3d = class {
	view;
	timer;
	renderLoop = null;
	onContextMenuCallback;
	getDimensionsCallback;
	eventManager;
	sceneManager;
	cameraManager;
	controlsManager;
	lightingManager;
	viewHelperManager;
	STATUS_MOUSE_ON_NODE;
	STATUS_MOUSE_ON_SCENE;
	STATUS_MOUSE_ON_VIEWER;
	INITIAL_RENDER_DONE = false;
	targetWidth = 0;
	targetHeight = 0;
	targetAspectRatio = 1;
	isViewerMode = false;
	disposeContextMenuGuard = null;
	getZoomScaleCallback;
	externalActiveCamera = null;
	overlay = null;
	initialRenderTimer = null;
	viewPixelScale = 1;
	letterboxDimmer = null;
	constructor(container, deps, options = {}) {
		this.view = deps.view;
		this.timer = new Timer();
		this.isViewerMode = options.isViewerMode || false;
		this.onContextMenuCallback = options.onContextMenu;
		this.getDimensionsCallback = options.getDimensions;
		this.getZoomScaleCallback = options.getZoomScale;
		if (options.width !== void 0 && options.height !== void 0) this.applyTargetSize(options.width, options.height);
		this.eventManager = deps.eventManager;
		this.sceneManager = deps.sceneManager;
		this.cameraManager = deps.cameraManager;
		this.controlsManager = deps.controlsManager;
		this.lightingManager = deps.lightingManager;
		this.viewHelperManager = deps.viewHelperManager;
		this.sceneManager.init();
		this.cameraManager.init();
		this.controlsManager.init();
		this.lightingManager.init();
		this.viewHelperManager.createViewHelper(container);
		this.viewHelperManager.init();
		this.STATUS_MOUSE_ON_NODE = false;
		this.STATUS_MOUSE_ON_SCENE = false;
		this.STATUS_MOUSE_ON_VIEWER = false;
		this.initContextMenu();
		this.view.observeResize(container, () => this.handleResize());
	}
	get renderer() {
		return this.view.renderer;
	}
	get rendererView() {
		return this.view;
	}
	get domElement() {
		return this.view.canvas;
	}
	start() {
		if (this.hasStarted) return;
		this.hasStarted = true;
		this.handleResize();
		this.startAnimation();
		this.initialRenderTimer = setTimeout(() => {
			this.initialRenderTimer = null;
			this.forceRender();
		}, 100);
	}
	hasStarted = false;
	applyTargetSize(width, height) {
		if (!Number.isFinite(width) || !Number.isFinite(height)) return;
		if (width <= 0 || height <= 0) return;
		this.targetWidth = width;
		this.targetHeight = height;
		this.targetAspectRatio = width / height;
	}
	initContextMenu() {
		this.disposeContextMenuGuard = attachContextMenuGuard(this.view.canvas, (event) => this.onContextMenuCallback?.(event), { isDisabled: () => this.isViewerMode });
	}
	getEventManager() {
		return this.eventManager;
	}
	getSceneManager() {
		return this.sceneManager;
	}
	getCameraManager() {
		return this.cameraManager;
	}
	getControlsManager() {
		return this.controlsManager;
	}
	getLightingManager() {
		return this.lightingManager;
	}
	getViewHelperManager() {
		return this.viewHelperManager;
	}
	getTargetSize() {
		return {
			width: this.targetWidth,
			height: this.targetHeight
		};
	}
	shouldMaintainAspectRatio() {
		return this.isViewerMode || this.targetWidth > 0 && this.targetHeight > 0;
	}
	forceRender() {
		const delta = this.timer.update().getDelta();
		this.tickPerFrame(delta);
		this.renderView();
		this.INITIAL_RENDER_DONE = true;
	}
	renderView() {
		this.renderer.state.reset();
		this.view.beginRender(this.sceneManager.hasSplats());
		this.runPreRenderCallbacks();
		this.renderMainScene();
		this.runPostRenderCallbacks();
		this.view.setScissorTest(false);
		this.viewHelperManager.render(this.view, VIEW_HELPER_SIZE * this.viewPixelScale);
		this.view.blit();
	}
	preRenderCallbacks = [];
	postRenderCallbacks = [];
	addPreRenderCallback(cb) {
		const registered = () => cb();
		this.preRenderCallbacks.push(registered);
		return () => {
			const i = this.preRenderCallbacks.indexOf(registered);
			if (i >= 0) this.preRenderCallbacks.splice(i, 1);
		};
	}
	addPostRenderCallback(cb) {
		const registered = () => cb();
		this.postRenderCallbacks.push(registered);
		return () => {
			const i = this.postRenderCallbacks.indexOf(registered);
			if (i >= 0) this.postRenderCallbacks.splice(i, 1);
		};
	}
	runPreRenderCallbacks() {
		for (const cb of Array.from(this.preRenderCallbacks)) cb();
	}
	runPostRenderCallbacks() {
		for (const cb of Array.from(this.postRenderCallbacks)) cb();
	}
	tickPerFrame(delta) {
		this.overlay?.update?.(delta);
		this.viewHelperManager.update(delta);
		this.controlsManager.update();
	}
	getRenderCamera() {
		return this.externalActiveCamera ?? this.cameraManager.activeCamera;
	}
	setExternalActiveCamera(camera) {
		if (this.externalActiveCamera === camera) return;
		this.externalActiveCamera = camera;
		if (camera) {
			this.controlsManager.detach();
			this.viewHelperManager.visibleViewHelper(false);
		} else {
			this.controlsManager.attach();
			this.viewHelperManager.visibleViewHelper(true);
		}
		this.overlay?.onActiveCameraChange?.(this.getRenderCamera());
		this.forceRender();
	}
	setOverlay(overlay) {
		if (this.overlay === overlay) return;
		if (this.overlay) {
			this.overlay.detach();
			this.overlay.dispose();
		}
		this.overlay = overlay;
		overlay.attach(this.sceneManager.scene);
		overlay.onActiveCameraChange?.(this.getRenderCamera());
		this.forceRender();
	}
	removeOverlay() {
		if (!this.overlay) return;
		this.overlay.detach();
		this.overlay.dispose();
		this.overlay = null;
		this.forceRender();
	}
	getOverlay() {
		return this.overlay;
	}
	renderMainScene() {
		const viewWidth = this.view.width;
		const viewHeight = this.view.height;
		if (this.getDimensionsCallback) {
			const dims = this.getDimensionsCallback();
			if (dims) this.applyTargetSize(dims.width, dims.height);
		}
		this.view.setViewport(0, 0, viewWidth, viewHeight);
		this.view.setScissor(0, 0, viewWidth, viewHeight);
		this.view.setScissorTest(true);
		if (!this.shouldMaintainAspectRatio()) {
			this.renderer.setClearColor(this.view.state.clearColor, this.view.state.clearAlpha);
			this.renderer.clear();
			this.sceneManager.renderBackground();
			this.renderer.render(this.sceneManager.scene, this.getRenderCamera());
			return;
		}
		const container = {
			width: viewWidth,
			height: viewHeight
		};
		const viewport = computeLetterboxedViewport(container, this.targetAspectRatio);
		this.renderer.setClearColor(LETTERBOX_CLEAR_COLOR);
		this.renderer.clear();
		this.cameraManager.updateAspectRatio(viewport.width / viewport.height);
		const camera = this.getRenderCamera();
		if (!supportsViewOffset(camera)) {
			this.view.setViewport(viewport.offsetX, viewport.offsetY, viewport.width, viewport.height);
			this.view.setScissor(viewport.offsetX, viewport.offsetY, viewport.width, viewport.height);
			this.sceneManager.renderBackground();
			this.renderer.render(this.sceneManager.scene, camera);
			return;
		}
		camera.setViewOffset(viewport.width, viewport.height, -viewport.offsetX, -viewport.offsetY, viewWidth, viewHeight);
		this.renderLetterboxedBackground(viewport);
		this.renderer.render(this.sceneManager.scene, camera);
		camera.clearViewOffset();
		this.dimLetterboxBars(computeLetterboxBars(container, viewport));
	}
	renderLetterboxedBackground(viewport) {
		if (this.sceneManager.getCurrentBackgroundInfo().type !== "image") {
			this.sceneManager.renderBackground();
			return;
		}
		this.view.setViewport(viewport.offsetX, viewport.offsetY, viewport.width, viewport.height);
		this.view.setScissor(viewport.offsetX, viewport.offsetY, viewport.width, viewport.height);
		this.sceneManager.renderBackground();
		this.view.setViewport(0, 0, this.view.width, this.view.height);
		this.view.setScissor(0, 0, this.view.width, this.view.height);
	}
	dimLetterboxBars(bars) {
		if (bars.length === 0) return;
		const dimmer = this.letterboxDimmer ??= createLetterboxDimmer();
		for (const bar of bars) {
			this.view.setViewport(bar.x, bar.y, bar.width, bar.height);
			this.view.setScissor(bar.x, bar.y, bar.width, bar.height);
			this.renderer.render(dimmer.scene, dimmer.camera);
		}
	}
	clientPointToNdc(clientX, clientY) {
		const rect = this.domElement.getBoundingClientRect();
		if (rect.width <= 0 || rect.height <= 0) return null;
		return clientPointToLetterboxNdc(normalize(clientX, rect.left, rect.right), normalize(clientY, rect.top, rect.bottom), {
			width: rect.width,
			height: rect.height
		}, this.shouldMaintainAspectRatio() ? this.targetAspectRatio : null);
	}
	startAnimation() {
		this.renderLoop = startRenderLoop({
			tick: () => {
				const delta = this.timer.update().getDelta();
				this.tickPerFrame(delta);
				this.renderView();
			},
			isActive: () => this.isActive()
		});
	}
	updateStatusMouseOnNode(onNode) {
		this.STATUS_MOUSE_ON_NODE = onNode;
	}
	updateStatusMouseOnScene(onScene) {
		this.STATUS_MOUSE_ON_SCENE = onScene;
	}
	updateStatusMouseOnViewer(onViewer) {
		this.STATUS_MOUSE_ON_VIEWER = onViewer;
	}
	isActive() {
		return isLoad3dActive({
			mouseOnNode: this.STATUS_MOUSE_ON_NODE,
			mouseOnScene: this.STATUS_MOUSE_ON_SCENE,
			mouseOnViewer: this.STATUS_MOUSE_ON_VIEWER,
			recording: false,
			initialRenderDone: this.INITIAL_RENDER_DONE,
			animationPlaying: false
		});
	}
	toggleCamera(cameraType) {
		this.cameraManager.toggleCamera(cameraType);
		this.controlsManager.updateCamera(this.cameraManager.activeCamera);
		this.onActiveCameraChanged();
		this.viewHelperManager.recreateViewHelper();
		if (!this.externalActiveCamera) this.overlay?.onActiveCameraChange?.(this.cameraManager.activeCamera);
		this.handleResize();
	}
	onActiveCameraChanged() {}
	getCurrentCameraType() {
		return this.cameraManager.getCurrentCameraType();
	}
	setCameraState(state) {
		this.cameraManager.setCameraState(state);
		this.forceRender();
	}
	getCameraState() {
		return this.cameraManager.getCameraState();
	}
	setUseCustomUp(use) {
		this.cameraManager.setUseCustomUp(use);
		this.forceRender();
	}
	setTargetSize(width, height) {
		this.applyTargetSize(width, height);
		this.handleResize();
	}
	addEventListener(event, callback) {
		this.eventManager.addEventListener(event, callback);
	}
	removeEventListener(event, callback) {
		this.eventManager.removeEventListener(event, callback);
	}
	refreshViewport() {
		this.handleResize();
	}
	handleResize() {
		const parentElement = this.view.canvas.parentElement;
		if (!parentElement) {
			console.warn("Parent element not found");
			return;
		}
		const containerWidth = parentElement.clientWidth;
		const containerHeight = parentElement.clientHeight;
		const zoomScale = this.getZoomScaleCallback?.() ?? 1;
		this.viewPixelScale = Math.min(zoomScale, 3);
		if (this.getDimensionsCallback) {
			const dims = this.getDimensionsCallback();
			if (dims) this.applyTargetSize(dims.width, dims.height);
		}
		this.view.setSize(containerWidth * this.viewPixelScale, containerHeight * this.viewPixelScale);
		if (this.shouldMaintainAspectRatio()) {
			const { width, height } = computeLetterboxedViewport({
				width: containerWidth,
				height: containerHeight
			}, this.targetAspectRatio);
			this.cameraManager.handleResize(width, height);
			this.sceneManager.handleResize(width, height);
		} else {
			this.cameraManager.handleResize(containerWidth, containerHeight);
			this.sceneManager.handleResize(containerWidth, containerHeight);
		}
		this.forceRender();
	}
	remove() {
		if (this.initialRenderTimer) {
			clearTimeout(this.initialRenderTimer);
			this.initialRenderTimer = null;
		}
		this.disposeContextMenuGuard?.();
		this.disposeContextMenuGuard = null;
		this.renderLoop?.stop();
		this.renderLoop = null;
		this.disposeManagers();
		this.view.dispose();
	}
	disposeManagers() {
		if (this.overlay) {
			this.overlay.detach();
			this.overlay.dispose();
			this.overlay = null;
		}
		if (this.letterboxDimmer) {
			this.letterboxDimmer.geometry.dispose();
			this.letterboxDimmer.material.dispose();
			this.letterboxDimmer = null;
		}
		this.sceneManager.dispose();
		this.cameraManager.dispose();
		this.controlsManager.dispose();
		this.lightingManager.dispose();
		this.viewHelperManager.dispose();
	}
};
//#endregion
//#region node_modules/.pnpm/@comfyorg+quad-wireframe-three@0.1.0_three@0.186.1/node_modules/@comfyorg/quad-wireframe-three/dist/fbx/faceSizes.js
function faceSizesFromPolygonVertexIndex(polygonVertexIndex) {
	let faceCount = 0;
	for (let i = 0; i < polygonVertexIndex.length; i++) if (polygonVertexIndex[i] < 0) faceCount++;
	const sizes = new Uint32Array(faceCount);
	let size = 0;
	let face = 0;
	for (let i = 0; i < polygonVertexIndex.length; i++) {
		size++;
		if (polygonVertexIndex[i] < 0) {
			sizes[face++] = size;
			size = 0;
		}
	}
	return sizes;
}
function triangleCountOf(faceSizes) {
	let triangles = 0;
	for (let i = 0; i < faceSizes.length; i++) {
		const size = faceSizes[i];
		if (size >= 3) triangles += size - 2;
	}
	return triangles;
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+quad-wireframe-three@0.1.0_three@0.186.1/node_modules/@comfyorg/quad-wireframe-three/dist/mesh/types.js
function positionAttributeOf(geometry) {
	const position = geometry.getAttribute("position");
	if (!position) throw new Error("geometry has no position attribute");
	return position;
}
function faceCount(mesh) {
	return mesh.faceOffsets.length - 1;
}
function polygonMeshFromFaces(positions, faces) {
	const faceOffsets = new Uint32Array(faces.length + 1);
	let total = 0;
	for (let f = 0; f < faces.length; f++) {
		faceOffsets[f] = total;
		total += faces[f].length;
	}
	faceOffsets[faces.length] = total;
	const faceVertices = new Uint32Array(total);
	let cursor = 0;
	for (const face of faces) for (let i = 0; i < face.length; i++) faceVertices[cursor++] = face[i];
	return {
		positions,
		faceOffsets,
		faceVertices
	};
}
Math.PI * 2;
Math.PI / 2;
//#endregion
//#region node_modules/.pnpm/@comfyorg+quad-wireframe-three@0.1.0_three@0.186.1/node_modules/@comfyorg/quad-wireframe-three/dist/join/joinTriangles.js
var DEGREES = Math.PI / 180;
40 * DEGREES, 40 * DEGREES;
Math.PI / 4;
//#endregion
//#region node_modules/.pnpm/@comfyorg+quad-wireframe-three@0.1.0_three@0.186.1/node_modules/@comfyorg/quad-wireframe-three/dist/mesh/edges.js
function polygonEdges(mesh) {
	const seen = /* @__PURE__ */ new Set();
	const pairs = [];
	const faces = faceCount(mesh);
	for (let f = 0; f < faces; f++) {
		const start = mesh.faceOffsets[f];
		const end = mesh.faceOffsets[f + 1];
		for (let i = start; i < end; i++) {
			const a = mesh.faceVertices[i];
			const b = mesh.faceVertices[i + 1 < end ? i + 1 : start];
			if (a === b) continue;
			const lo = a < b ? a : b;
			const hi = a < b ? b : a;
			const key = lo * 4294967296 + hi;
			if (seen.has(key)) continue;
			seen.add(key);
			pairs.push(lo, hi);
		}
	}
	return Uint32Array.from(pairs);
}
function createPolygonEdgesGeometry(mesh) {
	const edges = polygonEdges(mesh);
	const positions = new Float32Array(edges.length * 3);
	for (let i = 0; i < edges.length; i++) {
		const v = edges[i] * 3;
		positions[i * 3] = mesh.positions[v];
		positions[i * 3 + 1] = mesh.positions[v + 1];
		positions[i * 3 + 2] = mesh.positions[v + 2];
	}
	const geometry = new BufferGeometry();
	geometry.setAttribute("position", new Float32BufferAttribute(positions, 3));
	return geometry;
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+quad-wireframe-three@0.1.0_three@0.186.1/node_modules/@comfyorg/quad-wireframe-three/dist/mesh/weld.js
function weldPositions(source, tolerance = 1e-6) {
	const ids = /* @__PURE__ */ new Map();
	const remap = new Uint32Array(source.count);
	const welded = [];
	const inverseTolerance = 1 / tolerance;
	for (let i = 0; i < source.count; i++) {
		const x = source.getX(i);
		const y = source.getY(i);
		const z = source.getZ(i);
		const key = `${Math.round(x * inverseTolerance)},${Math.round(y * inverseTolerance)},${Math.round(z * inverseTolerance)}`;
		const existing = ids.get(key);
		if (existing === void 0) {
			remap[i] = ids.size;
			ids.set(key, ids.size);
			welded.push(x, y, z);
		} else remap[i] = existing;
	}
	return {
		positions: Float32Array.from(welded),
		remap
	};
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+quad-wireframe-three@0.1.0_three@0.186.1/node_modules/@comfyorg/quad-wireframe-three/dist/mesh/fromTriangles.js
function weldedTriangles(geometry) {
	const position = positionAttributeOf(geometry);
	const { positions, remap } = weldPositions(position);
	const index = geometry.index?.array;
	const cornerCount = index ? index.length : position.count;
	const corners = new Uint32Array(cornerCount);
	for (let i = 0; i < cornerCount; i++) corners[i] = remap[index ? index[i] : i];
	return {
		positions,
		corners
	};
}
function isDegenerate(a, b, c) {
	return a === b || b === c || a === c;
}
function perimeterLoop(corners, firstTriangle, triangleCount, expectedSize) {
	const edgeUses = /* @__PURE__ */ new Map();
	const neighbors = /* @__PURE__ */ new Map();
	const vertexIds = /* @__PURE__ */ new Set();
	for (let t = firstTriangle; t < firstTriangle + triangleCount; t++) for (let e = 0; e < 3; e++) {
		const a = corners[t * 3 + e];
		const b = corners[t * 3 + (e + 1) % 3];
		vertexIds.add(a);
		const key = a < b ? a * 4294967296 + b : b * 4294967296 + a;
		edgeUses.set(key, (edgeUses.get(key) ?? 0) + 1);
	}
	if (vertexIds.size !== expectedSize) return null;
	for (let t = firstTriangle; t < firstTriangle + triangleCount; t++) for (let e = 0; e < 3; e++) {
		const a = corners[t * 3 + e];
		const b = corners[t * 3 + (e + 1) % 3];
		const key = a < b ? a * 4294967296 + b : b * 4294967296 + a;
		if (edgeUses.get(key) !== 1) continue;
		const fromA = neighbors.get(a);
		if (fromA) fromA.push(b);
		else neighbors.set(a, [b]);
		const fromB = neighbors.get(b);
		if (fromB) fromB.push(a);
		else neighbors.set(b, [a]);
	}
	let start = -1;
	let second = -1;
	for (let e = 0; e < 3 && start < 0; e++) {
		const a = corners[firstTriangle * 3 + e];
		const b = corners[firstTriangle * 3 + (e + 1) % 3];
		const key = a < b ? a * 4294967296 + b : b * 4294967296 + a;
		if (edgeUses.get(key) === 1) {
			start = a;
			second = b;
		}
	}
	if (start < 0) return null;
	const loop = [start, second];
	let previous = start;
	let current = second;
	while (loop.length < expectedSize) {
		const next = neighbors.get(current)?.find((v) => v !== previous);
		if (next === void 0 || next === start) return null;
		loop.push(next);
		previous = current;
		current = next;
	}
	return neighbors.get(current)?.includes(start) ?? false ? loop : null;
}
function polygonMeshFromTriangles(geometry, faceSizes) {
	const { positions, corners } = weldedTriangles(geometry);
	const triangleCount = Math.floor(corners.length / 3);
	const faces = [];
	if (!faceSizes) {
		for (let t = 0; t < triangleCount; t++) {
			const a = corners[t * 3];
			const b = corners[t * 3 + 1];
			const c = corners[t * 3 + 2];
			if (!isDegenerate(a, b, c)) faces.push([
				a,
				b,
				c
			]);
		}
		return polygonMeshFromFaces(positions, faces);
	}
	const expectedTriangles = triangleCountOf(faceSizes);
	if (expectedTriangles !== triangleCount) throw new Error(`faceSizes describe ${expectedTriangles} triangles but geometry has ${triangleCount}`);
	let triangle = 0;
	for (let f = 0; f < faceSizes.length; f++) {
		const size = faceSizes[f];
		if (size < 3) continue;
		const span = size - 2;
		if (size === 3) {
			const a = corners[triangle * 3];
			const b = corners[triangle * 3 + 1];
			const c = corners[triangle * 3 + 2];
			if (!isDegenerate(a, b, c)) faces.push([
				a,
				b,
				c
			]);
		} else {
			const loop = perimeterLoop(corners, triangle, span, size);
			if (loop) faces.push(loop);
			else for (let t = triangle; t < triangle + span; t++) {
				const a = corners[t * 3];
				const b = corners[t * 3 + 1];
				const c = corners[t * 3 + 2];
				if (!isDegenerate(a, b, c)) faces.push([
					a,
					b,
					c
				]);
			}
		}
		triangle += span;
	}
	return polygonMeshFromFaces(positions, faces);
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+quad-wireframe-three@0.1.0_three@0.186.1/node_modules/@comfyorg/quad-wireframe-three/dist/fbx/binaryFbx.js
var MAGIC = "Kaydara FBX Binary  \0\0";
var VERSION_OFFSET = 23;
var FIRST_NODE_OFFSET = 27;
var ARRAY_TYPES = /* @__PURE__ */ new Set([
	"b",
	"c",
	"i",
	"l",
	"f",
	"d"
]);
var ARRAY_STRIDE = {
	b: 1,
	c: 1,
	i: 4,
	l: 8,
	f: 4,
	d: 8
};
var textDecoder = new TextDecoder();
function isBinaryFbx(buffer) {
	if (buffer.byteLength < FIRST_NODE_OFFSET) return false;
	const head = new Uint8Array(buffer, 0, 23);
	for (let i = 0; i < 23; i++) if (head[i] !== MAGIC.charCodeAt(i)) return false;
	return true;
}
function readHeader(cursor, is64) {
	const { view } = cursor;
	let endOffset;
	let propCount;
	if (is64) {
		endOffset = Number(view.getBigUint64(cursor.pos, true));
		propCount = Number(view.getBigUint64(cursor.pos + 8, true));
		cursor.pos += 24;
	} else {
		endOffset = view.getUint32(cursor.pos, true);
		propCount = view.getUint32(cursor.pos + 4, true);
		cursor.pos += 12;
	}
	const nameLength = view.getUint8(cursor.pos);
	cursor.pos += 1;
	const name = textDecoder.decode(cursor.bytes.subarray(cursor.pos, cursor.pos + nameLength));
	cursor.pos += nameLength;
	return {
		endOffset,
		propCount,
		name
	};
}
function readBlob(cursor) {
	const length = cursor.view.getUint32(cursor.pos, true);
	cursor.pos += 4;
	const blob = cursor.bytes.subarray(cursor.pos, cursor.pos + length);
	cursor.pos += length;
	return blob;
}
function readArrayProp(cursor, type) {
	const { view } = cursor;
	const length = view.getUint32(cursor.pos, true);
	const encoding = view.getUint32(cursor.pos + 4, true);
	const byteLength = view.getUint32(cursor.pos + 8, true);
	cursor.pos += 12;
	const bytes = cursor.bytes.subarray(cursor.pos, cursor.pos + byteLength);
	cursor.pos += byteLength;
	return {
		kind: "array",
		type,
		length,
		encoding,
		bytes
	};
}
function readProp(cursor) {
	const { view } = cursor;
	const typeCode = String.fromCharCode(view.getUint8(cursor.pos));
	cursor.pos += 1;
	if (ARRAY_TYPES.has(typeCode)) return readArrayProp(cursor, typeCode);
	switch (typeCode) {
		case "Y": {
			const value = view.getInt16(cursor.pos, true);
			cursor.pos += 2;
			return value;
		}
		case "C": {
			const value = view.getUint8(cursor.pos) !== 0;
			cursor.pos += 1;
			return value;
		}
		case "I": {
			const value = view.getInt32(cursor.pos, true);
			cursor.pos += 4;
			return value;
		}
		case "F": {
			const value = view.getFloat32(cursor.pos, true);
			cursor.pos += 4;
			return value;
		}
		case "D": {
			const value = view.getFloat64(cursor.pos, true);
			cursor.pos += 8;
			return value;
		}
		case "L": {
			const value = view.getBigInt64(cursor.pos, true);
			cursor.pos += 8;
			return value;
		}
		case "R": return readBlob(cursor);
		case "S": return textDecoder.decode(readBlob(cursor));
		default: throw new Error(`Unknown FBX property type '${typeCode}' at byte ${cursor.pos - 1}`);
	}
}
function readNode(cursor, is64) {
	const header = readHeader(cursor, is64);
	if (header.endOffset === 0) return null;
	const props = [];
	for (let i = 0; i < header.propCount; i++) props.push(readProp(cursor));
	const children = [];
	while (cursor.pos < header.endOffset) {
		const child = readNode(cursor, is64);
		if (child === null) break;
		children.push(child);
	}
	cursor.pos = header.endOffset;
	return {
		name: header.name,
		props,
		children
	};
}
function parseBinaryFbx(buffer) {
	if (!isBinaryFbx(buffer)) throw new Error("Not a binary FBX file (bad magic header)");
	const view = new DataView(buffer);
	const version = view.getUint32(VERSION_OFFSET, true);
	const cursor = {
		view,
		bytes: new Uint8Array(buffer),
		pos: FIRST_NODE_OFFSET
	};
	const is64 = version >= 7500;
	const nodes = [];
	while (cursor.pos < buffer.byteLength) {
		const node = readNode(cursor, is64);
		if (node === null) break;
		nodes.push(node);
	}
	return {
		version,
		nodes
	};
}
function decodeArray(prop) {
	const raw = prop.encoding === 1 ? unzlibSync(prop.bytes) : prop.bytes;
	const stride = ARRAY_STRIDE[prop.type];
	const expected = prop.length * stride;
	if (raw.byteLength < expected) throw new Error(`FBX array too short: expected ${expected} bytes, got ${raw.byteLength}`);
	const aligned = raw.slice(0, expected);
	switch (prop.type) {
		case "i": return new Int32Array(aligned.buffer);
		case "l": return new BigInt64Array(aligned.buffer);
		case "f": return new Float32Array(aligned.buffer);
		case "d": return new Float64Array(aligned.buffer);
		case "b":
		case "c": return aligned;
	}
}
function isArrayProp(prop) {
	return typeof prop === "object" && prop !== null && !(prop instanceof Uint8Array) && prop.kind === "array";
}
function findChild(node, name) {
	return node.children.find((child) => child.name === name);
}
function findChildren(node, name) {
	return node.children.filter((child) => child.name === name);
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+quad-wireframe-three@0.1.0_three@0.186.1/node_modules/@comfyorg/quad-wireframe-three/dist/fbx/readFbxPolygons.js
function threeStyleName(raw) {
	if (typeof raw !== "string") return "";
	const nul = raw.indexOf("\0");
	return nul >= 0 ? raw.slice(0, nul) : raw;
}
function polygonsOf(geometryNode) {
	const prop = findChild(geometryNode, "PolygonVertexIndex")?.props[0];
	if (!isArrayProp(prop) || prop.type !== "i") return null;
	const indices = decodeArray(prop);
	const id = geometryNode.props[0];
	return {
		id: typeof id === "bigint" || typeof id === "number" ? id : 0,
		name: threeStyleName(geometryNode.props[1]),
		faceSizes: faceSizesFromPolygonVertexIndex(indices)
	};
}
function readFbxPolygons(buffer) {
	const objects = parseBinaryFbx(buffer).nodes.find((node) => node.name === "Objects");
	if (!objects) return [];
	return findChildren(objects, "Geometry").map(polygonsOf).filter((entry) => entry !== null);
}
//#endregion
//#region node_modules/.pnpm/@comfyorg+quad-wireframe-three@0.1.0_three@0.186.1/node_modules/@comfyorg/quad-wireframe-three/dist/index.js
function triangleCountOfGeometry(geometry) {
	const corners = geometry.index ? geometry.index.array.length : positionAttributeOf(geometry).count;
	return Math.floor(corners / 3);
}
function matchFbxPolygons(polygons, geometry) {
	const triangles = triangleCountOfGeometry(geometry);
	const fits = polygons.filter((entry) => triangleCountOf(entry.faceSizes) === triangles);
	if (fits.length === 0) return null;
	const byName = geometry.name ? fits.filter((entry) => entry.name === geometry.name) : [];
	if (byName.length === 1) return byName[0].faceSizes;
	return fits.length === 1 ? fits[0].faceSizes : null;
}
//#endregion
//#region packages/viewport3d/src/load3d/quadWireframe/faceSizesRegistry.ts
var faceSizesByGeometry = /* @__PURE__ */ new WeakMap();
function registerFaceSizes(geometry, faceSizes) {
	faceSizesByGeometry.set(geometry, faceSizes);
}
function faceSizesFor(geometry) {
	return faceSizesByGeometry.get(geometry);
}
//#endregion
//#region packages/viewport3d/src/load3d/quadWireframe/QuadWireframeManager.ts
var QuadWireframeOverlay = class extends LineSegments {};
function isDeforming(mesh) {
	const hasMorphs = Object.keys(mesh.geometry.morphAttributes).length > 0;
	return mesh instanceof SkinnedMesh || hasMorphs;
}
function triangleCount(geometry) {
	const corners = geometry.index?.count ?? geometry.getAttribute("position").count;
	return Math.floor(corners / 3);
}
var QuadWireframeManager = class {
	overlays = /* @__PURE__ */ new Map();
	cache = /* @__PURE__ */ new Map();
	material = new LineBasicMaterial({ color: 16777215 });
	show(model) {
		this.hide();
		const quads = [];
		const triangles = [];
		let triangleTotal = 0;
		model.traverse((child) => {
			if (!(child instanceof Mesh) || isDeforming(child)) return;
			if (faceSizesFor(child.geometry)) quads.push(child);
			else {
				triangles.push(child);
				triangleTotal += triangleCount(child.geometry);
			}
		});
		const outlined = triangleTotal > 3e5 ? quads : [...quads, ...triangles];
		for (const child of outlined) {
			const overlay = new QuadWireframeOverlay(this.edgesFor(child.geometry), this.material);
			overlay.renderOrder = 1;
			child.add(overlay);
			this.overlays.set(child, overlay);
		}
		return outlined;
	}
	hide() {
		for (const [mesh, overlay] of this.overlays) mesh.remove(overlay);
		this.overlays.clear();
	}
	clear() {
		this.hide();
		for (const edges of this.cache.values()) edges.dispose();
		this.cache.clear();
	}
	dispose() {
		this.clear();
		this.material.dispose();
	}
	edgesFor(geometry) {
		let edges = this.cache.get(geometry);
		if (!edges) {
			edges = createPolygonEdgesGeometry(polygonMeshFromTriangles(geometry, faceSizesFor(geometry)));
			this.cache.set(geometry, edges);
		}
		return edges;
	}
};
//#endregion
//#region packages/viewport3d/src/load3d/SceneManager.ts
var SPLAT_SORT_TIMEOUT_MS = 5e3;
var SPLAT_SORT_POLL_MS = 16;
var SceneManager = class {
	scene;
	gridHelper;
	sparkRenderer;
	nextSparkDirtyPromise = null;
	nextSparkDirtyResolve = null;
	awaitNextSparkDirty() {
		if (this.nextSparkDirtyPromise) return this.nextSparkDirtyPromise;
		this.nextSparkDirtyPromise = new Promise((resolve) => {
			this.nextSparkDirtyResolve = resolve;
		});
		return this.nextSparkDirtyPromise;
	}
	async whenSplatsSorted(camera) {
		const spark = this.sparkRenderer;
		await spark.update({
			scene: this.scene,
			camera
		});
		const deadline = performance.now() + SPLAT_SORT_TIMEOUT_MS;
		while ((spark.sorting || spark.sortDirty) && performance.now() < deadline) await delay(SPLAT_SORT_POLL_MS);
	}
	hasSplats() {
		return this.sparkRenderer.activeSplats > 0;
	}
	backgroundScene;
	backgroundCamera;
	backgroundMesh = null;
	backgroundTexture = null;
	backgroundRenderMode = "tiled";
	backgroundColorMaterial = null;
	currentBackgroundType = "color";
	currentBackgroundColor = "#282828";
	eventManager;
	renderer;
	view;
	getActiveCamera;
	constructor(view, getActiveCamera, _getControls, eventManager) {
		this.view = view;
		this.renderer = view.renderer;
		this.eventManager = eventManager;
		this.scene = new Scene();
		this.scene.name = "MainScene";
		this.getActiveCamera = getActiveCamera;
		this.sparkRenderer = new SparkRenderer({
			renderer: view.renderer,
			onDirty: () => {
				const resolve = this.nextSparkDirtyResolve;
				this.nextSparkDirtyResolve = null;
				this.nextSparkDirtyPromise = null;
				resolve?.();
			}
		});
		this.scene.add(this.sparkRenderer);
		this.gridHelper = new GridHelper(20, 20);
		this.gridHelper.position.set(0, 0, 0);
		this.scene.add(this.gridHelper);
		this.backgroundScene = new Scene();
		this.backgroundScene.name = "BackgroundScene";
		this.backgroundCamera = new OrthographicCamera(-1, 1, 1, -1, -1, 1);
		this.initBackgroundScene();
	}
	initBackgroundScene() {
		const planeGeometry = new PlaneGeometry(2, 2);
		this.backgroundColorMaterial = new MeshBasicMaterial({
			color: new Color(this.currentBackgroundColor),
			transparent: false,
			depthWrite: false,
			depthTest: false,
			side: 2
		});
		this.backgroundMesh = new Mesh(planeGeometry, this.backgroundColorMaterial);
		this.backgroundMesh.position.set(0, 0, 0);
		this.backgroundScene.add(this.backgroundMesh);
		this.view.state.clearColor.set(0);
		this.view.state.clearAlpha = 0;
	}
	init() {}
	dispose() {
		if (this.backgroundTexture) this.backgroundTexture.dispose();
		if (this.backgroundColorMaterial) this.backgroundColorMaterial.dispose();
		if (this.backgroundMesh) {
			this.backgroundMesh.geometry.dispose();
			if (this.backgroundMesh.material instanceof Material) this.backgroundMesh.material.dispose();
		}
		if (this.scene.background) this.scene.background = null;
		this.backgroundScene.clear();
		this.scene.clear();
	}
	toggleGrid(showGrid) {
		this.gridHelper.visible = showGrid;
		this.eventManager.emitEvent("showGridChange", showGrid);
	}
	setBackgroundColor(color) {
		this.currentBackgroundColor = color;
		this.currentBackgroundType = "color";
		if (this.scene.background instanceof Texture) this.scene.background = null;
		if (this.backgroundRenderMode === "panorama") {
			this.backgroundRenderMode = "tiled";
			this.eventManager.emitEvent("backgroundRenderModeChange", "tiled");
		}
		if (!this.backgroundMesh || !this.backgroundColorMaterial) this.initBackgroundScene();
		this.backgroundColorMaterial.color.set(color);
		this.backgroundColorMaterial.map = null;
		this.backgroundColorMaterial.transparent = false;
		this.backgroundColorMaterial.needsUpdate = true;
		if (this.backgroundMesh) this.backgroundMesh.material = this.backgroundColorMaterial;
		if (this.backgroundTexture) {
			this.backgroundTexture.dispose();
			this.backgroundTexture = null;
		}
		this.eventManager.emitEvent("backgroundColorChange", color);
	}
	async setBackgroundImage(uploadPath, imageUrl) {
		if (uploadPath === "") {
			this.setBackgroundColor(this.currentBackgroundColor);
			return;
		}
		this.eventManager.emitEvent("backgroundImageLoadingStart", null);
		try {
			const textureLoader = new TextureLoader();
			const texture = await new Promise((resolve, reject) => {
				textureLoader.load(imageUrl, resolve, void 0, reject);
			});
			if (this.backgroundTexture) this.backgroundTexture.dispose();
			texture.colorSpace = SRGBColorSpace;
			this.backgroundTexture = texture;
			this.currentBackgroundType = "image";
			if (this.backgroundRenderMode === "panorama") {
				texture.mapping = 303;
				this.scene.background = texture;
			} else {
				if (!this.backgroundMesh) this.initBackgroundScene();
				const imageMaterial = new MeshBasicMaterial({
					map: texture,
					transparent: true,
					depthWrite: false,
					depthTest: false,
					side: 2
				});
				if (this.backgroundMesh) {
					if (this.backgroundMesh.material !== this.backgroundColorMaterial && this.backgroundMesh.material instanceof Material) this.backgroundMesh.material.dispose();
					this.backgroundMesh.material = imageMaterial;
					this.backgroundMesh.position.set(0, 0, 0);
				}
				this.updateBackgroundSize(this.backgroundTexture, this.backgroundMesh, this.view.canvas.clientWidth, this.view.canvas.clientHeight);
			}
			this.eventManager.emitEvent("backgroundImageChange", uploadPath);
			this.eventManager.emitEvent("backgroundImageLoadingEnd", null);
		} catch (error) {
			this.eventManager.emitEvent("backgroundImageLoadingEnd", null);
			console.error("Error loading background image:", error);
			this.setBackgroundColor(this.currentBackgroundColor);
		}
	}
	removeBackgroundImage() {
		this.setBackgroundColor(this.currentBackgroundColor);
		this.eventManager.emitEvent("backgroundImageLoadingEnd", null);
	}
	setBackgroundRenderMode(mode) {
		if (this.backgroundRenderMode === mode) return;
		this.backgroundRenderMode = mode;
		if (this.currentBackgroundType === "image" && this.backgroundTexture) try {
			if (mode === "panorama") {
				this.backgroundTexture.mapping = 303;
				this.scene.background = this.backgroundTexture;
			} else {
				this.scene.background = null;
				if (this.backgroundMesh && this.backgroundMesh.material instanceof MeshBasicMaterial) {
					this.backgroundMesh.material.map = this.backgroundTexture;
					this.backgroundMesh.material.needsUpdate = true;
				}
			}
		} catch (error) {
			console.error("Error set background render mode:", error);
		}
		this.eventManager.emitEvent("backgroundRenderModeChange", mode);
	}
	updateBackgroundSize(backgroundTexture, backgroundMesh, targetWidth, targetHeight) {
		if (!backgroundTexture || !backgroundMesh) return;
		const material = backgroundMesh.material;
		if (!material.map) return;
		const image = backgroundTexture.image;
		const imageAspect = image.width / image.height;
		const targetAspect = targetWidth / targetHeight;
		if (imageAspect > targetAspect) backgroundMesh.scale.set(imageAspect / targetAspect, 1, 1);
		else backgroundMesh.scale.set(1, targetAspect / imageAspect, 1);
		material.needsUpdate = true;
	}
	handleResize(width, height) {
		if (this.backgroundTexture && this.backgroundMesh && this.currentBackgroundType === "image") this.updateBackgroundSize(this.backgroundTexture, this.backgroundMesh, width, height);
	}
	renderBackground() {
		if ((this.backgroundRenderMode === "tiled" || this.currentBackgroundType === "color") && this.backgroundMesh) {
			const currentToneMapping = this.renderer.toneMapping;
			const currentExposure = this.renderer.toneMappingExposure;
			this.renderer.toneMapping = 0;
			this.renderer.render(this.backgroundScene, this.backgroundCamera);
			this.renderer.toneMapping = currentToneMapping;
			this.renderer.toneMappingExposure = currentExposure;
		}
	}
	getCurrentBackgroundInfo() {
		return {
			type: this.currentBackgroundType,
			value: this.currentBackgroundType === "color" ? this.currentBackgroundColor : ""
		};
	}
	async captureScene(width, height) {
		this.view.beginRender();
		const originalSize = new Vector2();
		this.renderer.getSize(originalSize);
		const originalPixelRatio = this.renderer.getPixelRatio();
		const originalClearColor = this.renderer.getClearColor(new Color());
		const originalClearAlpha = this.renderer.getClearAlpha();
		const originalOutputColorSpace = this.renderer.outputColorSpace;
		const activeCamera = this.getActiveCamera();
		const savedCameraParams = activeCamera instanceof PerspectiveCamera ? {
			type: "perspective",
			aspect: activeCamera.aspect
		} : {
			type: "orthographic",
			left: activeCamera.left,
			right: activeCamera.right,
			top: activeCamera.top,
			bottom: activeCamera.bottom
		};
		const originalMaterials = /* @__PURE__ */ new Map();
		const tempMaterials = [];
		const hiddenOverlays = [];
		const gridVisible = this.gridHelper.visible;
		const captureTarget = this.hasSplats() ? createHighPrecisionTarget(width, height) : null;
		const capturePass = (draw) => {
			this.view.bindOutput(captureTarget, width, height);
			draw();
			this.view.resolveOutput();
			return this.renderer.domElement.toDataURL("image/png");
		};
		try {
			this.renderer.setPixelRatio(1);
			this.renderer.setSize(width, height);
			if (activeCamera instanceof PerspectiveCamera) {
				activeCamera.aspect = width / height;
				activeCamera.updateProjectionMatrix();
			} else {
				const orthographicCamera = activeCamera;
				const frustumSize = 10;
				const aspect = width / height;
				orthographicCamera.left = -10 * aspect / 2;
				orthographicCamera.right = frustumSize * aspect / 2;
				orthographicCamera.top = frustumSize / 2;
				orthographicCamera.bottom = -5;
				orthographicCamera.updateProjectionMatrix();
			}
			if (this.backgroundTexture && this.backgroundMesh && this.currentBackgroundType === "image") this.updateBackgroundSize(this.backgroundTexture, this.backgroundMesh, width, height);
			const sceneData = capturePass(() => {
				this.renderer.clear();
				this.renderBackground();
				this.renderer.render(this.scene, activeCamera);
			});
			this.renderer.setClearColor(0, 0);
			const maskData = capturePass(() => {
				this.renderer.clear();
				this.renderer.render(this.scene, activeCamera);
			});
			this.scene.traverse((child) => {
				if (child instanceof Mesh) {
					originalMaterials.set(child, child.material);
					const tempMaterial = new MeshNormalMaterial({
						flatShading: false,
						side: 2,
						normalScale: new Vector2(1, 1)
					});
					tempMaterials.push(tempMaterial);
					child.material = tempMaterial;
				} else if (child instanceof QuadWireframeOverlay && child.visible) {
					hiddenOverlays.push(child);
					child.visible = false;
				}
			});
			this.gridHelper.visible = false;
			this.renderer.setClearColor(0, 1);
			const normalData = capturePass(() => {
				this.renderer.clear();
				this.renderer.render(this.scene, activeCamera);
			});
			this.renderer.setClearColor(16777215, 1);
			this.renderer.clear();
			return {
				scene: sceneData,
				mask: maskData,
				normal: normalData
			};
		} finally {
			this.view.bindOutput(null, width, height);
			captureTarget?.dispose();
			this.scene.traverse((child) => {
				if (child instanceof Mesh) {
					const originalMaterial = originalMaterials.get(child);
					if (originalMaterial) child.material = originalMaterial;
				}
			});
			for (const mat of tempMaterials) mat.dispose();
			for (const overlay of hiddenOverlays) overlay.visible = true;
			this.gridHelper.visible = gridVisible;
			if (savedCameraParams.type === "perspective") {
				const persp = activeCamera;
				persp.aspect = savedCameraParams.aspect;
				persp.updateProjectionMatrix();
			} else {
				const ortho = activeCamera;
				ortho.left = savedCameraParams.left;
				ortho.right = savedCameraParams.right;
				ortho.top = savedCameraParams.top;
				ortho.bottom = savedCameraParams.bottom;
				ortho.updateProjectionMatrix();
			}
			this.renderer.setClearColor(originalClearColor, originalClearAlpha);
			this.renderer.setPixelRatio(originalPixelRatio);
			this.renderer.setSize(originalSize.x, originalSize.y);
			this.renderer.outputColorSpace = originalOutputColorSpace;
			this.handleResize(this.view.canvas.clientWidth, this.view.canvas.clientHeight);
		}
	}
	reset() {}
};
//#endregion
//#region packages/viewport3d/src/load3d/ViewHelperManager.ts
var ViewHelperManager = class {
	viewHelper = null;
	viewHelperContainer = null;
	getActiveCamera;
	getControls;
	getCameraState;
	eventManager;
	helperCamera = new OrthographicCamera(-2, 2, 2, -2, 0, 4);
	savedViewport = new Vector4();
	constructor(_renderer, getActiveCamera, getControls, getCameraState, eventManager) {
		this.getActiveCamera = getActiveCamera;
		this.getControls = getControls;
		this.getCameraState = getCameraState;
		this.eventManager = eventManager;
		this.helperCamera.position.set(0, 0, 2);
	}
	init() {}
	render(view, size) {
		const helper = this.viewHelper;
		if (!helper) return;
		helper.quaternion.copy(this.getActiveCamera().quaternion).invert();
		helper.updateMatrixWorld();
		view.renderer.clearDepth();
		const { x, y, z, w } = view.getViewport(this.savedViewport);
		view.setViewport(0, 0, size, size);
		view.renderer.render(helper, this.helperCamera);
		view.setViewport(x, y, z, w);
	}
	dispose() {
		this.viewHelper?.dispose();
		this.viewHelperContainer?.remove();
	}
	createViewHelper(container) {
		const helperContainer = document.createElement("div");
		helperContainer.style.position = "absolute";
		helperContainer.style.bottom = "0";
		helperContainer.style.left = "0";
		helperContainer.style.width = "128px";
		helperContainer.style.height = "128px";
		helperContainer.addEventListener("pointerup", (event) => {
			event.stopPropagation();
			this.viewHelper?.handleClick(event);
		});
		helperContainer.addEventListener("pointerdown", (event) => {
			event.stopPropagation();
		});
		container.appendChild(helperContainer);
		this.viewHelperContainer = helperContainer;
		this.viewHelper = this.buildViewHelper(helperContainer);
	}
	update(delta) {
		const helper = this.viewHelper;
		if (!helper) return;
		const { animating } = helper;
		if (!animating) return;
		helper.update(delta);
		if (!helper.animating) this.eventManager.emitEvent("cameraChanged", this.getCameraState());
	}
	handleResize() {}
	visibleViewHelper(visible) {
		if (this.viewHelper) this.viewHelper.visible = visible;
		if (this.viewHelperContainer) this.viewHelperContainer.style.display = visible ? "block" : "none";
	}
	recreateViewHelper() {
		if (!this.viewHelperContainer) return;
		this.viewHelper?.dispose();
		this.viewHelper = this.buildViewHelper(this.viewHelperContainer);
	}
	buildViewHelper(container) {
		const helper = new ViewHelper(this.getActiveCamera(), container);
		helper.center = this.getControls().target;
		return helper;
	}
	reset() {}
};
//#endregion
export { ControlsManager as _, faceSizesFor as a, readFbxPolygons as c, Viewport3d as d, computeLetterboxedViewport as f, EventManager as g, LightingManager as h, QuadWireframeOverlay as i, isBinaryFbx as l, zlibSync as m, SceneManager as n, registerFaceSizes as o, isLoad3dActive as p, QuadWireframeManager as r, matchFbxPolygons as s, ViewHelperManager as t, positionAttributeOf as u, CameraManager as v, RendererView as y };
