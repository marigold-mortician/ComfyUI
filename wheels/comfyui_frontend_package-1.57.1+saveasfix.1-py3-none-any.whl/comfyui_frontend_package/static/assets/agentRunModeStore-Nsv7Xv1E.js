import "./rolldown-runtime-xtsTai4I.js";
import { C as FETCH_RESPONSE_HEADERS_TIMEOUT_MS, S as AUTH_INIT_TIMEOUT_MS, Y as authCredentialOf, i as api } from "./api-BdJmXw98.js";
import { Ft as ref, P as computed, d as defineStore } from "./vendor-vue-core-CuN1excl.js";
import { Ur as until, pr as useLocalStorage } from "./vendor-reka-ui-NRTk7aIV.js";
import { O as unknown } from "./vendor-zod-Del_rmdp.js";
import { D as zAuthTypeNotAllowedError, Ft as zWorkflowResponse, Mt as zUploadImageResponse, Q as zErrorResponse, s as zAgentCancelAccepted } from "./zod.gen-DzuaBm8H.js";
import { n as i18n } from "./i18n-BRluoVl-.js";
import { n as markErrorReported, r as reportError } from "./reportError-BHgDVvfb.js";
import { f as useApiKeyAuthStore, r as useAuthStore } from "./authStore-D2cL6XhN.js";
import { a as isDesktopHostSignedIn } from "./desktopHostSession-B3KqJnXo.js";
import { t as useAuthDialogs } from "./useAuthDialogs-C9YGTip0.js";
import { a as zAgentAnswerReceipt, c as zAgentMessages, d as zAgentTurnAccepted, f as zAttachmentRejection, l as zAgentRunMode, o as zAgentError, p as zCloudWorkflowIndex, s as zAgentIdentity, t as RENDERED_ASK_KINDS, u as zAgentThreads } from "./agentApiSchema-BSP_VZP6.js";
//#region src/platform/auth/authRejection.ts
var AUTH_REJECTION_STATUSES = [401, 403];
function isAuthRejectionStatus(status) {
	return AUTH_REJECTION_STATUSES.some((rejection) => rejection === status);
}
var OTHER = "other";
/**
* Backend values are reported only when they are on these lists, and anything
* else is `other`: the backend text is uncontrolled and can carry user,
* workspace or key identifiers, and an open value space would make the tags
* unbounded in cardinality. The generated ingest types describe these codes in
* prose only, so this is the one place they are listed.
*/
var KNOWN_AUTH_REFUSAL_CODES = [
	"UNAUTHORIZED",
	"FORBIDDEN",
	"csrf_invalid",
	"workspace_access_denied",
	"workspace_id_invalid",
	"origin_not_allowed",
	"cross_site_request"
];
var KNOWN_ACCEPTED_AUTH_METHODS = ["bearer_jwt", "x_api_key"];
/** Message phrases for the plain `{ error: string }` shape, which has no code. */
var REASON_PHRASES = [{
	phrase: "authentication method not allowed",
	reason: "auth_method_not_allowed"
}];
function isOneOf(known, value) {
	return known.some((entry) => entry === value);
}
function reasonOf(text) {
	const bounded = text.slice(0, 500).toLowerCase();
	if (bounded.trim().length === 0) return void 0;
	return REASON_PHRASES.find(({ phrase }) => bounded.includes(phrase))?.reason ?? OTHER;
}
function codeOf(code) {
	return isOneOf(KNOWN_AUTH_REFUSAL_CODES, code) ? code : OTHER;
}
function acceptedMethodsOf(accepted) {
	const methods = accepted.slice(0, 8).map((method) => isOneOf(KNOWN_ACCEPTED_AUTH_METHODS, method) ? method : OTHER);
	return methods.length > 0 ? [...new Set(methods)].join(",") : void 0;
}
/**
* The tags that tell an auth refusal's causes apart, taken from the ingest
* error shapes (`AuthTypeNotAllowedError`, `ErrorResponse`) or, for a body in
* neither, from the already-extracted message. Pure and total: any input
* yields a (possibly empty) tag set, and no value is copied from the response.
*/
function authRejectionTags(body, message) {
	const notAllowed = zAuthTypeNotAllowedError.safeParse(body).data;
	const refusal = zErrorResponse.safeParse(body).data;
	const reason = reasonOf(refusal?.message ?? message);
	const acceptedMethods = notAllowed && acceptedMethodsOf(notAllowed.accepted);
	return {
		...reason && { backendReason: reason },
		...notAllowed && { backendErrorType: notAllowed.error.type },
		...refusal && { backendErrorCode: codeOf(refusal.code) },
		...acceptedMethods && { acceptedMethods }
	};
}
//#endregion
//#region src/workbench/extensions/agent/utils/attachmentMessages.ts
var MAX_NAMED_REJECTIONS = 3;
function refusedAttachmentsMessage(names, rejectedCount = names.length) {
	const named = names.slice(0, MAX_NAMED_REJECTIONS);
	const remaining = rejectedCount - named.length;
	const name = named.length === 0 ? String(rejectedCount) : remaining > 0 ? i18n.global.t("agent.attachmentNamesOverflow", {
		names: named.join(", "),
		count: remaining
	}) : named.join(", ");
	return i18n.global.t("agent.attachmentTypeNotAccepted", { name }, rejectedCount);
}
//#endregion
//#region src/workbench/extensions/agent/services/agent/agentAuth.ts
function credentialValue(header) {
	return "X-API-KEY" in header ? header["X-API-KEY"] : header.Authorization.slice(7);
}
function isApiKeySession() {
	const authStore = useAuthStore();
	return !isDesktopHostSignedIn() && !authStore.currentUser && !authStore.sessionOnlyUser && useApiKeyAuthStore().isAuthenticated;
}
async function agentAuthHeader() {
	if (isApiKeySession()) return useApiKeyAuthStore().getAuthHeader();
	const authStore = useAuthStore();
	if (!authStore.isAuthenticated) return null;
	return { Authorization: `Bearer ${await authStore.getWorkspaceAuthTokenOrThrow()}` };
}
async function withAgentAuth(init) {
	const header = await agentAuthHeader();
	if (!header) return init;
	const headers = new Headers(init.headers);
	for (const [name, value] of Object.entries(header)) headers.set(name, value);
	const attached = authCredentialOf(header);
	return {
		...init,
		headers,
		redirect: "error",
		onAuthScheme: () => init.onAuthScheme?.("cloud-auth-header"),
		onAuthCredential: () => init.onAuthCredential?.(attached)
	};
}
async function agentSocketAuthParams() {
	const params = new URLSearchParams();
	const header = await agentAuthHeader();
	if (header) params.set("token", credentialValue(header));
	return params;
}
function hasAgentCredential() {
	return useAuthStore().isAuthenticated || useApiKeyAuthStore().getAuthHeader() !== null;
}
function devProxySuppliesCredential() {
	return false;
}
async function ensureSignedIn() {
	const authStore = useAuthStore();
	if (await authStore.getUserAuthHeader()) return true;
	if (devProxySuppliesCredential()) return true;
	try {
		if (!await useAuthDialogs().showSignInDialog()) return false;
	} catch {
		return false;
	}
	return hasAgentCredential() || await authStore.getUserAuthHeader() !== null;
}
//#endregion
//#region src/workbench/extensions/agent/services/agent/agentRestClient.ts
var LIST_PAGE_SIZE = 100;
/**
* PM-1658: tightens `fetchApi`'s shared 60s header deadline for the one
* request an ask card's Submit waits on, since the card is held disabled
* from the click until this settles. A quarter of it, rather than merely lower, so that
* the caller's single re-drive still fits inside the 60s the card used to be
* able to wait. Goes through `timeoutMs` rather than a raw signal so a timeout
* still raises fetchApi's own telemetry.
*/
var ANSWER_ASK_TIMEOUT_MS = 15e3;
/**
* The reported message for an auth rejection, constant by construction.
*
* The backend's own text is what `AgentApiError` carries to the caller, but it
* is not the Sentry message: it is uncontrolled and varies enough to fragment
* issue grouping across what is one failure mode. Status, operation, auth
* scheme, credential kind and an allowlisted classification of the backend's
* refusal ride as tags.
*/
var AUTH_REJECTED_MESSAGE = "Agent API request rejected by authentication";
function reportAuthRejection({ status, operation, authScheme, credential, body, message }) {
	let backendTags;
	try {
		backendTags = authRejectionTags(body, message);
	} catch {
		backendTags = {};
	}
	try {
		reportError(/* @__PURE__ */ new Error(AUTH_REJECTED_MESSAGE), {
			surface: "agent",
			errorType: "agent_api_auth_rejected",
			tags: {
				operation,
				status,
				authScheme,
				credential,
				...backendTags
			},
			level: "warning"
		});
		return true;
	} catch {
		return false;
	}
}
var AgentApiError = class extends Error {
	status;
	body;
	retryAfterSeconds;
	/** The {@link AgentApiOperation} that raised this error. */
	operation;
	constructor(message, status, body, retryAfterSeconds, operation) {
		super(message.trim().length > 0 ? message : `Agent request failed (HTTP ${status})`);
		this.name = "AgentApiError";
		this.status = status;
		this.body = body;
		this.retryAfterSeconds = retryAfterSeconds;
		this.operation = operation;
	}
};
var AgentResponseUnreadableError = class extends Error {
	constructor(cause) {
		super("Unreadable agent response body", { cause });
		this.name = "AgentResponseUnreadableError";
	}
};
var CLIENT_VERSION = `1.59.1+1a2e6b01c114f0cd905ad8372286653ebff58e92`;
/**
* Drops keys whose value is `undefined` so an absent optional is omitted from the
* JSON body rather than sent as an explicit null-ish key. `false` and `0` are
* values and survive - `current_tab_unbound: false` is a meaningful signal, so
* this filters on `undefined` exactly, never on falsiness.
*/
function withoutUndefined(fields) {
	return Object.fromEntries(Object.entries(fields).filter(([, value]) => value !== void 0));
}
function isIngestErrorBody(body) {
	if (typeof body !== "object" || body === null) return false;
	const { error } = body;
	return typeof error === "object" && error !== null && typeof error.message === "string";
}
function parseErrorBody(text) {
	if (text.length === 0) return void 0;
	try {
		return JSON.parse(text);
	} catch {
		return;
	}
}
function getBackendErrorMessage(body) {
	const plain = zAgentError.safeParse(body);
	if (plain.success) return typeof plain.data.error === "string" ? plain.data.error : plain.data.error.message;
	return isIngestErrorBody(body) ? body.error.message : void 0;
}
function getErrorMessage(body, status, operation, statusText) {
	const refused = zAttachmentRejection.safeParse(body);
	if (refused.success) return refusedAttachmentsMessage(refused.data.rejected, refused.data.rejected_count);
	const backendMessage = getBackendErrorMessage(body);
	const normalizedStatusText = statusText.trim().slice(0, 80);
	const statusTextSuffix = !normalizedStatusText || normalizedStatusText.toLowerCase() === "no error message" ? "" : ` ${normalizedStatusText}`;
	return backendMessage?.trim() ? backendMessage : `Agent request failed (HTTP ${status}${statusTextSuffix}, ${operation})`;
}
var DAY_NAME = "Mon|Tue|Wed|Thu|Fri|Sat|Sun";
var DAY_NAME_LONG = "Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday";
var MONTHS = [
	"Jan",
	"Feb",
	"Mar",
	"Apr",
	"May",
	"Jun",
	"Jul",
	"Aug",
	"Sep",
	"Oct",
	"Nov",
	"Dec"
];
var MONTH = MONTHS.join("|");
var TIME_OF_DAY = "(\\d{2}):(\\d{2}):(\\d{2})";
var IMF_FIXDATE = new RegExp(`^(?:${DAY_NAME}), (\\d{2}) (${MONTH}) (\\d{4}) ${TIME_OF_DAY} GMT$`);
var RFC850_DATE = new RegExp(`^(?:${DAY_NAME_LONG}), (\\d{2})-(${MONTH})-(\\d{2}) ${TIME_OF_DAY} GMT$`);
var ASCTIME_DATE = new RegExp(`^(?:${DAY_NAME}) (${MONTH}) (\\d{2}| \\d) ${TIME_OF_DAY} (\\d{4})$`);
function monthNumber(name) {
	return MONTHS.indexOf(name) + 1;
}
function httpDateInstant(year, month, day, hour, minute, second) {
	return Date.UTC(year, month - 1, day, hour, minute, Math.min(second, 59)) + (second === 60 ? 1e3 : 0);
}
function hasValidHttpDateFields(fields) {
	const { year, hour, minute, second } = fields;
	return year >= 1900 && hour <= 23 && minute <= 59 && second <= 60;
}
function namesRealCalendarDate(fields, instant) {
	const { year, month, day, second } = fields;
	const utc = /* @__PURE__ */ new Date(instant - (second === 60 ? 1e3 : 0));
	return utc.getUTCFullYear() === year && utc.getUTCMonth() === month - 1 && utc.getUTCDate() === day;
}
/**
* The four-digit year an RFC 850 two-digit year stands for. RFC 9110 requires a
* timestamp that would read as more than 50 years in the future to be taken as
* the most recent past year with those last two digits, which is a rolling
* window rather than the fixed pivot `Date.parse` applies.
*/
function expandTwoDigitYear(twoDigit, month, day, hour, minute, second) {
	const now = new Date(Date.now());
	const candidateYear = Math.floor(now.getUTCFullYear() / 100) * 100 + twoDigit;
	const fiftyYearsFromNow = Date.UTC(now.getUTCFullYear() + 50, now.getUTCMonth(), now.getUTCDate(), now.getUTCHours(), now.getUTCMinutes(), now.getUTCSeconds(), now.getUTCMilliseconds());
	for (const year of [candidateYear + 100, candidateYear]) if (httpDateInstant(year, month, day, hour, minute, second) <= fiftyYearsFromNow) return year;
	return candidateYear - 100;
}
function httpDateFields(value) {
	const imf = IMF_FIXDATE.exec(value);
	if (imf) return {
		year: Number(imf[3]),
		month: monthNumber(imf[2]),
		day: Number(imf[1]),
		hour: Number(imf[4]),
		minute: Number(imf[5]),
		second: Number(imf[6])
	};
	const rfc850 = RFC850_DATE.exec(value);
	if (rfc850) {
		const month = monthNumber(rfc850[2]);
		const day = Number(rfc850[1]);
		const hour = Number(rfc850[4]);
		const minute = Number(rfc850[5]);
		const second = Number(rfc850[6]);
		return {
			year: expandTwoDigitYear(Number(rfc850[3]), month, day, hour, minute, second),
			month,
			day,
			hour,
			minute,
			second
		};
	}
	const asctime = ASCTIME_DATE.exec(value);
	if (asctime) return {
		year: Number(asctime[6]),
		month: monthNumber(asctime[1]),
		day: Number(asctime[2].trim()),
		hour: Number(asctime[3]),
		minute: Number(asctime[4]),
		second: Number(asctime[5])
	};
}
/**
* The instant an RFC 9110 `HTTP-date` names, or `undefined` when the value is
* not one of the three formats that grammar allows (IMF-fixdate, RFC 850,
* asctime) or names no real date.
*
* The components are read and checked here rather than handed to `Date.parse`,
* which accepts far more than the grammar - an ISO-8601 local timestamp such as
* `2099-12-31T00:00:00` among them - and whose handling of these pre-ISO
* formats is implementation-defined: V8 rolls `29 Feb 2023` forward to March 1,
* reads `24:00:00` as the next day, and applies a fixed two-digit-year pivot
* rather than the rolling one RFC 9110 mandates. Calendar and time fields are
* validated, and all three formats name a UTC instant (asctime carries no zone
* but is defined as UTC), so the result no longer varies with the engine or the
* host zone.
*
* Deliberately lenient about `day-name`: RFC 9110 asks recipients to be robust,
* so a weekday that disagrees with the date is ignored rather than rejected.
*/
function parseHttpDate(value) {
	const fields = httpDateFields(value);
	if (fields === void 0) return void 0;
	if (!hasValidHttpDateFields(fields)) return void 0;
	const { year, month, day, hour, minute, second } = fields;
	const instant = httpDateInstant(year, month, day, hour, minute, second);
	return namesRealCalendarDate(fields, instant) ? instant : void 0;
}
function parseRetryAfter(header) {
	if (header === null) return void 0;
	if (/^\d+$/.test(header)) return asDelaySeconds(Number(header));
	if (Number.isFinite(Number(header))) return void 0;
	const deadline = parseHttpDate(header);
	if (deadline === void 0) return void 0;
	return asDelaySeconds(Math.max(0, Math.ceil((deadline - Date.now()) / 1e3)));
}
function asDelaySeconds(seconds) {
	return Number.isSafeInteger(seconds) && seconds >= 0 ? seconds : void 0;
}
function getNextPageCursor(cursor, seenCursors) {
	if (!cursor) return {
		ok: false,
		reason: "missing_cursor"
	};
	if (seenCursors.has(cursor)) return {
		ok: false,
		reason: "repeated_cursor"
	};
	return {
		ok: true,
		cursor
	};
}
function createAgentRestClient() {
	async function toApiError(response, operation, authScheme, credential) {
		const body = parseErrorBody(await response.text());
		const backendMessage = getBackendErrorMessage(body);
		const message = getErrorMessage(body, response.status, operation, response.statusText);
		const retryAfterSeconds = parseRetryAfter(response.headers.get("Retry-After"));
		const apiError = new AgentApiError(message, response.status, body, retryAfterSeconds, operation);
		if (isAuthRejectionStatus(response.status) && reportAuthRejection({
			status: response.status,
			operation,
			authScheme,
			credential,
			body,
			message: backendMessage ?? ""
		})) markErrorReported(apiError);
		return apiError;
	}
	async function requestResult(operation, route, init, schema) {
		let authScheme = "unreported";
		let credential = "unreported";
		let response;
		try {
			response = await api.fetchApi(route, await withAgentAuth({
				...init,
				onAuthScheme: (scheme) => {
					authScheme = scheme;
				},
				onAuthCredential: (kind) => {
					credential = kind;
				}
			}));
		} catch (cause) {
			return {
				ok: false,
				cause
			};
		}
		if (!response.ok) try {
			return {
				ok: false,
				cause: await toApiError(response, operation, authScheme, credential)
			};
		} catch (cause) {
			return {
				ok: false,
				cause
			};
		}
		let payload;
		try {
			payload = await response.json();
		} catch (cause) {
			return {
				ok: false,
				cause: cause instanceof SyntaxError ? new AgentResponseUnreadableError(cause) : cause
			};
		}
		const parsed = schema.safeParse(payload);
		return parsed.success ? {
			ok: true,
			value: parsed.data
		} : {
			ok: false,
			cause: parsed.error
		};
	}
	async function request(operation, route, init, schema) {
		const result = await requestResult(operation, route, init, schema);
		if (!result.ok) throw result.cause;
		return result.value;
	}
	function jsonInit(method, body) {
		return {
			method,
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(body)
		};
	}
	async function listAllPages(operation, path, schema, itemsOf, signal) {
		const items = [];
		let cursor;
		let hasMore;
		const seenCursors = /* @__PURE__ */ new Set();
		do {
			const after = cursor ? `&after=${encodeURIComponent(cursor)}` : "";
			const result = await requestResult(operation, `${path}${path.includes("?") ? "&" : "?"}limit=${LIST_PAGE_SIZE}${after}`, {
				method: "GET",
				signal
			}, schema);
			if (signal?.aborted) return {
				ok: false,
				cause: signal.reason
			};
			if (!result.ok) return result;
			const page = result.value;
			items.push(...itemsOf(page));
			hasMore = page.pagination.has_more;
			if (hasMore) {
				const next = getNextPageCursor(page.pagination.next_cursor, seenCursors);
				if (!next.ok) return {
					ok: true,
					value: {
						items,
						stopReason: next.reason
					}
				};
				seenCursors.add(next.cursor);
				cursor = next.cursor;
			}
		} while (hasMore);
		return {
			ok: true,
			value: { items }
		};
	}
	async function postMessage(threadId, req) {
		const body = withoutUndefined({
			content: req.content,
			ask_kinds: [...RENDERED_ASK_KINDS],
			workflow_id: req.workflowId,
			open_tabs: req.tabs?.open_tabs,
			current_tab: req.tabs?.current_tab,
			workflow_references: req.workflowReferences,
			selection: req.selection,
			attachments: req.attachments,
			draft: req.draft && { content: req.draft.content },
			current_tab_unbound: req.currentTabUnbound,
			client_message_id: req.clientMessageId,
			client_id: api.clientId,
			client_version: CLIENT_VERSION
		});
		return request("post_thread_message", `/agent/threads/${encodeURIComponent(threadId)}/messages`, jsonInit("POST", body), zAgentTurnAccepted);
	}
	async function getMessages(threadId, options = {}) {
		return request("get_thread_messages", `/agent/threads/${encodeURIComponent(threadId)}/messages`, {
			method: "GET",
			signal: options.signal
		}, zAgentMessages);
	}
	async function listThreads(options = {}) {
		if (options.signal?.aborted) return { status: "aborted" };
		const result = await listAllPages("list_threads", `/agent/threads${options.workflowId === void 0 ? "" : `?workflow_id=${encodeURIComponent(options.workflowId)}`}`, zAgentThreads, (page) => page.threads, options.signal);
		if (options.signal?.aborted) return { status: "aborted" };
		if (!result.ok) return {
			status: "failed",
			cause: result.cause
		};
		const { items, stopReason } = result.value;
		return stopReason ? {
			status: "incomplete",
			reason: stopReason
		} : {
			status: "complete",
			threads: items
		};
	}
	async function getIdentity() {
		return { userId: (await request("get_agent_identity", "/agent/identity", { method: "GET" }, zAgentIdentity)).user_id };
	}
	async function getRunMode() {
		return request("get_run_mode", "/agent/run-mode", { method: "GET" }, zAgentRunMode);
	}
	async function putRunMode(preference) {
		return request("put_run_mode", "/agent/run-mode", jsonInit("PUT", preference), zAgentRunMode);
	}
	async function listCloudWorkflows() {
		const result = await listAllPages("list_cloud_workflows", "/workflows", zCloudWorkflowIndex, (page) => page.data);
		if (!result.ok) throw result.cause;
		const { items, stopReason } = result.value;
		return {
			entries: items,
			complete: stopReason === void 0
		};
	}
	async function getCloudWorkflow(workflowId) {
		return request("get_cloud_workflow", `/workflows/${encodeURIComponent(workflowId)}`, { method: "GET" }, zWorkflowResponse);
	}
	async function cancelMessage(threadId, messageId) {
		return request("cancel_thread_message", `/agent/threads/${encodeURIComponent(threadId)}/messages/${encodeURIComponent(messageId)}/cancel`, jsonInit("POST", {}), zAgentCancelAccepted);
	}
	async function answerAsk(threadId, askId, answer) {
		return request("answer_thread_ask", `/agent/threads/${encodeURIComponent(threadId)}/asks/${encodeURIComponent(askId)}/answer`, {
			...jsonInit("POST", answer),
			timeoutMs: ANSWER_ASK_TIMEOUT_MS
		}, zAgentAnswerReceipt);
	}
	async function refreshCredential() {
		await request("refresh_credential", "/agent/threads?limit=1", { method: "GET" }, unknown());
	}
	async function uploadImage(image, filename, signal) {
		const form = new FormData();
		form.append("image", image, filename);
		return request("upload_image", "/upload/image", {
			method: "POST",
			body: form,
			signal,
			timeoutMs: signal ? null : void 0
		}, zUploadImageResponse);
	}
	return {
		postMessage,
		getMessages,
		listThreads,
		getIdentity,
		getRunMode,
		putRunMode,
		listCloudWorkflows,
		getCloudWorkflow,
		cancelMessage,
		answerAsk,
		refreshCredential,
		uploadImage
	};
}
/**
* Deliberately longer than every path that can still deliver the POST, so the
* backstop cannot release the gate while the message is still on its way and
* let a run-mode write overtake it.
*
* DERIVED rather than transcribed, because a hand-summed 150s here sat BELOW
* its own window: 3s of prepare + 10s of auth init + 60s + a 15s remint + a
* second 60s is 148s, and a slower remint makes it 163s, so a retried POST
* could land after the backstop had already let a parked PUT through — the
* PM-1660 ordering again.
*
* Past this the only unbounded case left is a stalled response BODY, and
* headers having arrived means the server already ran `resolveRunMode`: cloud
* `services/agent/server/agent_handler.go` pins the turn's mode inside
* `postMessage` before it writes `202 Accepted`. The ordering this gate
* protects is settled by then, so releasing is safe.
*/
var MAX_HOLD_MS = AUTH_INIT_TIMEOUT_MS + 2 * FETCH_RESPONSE_HEADERS_TIMEOUT_MS + 3e4 + 3e4;
/**
* Counts the messages currently on their way to the server: held from entry to
* useAgentSession.sendMessage until the POST that carries the message has
* settled.
*
* NOT from the send click, and the gap is not nothing.
* useAgentDraftSubmission.submit clears the draft before it calls `send`, so
* anything AgentPanelRoot awaits in between runs with the composer already
* looking sent and no hold taken — on main that is the first-message consent
* check and the coach tour it waits on. A mode picked inside that window still
* precedes the POST. It is one consent round trip on an account's first
* message; closing it means taking the hold at startSubmission and passing the
* release through.
*
* It exists because that window is not visible anywhere else. The composer's
* submission looks like it, but New Chat and switching threads both clear it
* (agentComposerStore.invalidateSubmission) while the POST is still in flight —
* and neither cancels the turn. The POST keeps running server-side and keeps
* spending; what is discarded is the client's view of it, since
* stashActiveTurn() has no slot to stash before the ack and performSend's
* generation check drops the late one. Anything that must not overtake a sent
* message has to track the request, not the draft it came from (PM-1660).
*
* It orders writes from THIS page only. The server resolves run mode per
* user, so a second tab's write is ordered against its own sends and can
* still overtake this one's — closing that needs the ordering point to move
* to the server, which is where the mode is pinned.
*
* And a hold ends on ANY settle, including a client-side abort: a headers
* timeout or a network error releases it, which does not prove the server
* discarded a request it may already have queued. Unresolved deliberately —
* it turns on whether cloud cancels on client disconnect, which needs an
* experiment against the service rather than a reading of this file, and
* holding on every ambiguous failure would change behaviour for every failed
* send.
*/
var useAgentSendGateStore = defineStore("agentSendGate", () => {
	const inFlight = ref(0);
	/**
	* Marks one message as on its way and returns ITS release. The release is
	* single-use, so a caller cannot decrement a hold it does not own, and it
	* fires on its own after MAX_HOLD_MS, so a send that never settles cannot
	* strand the gate. Both matter: `isSending` reading false during a live send
	* silently reopens the ordering hole this store exists to close.
	*/
	function begin() {
		inFlight.value += 1;
		let released = false;
		const release = () => {
			if (released) return;
			released = true;
			clearTimeout(backstop);
			inFlight.value = Math.max(0, inFlight.value - 1);
		};
		const backstop = setTimeout(release, MAX_HOLD_MS);
		return release;
	}
	return {
		isSending: computed(() => inFlight.value > 0),
		begin
	};
});
//#endregion
//#region src/workbench/extensions/agent/stores/agent/agentRunModeStore.ts
var DEFAULT_PREFERENCE = {
	mode: "ask_approval",
	credit_limit: null
};
var DEFAULT_CREDIT_LIMIT = 300;
var PREFERENCE_STORAGE_KEY = "Comfy.Agent.RunModePreference";
var LEGACY_MODE_STORAGE_KEY = "Comfy.Agent.RunMode";
var LEGACY_CREDIT_LIMIT_STORAGE_KEY = "Comfy.Agent.RunCreditLimit";
function migrateLegacyPreference() {
	const storedPreference = localStorage.getItem(PREFERENCE_STORAGE_KEY);
	const legacyMode = localStorage.getItem(LEGACY_MODE_STORAGE_KEY);
	const legacyCreditLimit = localStorage.getItem(LEGACY_CREDIT_LIMIT_STORAGE_KEY);
	let canRemoveLegacy = storedPreference !== null;
	if (storedPreference === null && legacyMode !== null) {
		const mode = {
			ask: "ask_approval",
			auto: "auto",
			"auto-limit": "auto_limited"
		}[legacyMode];
		const parsedCreditLimit = Number(legacyCreditLimit);
		const creditLimit = legacyCreditLimit !== null && legacyCreditLimit !== "" && Number.isInteger(parsedCreditLimit) && parsedCreditLimit > 0 ? parsedCreditLimit : DEFAULT_CREDIT_LIMIT;
		const migrated = zAgentRunMode.safeParse({
			mode,
			credit_limit: mode === "auto_limited" ? creditLimit : null
		});
		if (migrated.success) {
			localStorage.setItem(PREFERENCE_STORAGE_KEY, JSON.stringify(migrated.data));
			canRemoveLegacy = true;
		}
	}
	if (canRemoveLegacy && (legacyMode !== null || legacyCreditLimit !== null)) {
		localStorage.removeItem(LEGACY_MODE_STORAGE_KEY);
		localStorage.removeItem(LEGACY_CREDIT_LIMIT_STORAGE_KEY);
	}
}
var useAgentRunModeStore = defineStore("agentRunMode", () => {
	const api = createAgentRestClient();
	migrateLegacyPreference();
	const preference = useLocalStorage(PREFERENCE_STORAGE_KEY, DEFAULT_PREFERENCE, { serializer: {
		read: (value) => {
			try {
				return zAgentRunMode.catch(DEFAULT_PREFERENCE).parse(JSON.parse(value));
			} catch {
				return DEFAULT_PREFERENCE;
			}
		},
		write: JSON.stringify
	} });
	const mode = computed(() => preference.value.mode);
	const creditLimit = computed(() => preference.value.credit_limit);
	let saveRevision = 0;
	let appliedSaveRevision = 0;
	function apply(nextPreference) {
		preference.value = nextPreference;
	}
	function localPreference() {
		const parsed = zAgentRunMode.safeParse(preference.value);
		if (parsed.success) return parsed.data;
		apply(DEFAULT_PREFERENCE);
		return DEFAULT_PREFERENCE;
	}
	async function load() {
		const revision = saveRevision;
		const appliedRevision = appliedSaveRevision;
		try {
			const serverPreference = await api.getRunMode();
			if (revision === saveRevision && appliedRevision === appliedSaveRevision) apply(serverPreference);
		} catch (error) {
			if (!(error instanceof AgentApiError && error.status === 404)) throw error;
			localPreference();
		}
	}
	async function save(nextMode, nextLimit) {
		const next = zAgentRunMode.parse({
			mode: nextMode,
			credit_limit: nextLimit
		});
		const revision = ++saveRevision;
		const applySaved = (savedPreference) => {
			if (revision <= appliedSaveRevision) return;
			appliedSaveRevision = revision;
			apply(savedPreference);
		};
		try {
			const sendGate = useAgentSendGateStore();
			if (sendGate.isSending) await until(() => sendGate.isSending).toBe(false);
			if (revision !== saveRevision) return;
			applySaved(await api.putRunMode(next));
		} catch (error) {
			if (!(error instanceof AgentApiError && error.status === 404)) throw error;
			applySaved(next);
		}
	}
	localPreference();
	return {
		mode,
		creditLimit,
		load,
		save
	};
});
//#endregion
export { createAgentRestClient as a, hasAgentCredential as c, AgentResponseUnreadableError as i, useAgentSendGateStore as n, agentSocketAuthParams as o, AgentApiError as r, ensureSignedIn as s, useAgentRunModeStore as t };
