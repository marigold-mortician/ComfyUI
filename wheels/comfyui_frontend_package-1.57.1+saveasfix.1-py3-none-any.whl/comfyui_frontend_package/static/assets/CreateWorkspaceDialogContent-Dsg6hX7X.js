import "./rolldown-runtime-xtsTai4I.js";
import { t as useTeamWorkspaceStore } from "./teamWorkspaceStore-BNm5cZOK.js";
import { C as vModelText, F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, I as createBlock, P as computed, T as withKeys, Tt as withDirectives, U as createVNode, Yt as toDisplayString, ct as openBlock, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as useToast } from "./toastStore-Dg65fRgL.js";
import { t as getErrorMessage } from "./errorUtil-DoQyAUQC.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
import { t as AppDialogPanel_default } from "./AppDialogPanel-BklaJBTn.js";
//#region src/platform/workspace/components/dialogs/CreateWorkspaceDialogContent.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "m-0 text-sm text-muted-foreground" };
var _hoisted_2 = { class: "flex flex-col gap-2 text-sm" };
var _hoisted_3 = { class: "text-muted-foreground" };
var _hoisted_4 = ["placeholder"];
//#endregion
//#region src/platform/workspace/components/dialogs/CreateWorkspaceDialogContent.vue
var CreateWorkspaceDialogContent_default = /* @__PURE__ */ defineComponent({
	__name: "CreateWorkspaceDialogContent",
	props: { onConfirm: { type: Function } },
	setup(__props) {
		const { t } = useI18n();
		const dialogStore = useDialogStore();
		const toast = useToast();
		const workspaceStore = useTeamWorkspaceStore();
		const loading = ref(false);
		const workspaceName = ref("");
		const isValidName = computed(() => {
			const name = workspaceName.value.trim();
			return name.length >= 1 && name.length <= 50 && /^[a-zA-Z0-9][a-zA-Z0-9\s\-_'.,()&+]*$/.test(name);
		});
		function onCancel() {
			dialogStore.closeDialog({ key: "create-workspace" });
		}
		async function onCreate() {
			if (!isValidName.value) return;
			loading.value = true;
			try {
				const name = workspaceName.value.trim();
				await __props.onConfirm?.(name);
				dialogStore.closeDialog({ key: "create-workspace" });
				await workspaceStore.createWorkspace(name);
			} catch (error) {
				console.error("[CreateWorkspaceDialog] Failed to create workspace:", error);
				toast.error(t("workspacePanel.toast.failedToCreateWorkspace"), { description: getErrorMessage(error) ?? t("g.unknownError") });
			} finally {
				loading.value = false;
			}
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(AppDialogPanel_default, {
				"body-class": "flex flex-col gap-4",
				onClose: onCancel
			}, {
				title: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.createWorkspaceDialog.title")), 1)]),
				footer: withCtx(() => [createVNode(Button_default, {
					variant: "muted-textonly",
					onClick: onCancel
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("g.cancel")), 1)]),
					_: 1
				}), createVNode(Button_default, {
					variant: "primary",
					size: "lg",
					loading: loading.value,
					disabled: !isValidName.value,
					onClick: onCreate
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.createWorkspaceDialog.create")), 1)]),
					_: 1
				}, 8, ["loading", "disabled"])]),
				default: withCtx(() => [createBaseVNode("p", _hoisted_1, toDisplayString(_ctx.$t("workspacePanel.createWorkspaceDialog.message")), 1), createBaseVNode("div", _hoisted_2, [createBaseVNode("label", _hoisted_3, toDisplayString(_ctx.$t("workspacePanel.createWorkspaceDialog.nameLabel")), 1), withDirectives(createBaseVNode("input", {
					"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => workspaceName.value = $event),
					type: "text",
					class: "h-10 w-full rounded-lg border-none bg-secondary px-4 placeholder:text-muted-foreground focus:ring-1 focus:ring-ring focus:outline-none",
					placeholder: _ctx.$t("workspacePanel.createWorkspaceDialog.namePlaceholder"),
					onKeydown: _cache[1] || (_cache[1] = withKeys(($event) => isValidName.value && onCreate(), ["enter"]))
				}, null, 40, _hoisted_4), [[vModelText, workspaceName.value]])])]),
				_: 1
			});
		};
	}
});
//#endregion
export { CreateWorkspaceDialogContent_default as default };
