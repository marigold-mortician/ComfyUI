import "./rolldown-runtime-xtsTai4I.js";
import { G as defineComponent, Kt as normalizeClass, R as createElementBlock, Wt as unref, ct as openBlock } from "./vendor-vue-core-CuN1excl.js";
import { t as cn } from "./src-BHQtMnZc.js";
//#endregion
//#region src/components/ui/skeleton/Skeleton.vue
var Skeleton_default = /* @__PURE__ */ defineComponent({
	__name: "Skeleton",
	props: { class: { type: [
		Boolean,
		null,
		String,
		Object,
		Array
	] } },
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				"data-slot": "skeleton",
				class: normalizeClass(unref(cn)("animate-pulse rounded-md bg-secondary", __props.class))
			}, null, 2);
		};
	}
});
//#endregion
export { Skeleton_default as t };
