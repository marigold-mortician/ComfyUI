import "./rolldown-runtime-xtsTai4I.js";
import { G as defineComponent, I as createBlock, Wt as unref, ct as openBlock, dt as renderSlot, et as mergeProps, wt as withCtx, z as createPropsRestProxy } from "./vendor-vue-core-CuN1excl.js";
import { Sn as DialogDescription_default$1 } from "./vendor-reka-ui-NRTk7aIV.js";
import { t as cn } from "./src-BHQtMnZc.js";
//#endregion
//#region src/components/ui/dialog/DialogDescription.vue
var DialogDescription_default = /* @__PURE__ */ defineComponent({
	__name: "DialogDescription",
	props: {
		asChild: { type: Boolean },
		as: {},
		class: {
			type: [
				Boolean,
				null,
				String,
				Object,
				Array
			],
			default: ""
		}
	},
	setup(__props) {
		const delegated = createPropsRestProxy(__props, ["class"]);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(DialogDescription_default$1), mergeProps(delegated, { class: unref(cn)("text-sm text-muted-foreground", __props.class) }), {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
				_: 3
			}, 16, ["class"]);
		};
	}
});
//#endregion
export { DialogDescription_default as t };
