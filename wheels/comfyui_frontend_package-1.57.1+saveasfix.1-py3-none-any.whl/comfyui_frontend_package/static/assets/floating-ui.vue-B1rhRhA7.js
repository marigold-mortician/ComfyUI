import "./rolldown-runtime-xtsTai4I.js";
import { c as useSubgraphNavigationStore } from "./appModeStore-C3kEWkI2.js";
import { Nt as graphScopeOf, Tt as isSelectedIn, ct as registerNodeEmphasisQuery, sn as toSelectableKey } from "./litegraph-DsPnoImk.js";
import { t as TimeoutError } from "./TimeoutError-DBgma3uz.js";
import { t as debounce } from "./debounce-CrddqoI1.js";
import { t as useTeamWorkspaceStore } from "./teamWorkspaceStore-BNm5cZOK.js";
import { E as withModifiers, F as createBaseVNode, Ft as ref, G as defineComponent, Ht as toValue$1, I as createBlock, It as shallowReactive, Kt as normalizeClass, L as createCommentVNode, Lt as shallowReadonly, Mt as onScopeDispose, P as computed, Pt as readonly, R as createElementBlock, Rt as shallowRef, Wt as unref, Yt as toDisplayString, bt as watch, ct as openBlock, dt as renderSlot, et as mergeProps, kt as getCurrentScope, tt as nextTick, wt as withCtx, z as createPropsRestProxy } from "./vendor-vue-core-CuN1excl.js";
import { Mn as useForwardPropsEmits, Tr as useResizeObserver, an as computePosition, br as useMutationObserver, ln as getNodeName, un as isNode, xt as DropdownMenuItem_default } from "./vendor-reka-ui-NRTk7aIV.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { r as reportError } from "./reportError-BHgDVvfb.js";
import { r as menuItemClass } from "./menuStyles-BC25qUwO.js";
import { g as getNodeByExecutionId } from "./graphTraversalUtil-BUK1cr2m.js";
import { i as visibleCanvasViewport, n as useCanvasStore } from "./canvasStore-siYzI5aT.js";
import { t as useCurrentUser } from "./useCurrentUser-DjJaVYwd.js";
import { n as app } from "./app-C-5f0uvA.js";
import { r as tagVariants, t as TagRemoveButton_default } from "./TagRemoveButton-DmMMh2ek.js";
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/promise/timeout.mjs
/**
* Returns a promise that rejects with a `TimeoutError` after a specified delay.
*
* You can pass an `AbortSignal` to cancel the timeout. Unlike most `AbortSignal`-aware
* APIs, aborting does **not** reject the promise. A `timeout` only exists to lose a
* `Promise.race`, so cancelling it leaves the promise pending forever, allowing the
* operation it guards to settle on its own. The underlying timer and abort listener
* are cleared on abort, so nothing is leaked.
*
* @param ms - The delay duration in milliseconds.
* @param options - The options object.
* @param options.signal - An optional AbortSignal to cancel the timeout. When aborted, the returned promise never settles.
* @returns A promise that rejects with a `TimeoutError` after the specified delay, or never settles if aborted.
* @throws {TimeoutError} Throws a `TimeoutError` after the specified delay.
*
* @example
* try {
*   await timeout(1000); // Timeout exception after 1 second
* } catch (error) {
*   console.error(error); // Will log 'The operation was timed out'
* }
*
* @example
* // Cancelling the timeout lifts the time limit instead of throwing.
* const controller = new AbortController();
* setTimeout(() => controller.abort(), 50);
*
* const result = await Promise.race([
*   doWork(),
*   timeout(1000, { signal: controller.signal }), // never rejects once aborted
* ]);
*/
function timeout(ms, { signal } = {}) {
	return new Promise((_resolve, reject) => {
		const abortHandler = () => {
			clearTimeout(timeoutId);
		};
		if (signal?.aborted) return;
		const timeoutId = setTimeout(() => {
			signal?.removeEventListener("abort", abortHandler);
			reject(new TimeoutError());
		}, ms);
		signal?.addEventListener("abort", abortHandler, { once: true });
	});
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/promise/withTimeout.mjs
/**
* Executes an async function and enforces a timeout.
*
* If the promise does not resolve within the specified time,
* the timeout will trigger and the returned promise will be rejected.
*
* You can pass an `AbortSignal` to cancel the timeout. Aborting the signal lifts the
* time limit: the timeout stops counting and `run`'s promise is awaited without a
* deadline. It does not reject the returned promise or abort `run` itself — pass the
* same signal into `run` if you also want to cancel the underlying work.
*
* @template T
* @param run - A function that returns a promise to be executed.
* @param ms - The timeout duration in milliseconds.
* @param options - The options object.
* @param options.signal - An optional AbortSignal to cancel the timeout. When aborted, the time limit is lifted.
* @returns A promise that resolves with the result of the `run` function or rejects if the timeout is reached.
*
* @example
* async function fetchData() {
*   const response = await fetch('https://example.com/data');
*   return response.json();
* }
*
* try {
*   const data = await withTimeout(fetchData, 1000);
*   console.log(data); // Logs the fetched data if `fetchData` is resolved within 1 second.
* } catch (error) {
*   console.error(error); // Will log 'TimeoutError' if `fetchData` is not resolved within 1 second.
* }
*
* @example
* // Lift the time limit when the user opts to keep waiting.
* const controller = new AbortController();
* keepWaitingButton.onclick = () => controller.abort();
*
* const data = await withTimeout(fetchData, 1000, { signal: controller.signal });
*/
async function withTimeout(run, ms, { signal } = {}) {
	return Promise.race([run(), timeout(ms, { signal })]);
}
//#endregion
//#region src/components/ui/menu/MenuItem.vue
var MenuItem_default = /* @__PURE__ */ defineComponent({
	__name: "MenuItem",
	props: {
		disabled: { type: Boolean },
		textValue: {},
		asChild: { type: Boolean },
		as: {},
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	},
	emits: ["select"],
	setup(__props, { emit: __emit }) {
		const restProps = createPropsRestProxy(__props, ["class"]);
		const forwarded = useForwardPropsEmits(restProps, __emit);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(DropdownMenuItem_default), mergeProps(unref(forwarded), { class: unref(cn)(unref(menuItemClass), __props.class) }), {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
				_: 3
			}, 16, ["class"]);
		};
	}
});
//#endregion
//#region src/components/chip/Tag.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$1 = ["role", "tabindex"];
var _hoisted_2$1 = { class: "min-w-0 truncate" };
//#endregion
//#region src/components/chip/Tag.vue
var Tag_default = /* @__PURE__ */ defineComponent({
	__name: "Tag",
	props: {
		label: {},
		shape: { default: "square" },
		state: { default: "default" },
		removable: {
			type: Boolean,
			default: false
		},
		removeLabel: {},
		removeTooltip: {},
		interactive: {
			type: Boolean,
			default: false
		},
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	},
	emits: ["remove"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		function handleKeydown(event) {
			if (event.target !== event.currentTarget) return;
			if (!__props.interactive) return;
			if (event.key === "Enter" || event.key === " ") event.preventDefault();
			if (event.key === "Enter" && event.currentTarget instanceof HTMLElement) event.currentTarget.click();
		}
		function handleKeyup(event) {
			if (event.target !== event.currentTarget) return;
			if (!__props.interactive || event.key !== " ") return;
			event.preventDefault();
			if (event.currentTarget instanceof HTMLElement) event.currentTarget.click();
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("span", {
				role: __props.interactive ? "button" : void 0,
				tabindex: __props.interactive ? 0 : void 0,
				class: normalizeClass(unref(cn)(unref(tagVariants)({
					shape: __props.shape,
					state: __props.state,
					removable: __props.removable,
					interactive: __props.interactive
				}), __props.class)),
				onKeydown: handleKeydown,
				onKeyup: handleKeyup
			}, [
				renderSlot(_ctx.$slots, "icon"),
				createBaseVNode("span", _hoisted_2$1, toDisplayString(__props.label), 1),
				renderSlot(_ctx.$slots, "default"),
				__props.removable ? (openBlock(), createBlock(TagRemoveButton_default, {
					key: 0,
					"aria-label": __props.removeLabel ?? _ctx.$t("g.remove"),
					tooltip: __props.removeTooltip,
					onClick: _cache[0] || (_cache[0] = withModifiers(($event) => emit("remove", $event), ["stop"]))
				}, null, 8, ["aria-label", "tooltip"])) : createCommentVNode("", true)
			], 42, _hoisted_1$1);
		};
	}
});
//#endregion
//#region src/composables/element/useOverflowObserver.ts
/**
* Observes an element for overflow changes and optionally debounces the check
* @param element - The element to observe
* @param options - The options for the observer
* @param options.debounceTime - The time to debounce the check in milliseconds
* @param options.useMutationObserver - Whether to use a mutation observer to check for overflow
* @param options.useResizeObserver - Whether to use a resize observer to check for overflow
* @returns An object containing the isOverflowing state and the checkOverflow function to manually trigger
*/
var useOverflowObserver = (element, options) => {
	options = {
		debounceTime: 25,
		useMutationObserver: true,
		useResizeObserver: true,
		...options
	};
	const isOverflowing = ref(false);
	const disposeFns = [];
	const disposed = ref(false);
	const checkOverflowFn = () => {
		const resolvedElement = toValue$1(element);
		isOverflowing.value = resolvedElement ? resolvedElement.scrollWidth > resolvedElement.clientWidth : false;
		options.onCheck?.(isOverflowing.value);
	};
	const checkOverflow = options.debounceTime ? debounce(checkOverflowFn, options.debounceTime) : checkOverflowFn;
	if (options.useMutationObserver) disposeFns.push(useMutationObserver(element, checkOverflow, {
		subtree: true,
		childList: true
	}).stop);
	if (options.useResizeObserver) disposeFns.push(useResizeObserver(element, checkOverflow).stop);
	return {
		isOverflowing: readonly(isOverflowing),
		disposed: readonly(disposed),
		checkOverflow,
		dispose: () => {
			disposed.value = true;
			disposeFns.forEach((fn) => fn());
		}
	};
};
//#endregion
//#region src/platform/assets/utils/mediaIconUtil.ts
function iconForMediaType(mediaType) {
	switch (mediaType) {
		case "video": return "icon-[lucide--video]";
		case "audio": return "icon-[lucide--music]";
		case "3D": return "icon-[lucide--box]";
		case "text": return "icon-[lucide--text]";
		case "other": return "icon-[lucide--check-check]";
		default: return "icon-[lucide--image]";
	}
}
//#endregion
//#region src/platform/canvas/minimapDecorationRegistry.ts
var layers = /* @__PURE__ */ new Map();
var revision = shallowRef(0);
function targetKey(target) {
	return `${target.rootGraphId}:${target.owningGraphId}:${target.nodeId}`;
}
function copyDecoration(row, enteredAt) {
	return {
		target: { ...row.target },
		enter: row.enter,
		enteredAt
	};
}
function invalidate() {
	revision.value += 1;
}
/**
* Registers transient, graph-scoped minimap decorations. Producers own which
* nodes are decorated and when the layer is disposed; the minimap exclusively
* owns projection, palette, paint order, and animation scheduling.
*/
function registerMinimapDecorationLayer(id) {
	const stale = layers.get(id);
	if (stale) {
		reportError(/* @__PURE__ */ new Error(`Minimap decoration layer exists: ${id}`), {
			surface: "graph",
			errorType: "minimap_decoration_layer_duplicate"
		});
		stale.disposed = true;
	}
	const layer = {
		rows: /* @__PURE__ */ new Map(),
		disposed: false
	};
	layers.set(id, layer);
	if (stale) invalidate();
	return {
		replace(rows) {
			if (layer.disposed) return;
			const next = /* @__PURE__ */ new Map();
			const now = performance.now();
			for (const [index, row] of rows.entries()) {
				const key = targetKey(row.target);
				const previous = layer.rows.get(key);
				const enteredAt = row.enter === "pop" ? previous?.enteredAt ?? now + Math.min(index, 8) * 50 : void 0;
				next.set(key, copyDecoration(row, enteredAt));
			}
			layer.rows.clear();
			for (const [key, row] of next) layer.rows.set(key, row);
			invalidate();
		},
		dispose() {
			if (layer.disposed) return;
			layer.disposed = true;
			layers.delete(id);
			invalidate();
		}
	};
}
var minimapDecorationRevision = readonly(revision);
function getMinimapDecorations(scope) {
	return [...layers.entries()].sort(([left], [right]) => left.localeCompare(right)).flatMap(([, layer]) => [...layer.rows.values()]).filter(({ target }) => target.rootGraphId === scope.rootGraphId && target.owningGraphId === scope.owningGraphId).map((row) => copyDecoration(row, row.enteredAt));
}
//#endregion
//#region src/components/graph/CanvasBanner.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "flex min-w-0 items-center gap-2" };
var _hoisted_2 = { class: "flex min-w-0 flex-col text-sm wrap-break-word" };
var _hoisted_3 = { class: "font-medium text-foreground" };
var _hoisted_4 = {
	key: 0,
	class: "text-muted-foreground"
};
//#endregion
//#region src/components/graph/CanvasBanner.vue
var CanvasBanner_default = /* @__PURE__ */ defineComponent({
	__name: "CanvasBanner",
	props: { accent: {} },
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", { class: normalizeClass(unref(cn)("pointer-events-auto relative flex items-center gap-12 rounded-lg border border-l-4 bg-background p-4 shadow-md", __props.accent)) }, [createBaseVNode("div", _hoisted_1, [renderSlot(_ctx.$slots, "icon"), createBaseVNode("div", _hoisted_2, [createBaseVNode("span", _hoisted_3, [renderSlot(_ctx.$slots, "title")]), _ctx.$slots.description ? (openBlock(), createElementBlock("span", _hoisted_4, [renderSlot(_ctx.$slots, "description")])) : createCommentVNode("", true)])]), renderSlot(_ctx.$slots, "actions")], 2);
		};
	}
});
//#endregion
//#region src/composables/canvas/useFocusNode.ts
async function waitForAnimationFrame() {
	await new Promise((resolve) => {
		const timeoutId = window.setTimeout(resolve, 100);
		requestAnimationFrame(() => {
			window.clearTimeout(timeoutId);
			resolve();
		});
	});
}
async function waitForCanvasNavigation() {
	await nextTick();
	await waitForAnimationFrame();
	await waitForAnimationFrame();
}
function useFocusNode() {
	const canvasStore = useCanvasStore();
	const navigationStore = useSubgraphNavigationStore();
	async function focusNodeInstance(node) {
		const canvas = canvasStore.canvas;
		if (!canvas || !node.graph) return;
		const graphChanged = canvas.graph !== node.graph;
		if (!await navigationStore.navigateToGraph(node.graph)) return;
		if (graphChanged) await waitForCanvasNavigation();
		const activeCanvas = canvasStore.canvas;
		if (!activeCanvas || activeCanvas.graph !== node.graph || !node.graph.nodes.includes(node)) return;
		activeCanvas.animateToBounds(node.boundingRect, { viewport: visibleCanvasViewport(activeCanvas) });
	}
	async function focusNode(nodeId, executionIdMap) {
		if (!canvasStore.canvas) return;
		const graphNode = executionIdMap ? executionIdMap.get(nodeId) : getNodeByExecutionId(app.rootGraph, nodeId);
		if (!graphNode?.graph) return;
		await focusNodeInstance(graphNode);
	}
	return {
		focusNode,
		focusNodeInstance
	};
}
//#endregion
//#region src/workbench/extensions/agent/composables/useBillingIdentity.ts
function useBillingIdentity() {
	const { resolvedUserInfo } = useCurrentUser();
	const teamWorkspaceStore = useTeamWorkspaceStore();
	return computed(() => `${resolvedUserInfo.value?.id ?? "anonymous"}:${teamWorkspaceStore.workspaceId ?? "none"}`);
}
//#endregion
//#region src/systems/nodeEmphasisSystem.ts
var referenceSources = shallowReactive(/* @__PURE__ */ new Set());
var referencedNodeIds = computed(() => {
	const ids = /* @__PURE__ */ new Set();
	for (const source of referenceSources) {
		const id = source();
		if (id !== void 0) ids.add(id);
	}
	return ids;
});
/**
* Emphasizes the node `source` names, without selecting it, for as long as
* the calling scope lives. The caller stays the owner of the reference.
*/
function useNodeEmphasisSource(source) {
	referenceSources.add(source);
	onScopeDispose(() => referenceSources.delete(source));
}
/**
* Whether a node of the graph `scope` is drawn emphasized: selected there,
* or named by an emphasis source.
*/
function isNodeEmphasized(scope, nodeId) {
	return isSelectedIn(scope, toSelectableKey("node", nodeId)) || referencedNodeIds.value.has(nodeId);
}
function isCanvasNodeEmphasized(node) {
	return node.graph ? isNodeEmphasized(graphScopeOf(node.graph), node.id) : node.selected;
}
/**
* Installs {@link isNodeEmphasized} as the legacy canvas's emphasis query
* and redraws that canvas when the referenced nodes change.
*/
function useNodeEmphasis() {
	const canvasStore = useCanvasStore();
	onScopeDispose(registerNodeEmphasisQuery(isCanvasNodeEmphasized));
	watch(referencedNodeIds, () => canvasStore.canvas?.setDirty(true, false));
}
//#endregion
//#region node_modules/.pnpm/@floating-ui+vue@1.1.11_vue@3.5.42_typescript@6.0.3_/node_modules/@floating-ui/vue/dist/floating-ui.vue.mjs
function isComponentPublicInstance(target) {
	return target != null && typeof target === "object" && "$el" in target;
}
function unwrapElement(target) {
	if (isComponentPublicInstance(target)) {
		const element = target.$el;
		return isNode(element) && getNodeName(element) === "#comment" ? null : element;
	}
	return target;
}
function toValue(source) {
	return typeof source === "function" ? source() : unref(source);
}
function getDPR(element) {
	if (typeof window === "undefined") return 1;
	return (element.ownerDocument.defaultView || window).devicePixelRatio || 1;
}
function roundByDPR(element, value) {
	const dpr = getDPR(element);
	return Math.round(value * dpr) / dpr;
}
/**
* Computes the `x` and `y` coordinates that will place the floating element next to a reference element when it is given a certain CSS positioning strategy.
* @param reference The reference template ref.
* @param floating The floating template ref.
* @param options The floating options.
* @see https://floating-ui.com/docs/vue
*/
function useFloating(reference, floating, options) {
	if (options === void 0) options = {};
	const whileElementsMountedOption = options.whileElementsMounted;
	const openOption = computed(() => {
		var _toValue;
		return (_toValue = toValue(options.open)) != null ? _toValue : true;
	});
	const middlewareOption = computed(() => toValue(options.middleware));
	const placementOption = computed(() => {
		var _toValue2;
		return (_toValue2 = toValue(options.placement)) != null ? _toValue2 : "bottom";
	});
	const strategyOption = computed(() => {
		var _toValue3;
		return (_toValue3 = toValue(options.strategy)) != null ? _toValue3 : "absolute";
	});
	const transformOption = computed(() => {
		var _toValue4;
		return (_toValue4 = toValue(options.transform)) != null ? _toValue4 : true;
	});
	const referenceElement = computed(() => unwrapElement(reference.value));
	const floatingElement = computed(() => unwrapElement(floating.value));
	const x = ref(0);
	const y = ref(0);
	const strategy = ref(strategyOption.value);
	const placement = ref(placementOption.value);
	const middlewareData = shallowRef({});
	const isPositioned = ref(false);
	const floatingStyles = computed(() => {
		const initialStyles = {
			position: strategy.value,
			left: "0",
			top: "0"
		};
		if (!floatingElement.value) return initialStyles;
		const xVal = roundByDPR(floatingElement.value, x.value);
		const yVal = roundByDPR(floatingElement.value, y.value);
		if (transformOption.value) return {
			...initialStyles,
			transform: "translate(" + xVal + "px, " + yVal + "px)",
			...getDPR(floatingElement.value) >= 1.5 && { willChange: "transform" }
		};
		return {
			position: strategy.value,
			left: xVal + "px",
			top: yVal + "px"
		};
	});
	let whileElementsMountedCleanup;
	function update() {
		if (referenceElement.value == null || floatingElement.value == null) return;
		const open = openOption.value;
		computePosition(referenceElement.value, floatingElement.value, {
			middleware: middlewareOption.value,
			placement: placementOption.value,
			strategy: strategyOption.value
		}).then((position) => {
			x.value = position.x;
			y.value = position.y;
			strategy.value = position.strategy;
			placement.value = position.placement;
			middlewareData.value = position.middlewareData;
			/**
			* The floating element's position may be recomputed while it's closed
			* but still mounted (such as when transitioning out). To ensure
			* `isPositioned` will be `false` initially on the next open, avoid
			* setting it to `true` when `open === false` (must be specified).
			*/
			isPositioned.value = open !== false;
		});
	}
	function cleanup() {
		if (typeof whileElementsMountedCleanup === "function") {
			whileElementsMountedCleanup();
			whileElementsMountedCleanup = void 0;
		}
	}
	function attach() {
		cleanup();
		if (whileElementsMountedOption === void 0) {
			update();
			return;
		}
		if (referenceElement.value != null && floatingElement.value != null) {
			whileElementsMountedCleanup = whileElementsMountedOption(referenceElement.value, floatingElement.value, update);
			return;
		}
	}
	function reset() {
		if (!openOption.value) isPositioned.value = false;
	}
	watch([
		middlewareOption,
		placementOption,
		strategyOption,
		openOption
	], update, { flush: "sync" });
	watch([referenceElement, floatingElement], attach, { flush: "sync" });
	watch(openOption, reset, { flush: "sync" });
	if (getCurrentScope()) onScopeDispose(cleanup);
	return {
		x: shallowReadonly(x),
		y: shallowReadonly(y),
		strategy: shallowReadonly(strategy),
		placement: shallowReadonly(placement),
		middlewareData: shallowReadonly(middlewareData),
		isPositioned: shallowReadonly(isPositioned),
		floatingStyles,
		update
	};
}
//#endregion
export { useBillingIdentity as a, getMinimapDecorations as c, iconForMediaType as d, useOverflowObserver as f, withTimeout as h, useNodeEmphasisSource as i, minimapDecorationRevision as l, MenuItem_default as m, isNodeEmphasized as n, useFocusNode as o, Tag_default as p, useNodeEmphasis as r, CanvasBanner_default as s, useFloating as t, registerMinimapDecorationLayer as u };
