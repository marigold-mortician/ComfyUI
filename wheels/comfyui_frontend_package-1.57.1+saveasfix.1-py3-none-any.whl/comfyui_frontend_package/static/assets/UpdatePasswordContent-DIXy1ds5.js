import "./rolldown-runtime-xtsTai4I.js";
import { n as useDialogService } from "./dialogService-CqZr0BhP.js";
import { E as withModifiers, Ft as ref, G as defineComponent, H as createTextVNode, R as createElementBlock, U as createVNode, Wt as unref, Yt as toDisplayString, ct as openBlock, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as AUTH_ERROR_CODES_MAP_DO_NOT_USE_INTERNALLY, x as FirebaseError } from "./vendor-firebase-B37L--zT.js";
import { t as useToast } from "./toastStore-Dg65fRgL.js";
import { d as t } from "./i18n-BRluoVl-.js";
import { t as useErrorHandling } from "./useErrorHandling-WrECc0C0.js";
import { r as useAuthStore } from "./authStore-D2cL6XhN.js";
import { t as useAuthActions } from "./useAuthActions-_rhVfmiU.js";
import { r as useForm } from "./zodTypedSchema-BoLUZgf5.js";
import { i as updatePasswordSchema } from "./signInSchema-ypzhk4JK.js";
import { t as PasswordFields_default } from "./PasswordFields-CR6jcreU.js";
//#region src/composables/auth/useUpdatePassword.ts
/**
* Password update with recovery from Firebase auth/requires-recent-login:
* the user is asked to confirm, signed out, sent through `requestSignIn`,
* and the update is retried after a successful sign-in.
*/
function useUpdatePassword(requestSignIn) {
	const authStore = useAuthStore();
	const toast = useToast();
	const dialogService = useDialogService();
	const { wrapWithErrorHandlingAsync } = useErrorHandling();
	const { reportError } = useAuthActions();
	return wrapWithErrorHandlingAsync(async (newPassword) => {
		await authStore.updatePassword(newPassword);
		toast.success(t("auth.passwordUpdate.success"), {
			description: t("auth.passwordUpdate.successDetail"),
			duration: 5e3
		});
	}, reportError, void 0, [{
		shouldHandle: (error) => error instanceof FirebaseError && error.code === AUTH_ERROR_CODES_MAP_DO_NOT_USE_INTERNALLY.CREDENTIAL_TOO_OLD_LOGIN_AGAIN,
		recover: async (_error, retry, args) => {
			if (!await dialogService.confirm({
				title: t("auth.reauthRequired.title"),
				message: t("auth.reauthRequired.message"),
				type: "default"
			})) return;
			await authStore.logout();
			if (await requestSignIn()) await retry(...args);
		}
	}]);
}
//#endregion
//#region src/components/dialog/content/UpdatePasswordContent.vue
var UpdatePasswordContent_default = /* @__PURE__ */ defineComponent({
	__name: "UpdatePasswordContent",
	props: {
		requestSignIn: { type: Function },
		onSuccess: { type: Function }
	},
	setup(__props) {
		const updatePassword = useUpdatePassword(__props.requestSignIn);
		const loading = ref(false);
		const { handleSubmit } = useForm({
			validationSchema: updatePasswordSchema,
			initialValues: {
				password: "",
				confirmPassword: ""
			}
		});
		const onSubmit = handleSubmit(async ({ password }) => {
			loading.value = true;
			try {
				await updatePassword(password);
				__props.onSuccess();
			} finally {
				loading.value = false;
			}
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("form", {
				"data-testid": "update-password-dialog",
				class: "flex w-96 flex-col gap-6",
				onSubmit: _cache[0] || (_cache[0] = withModifiers((...args) => unref(onSubmit) && unref(onSubmit)(...args), ["prevent"]))
			}, [createVNode(PasswordFields_default), createVNode(Button_default, {
				type: "submit",
				class: "mt-4 h-10",
				loading: loading.value
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("userSettings.updatePassword")), 1)]),
				_: 1
			}, 8, ["loading"])], 32);
		};
	}
});
//#endregion
export { UpdatePasswordContent_default as default };
