import "./rolldown-runtime-xtsTai4I.js";
import { F as createBaseVNode, Ft as ref, G as defineComponent, I as createBlock, Kt as normalizeClass, L as createCommentVNode, O as Fragment, P as computed, R as createElementBlock, U as createVNode, Wt as unref, _t as useModel, bt as watch, ct as openBlock, ut as renderList, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { Gt as RovingFocusGroup_default, Wt as RovingFocusItem_default } from "./vendor-reka-ui-NRTk7aIV.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
//#region src/renderer/extensions/vueNodes/widgets/components/WidgetGalleria.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "flex flex-col gap-1" };
var _hoisted_2 = ["aria-label"];
var _hoisted_3 = { class: "relative flex items-center justify-center" };
var _hoisted_4 = ["src", "alt"];
var _hoisted_5 = {
	key: 0,
	class: "overflow-x-auto px-2 py-4"
};
var _hoisted_6 = [
	"aria-label",
	"aria-current",
	"onFocus",
	"onClick"
];
var _hoisted_7 = ["src"];
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/components/WidgetGalleria.vue
var WidgetGalleria_default = /* @__PURE__ */ defineComponent({
	inheritAttrs: false,
	__name: "WidgetGalleria",
	props: {
		"modelValue": { required: true },
		"modelModifiers": {}
	},
	emits: ["update:modelValue"],
	setup(__props) {
		const modelValue = useModel(__props, "modelValue");
		const images = computed(() => Array.isArray(modelValue.value) ? modelValue.value.filter((image) => typeof image === "string" && image.length > 0) : []);
		const activeIndex = ref(0);
		const { t } = useI18n();
		watch(() => images.value.length, (length) => {
			activeIndex.value = Math.max(0, Math.min(activeIndex.value, length - 1));
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1, [createBaseVNode("div", {
				class: "max-w-full overflow-hidden rounded-lg border",
				role: "region",
				"aria-label": unref(t)("g.imageGallery")
			}, [createBaseVNode("div", _hoisted_3, [
				images.value.length ? (openBlock(), createElementBlock("img", {
					key: 0,
					src: images.value[activeIndex.value],
					alt: unref(t)("g.galleryImagePosition", {
						index: activeIndex.value + 1,
						total: images.value.length
					}),
					class: "h-auto max-h-64 w-full object-contain"
				}, null, 8, _hoisted_4)) : createCommentVNode("", true),
				images.value.length > 1 ? (openBlock(), createBlock(Button_default, {
					key: 1,
					variant: "secondary",
					size: "icon",
					class: "absolute top-1/2 left-2 -translate-y-1/2 rounded-full bg-secondary/80 hover:bg-secondary disabled:opacity-40",
					type: "button",
					"aria-label": unref(t)("g.previousImage"),
					disabled: activeIndex.value === 0,
					onClick: _cache[0] || (_cache[0] = ($event) => activeIndex.value--)
				}, {
					default: withCtx(() => [..._cache[2] || (_cache[2] = [createBaseVNode("i", {
						class: "icon-[lucide--chevron-left] size-4",
						"aria-hidden": "true"
					}, null, -1)])]),
					_: 1
				}, 8, ["aria-label", "disabled"])) : createCommentVNode("", true),
				images.value.length > 1 ? (openBlock(), createBlock(Button_default, {
					key: 2,
					variant: "secondary",
					size: "icon",
					class: "absolute top-1/2 right-2 -translate-y-1/2 rounded-full bg-secondary/80 hover:bg-secondary disabled:opacity-40",
					type: "button",
					"aria-label": unref(t)("g.nextImage"),
					disabled: activeIndex.value === images.value.length - 1,
					onClick: _cache[1] || (_cache[1] = ($event) => activeIndex.value++)
				}, {
					default: withCtx(() => [..._cache[3] || (_cache[3] = [createBaseVNode("i", {
						class: "icon-[lucide--chevron-right] size-4",
						"aria-hidden": "true"
					}, null, -1)])]),
					_: 1
				}, 8, ["aria-label", "disabled"])) : createCommentVNode("", true)
			]), images.value.length > 1 ? (openBlock(), createElementBlock("div", _hoisted_5, [createVNode(unref(RovingFocusGroup_default), {
				"current-tab-stop-id": `gallery-thumbnail-${activeIndex.value}`,
				orientation: "horizontal",
				class: "flex min-w-max items-center justify-center gap-1"
			}, {
				default: withCtx(() => [(openBlock(true), createElementBlock(Fragment, null, renderList(images.value, (image, index) => {
					return openBlock(), createBlock(unref(RovingFocusItem_default), {
						key: `${image}-${index}`,
						"as-child": "",
						"tab-stop-id": `gallery-thumbnail-${index}`
					}, {
						default: withCtx(() => [createBaseVNode("button", {
							type: "button",
							class: normalizeClass(unref(cn)("size-12 shrink-0 overflow-hidden rounded-lg border-0 bg-transparent p-1 opacity-50 transition-opacity hover:opacity-100", index === activeIndex.value && "opacity-100")),
							"aria-label": unref(t)("g.galleryThumbnailPosition", {
								index: index + 1,
								total: images.value.length
							}),
							"aria-current": index === activeIndex.value ? "true" : void 0,
							onFocus: ($event) => activeIndex.value = index,
							onClick: ($event) => activeIndex.value = index
						}, [createBaseVNode("img", {
							src: image,
							alt: "",
							class: "size-full rounded-lg object-cover"
						}, null, 8, _hoisted_7)], 42, _hoisted_6)]),
						_: 2
					}, 1032, ["tab-stop-id"]);
				}), 128))]),
				_: 1
			}, 8, ["current-tab-stop-id"])])) : createCommentVNode("", true)], 8, _hoisted_2)]);
		};
	}
});
//#endregion
export { WidgetGalleria_default as default };
