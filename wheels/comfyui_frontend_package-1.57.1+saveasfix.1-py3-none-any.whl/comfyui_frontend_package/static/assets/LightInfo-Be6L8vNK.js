import "./rolldown-runtime-xtsTai4I.js";
import { F as Color, Ht as Vector2, Mt as SphereGeometry, Nt as SpotLight, Pt as SpotLightHelper, R as DirectionalLight, Tt as Raycaster, Ut as Vector3, Y as HemisphereLight, bt as PointLightHelper, lt as Mesh, pt as MeshStandardMaterial, q as Group, ut as MeshBasicMaterial, vt as PlaneGeometry, yt as PointLight, z as DirectionalLightHelper } from "./vendor-three-B-UiePqj.js";
import { un as onGraphIntent } from "./litegraph-CgrqhFEE.js";
import { y as resolveNode } from "./litegraphUtil-B_WxWXjg.js";
import { $ as mergeModels, E as withModifiers, F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, I as createBlock, Jt as normalizeStyle, Kt as normalizeClass, L as createCommentVNode, O as Fragment, P as computed, R as createElementBlock, Rt as shallowRef, U as createVNode, Wt as unref, Yt as toDisplayString, _t as useModel, at as onMounted, bt as watch, ct as openBlock, ot as onUnmounted, ut as renderList, wt as withCtx, zt as toRaw } from "./vendor-vue-core-CuN1excl.js";
import { rr as useElementSize } from "./vendor-reka-ui-NRTk7aIV.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { t as useToast } from "./toastStore-Dg65fRgL.js";
import { d as t } from "./i18n-BRluoVl-.js";
import { r as reportError } from "./reportError-BHgDVvfb.js";
import { t as Switch_default } from "./Switch-CDfqeaPZ.js";
import { t as AppColorPicker_default } from "./AppColorPicker-DF4cO9Dd.js";
import { i as WidgetHistoryButtons_default, n as widgetHistoryScope, r as useWidgetValueHistory } from "./widgetHistoryScope-DLmWjnnJ.js";
import { dt as LIGHT_TYPE_LABEL_KEYS, ft as cloneLights, lt as normalizeLightsValue, mt as lightTarget, pt as createDefaultLight, ut as LIGHT_TYPES } from "./app-CSsV1u1T.js";
import { t as ScrubableNumberInput_default } from "./ScrubableNumberInput-Dig5Z8Hb.js";
import { n as setNodeWidgetValue, t as getNodeWidgetValue } from "./nodeWidgetValues-CVGjrpz0.js";
import { a as DEFAULT_CAMERA_INFO_STATE, i as pointToYawAngle, n as pointToDistance, r as pointToPitchAngle } from "./orbitDragMath-COuSsRvb.js";
import { n as chipClass, t as actionClass } from "./menuBarStyles-Bea0qWup.js";
import { n as ToggleGroup_default, t as ToggleGroupItem_default } from "./ToggleGroupItem-B6sGt08k.js";
import "./toggle-group-Cn40zTWz.js";
import { a as createSceneHoverHandlers, i as isOrbitHandleType, n as pickHandleAtPointer, o as useViewportNodeWiring, r as OrbitHandles, t as createViewport3d } from "./createViewport3d-LhTmoqJk.js";
import { t as TargetHandle } from "./TargetHandle-DsnsHetN.js";
//#region src/extensions/core/load3d/components/lightInfo/LightInfoLightEditor.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$2 = { class: "flex flex-col gap-2 rounded-sm bg-node p-2" };
var FIELD_LABEL_CLASS = "content-center truncate";
//#endregion
//#region src/extensions/core/load3d/components/lightInfo/LightInfoLightEditor.vue
var LightInfoLightEditor_default = /* @__PURE__ */ defineComponent({
	__name: "LightInfoLightEditor",
	props: {
		light: {},
		compact: { type: Boolean }
	},
	emits: ["update", "changeType"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const { locale } = useI18n();
		const numberFields = computed(() => {
			const directional = __props.light.type === "directional";
			const fields = [{
				key: "intensity",
				labelKey: "lightInfo.intensity",
				value: __props.light.intensity,
				min: 0,
				step: .1
			}, {
				key: "radius",
				labelKey: directional ? "lightInfo.angle" : "lightInfo.size",
				value: __props.light.radius ?? 0,
				min: 0,
				step: directional ? .1 : .05
			}];
			if (!directional) fields.push({
				key: "range",
				labelKey: "lightInfo.range",
				value: __props.light.range ?? 0,
				min: 0,
				step: .5
			});
			if (__props.light.type === "spot") fields.push({
				key: "innerConeAngle",
				labelKey: "lightInfo.innerCone",
				value: __props.light.innerConeAngle ?? 30,
				min: 0,
				max: 90,
				step: 1
			}, {
				key: "outerConeAngle",
				labelKey: "lightInfo.outerCone",
				value: __props.light.outerConeAngle ?? 45,
				min: 1,
				max: 90,
				step: 1
			});
			return fields;
		});
		function onTypeChange(value) {
			const type = LIGHT_TYPES.find((candidate) => candidate === value);
			if (type) emit("changeType", type);
		}
		function fieldDecimals(field) {
			if (field === "innerConeAngle" || field === "outerConeAngle") return 0;
			if (field === "radius" && __props.light.type !== "directional") return 2;
			return 1;
		}
		function formatField(field, value) {
			return new Intl.NumberFormat(locale.value, {
				maximumFractionDigits: fieldDecimals(field),
				useGrouping: false
			}).format(value);
		}
		function setNumber(field, raw) {
			if (!Number.isFinite(raw)) return;
			const value = Number(raw.toFixed(fieldDecimals(field)));
			if (field === "innerConeAngle") {
				emit("update", { innerConeAngle: Math.min(value, __props.light.outerConeAngle ?? 45) });
				return;
			}
			if (field === "outerConeAngle") {
				emit("update", {
					outerConeAngle: value,
					innerConeAngle: Math.min(__props.light.innerConeAngle ?? 30, value)
				});
				return;
			}
			emit("update", { [field]: value });
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$2, [createVNode(unref(ToggleGroup_default), {
				type: "single",
				"model-value": __props.light.type,
				class: "w-full min-w-0 rounded-md bg-input p-1",
				"onUpdate:modelValue": onTypeChange
			}, {
				default: withCtx(() => [(openBlock(true), createElementBlock(Fragment, null, renderList(unref(LIGHT_TYPES), (type) => {
					return openBlock(), createBlock(unref(ToggleGroupItem_default), {
						key: type,
						value: type,
						size: "sm",
						class: "flex-1 px-2"
					}, {
						default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t(unref(LIGHT_TYPE_LABEL_KEYS)[type])), 1)]),
						_: 2
					}, 1032, ["value"]);
				}), 128))]),
				_: 1
			}, 8, ["model-value"]), createBaseVNode("div", { class: normalizeClass(unref(cn)("grid items-center gap-x-2 gap-y-1", __props.compact ? "grid-cols-[auto_minmax(0,1fr)]" : "grid-cols-[auto_minmax(0,1fr)_auto_minmax(0,1fr)]")) }, [
				createBaseVNode("label", { class: normalizeClass(FIELD_LABEL_CLASS) }, toDisplayString(_ctx.$t("lightInfo.color")), 1),
				createVNode(AppColorPicker_default, {
					"model-value": __props.light.color,
					alpha: false,
					"accessible-label": _ctx.$t("lightInfo.color"),
					"onUpdate:modelValue": _cache[0] || (_cache[0] = (color) => emit("update", { color }))
				}, null, 8, ["model-value", "accessible-label"]),
				createBaseVNode("label", { class: normalizeClass(FIELD_LABEL_CLASS) }, toDisplayString(_ctx.$t("lightInfo.castShadow")), 1),
				createVNode(Switch_default, {
					"model-value": __props.light.castShadow !== false,
					"aria-label": _ctx.$t("lightInfo.castShadow"),
					"onUpdate:modelValue": _cache[1] || (_cache[1] = (castShadow) => emit("update", { castShadow }))
				}, null, 8, ["model-value", "aria-label"]),
				(openBlock(true), createElementBlock(Fragment, null, renderList(numberFields.value, (field) => {
					return openBlock(), createElementBlock(Fragment, { key: field.key }, [createBaseVNode("label", { class: normalizeClass(FIELD_LABEL_CLASS) }, toDisplayString(_ctx.$t(field.labelKey)), 1), createVNode(ScrubableNumberInput_default, {
						"model-value": field.value,
						"display-value": formatField(field.key, field.value),
						"input-attrs": { "aria-label": _ctx.$t(field.labelKey) },
						min: field.min,
						max: field.max,
						step: field.step,
						"onUpdate:modelValue": (value) => setNumber(field.key, value)
					}, null, 8, [
						"model-value",
						"display-value",
						"input-attrs",
						"min",
						"max",
						"step",
						"onUpdate:modelValue"
					])], 64);
				}), 128))
			], 2)]);
		};
	}
});
//#endregion
//#region packages/viewport3d/src/lightInfo/LightInfoOverlay.ts
var SPHERE_RADIUS = 1;
var SPHERE_SEGMENTS = 64;
var SPHERE_COLOR = 13421772;
var GROUND_SIZE = 40;
var GROUND_Y = -1;
var GROUND_COLOR = 9079434;
var AMBIENT_INTENSITY = .2;
var AMBIENT_SKY_COLOR = 16777215;
var AMBIENT_GROUND_COLOR = 8421504;
var MARKER_RADIUS = .1;
var MARKER_SELECTED_SCALE = 1.4;
var SHADOW_MAP_SIZE = 1024;
var SHADOW_BIAS = -5e-4;
var DIRECTIONAL_SHADOW_HALF = GROUND_SIZE / 2;
var SHADOW_BLUR_TEXELS_PER_UNIT = 20;
var SHADOW_BLUR_TEXELS_PER_DEGREE = 2;
var DEG2RAD$1 = Math.PI / 180;
function createSceneLight(type) {
	if (type === "point") return new PointLight();
	if (type === "spot") return new SpotLight();
	return new DirectionalLight();
}
function createHelper(light) {
	if (light instanceof PointLight) return new PointLightHelper(light, .3);
	if (light instanceof SpotLight) return new SpotLightHelper(light);
	return new DirectionalLightHelper(light, .5);
}
var LightInfoOverlay = class {
	scene = null;
	lights = [];
	selectedIndex = -1;
	studioGroup;
	sphere;
	ground;
	ambientLight;
	rigs = [];
	helpersOn = true;
	disposed = false;
	constructor(initialLights = []) {
		this.lights = cloneLights(initialLights);
		this.selectedIndex = this.lights.length ? 0 : -1;
		this.sphere = new Mesh(new SphereGeometry(SPHERE_RADIUS, SPHERE_SEGMENTS, SPHERE_SEGMENTS), new MeshStandardMaterial({
			color: SPHERE_COLOR,
			roughness: .8,
			metalness: 0
		}));
		this.sphere.castShadow = true;
		this.sphere.receiveShadow = true;
		this.ground = new Mesh(new PlaneGeometry(GROUND_SIZE, GROUND_SIZE), new MeshStandardMaterial({
			color: GROUND_COLOR,
			roughness: 1,
			metalness: 0
		}));
		this.ground.rotation.x = -Math.PI / 2;
		this.ground.position.y = GROUND_Y;
		this.ground.receiveShadow = true;
		this.studioGroup = new Group();
		this.studioGroup.name = "LightInfoStudio";
		this.studioGroup.add(this.sphere);
		this.studioGroup.add(this.ground);
		this.ambientLight = new HemisphereLight(AMBIENT_SKY_COLOR, AMBIENT_GROUND_COLOR, AMBIENT_INTENSITY);
	}
	attach(scene) {
		this.scene = scene;
		scene.add(this.studioGroup);
		scene.add(this.ambientLight);
		this.rebuildRigs();
		this.lights.forEach((light, i) => this.applyLightToRig(light, i));
		this.refreshHelperVisibility();
		this.updateHelpers();
	}
	detach() {
		if (!this.scene) return;
		this.removeRigs();
		this.scene.remove(this.studioGroup);
		this.scene.remove(this.ambientLight);
		this.scene = null;
	}
	update(_delta) {
		this.updateHelpers();
	}
	dispose() {
		if (this.disposed) return;
		this.disposed = true;
		this.removeRigs();
		this.sphere.geometry.dispose();
		this.sphere.material.dispose();
		this.ground.geometry.dispose();
		this.ground.material.dispose();
	}
	getLights() {
		return cloneLights(this.lights);
	}
	getSelectedIndex() {
		return this.selectedIndex;
	}
	getSelectedLight() {
		if (this.selectedIndex < 0 || this.selectedIndex >= this.lights.length) return null;
		return cloneLights([this.lights[this.selectedIndex]])[0];
	}
	applyLights(lights, selectedIndex) {
		this.lights = cloneLights(lights);
		this.selectedIndex = Math.min(selectedIndex, this.lights.length - 1);
		if (!this.scene) return;
		if (!(this.rigs.length === this.lights.length && this.rigs.every((rig, i) => rig.type === this.lights[i].type))) this.rebuildRigs();
		this.lights.forEach((light, i) => this.applyLightToRig(light, i));
		this.refreshHelperVisibility();
		this.updateHelpers();
	}
	markerMeshes() {
		return this.rigs.map((rig) => rig.marker);
	}
	setHelpersVisible(visible) {
		this.helpersOn = visible;
		this.refreshHelperVisibility();
	}
	rebuildRigs() {
		this.removeRigs();
		const scene = this.scene;
		if (!scene) return;
		this.rigs = this.lights.map((entry, i) => {
			const light = createSceneLight(entry.type);
			light.castShadow = true;
			light.shadow.mapSize.set(SHADOW_MAP_SIZE, SHADOW_MAP_SIZE);
			light.shadow.bias = SHADOW_BIAS;
			if (light instanceof DirectionalLight) {
				light.shadow.camera.left = -20;
				light.shadow.camera.right = DIRECTIONAL_SHADOW_HALF;
				light.shadow.camera.top = DIRECTIONAL_SHADOW_HALF;
				light.shadow.camera.bottom = -20;
			}
			const marker = new Mesh(new SphereGeometry(MARKER_RADIUS, 16, 16), new MeshBasicMaterial({ color: 16777215 }));
			marker.name = `LightInfoEmitterMarker${i}`;
			const helper = createHelper(light);
			scene.add(light);
			if (hasTargetObject(light)) scene.add(light.target);
			scene.add(marker);
			scene.add(helper);
			return {
				type: entry.type,
				light,
				helper,
				marker
			};
		});
	}
	removeRigs() {
		for (const rig of this.rigs) {
			this.scene?.remove(rig.light);
			if (hasTargetObject(rig.light)) this.scene?.remove(rig.light.target);
			this.scene?.remove(rig.marker);
			this.scene?.remove(rig.helper);
			rig.helper.dispose();
			rig.marker.geometry.dispose();
			rig.marker.material.dispose();
			rig.light.dispose();
		}
		this.rigs = [];
	}
	applyLightToRig(entry, index) {
		const rig = this.rigs.at(index);
		if (!rig) return;
		const color = new Color(entry.color);
		const { light, marker } = rig;
		light.color.copy(color);
		light.intensity = entry.intensity;
		light.position.set(entry.position.x, entry.position.y, entry.position.z);
		light.castShadow = entry.castShadow !== false;
		light.shadow.radius = 1 + shadowBlurTexels(entry);
		const target = lightTarget(entry);
		if (light instanceof SpotLight) {
			light.target.position.set(target.x, target.y, target.z);
			light.target.updateMatrixWorld(true);
			light.distance = entry.range ?? 0;
			light.angle = (entry.outerConeAngle ?? 45) * DEG2RAD$1;
			light.penumbra = spotPenumbra(entry);
		} else if (light instanceof PointLight) light.distance = entry.range ?? 0;
		else {
			light.target.position.set(target.x, target.y, target.z);
			light.target.updateMatrixWorld(true);
		}
		light.updateMatrixWorld(true);
		marker.position.set(entry.position.x, entry.position.y, entry.position.z);
		marker.userData.lightIndex = index;
		marker.userData.handleType = String(index);
		marker.material.color.copy(color);
		marker.scale.setScalar(index === this.selectedIndex ? MARKER_SELECTED_SCALE : 1);
	}
	refreshHelperVisibility() {
		this.rigs.forEach((rig, i) => {
			rig.marker.visible = this.helpersOn;
			rig.helper.visible = this.helpersOn && i === this.selectedIndex;
		});
	}
	updateHelpers() {
		for (const rig of this.rigs) rig.helper.update?.();
	}
};
function hasTargetObject(light) {
	return light instanceof DirectionalLight || light instanceof SpotLight;
}
function shadowBlurTexels(entry) {
	const radius = Math.max(entry.radius ?? 0, 0);
	return entry.type === "directional" ? radius * SHADOW_BLUR_TEXELS_PER_DEGREE : radius * SHADOW_BLUR_TEXELS_PER_UNIT;
}
function spotPenumbra(entry) {
	const outer = Math.max(entry.outerConeAngle ?? 45, .001);
	const inner = Math.min(entry.innerConeAngle ?? 30, outer);
	return Math.min(Math.max(1 - inner / outer, 0), 1);
}
//#endregion
//#region packages/viewport3d/src/lightInfo/lightTransform.ts
var DEG2RAD = Math.PI / 180;
var RAD2DEG = 180 / Math.PI;
function orbitPosition(target, yawDeg, pitchDeg, distance) {
	const yaw = yawDeg * DEG2RAD;
	const pitch = pitchDeg * DEG2RAD;
	const cosPitch = Math.cos(pitch);
	return {
		x: target.x + distance * cosPitch * Math.sin(yaw),
		y: target.y + distance * Math.sin(pitch),
		z: target.z + distance * cosPitch * Math.cos(yaw)
	};
}
function orbitAnglesFor(position, target) {
	const dx = position.x - target.x;
	const dy = position.y - target.y;
	const dz = position.z - target.z;
	const horizontal = Math.hypot(dx, dz);
	const distance = Math.max(Math.hypot(dx, dy, dz), 1e-6);
	return {
		yaw: Math.atan2(dx, dz) * RAD2DEG,
		pitch: Math.atan2(dy, horizontal) * RAD2DEG,
		distance
	};
}
function orbitHandleState(light) {
	if (light?.type !== "directional") return {
		...DEFAULT_CAMERA_INFO_STATE,
		mode: "look_at"
	};
	const target = lightTarget(light);
	return {
		...DEFAULT_CAMERA_INFO_STATE,
		mode: "orbit",
		target,
		orbit: orbitAnglesFor(light.position, target)
	};
}
//#endregion
//#region packages/viewport3d/src/lightInfo/LightInfoViewport.ts
var OUTPUT_VIEW = {
	position: {
		x: 0,
		y: 6,
		z: 8
	},
	target: {
		x: 0,
		y: -.5,
		z: 0
	},
	fov: 35
};
var LightInfoViewport = class {
	viewport;
	overlay;
	orbitHandles;
	positionHandle;
	targetHandle;
	onLightsChange;
	onSelectLight;
	onEditEnd;
	raycaster = new Raycaster();
	pointer = new Vector2();
	dragState = null;
	hoveredHandle = null;
	hoveredMarker = false;
	gizmosOn = true;
	cameraLocked = false;
	transformGizmoMode = "none";
	constructor(container, initialLights = [], options) {
		this.onLightsChange = options?.onLightsChange;
		this.onSelectLight = options?.onSelectLight;
		this.onEditEnd = options?.onEditEnd;
		this.viewport = createViewport3d(container, options);
		this.viewport.viewHelperManager.visibleViewHelper(false);
		this.viewport.sceneManager.toggleGrid(false);
		this.viewport.lightingManager.setLightIntensity(0);
		this.viewport.renderer.shadowMap.enabled = true;
		this.viewport.renderer.shadowMap.type = 1;
		this.overlay = new LightInfoOverlay(initialLights);
		this.viewport.setOverlay(this.overlay);
		this.orbitHandles = new OrbitHandles();
		this.orbitHandles.attach(this.viewport.sceneManager.scene);
		this.positionHandle = new TargetHandle(this.viewport.cameraManager.activeCamera, this.viewport.domElement, (dragging) => this.onHandleDraggingChange(dragging), (position) => {
			this.mutateSelected((light) => ({
				...light,
				position: { ...position }
			}));
		}, "LightInfoPosition");
		this.positionHandle.attach(this.viewport.sceneManager.scene);
		this.targetHandle = new TargetHandle(this.viewport.cameraManager.activeCamera, this.viewport.domElement, (dragging) => this.onHandleDraggingChange(dragging), (target) => {
			this.mutateSelected((light) => ({
				...light,
				target: { ...target }
			}));
		}, "LightInfoTarget");
		this.targetHandle.attach(this.viewport.sceneManager.scene);
		this.syncHandles();
		this.attachPointerHandlers();
	}
	applyLights(lights, selectedIndex) {
		this.overlay.applyLights(lights, selectedIndex);
		this.syncHandles();
		this.refreshGizmoVisibility();
		this.viewport.forceRender();
	}
	setGizmosVisible(on) {
		if (this.gizmosOn === on) return;
		this.gizmosOn = on;
		this.overlay.setHelpersVisible(on);
		this.refreshGizmoVisibility();
		this.viewport.forceRender();
	}
	setTransformGizmoMode(mode) {
		if (this.transformGizmoMode === mode) return;
		this.transformGizmoMode = mode;
		this.refreshGizmoVisibility();
		this.viewport.forceRender();
	}
	resetViewToOutput() {
		this.viewport.setCameraState({
			position: new Vector3(OUTPUT_VIEW.position.x, OUTPUT_VIEW.position.y, OUTPUT_VIEW.position.z),
			target: new Vector3(OUTPUT_VIEW.target.x, OUTPUT_VIEW.target.y, OUTPUT_VIEW.target.z),
			zoom: 1,
			cameraType: "perspective",
			fov: OUTPUT_VIEW.fov
		});
		this.viewport.forceRender();
	}
	setCameraLocked(locked) {
		if (this.cameraLocked === locked) return;
		this.cameraLocked = locked;
		this.viewport.controlsManager.controls.enabled = !locked;
	}
	remove() {
		this.detachPointerHandlers();
		this.canvas.style.cursor = "";
		this.orbitHandles.dispose();
		this.positionHandle.dispose();
		this.targetHandle.dispose();
		this.viewport.remove();
	}
	get selectedLight() {
		return this.overlay.getSelectedLight();
	}
	mutateSelected(mutate) {
		const lights = this.overlay.getLights();
		const index = this.overlay.getSelectedIndex();
		if (index < 0 || !lights[index]) return;
		lights[index] = mutate(lights[index]);
		this.applyLights(lights, index);
		this.onLightsChange?.(lights);
	}
	syncHandles() {
		const light = this.selectedLight;
		this.orbitHandles.update(orbitHandleState(light));
		if (!light) return;
		this.positionHandle.setTarget(light.position);
		this.targetHandle.setTarget(lightTarget(light));
	}
	refreshGizmoVisibility() {
		const type = this.gizmosOn ? this.selectedLight?.type ?? null : null;
		this.orbitHandles.setVisible(type === "directional");
		this.positionHandle.setVisible(this.transformGizmoMode === "light-position" && type !== null && lightPositionApplies(type));
		this.targetHandle.setVisible(this.transformGizmoMode === "target" && type !== null && targetApplies(type));
	}
	get canvas() {
		return this.viewport.domElement;
	}
	attachPointerHandlers() {
		const canvas = this.canvas;
		canvas.addEventListener("pointerdown", this.onPointerDown);
		canvas.addEventListener("pointermove", this.onPointerMove);
		canvas.addEventListener("pointerup", this.onPointerUp);
		canvas.addEventListener("pointercancel", this.onPointerUp);
		canvas.addEventListener("pointerleave", this.onPointerLeave);
	}
	detachPointerHandlers() {
		const canvas = this.canvas;
		canvas.removeEventListener("pointerdown", this.onPointerDown);
		canvas.removeEventListener("pointermove", this.onPointerMove);
		canvas.removeEventListener("pointerup", this.onPointerUp);
		canvas.removeEventListener("pointercancel", this.onPointerUp);
		canvas.removeEventListener("pointerleave", this.onPointerLeave);
	}
	onPointerLeave = () => {
		if (this.dragState) return;
		this.setHoveredHandle(null);
		this.setHoveredMarker(false);
	};
	updatePointer(event) {
		const rect = this.canvas.getBoundingClientRect();
		this.pointer.x = (event.clientX - rect.left) / rect.width * 2 - 1;
		this.pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
	}
	pickHandle(event) {
		if (!this.gizmosOn) return null;
		if (this.selectedLight?.type !== "directional") return null;
		this.updatePointer(event);
		const picked = pickHandleAtPointer(this.raycaster, this.pointer, this.viewport.cameraManager.activeCamera, this.orbitHandles.pickableMeshes(), this.canvas);
		return picked !== null && isOrbitHandleType(picked) ? picked : null;
	}
	pickMarker(event) {
		if (!this.gizmosOn) return null;
		this.updatePointer(event);
		const picked = pickHandleAtPointer(this.raycaster, this.pointer, this.viewport.cameraManager.activeCamera, this.overlay.markerMeshes(), this.canvas);
		if (picked === null) return null;
		const index = Number(picked);
		return Number.isInteger(index) ? index : null;
	}
	setHoveredHandle(type) {
		if (this.hoveredHandle === type) return;
		this.hoveredHandle = type;
		this.orbitHandles.setHovered(type);
		this.refreshCursor();
		this.viewport.forceRender();
	}
	setHoveredMarker(hovered) {
		if (this.hoveredMarker === hovered) return;
		this.hoveredMarker = hovered;
		this.refreshCursor();
	}
	refreshCursor() {
		this.canvas.style.cursor = this.hoveredHandle ? "grab" : this.hoveredMarker ? "pointer" : "";
	}
	onPointerDown = (event) => {
		if (event.button !== 0) return;
		const type = this.pickHandle(event);
		if (type) {
			this.setHoveredHandle(type);
			this.dragState = {
				type,
				pointerId: event.pointerId
			};
			this.canvas.setPointerCapture(event.pointerId);
			this.canvas.style.cursor = "grabbing";
			this.viewport.controlsManager.controls.enabled = false;
			event.stopPropagation();
			return;
		}
		const markerIndex = this.pickMarker(event);
		if (markerIndex === null) return;
		if (markerIndex !== this.overlay.getSelectedIndex()) {
			this.applyLights(this.overlay.getLights(), markerIndex);
			this.onSelectLight?.(markerIndex);
		}
		event.stopPropagation();
	};
	onPointerMove = (event) => {
		if (!this.dragState) {
			const handle = this.pickHandle(event);
			this.setHoveredHandle(handle);
			this.setHoveredMarker(!handle && this.pickMarker(event) !== null);
			return;
		}
		if (event.pointerId !== this.dragState.pointerId) return;
		this.updatePointer(event);
		this.raycaster.setFromCamera(this.pointer, this.viewport.cameraManager.activeCamera);
		const light = this.selectedLight;
		if (!light) return;
		const plane = this.orbitHandles.dragPlaneFor(this.dragState.type, orbitHandleState(light));
		const point = new Vector3();
		if (!this.raycaster.ray.intersectPlane(plane, point)) return;
		const handleType = this.dragState.type;
		this.mutateSelected((current) => applyOrbitDrag(handleType, current, point));
	};
	onPointerUp = (event) => {
		if (!this.dragState || event.pointerId !== this.dragState.pointerId) return;
		if (this.canvas.hasPointerCapture(event.pointerId)) this.canvas.releasePointerCapture(event.pointerId);
		this.dragState = null;
		this.viewport.controlsManager.controls.enabled = !this.cameraLocked;
		this.refreshCursor();
		this.onEditEnd?.();
	};
	onHandleDraggingChange(dragging) {
		this.viewport.controlsManager.controls.enabled = !dragging && !this.cameraLocked;
		if (!dragging) this.onEditEnd?.();
	}
};
function applyOrbitDrag(type, light, point) {
	const target = lightTarget(light);
	const angles = orbitAnglesFor(light.position, target);
	if (type === "yaw") angles.yaw = pointToYawAngle(point, target);
	else if (type === "pitch") angles.pitch = pointToPitchAngle(point, target, angles.yaw);
	else angles.distance = pointToDistance(point, target, angles.yaw, angles.pitch);
	return {
		...light,
		position: orbitPosition(target, angles.yaw, angles.pitch, angles.distance)
	};
}
function lightPositionApplies(type) {
	return type === "point" || type === "spot";
}
function targetApplies(type) {
	return type === "directional" || type === "spot";
}
//#endregion
//#region src/extensions/core/load3d/components/lightInfo/LightInfoViewportToolbar.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$1 = { class: "pointer-events-none absolute inset-0 flex flex-col" };
var _hoisted_2$1 = { key: 0 };
var _hoisted_3$1 = { key: 0 };
//#endregion
//#region src/extensions/core/load3d/components/lightInfo/LightInfoViewportToolbar.vue
var LightInfoViewportToolbar_default = /* @__PURE__ */ defineComponent({
	__name: "LightInfoViewportToolbar",
	props: /*@__PURE__*/ mergeModels({
		compact: { type: Boolean },
		lightType: {}
	}, {
		"gizmosOn": {
			type: Boolean,
			required: true
		},
		"gizmosOnModifiers": {},
		"transformGizmoMode": { required: true },
		"transformGizmoModeModifiers": {},
		"cameraLocked": {
			type: Boolean,
			required: true
		},
		"cameraLockedModifiers": {}
	}),
	emits: /*@__PURE__*/ mergeModels(["resetView"], [
		"update:gizmosOn",
		"update:transformGizmoMode",
		"update:cameraLocked"
	]),
	setup(__props, { emit: __emit }) {
		const gizmosOn = useModel(__props, "gizmosOn");
		const transformGizmoMode = useModel(__props, "transformGizmoMode");
		const cameraLocked = useModel(__props, "cameraLocked");
		const emit = __emit;
		const { t } = useI18n();
		const gizmosLabel = computed(() => gizmosOn.value ? t("load3d.hideGizmos") : t("load3d.showGizmos"));
		const cameraLockLabel = computed(() => cameraLocked.value ? t("load3d.unlockCamera") : t("load3d.lockCamera"));
		const transformGizmoOptions = computed(() => [
			{
				value: "none",
				labelKey: "load3d.transformGizmo.none",
				icon: "icon-[lucide--ban]",
				enabled: true
			},
			{
				value: "light-position",
				labelKey: "load3d.transformGizmo.lightPosition",
				icon: "icon-[lucide--move-3d]",
				enabled: __props.lightType !== null && lightPositionApplies(__props.lightType)
			},
			{
				value: "target",
				labelKey: "load3d.transformGizmo.target",
				icon: "icon-[lucide--target]",
				enabled: __props.lightType !== null && targetApplies(__props.lightType)
			}
		]);
		const effectiveTransformGizmoMode = computed(() => transformGizmoOptions.value.some(({ value, enabled }) => value === transformGizmoMode.value && enabled) ? transformGizmoMode.value : "none");
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$1, [
				createBaseVNode("div", {
					class: "pointer-events-auto flex h-10 items-center gap-1 bg-popover px-2",
					onWheel: _cache[1] || (_cache[1] = withModifiers(() => {}, ["stop"]))
				}, [
					createVNode(Button_default, {
						variant: "textonly",
						size: "unset",
						tooltip: gizmosLabel.value,
						"tooltip-side": "bottom",
						type: "button",
						class: normalizeClass(unref(actionClass)(gizmosOn.value)),
						"aria-pressed": gizmosOn.value,
						"aria-label": gizmosLabel.value,
						onClick: _cache[0] || (_cache[0] = ($event) => gizmosOn.value = !gizmosOn.value)
					}, {
						default: withCtx(() => [createBaseVNode("i", { class: normalizeClass(unref(cn)("size-4", gizmosOn.value ? "icon-[lucide--eye]" : "icon-[lucide--eye-off]")) }, null, 2), !__props.compact ? (openBlock(), createElementBlock("span", _hoisted_2$1, toDisplayString(gizmosLabel.value), 1)) : createCommentVNode("", true)]),
						_: 1
					}, 8, [
						"tooltip",
						"class",
						"aria-pressed",
						"aria-label"
					]),
					_cache[5] || (_cache[5] = createBaseVNode("div", { class: "mx-1 h-5 w-px shrink-0 bg-border" }, null, -1)),
					(openBlock(true), createElementBlock(Fragment, null, renderList(transformGizmoOptions.value, (option) => {
						return openBlock(), createBlock(Button_default, {
							key: option.value,
							variant: "textonly",
							size: "unset",
							tooltip: _ctx.$t(option.labelKey),
							"tooltip-side": "bottom",
							type: "button",
							disabled: !option.enabled,
							"aria-pressed": effectiveTransformGizmoMode.value === option.value,
							"aria-label": _ctx.$t(option.labelKey),
							class: normalizeClass(unref(actionClass)(effectiveTransformGizmoMode.value === option.value)),
							onClick: ($event) => transformGizmoMode.value = option.value
						}, {
							default: withCtx(() => [createBaseVNode("i", { class: normalizeClass(unref(cn)("size-4", option.icon)) }, null, 2), !__props.compact ? (openBlock(), createElementBlock("span", _hoisted_3$1, toDisplayString(_ctx.$t(option.labelKey)), 1)) : createCommentVNode("", true)]),
							_: 2
						}, 1032, [
							"tooltip",
							"disabled",
							"aria-pressed",
							"aria-label",
							"class",
							"onClick"
						]);
					}), 128))
				], 32),
				_cache[7] || (_cache[7] = createBaseVNode("div", { class: "flex-1" }, null, -1)),
				createBaseVNode("div", {
					class: "pointer-events-auto flex h-10 items-center justify-end gap-1 bg-popover px-2",
					onWheel: _cache[4] || (_cache[4] = withModifiers(() => {}, ["stop"]))
				}, [createVNode(Button_default, {
					variant: "textonly",
					size: "icon",
					tooltip: _ctx.$t("load3d.outputView"),
					type: "button",
					"aria-label": _ctx.$t("load3d.outputView"),
					onClick: _cache[2] || (_cache[2] = ($event) => emit("resetView"))
				}, {
					default: withCtx(() => [..._cache[6] || (_cache[6] = [createBaseVNode("i", { class: "icon-[lucide--focus] size-4" }, null, -1)])]),
					_: 1
				}, 8, ["tooltip", "aria-label"]), createVNode(Button_default, {
					variant: "textonly",
					size: "icon",
					tooltip: cameraLockLabel.value,
					type: "button",
					class: normalizeClass(unref(cn)(cameraLocked.value && "bg-muted")),
					"aria-pressed": cameraLocked.value,
					"aria-label": cameraLockLabel.value,
					onClick: _cache[3] || (_cache[3] = ($event) => cameraLocked.value = !cameraLocked.value)
				}, {
					default: withCtx(() => [createBaseVNode("i", { class: normalizeClass(unref(cn)("size-4", cameraLocked.value ? "icon-[lucide--lock]" : "icon-[lucide--lock-open]")) }, null, 2)]),
					_: 1
				}, 8, [
					"tooltip",
					"class",
					"aria-pressed",
					"aria-label"
				])], 32)
			]);
		};
	}
});
//#endregion
//#region src/extensions/core/load3d/composables/useLightInfo.ts
var EDITOR_WIDGET_NAME = "editor_state";
function useLightInfo(nodeRef, historyScope = () => null) {
	let viewport = null;
	let host = null;
	let stopObserving = null;
	const wiring = useViewportNodeWiring();
	let suppressEcho = false;
	const lights = ref([]);
	const selectedIndex = ref(-1);
	const selectedLight = computed(() => lights.value[selectedIndex.value] ?? null);
	const { canUndo, canRedo, undo, redo, commit: commitHistory, syncBaseline, discardHistory } = useWidgetValueHistory({
		scope: historyScope,
		read: () => lights.value,
		apply: (value) => commit(normalizeLightsValue(value))
	});
	const initialize = (container) => {
		const raw = toRaw(unref(nodeRef));
		if (!raw) return;
		if (viewport) cleanup();
		try {
			host = raw;
			lights.value = normalizeLightsValue(getNodeWidgetValue(raw, EDITOR_WIDGET_NAME));
			selectedIndex.value = lights.value.length ? 0 : -1;
			syncBaseline();
			viewport = new LightInfoViewport(container, lights.value, {
				onLightsChange: (next) => {
					lights.value = next;
					writeWidgetValue(next);
				},
				onSelectLight: (index) => {
					selectedIndex.value = index;
				},
				onEditEnd: () => commitHistory()
			});
			viewport.applyLights(lights.value, selectedIndex.value);
			observeExternalChanges(raw);
			wiring.wireNode(raw, { viewport: () => viewport?.viewport });
		} catch (error) {
			reportError(error, {
				errorType: "failure_initializing_light_info_viewport",
				surface: "graph"
			});
			cleanup();
			useToast().warning(t("toastMessages.failedToInitializeLightInfoViewer"));
		}
	};
	const cleanup = () => {
		stopObserving?.();
		stopObserving = null;
		wiring.unwire();
		host = null;
		viewport?.remove();
		viewport = null;
	};
	const { handleMouseEnter, handleMouseLeave } = createSceneHoverHandlers(() => viewport?.viewport);
	const setGizmosVisible = (on) => {
		viewport?.setGizmosVisible(on);
	};
	const setTransformGizmoMode = (mode) => {
		viewport?.setTransformGizmoMode(mode);
	};
	const resetViewToOutput = () => {
		viewport?.resetViewToOutput();
	};
	const setCameraLocked = (locked) => {
		viewport?.setCameraLocked(locked);
	};
	const selectLight = (index) => {
		if (index < 0 || index >= lights.value.length) return;
		selectedIndex.value = index;
		viewport?.applyLights(lights.value, index);
	};
	const addLight = (type) => {
		const next = [...lights.value, createDefaultLight(type)];
		selectedIndex.value = next.length - 1;
		commit(next);
		commitHistory();
	};
	const removeSelectedLight = () => {
		if (selectedIndex.value < 0) return;
		const next = [...lights.value];
		next.splice(selectedIndex.value, 1);
		selectedIndex.value = Math.min(selectedIndex.value, next.length - 1);
		commit(next);
		commitHistory();
	};
	const updateSelectedLight = (patch) => {
		const current = selectedLight.value;
		if (!current) return;
		const next = [...lights.value];
		next[selectedIndex.value] = normalizeLightsValue([{
			...current,
			...patch
		}])[0];
		commit(next);
		commitHistory(`light:${selectedIndex.value}:${Object.keys(patch).sort().join(",")}`);
	};
	const setSelectedLightType = (type) => {
		const current = selectedLight.value;
		if (!current || current.type === type) return;
		const base = createDefaultLight(type);
		const next = [...lights.value];
		next[selectedIndex.value] = {
			...base,
			color: current.color,
			position: { ...current.position },
			...base.target && current.target ? { target: { ...current.target } } : {}
		};
		commit(next);
		commitHistory();
	};
	function commit(next) {
		lights.value = next;
		if (selectedIndex.value >= next.length) selectedIndex.value = next.length - 1;
		else if (selectedIndex.value < 0 && next.length) selectedIndex.value = 0;
		writeWidgetValue(next);
		viewport?.applyLights(next, selectedIndex.value);
	}
	function writeWidgetValue(next) {
		if (!host) return;
		suppressEcho = true;
		try {
			setNodeWidgetValue(host, EDITOR_WIDGET_NAME, cloneLights(next));
		} finally {
			suppressEcho = false;
		}
	}
	function applyExternalValue(value) {
		if (suppressEcho || !viewport) return;
		lights.value = normalizeLightsValue(value);
		if (selectedIndex.value >= lights.value.length) selectedIndex.value = lights.value.length - 1;
		else if (selectedIndex.value < 0 && lights.value.length) selectedIndex.value = 0;
		viewport.applyLights(lights.value, selectedIndex.value);
		discardHistory();
	}
	function observeExternalChanges(target) {
		const graphId = target.graph?.rootGraph.id;
		if (!graphId) return;
		stopObserving = onGraphIntent((intent) => {
			if (intent.type === "set_widget" && intent.graphId === graphId && intent.nodeId === target.id && intent.name === EDITOR_WIDGET_NAME) applyExternalValue(intent.value);
		});
	}
	return {
		initialize,
		cleanup,
		handleMouseEnter,
		handleMouseLeave,
		setGizmosVisible,
		setTransformGizmoMode,
		resetViewToOutput,
		setCameraLocked,
		lights,
		selectedIndex,
		selectedLight,
		selectLight,
		addLight,
		removeSelectedLight,
		updateSelectedLight,
		setSelectedLightType,
		canUndo,
		canRedo,
		undo,
		redo
	};
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.useLightInfo = window.comfyAPI.useLightInfo || {};
window.comfyAPI.useLightInfo.useLightInfo = useLightInfo;
//#endregion
//#region src/extensions/core/load3d/components/lightInfo/LightInfo.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = {
	class: "flex min-h-0 flex-1 flex-col gap-1 overflow-y-auto",
	"data-capture-wheel": "true"
};
var _hoisted_2 = { class: "flex h-9 items-center gap-1 overflow-x-auto px-1" };
var _hoisted_3 = {
	key: 1,
	class: "px-2 pb-1 text-muted-foreground"
};
var COMPACT_WIDTH_THRESHOLD = 480;
var PANEL_BUDGET_WIDE = 208;
var PANEL_BUDGET_COMPACT = 352;
//#endregion
//#region src/extensions/core/load3d/components/lightInfo/LightInfo.vue
var LightInfo_default = /* @__PURE__ */ defineComponent({
	__name: "LightInfo",
	props: {
		nodeId: {},
		widget: {}
	},
	setup(__props) {
		function chipNumber(index) {
			return String(index + 1).padStart(2, "0");
		}
		function lightChipClass(active) {
			return cn(chipClass, "border border-transparent bg-transparent font-mono text-xs", active ? "border-node-border bg-muted text-foreground" : "text-muted-foreground hover:bg-accent hover:text-foreground");
		}
		const node = shallowRef(null);
		const container = ref(null);
		const viewportArea = ref(null);
		const { width: viewportWidth } = useElementSize(viewportArea);
		const compact = computed(() => viewportWidth.value > 0 && viewportWidth.value < COMPACT_WIDTH_THRESHOLD);
		const panelBudget = computed(() => compact.value ? PANEL_BUDGET_COMPACT : PANEL_BUDGET_WIDE);
		const gizmosOn = ref(true);
		const transformGizmoMode = ref("none");
		const cameraLocked = ref(false);
		const { initialize, cleanup, handleMouseEnter, handleMouseLeave, setGizmosVisible, setTransformGizmoMode, resetViewToOutput, setCameraLocked, lights, selectedIndex, selectedLight, selectLight, addLight, removeSelectedLight, updateSelectedLight, setSelectedLightType, canUndo, canRedo, undo, redo } = useLightInfo(node, () => __props.widget ? widgetHistoryScope(__props.widget, __props.nodeId) : null);
		watch(gizmosOn, (on) => setGizmosVisible(on));
		watch(transformGizmoMode, (mode) => setTransformGizmoMode(mode));
		watch(cameraLocked, (locked) => setCameraLocked(locked));
		onMounted(() => {
			node.value = resolveNode(__props.nodeId) ?? null;
			if (container.value) initialize(container.value);
		});
		onUnmounted(() => {
			cleanup();
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				class: "flex size-full min-h-[300px] flex-col gap-1",
				onPointerdown: _cache[7] || (_cache[7] = withModifiers(() => {}, ["stop"])),
				onMousedown: _cache[8] || (_cache[8] = withModifiers(() => {}, ["stop"])),
				onContextmenu: _cache[9] || (_cache[9] = withModifiers(() => {}, ["stop", "prevent"]))
			}, [createBaseVNode("div", {
				ref_key: "viewportArea",
				ref: viewportArea,
				class: "relative min-h-[220px] shrink-0",
				style: normalizeStyle({ height: `calc(100% - ${panelBudget.value}px)` })
			}, [createBaseVNode("div", {
				ref_key: "container",
				ref: container,
				class: "relative size-full",
				"data-capture-wheel": "true",
				tabindex: "-1",
				onPointerdown: _cache[0] || (_cache[0] = withModifiers(($event) => container.value?.focus(), ["stop"])),
				onMouseenter: _cache[1] || (_cache[1] = (...args) => unref(handleMouseEnter) && unref(handleMouseEnter)(...args)),
				onMouseleave: _cache[2] || (_cache[2] = (...args) => unref(handleMouseLeave) && unref(handleMouseLeave)(...args))
			}, null, 544), createVNode(LightInfoViewportToolbar_default, {
				"gizmos-on": gizmosOn.value,
				"onUpdate:gizmosOn": _cache[3] || (_cache[3] = ($event) => gizmosOn.value = $event),
				"transform-gizmo-mode": transformGizmoMode.value,
				"onUpdate:transformGizmoMode": _cache[4] || (_cache[4] = ($event) => transformGizmoMode.value = $event),
				"camera-locked": cameraLocked.value,
				"onUpdate:cameraLocked": _cache[5] || (_cache[5] = ($event) => cameraLocked.value = $event),
				compact: compact.value,
				"light-type": unref(selectedLight)?.type ?? null,
				onResetView: unref(resetViewToOutput)
			}, null, 8, [
				"gizmos-on",
				"transform-gizmo-mode",
				"camera-locked",
				"compact",
				"light-type",
				"onResetView"
			])], 4), createBaseVNode("div", _hoisted_1, [createBaseVNode("div", _hoisted_2, [
				(openBlock(true), createElementBlock(Fragment, null, renderList(unref(lights), (light, index) => {
					return openBlock(), createBlock(Button_default, {
						key: index,
						tooltip: _ctx.$t(unref(LIGHT_TYPE_LABEL_KEYS)[light.type]),
						variant: "textonly",
						size: "unset",
						"aria-pressed": index === unref(selectedIndex),
						"aria-label": _ctx.$t("lightInfo.lightChip", {
							index: chipNumber(index),
							type: _ctx.$t(unref(LIGHT_TYPE_LABEL_KEYS)[light.type])
						}),
						class: normalizeClass(lightChipClass(index === unref(selectedIndex))),
						onClick: ($event) => unref(selectLight)(index)
					}, {
						default: withCtx(() => [createBaseVNode("span", {
							class: "size-2.5 shrink-0 rounded-full",
							style: normalizeStyle({ backgroundColor: light.color })
						}, null, 4), createTextVNode(" " + toDisplayString(chipNumber(index)), 1)]),
						_: 2
					}, 1032, [
						"tooltip",
						"aria-pressed",
						"aria-label",
						"class",
						"onClick"
					]);
				}), 128)),
				createVNode(Button_default, {
					tooltip: _ctx.$t("lightInfo.addLight"),
					variant: "textonly",
					size: "icon",
					"aria-label": _ctx.$t("lightInfo.addLight"),
					onClick: _cache[6] || (_cache[6] = ($event) => unref(addLight)("directional"))
				}, {
					default: withCtx(() => [..._cache[10] || (_cache[10] = [createBaseVNode("i", { class: "icon-[lucide--plus] size-4" }, null, -1)])]),
					_: 1
				}, 8, ["tooltip", "aria-label"]),
				unref(selectedLight) ? (openBlock(), createBlock(Button_default, {
					key: 0,
					tooltip: _ctx.$t("lightInfo.removeLight"),
					variant: "textonly",
					size: "icon",
					"aria-label": _ctx.$t("lightInfo.removeLight"),
					onClick: unref(removeSelectedLight)
				}, {
					default: withCtx(() => [..._cache[11] || (_cache[11] = [createBaseVNode("i", { class: "icon-[lucide--trash-2] size-4" }, null, -1)])]),
					_: 1
				}, 8, [
					"tooltip",
					"aria-label",
					"onClick"
				])) : createCommentVNode("", true),
				createVNode(WidgetHistoryButtons_default, {
					class: "ml-auto",
					"can-undo": unref(canUndo),
					"can-redo": unref(canRedo),
					onUndo: unref(undo),
					onRedo: unref(redo)
				}, null, 8, [
					"can-undo",
					"can-redo",
					"onUndo",
					"onRedo"
				])
			]), unref(selectedLight) ? (openBlock(), createBlock(LightInfoLightEditor_default, {
				key: 0,
				light: unref(selectedLight),
				compact: compact.value,
				onUpdate: unref(updateSelectedLight),
				onChangeType: unref(setSelectedLightType)
			}, null, 8, [
				"light",
				"compact",
				"onUpdate",
				"onChangeType"
			])) : (openBlock(), createElementBlock("div", _hoisted_3, toDisplayString(_ctx.$t("lightInfo.noLights")), 1))])], 32);
		};
	}
});
//#endregion
export { LightInfo_default as default };
