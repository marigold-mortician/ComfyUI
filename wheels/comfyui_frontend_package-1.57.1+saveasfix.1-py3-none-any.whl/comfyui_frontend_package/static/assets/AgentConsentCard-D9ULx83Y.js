import "./rolldown-runtime-xtsTai4I.js";
import { F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, I as createBlock, Kt as normalizeClass, L as createCommentVNode, O as Fragment, P as computed, R as createElementBlock, U as createVNode, Wt as unref, Yt as toDisplayString, at as onMounted, ct as openBlock, gt as useId, ut as renderList, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { gr as useMediaQuery } from "./vendor-reka-ui-NRTk7aIV.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { t as applyDarkPaletteTheme } from "./colorPaletteTheme-BLTbQMIT.js";
import { t as DialogTitle_default } from "./DialogTitle-CWOHHLwH.js";
import { t as Video_default } from "./Video-9q8givji.js";
//#region src/workbench/extensions/agent/components/agent/AgentConsentCard.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = {
	key: 0,
	role: "alert",
	class: "my-0 text-sm/5 text-destructive"
};
var _hoisted_2 = {
	key: 0,
	class: "flex flex-wrap items-center justify-between gap-x-3 gap-y-1"
};
var _hoisted_3 = ["id"];
var _hoisted_4 = { class: "flex flex-wrap gap-2.5" };
//#endregion
//#region src/workbench/extensions/agent/components/agent/AgentConsentCard.vue
var AgentConsentCard_default = /* @__PURE__ */ defineComponent({
	__name: "AgentConsentCard",
	props: {
		title: {},
		paragraphs: {},
		videoSources: { default: () => [] },
		posterSrc: { default: "" },
		docsUrl: { default: "" },
		requiresSignIn: {
			type: Boolean,
			default: false
		},
		accepting: {
			type: Boolean,
			default: false
		},
		error: { default: "" }
	},
	emits: ["reject", "accept"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const containerRef = ref();
		const isTwoColumn = useMediaQuery("(min-width: 700px) and (height < 650px)");
		const isShortViewport = useMediaQuery("(height < 680px)");
		const isCompact = computed(() => isShortViewport.value && !isTwoColumn.value);
		const layoutClasses = computed(() => ({
			width: isTwoColumn.value ? "w-[min(960px,calc(100vw-2rem))]" : "w-[min(600px,calc(100vw-2rem))]",
			heading: isCompact.value ? "text-[22px]/7" : void 0,
			video: isCompact.value ? "max-h-41.5" : isTwoColumn.value ? "max-h-[calc(85dvh-2.5rem)]" : "max-h-[min(238px,calc(85dvh-22rem))]",
			fallback: isCompact.value ? "max-h-41.5" : "max-h-59.5"
		}));
		const signInHintId = useId();
		const hasConsentHelp = computed(() => Boolean(__props.docsUrl || __props.requiresSignIn));
		const acceptAction = computed(() => __props.requiresSignIn ? {
			labelKey: "agent.consent.agreeAndContinue",
			describedBy: signInHintId
		} : {
			labelKey: "agent.consent.accept",
			describedBy: void 0
		});
		onMounted(() => {
			if (containerRef.value) applyDarkPaletteTheme(containerRef.value.style);
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				ref_key: "containerRef",
				ref: containerRef,
				class: normalizeClass(unref(cn)("max-w-full", layoutClasses.value.width))
			}, [createBaseVNode("div", {
				"data-testid": "agent-consent-card",
				class: normalizeClass(unref(cn)("grid max-h-[85dvh] gap-4.5 overflow-y-auto overscroll-contain rounded-2xl border bg-background p-6 shadow-2xl", unref(isTwoColumn) && "grid-cols-2 grid-rows-[auto_auto] gap-x-7 gap-y-3.5 p-5", isCompact.value && "gap-3 p-4.5"))
			}, [
				createBaseVNode("div", { class: normalizeClass(unref(cn)("min-w-0", unref(isTwoColumn) && "row-span-2 self-center")) }, [createVNode(Video_default, {
					sources: __props.videoSources,
					"poster-src": __props.posterSrc,
					autoplay: "",
					muted: "",
					loop: "",
					"plays-inline": "",
					"data-testid": "agent-consent-video",
					class: normalizeClass(unref(cn)("mx-auto aspect-video w-full max-w-full rounded-lg object-contain", layoutClasses.value.video))
				}, {
					fallback: withCtx(() => [createBaseVNode("div", { class: normalizeClass(unref(cn)("grid aspect-video w-full place-items-center rounded-lg bg-secondary text-xs text-muted-foreground", layoutClasses.value.fallback)) }, toDisplayString(_ctx.$t("agent.consent.videoPlaceholder")), 3)]),
					_: 1
				}, 8, [
					"sources",
					"poster-src",
					"class"
				])], 2),
				createBaseVNode("section", { class: normalizeClass(unref(cn)("flex min-w-0 flex-col gap-3", unref(isTwoColumn) && "col-start-2 row-start-1 gap-2.5", isCompact.value && "gap-2")) }, [
					createVNode(DialogTitle_default, { class: normalizeClass(unref(cn)("my-0 text-2xl/7.5", layoutClasses.value.heading)) }, {
						default: withCtx(() => [createTextVNode(toDisplayString(__props.title), 1)]),
						_: 1
					}, 8, ["class"]),
					(openBlock(true), createElementBlock(Fragment, null, renderList(__props.paragraphs, (paragraph, index) => {
						return openBlock(), createElementBlock("p", {
							key: index,
							class: normalizeClass(unref(cn)("my-0 text-sm/5 text-muted-foreground", isCompact.value && "text-[13px]/4.5"))
						}, toDisplayString(paragraph), 3);
					}), 128)),
					__props.error ? (openBlock(), createElementBlock("p", _hoisted_1, toDisplayString(__props.error), 1)) : createCommentVNode("", true)
				], 2),
				createBaseVNode("footer", { class: normalizeClass(unref(cn)("flex min-w-0 flex-col gap-2.5", unref(isTwoColumn) && "col-start-2 row-start-2")) }, [hasConsentHelp.value ? (openBlock(), createElementBlock("div", _hoisted_2, [__props.docsUrl ? (openBlock(), createBlock(Button_default, {
					key: 0,
					variant: "link",
					size: "link",
					class: "w-fit py-0 text-xs/5",
					as: "a",
					href: __props.docsUrl,
					target: "_blank",
					rel: "noopener noreferrer"
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("agent.consent.readDocs")) + " ", 1), _cache[2] || (_cache[2] = createBaseVNode("span", { class: "icon-[lucide--square-arrow-out-up-right] size-3" }, null, -1))]),
					_: 1
				}, 8, ["href"])) : createCommentVNode("", true), __props.requiresSignIn ? (openBlock(), createElementBlock("p", {
					key: 1,
					id: unref(signInHintId),
					class: "my-0 text-xs/5 text-muted-foreground"
				}, toDisplayString(_ctx.$t("agent.consent.signInNext")), 9, _hoisted_3)) : createCommentVNode("", true)])) : createCommentVNode("", true), createBaseVNode("div", _hoisted_4, [!__props.accepting ? (openBlock(), createBlock(Button_default, {
					key: 0,
					variant: "secondary",
					size: "lg",
					class: "h-auto min-h-11 max-w-full whitespace-normal",
					onClick: _cache[0] || (_cache[0] = ($event) => emit("reject"))
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("agent.consent.reject")), 1)]),
					_: 1
				})) : createCommentVNode("", true), createVNode(Button_default, {
					variant: "inverted",
					size: "lg",
					class: "h-auto min-h-11 max-w-full flex-1 whitespace-normal",
					loading: __props.accepting,
					disabled: __props.accepting,
					"aria-describedby": acceptAction.value.describedBy,
					onClick: _cache[1] || (_cache[1] = ($event) => emit("accept"))
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t(acceptAction.value.labelKey)), 1)]),
					_: 1
				}, 8, [
					"loading",
					"disabled",
					"aria-describedby"
				])])], 2)
			], 2)], 2);
		};
	}
});
//#endregion
export { AgentConsentCard_default as default };
