import "./rolldown-runtime-xtsTai4I.js";
import { t as delay } from "./delay-Cu8bS1zn.js";
import { E as platformLink, M as useFreeTierQuota, p as createJourneyId, t as useBillingContext, y as paymentIntentSourceForAddCreditsClick } from "./useBillingContext-Cc-YANxo.js";
import { o as WorkspaceApiError, r as workspaceApi, t as useTeamWorkspaceStore } from "./teamWorkspaceStore-BNm5cZOK.js";
import { F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, Ht as toValue, I as createBlock, Kt as normalizeClass, L as createCommentVNode, O as Fragment, P as computed, R as createElementBlock, Rt as shallowRef, U as createVNode, Wt as unref, Yt as toDisplayString, at as onMounted, bt as watch, ct as openBlock, dt as renderSlot, ut as renderList, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { Fr as createSharedComposable, Qn as useDocumentVisibility, qn as useAsyncState } from "./vendor-reka-ui-NRTk7aIV.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { n as useTelemetry } from "./telemetry-IkzvF0TI.js";
import { r as reportError } from "./reportError-BHgDVvfb.js";
import { t as DialogTitle_default } from "./DialogTitle-CWOHHLwH.js";
import { t as useFeatureFlags } from "./useFeatureFlags-B3zg5FdZ.js";
import { f as useApiKeyAuthStore, r as useAuthStore } from "./authStore-D2cL6XhN.js";
import { d as isSalesManagedTier } from "./tierPricing-Dm5JzLf8.js";
import { i as formatCreditsFromCents, o as formatUsdFromCents, r as formatCredits, t as centsToCredits } from "./creditsUtil-DxLnYjvD.js";
import { t as useBillingCapabilities } from "./useBillingCapabilities-x1h7nBmq.js";
import { n as useTopUpPlanCreditCopy, t as useBillingDialogs } from "./useBillingDialogs-Bc5B2YTn.js";
import { t as useSubscriptionPaywall } from "./useSubscriptionPaywall-DbqkouMv.js";
import { t as useWorkspaceUI } from "./useWorkspaceUI-CALMkHxF.js";
import { n as usePaymentRecoveryDialog, t as isTopUpDeniedPastDue } from "./usePaymentRecoveryDialog-DeFBWQ7b.js";
import { t as DialogClose_default } from "./DialogClose-dPzCXguP.js";
import { t as Skeleton_default } from "./Skeleton-COEG5vV3.js";
import { i as Dialog_default, n as DialogOverlay_default, r as DialogContent_default, t as DialogPortal_default } from "./DialogPortal-Dg32KeeQ.js";
import { t as DialogFooter_default } from "./DialogFooter-vpYOaTtS.js";
import { t as DialogHeader_default } from "./DialogHeader-C7IU_d9Y.js";
import { r as resolveSubscriptionTierKey, t as useScheduledPlanChange } from "./useScheduledPlanChange-BZgRnb-d.js";
import { n as usePausedBanner, o as WorkspaceHeaderMenu_default, t as pausedBannerCopy } from "./usePausedBanner-CAOtpjFX.js";
import { t as DialogDescription_default } from "./DialogDescription-C7bPVGYH.js";
import { t as getPlanCreditGrant } from "./planCreditGrant-DHIjEmw5.js";
//#region src/platform/billing/components/billingTab/BillingAutoTopUpBanner.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$9 = {
	class: "@container",
	"data-testid": "billing-auto-top-up-banner"
};
var _hoisted_2$9 = {
	role: "status",
	class: "flex flex-col gap-3 rounded-xl border border-border/60 bg-background p-3 @2xl:flex-row @2xl:items-center @2xl:gap-2"
};
var _hoisted_3$8 = { class: "flex min-w-0 flex-1 flex-col gap-2" };
var _hoisted_4$8 = { class: "flex items-center gap-2" };
var _hoisted_5$8 = { class: "text-sm text-foreground" };
var _hoisted_6$4 = { class: "m-0 pl-6 text-sm text-muted-foreground" };
//#endregion
//#region src/platform/billing/components/billingTab/BillingAutoTopUpBanner.vue
var BillingAutoTopUpBanner_default = /* @__PURE__ */ defineComponent({
	__name: "BillingAutoTopUpBanner",
	props: { kind: {} },
	setup(__props) {
		const COPY = {
			autoTopUpFailed: {
				title: "workspacePanel.billingStatus.autoTopUpFailed.title",
				body: "workspacePanel.billingStatus.autoTopUpFailed.body"
			},
			autoTopUpOff: {
				title: "workspacePanel.billingStatus.autoTopUpOff.title",
				body: "workspacePanel.billingStatus.autoTopUpOff.body"
			}
		};
		const copy = computed(() => COPY[__props.kind]);
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$9, [createBaseVNode("div", _hoisted_2$9, [createBaseVNode("div", _hoisted_3$8, [createBaseVNode("div", _hoisted_4$8, [_cache[0] || (_cache[0] = createBaseVNode("i", { class: "icon-[lucide--triangle-alert] size-4 shrink-0 text-warning" }, null, -1)), createBaseVNode("span", _hoisted_5$8, toDisplayString(_ctx.$t(copy.value.title)), 1)]), createBaseVNode("p", _hoisted_6$4, toDisplayString(_ctx.$t(copy.value.body)), 1)]), renderSlot(_ctx.$slots, "default")])]);
		};
	}
});
//#endregion
//#region src/platform/billing/composables/useBillingAutoTopUpCard.ts
function useBillingAutoTopUpCardInternal() {
	const authStore = useAuthStore();
	const apiKeyAuthStore = useApiKeyAuthStore();
	const workspaceStore = useTeamWorkspaceStore();
	const scope = computed(() => {
		const actorId = authStore.userId ?? apiKeyAuthStore.currentUser?.id;
		const workspaceId = workspaceStore.activeWorkspaceId;
		return actorId && workspaceId ? `${actorId}:${workspaceId}` : null;
	});
	let requested = false;
	let refreshSerial = 0;
	let inFlightScope = null;
	let committed = null;
	async function readCurrentScope() {
		const requestScope = scope.value;
		if (requestScope === null) return null;
		const serial = ++refreshSerial;
		inFlightScope = requestScope;
		try {
			const next = {
				scope: requestScope,
				settings: await workspaceApi.getBillingAutoReload()
			};
			if (serial !== refreshSerial) return committed;
			committed = next;
			return next;
		} catch (error) {
			reportError(error, {
				errorType: "auto_top_up_read_failed",
				surface: "billing"
			});
			if (serial !== refreshSerial) return committed;
			if (committed?.scope === requestScope && committed.settings) return committed;
			const failed = {
				scope: requestScope,
				settings: null
			};
			committed = failed;
			return failed;
		} finally {
			if (inFlightScope === requestScope) inFlightScope = null;
		}
	}
	const read = useAsyncState(readCurrentScope, null, {
		immediate: false,
		resetOnExecute: false
	});
	const answer = computed(() => {
		const current = read.state.value;
		return current?.scope === scope.value ? current : null;
	});
	const state = computed(() => {
		const settings = answer.value?.settings;
		if (read.isLoading.value && !settings) return { kind: "loading" };
		if (settings) return {
			kind: "loaded",
			settings
		};
		return { kind: "unavailable" };
	});
	const isReady = computed(() => answer.value !== null && !read.isLoading.value);
	function refresh() {
		if (scope.value === null || inFlightScope === scope.value) return;
		read.execute();
	}
	function ensureRead() {
		requested = true;
		if (scope.value === null) return;
		if (answer.value !== null) return;
		refresh();
	}
	async function retry() {
		await read.execute();
	}
	watch(scope, () => {
		if (requested) ensureRead();
	});
	watch(useDocumentVisibility(), (visibility) => {
		if (visibility === "visible" && requested) refresh();
	});
	return {
		state,
		isReady,
		ensureRead,
		retry
	};
}
var useBillingAutoTopUpCard = createSharedComposable(useBillingAutoTopUpCardInternal);
//#endregion
//#region src/platform/billing/composables/deriveAutoTopUpBanner.ts
function deriveAutoTopUpBanner(input) {
	if (!input.enabled || !input.canManageAutoTopUp) return null;
	if (input.isPaused || !input.hasActivePlan) return null;
	if (input.status !== "failed") return null;
	return input.disabledReason === "consecutive_declines" ? "autoTopUpOff" : "autoTopUpFailed";
}
//#endregion
//#region src/platform/billing/composables/useAutoTopUpBannerKind.ts
function useAutoTopUpBannerKind() {
	useBillingContext();
	const { flags } = useFeatureFlags();
	const { canManageAutoTopUp } = useBillingCapabilities();
	const { isPaused } = usePausedBanner();
	const readEnabled = computed(() => {
		if (!flags.autoTopUpEnabled) return false;
		return canManageAutoTopUp.value;
	});
	const { state, ensureRead } = useBillingAutoTopUpCard();
	watch(readEnabled, (enabled) => {
		if (enabled) ensureRead();
	}, { immediate: true });
	return computed(() => {
		const read = state.value;
		const loaded = read.kind === "loaded" ? read.settings : null;
		return deriveAutoTopUpBanner({
			enabled: flags.autoTopUpEnabled,
			canManageAutoTopUp: canManageAutoTopUp.value,
			isPaused: isPaused.value,
			hasActivePlan: true,
			status: loaded?.status ?? null,
			disabledReason: loaded?.disabled_reason ?? null
		});
	});
}
//#endregion
//#region src/platform/billing/composables/deriveLocalCreditBanner.ts
function deriveLocalCreditBanner(input) {
	if (!input.unifiedBillingSettingsEnabled) return null;
	if (input.autoTopUp) return input.autoTopUp;
	if (input.isCloud && !input.isActive) return null;
	if (input.hasFunds === false && !input.outOfCreditsDismissed) return "outOfCredits";
	if (input.lowBalance === true && !input.lowCreditsDismissed) return "lowCredits";
	return null;
}
//#endregion
//#region src/platform/workspace/composables/usePlatformHandoff.ts
/** A platform link that carries one journey id and reports the click with it. */
function usePlatformHandoff(path, destination) {
	const correlationId = ref(createJourneyId());
	const href = computed(() => platformLink(toValue(path), correlationId.value));
	function track() {
		useTelemetry()?.trackBillingEvent({
			operation: "platform_handoff",
			stage: "opened",
			outcome: "pending",
			correlation_id: correlationId.value,
			...toValue(destination)
		});
		setTimeout(() => {
			correlationId.value = createJourneyId();
		});
	}
	return {
		href,
		track
	};
}
//#endregion
//#region src/platform/billing/components/billingTab/BillingLocalCreditBanner.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$8 = {
	key: 1,
	class: "@container",
	"data-testid": "billing-local-credit-banner"
};
var _hoisted_2$8 = {
	role: "status",
	class: "flex flex-col gap-3 rounded-xl border border-border/60 bg-background p-3 @2xl:flex-row @2xl:items-center @2xl:gap-2"
};
var _hoisted_3$7 = { class: "flex min-w-0 flex-1 flex-col gap-2" };
var _hoisted_4$7 = { class: "flex items-center gap-2" };
var _hoisted_5$7 = { class: "text-sm text-foreground" };
var _hoisted_6$3 = { class: "m-0 pl-6 text-sm text-muted-foreground" };
var _hoisted_7$2 = {
	key: 0,
	class: "flex shrink-0 flex-wrap items-center gap-2 pl-6 @2xl:pl-0"
};
var bs = "workspacePanel.billingStatus";
//#endregion
//#region src/platform/billing/components/billingTab/BillingLocalCreditBanner.vue
var BillingLocalCreditBanner_default = /* @__PURE__ */ defineComponent({
	__name: "BillingLocalCreditBanner",
	props: { suppressed: {
		type: Boolean,
		default: false
	} },
	setup(__props) {
		const billing = useBillingContext();
		const { flags } = useFeatureFlags();
		const { permissions } = useWorkspaceUI();
		const { canTopUp, topUpDenial, canManageBilling } = useBillingCapabilities();
		const { showTopUpCreditsDialog } = useBillingDialogs();
		const { updatePayment, isUpdatingPayment } = usePaymentRecoveryDialog();
		const { t, d, locale } = useI18n();
		const outOfCreditsDismissed = ref(false);
		const lowCreditsDismissed = ref(false);
		const subscription = computed(() => billing.subscription?.value ?? null);
		const balance = computed(() => billing.balance?.value ?? null);
		const isTeamPlan = computed(() => billing.isTeamPlan?.value ?? false);
		const autoTopUp = useAutoTopUpBannerKind();
		const { href, track } = usePlatformHandoff("/profile/billing", {
			target: "auto_top_up",
			action: "update_payment"
		});
		const kind = computed(() => {
			if (__props.suppressed) return null;
			return deriveLocalCreditBanner({
				autoTopUp: autoTopUp.value,
				unifiedBillingSettingsEnabled: flags.unifiedBillingSettingsEnabled,
				isCloud: false,
				isActive: subscription.value?.isActive === true,
				hasFunds: subscription.value?.hasFunds ?? null,
				lowBalance: balance.value?.lowBalance,
				outOfCreditsDismissed: outOfCreditsDismissed.value,
				lowCreditsDismissed: lowCreditsDismissed.value
			});
		});
		const autoTopUpKind = computed(() => kind.value === "autoTopUpFailed" || kind.value === "autoTopUpOff" ? kind.value : null);
		watch(() => subscription.value?.hasFunds === false, (exhausted) => {
			if (!exhausted) outOfCreditsDismissed.value = false;
		});
		watch(() => balance.value?.lowBalance === true, (low) => {
			if (!low) lowCreditsDismissed.value = false;
		});
		const availableCents = computed(() => {
			const current = balance.value;
			if (!current) return null;
			return current.effectiveBalanceMicros ?? current.amountMicros;
		});
		watch(availableCents, (cents, previous) => {
			if (previous != null && cents !== previous) lowCreditsDismissed.value = false;
		});
		const audience = computed(() => isTeamPlan.value ? "team" : "personal");
		function longDate(raw) {
			const date = raw ? new Date(raw) : null;
			if (!date || Number.isNaN(date.getTime())) return "";
			return d(date, {
				year: "numeric",
				month: "long",
				day: "numeric"
			});
		}
		const cycleResetDate = computed(() => longDate(billing.renewalDate?.value ?? null));
		function datedBody(key, noDateKey) {
			return cycleResetDate.value ? t(key, { date: cycleResetDate.value }) : t(noDateKey);
		}
		function pastDueBodyKey() {
			if (audience.value === "personal") return `${bs}.outOfCredits.pastDuePersonalBody`;
			return canManageBilling.value ? `${bs}.outOfCredits.pastDueBody` : `${bs}.outOfCredits.pastDueMemberBody`;
		}
		function outOfCreditsView() {
			if (isTopUpDeniedPastDue(topUpDenial.value)) return {
				title: t(`${bs}.outOfCredits.title`),
				body: t(pastDueBodyKey()),
				action: canManageBilling.value ? "updatePayment" : null,
				dismissible: true
			};
			if (!permissions.value.canManageSubscription) return {
				title: t(`${bs}.outOfCredits.title`),
				body: datedBody(`${bs}.outOfCredits.memberBody`, `${bs}.outOfCredits.memberBodyNoDate`),
				action: null,
				dismissible: true
			};
			if (!canTopUp.value) return null;
			const bodyKey = audience.value === "personal" ? `${bs}.outOfCredits.personalBody` : `${bs}.outOfCredits.body`;
			const noDateKey = audience.value === "personal" ? `${bs}.outOfCredits.personalBodyNoDate` : `${bs}.outOfCredits.bodyNoDate`;
			return {
				title: t(`${bs}.outOfCredits.title`),
				body: datedBody(bodyKey, noDateKey),
				action: "addCredits",
				dismissible: true
			};
		}
		function creditsLeft() {
			const cents = availableCents.value;
			if (cents == null) return "";
			return formatCreditsFromCents({
				cents,
				locale: locale.value,
				numberOptions: {
					minimumFractionDigits: 0,
					maximumFractionDigits: 0
				}
			});
		}
		function lowCreditsView() {
			return {
				title: t(`${bs}.lowCredits.title`),
				body: t(`${bs}.lowCredits.localBody`, { credits: creditsLeft() }),
				action: canTopUp.value ? "addCredits" : null,
				dismissible: true
			};
		}
		const banner = computed(() => {
			if (kind.value === "outOfCredits") return outOfCreditsView();
			if (kind.value === "lowCredits") return lowCreditsView();
			return null;
		});
		function dismiss() {
			const visible = kind.value;
			if (visible === "outOfCredits") {
				outOfCreditsDismissed.value = true;
				if (balance.value?.lowBalance === true) lowCreditsDismissed.value = true;
			} else if (visible === "lowCredits") lowCreditsDismissed.value = true;
		}
		function handleAddCredits() {
			showTopUpCreditsDialog();
		}
		return (_ctx, _cache) => {
			return autoTopUpKind.value ? (openBlock(), createBlock(BillingAutoTopUpBanner_default, {
				key: 0,
				kind: autoTopUpKind.value
			}, {
				default: withCtx(() => [createVNode(Button_default, {
					as: "a",
					href: unref(href),
					target: "_blank",
					rel: "noopener",
					variant: "inverted",
					size: "md",
					class: "shrink-0",
					onClick: unref(track)
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.billingStatus.updatePayment")), 1)]),
					_: 1
				}, 8, ["href", "onClick"])]),
				_: 1
			}, 8, ["kind"])) : banner.value ? (openBlock(), createElementBlock("div", _hoisted_1$8, [createBaseVNode("div", _hoisted_2$8, [createBaseVNode("div", _hoisted_3$7, [createBaseVNode("div", _hoisted_4$7, [_cache[0] || (_cache[0] = createBaseVNode("i", { class: "icon-[lucide--triangle-alert] size-4 shrink-0 text-warning" }, null, -1)), createBaseVNode("span", _hoisted_5$7, toDisplayString(banner.value.title), 1)]), createBaseVNode("p", _hoisted_6$3, toDisplayString(banner.value.body), 1)]), banner.value.dismissible || banner.value.action ? (openBlock(), createElementBlock("div", _hoisted_7$2, [banner.value.dismissible ? (openBlock(), createBlock(Button_default, {
				key: 0,
				variant: "textonly",
				size: "md",
				onClick: dismiss
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.billingStatus.outOfCredits.dismiss")), 1)]),
				_: 1
			})) : createCommentVNode("", true), banner.value.action === "addCredits" ? (openBlock(), createBlock(Button_default, {
				key: 1,
				variant: "secondary",
				size: "md",
				onClick: handleAddCredits
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.billingStatus.outOfCredits.addCredits")), 1)]),
				_: 1
			})) : banner.value.action === "updatePayment" ? (openBlock(), createBlock(Button_default, {
				key: 2,
				variant: "inverted",
				size: "md",
				loading: unref(isUpdatingPayment),
				onClick: unref(updatePayment)
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.billingStatus.updatePayment")), 1)]),
				_: 1
			}, 8, ["loading", "onClick"])) : createCommentVNode("", true)])) : createCommentVNode("", true)])])) : createCommentVNode("", true);
		};
	}
});
//#endregion
//#region src/platform/billing/components/billingTab/BillingPlanCheckoutBanner.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$7 = {
	key: 0,
	role: "status",
	class: "flex flex-col gap-3 rounded-xl border border-border/60 bg-background p-3 sm:flex-row sm:items-center sm:gap-2",
	"data-testid": "billing-plan-checkout-banner"
};
var _hoisted_2$7 = { class: "flex min-w-0 flex-1 flex-col gap-2" };
var _hoisted_3$6 = { class: "flex items-center gap-2" };
var _hoisted_4$6 = { class: "text-sm text-foreground" };
var _hoisted_5$6 = { class: "m-0 pl-6 text-sm text-muted-foreground" };
var _hoisted_6$2 = { class: "flex shrink-0 flex-wrap items-center gap-2 pl-6 sm:pl-0" };
//#endregion
//#region src/platform/billing/components/billingTab/BillingPlanCheckoutBanner.vue
var BillingPlanCheckoutBanner_default = /* @__PURE__ */ defineComponent({
	__name: "BillingPlanCheckoutBanner",
	props: { banner: {} },
	emits: ["dismiss"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const { t } = useI18n();
		const copy = computed(() => {
			if (!__props.banner) return null;
			const prefix = `workspacePanel.billingStatus.planCheckout.${__props.banner.kind === "verifyPayment" ? "verifyPayment" : "paymentReceived"}`;
			return {
				title: t(`${prefix}.title`),
				body: t(`${prefix}.body`)
			};
		});
		return (_ctx, _cache) => {
			return __props.banner ? (openBlock(), createElementBlock("div", _hoisted_1$7, [createBaseVNode("div", _hoisted_2$7, [createBaseVNode("div", _hoisted_3$6, [createBaseVNode("i", {
				class: normalizeClass(unref(cn)("size-4 shrink-0", __props.banner.kind === "verifyPayment" ? "icon-[lucide--triangle-alert] text-warning" : "icon-[lucide--circle-alert] text-muted-foreground")),
				"aria-hidden": "true"
			}, null, 2), createBaseVNode("span", _hoisted_4$6, toDisplayString(copy.value?.title), 1)]), createBaseVNode("p", _hoisted_5$6, toDisplayString(copy.value?.body), 1)]), createBaseVNode("div", _hoisted_6$2, [createVNode(Button_default, {
				variant: "textonly",
				size: "md",
				onClick: _cache[0] || (_cache[0] = ($event) => emit("dismiss"))
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.billingStatus.planCheckout.dismiss")), 1)]),
				_: 1
			}), __props.banner.kind === "verifyPayment" && __props.banner.actionUrl ? (openBlock(), createBlock(Button_default, {
				key: 0,
				as: "a",
				href: __props.banner.actionUrl,
				target: "_blank",
				rel: "noopener",
				variant: "secondary",
				size: "md",
				class: "no-underline"
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.billingStatus.planCheckout.verifyPayment.action")), 1)]),
				_: 1
			}, 8, ["href"])) : createCommentVNode("", true)])])) : createCommentVNode("", true);
		};
	}
});
//#endregion
//#region src/platform/billing/components/billingTab/BillingParkedBanner.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$6 = {
	key: 0,
	role: "status",
	class: "flex flex-col gap-3 rounded-2xl border border-border/60 bg-background p-4 sm:flex-row sm:items-center sm:gap-2",
	"data-testid": "billing-parked-banner"
};
var _hoisted_2$6 = { class: "flex min-w-0 flex-1 flex-col gap-1" };
var _hoisted_3$5 = { class: "flex items-center gap-2" };
var _hoisted_4$5 = { class: "text-sm text-foreground" };
var _hoisted_5$5 = { class: "m-0 pl-6 text-sm text-muted-foreground" };
var CONTACT_SUPPORT_URL = "https://comfy.org/contact/";
//#endregion
//#region src/platform/billing/components/billingTab/BillingParkedBanner.vue
var BillingParkedBanner_default = /* @__PURE__ */ defineComponent({
	__name: "BillingParkedBanner",
	props: { parked: { type: Boolean } },
	setup(__props) {
		return (_ctx, _cache) => {
			return __props.parked ? (openBlock(), createElementBlock("div", _hoisted_1$6, [createBaseVNode("div", _hoisted_2$6, [createBaseVNode("div", _hoisted_3$5, [_cache[0] || (_cache[0] = createBaseVNode("i", { class: "icon-[lucide--triangle-alert] size-4 shrink-0 text-warning" }, null, -1)), createBaseVNode("span", _hoisted_4$5, toDisplayString(_ctx.$t("workspacePanel.billingStatus.parked.title")), 1)]), createBaseVNode("p", _hoisted_5$5, toDisplayString(_ctx.$t("workspacePanel.billingStatus.parked.body")), 1)]), createVNode(Button_default, {
				as: "a",
				variant: "inverted",
				size: "lg",
				class: "shrink-0",
				href: CONTACT_SUPPORT_URL,
				target: "_blank",
				rel: "noopener"
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.billingStatus.parked.contactSupport")), 1)]),
				_: 1
			})])) : createCommentVNode("", true);
		};
	}
});
//#endregion
//#region src/platform/billing/components/billingTab/BillingPausedBanner.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$5 = {
	key: 0,
	role: "status",
	class: "flex flex-col gap-3 rounded-xl border border-border/60 bg-background p-3 sm:flex-row sm:items-center sm:gap-2",
	"data-testid": "billing-paused-banner"
};
var _hoisted_2$5 = { class: "flex min-w-0 flex-1 flex-col gap-2" };
var _hoisted_3$4 = { class: "flex items-center gap-2" };
var _hoisted_4$4 = { class: "text-sm text-foreground" };
var _hoisted_5$4 = { class: "m-0 pl-6 text-sm text-muted-foreground" };
//#endregion
//#region src/platform/billing/components/billingTab/BillingPausedBanner.vue
var BillingPausedBanner_default = /* @__PURE__ */ defineComponent({
	__name: "BillingPausedBanner",
	props: { canManageBilling: { type: Boolean } },
	setup(__props) {
		const { isPaused } = usePausedBanner();
		const paused = computed(() => pausedBannerCopy(__props.canManageBilling));
		const { updatePayment, isUpdatingPayment } = usePaymentRecoveryDialog();
		return (_ctx, _cache) => {
			return unref(isPaused) ? (openBlock(), createElementBlock("div", _hoisted_1$5, [createBaseVNode("div", _hoisted_2$5, [createBaseVNode("div", _hoisted_3$4, [createBaseVNode("i", { class: normalizeClass(unref(cn)("size-4 shrink-0", paused.value.muted ? "icon-[lucide--circle-alert] text-muted-foreground" : "icon-[lucide--triangle-alert] text-warning")) }, null, 2), createBaseVNode("span", _hoisted_4$4, toDisplayString(_ctx.$t(paused.value.titleKey)), 1)]), createBaseVNode("p", _hoisted_5$4, toDisplayString(_ctx.$t(paused.value.bodyKey)), 1)]), paused.value.action === "updatePayment" ? (openBlock(), createBlock(Button_default, {
				key: 0,
				variant: "inverted",
				size: "md",
				class: "shrink-0",
				loading: unref(isUpdatingPayment),
				onClick: unref(updatePayment)
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.billingStatus.updatePayment")), 1)]),
				_: 1
			}, 8, ["loading", "onClick"])) : createCommentVNode("", true)])) : createCommentVNode("", true);
		};
	}
});
//#endregion
//#region src/platform/billing/components/billingTab/planCheckoutBanner.ts
/** The Billing-tab plan banner for a served `checkout_state`. */
function planCheckoutBannerFor(operation) {
	switch (operation.checkout_state) {
		case "verify_payment": return {
			kind: "verifyPayment",
			opId: operation.id,
			actionUrl: operation.action_url ?? null
		};
		case "payment_received": return {
			kind: "paymentReceived",
			opId: operation.id
		};
		default: return null;
	}
}
//#endregion
//#region src/platform/billing/composables/usePlanCheckoutBanner.ts
function usePlanCheckoutBanner() {
	const { flags } = useFeatureFlags();
	const workspaceStore = useTeamWorkspaceStore();
	const operation = shallowRef(null);
	const dismissed = shallowRef(/* @__PURE__ */ new Set());
	const shown = computed(() => false);
	let refreshGeneration = 0;
	const banner = computed(() => {
		if (!shown.value || !operation.value) return null;
		const next = planCheckoutBannerFor(operation.value);
		if (!next || dismissed.value.has(`${next.opId}:${next.kind}`)) return null;
		return next;
	});
	function currentRefreshIs(refreshId, launchedGeneration) {
		return refreshId === refreshGeneration && workspaceStore.workspaceTransitionGeneration === launchedGeneration;
	}
	async function refresh() {
		const launchedGeneration = workspaceStore.workspaceTransitionGeneration;
		const refreshId = ++refreshGeneration;
		if (!shown.value) {
			operation.value = null;
			return;
		}
		try {
			const status = await workspaceApi.getBillingStatus();
			if (!currentRefreshIs(refreshId, launchedGeneration)) return;
			const opId = status.latest_subscription_op_id;
			const nextOperation = opId ? await workspaceApi.getBillingOpStatus(opId) : null;
			if (!currentRefreshIs(refreshId, launchedGeneration)) return;
			operation.value = nextOperation;
		} catch (error) {
			if (!currentRefreshIs(refreshId, launchedGeneration)) return;
			reportError(error, {
				errorType: "plan_checkout_banner_read_failed",
				surface: "billing"
			});
		}
	}
	function dismiss() {
		if (!banner.value) return;
		dismissed.value = /* @__PURE__ */ new Set([...dismissed.value, `${banner.value.opId}:${banner.value.kind}`]);
	}
	refresh();
	watch(() => workspaceStore.workspaceTransitionGeneration, () => {
		refreshGeneration++;
		operation.value = null;
		dismissed.value = /* @__PURE__ */ new Set();
		refresh();
	});
	watch(useDocumentVisibility(), (visibility) => {
		if (visibility === "visible") refresh();
	});
	watch(shown, () => {
		refresh();
	});
	return {
		banner,
		dismiss
	};
}
//#endregion
//#region src/platform/billing/components/billingTab/planRow.ts
var CONTACT_SALES_URL = "https://comfy.org/contact/";
var UNKNOWN = { kind: "unknown" };
function toCadence(duration) {
	if (duration === "MONTHLY") return "monthly";
	if (duration === "ANNUAL") return "yearly";
	return null;
}
/** Maps the served status fields onto the plan row; whatever they cannot render is `unknown`. */
function derivePlanRow(facts) {
	const { subscriptionStatus, planName, renewalDate, endDate } = facts;
	if (facts.subscriptionState === "activating" && planName !== null) return {
		kind: "activating",
		planName
	};
	if (subscriptionStatus === null) return {
		kind: "noPlan",
		freeRuns: facts.freeRuns
	};
	if (planName === null) return UNKNOWN;
	switch (facts.billingStatus) {
		case "paused": return UNKNOWN;
	}
	const cadence = toCadence(facts.duration);
	switch (subscriptionStatus) {
		case "active":
			if (!renewalDate || cadence === null) return UNKNOWN;
			return {
				kind: "active",
				planName,
				cadence,
				nextInvoice: renewalDate,
				scheduledChange: facts.scheduledChange
			};
		case "canceled": return endDate ? {
			kind: "ending",
			planName,
			cadence,
			endsAt: endDate
		} : UNKNOWN;
		case "ended": return endDate ? {
			kind: "ended",
			planName,
			cadence,
			endedAt: endDate
		} : UNKNOWN;
		default: return UNKNOWN;
	}
}
/** Self-serve actions follow `can_open_plans`. `sales_managed` is Contact sales. */
function planRowAction(state, { canOpenPlans, planKind }) {
	if (planKind === "sales_managed") return "contactSales";
	if (!canOpenPlans) return null;
	switch (state.kind) {
		case "activating":
		case "active":
		case "unknown": return "manage";
		case "noPlan": return "subscribe";
		case "ended": return "choosePlan";
		case "ending": return null;
	}
}
function deriveBillingTabLoad(facts) {
	if (facts.billingError !== null || facts.capabilitiesReady && !facts.capabilitiesResolved) return "error";
	return facts.billingInitialized && facts.capabilitiesReady ? "ready" : "loading";
}
/** Full month name, no ordinal; the year unless the plan is monthly. */
function formatPlanDate(isoDate, locale, cadence) {
	const date = new Date(isoDate);
	if (Number.isNaN(date.getTime())) return "";
	return new Intl.DateTimeFormat(locale, {
		month: "long",
		day: "numeric",
		...cadence === "monthly" ? {} : { year: "numeric" },
		timeZone: "UTC"
	}).format(date);
}
//#endregion
//#region src/platform/billing/composables/useAutoTopUpCardViewed.ts
function useAutoTopUpCardViewed(renderedStatus) {
	let reportedStatus;
	watch(renderedStatus, (status) => {
		if (!status || status === reportedStatus) return;
		reportedStatus = status;
		useTelemetry()?.trackBillingEvent({
			operation: "auto_top_up_card",
			stage: "viewed",
			outcome: "pending",
			status
		});
	}, { immediate: true });
}
//#endregion
//#region src/platform/billing/components/billingTab/BillingAutoTopUpCard.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$4 = {
	key: 0,
	class: "flex flex-col",
	"data-testid": "billing-auto-top-up-card"
};
var _hoisted_2$4 = {
	key: 0,
	class: "rounded-xl border border-card px-5 py-4"
};
var _hoisted_3$3 = {
	key: 1,
	class: "m-0 flex items-center gap-1 rounded-xl border border-card px-5 py-4 text-sm text-muted-foreground",
	role: "alert"
};
var _hoisted_4$3 = { class: "flex min-w-0 flex-col gap-1" };
var _hoisted_5$3 = { class: "m-0 flex items-center gap-2 text-sm font-medium text-foreground" };
var OPEN = "icon-[lucide--arrow-up-right]";
var EXTERNAL = "icon-[lucide--external-link]";
//#endregion
//#region src/platform/billing/components/billingTab/BillingAutoTopUpCard.vue
var BillingAutoTopUpCard_default = /* @__PURE__ */ defineComponent({
	__name: "BillingAutoTopUpCard",
	setup(__props) {
		const NEUTRAL = {
			border: "border-card",
			text: "text-muted-foreground"
		};
		const DANGER = {
			border: "border-destructive-background",
			text: "text-destructive-background"
		};
		const MANAGE = {
			id: "manage",
			label: "workspacePanel.billingTab.autoTopUp.actions.manage",
			variant: "secondary",
			icon: OPEN
		};
		const UPDATE_PAYMENT = {
			id: "update_payment",
			label: "workspacePanel.billingTab.autoTopUp.actions.updatePayment",
			variant: "inverted",
			icon: EXTERNAL
		};
		const STATUS = {
			failed: {
				...DANGER,
				label: "workspacePanel.billingTab.autoTopUp.status.failed",
				dot: "bg-destructive-background",
				action: UPDATE_PAYMENT
			},
			turnedOff: {
				...DANGER,
				label: "workspacePanel.billingTab.autoTopUp.status.turnedOff",
				dot: "bg-destructive-background",
				action: UPDATE_PAYMENT
			},
			off: {
				...NEUTRAL,
				label: "workspacePanel.billingTab.autoTopUp.status.off",
				dot: "bg-muted-foreground",
				action: {
					id: "turn_on",
					label: "workspacePanel.billingTab.autoTopUp.actions.turnOn",
					variant: "secondary",
					icon: EXTERNAL
				}
			},
			on_hold: {
				...NEUTRAL,
				label: "workspacePanel.billingTab.autoTopUp.status.onHold",
				dot: "bg-warning-background",
				action: UPDATE_PAYMENT
			},
			paused_by_budget: {
				...NEUTRAL,
				label: "workspacePanel.billingTab.autoTopUp.status.paused",
				dot: "bg-warning-background",
				action: MANAGE
			},
			on: {
				...NEUTRAL,
				label: "workspacePanel.billingTab.autoTopUp.status.on",
				dot: "bg-success-background",
				action: MANAGE
			}
		};
		const { t, locale } = useI18n();
		const { autoTopUpSetup } = useBillingCapabilities();
		const { state, isReady, ensureRead, retry } = useBillingAutoTopUpCard();
		ensureRead();
		useAutoTopUpCardViewed(() => {
			const current = state.value;
			return autoTopUpSetup.value?.state !== "unavailable" && isReady.value && current.kind === "loaded" ? current.settings.status : void 0;
		});
		function usd(cents) {
			return formatUsdFromCents({
				cents,
				locale: locale.value,
				numberOptions: {
					style: "currency",
					currency: "USD",
					minimumFractionDigits: cents % 100 === 0 ? 0 : 2
				}
			});
		}
		function credits(value) {
			return formatCredits({
				value,
				locale: locale.value,
				numberOptions: { maximumFractionDigits: 0 }
			});
		}
		function day(isoDate) {
			return formatPlanDate(isoDate, locale.value, "monthly");
		}
		function limitTooltip(resetsAt) {
			return resetsAt === null ? t("workspacePanel.billingTab.autoTopUp.limitTooltipNoDate") : t("workspacePanel.billingTab.autoTopUp.limitTooltip", { date: day(resetsAt) });
		}
		function ruleLines({ reload_amount_cents: amountCents, reload_credits: reloadCredits, threshold_credits: thresholdCredits }) {
			if (amountCents === null) return [];
			if (reloadCredits === null) return [];
			if (thresholdCredits === null) return [];
			return [{ text: t("workspacePanel.billingTab.autoTopUp.rule", {
				amount: usd(amountCents),
				credits: credits(reloadCredits),
				threshold: credits(thresholdCredits)
			}) }];
		}
		function limitLines(settings) {
			if (settings.monthly_budget_cents === null) return [];
			return [{
				text: t("workspacePanel.billingTab.autoTopUp.limit", {
					spent: usd(settings.spent_this_cycle_cents),
					limit: usd(settings.monthly_budget_cents)
				}),
				tooltip: limitTooltip(settings.cycle_resets_at)
			}];
		}
		function pausedLine({ cycle_resets_at: resumesAt }) {
			return {
				text: resumesAt === null ? t("workspacePanel.billingTab.autoTopUp.pausedNoDate") : t("workspacePanel.billingTab.autoTopUp.paused", { date: day(resumesAt) }),
				tooltip: limitTooltip(resumesAt)
			};
		}
		const LINES = {
			failed: () => [{ text: t("workspacePanel.billingTab.autoTopUp.failed") }],
			turnedOff: () => [{ text: t("workspacePanel.billingTab.autoTopUp.turnedOff") }],
			off: () => [{ text: t("workspacePanel.billingTab.autoTopUp.off") }],
			on_hold: (settings) => [...ruleLines(settings), { text: t("workspacePanel.billingTab.autoTopUp.onHold") }],
			paused_by_budget: (settings) => [...ruleLines(settings), pausedLine(settings)],
			on: (settings) => [...ruleLines(settings), ...limitLines(settings)]
		};
		function isStatus(status) {
			return Object.hasOwn(STATUS, status);
		}
		function viewKey(settings) {
			if (!isStatus(settings.status)) return "off";
			if (settings.status === "failed" && settings.disabled_reason === "consecutive_declines") return "turnedOff";
			return settings.status;
		}
		const view = computed(() => {
			if (state.value.kind !== "loaded") return null;
			const { settings } = state.value;
			const key = viewKey(settings);
			return {
				status: STATUS[key],
				lines: LINES[key](settings)
			};
		});
		const { href, track } = usePlatformHandoff("/profile/billing", () => ({
			target: "auto_top_up",
			action: view.value?.status.action.id ?? "turn_on"
		}));
		return (_ctx, _cache) => {
			return unref(autoTopUpSetup)?.state !== "unavailable" ? (openBlock(), createElementBlock("section", _hoisted_1$4, [unref(state).kind === "loading" ? (openBlock(), createElementBlock("div", _hoisted_2$4, [createVNode(Skeleton_default, { class: "h-16 w-full" })])) : unref(state).kind === "unavailable" ? (openBlock(), createElementBlock("p", _hoisted_3$3, [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.billingTab.autoTopUp.unavailable")) + " ", 1), createVNode(Button_default, {
				variant: "link",
				size: "sm",
				onClick: unref(retry)
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.billingTab.tryAgain")), 1)]),
				_: 1
			}, 8, ["onClick"])])) : view.value ? (openBlock(), createElementBlock("div", {
				key: 2,
				class: normalizeClass(unref(cn)("flex items-start justify-between gap-4 rounded-xl border px-5 py-4", view.value.status.border))
			}, [createBaseVNode("div", _hoisted_4$3, [createBaseVNode("h3", _hoisted_5$3, [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.billingTab.autoTopUp.title")) + " ", 1), createBaseVNode("span", {
				class: normalizeClass(unref(cn)("flex items-center gap-1 text-xs font-normal", view.value.status.text)),
				"data-testid": "billing-auto-top-up-status"
			}, [createBaseVNode("span", {
				class: normalizeClass(unref(cn)("size-1.75 rounded-full", view.value.status.dot)),
				"aria-hidden": "true"
			}, null, 2), createTextVNode(" " + toDisplayString(_ctx.$t(view.value.status.label)), 1)], 2)]), (openBlock(true), createElementBlock(Fragment, null, renderList(view.value.lines, (line) => {
				return openBlock(), createElementBlock("p", {
					key: line.text,
					class: "m-0 flex items-center gap-1 text-sm text-muted-foreground",
					"data-testid": "billing-auto-top-up-line"
				}, [createTextVNode(toDisplayString(line.text) + " ", 1), line.tooltip ? (openBlock(), createBlock(Button_default, {
					key: 0,
					tooltip: line.tooltip,
					"aria-label": line.tooltip,
					variant: "muted-textonly",
					size: "icon-sm"
				}, {
					default: withCtx(() => [..._cache[0] || (_cache[0] = [createBaseVNode("i", {
						class: "icon-[lucide--info] size-3.5",
						"aria-hidden": "true"
					}, null, -1)])]),
					_: 1
				}, 8, ["tooltip", "aria-label"])) : createCommentVNode("", true)]);
			}), 128))]), createVNode(Button_default, {
				as: "a",
				href: unref(href),
				target: "_blank",
				rel: "noopener",
				variant: view.value.status.action.variant,
				size: "md",
				class: "shrink-0",
				onClick: unref(track)
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t(view.value.status.action.label)) + " ", 1), createBaseVNode("i", {
					class: normalizeClass(unref(cn)(view.value.status.action.icon, "size-4")),
					"aria-hidden": "true"
				}, null, 2)]),
				_: 1
			}, 8, [
				"href",
				"variant",
				"onClick"
			])], 2)) : createCommentVNode("", true)])) : createCommentVNode("", true);
		};
	}
});
//#endregion
//#region src/platform/billing/components/billingTab/BillingCreditsCard.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$3 = {
	class: "flex flex-col gap-3",
	"data-testid": "billing-credits-card"
};
var _hoisted_2$3 = { class: "m-0 flex items-center gap-1.5 text-base font-medium text-foreground" };
var _hoisted_3$2 = {
	class: "flex flex-col rounded-xl border border-card",
	"data-testid": "billing-credits-surface"
};
var _hoisted_4$2 = { class: "flex items-start justify-between gap-4 px-5 py-4" };
var _hoisted_5$2 = { class: "flex min-w-0 flex-col gap-2" };
var _hoisted_6$1 = { class: "text-sm text-muted-foreground" };
var _hoisted_7$1 = {
	key: 0,
	class: "m-0 flex items-center gap-1 text-sm text-muted-foreground",
	role: "alert"
};
var _hoisted_8$1 = {
	key: 1,
	class: "m-0 text-sm text-muted-foreground"
};
var _hoisted_9$1 = {
	key: 2,
	class: "m-0 text-sm text-muted-foreground",
	"data-testid": "billing-credits-plan-note"
};
var _hoisted_10$1 = {
	key: 0,
	class: "flex border-t border-card"
};
var _hoisted_11$1 = { class: "flex flex-1 flex-col gap-2 border-r border-card px-5 py-4" };
var _hoisted_12 = { class: "flex items-center gap-1 text-sm text-muted-foreground" };
var _hoisted_13 = {
	class: "text-sm font-semibold text-foreground",
	"data-testid": "billing-credits-plan"
};
var _hoisted_14 = { class: "flex flex-1 items-start justify-between gap-4 px-5 py-4" };
var _hoisted_15 = { class: "flex flex-col gap-2" };
var _hoisted_16 = { class: "flex items-center gap-1 text-sm text-muted-foreground" };
var _hoisted_17 = {
	class: "text-sm font-semibold text-foreground",
	"data-testid": "billing-credits-top-up"
};
var _hoisted_18 = {
	key: 0,
	class: "text-xs text-muted-foreground"
};
//#endregion
//#region src/platform/billing/components/billingTab/BillingCreditsCard.vue
var BillingCreditsCard_default = /* @__PURE__ */ defineComponent({
	__name: "BillingCreditsCard",
	props: {
		state: {},
		canTopUp: { type: Boolean },
		planCreditNote: {}
	},
	emits: ["retry", "addCredits"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const { t, d, locale } = useI18n();
		const WHOLE = { maximumFractionDigits: 0 };
		function credits(cents) {
			return formatCreditsFromCents({
				cents,
				locale: locale.value,
				numberOptions: WHOLE
			});
		}
		function planAmount(cents, poolCredits) {
			if (poolCredits === null) return credits(cents);
			return t("workspacePanel.billingTab.credits.planOfPool", {
				remaining: credits(cents),
				total: formatCredits({
					value: poolCredits,
					locale: locale.value,
					numberOptions: WHOLE
				})
			});
		}
		function longDate(raw) {
			const date = raw ? new Date(raw) : null;
			if (!date || Number.isNaN(date.getTime())) return "";
			return d(date, {
				year: "numeric",
				month: "long",
				day: "numeric"
			});
		}
		function planLine() {
			if (__props.state.kind !== "plan") return "";
			const amount = planAmount(__props.state.planCents, __props.state.planPoolCredits);
			const date = longDate(__props.state.renewalDate);
			if (!date) return amount;
			return `${amount} ${t("subscription.refillsDate", { date })}`;
		}
		const overdrawnCredits = computed(() => __props.state.kind === "unavailable" ? 0 : centsToCredits(-__props.state.availableCents));
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("section", _hoisted_1$3, [createBaseVNode("h3", _hoisted_2$3, [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.billingTab.credits.title")) + " ", 1), createVNode(Button_default, {
				tooltip: _ctx.$t("workspacePanel.billingTab.credits.rateTooltip", { credits: unref(211) }),
				"aria-label": _ctx.$t("workspacePanel.billingTab.credits.rateInfo"),
				variant: "muted-textonly",
				size: "icon-sm"
			}, {
				default: withCtx(() => [..._cache[3] || (_cache[3] = [createBaseVNode("i", {
					class: "icon-[lucide--info] size-3.5",
					"aria-hidden": "true"
				}, null, -1)])]),
				_: 1
			}, 8, ["tooltip", "aria-label"])]), createBaseVNode("div", _hoisted_3$2, [createBaseVNode("div", _hoisted_4$2, [createBaseVNode("div", _hoisted_5$2, [
				createBaseVNode("span", _hoisted_6$1, toDisplayString(_ctx.$t("workspacePanel.billingTab.credits.available")), 1),
				createBaseVNode("span", {
					class: normalizeClass(unref(cn)("text-2xl font-medium text-foreground", __props.state.kind === "unavailable" && "text-muted-foreground")),
					"data-testid": "billing-credits-available"
				}, toDisplayString(__props.state.kind === "unavailable" ? "—" : credits(__props.state.availableCents)), 3),
				__props.state.kind === "unavailable" ? (openBlock(), createElementBlock("p", _hoisted_7$1, [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.billingTab.credits.unavailable")) + " ", 1), createVNode(Button_default, {
					variant: "link",
					size: "sm",
					onClick: _cache[0] || (_cache[0] = ($event) => emit("retry"))
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.billingTab.tryAgain")), 1)]),
					_: 1
				})])) : overdrawnCredits.value > 0 ? (openBlock(), createElementBlock("p", _hoisted_8$1, toDisplayString(_ctx.$t("workspacePanel.billingTab.credits.overdrawn", { count: credits(-__props.state.availableCents) }, overdrawnCredits.value)), 1)) : createCommentVNode("", true),
				__props.planCreditNote ? (openBlock(), createElementBlock("p", _hoisted_9$1, toDisplayString(__props.planCreditNote), 1)) : createCommentVNode("", true)
			]), __props.state.kind === "noPlan" && __props.canTopUp ? (openBlock(), createBlock(Button_default, {
				key: 0,
				variant: "secondary",
				size: "md",
				class: "shrink-0",
				onClick: _cache[1] || (_cache[1] = ($event) => emit("addCredits"))
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.billingTab.credits.addCredits")), 1)]),
				_: 1
			})) : createCommentVNode("", true)]), __props.state.kind === "plan" ? (openBlock(), createElementBlock("div", _hoisted_10$1, [createBaseVNode("div", _hoisted_11$1, [createBaseVNode("span", _hoisted_12, [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.billingTab.credits.plan")) + " ", 1), createVNode(Button_default, {
				tooltip: _ctx.$t("workspacePanel.billingTab.credits.planTooltip"),
				"aria-label": _ctx.$t("workspacePanel.billingTab.credits.planTooltip"),
				variant: "muted-textonly",
				size: "icon-sm"
			}, {
				default: withCtx(() => [..._cache[4] || (_cache[4] = [createBaseVNode("i", {
					class: "icon-[lucide--info] size-3.5",
					"aria-hidden": "true"
				}, null, -1)])]),
				_: 1
			}, 8, ["tooltip", "aria-label"])]), createBaseVNode("span", _hoisted_13, toDisplayString(planLine()), 1)]), createBaseVNode("div", _hoisted_14, [createBaseVNode("div", _hoisted_15, [
				createBaseVNode("span", _hoisted_16, [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.billingTab.credits.topUp")) + " ", 1), createVNode(Button_default, {
					tooltip: _ctx.$t("workspacePanel.billingTab.credits.topUpTooltip"),
					"aria-label": _ctx.$t("workspacePanel.billingTab.credits.topUpTooltip"),
					variant: "muted-textonly",
					size: "icon-sm"
				}, {
					default: withCtx(() => [..._cache[5] || (_cache[5] = [createBaseVNode("i", {
						class: "icon-[lucide--info] size-3.5",
						"aria-hidden": "true"
					}, null, -1)])]),
					_: 1
				}, 8, ["tooltip", "aria-label"])]),
				createBaseVNode("span", _hoisted_17, toDisplayString(credits(__props.state.topUpCents)), 1),
				__props.state.topUpInUse ? (openBlock(), createElementBlock("span", _hoisted_18, toDisplayString(_ctx.$t("workspacePanel.billingTab.credits.inUse")), 1)) : createCommentVNode("", true)
			]), __props.canTopUp ? (openBlock(), createBlock(Button_default, {
				key: 0,
				variant: "secondary",
				size: "md",
				class: "shrink-0",
				onClick: _cache[2] || (_cache[2] = ($event) => emit("addCredits"))
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.billingTab.credits.addCredits")), 1)]),
				_: 1
			})) : createCommentVNode("", true)])])) : createCommentVNode("", true)])]);
		};
	}
});
//#endregion
//#region src/platform/billing/components/billingTab/planLifecycle.ts
var PLAN_CONFIRM_CLOSED = { phase: "closed" };
/** The Stay on {plan} confirmation for a row whose status carries a scheduled change. */
function stayIntent(state) {
	if (state.kind !== "active" || state.scheduledChange === null) return null;
	return {
		kind: "stay",
		planName: state.planName,
		targetPlanName: state.scheduledChange.planName,
		effectiveAt: state.scheduledChange.effectiveAt
	};
}
/** The Resume plan confirmation for a row whose plan is ending. */
function resumeIntent(state) {
	if (state.kind !== "ending") return null;
	return {
		kind: "resume",
		planName: state.planName,
		renewsAt: state.endsAt
	};
}
function reducePlanConfirm(state, event) {
	switch (event.type) {
		case "opened": return state.phase === "closed" ? {
			phase: "confirming",
			intent: event.intent
		} : state;
		case "submitted": return state.phase === "confirming" || state.phase === "refused" ? {
			phase: "submitting",
			intent: state.intent
		} : state;
		case "settled":
			if (state.phase !== "submitting") return state;
			return event.outcome.ok ? PLAN_CONFIRM_CLOSED : {
				phase: "refused",
				intent: state.intent,
				serverMessage: event.outcome.serverMessage
			};
		case "dismissed": return state.phase === "submitting" ? state : PLAN_CONFIRM_CLOSED;
	}
}
//#endregion
//#region src/platform/billing/components/billingTab/usePlanLifecycleCommands.ts
function isCodedServerRefusal(err) {
	return err instanceof WorkspaceApiError && err.code !== void 0 && err.status !== void 0 && err.status >= 400 && err.status < 500;
}
var REVERT_POLL_INTERVAL_MS = 1500;
var REVERT_POLL_ATTEMPTS = 20;
async function readRevertOperation(opId) {
	try {
		const operation = await workspaceApi.getBillingOpStatus(opId);
		if (operation.status === "succeeded") return { settled: true };
		if (operation.status === "pending") return null;
		return {
			settled: false,
			cause: operation.error_message ?? `Scheduled change revert ended as ${operation.status}`
		};
	} catch (cause) {
		return {
			settled: false,
			cause
		};
	}
}
async function waitForRevertOperation(opId) {
	for (let attempt = 0; attempt < REVERT_POLL_ATTEMPTS; attempt++) {
		await delay(REVERT_POLL_INTERVAL_MS);
		const settlement = await readRevertOperation(opId);
		if (settlement) return settlement;
	}
	return {
		settled: false,
		cause: "Scheduled change revert did not settle"
	};
}
async function requestRevert() {
	const response = await workspaceApi.revertScheduledChange();
	return response.status === "pending" ? waitForRevertOperation(response.billing_op_id) : { settled: true };
}
function refusalOf(err, errorType) {
	if (isCodedServerRefusal(err)) return {
		ok: false,
		serverMessage: err.message
	};
	reportError(err, {
		surface: "billing",
		errorType
	});
	return {
		ok: false,
		serverMessage: null
	};
}
/** Revert a scheduled plan change or resume an ending plan, returning the server's refusal as data. */
function usePlanLifecycleCommands() {
	const billing = useBillingContext();
	const capabilities = useBillingCapabilities();
	async function resync() {
		await Promise.allSettled([billing.fetchStatus(), capabilities.refresh()]);
	}
	async function revertScheduledChange() {
		const errorType = "failure_reverting_scheduled_plan_change";
		try {
			const settlement = await requestRevert();
			if (!settlement.settled) {
				reportError(settlement.cause, {
					surface: "billing",
					errorType
				});
				await resync();
				return {
					ok: false,
					serverMessage: null
				};
			}
		} catch (err) {
			return refusalOf(err, errorType);
		}
		await resync();
		return { ok: true };
	}
	async function resumePlan() {
		try {
			await billing.resubscribe({ source: "settings_billing_panel" });
		} catch (err) {
			return refusalOf(err, "failure_resuming_subscription");
		}
		await resync();
		return { ok: true };
	}
	return {
		revertScheduledChange,
		resumePlan
	};
}
//#endregion
//#region src/platform/billing/components/billingTab/BillingPlanLifecycle.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$2 = { class: "flex flex-col gap-2 px-4 py-2" };
var _hoisted_2$2 = {
	key: 0,
	role: "alert",
	class: "m-0 text-sm wrap-break-word text-destructive"
};
//#endregion
//#region src/platform/billing/components/billingTab/BillingPlanLifecycle.vue
var BillingPlanLifecycle_default = /* @__PURE__ */ defineComponent({
	__name: "BillingPlanLifecycle",
	props: { state: {} },
	setup(__props) {
		const { t, locale } = useI18n();
		const { canRevertScheduledChange, canReactivate } = useBillingCapabilities();
		const { revertScheduledChange, resumePlan } = usePlanLifecycleCommands();
		const confirm = shallowRef(PLAN_CONFIRM_CLOSED);
		const stay = computed(() => stayIntent(__props.state));
		const resume = computed(() => resumeIntent(__props.state));
		function dispatch(event) {
			confirm.value = reducePlanConfirm(confirm.value, event);
		}
		function copyFor(intent) {
			const key = "workspacePanel.billingTab.plan";
			if (intent.kind === "stay") return {
				title: t(`${key}.stayConfirm.title`, { plan: intent.targetPlanName }),
				body: t(`${key}.stayConfirm.body`, {
					plan: intent.targetPlanName,
					date: formatPlanDate(intent.effectiveAt, locale.value, null)
				}),
				confirm: t(`${key}.actions.stay`, { plan: intent.planName })
			};
			return {
				title: t(`${key}.resumeConfirm.title`, { plan: intent.planName }),
				body: t(`${key}.resumeConfirm.body`, { date: formatPlanDate(intent.renewsAt, locale.value, null) }),
				confirm: t(`${key}.actions.resume`)
			};
		}
		const copy = computed(() => confirm.value.phase === "closed" ? {
			title: "",
			body: "",
			confirm: ""
		} : copyFor(confirm.value.intent));
		function onOpenChange(open) {
			if (!open) dispatch({ type: "dismissed" });
		}
		async function submit() {
			const current = confirm.value;
			if (current.phase !== "confirming" && current.phase !== "refused") return;
			dispatch({ type: "submitted" });
			dispatch({
				type: "settled",
				outcome: current.intent.kind === "stay" ? await revertScheduledChange() : await resumePlan()
			});
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock(Fragment, null, [
				unref(canRevertScheduledChange) ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [stay.value ? (openBlock(), createBlock(Button_default, {
					key: 0,
					variant: "secondary",
					size: "md",
					class: "shrink-0",
					onClick: _cache[0] || (_cache[0] = ($event) => dispatch({
						type: "opened",
						intent: stay.value
					}))
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.billingTab.plan.actions.stay", { plan: stay.value.planName })), 1)]),
					_: 1
				})) : createCommentVNode("", true)], 64)) : createCommentVNode("", true),
				unref(canReactivate) ? (openBlock(), createElementBlock(Fragment, { key: 1 }, [resume.value ? (openBlock(), createBlock(Button_default, {
					key: 0,
					variant: "secondary",
					size: "md",
					class: "shrink-0",
					onClick: _cache[1] || (_cache[1] = ($event) => dispatch({
						type: "opened",
						intent: resume.value
					}))
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.billingTab.plan.actions.resume")), 1)]),
					_: 1
				})) : createCommentVNode("", true)], 64)) : createCommentVNode("", true),
				createVNode(Dialog_default, {
					open: confirm.value.phase !== "closed",
					"onUpdate:open": onOpenChange
				}, {
					default: withCtx(() => [createVNode(DialogPortal_default, null, {
						default: withCtx(() => [createVNode(DialogOverlay_default), confirm.value.phase !== "closed" ? (openBlock(), createBlock(DialogContent_default, {
							key: 0,
							size: "sm",
							"data-testid": "billing-plan-confirm"
						}, {
							default: withCtx(() => [
								createVNode(DialogHeader_default, null, {
									default: withCtx(() => [createVNode(DialogTitle_default, null, {
										default: withCtx(() => [createTextVNode(toDisplayString(copy.value.title), 1)]),
										_: 1
									}), createVNode(DialogClose_default, { "aria-label": _ctx.$t("g.close") }, null, 8, ["aria-label"])]),
									_: 1
								}),
								createBaseVNode("div", _hoisted_1$2, [createVNode(DialogDescription_default, null, {
									default: withCtx(() => [createTextVNode(toDisplayString(copy.value.body), 1)]),
									_: 1
								}), confirm.value.phase === "refused" ? (openBlock(), createElementBlock("p", _hoisted_2$2, toDisplayString(confirm.value.serverMessage ?? _ctx.$t("workspacePanel.billingTab.plan.lifecycleRefused")), 1)) : createCommentVNode("", true)]),
								createVNode(DialogFooter_default, null, {
									default: withCtx(() => [createVNode(Button_default, {
										variant: "secondary",
										loading: confirm.value.phase === "submitting",
										onClick: submit
									}, {
										default: withCtx(() => [createTextVNode(toDisplayString(copy.value.confirm), 1)]),
										_: 1
									}, 8, ["loading"])]),
									_: 1
								})
							]),
							_: 1
						})) : createCommentVNode("", true)]),
						_: 1
					})]),
					_: 1
				}, 8, ["open"])
			], 64);
		};
	}
});
//#endregion
//#region src/platform/billing/components/billingTab/BillingPlanRow.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$1 = {
	class: "flex items-start justify-between gap-4 rounded-xl border border-card px-5 py-4",
	"data-testid": "billing-plan-row"
};
var _hoisted_2$1 = { class: "flex min-w-0 flex-col gap-1" };
var _hoisted_3$1 = { class: "m-0 text-sm font-semibold wrap-break-word text-foreground" };
var _hoisted_4$1 = {
	key: 0,
	class: "m-0 text-sm wrap-break-word text-muted-foreground",
	"data-testid": "billing-plan-line"
};
var _hoisted_5$1 = { class: "flex shrink-0 items-center gap-2" };
//#endregion
//#region src/platform/billing/components/billingTab/BillingPlanRow.vue
var BillingPlanRow_default = /* @__PURE__ */ defineComponent({
	__name: "BillingPlanRow",
	props: {
		state: {},
		action: {},
		canManageSubscription: { type: Boolean },
		salesVariant: { default: "secondary" }
	},
	emits: ["openPlan"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const { t, locale } = useI18n();
		const title = computed(() => {
			if (__props.state.kind === "noPlan") return t("workspacePanel.billingTab.plan.noPlan.title");
			if (__props.state.kind === "unknown") return t("workspacePanel.billingTab.plan.unknown.title");
			return __props.state.planName;
		});
		function activeLine(state) {
			const key = "workspacePanel.billingTab.plan";
			const billed = t(`${key}.active.${state.cadence}`, { date: formatPlanDate(state.nextInvoice, locale.value, state.cadence) });
			if (!state.scheduledChange) return billed;
			return `${billed} ${t(`${key}.scheduledChange`, {
				plan: state.scheduledChange.planName,
				date: formatPlanDate(state.scheduledChange.effectiveAt, locale.value, state.cadence)
			})}`;
		}
		function noPlanLine(state) {
			const key = "workspacePanel.billingTab.plan.noPlan";
			if (!__props.canManageSubscription) return "";
			if (!state.freeRuns) return t(`${key}.line`);
			const { remaining, total } = state.freeRuns;
			return remaining > 0 ? t(`${key}.freeRunsLeft`, {
				remaining,
				total
			}) : t(`${key}.freeRunsUsed`, { total });
		}
		const statusLine = computed(() => {
			const key = "workspacePanel.billingTab.plan";
			if (__props.state.kind === "activating") return t(`${key}.activating`, { plan: __props.state.planName });
			if (__props.state.kind === "active") return activeLine(__props.state);
			if (__props.state.kind === "noPlan") return noPlanLine(__props.state);
			if (__props.state.kind === "ending") return t(`${key}.ending`, { date: formatPlanDate(__props.state.endsAt, locale.value, __props.state.cadence) });
			if (__props.state.kind === "ended") return t(`${key}.ended`, { date: formatPlanDate(__props.state.endedAt, locale.value, __props.state.cadence) });
			return "";
		});
		const line = computed(() => __props.canManageSubscription ? statusLine.value : [statusLine.value, t("workspacePanel.billingTab.plan.managedByOwner")].filter(Boolean).join(" "));
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("section", _hoisted_1$1, [createBaseVNode("div", _hoisted_2$1, [createBaseVNode("h3", _hoisted_3$1, toDisplayString(title.value), 1), line.value ? (openBlock(), createElementBlock("p", _hoisted_4$1, toDisplayString(line.value), 1)) : createCommentVNode("", true)]), createBaseVNode("div", _hoisted_5$1, [createVNode(BillingPlanLifecycle_default, { state: __props.state }, null, 8, ["state"]), __props.action === "contactSales" ? (openBlock(), createBlock(Button_default, {
				key: 0,
				as: "a",
				href: unref(CONTACT_SALES_URL),
				target: "_blank",
				rel: "noopener",
				variant: __props.salesVariant,
				class: "shrink-0 no-underline"
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.billingTab.plan.actions.contactSales")) + " ", 1), _cache[1] || (_cache[1] = createBaseVNode("i", {
					class: "icon-[lucide--external-link] size-4",
					"aria-hidden": "true"
				}, null, -1))]),
				_: 1
			}, 8, ["href", "variant"])) : __props.action ? (openBlock(), createBlock(Button_default, {
				key: 1,
				variant: __props.action === "manage" ? "secondary" : "inverted",
				size: "md",
				class: "shrink-0",
				onClick: _cache[0] || (_cache[0] = ($event) => emit("openPlan"))
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t(`workspacePanel.billingTab.plan.actions.${__props.action}`)), 1)]),
				_: 1
			}, 8, ["variant"])) : createCommentVNode("", true)])]);
		};
	}
});
//#endregion
//#region src/platform/billing/components/billingTab/creditsCard.ts
/** Maps the served balance and plan state onto the Credits card. */
function deriveCreditsCard(facts) {
	const { balance } = facts;
	if (!balance || balance.effectiveBalanceAuthoritative === false) return { kind: "unavailable" };
	const availableCents = balance.effectiveBalanceMicros ?? balance.amountMicros;
	if (facts.planKind === "noPlan" || facts.planKind === "ended") return {
		kind: "noPlan",
		availableCents
	};
	const overdrawn = availableCents < 0;
	const planCents = overdrawn ? 0 : balance.cloudCreditBalanceMicros ?? 0;
	const topUpCents = overdrawn ? 0 : balance.prepaidBalanceMicros ?? 0;
	return {
		kind: "plan",
		availableCents,
		planCents: facts.billingStatus === "paused" ? 0 : planCents,
		planPoolCredits: facts.planPoolCredits,
		topUpCents,
		topUpInUse: planCents === 0 && topUpCents > 0,
		renewalDate: facts.renewalDate
	};
}
//#endregion
//#region src/platform/billing/components/billingTab/useBillingCreditsCard.ts
function useBillingCreditsCard(planRow) {
	const { balance, billingStatus, subscription, currentTeamCreditStop, renewalDate } = useBillingContext();
	const planPoolCredits = computed(() => getPlanCreditGrant({
		tier: subscription.value?.tier,
		duration: subscription.value?.duration,
		teamMonthlyCredits: currentTeamCreditStop.value?.credits_monthly
	})?.credits ?? null);
	return { state: computed(() => deriveCreditsCard({
		balance: balance.value,
		planKind: planRow.value.kind,
		billingStatus: billingStatus.value,
		planPoolCredits: planPoolCredits.value,
		renewalDate: renewalDate.value
	})) };
}
//#endregion
//#region src/platform/billing/components/billingTab/useBillingPlanRow.ts
function useBillingPlanRow() {
	const { t } = useI18n();
	const { subscription, subscriptionStatus, subscriptionState, billingStatus, isTeamPlan } = useBillingContext();
	const { quotaEnabled, available, maxAvailable } = useFreeTierQuota();
	const scheduled = useScheduledPlanChange();
	function planNameFor(tier) {
		if (tier === null || isSalesManagedTier(tier)) return null;
		if (isTeamPlan.value) return t("subscription.teamPlanName");
		return t(`subscription.tiers.${resolveSubscriptionTierKey(tier)}.name`);
	}
	const scheduledChange = computed(() => {
		const change = scheduled.scheduledChange.value;
		const planName = scheduled.planName.value;
		return change && planName ? {
			planName,
			effectiveAt: change.effective_at
		} : null;
	});
	const freeRuns = computed(() => quotaEnabled.value ? {
		remaining: available.value,
		total: maxAvailable.value
	} : null);
	const subscriptionFacts = computed(() => ({
		duration: subscription.value?.duration ?? null,
		planName: planNameFor(subscription.value?.tier ?? null),
		renewalDate: subscription.value?.renewalDate ?? null,
		endDate: subscription.value?.endDate ?? null
	}));
	return { state: computed(() => derivePlanRow({
		...subscriptionFacts.value,
		subscriptionStatus: subscriptionStatus.value,
		subscriptionState: subscriptionState.value,
		billingStatus: billingStatus.value,
		scheduledChange: scheduledChange.value,
		freeRuns: freeRuns.value
	})) };
}
//#endregion
//#region src/platform/billing/components/billingTab/BillingTab.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = {
	class: "flex flex-col gap-12",
	"data-testid": "billing-tab"
};
var _hoisted_2 = {
	class: "flex flex-col gap-3",
	"data-testid": "billing-plan-section"
};
var _hoisted_3 = { class: "m-0 text-base font-medium text-foreground" };
var _hoisted_4 = {
	key: 0,
	class: "rounded-xl border border-card px-5 py-4",
	"data-testid": "billing-plan-skeleton",
	"aria-busy": "true"
};
var _hoisted_5 = { class: "flex flex-col gap-2" };
var _hoisted_6 = {
	key: 1,
	class: "flex items-center justify-between gap-4 rounded-xl border border-card px-5 py-4",
	role: "alert",
	"data-testid": "billing-load-error"
};
var _hoisted_7 = { class: "m-0 text-sm text-muted-foreground" };
var _hoisted_8 = {
	key: 0,
	class: "flex flex-col gap-3",
	"data-testid": "billing-credits-section"
};
var _hoisted_9 = {
	class: "flex flex-col gap-3",
	"data-testid": "billing-handoff"
};
var _hoisted_10 = { class: "m-0 text-base font-medium text-foreground" };
var _hoisted_11 = {
	class: "flex items-center justify-end rounded-xl border border-card px-5 py-4",
	"data-testid": "billing-handoff-card"
};
//#endregion
//#region src/platform/billing/components/billingTab/BillingTab.vue
var BillingTab_default = /* @__PURE__ */ defineComponent({
	__name: "BillingTab",
	setup(__props) {
		const billing = useBillingContext();
		const capabilities = useBillingCapabilities();
		const { isPaused } = usePausedBanner();
		const planCheckout = usePlanCheckoutBanner();
		const suppressCreditBanner = computed(() => isPaused.value || planCheckout.banner.value != null);
		const { flags } = useFeatureFlags();
		const { state: planRow } = useBillingPlanRow();
		const { state: creditsCard } = useBillingCreditsCard(planRow);
		const planCreditNote = useTopUpPlanCreditCopy();
		const { showTopUpCreditsDialog } = useBillingDialogs();
		const { showSubscriptionDialog } = useSubscriptionPaywall();
		const telemetry = useTelemetry();
		const HANDOFF = {
			owner: {
				path: "/profile/billing",
				target: "open_billing"
			},
			member: {
				path: "/profile/usage",
				target: "usage"
			}
		};
		const handoffAudience = computed(() => capabilities.canManageBilling.value ? "owner" : "member");
		const load = computed(() => deriveBillingTabLoad({
			billingError: billing.error.value,
			billingInitialized: billing.isInitialized.value,
			capabilitiesReady: capabilities.isReady.value,
			capabilitiesResolved: capabilities.hasResolvedCapabilities.value
		}));
		const action = computed(() => planRowAction(planRow.value, {
			canOpenPlans: capabilities.canOpenPlans.value,
			planKind: capabilities.planKind.value
		}));
		const salesVariant = computed(() => billing.subscriptionStatus.value === "ended" ? "inverted" : "secondary");
		const { href: handoffHref, track: trackHandoff } = usePlatformHandoff(() => HANDOFF[handoffAudience.value].path, () => ({ target: HANDOFF[handoffAudience.value].target }));
		const handoffIcon = computed(() => handoffAudience.value === "owner" ? "icon-[lucide--arrow-up-right]" : "icon-[lucide--external-link]");
		async function retryBalance() {
			await billing.fetchBalance().catch(() => void 0);
		}
		function openPlan() {
			showSubscriptionDialog({ reason: "settings_billing_panel" });
		}
		function addCredits() {
			telemetry?.trackAddApiCreditButtonClicked({ source: "credits_panel" });
			showTopUpCreditsDialog({ source: paymentIntentSourceForAddCreditsClick("credits_panel") });
		}
		async function retry() {
			await Promise.allSettled([billing.initialize(), capabilities.refresh()]);
		}
		onMounted(() => {
			if (!billing.isInitialized.value && !billing.isLoading.value) billing.initialize().catch(() => void 0);
			capabilities.initialize();
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1, [
				createVNode(WorkspaceHeaderMenu_default),
				createVNode(BillingPausedBanner_default, { "can-manage-billing": unref(capabilities).canManageBilling.value }, null, 8, ["can-manage-billing"]),
				createVNode(BillingPlanCheckoutBanner_default, {
					banner: unref(planCheckout).banner.value,
					onDismiss: unref(planCheckout).dismiss
				}, null, 8, ["banner", "onDismiss"]),
				createVNode(BillingParkedBanner_default, { parked: unref(capabilities).hasParkedBillingOperation.value }, null, 8, ["parked"]),
				createVNode(BillingLocalCreditBanner_default, { suppressed: suppressCreditBanner.value }, null, 8, ["suppressed"]),
				createBaseVNode("section", _hoisted_2, [createBaseVNode("h2", _hoisted_3, toDisplayString(_ctx.$t("workspacePanel.billingTab.credits.plan")), 1), load.value === "loading" ? (openBlock(), createElementBlock("div", _hoisted_4, [createBaseVNode("div", _hoisted_5, [createVNode(Skeleton_default, { class: "h-6 w-1/3" }), createVNode(Skeleton_default, { class: "h-4 w-2/3" })])])) : load.value === "error" ? (openBlock(), createElementBlock("div", _hoisted_6, [createBaseVNode("p", _hoisted_7, toDisplayString(_ctx.$t("workspacePanel.billingTab.loadError")), 1), createVNode(Button_default, {
					variant: "secondary",
					size: "md",
					class: "shrink-0",
					onClick: retry
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.billingTab.tryAgain")), 1)]),
					_: 1
				})])) : (openBlock(), createBlock(BillingPlanRow_default, {
					key: 2,
					state: unref(planRow),
					action: action.value,
					"sales-variant": salesVariant.value,
					"can-manage-subscription": unref(capabilities).canManageSubscription.value,
					onOpenPlan: openPlan
				}, null, 8, [
					"state",
					"action",
					"sales-variant",
					"can-manage-subscription"
				]))]),
				load.value === "ready" ? (openBlock(), createElementBlock("section", _hoisted_8, [createVNode(BillingCreditsCard_default, {
					state: unref(creditsCard),
					"can-top-up": unref(capabilities).canTopUp.value,
					"plan-credit-note": unref(planCreditNote),
					onRetry: retryBalance,
					onAddCredits: addCredits
				}, null, 8, [
					"state",
					"can-top-up",
					"plan-credit-note"
				]), unref(flags).autoTopUpEnabled ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [unref(capabilities).canManageAutoTopUp.value ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [unref(capabilities).canTopUp.value ? (openBlock(), createBlock(BillingAutoTopUpCard_default, { key: 0 })) : createCommentVNode("", true)], 64)) : createCommentVNode("", true)], 64)) : createCommentVNode("", true)])) : createCommentVNode("", true),
				createBaseVNode("section", _hoisted_9, [createBaseVNode("h2", _hoisted_10, toDisplayString(_ctx.$t(`workspacePanel.billingTab.handoff.${handoffAudience.value}.label`)), 1), createBaseVNode("div", _hoisted_11, [createVNode(Button_default, {
					as: "a",
					href: unref(handoffHref),
					target: "_blank",
					rel: "noopener",
					variant: "secondary",
					size: "md",
					class: "shrink-0",
					onClick: unref(trackHandoff)
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t(`workspacePanel.billingTab.handoff.${handoffAudience.value}.action`)) + " ", 1), createBaseVNode("i", {
						class: normalizeClass(unref(cn)(handoffIcon.value, "size-4")),
						"aria-hidden": "true"
					}, null, 2)]),
					_: 1
				}, 8, ["href", "onClick"])])])
			]);
		};
	}
});
//#endregion
export { BillingTab_default as default };
