import "./rolldown-runtime-xtsTai4I.js";
import { Ft as ref, bt as watch, d as defineStore } from "./vendor-vue-core-CuN1excl.js";
import { Jr as useTimeoutFn } from "./vendor-reka-ui-NRTk7aIV.js";
import { n as useTelemetry } from "./telemetry-IkzvF0TI.js";
import { t as useAgentPanelStore } from "./agentPanelStore-CFwk6coW.js";
//#region src/workbench/extensions/agent/stores/agent/agentPanelRenderStore.ts
var AGENT_PANEL_RENDER_STALL_MS = 3e3;
/** Tracks how far each opening of the agent panel gets toward drawn content. */
var useAgentPanelRenderStore = defineStore("agentPanelRender", () => {
	const agentPanelStore = useAgentPanelStore();
	const progress = ref("dock_unresolved");
	const stallTimer = useTimeoutFn(() => {
		const stage = progress.value;
		if (stage !== "drawn") useTelemetry()?.trackAgentPanelRenderStalled({ stage });
	}, AGENT_PANEL_RENDER_STALL_MS, { immediate: false });
	watch(() => agentPanelStore.isVisible, (visible) => {
		progress.value = "dock_unresolved";
		if (visible) stallTimer.start();
		else stallTimer.stop();
	}, { immediate: true });
	function reach(stage) {
		progress.value = stage;
	}
	return {
		progress,
		reach
	};
});
//#endregion
export { useAgentPanelRenderStore as t };
