import "./rolldown-runtime-xtsTai4I.js";
import { Dn as widgetId, G as registerDocBoundRootGraphProbe, Mn as isEqual, ln as useWidgetValueStore, un as onGraphIntent } from "./litegraph-CgrqhFEE.js";
import { i as api } from "./api-BdJmXw98.js";
import { Ft as ref, Ht as toValue, It as shallowReactive, Mt as onScopeDispose, P as computed, Rt as shallowRef, bt as watch, d as defineStore, kt as getCurrentScope } from "./vendor-vue-core-CuN1excl.js";
import { m as getMediaTypeFromFilename } from "./formatUtil-DsZFGVbT.js";
import { r as reportError } from "./reportError-BHgDVvfb.js";
import { o as isWidgetValue } from "./rerouteId-1TDIYZkX.js";
import { A as traverseSubgraphPath, a as findNodeInHierarchy, o as findSubgraphByUuid, s as findSubgraphNodePathById } from "./graphTraversalUtil-BUK1cr2m.js";
import { t as assert } from "./assert--qJvwrYk.js";
import { i as useNodeDefStore } from "./nodeDefStore-CF96GLZA.js";
import { Ot as liveAutogrowGroupOf } from "./app-CSsV1u1T.js";
import { g as recordDevEvent, n as serializeSkillReference, o as SUBSCRIBE_ACK_TIMEOUT_MS, r as promptReferenceParts } from "./skillReferenceText-Dr3UZVuB.js";
//#region src/workbench/extensions/agent/crdt/reportLostEdit.ts
function reportLostEdit(kind, ops, cause, { shouldReport = true } = {}) {
	const { errorType = `failure_syncing_agent_edit_${kind}`, ...detail } = cause;
	const context = {
		...detail,
		workflowId: cause.workflowId,
		opId: ops[0]?.op_id,
		opIds: ops.map((op) => op.op_id),
		operations: ops.map((op) => op.op)
	};
	if (shouldReport) reportError(new Error(errorType), {
		surface: "agent",
		errorType,
		fingerprint: [errorType],
		level: kind === "host_rejected" ? "warning" : "error",
		tags: {
			tab: api.clientId,
			outcome: kind,
			code: cause.code
		},
		context
	});
	if (kind === "mint_divergence" || kind === "host_rejected") recordDevEvent(kind, context, { level: "warn" });
	else recordDevEvent("human_ops_settled", {
		state: kind,
		ops
	});
}
//#endregion
//#region src/workbench/extensions/agent/crdt/widgetValuesForm.ts
/**
* Nothing to declare is not a declaration gap: a node whose only widgets are
* buttons has no named value for a form to order, so counting it would bury
* invariant 4's signal under every such class in the ecosystem.
*/
var UNREPORTED = /* @__PURE__ */ new Set(["no_value_widgets"]);
var ADR = "docs/adr/WIDGET-SERIALIZATION-0047-agent-wire-widget-form-is-proven-not-derived.md";
/**
* Assertion text, one per broken invariant. Membership of this record is what
* makes a reason an invariant violation rather than a shape we cannot
* describe. `assert` forwards the message to external telemetry and groups on
* it, so each is a static description of the invariant that broke plus where
* it is written down — never a value.
*/
var INVARIANT_MESSAGES = {
	order_names_unserialized_widget: `Agent widget form invariant 1: a declared order entry names no live widget with serialize !== false, so the form orders a widget core never serialises — see ${ADR}`,
	declared_keys_disagree: `Agent widget form invariant 2: the declared order and the object-shaped widgets_values keys differ in one direction or the other, so the form either orders an absent value or drops a stored one — see ${ADR}`,
	hook_changed_serialized_widgets: `Agent widget form invariant 3: the extension serialize hook changed which live value widgets reach the Agent wire, so the form no longer describes the values sent — see ${ADR}`
};
var UNDECLARED_FORM_MESSAGE = "Agent widget form invariant 4: object-shaped widget values with no declared form";
var VALUE_DEPENDENT_LAYOUT_INPUT_TYPES = /* @__PURE__ */ new Set([
	"COMFY_AUTOGROW_V3",
	"COMFY_DYNAMICCOMBO_V3",
	"COMFY_DYNAMICGROUP_V3"
]);
var tally = /* @__PURE__ */ new Map();
var reported = /* @__PURE__ */ new Set();
var MAX_SUPPRESSION_KEYS = 100;
var tallyKey = (nodeType, reason) => JSON.stringify([nodeType, reason]);
function record(nodeType, reason) {
	const key = tallyKey(nodeType, reason);
	const seen = tally.get(key);
	if (seen) {
		seen.count += 1;
		return;
	}
	if (tally.size >= MAX_SUPPRESSION_KEYS) return;
	tally.set(key, {
		nodeType,
		reason,
		count: 1
	});
}
function firstReport(nodeType, reason) {
	const key = tallyKey(nodeType, reason);
	if (reported.has(key) || reported.size >= MAX_SUPPRESSION_KEYS) return false;
	reported.add(key);
	return true;
}
function suppressed(reason, detail) {
	return detail ? {
		declared: false,
		reason,
		detail
	} : {
		declared: false,
		reason
	};
}
function sameNames(left, right) {
	const a = new Set(left);
	const b = new Set(right);
	return a.size === b.size && [...a].every((name) => b.has(name));
}
/**
* Whether the live widget, or the store metadata the intent was keyed by when
* the live widget is missing or omits a field, identifies a value the document
* carries. Unknown widgets fail closed.
*/
function isValueWidget(widget, stored) {
	if (!widget && !stored) return false;
	const { type = stored?.type, serialize = stored?.serialize } = widget ?? {};
	return type !== "button" && serialize !== false;
}
/** The named values the document carries, dropping non-value widgets. */
function valueWidgetsOnly(node, named) {
	const filtered = Object.create(null);
	const rootGraphId = node.graph?.rootGraph.id;
	const widgetValueStore = useWidgetValueStore();
	for (const [name, value] of Object.entries(named)) {
		const stored = rootGraphId ? widgetValueStore.getWidget(widgetId(rootGraphId, node.id, name)) : void 0;
		if (node.widgets?.some((candidate) => candidate.name === name && isValueWidget(candidate, stored))) Object.defineProperty(filtered, name, {
			value,
			writable: true,
			enumerable: true,
			configurable: true
		});
	}
	return filtered;
}
function formProof(node, values, _serialized) {
	const live = node.widgets ?? [];
	const rootGraphId = node.graph?.rootGraph.id;
	const widgetValueStore = useWidgetValueStore();
	const valueWidgetNames = live.filter((widget) => {
		return isValueWidget(widget, rootGraphId ? widgetValueStore.getWidget(widgetId(rootGraphId, node.id, widget.name)) : void 0);
	}).map((widget) => widget.name);
	return {
		liveNames: live.map((widget) => widget.name),
		valueWidgetNames,
		valueNames: Object.keys(values),
		order: valueWidgetNames.filter((name) => Object.hasOwn(values, name))
	};
}
/**
* Invariant 3 — compare the key set that survives the Agent wire's value
* filter with the live value widgets. Positional values and extension-private
* entries are not sent, so neither can invalidate this proof.
*/
var hookKeptTheSerialisedWidgets = ({ valueNames, valueWidgetNames }) => sameNames(valueNames, valueWidgetNames) ? void 0 : suppressed("hook_changed_serialized_widgets", {
	wire: valueNames,
	live: valueWidgetNames
});
/**
* A document value with no live widget at all is the stored-state family, not
* a broken invariant: the node shed the widget, or was never registered.
* Checked before invariant 1 so the two are not conflated — "there is no
* widget" and "there is one core refuses to serialise" have different causes
* and different fixes.
*/
var everyValueHasALiveWidget = ({ valueNames, liveNames }) => {
	const unbacked = valueNames.filter((name) => !liveNames.includes(name));
	return unbacked.length ? suppressed("value_has_no_live_widget", { names: unbacked }) : void 0;
};
/**
* Invariant 1 — an order entry must name a live widget core serialises.
* Reachable only if a value for a `serialize: false` widget gets into
* `values`, which `isValueWidget` currently refuses: this is the guard on
* that filter.
*/
var orderNamesSerialisedWidgets = ({ order, valueWidgetNames }) => {
	const unserialized = order.filter((name) => !valueWidgetNames.includes(name));
	return unserialized.length ? suppressed("order_names_unserialized_widget", { names: unserialized }) : void 0;
};
/**
* Invariant 2 — the object case, as a set difference in BOTH directions.
* Order without a value orders nothing; a value outside the order is residue
* the host would store and never project. Stated against the enumerable keys,
* because those are what travel: the wire ships `values` as JSON, so an own
* property `Object.hasOwn` can see and `Object.keys` cannot is an order entry
* whose value never arrives.
*/
var declaredKeysAgree = ({ valueNames, order }) => {
	const undeclared = valueNames.filter((name) => !order.includes(name));
	const unvalued = order.filter((name) => !valueNames.includes(name));
	return undeclared.length || unvalued.length ? suppressed("declared_keys_disagree", {
		undeclared,
		unvalued
	}) : void 0;
};
/** Shapes a name-keyed order cannot address, whatever the values say. */
var orderIsAddressable = ({ order }) => {
	if (!order.length) return suppressed("no_value_widgets");
	if (order.some((name) => !name.length)) return suppressed("unnamed_value_widget");
	if (new Set(order).size !== order.length) return suppressed("duplicate_widget_name", { order });
};
/**
* Ordered most-specific-cause first, so the reason names the thing that
* actually happened rather than its downstream shadow: the hook changing the
* serialised widget set shows up as a key disagreement too, and attributing
* it to the key disagreement would send a reader looking in the wrong place.
*/
var FORM_PROBES = [
	everyValueHasALiveWidget,
	orderNamesSerialisedWidgets,
	declaredKeysAgree,
	hookKeptTheSerialisedWidgets,
	orderIsAddressable
];
/**
* Classifies a node's form without declaring, asserting or reporting
* anything. Pure apart from the node-definition read, so a bulk pass can call
* it per node and keep the reason.
*/
function classifyWidgetValuesForm(node, values, serialized) {
	if (layoutDependsOnValues(node)) return suppressed("value_dependent_layout");
	if (node.last_serialization) return suppressed("shell_last_serialization");
	const proof = formProof(node, values, serialized);
	for (const probe of FORM_PROBES) {
		const failed = probe(proof);
		if (failed) return failed;
	}
	return {
		declared: true,
		form: { order: [...proof.order] }
	};
}
/**
* The form to put on the wire, or nothing.
*
* Suppression is the gate in every environment. `assert` throws under DEV
* only, so it is the invariant channel and not the mechanism — and the throw
* is swallowed here on purpose, because every one of these invariants is
* breakable by a third-party pack. A pack must not be able to stop the Agent
* from minting in a developer's browser; it must only be unable to make us
* publish a form that describes the wrong values.
*/
function provenWidgetValuesForm(node, values, serialized) {
	const verdict = classifyWidgetValuesForm(node, values, serialized);
	if (verdict.declared) return verdict.form;
	const nodeType = node.type;
	record(nodeType, verdict.reason);
	const first = !UNREPORTED.has(verdict.reason) && firstReport(nodeType, verdict.reason);
	const invariantMessage = INVARIANT_MESSAGES[verdict.reason];
	if (first && invariantMessage) try {
		assert(false, invariantMessage, {
			nodeType,
			...verdict.detail
		});
	} catch {}
	if (first) reportError(/* @__PURE__ */ new Error(UNDECLARED_FORM_MESSAGE), {
		errorType: "agent_widget_form_undeclared",
		surface: "agent",
		level: "warning",
		tags: {
			node_type: nodeType,
			reason: verdict.reason
		},
		fingerprint: [
			"agent_widget_form_undeclared",
			verdict.reason,
			nodeType
		],
		context: {
			adr: ADR,
			...verdict.detail
		}
	});
}
function layoutDependsOnValues(node) {
	const definition = useNodeDefStore().fromLGraphNode(node);
	return Object.values(definition?.inputs ?? {}).some((spec) => VALUE_DEPENDENT_LAYOUT_INPUT_TYPES.has(spec.type));
}
//#endregion
//#region src/workbench/extensions/agent/crdt/docOpMinter.ts
/**
* How long a promoted-host write waits for the bound document to catch up
* before it is refused: as long as the subscribe lifecycle keeps retrying.
*/
var PROMOTED_WRITE_CATCH_UP_DEADLINE_MS = 3 * SUBSCRIBE_ACK_TIMEOUT_MS;
function heldWriteKey(event) {
	return JSON.stringify([
		event.graphId,
		String(event.nodeId),
		event.name
	]);
}
/** Returns the node's save-format snapshot for a semantic add operation. */
function wireNodeSnapshot(node) {
	let serialized;
	try {
		serialized = node.serialize();
	} catch {
		return null;
	}
	const wireSerialized = { ...serialized };
	Reflect.deleteProperty(wireSerialized, "__incarnation");
	Reflect.deleteProperty(wireSerialized, "widgets_values_form");
	const { widgets_values_named: named, flags: { ghost: _ghost, ...flags }, ...rest } = wireSerialized;
	const snapshot = {
		...rest,
		flags
	};
	if (!named || node.isVirtualNode) return snapshot;
	const values = valueWidgetsOnly(node, named);
	const form = provenWidgetValuesForm(node, values, serialized);
	return form ? {
		...snapshot,
		widgets_values: values,
		widgets_values_form: form
	} : {
		...snapshot,
		widgets_values: values
	};
}
function nodeKey(graphId, nodeId) {
	return `${graphId}:${String(nodeId)}`;
}
function reachableIntentGraph(graph, graphId) {
	if (graphId === graph.id) return graph;
	const registered = findSubgraphByUuid(graph, graphId);
	if (registered) return registered;
	const path = findSubgraphNodePathById(graph, graphId);
	return path ? traverseSubgraphPath(graph, path) : null;
}
/**
* Whether the live widget, or the store metadata the intent was keyed by when
* the live widget is missing or omits a field, identifies a value the document
* carries. Unknown widgets fail closed.
*/
function isValueWidgetWrite(owner, event) {
	const rootGraphId = owner?.graph?.rootGraph.id ?? event.graphId;
	const stored = useWidgetValueStore().getWidget(widgetId(rootGraphId, event.nodeId, event.name));
	const widget = owner?.widgets?.find((candidate) => candidate.name === event.name);
	return isValueWidget(widget, stored);
}
function promotedHostWrite(node, event, deps) {
	const hostInputs = node.inputs.flatMap((input) => input.widgetId ? [{
		name: input.name,
		widgetId: input.widgetId
	}] : []);
	const valueIndex = hostInputs.findIndex((input) => input.name === event.name);
	const liveNames = hostInputs.map((input) => input.name);
	if (valueIndex === -1) return {
		reason: "unpromoted_widget",
		liveNames
	};
	if (!deps.mayWritePromotedHost(event.nodeId)) return { reason: "doc_not_synced" };
	const doc = deps.docPromotedWidgets(event.nodeId);
	if (doc !== null && !documentAcceptsLiveIndex(doc, liveNames)) return {
		reason: "layout_drift",
		liveNames,
		doc
	};
	const widgetValueStore = useWidgetValueStore();
	return {
		value_index: valueIndex,
		instance_path: [String(event.nodeId)],
		host_widgets_values: hostInputs.map((input, index) => {
			if (index === valueIndex) return event.value;
			const value = widgetValueStore.getWidget(input.widgetId)?.value;
			return isWidgetValue(value) ? value : void 0;
		})
	};
}
/**
* Whether a live index is a safe index into the document's array.
*
* Two independent ways it is not, and the document answers both:
*
* - The array is sized for a different set of widgets. Checked against
*   `valueCount`, the same cardinality invariant `applyHostWidgets` enforces
*   on the way in.
* - The promoted name sequence is different. Definition order combined with
*   the instance's stored input mirror identifies the exact names behind the
*   positional array, catching same-cardinality demote/promote swaps as well
*   as `reorderSubgraphInputsByWidgetOrder` permutations.
*
* A document holding no array yet is sized by nothing, but it is NOT ordered
* by nothing: the first write seeds the whole array from `host_widgets_values`
* in live order, and a reload reads it back in the DEFINITION's order
* (`_applyPromotedWidgetValues`). A reorder permutes the live definition
* without minting, so the document's copy still holds the old order — seeding
* against it would land every value on a neighbour. Only a document that
* declares no definition at all leaves the live order unopposed.
*
* A refused write is dropped before enqueue so its `opaque_widgets` rejection
* cannot abort unrelated operations in the same batch.
*/
function documentAcceptsLiveIndex(doc, liveNames) {
	if (doc === null) return true;
	const namesMatch = doc.promotedNames != null && doc.promotedNames.length === liveNames.length && doc.promotedNames.every((name, index) => name === liveNames[index]);
	if (doc.valueCount === 0) return doc.promotedNames === void 0 || namesMatch;
	return doc.valueCount === liveNames.length && namesMatch;
}
function routedWidgetOperation(graph, rootGraphId, event, node, deps) {
	const operation = {
		op: "set_widget",
		node_id: event.nodeId,
		widget: event.name,
		value: event.value,
		old: event.previous
	};
	const owningGraphId = node?.graph?.id ?? event.graphId;
	if (owningGraphId === rootGraphId) {
		if (!node?.isSubgraphNode()) return operation;
		const promoted = promotedHostWrite(node, event, deps);
		return "reason" in promoted ? promoted : {
			...operation,
			promoted
		};
	}
	const subgraphNodePath = findSubgraphNodePathById(graph, owningGraphId);
	if (subgraphNodePath === null || subgraphNodePath.length === 0) return { unresolvedGraphId: owningGraphId };
	const [head, ...rest] = subgraphNodePath;
	return {
		...operation,
		path: [
			head,
			...rest,
			String(event.nodeId)
		],
		inner_widget: event.name
	};
}
/**
* Drops a same-tick pending `add_node` together with every link command that
* touched it: the doc never sees the node, so a `connect` naming it would
* dangle, and a `disconnect` of such a link would target a link the doc
* never had.
*/
function withoutCancelledAdd(pending, nodeId) {
	const cancelledLinkIds = /* @__PURE__ */ new Set();
	for (const entry of pending) {
		if (entry.kind !== "op" || entry.operation.op !== "connect") continue;
		const { from_node, to_node, link_id } = entry.operation;
		if (from_node === nodeId || to_node === nodeId) cancelledLinkIds.add(link_id);
	}
	return pending.filter((entry) => {
		if (entry.kind === "add_node") return entry.node.id !== nodeId;
		const { operation } = entry;
		switch (operation.op) {
			case "connect": return !cancelledLinkIds.has(operation.link_id);
			case "disconnect": return operation.to_node !== nodeId && !cancelledLinkIds.has(operation.link_id);
			default: return true;
		}
	});
}
/**
* The document input register a live link's target slot names, resolved by
* NAME against the bound document's own input order: the live order drifts
* from it (an autogrow slot disconnected and regrown lands at the tail of
* its group live, while the document keeps its order), and the applier
* indexes the document's array. The live index stands in only while the
* document has no such node yet. Undefined when the document has the node
* but no slot by that name.
*/
function docInputIndex(docNames, input, liveIndex) {
	if (docNames === null || input === void 0) return liveIndex;
	const index = docNames.indexOf(input.name);
	return index === -1 ? void 0 : index;
}
function growForMissingSlot(target, input) {
	if (!target || !input) return void 0;
	const widgetBacked = !!input.widget && !target.isSubgraphNode();
	const autogrow = !!liveAutogrowGroupOf(target, input.name);
	const selection = useNodeDefStore().getDynamicComboSelectionForInput(target, input.name);
	if (!widgetBacked && !autogrow && !selection) return void 0;
	return {
		grow: {
			name: input.name,
			type: String(input.type),
			...input.widget ? { widget: input.widget.name } : {}
		},
		...selection ? { selection } : {}
	};
}
function canvasReplaced(graph, event) {
	const eventGraph = reachableIntentGraph(graph, event.graphId);
	const input = (eventGraph ? findNodeInHierarchy(eventGraph, event.nodeId) : null)?.inputs.find((slot) => slot.name === event.name);
	const stored = input?.widgetId ? useWidgetValueStore().getWidget(input.widgetId) : void 0;
	return stored !== void 0 && !isEqual(stored.value, event.value);
}
function attachDocOpMinter(deps) {
	let pending = [];
	const pendingAdds = /* @__PURE__ */ new Map();
	const pendingDynamicSlots = /* @__PURE__ */ new Map();
	const pendingWidgetValues = /* @__PURE__ */ new Map();
	const reported = /* @__PURE__ */ new Set();
	const reportedRefusals = /* @__PURE__ */ new Set();
	const heldPromotedWrites = /* @__PURE__ */ new Map();
	let heldRetryTimer = null;
	let dynamicSlotRetryTimer = null;
	let flushScheduled = false;
	let detached = false;
	/**
	* Scopes a pending slot to the document it was grown in, so a delayed
	* operation can never be found — and replayed — under another one.
	*/
	function dynamicSlotKey(rootGraphId, nodeId, inputName) {
		return JSON.stringify([
			rootGraphId,
			String(nodeId),
			inputName
		]);
	}
	function widgetValueKey(nodeId, widgetName) {
		return JSON.stringify([String(nodeId), widgetName]);
	}
	/**
	* True while the document still reads what it read when the write was
	* minted, which is the only state in which that write can still be the
	* next one to land. A document that reflects the written value has settled
	* it; any other value superseded it.
	*/
	function widgetWriteInFlight(pending) {
		const documentValue = deps.docWidgetValue(pending.nodeId, pending.widgetName);
		return isEqual(documentValue, pending.documentValueAtWrite) && !isEqual(documentValue, pending.value);
	}
	/** Drops recorded writes the document has settled or superseded. */
	function retireSettledWidgetValues() {
		for (const [key, pending] of pendingWidgetValues) if (!widgetWriteInFlight(pending)) pendingWidgetValues.delete(key);
	}
	/**
	* Whether the bound document will carry this selector value by the time the
	* grow lands. An in-flight selector write decides it, because that write is
	* what the document reads next; otherwise the document's own value does.
	*/
	function documentMatchesSelection(nodeId, selection) {
		const key = widgetValueKey(nodeId, selection.widget);
		const pending = pendingWidgetValues.get(key);
		if (pending && !widgetWriteInFlight(pending)) pendingWidgetValues.delete(key);
		const inFlight = pendingWidgetValues.get(key);
		if (inFlight) return isEqual(inFlight.value, selection.value);
		return isEqual(deps.docWidgetValue(nodeId, selection.widget), selection.value);
	}
	function resolvedDynamicSlot(state) {
		const index = deps.docInputNames(state.nodeId)?.indexOf(state.inputName) ?? -1;
		return index < 0 ? void 0 : index;
	}
	function scheduleDeferredDynamicOperation(deferred, toSlot) {
		schedule({
			kind: "op",
			operation: {
				...deferred.operation,
				to_slot: toSlot
			}
		});
	}
	function releaseDynamicSlot(state) {
		const toSlot = resolvedDynamicSlot(state);
		if (toSlot === void 0) return false;
		pendingDynamicSlots.delete(pendingSlotKey(state));
		for (const deferred of state.deferred) scheduleDeferredDynamicOperation(deferred, toSlot);
		return true;
	}
	function pendingSlotKey(state) {
		return dynamicSlotKey(state.rootGraphId, state.nodeId, state.inputName);
	}
	/**
	* Drops a pending slot whose document is no longer bound, so its deferred
	* operations are never re-addressed to the document that replaced it.
	*/
	function dropRetargetedDynamicSlot(state) {
		const boundRootGraphId = deps.boundRootGraphId() ?? deps.getGraph()?.rootGraph.id ?? null;
		if (boundRootGraphId === null || boundRootGraphId === state.rootGraphId) return false;
		const key = pendingSlotKey(state);
		pendingDynamicSlots.delete(key);
		reportOnce(`dynamic_slot_workflow_changed:${key}`, `Dynamic-combo input ${state.inputName} of node ${String(state.nodeId)} belongs to graph ${state.rootGraphId}, which is no longer bound; dropping its deferred link operations rather than replaying them into ${boundRootGraphId}`, "agent_crdt_link_slot_workflow_changed", {
			nodeId: state.nodeId,
			input: state.inputName,
			rootGraphId: state.rootGraphId,
			boundRootGraphId,
			operations: state.deferred.map(({ kind }) => kind)
		});
		return true;
	}
	function dropExpiredDynamicSlot(state) {
		if (performance.now() - state.since < PROMOTED_WRITE_CATCH_UP_DEADLINE_MS) return false;
		const key = pendingSlotKey(state);
		pendingDynamicSlots.delete(key);
		reportOnce(`dynamic_slot_timeout:${key}`, `Dynamic-combo input ${state.inputName} of node ${String(state.nodeId)} never reached the bound document; dropping its deferred link operations`, "agent_crdt_link_slot_not_in_doc", {
			nodeId: state.nodeId,
			input: state.inputName,
			operations: state.deferred.map(({ kind }) => kind)
		});
		return true;
	}
	function retryDynamicSlots() {
		dynamicSlotRetryTimer = null;
		if (detached) return;
		let waiting = false;
		for (const state of pendingDynamicSlots.values()) {
			if (dropRetargetedDynamicSlot(state)) continue;
			if (releaseDynamicSlot(state) || dropExpiredDynamicSlot(state)) continue;
			waiting = true;
		}
		if (waiting) dynamicSlotRetryTimer = setTimeout(retryDynamicSlots, 100);
	}
	function retryDynamicSlotsSoon() {
		if (dynamicSlotRetryTimer !== null) return;
		dynamicSlotRetryTimer = setTimeout(retryDynamicSlots, 100);
	}
	function schedule(op) {
		pending.push(op);
		if (flushScheduled) return;
		flushScheduled = true;
		queueMicrotask(flush);
	}
	function mintAddNodeOperation(graph, node) {
		if (node.graph !== graph) return null;
		const snapshot = wireNodeSnapshot(node);
		if (!snapshot) {
			const key = `snapshot:${nodeKey(graph.id, node.id)}`;
			if (reported.has(key)) return null;
			reported.add(key);
			reportLostEdit("mint_divergence", [{ op: "add_node" }], {
				code: "missing_node_snapshot",
				errorType: "agent_crdt_node_snapshot_missing",
				graphId: graph.id,
				nodeId: node.id
			});
			return null;
		}
		return {
			op: "add_node",
			node_id: node.id,
			class_type: snapshot.type,
			pos: [node.pos[0], node.pos[1]],
			node: snapshot
		};
	}
	function serialisedDefinition(subgraph) {
		try {
			return JSON.parse(JSON.stringify(subgraph.asSerialisable()));
		} catch (error) {
			reportError(error, {
				surface: "agent",
				errorType: "agent_crdt_subgraph_definition_unserializable",
				context: { definitionId: subgraph.id }
			});
			return null;
		}
	}
	function mintMissingDefinitions(hosts) {
		const operations = [];
		const available = /* @__PURE__ */ new Map();
		const define = (subgraph) => {
			const settled = available.get(subgraph.id);
			if (settled !== void 0) return settled;
			available.set(subgraph.id, false);
			const dependenciesAvailable = subgraph.nodes.filter((node) => node.isSubgraphNode()).map((node) => define(node.subgraph)).every(Boolean);
			if (deps.docHasSubgraphDefinition(subgraph.id)) {
				available.set(subgraph.id, true);
				return true;
			}
			const definition = dependenciesAvailable ? serialisedDefinition(subgraph) : null;
			if (!definition) return false;
			operations.push({
				op: "define_subgraph",
				subgraph_id: subgraph.id,
				subgraph_definition: definition
			});
			available.set(subgraph.id, true);
			return true;
		};
		for (const host of hosts) define(host.subgraph);
		return operations;
	}
	function flush() {
		flushScheduled = false;
		reported.clear();
		const batch = pending;
		pending = [];
		pendingAdds.clear();
		if (detached) return;
		const hosts = [];
		const operations = batch.flatMap((entry) => {
			if (entry.kind === "op") return [entry.operation];
			const operation = mintAddNodeOperation(entry.graph, entry.node);
			if (!operation) return [];
			if (entry.node.isSubgraphNode()) hosts.push(entry.node);
			return [operation];
		});
		operations.push(...mintMissingDefinitions(hosts));
		for (const state of pendingDynamicSlots.values()) {
			if (state.sent) continue;
			state.sent = operations.some((operation) => operation.op === "connect" && operation.link_id === state.growLinkId && "grow" in operation);
		}
		if (operations.length > 0) deps.enqueue(operations);
	}
	function reportOnce(key, message, errorType, context, budget = reported) {
		if (budget.has(key)) return;
		budget.add(key);
		reportError(new Error(message), {
			surface: "agent",
			errorType,
			context
		});
	}
	/** True when `graph` is the bound document's root graph. */
	function isMintableRootScope(graph, action, entityId) {
		const boundRootGraphId = deps.boundRootGraphId();
		const rootGraphId = graph.rootGraph.id;
		if (boundRootGraphId !== null && rootGraphId !== boundRootGraphId) {
			reportOnce(`${action}:${rootGraphId}:${boundRootGraphId}`, `${action} targets graph ${rootGraphId}, not the bound document's root graph ${boundRootGraphId}; refusing to mint`, "agent_crdt_op_for_unbound_graph", {
				graphId: rootGraphId,
				boundRootGraphId,
				entityId
			});
			return false;
		}
		if (!graph.isRootGraph) {
			reportOnce(`${action}:${graph.id}:interior`, `Subgraph-interior ${action} has no wire op; the bound doc diverges from the local graph`, `agent_crdt_unrepresentable_subgraph_${action}`, {
				graphId: rootGraphId,
				ownerGraphId: graph.id,
				entityId
			});
			return false;
		}
		return true;
	}
	function routeSetWidget(event, retried) {
		const held = retried ?? takeHeldWrite(event);
		if (pendingAdds.has(nodeKey(event.graphId, event.nodeId))) return;
		const graph = deps.getGraph();
		if (!graph) return;
		const eventGraph = reachableIntentGraph(graph, event.graphId);
		const owner = eventGraph ? findNodeInHierarchy(eventGraph, event.nodeId) : null;
		if (!isValueWidgetWrite(owner, event)) return;
		const rootGraphId = deps.boundRootGraphId() ?? graph.id;
		const routed = routedWidgetOperation(graph, rootGraphId, event, owner, deps);
		if ("unresolvedGraphId" in routed) {
			reportUnresolvedWidgetOwner(routed.unresolvedGraphId, event);
			return;
		}
		if ("reason" in routed) {
			holdOrRefuseWidgetWrite(rootGraphId, event, routed, held);
			return;
		}
		rememberPendingWidgetValue(routed, event);
		schedule({
			kind: "op",
			operation: routed
		});
	}
	function rememberPendingWidgetValue(operation, event) {
		if (operation.op !== "set_widget" || "path" in operation || "promoted" in operation) return;
		retireSettledWidgetValues();
		pendingWidgetValues.set(widgetValueKey(event.nodeId, event.name), {
			nodeId: event.nodeId,
			widgetName: event.name,
			value: event.value,
			documentValueAtWrite: deps.docWidgetValue(event.nodeId, event.name)
		});
	}
	function reportUnresolvedWidgetOwner(graphId, event) {
		const key = `owner:${nodeKey(graphId, event.nodeId)}`;
		if (reportedRefusals.has(key)) return;
		reportedRefusals.add(key);
		reportLostEdit("mint_divergence", [{ op: "set_widget" }], {
			code: "unresolvable_widget_owner",
			errorType: "agent_crdt_widget_owner_unresolved",
			graphId,
			nodeId: event.nodeId
		});
	}
	function takeHeldWrite(event) {
		const key = heldWriteKey(event);
		const held = heldPromotedWrites.get(key) ?? null;
		heldPromotedWrites.delete(key);
		return held;
	}
	function holdOrRefuseWidgetWrite(rootGraphId, event, refusal, held) {
		const heldSince = held?.heldSince ?? performance.now();
		if (refusal.reason === "doc_not_synced" && performance.now() - heldSince < PROMOTED_WRITE_CATCH_UP_DEADLINE_MS) holdPromotedWrite({
			event,
			rootGraphId,
			heldSince
		});
		else refuseWidgetWrite(rootGraphId, event, refusal);
	}
	function refuseWidgetWrite(rootGraphId, event, refusal) {
		reportRefusal(rootGraphId, event, refusal);
		deps.onWidgetWriteRefused(event.nodeId, event.name);
	}
	function holdPromotedWrite(held) {
		heldPromotedWrites.set(heldWriteKey(held.event), held);
		if (heldRetryTimer !== null) return;
		heldRetryTimer = setTimeout(retryHeldPromotedWrites, 100);
	}
	function retryHeldPromotedWrites() {
		heldRetryTimer = null;
		if (detached) return;
		const held = [...heldPromotedWrites.values()];
		heldPromotedWrites.clear();
		const bound = deps.isDocBound();
		if (!deps.isEnabled() || !bound && deps.boundRootGraphId() === null) return;
		const graph = bound ? deps.getGraph() : null;
		for (const entry of held) if (graph) retryHeldWrite(graph, entry);
		else waitOrGiveUp(entry);
	}
	function waitOrGiveUp(entry) {
		if (!heldTooLong(entry)) holdPromotedWrite(entry);
		else refuseWidgetWrite(entry.rootGraphId, entry.event, { reason: "doc_not_synced" });
	}
	function heldTooLong(entry) {
		return performance.now() - entry.heldSince >= PROMOTED_WRITE_CATCH_UP_DEADLINE_MS;
	}
	function retryHeldWrite(graph, entry) {
		if (canvasReplaced(graph, entry.event)) return;
		if ((deps.boundRootGraphId() ?? graph.id) !== entry.rootGraphId) {
			refuseWidgetWrite(entry.rootGraphId, entry.event, { reason: "workflow_changed" });
			return;
		}
		routeSetWidget(entry.event, entry);
	}
	function reportRefusal(rootGraphId, event, refusal) {
		const host = String(event.nodeId);
		switch (refusal.reason) {
			case "layout_drift": {
				const { liveNames, doc } = refusal;
				reportOnce(`promoted_drift:${rootGraphId}:${host}`, `Subgraph host ${host} promotes [${liveNames.join(", ")}], which the document's ${doc.valueCount} stored values and declared inputs [${doc.declaredNames.join(", ")}] do not place; refusing to mint a promoted write`, "agent_crdt_promoted_widget_order_drift", {
					nodeId: event.nodeId,
					liveNames,
					docValueCount: doc.valueCount,
					docDeclaredNames: doc.declaredNames,
					docPromotedNames: doc.promotedNames
				}, reportedRefusals);
				return;
			}
			case "unpromoted_widget":
				reportOnce(`promoted_unpromoted:${rootGraphId}:${host}:${event.name}`, `Widget ${event.name} on subgraph host ${host} is not one of its promoted inputs [${refusal.liveNames.join(", ")}]; refusing to mint`, "agent_crdt_promoted_widget_not_promoted", {
					nodeId: event.nodeId,
					widget: event.name,
					liveNames: refusal.liveNames
				}, reportedRefusals);
				return;
			case "workflow_changed":
				reportOnce(`promoted_workflow_changed:${rootGraphId}:${host}`, `Subgraph host ${host} was edited while the bound document caught up, and the bound workflow changed before it did; refusing to mint a promoted write`, "agent_crdt_promoted_widget_workflow_changed", {
					nodeId: event.nodeId,
					widget: event.name
				}, reportedRefusals);
				return;
			case "doc_not_synced":
				reportOnce(`promoted_unsynced:${rootGraphId}:${host}`, `Subgraph host ${host} was edited before the bound document caught up; refusing to mint a promoted write`, "agent_crdt_promoted_widget_doc_not_synced", {
					nodeId: event.nodeId,
					widget: event.name
				}, reportedRefusals);
				return;
			default: return refusal;
		}
	}
	function mintSetNodeField(event) {
		if (pendingAdds.has(nodeKey(event.graph.id, event.nodeId))) return;
		if (!isMintableRootScope(event.graph, "set_node_field", event.nodeId)) return;
		const { type: _type, graph: _graph, nodeId, source: _source, ...write } = event;
		schedule({
			kind: "op",
			operation: {
				op: "set_node_field",
				node_id: nodeId,
				...write
			}
		});
	}
	function mintRemoveNode(event) {
		if (!isMintableRootScope(event.graph, "node_delete", event.node.id)) return;
		for (const [key, state] of pendingDynamicSlots) if (state.nodeId === event.node.id) pendingDynamicSlots.delete(key);
		for (const [key, pending] of pendingWidgetValues) if (pending.nodeId === event.node.id) pendingWidgetValues.delete(key);
		const key = nodeKey(event.graph.id, event.node.id);
		if (pendingAdds.get(key) === event.node) {
			pendingAdds.delete(key);
			pending = withoutCancelledAdd(pending, event.node.id);
			return;
		}
		schedule({
			kind: "op",
			operation: {
				op: "delete_node",
				node_id: event.node.id,
				removed_links: [...event.removedLinkIds]
			}
		});
	}
	function reportSlotNotInDoc(action, link, input) {
		reportOnce(`${action}:${link.target_id}:${input.name}`, `${action} targets input ${input.name} of node ${String(link.target_id)}, which the bound document does not carry; the bound doc diverges from the local graph`, "agent_crdt_link_slot_not_in_doc", {
			action,
			linkId: link.id,
			nodeId: link.target_id,
			input: input.name
		});
	}
	function mintMissingSlotConnect(rootGraphId, link, target, input, slotKey, pendingSlot, connect) {
		const growth = growForMissingSlot(target, input);
		if (growth?.selection) {
			if (!documentMatchesSelection(link.target_id, growth.selection)) {
				if (input) reportSlotNotInDoc("connect", link, input);
				return;
			}
			if (pendingSlot) {
				pendingSlot.deferred.push({
					kind: "connect",
					operation: connect
				});
				retryDynamicSlotsSoon();
				return;
			}
		}
		if (!growth) {
			if (input) reportSlotNotInDoc("connect", link, input);
			return;
		}
		scheduleGrowthConnect(rootGraphId, link, input, slotKey, connect, growth);
	}
	function scheduleGrowthConnect(rootGraphId, link, input, slotKey, connect, growth) {
		schedule({
			kind: "op",
			operation: {
				...connect,
				to_slot: null,
				grow: growth.grow
			}
		});
		if (!growth.selection || !input || !slotKey) return;
		pendingDynamicSlots.set(slotKey, {
			rootGraphId,
			nodeId: link.target_id,
			inputName: input.name,
			growLinkId: link.id,
			since: performance.now(),
			sent: false,
			deferred: []
		});
		retryDynamicSlotsSoon();
	}
	function mintConnect(event) {
		if (!isMintableRootScope(event.graph, "connect", event.link.id)) return;
		const { link } = event;
		const target = event.graph.getNodeById(link.target_id);
		const input = target?.inputs[link.target_slot];
		const toSlot = docInputIndex(deps.docInputNames(link.target_id), input, link.target_slot);
		const rootGraphId = event.graph.rootGraph.id;
		const slotKey = input ? dynamicSlotKey(rootGraphId, link.target_id, input.name) : void 0;
		const pendingSlot = slotKey ? pendingDynamicSlots.get(slotKey) : void 0;
		if (pendingSlot && toSlot !== void 0) releaseDynamicSlot(pendingSlot);
		const connect = {
			op: "connect",
			link_id: link.id,
			from_node: link.origin_id,
			from_slot: link.origin_slot,
			to_node: link.target_id,
			link_type: String(link.type)
		};
		if (toSlot !== void 0) {
			schedule({
				kind: "op",
				operation: {
					...connect,
					to_slot: toSlot
				}
			});
			return;
		}
		mintMissingSlotConnect(rootGraphId, link, target, input, slotKey, pendingSlot, connect);
	}
	function mintMissingSlotDisconnect(link, input, slotKey, pendingSlot) {
		if (!pendingSlot) {
			if (input) reportSlotNotInDoc("disconnect", link, input);
			return;
		}
		if (!pendingSlot.sent && pendingSlot.growLinkId === link.id) {
			pending = pending.filter((entry) => entry.kind !== "op" || entry.operation.op !== "connect" || entry.operation.link_id !== link.id || !("grow" in entry.operation));
			if (slotKey) pendingDynamicSlots.delete(slotKey);
			return;
		}
		pendingSlot.deferred.push({
			kind: "disconnect",
			operation: {
				op: "disconnect",
				link_id: link.id,
				to_node: link.target_id
			}
		});
		retryDynamicSlotsSoon();
	}
	function mintDisconnect(event) {
		if (!isMintableRootScope(event.graph, "disconnect", event.link.id)) return;
		const { link } = event;
		const input = event.graph.getNodeById(link.target_id)?.inputs[link.target_slot];
		const slotKey = input ? dynamicSlotKey(event.graph.rootGraph.id, link.target_id, input.name) : void 0;
		const pendingSlot = slotKey ? pendingDynamicSlots.get(slotKey) : void 0;
		const toSlot = docInputIndex(deps.docInputNames(link.target_id), input, link.target_slot);
		if (toSlot === void 0) {
			mintMissingSlotDisconnect(link, input, slotKey, pendingSlot);
			return;
		}
		if (pendingSlot) releaseDynamicSlot(pendingSlot);
		schedule({
			kind: "op",
			operation: {
				op: "disconnect",
				link_id: link.id,
				to_node: link.target_id,
				to_slot: toSlot
			}
		});
	}
	function mintClear(event) {
		if (event.nodeIds.length === 0) return;
		const boundRootGraphId = deps.boundRootGraphId();
		if (boundRootGraphId !== null && event.graphId !== boundRootGraphId) {
			reportOnce(`clear:${event.graphId}:${boundRootGraphId}`, `clear targets graph ${event.graphId}, not the bound document's root graph ${boundRootGraphId}; refusing to mint`, "agent_crdt_op_for_unbound_graph", {
				graphId: event.graphId,
				boundRootGraphId
			});
			return;
		}
		schedule({
			kind: "op",
			operation: {
				op: "clear",
				removed_nodes: [...event.nodeIds]
			}
		});
	}
	function mintAddNode(event) {
		if (!isMintableRootScope(event.graph, "node_create", event.node.id)) return;
		pendingAdds.set(nodeKey(event.graph.id, event.node.id), event.node);
		schedule({
			kind: "add_node",
			graph: event.graph,
			node: event.node
		});
	}
	function onIntent(event) {
		if (event.source !== "local") return;
		if (!deps.isEnabled() || !deps.isDocBound()) {
			if (event.type === "set_widget") heldPromotedWrites.delete(heldWriteKey(event));
			return;
		}
		mintIntent(event);
	}
	function mintIntent(event) {
		switch (event.type) {
			case "add_node":
				mintAddNode(event);
				return;
			case "remove_node":
				mintRemoveNode(event);
				return;
			case "connect":
				mintConnect(event);
				return;
			case "disconnect":
				mintDisconnect(event);
				return;
			case "clear":
				mintClear(event);
				return;
			case "set_widget":
				routeSetWidget(event, null);
				return;
			case "set_node_field":
				mintSetNodeField(event);
				return;
		}
	}
	const detachIntents = onGraphIntent(onIntent);
	const unregisterDocBoundProbe = registerDocBoundRootGraphProbe(() => {
		if (!deps.isEnabled() || !deps.isDocBound()) return null;
		const graph = deps.getGraph();
		if (!graph) return null;
		return graph.rootGraph.id;
	});
	return { detach() {
		detached = true;
		pending = [];
		pendingAdds.clear();
		pendingDynamicSlots.clear();
		pendingWidgetValues.clear();
		heldPromotedWrites.clear();
		if (heldRetryTimer !== null) clearTimeout(heldRetryTimer);
		heldRetryTimer = null;
		if (dynamicSlotRetryTimer !== null) clearTimeout(dynamicSlotRetryTimer);
		dynamicSlotRetryTimer = null;
		detachIntents();
		unregisterDocBoundProbe();
	} };
}
//#endregion
//#region src/workbench/extensions/agent/crdt/restoreOpMinter.ts
var activeMinters = /* @__PURE__ */ new Set();
function notifyRestoreMintersBeforeGraphLoad() {
	for (const minter of activeMinters) minter.onBeforeGraphLoad();
}
function notifyRestoreMintersAfterGraphConfigure() {
	for (const minter of activeMinters) minter.onAfterGraphConfigure();
}
function notifyRestoreMintersGraphLoadError() {
	for (const minter of activeMinters) minter.onGraphLoadError();
}
function snapshotGraph(graph) {
	const nodes = /* @__PURE__ */ new Map();
	const unserializableNodeIds = [];
	for (const node of graph._nodes) {
		const serialized = wireNodeSnapshot(node);
		if (serialized) nodes.set(String(node.id), serialized);
		else unserializableNodeIds.push(String(node.id));
	}
	const links = /* @__PURE__ */ new Map();
	for (const link of graph.links.values()) links.set(String(link.id), link);
	return {
		nodes,
		links,
		unserializableNodeIds
	};
}
function widgetValuesOf(node) {
	const values = node.widgets_values;
	return values != null && typeof values === "object" && !Array.isArray(values) ? values : {};
}
function removedNodeOperations(before, after) {
	return [...before.nodes.keys()].flatMap((id) => {
		if (after.nodes.has(id)) return [];
		return [{
			op: "delete_node",
			node_id: id,
			removed_links: [...before.links.values()].filter((link) => String(link.origin_id) === id || String(link.target_id) === id).map((link) => link.id)
		}];
	});
}
function addedNodeOperations(before, after) {
	return [...after.nodes].flatMap(([id, node]) => before.nodes.has(id) ? [] : [{
		op: "add_node",
		node_id: id,
		class_type: node.type,
		pos: Array.isArray(node.pos) ? node.pos : [0, 0],
		node
	}]);
}
function changedWidgetOperations(before, after) {
	return [...after.nodes].flatMap(([id, node]) => {
		const previous = before.nodes.get(id);
		if (!previous) return [];
		const oldValues = widgetValuesOf(previous);
		return Object.entries(widgetValuesOf(node)).flatMap(([name, value]) => {
			const old = oldValues[name];
			return JSON.stringify(old) === JSON.stringify(value) ? [] : [{
				op: "set_widget",
				node_id: id,
				widget: name,
				value,
				old
			}];
		});
	});
}
function addedLinkOperations(before, after, deps) {
	return [...after.links].flatMap(([id, link]) => {
		if (before.links.has(id)) return [];
		const targetId = String(link.target_id);
		const targetAdded = !before.nodes.has(targetId);
		const serializedInput = after.nodes.get(targetId)?.inputs?.[link.target_slot];
		const input = serializedInput && typeof serializedInput === "object" && "name" in serializedInput && typeof serializedInput.name === "string" ? { name: serializedInput.name } : void 0;
		const toSlot = targetAdded ? link.target_slot : docInputIndex(deps.docInputNames(targetId), input, link.target_slot);
		if (toSlot === void 0) return [];
		return [{
			op: "connect",
			link_id: link.id,
			from_node: link.origin_id,
			from_slot: link.origin_slot,
			to_node: link.target_id,
			to_slot: toSlot,
			link_type: String(link.type)
		}];
	});
}
function reportDetachedLinks(before, after) {
	for (const [id, link] of before.links) {
		if (after.links.has(id)) continue;
		if (!(!after.nodes.has(String(link.origin_id)) || !after.nodes.has(String(link.target_id)))) console.error("[agent-crdt] undo/redo restore removed link without its node; doc may diverge", id);
	}
}
/**
* An incomplete snapshot is not a smaller graph: a node that threw only after
* the restore would read as deleted and mint `delete_node` for a node still on
* the canvas (and the mirror case a duplicate `add_node`). Serialization
* failure has no op either, so the whole diff is skipped loudly.
*/
function diffRestore(before, after, deps) {
	const unserializable = [.../* @__PURE__ */ new Set([...before.unserializableNodeIds, ...after.unserializableNodeIds])];
	if (unserializable.length > 0) {
		console.error("[agent-crdt] undo/redo restore snapshot could not serialize every present node; skipping the restore diff so the doc is not told a still-present node was deleted", unserializable);
		return [];
	}
	reportDetachedLinks(before, after);
	return [
		...removedNodeOperations(before, after),
		...addedNodeOperations(before, after),
		...changedWidgetOperations(before, after),
		...addedLinkOperations(before, after, deps)
	];
}
function attachRestoreOpMinter(deps) {
	let restoreSnapshot = null;
	const listener = {
		onBeforeGraphLoad() {
			restoreSnapshot = null;
			if (!deps.isRestoringState() || !deps.isEnabled() || !deps.isDocBound()) return;
			const graph = deps.getGraph();
			if (graph) restoreSnapshot = snapshotGraph(graph);
		},
		onAfterGraphConfigure() {
			const before = restoreSnapshot;
			restoreSnapshot = null;
			if (!before) return;
			const graph = deps.getGraph();
			if (!graph) return;
			const operations = diffRestore(before, snapshotGraph(graph), deps);
			if (operations.length > 0) deps.enqueue(operations);
		},
		onGraphLoadError() {
			restoreSnapshot = null;
		}
	};
	activeMinters.add(listener);
	return { detach() {
		activeMinters.delete(listener);
		restoreSnapshot = null;
	} };
}
//#endregion
//#region src/workbench/extensions/agent/composables/agent/useCanvasSelection.ts
function selectedNodeKey(node) {
	return node.locatorId ?? node.id;
}
function signature(scope, nodes) {
	return JSON.stringify([scope, nodes.map(selectedNodeKey).sort()]);
}
function useCanvasSelection(options) {
	const staged = options.staged ?? ref([]);
	const consumedSig = ref(null);
	const stagedSig = ref(null);
	const dismissedSig = options.dismissedSignature ?? ref(null);
	let lastLiveSig = null;
	let stopSelectionWatch;
	function retainOffSelectionNodes(nodes) {
		if (!options.retainStagedNode) return nodes;
		const selectedKeys = new Set(nodes.map(selectedNodeKey));
		return [...staged.value.filter((node) => options.retainStagedNode?.(node) && !selectedKeys.has(selectedNodeKey(node))), ...nodes];
	}
	function stageUserSelection(nodes) {
		const previousKeys = new Set(staged.value.map(selectedNodeKey));
		if (nodes.some((node) => !previousKeys.has(selectedNodeKey(node)))) options.onNodesAdded?.();
		staged.value = nodes;
	}
	watch(() => toValue(options.enabled ?? true), (enabled) => {
		stopSelectionWatch?.();
		stopSelectionWatch = void 0;
		if (!enabled) {
			staged.value = [];
			consumedSig.value = null;
			stagedSig.value = null;
			dismissedSig.value = null;
			lastLiveSig = null;
			return;
		}
		stopSelectionWatch = watch(() => [
			toValue(options.isLive),
			toValue(options.isTracking ?? true),
			toValue(options.scope ?? null),
			toValue(options.selection)
		], ([isLive, isTracking, scope, nodes]) => {
			if (!isLive) {
				if (options.retainWhenNotLive) return;
				staged.value = [];
				consumedSig.value = null;
				stagedSig.value = null;
				lastLiveSig = null;
				return;
			}
			if (!isTracking) return;
			const projectedNodes = retainOffSelectionNodes(nodes);
			if (projectedNodes.length === 0) {
				staged.value = [];
				consumedSig.value = null;
				stagedSig.value = null;
				if (lastLiveSig !== null) dismissedSig.value = null;
				lastLiveSig = null;
				return;
			}
			const sig = signature(scope, projectedNodes);
			lastLiveSig = sig;
			if (sig !== dismissedSig.value) dismissedSig.value = null;
			if (sig === dismissedSig.value) return;
			if (sig === consumedSig.value || sig === stagedSig.value) return;
			consumedSig.value = null;
			stagedSig.value = sig;
			stageUserSelection(projectedNodes);
		}, {
			immediate: true,
			deep: true,
			flush: "sync"
		});
	}, {
		immediate: true,
		flush: "sync"
	});
	if (getCurrentScope()) onScopeDispose(() => stopSelectionWatch?.());
	function currentSignature() {
		return signature(toValue(options.scope ?? null), toValue(options.selection));
	}
	function consume() {
		const tags = staged.value;
		consumedSig.value = currentSignature();
		staged.value = [];
		return tags;
	}
	function dismissed() {
		return dismissedSig.value !== null && dismissedSig.value === currentSignature();
	}
	function remove(id) {
		staged.value = staged.value.filter((node) => selectedNodeKey(node) !== id);
		if (staged.value.length === 0) dismissedSig.value = currentSignature();
	}
	function add(node) {
		if (staged.value.some((tag) => selectedNodeKey(tag) === selectedNodeKey(node))) return;
		stageUserSelection([...staged.value, node]);
	}
	function replace(nodes) {
		staged.value = [...nodes];
		consumedSig.value = null;
		stagedSig.value = nodes.length ? signature(toValue(options.scope ?? null), nodes) : null;
		if (nodes.length) dismissedSig.value = null;
	}
	return {
		staged,
		consume,
		dismissed,
		remove,
		add,
		replace
	};
}
//#endregion
//#region src/workbench/extensions/agent/types/composerPrompt.ts
function composerReferenceKey(reference) {
	switch (reference.kind) {
		case "workflow": return `workflow:${reference.id}`;
		case "skill": return `skill:${reference.name}`;
		case "node": return `node:${JSON.stringify([reference.scope, selectedNodeKey(reference.node)])}`;
		case "asset": return `asset:${reference.attachment.id}`;
	}
}
function composerReferenceName(reference) {
	switch (reference.kind) {
		case "workflow": return reference.name;
		case "skill": return reference.name;
		case "node": return `${reference.node.title} #${reference.node.id}`;
		case "asset": return reference.attachment.name;
	}
}
//#endregion
//#region src/workbench/extensions/agent/utils/agentMessageText.ts
function nodeReferenceText(name) {
	return `@[Node: ${name}]`;
}
function assetReferenceText(name, resolvedKind) {
	return `@[${{
		image: "Image",
		video: "Video",
		audio: "Audio",
		"3D": "3D",
		text: "File",
		other: "File"
	}[resolvedKind ?? getMediaTypeFromFilename(name)]}: ${name}]`;
}
function agentMessageText(message) {
	const text = promptReferenceParts(message.text, message.workflowReferences ?? [], message.skillReference).map((part) => part.type === "text" ? part.text : part.type === "skill" ? `/${part.reference.name}` : `@[Workflow: ${part.reference.name}]`).join("");
	const context = [...(message.tags ?? []).map(nodeReferenceText), ...(message.attachments ?? []).map(({ name, kind }) => assetReferenceText(name, kind))].filter((label) => !text.includes(label));
	return [text, ...new Set(context)].filter(Boolean).join("\n");
}
//#endregion
//#region src/workbench/extensions/agent/utils/composerPrompt.ts
function insertComposerReference(prompt, reference, insertion) {
	const textOffset = Math.min(prompt.text.length, Math.max(0, insertion.textOffset));
	const referenceIndex = Math.min(prompt.references.length, Math.max(0, insertion.referenceIndex));
	const needsSpace = prompt.text[textOffset] !== " ";
	const references = prompt.references.map((item, index) => ({
		...item,
		textOffset: needsSpace && (item.textOffset > textOffset || item.textOffset === textOffset && index >= referenceIndex) ? item.textOffset + 1 : item.textOffset
	}));
	references.splice(referenceIndex, 0, {
		...reference,
		textOffset
	});
	return {
		prompt: {
			text: needsSpace ? `${prompt.text.slice(0, textOffset)} ${prompt.text.slice(textOffset)}` : prompt.text,
			references
		},
		insertion: {
			textOffset: textOffset + 1,
			referenceIndex: referenceIndex + 1
		}
	};
}
function composerPromptForSend(prompt) {
	let text = "";
	let offset = 0;
	const workflowReferences = [];
	let skillReference;
	for (const reference of prompt.references) {
		text += prompt.text.slice(offset, reference.textOffset);
		offset = reference.textOffset;
		if (reference.kind === "workflow") {
			const { kind: _kind, ...workflow } = reference;
			workflowReferences.push({
				...workflow,
				textOffset: text.length
			});
		} else if (reference.kind === "skill") {
			const { kind: _kind, scope: _scope, resolvePastedName: _resolvePastedName, ...skill } = reference;
			skillReference = {
				...skill,
				textOffset: text.length,
				workflowIndex: workflowReferences.length
			};
		} else {
			const name = composerReferenceName(reference);
			text += reference.kind === "node" ? nodeReferenceText(name) : assetReferenceText(name);
		}
	}
	return {
		text: text + prompt.text.slice(offset),
		workflowReferences,
		...skillReference ? { skillReference } : {}
	};
}
function sameComposerReferenceOrder(a, b) {
	return a.references.length === b.references.length && a.references.every((reference, index) => composerReferenceKey(reference) === composerReferenceKey(b.references[index]));
}
function composerPromptForSubmission(prompt) {
	const snapshot = composerPromptForSend(prompt);
	let text = "";
	const workflowReferences = [];
	for (const part of promptReferenceParts(snapshot.text, snapshot.workflowReferences, snapshot.skillReference)) if (part.type === "text") text += part.text;
	else if (part.type === "skill") text += serializeSkillReference(part.reference);
	else workflowReferences.push({
		...part.reference,
		textOffset: text.length
	});
	return {
		text,
		workflowReferences
	};
}
//#endregion
//#region src/workbench/extensions/agent/utils/videoThumbnail.ts
function createVideoThumbnail(source, signal) {
	if (signal.aborted) return Promise.resolve(void 0);
	const video = document.createElement("video");
	video.crossOrigin = "anonymous";
	video.preload = "auto";
	video.muted = true;
	video.playsInline = true;
	return new Promise((resolve) => {
		let settled = false;
		const finish = (url) => {
			if (settled) return;
			settled = true;
			clearTimeout(timer);
			signal.removeEventListener("abort", cancel);
			video.removeEventListener("error", cancel);
			video.removeEventListener("loadeddata", capture);
			video.pause();
			video.removeAttribute("src");
			video.load();
			resolve(url);
		};
		const cancel = () => finish();
		const capture = () => {
			if (!video.videoWidth || !video.videoHeight) return finish();
			try {
				const canvas = document.createElement("canvas");
				const scale = Math.min(320 / video.videoWidth, 320 / video.videoHeight, 1);
				canvas.width = Math.max(1, Math.round(video.videoWidth * scale));
				canvas.height = Math.max(1, Math.round(video.videoHeight * scale));
				const context = canvas.getContext("2d");
				if (!context) return finish();
				context.drawImage(video, 0, 0, canvas.width, canvas.height);
				canvas.toBlob((blob) => {
					if (!settled) finish(blob ? URL.createObjectURL(blob) : void 0);
				}, "image/jpeg", .8);
			} catch {
				finish();
			}
		};
		const timer = setTimeout(cancel, 15e3);
		signal.addEventListener("abort", cancel, { once: true });
		video.addEventListener("error", cancel, { once: true });
		video.addEventListener("loadeddata", capture, { once: true });
		video.src = source;
		video.load();
	});
}
//#endregion
//#region src/workbench/extensions/agent/stores/agent/agentComposerStore.ts
/**
* `insertComposerReference` (composerPrompt.ts) pads an empty `text` with a
* literal space on first insert. Once the last reference is removed, that
* padding is meaningless whitespace rather than real content, so it is
* cleared along with the reference that caused it.
*/
function resetTextWhenReferencesCleared(text, references) {
	return references.length === 0 && text.trim() === "" ? "" : text;
}
var useAgentComposerStore = defineStore("agentComposer", () => {
	const draftState = shallowRef({
		text: "",
		references: []
	});
	const prompt = computed(() => draftState.value);
	const draft = computed(() => prompt.value.text);
	const attachmentIds = ref([]);
	const assetsById = shallowReactive(/* @__PURE__ */ new Map());
	const attachments = computed(() => attachmentIds.value.flatMap((id) => {
		const attachment = assetsById.get(id);
		return attachment ? [attachment] : [];
	}));
	const workflowReferences = computed(() => prompt.value.references.flatMap((item) => {
		if (item.kind !== "workflow") return [];
		const { kind: _kind, ...reference } = item;
		return [reference];
	}));
	const nodes = computed(() => prompt.value.references.flatMap((item) => item.kind === "node" ? [item.node] : []));
	const hasDraft = computed(() => draft.value.trim() !== "" || attachments.value.length > 0 || prompt.value.references.length > 0);
	const nodeScope = ref(null);
	let skillScope = null;
	const promptEpoch = ref(0);
	const promptOrigin = ref("typed");
	const starterPrompt = ref(null);
	const insertionPoint = shallowRef({
		textOffset: 0,
		referenceIndex: 0
	});
	const retiredAssets = /* @__PURE__ */ new Set();
	const thumbnailJobs = /* @__PURE__ */ new Map();
	onScopeDispose(() => {
		for (const job of thumbnailJobs.values()) job.controller.abort();
		thumbnailJobs.clear();
		for (const attachment of assetsById.values()) revokePreview(attachment);
	});
	function cancelThumbnail(id) {
		thumbnailJobs.get(id)?.controller.abort();
		thumbnailJobs.delete(id);
	}
	function ensureThumbnail(attachment) {
		const { id, mediaUrl, previewUrl } = attachment;
		if ((attachment.mediaKind ?? getMediaTypeFromFilename(attachment.name)) !== "video" || !mediaUrl || previewUrl) {
			cancelThumbnail(id);
			return;
		}
		if (thumbnailJobs.get(id)?.source === mediaUrl) return;
		cancelThumbnail(id);
		const job = {
			source: mediaUrl,
			controller: new AbortController()
		};
		thumbnailJobs.set(id, job);
		createVideoThumbnail(mediaUrl, job.controller.signal).then((url) => {
			if (!url) return;
			const current = assetsById.get(id);
			if (thumbnailJobs.get(id) !== job || !current || current.previewUrl || current.mediaUrl !== mediaUrl) {
				URL.revokeObjectURL(url);
				return;
			}
			updateAttachment(id, { previewUrl: url });
		});
	}
	const submission = shallowRef(null);
	let revision = 0;
	let nextSubmissionId = 0;
	function updateDraft(next) {
		++revision;
		draftState.value = next;
	}
	function setInsertionPoint(point) {
		insertionPoint.value = point;
	}
	function resetPromptHistory() {
		++promptEpoch.value;
	}
	function setText(text) {
		if (text === draft.value) return;
		updateDraft({
			text,
			references: prompt.value.references.map((item) => ({
				...item,
				textOffset: Math.min(text.length, item.textOffset)
			}))
		});
		insertionPoint.value = {
			textOffset: text.length,
			referenceIndex: prompt.value.references.length
		};
	}
	function resolveEditorReference(item) {
		if (item.kind === "node" && item.scope !== nodeScope.value) return [];
		if (item.kind !== "asset") return [item];
		if (!attachmentIds.value.includes(item.attachment.id)) return [];
		const attachment = assetsById.get(item.attachment.id);
		if (!attachment) return [];
		return [{
			...item,
			attachment
		}];
	}
	function applyEditorPrompt(next, metadataOnly = false) {
		const seen = /* @__PURE__ */ new Set();
		let hasSkill = false;
		const references = next.references.flatMap((item) => {
			if (item.kind === "skill") {
				if (item.scope !== skillScope || hasSkill) return [];
				hasSkill = true;
			}
			const key = composerReferenceKey(item);
			if (item.kind !== "asset" && seen.has(key)) return [];
			seen.add(key);
			return resolveEditorReference(item);
		});
		if (!next.text.trim() && references.length === 0 && promptOrigin.value === "suggestion") {
			promptOrigin.value = "typed";
			starterPrompt.value = null;
		}
		if (metadataOnly) draftState.value = {
			text: next.text,
			references
		};
		else updateDraft({
			text: next.text,
			references
		});
	}
	function resolveSkillMetadata(next) {
		if (next.text !== prompt.value.text) return;
		const previous = prompt.value.references.find((item) => item.kind === "skill");
		const resolved = next.references.find((item) => item.kind === "skill");
		if (!previous?.resolvePastedName || !resolved || resolved.resolvePastedName || previous.name !== resolved.name || previous.scope !== resolved.scope) return;
		applyEditorPrompt(next, true);
	}
	function markSuggestedPrompt(source) {
		promptOrigin.value = "suggestion";
		starterPrompt.value = source ?? null;
	}
	function snapshotReferences(next) {
		return promptReferenceParts(next.text, next.workflowReferences, next.skillReference).flatMap((part) => {
			if (part.type === "text") return [];
			if (part.type === "workflow") return [{
				...part.reference,
				kind: "workflow"
			}];
			return [{
				...part.reference,
				kind: "skill",
				scope: skillScope ?? ""
			}];
		});
	}
	function replacePrompt(next) {
		promptOrigin.value = "edited";
		starterPrompt.value = null;
		resetPromptHistory();
		updateDraft({
			text: next.text,
			references: [...snapshotReferences(next), ...prompt.value.references.filter((item) => item.kind !== "workflow" && item.kind !== "skill").map((item) => ({
				...item,
				textOffset: Math.min(item.textOffset, next.text.length)
			}))].sort((a, b) => a.textOffset - b.textOffset)
		});
	}
	function restorePrompt(next, included = attachments.value) {
		for (const attachment of included) {
			const current = assetsById.get(attachment.id);
			const restored = {
				...attachment,
				...current?.mediaUrl === attachment.mediaUrl && current?.previewUrl && !attachment.previewUrl ? { previewUrl: current.previewUrl } : {}
			};
			if (current) revokePreview(current, restored);
			assetsById.set(attachment.id, restored);
			retiredAssets.delete(attachment.id);
			ensureThumbnail(restored);
		}
		attachmentIds.value = included.map(({ id }) => id);
		resetPromptHistory();
		applyEditorPrompt(next);
		releaseUnusedAssets();
	}
	function replaceDraft(next) {
		restorePrompt({
			text: next.text,
			references: snapshotReferences(next)
		}, next.attachments);
	}
	function setWorkflowReferences(references) {
		updateDraft({
			text: draft.value,
			references: [...references.map((item) => ({
				...item,
				kind: "workflow"
			})), ...prompt.value.references.filter((item) => item.kind !== "workflow")].sort((a, b) => a.textOffset - b.textOffset)
		});
	}
	function removeReference(key) {
		const references = prompt.value.references.filter((item) => composerReferenceKey(item) !== key);
		if (references.length !== prompt.value.references.length) updateDraft({
			text: resetTextWhenReferencesCleared(draft.value, references),
			references
		});
	}
	function removeWorkflowReference(id) {
		removeReference(`workflow:${id}`);
	}
	function setNodeScope(scope) {
		if (scope === nodeScope.value) return;
		nodeScope.value = scope;
		if (nodes.value.length === 0) return;
		resetPromptHistory();
		const references = prompt.value.references.filter((item) => item.kind !== "node");
		updateDraft({
			text: resetTextWhenReferencesCleared(draft.value, references),
			references
		});
	}
	function setNodes(next) {
		if (next.length === nodes.value.length && next.every((node, index) => {
			const previous = nodes.value[index];
			return node.id === previous.id && node.locatorId === previous.locatorId && node.title === previous.title;
		})) return;
		const byKey = new Map(next.map((node) => [selectedNodeKey(node), node]));
		let result = {
			text: draft.value,
			references: prompt.value.references.flatMap((item) => {
				if (item.kind !== "node") return [item];
				const node = byKey.get(selectedNodeKey(item.node));
				return node ? [{
					...item,
					node
				}] : [];
			})
		};
		if (nodeScope.value !== null) for (const node of next) {
			if (result.references.some((item) => item.kind === "node" && selectedNodeKey(item.node) === selectedNodeKey(node))) continue;
			const inserted = insertComposerReference(result, {
				kind: "node",
				node: { ...node },
				scope: nodeScope.value,
				textOffset: 0
			}, insertionPoint.value);
			result = inserted.prompt;
			insertionPoint.value = inserted.insertion;
		}
		updateDraft({
			...result,
			text: resetTextWhenReferencesCleared(result.text, result.references)
		});
	}
	function setSkillScope(scope) {
		if (scope === skillScope) return;
		skillScope = scope;
		if (!prompt.value.references.some((item) => item.kind === "skill")) return;
		resetPromptHistory();
		const references = prompt.value.references.filter((item) => item.kind !== "skill");
		updateDraft({
			text: resetTextWhenReferencesCleared(draft.value, references),
			references
		});
	}
	function addAttachment(attachment) {
		if (assetsById.has(attachment.id) || retiredAssets.has(attachment.id)) return false;
		if (attachment.sourceKey && attachments.value.some((item) => item.sourceKey === attachment.sourceKey)) return false;
		assetsById.set(attachment.id, { ...attachment });
		attachmentIds.value = [...attachmentIds.value, attachment.id];
		++revision;
		ensureThumbnail(attachment);
		return true;
	}
	function referenceAttachment(id) {
		const attachment = assetsById.get(id);
		if (!attachment || !attachmentIds.value.includes(id)) return false;
		const inserted = insertComposerReference(prompt.value, {
			kind: "asset",
			attachment: { ...attachment },
			textOffset: 0
		}, insertionPoint.value);
		insertionPoint.value = inserted.insertion;
		updateDraft(inserted.prompt);
		return true;
	}
	function revokePreview(attachment, retained) {
		const retainedUrls = /* @__PURE__ */ new Set([retained?.previewUrl, retained?.mediaUrl]);
		for (const url of /* @__PURE__ */ new Set([attachment.previewUrl, attachment.mediaUrl])) if (url?.startsWith("blob:") && !retainedUrls.has(url)) URL.revokeObjectURL(url);
	}
	function updateAttachment(id, patch) {
		const previous = assetsById.get(id);
		if (!previous) {
			revokePreview(patch);
			return;
		}
		const attachment = {
			...previous,
			...patch,
			id
		};
		if (attachment.mediaUrl !== previous.mediaUrl) cancelThumbnail(id);
		revokePreview(previous, attachment);
		assetsById.set(id, attachment);
		ensureThumbnail(attachment);
		if (prompt.value.references.some((item) => item.kind === "asset" && item.attachment.id === id)) updateDraft({
			text: draft.value,
			references: prompt.value.references.map((item) => item.kind === "asset" && item.attachment.id === id ? {
				...item,
				attachment
			} : item)
		});
	}
	function removeAttachment(id) {
		cancelThumbnail(id);
		const attachment = assetsById.get(id);
		if (attachment) revokePreview(attachment);
		assetsById.delete(id);
		retiredAssets.add(id);
		if (attachmentIds.value.includes(id)) {
			attachmentIds.value = attachmentIds.value.filter((item) => item !== id);
			++revision;
		}
		removeReference(`asset:${id}`);
	}
	function releaseUnusedAssets() {
		const retained = new Set(attachments.value.map(({ id }) => id));
		for (const attachment of submission.value?.snapshot.attachments ?? []) retained.add(attachment.id);
		for (const [id, attachment] of assetsById) if (!retained.has(id)) {
			cancelThumbnail(id);
			revokePreview(attachment);
			assetsById.delete(id);
			retiredAssets.add(id);
		}
	}
	function startSubmission(snapshot) {
		resetPromptHistory();
		const origin = promptOrigin.value;
		const chip = starterPrompt.value;
		promptOrigin.value = "typed";
		starterPrompt.value = null;
		attachmentIds.value = [];
		updateDraft({
			text: "",
			references: []
		});
		insertionPoint.value = {
			textOffset: 0,
			referenceIndex: 0
		};
		const id = ++nextSubmissionId;
		submission.value = {
			id,
			phase: "pending",
			revision,
			origin,
			starterPrompt: chip,
			snapshot
		};
		return id;
	}
	function settleSubmission(id, sent) {
		const pending = submission.value;
		if (pending?.id !== id) return;
		submission.value = sent || pending.revision !== revision ? null : {
			...pending,
			phase: "failed"
		};
		releaseUnusedAssets();
	}
	function takeFailedSubmission() {
		const failed = submission.value;
		if (failed?.phase !== "failed") return;
		submission.value = null;
		if (failed.revision !== revision) return;
		promptOrigin.value = failed.origin;
		starterPrompt.value = failed.starterPrompt;
		return failed.snapshot;
	}
	function invalidateSubmission() {
		submission.value = null;
		releaseUnusedAssets();
	}
	return {
		draftState,
		draft,
		attachments,
		workflowReferences,
		prompt,
		nodes,
		hasDraft,
		nodeScope,
		promptEpoch,
		promptOrigin,
		starterPrompt,
		insertionPoint,
		submission,
		setText,
		setInsertionPoint,
		resetPromptHistory,
		applyEditorPrompt,
		resolveSkillMetadata,
		markSuggestedPrompt,
		replacePrompt,
		restorePrompt,
		replaceDraft,
		setWorkflowReferences,
		removeWorkflowReference,
		removeReference,
		setNodeScope,
		setSkillScope,
		setNodes,
		addAttachment,
		referenceAttachment,
		updateAttachment,
		removeAttachment,
		releaseUnusedAssets,
		startSubmission,
		settleSubmission,
		takeFailedSubmission,
		invalidateSubmission
	};
});
//#endregion
export { reportLostEdit as _, agentMessageText as a, composerReferenceKey as c, useCanvasSelection as d, attachRestoreOpMinter as f, attachDocOpMinter as g, notifyRestoreMintersGraphLoadError as h, sameComposerReferenceOrder as i, composerReferenceName as l, notifyRestoreMintersBeforeGraphLoad as m, composerPromptForSend as n, assetReferenceText as o, notifyRestoreMintersAfterGraphConfigure as p, composerPromptForSubmission as r, nodeReferenceText as s, useAgentComposerStore as t, selectedNodeKey as u };
