import "./rolldown-runtime-xtsTai4I.js";
import { Ft as ref, P as computed, Rt as shallowRef, d as defineStore, jt as markRaw } from "./vendor-vue-core-CuN1excl.js";
//#region src/stores/extensionStore.ts
/**
* These extensions are always active, even if they are disabled in the setting.
*/
var ALWAYS_ENABLED_EXTENSIONS = [];
var ALWAYS_DISABLED_EXTENSIONS = [
	"pysssss.Locking",
	"pysssss.SnapToGrid",
	"pysssss.FaviconStatus",
	"KJNodes.browserstatus"
];
var useExtensionStore = defineStore("extension", () => {
	const extensionByName = ref({});
	const extensions = computed(() => Object.values(extensionByName.value));
	const disabledExtensionNames = ref(/* @__PURE__ */ new Set());
	const inactiveDisabledExtensionNames = computed(() => {
		return Array.from(disabledExtensionNames.value).filter((name) => !(name in extensionByName.value));
	});
	const isExtensionInstalled = (name) => name in extensionByName.value;
	const isExtensionEnabled = (name) => !disabledExtensionNames.value.has(name);
	const enabledExtensions = computed(() => {
		return extensions.value.filter((ext) => isExtensionEnabled(ext.name));
	});
	function isExtensionReadOnly(name) {
		return ALWAYS_DISABLED_EXTENSIONS.includes(name) || ALWAYS_ENABLED_EXTENSIONS.includes(name);
	}
	function registerExtension(extension) {
		if (!extension.name) throw new Error("Extensions must have a 'name' property.");
		if (extension.name in extensionByName.value) throw new Error(`Extension named '${extension.name}' already registered.`);
		if (disabledExtensionNames.value.has(extension.name)) console.warn(`Extension ${extension.name} is disabled.`);
		extensionByName.value[extension.name] = markRaw(extension);
	}
	const registration = shallowRef({ mode: "immediate" });
	const isHoldingExtensions = computed(() => registration.value.mode === "holding");
	const areLateExtensionsPending = computed(() => registration.value.mode !== "immediate");
	/** From now on the extension service holds new extensions instead of registering them. */
	function holdNewExtensions() {
		if (registration.value.mode === "immediate") registration.value = {
			mode: "holding",
			held: []
		};
	}
	function holdExtension(extension) {
		const current = registration.value;
		if (current.mode === "holding") registration.value = {
			mode: "holding",
			held: [...current.held, extension]
		};
	}
	function releaseHeldExtension(extension) {
		const current = registration.value;
		if (current.mode === "holding") registration.value = {
			mode: "holding",
			held: current.held.filter((held) => held !== extension)
		};
	}
	/** Returns the extensions held so far, in registration order; holding goes on. */
	function takeHeldExtensions() {
		const current = registration.value;
		if (current.mode !== "holding") return [];
		registration.value = {
			mode: "holding",
			held: []
		};
		return [...current.held];
	}
	/** Ends holding and returns the extensions still held; they stay pending until `finishLateExtensions`. */
	function stopHoldingExtensions() {
		const current = registration.value;
		if (current.mode !== "holding") return [];
		registration.value = { mode: "starting" };
		return [...current.held];
	}
	function finishLateExtensions() {
		registration.value = { mode: "immediate" };
	}
	const nodeDefHooksOwed = ref(false);
	/** The next node definitions fetched go through every extension's `addCustomNodeDefs` before they register. */
	function oweNodeDefHooks() {
		nodeDefHooksOwed.value = true;
	}
	/** Whether the next node definitions fetched are owed to `addCustomNodeDefs`, without settling the debt. */
	function areNodeDefHooksOwed() {
		return nodeDefHooksOwed.value;
	}
	/** Whether fetched node definitions are owed to `addCustomNodeDefs`; settles the debt. */
	function takeOwedNodeDefHooks() {
		const owed = nodeDefHooksOwed.value;
		nodeDefHooksOwed.value = false;
		return owed;
	}
	function unregisterExtension(name) {
		delete extensionByName.value[name];
	}
	function loadDisabledExtensionNames(names) {
		disabledExtensionNames.value = new Set(names);
		for (const name of ALWAYS_DISABLED_EXTENSIONS) disabledExtensionNames.value.add(name);
		for (const name of ALWAYS_ENABLED_EXTENSIONS) disabledExtensionNames.value.delete(name);
	}
	/**
	* Core extensions are extensions that are defined in the core package.
	* See /extensions/core/index.ts for the list.
	*/
	const coreExtensionNames = ref([]);
	function captureCoreExtensions() {
		coreExtensionNames.value = extensions.value.map((ext) => ext.name);
	}
	function isCoreExtension(name) {
		return coreExtensionNames.value.includes(name);
	}
	return {
		extensions,
		enabledExtensions,
		inactiveDisabledExtensionNames,
		isExtensionInstalled,
		isExtensionEnabled,
		isExtensionReadOnly,
		registerExtension,
		unregisterExtension,
		isHoldingExtensions,
		areLateExtensionsPending,
		holdNewExtensions,
		holdExtension,
		releaseHeldExtension,
		takeHeldExtensions,
		stopHoldingExtensions,
		finishLateExtensions,
		oweNodeDefHooks,
		areNodeDefHooksOwed,
		takeOwedNodeDefHooks,
		loadDisabledExtensionNames,
		captureCoreExtensions,
		isCoreExtension,
		hasThirdPartyExtensions: computed(() => {
			return extensions.value.some((ext) => !isCoreExtension(ext.name));
		})
	};
});
//#endregion
export { useExtensionStore as t };
