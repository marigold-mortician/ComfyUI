import { a as __toESM, r as __name } from "./rolldown-runtime-xtsTai4I.js";
import { An as toNumber, Fn as without$1, In as remove$1, Mn as isEqual, Nn as isEqualWith$1, On as truncate, P as SubgraphNode, Pn as once$1, Rn as difference$1, U as resolveSubgraphInputTarget, _n as parseWidgetId, gn as isWidgetId, jn as isSymbol$1, kn as clamp, n as LGraphCanvas, t as LiteGraph, vn as widgetId, yn as isUuidShapedSubgraphId } from "./litegraph-DsPnoImk.js";
import { a as groupBy, o as groupBy$1 } from "./commandStore-XD_i1hej.js";
import { C as head, D as toArray$1, E as isIterateeCall, S as isPrototype, T as every, b as resolveNodeWidget, o as getWidgetIdForNode, p as isSelectOnly, w as filter, x as isEmpty, y as resolveNode } from "./litegraphUtil-8EMdlR16.js";
import { t as shuffle$1 } from "./shuffle-CnBsCH60.js";
import { s as uniq } from "./treeUtil-4aExWhwq.js";
import { d as uniqBy$1 } from "./executionErrorStore-DzGUJU_L.js";
import { t as debounce } from "./debounce-CrddqoI1.js";
import { a as isArguments, c as isMatchWith, d as identity$1, i as isIndex, l as property, n as matchesProperty, o as matches, r as has, s as isMatch, t as iteratee, u as cloneDeep } from "./iteratee-D-xtYlr8.js";
import { n as useSettingStore } from "./settingStore-DRRi2kOn.js";
import { F as isObjectLike, I as isPlainObject, L as sumBy$1, M as merge, N as mergeWith, P as isArrayLikeObject } from "./dialogService-CqZr0BhP.js";
import { n as range$1, t as map } from "./map--HGZfCRO.js";
import { A as getTag, C as setTag, D as uint32ArrayTag, E as uint16ArrayTag, M as isBuffer$1, O as uint8ArrayTag, P as isPrimitive, S as regexpTag, T as symbolTag, _ as int32ArrayTag, a as arrayBufferTag, b as numberTag, d as dateTag, g as int16ArrayTag, i as argumentsTag, j as getSymbols, k as uint8ClampedArrayTag, l as booleanTag, m as float64ArrayTag, n as cloneDeepWith, o as arrayTag, p as float32ArrayTag, t as cloneDeep$1, u as dataViewTag, v as int8ArrayTag, w as stringTag, x as objectTag, y as mapTag } from "./cloneDeep-BX7AjX4w.js";
import { c as mapKeys$1, t as useNodeOutputStore } from "./nodeOutputStore-Dec5oA1b.js";
import { n as mapValues$1, t as uniq$1 } from "./uniq-HSN5S90b.js";
import { a as toString, i as toKey, n as isDeepKey, o as isUnsafeProperty, r as toPath, t as get } from "./get-Bk-Y8oEe.js";
import { n as isArrayLike, r as isEqualsSameValueZero, t as isObject } from "./isObject-BDwzDI3k.js";
import { t as deburr$1 } from "./deburr-BNFMXPzm.js";
import { X as trimEnd$1, i as api } from "./api-BdJmXw98.js";
import { Ft as ref, P as computed, Rt as shallowRef, bt as watch, d as defineStore, l as useRouter, o as NavigationFailureType, s as isNavigationFailure } from "./vendor-vue-core-CuN1excl.js";
import { Fr as createSharedComposable, Wr as useDebounceFn, ar as useEventListener } from "./vendor-reka-ui-NRTk7aIV.js";
import { D as flatten$1, E as flatMapDepth, T as union, a as useWidgetHistoryStore, i as ownsNodeHistory, l as provideChangeTracker, n as useWorkflowStore } from "./workflowStore-ChkUx7Si.js";
import { _ as memoize } from "./colorUtil--RFe1UD6.js";
import { n as useApp, r as isTypedArray } from "./appInstance-CiT6CpGM.js";
import { r as reportError } from "./reportError-BHgDVvfb.js";
import { r as useQueueSettingsStore } from "./queueSettingsStore-BzKxsLQU.js";
import { L as isSubgraph, P as isNonNullish, Q as serializeNodeId, Z as parseNodeId, c as findSubgraphPathById } from "./graphTraversalUtil-BUK1cr2m.js";
import { t as assert } from "./assert--qJvwrYk.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
import { a as useAppMode, n as useCanvasStore } from "./canvasStore-siYzI5aT.js";
import { n as useRouteHash } from "./vendor-vueuse-ehQVlHrl.js";
import { t as useSidebarTabStore } from "./sidebarTabStore-DSQyJJJG.js";
import "./layerEditorDialogKey-j8nal3kA.js";
import { a as parseFlattenableSubgraphDefinitions, r as collectSubgraphDefinitions } from "./workflowFlattening-DY0Vs9rF.js";
import { n as useExecutionStore } from "./executionStore-DrU24oQb.js";
import { t as require_quick_lru } from "./quick-lru-CwZ_Nev1.js";
import { t as isModalOpen } from "./modalUtil-Cmzr62_V.js";
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/chunk.mjs
/**
* Splits an array into smaller arrays of a specified length.
*
* This function takes an input array and divides it into multiple smaller arrays,
* each of a specified length. If the input array cannot be evenly divided,
* the final sub-array will contain the remaining elements.
*
* @template T The type of elements in the array.
* @param arr - The array to be chunked into smaller arrays.
* @param size - The size of each smaller array. Must be a positive integer.
* @returns A two-dimensional array where each sub-array has a maximum length of `size`.
* @throws {Error} Throws an error if `size` is not a positive integer.
*
* @example
* // Splits an array of numbers into sub-arrays of length 2
* chunk([1, 2, 3, 4, 5], 2);
* // Returns: [[1, 2], [3, 4], [5]]
*
* @example
* // Splits an array of strings into sub-arrays of length 3
* chunk(['a', 'b', 'c', 'd', 'e', 'f', 'g'], 3);
* // Returns: [['a', 'b', 'c'], ['d', 'e', 'f'], ['g']]
*/
function chunk$1(arr, size) {
	if (!Number.isInteger(size) || size <= 0) throw new Error("Size must be an integer greater than zero.");
	const chunkLength = Math.ceil(arr.length / size);
	const result = Array(chunkLength);
	for (let index = 0; index < chunkLength; index++) {
		const start = index * size;
		const end = start + size;
		result[index] = arr.slice(start, end);
	}
	return result;
}
__name(chunk$1, "chunk");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/compact.mjs
/**
* Removes falsey values (false, null, 0, -0, 0n, '', undefined, NaN) from an array.
*
* @template T - The type of elements in the array.
* @param arr - The input array to remove falsey values.
* @returns A new array with all falsey values removed.
*
* @example
* compact([0, -0, 0n, 1, false, 2, '', 3, null, undefined, 4, NaN, 5]);
* Returns: [1, 2, 3, 4, 5]
*/
function compact$1(arr) {
	const result = [];
	for (let i = 0; i < arr.length; i++) {
		const item = arr[i];
		if (item) result.push(item);
	}
	return result;
}
__name(compact$1, "compact");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/differenceBy.mjs
/**
* Computes the difference between two arrays after mapping their elements through a provided function.
*
* This function takes two arrays and a mapper function. It returns a new array containing the elements
* that are present in the first array but not in the second array, based on the identity calculated
* by the mapper function.
*
* Essentially, it filters out any elements from the first array that, when
* mapped, match an element in the mapped version of the second array.
*
* @template T, U
* @param firstArr - The primary array from which to derive the difference.
* @param secondArr - The array containing elements to be excluded from the first array.
* @param mapper - The function to map the elements of both arrays. This function
* is applied to each element in both arrays, and the comparison is made based on the mapped values.
* @returns A new array containing the elements from the first array that do not have a corresponding
* mapped identity in the second array.
*
* @example
* const array1 = [{ id: 1 }, { id: 2 }, { id: 3 }];
* const array2 = [{ id: 2 }, { id: 4 }];
* const mapper = item => item.id;
* const result = differenceBy(array1, array2, mapper);
* // result will be [{ id: 1 }, { id: 3 }] since the elements with id 2 are in both arrays and are excluded from the result.
*
* @example
* const array1 = [{ id: 1 }, { id: 2 }, { id: 3 }];
* const array2 = [2, 4];
* const mapper = item => (typeof item === 'object' ? item.id : item);
* const result = differenceBy(array1, array2, mapper);
* // result will be [{ id: 1 }, { id: 3 }] since 2 is present in both arrays after mapping, and is excluded from the result.
*/
function differenceBy$1(firstArr, secondArr, mapper) {
	const mappedSecondSet = new Set(secondArr.map((item) => mapper(item)));
	return firstArr.filter((item) => {
		return !mappedSecondSet.has(mapper(item));
	});
}
__name(differenceBy$1, "differenceBy");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/differenceWith.mjs
/**
* Computes the difference between two arrays based on a custom equality function.
*
* This function takes two arrays and a custom comparison function. It returns a new array containing
* the elements that are present in the first array but not in the second array. The comparison to determine
* if elements are equal is made using the provided custom function.
*
* @template T, U
* @param firstArr - The array from which to get the difference.
* @param secondArr - The array containing elements to exclude from the first array.
* @param areItemsEqual - A function to determine if two items are equal.
* @returns A new array containing the elements from the first array that do not match any elements in the second array
* according to the custom equality function.
*
* @example
* const array1 = [{ id: 1 }, { id: 2 }, { id: 3 }];
* const array2 = [{ id: 2 }, { id: 4 }];
* const areItemsEqual = (a, b) => a.id === b.id;
* const result = differenceWith(array1, array2, areItemsEqual);
* // result will be [{ id: 1 }, { id: 3 }] since the elements with id 2 are considered equal and are excluded from the result.
*
* @example
* const array1 = [{ id: 1 }, { id: 2 }, { id: 3 }];
* const array2 = [2, 4];
* const areItemsEqual = (a, b) => a.id === b;
* const result = differenceWith(array1, array2, areItemsEqual);
* // result will be [{ id: 1 }, { id: 3 }] since the element with id 2 is considered equal to the second array's element and is excluded from the result.
*/
function differenceWith$1(firstArr, secondArr, areItemsEqual) {
	return firstArr.filter((firstItem) => {
		return secondArr.every((secondItem) => {
			return !areItemsEqual(firstItem, secondItem);
		});
	});
}
__name(differenceWith$1, "differenceWith");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/drop.mjs
/**
* Removes a specified number of elements from the beginning of an array and returns the rest.
*
* This function takes an array and a number, and returns a new array with the specified number
* of elements removed from the start.
*
* @template T - The type of elements in the array.
* @param arr - The array from which to drop elements.
* @param itemsCount - The number of elements to drop from the beginning of the array.
* @returns A new array with the specified number of elements removed from the start.
*
* @example
* const array = [1, 2, 3, 4, 5];
* const result = drop(array, 2);
* // result will be [3, 4, 5] since the first two elements are dropped.
*/
function drop$1(arr, itemsCount) {
	itemsCount = Math.max(itemsCount, 0);
	return arr.slice(itemsCount);
}
__name(drop$1, "drop");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/dropRight.mjs
/**
* Removes a specified number of elements from the end of an array and returns the rest.
*
* This function takes an array and a number, and returns a new array with the specified number
* of elements removed from the end.
*
* @template T - The type of elements in the array.
* @param arr - The array from which to drop elements.
* @param itemsCount - The number of elements to drop from the end of the array.
* @returns A new array with the specified number of elements removed from the end.
*
* @example
* const array = [1, 2, 3, 4, 5];
* const result = dropRight(array, 2);
* // result will be [1, 2, 3] since the last two elements are dropped.
*/
function dropRight$1(arr, itemsCount) {
	itemsCount = Math.min(-itemsCount, 0);
	if (itemsCount === 0) return arr.slice();
	return arr.slice(0, itemsCount);
}
__name(dropRight$1, "dropRight");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/dropRightWhile.mjs
/**
* Removes elements from the end of an array until the predicate returns false.
*
* This function iterates over an array from the end and drops elements until the provided
* predicate function returns false. It then returns a new array with the remaining elements.
*
* @template T - The type of elements in the array.
* @param arr - The array from which to drop elements.
* @param canContinueDropping - A predicate function that determines
* whether to continue dropping elements. The function is called with each element from the end,
* and dropping continues as long as it returns true.
* @returns A new array with the elements remaining after the predicate returns false.
*
* @example
* const array = [1, 2, 3, 4, 5];
* const result = dropRightWhile(array, x => x > 3);
* // result will be [1, 2, 3] since elements greater than 3 are dropped from the end.
*/
function dropRightWhile$1(arr, canContinueDropping) {
	for (let i = arr.length - 1; i >= 0; i--) if (!canContinueDropping(arr[i], i, arr)) return arr.slice(0, i + 1);
	return [];
}
__name(dropRightWhile$1, "dropRightWhile");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/dropWhile.mjs
/**
* Removes elements from the beginning of an array until the predicate returns false.
*
* This function iterates over an array and drops elements from the start until the provided
* predicate function returns false. It then returns a new array with the remaining elements.
*
* @template T - The type of elements in the array.
* @param arr - The array from which to drop elements.
* @param canContinueDropping - A predicate function that determines
* whether to continue dropping elements. The function is called with each element, and dropping
* continues as long as it returns true.
* @returns A new array with the elements remaining after the predicate returns false.
*
* @example
* const array = [1, 2, 3, 4, 5];
* const result = dropWhile(array, x => x < 3);
* // result will be [3, 4, 5] since elements less than 3 are dropped.
*/
function dropWhile$1(arr, canContinueDropping) {
	const dropEndIndex = arr.findIndex((item, index, arr) => !canContinueDropping(item, index, arr));
	if (dropEndIndex === -1) return [];
	return arr.slice(dropEndIndex);
}
__name(dropWhile$1, "dropWhile");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/fill.mjs
/**
* Fills elements of an array with a specified value from the start position up to, but not including, the end position.
*
* This function mutates the original array and replaces its elements with the provided value, starting from the specified
* start index up to the end index (non-inclusive). If the start or end indices are not provided, it defaults to filling the
* entire array.
*
* @template T - The type of elements in the original array.
* @template U - The type of the value to fill the array with.
* @param array - The array to fill.
* @param value - The value to fill the array with.
* @param [start=0] - The start position. Defaults to 0.
* @param [end=arr.length] - The end position. Defaults to the array's length.
* @returns The array with the filled values.
*
* @example
* fill([1, 2, 3], 'a');
* // => ['a', 'a', 'a']
*
* fill(Array(3), 2);
* // => [2, 2, 2]
*
* fill([4, 6, 8, 10], '*', 1, 3);
* // => [4, '*', '*', 10]
*
* fill([1, 2, 3], '*', -2, -1);
* // => [1, '*', 3]
*/
function fill$1(array, value, start = 0, end = array.length) {
	const length = array.length;
	const finalStart = Math.max(start >= 0 ? start : length + start, 0);
	const finalEnd = Math.min(end >= 0 ? end : length + end, length);
	for (let i = finalStart; i < finalEnd; i++) array[i] = value;
	return array;
}
__name(fill$1, "fill");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/flatten.mjs
/**
* Flattens an array up to the specified depth.
*
* @template T - The type of elements within the array.
* @template D - The depth to which the array should be flattened.
* @param arr - The array to flatten.
* @param depth - The depth level specifying how deep a nested array structure should be flattened. Defaults to 1.
* @returns A new array that has been flattened.
*
* @example
* const arr = flatten([1, [2, 3], [4, [5, 6]]], 1);
* // Returns: [1, 2, 3, 4, [5, 6]]
*
* const arr = flatten([1, [2, 3], [4, [5, 6]]], 2);
* // Returns: [1, 2, 3, 4, 5, 6]
*/
function flatten(arr, depth = 1) {
	const result = [];
	const flooredDepth = Math.floor(depth);
	const recursive = (arr, currentDepth) => {
		for (let i = 0; i < arr.length; i++) {
			const item = arr[i];
			if (Array.isArray(item) && currentDepth < flooredDepth) recursive(item, currentDepth + 1);
			else result.push(item);
		}
	};
	recursive(arr, 0);
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/initial.mjs
/**
* Returns a new array containing all elements except the last one from the input array.
* If the input array is empty or has only one element, the function returns an empty array.
*
* @template T The type of elements in the array.
* @param arr - The input array.
* @returns A new array containing all but the last element of the input array.
*
* @example
* const arr = [1, 2, 3, 4];
* const result = initial(arr);
* // result will be [1, 2, 3]
*/
function initial$1(arr) {
	return arr.slice(0, -1);
}
__name(initial$1, "initial");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/intersection.mjs
/**
* Returns the intersection of two arrays.
*
* This function takes two arrays and returns a new array containing the elements that are
* present in both arrays. It effectively filters out any elements from the first array that
* are not found in the second array.
*
* @template T - The type of elements in the array.
* @param firstArr - The first array to compare.
* @param secondArr - The second array to compare.
* @returns A new array containing the elements that are present in both arrays.
*
* @example
* const array1 = [1, 2, 3, 4, 5];
* const array2 = [3, 4, 5, 6, 7];
* const result = intersection(array1, array2);
* // result will be [3, 4, 5] since these elements are in both arrays.
*/
function intersection$1(firstArr, secondArr) {
	const secondSet = new Set(secondArr);
	return firstArr.filter((item) => secondSet.has(item));
}
__name(intersection$1, "intersection");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/intersectionBy.mjs
/**
* Returns the intersection of two arrays based on a mapping function.
*
* This function takes two arrays and a mapping function. It returns a new array containing
* the elements from the first array that, when mapped using the provided function, have matching
* mapped elements in the second array. It effectively filters out any elements from the first array
* that do not have corresponding mapped values in the second array.
*
* @template T - The type of elements in the first array.
* @template U - The type of elements in the second array.
* @param firstArr - The first array to compare.
* @param secondArr - The second array to compare.
* @param mapper - A function to map the elements of both arrays for comparison.
* @returns A new array containing the elements from the first array that have corresponding mapped values in the second array.
*
* @example
* const array1 = [{ id: 1 }, { id: 2 }, { id: 3 }];
* const array2 = [{ id: 2 }, { id: 4 }];
* const mapper = item => item.id;
* const result = intersectionBy(array1, array2, mapper);
* // result will be [{ id: 2 }] since only this element has a matching id in both arrays.
*
* @example
* const array1 = [
*   { id: 1, name: 'jane' },
*   { id: 2, name: 'amy' },
*   { id: 3, name: 'michael' },
* ];
* const array2 = [2, 4];
* const mapper = item => (typeof item === 'object' ? item.id : item);
* const result = intersectionBy(array1, array2, mapper);
* // result will be [{ id: 2, name: 'amy' }] since only this element has a matching id that is equal to seconds array's element.
*/
function intersectionBy$1(firstArr, secondArr, mapper) {
	const result = [];
	const mappedSecondSet = new Set(secondArr.map(mapper));
	for (let i = 0; i < firstArr.length; i++) {
		const item = firstArr[i];
		const mappedItem = mapper(item);
		if (mappedSecondSet.has(mappedItem)) {
			result.push(item);
			mappedSecondSet.delete(mappedItem);
		}
	}
	return result;
}
__name(intersectionBy$1, "intersectionBy");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/intersectionWith.mjs
/**
* Returns the intersection of two arrays based on a custom equality function.
*
* This function takes two arrays and a custom equality function. It returns a new array containing
* the elements from the first array that have matching elements in the second array, as determined
* by the custom equality function. It effectively filters out any elements from the first array that
* do not have corresponding matches in the second array according to the equality function.
*
* @template T - The type of elements in the first array.
* @template U - The type of elements in the second array.
* @param firstArr - The first array to compare.
* @param secondArr - The second array to compare.
* @param areItemsEqual - A custom function to determine if two elements are equal.
* This function takes two arguments, one from each array, and returns `true` if the elements are considered equal, and `false` otherwise.
* @returns A new array containing the elements from the first array that have corresponding matches in the second array according to the custom equality function.
*
* @example
* const array1 = [{ id: 1 }, { id: 2 }, { id: 3 }];
* const array2 = [{ id: 2 }, { id: 4 }];
* const areItemsEqual = (a, b) => a.id === b.id;
* const result = intersectionWith(array1, array2, areItemsEqual);
* // result will be [{ id: 2 }] since this element has a matching id in both arrays.
*
* @example
* const array1 = [
*   { id: 1, name: 'jane' },
*   { id: 2, name: 'amy' },
*   { id: 3, name: 'michael' },
* ];
* const array2 = [2, 4];
* const areItemsEqual = (a, b) => a.id === b;
* const result = intersectionWith(array1, array2, areItemsEqual);
* // result will be [{ id: 2, name: 'amy' }] since this element has a matching id that is equal to seconds array's element.
*/
function intersectionWith$1(firstArr, secondArr, areItemsEqual) {
	return firstArr.filter((firstItem) => {
		return secondArr.some((secondItem) => {
			return areItemsEqual(firstItem, secondItem);
		});
	});
}
__name(intersectionWith$1, "intersectionWith");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/last.mjs
/**
* Returns the last element of an array.
*
* This function takes an array and returns the last element of the array.
* If the array is empty, the function returns `undefined`.
*
* Unlike some implementations, this function is optimized for performance
* by directly accessing the last index of the array.
*
* @template T - The type of elements in the array.
* @param arr - The array from which to get the last element.
* @returns The last element of the array, or `undefined` if the array is empty.
*
* @example
* const arr = [1, 2, 3];
* const lastElement = last(arr);
* // lastElement will be 3
*
* const emptyArr: number[] = [];
* const noElement = last(emptyArr);
* // noElement will be undefined
*/
function last$1(arr) {
	return arr[arr.length - 1];
}
__name(last$1, "last");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/maxBy.mjs
/**
* Finds the element in an array that has the maximum value when applying
* the `getValue` function to each element.
*
* @template T - The type of elements in the array.
* @param items The array of elements to search.
* @param getValue A function that selects a numeric value from each element.
* @returns The element with the maximum value as determined by the `getValue` function,
* or `undefined` if the array is empty.
* @example
* maxBy([{ a: 1 }, { a: 2 }, { a: 3 }], x => x.a); // Returns: { a: 3 }
* maxBy([], x => x.a); // Returns: undefined
* maxBy([3, NaN, 1], x => x); // Returns: NaN (NaN propagates, matching Math.max)
* maxBy(
*   [
*     { name: 'john', age: 30 },
*     { name: 'jane', age: 28 },
*     { name: 'joe', age: 26 },
*   ],
*   x => x.age
* ); // Returns: { name: 'john', age: 30 }
*/
function maxBy$1(items, getValue) {
	if (items.length === 0) return;
	let maxElement = items[0];
	let max = -Infinity;
	for (let i = 0; i < items.length; i++) {
		const element = items[i];
		const value = getValue(element, i, items);
		if (Number.isNaN(value)) return element;
		if (value > max) {
			max = value;
			maxElement = element;
		}
	}
	return maxElement;
}
__name(maxBy$1, "maxBy");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/minBy.mjs
/**
* Finds the element in an array that has the minimum value when applying
* the `getValue` function to each element.
*
* @template T - The type of elements in the array.
* @param items The array of elements to search.
* @param getValue A function that selects a numeric value from each element.
* @returns The element with the minimum value as determined by the `getValue` function,
* or `undefined` if the array is empty.
* @example
* minBy([{ a: 1 }, { a: 2 }, { a: 3 }], x => x.a); // Returns: { a: 1 }
* minBy([], x => x.a); // Returns: undefined
* minBy([3, NaN, 1], x => x); // Returns: NaN (NaN propagates, matching Math.min)
* minBy(
*   [
*     { name: 'john', age: 30 },
*     { name: 'jane', age: 28 },
*     { name: 'joe', age: 26 },
*   ],
*   x => x.age
* ); // Returns: { name: 'joe', age: 26 }
*/
function minBy$1(items, getValue) {
	if (items.length === 0) return;
	let minElement = items[0];
	let min = Infinity;
	for (let i = 0; i < items.length; i++) {
		const element = items[i];
		const value = getValue(element, i, items);
		if (Number.isNaN(value)) return element;
		if (value < min) {
			min = value;
			minElement = element;
		}
	}
	return minElement;
}
__name(minBy$1, "minBy");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/pull.mjs
/**
* Removes all specified values from an array.
*
* This function changes `arr` in place.
* If you want to remove values without modifying the original array, use `difference`.
*
* @template T
* @param arr - The array to modify.
* @param valuesToRemove - The values to remove from the array.
* @returns The modified array with the specified values removed.
*
* @example
* const numbers = [1, 2, 3, 4, 5, 2, 4];
* pull(numbers, [2, 4]);
* console.log(numbers); // [1, 3, 5]
*/
function pull$1(arr, valuesToRemove) {
	const valuesSet = new Set(valuesToRemove);
	let resultIndex = 0;
	for (let i = 0; i < arr.length; i++) {
		if (valuesSet.has(arr[i])) continue;
		if (!Object.hasOwn(arr, i)) {
			delete arr[resultIndex++];
			continue;
		}
		arr[resultIndex++] = arr[i];
	}
	arr.length = resultIndex;
	return arr;
}
__name(pull$1, "pull");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/sample.mjs
/**
* Returns a random element from an array.
*
* This function takes an array and returns a single element selected randomly from the array.
*
* @template T - The type of elements in the array.
* @param arr - The array to sample from.
* @returns A random element from the array.
*
* @example
* const array = [1, 2, 3, 4, 5];
* const randomElement = sample(array);
* // randomElement will be one of the elements from the array, selected randomly.
*/
function sample$1(arr) {
	return arr[Math.floor(Math.random() * arr.length)];
}
__name(sample$1, "sample");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/math/random.mjs
/**
* Generate a random number within the given range.
*
* @param minimum - The lower bound (inclusive).
* @param maximum - The upper bound (exclusive).
* @returns A random number between minimum (inclusive) and maximum (exclusive). The number can be an integer or a decimal.
* @throws {Error} Throws an error if `maximum` is not greater than `minimum`.
*
* @example
* const result1 = random(0, 5); // Returns a random number between 0 and 5.
* const result2 = random(5, 0); // If the minimum is greater than the maximum, an error is thrown.
* const result3 = random(5, 5); // If the minimum is equal to the maximum, an error is thrown.
*/
function random$1(minimum, maximum) {
	if (maximum == null) {
		maximum = minimum;
		minimum = 0;
	}
	if (minimum >= maximum) throw new Error("Invalid input: The maximum value must be greater than the minimum value.");
	return Math.random() * (maximum - minimum) + minimum;
}
__name(random$1, "random");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/math/randomInt.mjs
/**
* Generates a random integer between minimum (inclusive) and maximum (exclusive).
*
* If only one argument is provided, a number between `0` and the given number is returned.
*
* @param minimum - The lower bound (inclusive).
* @param maximum - The upper bound (exclusive).
* @returns A random integer between minimum (inclusive) and maximum (exclusive).
* @throws {Error} Throws an error if `maximum` is not greater than `minimum`.
*
* @example
* const result = randomInt(0, 5); // result will be a random integer between 0 (inclusive) and 5 (exclusive)
* const result2 = randomInt(5, 0); // This will throw an error
*/
function randomInt(minimum, maximum) {
	return Math.floor(random$1(minimum, maximum));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/sampleSize.mjs
/**
* Returns a sample element array of a specified `size`.
*
* This function takes an array and a number, and returns an array containing the sampled elements using Floyd's algorithm.
*
* {@link https://www.nowherenearithaca.com/2013/05/robert-floyds-tiny-and-beautiful.html Floyd's algorithm}
*
* @template T - The type of elements in the array.
* @param array - The array to sample from.
* @param size - The size of sample.
* @returns A new array with sample size applied.
* @throws {Error} Throws an error if `size` is greater than the length of `array`.
*
* @example
* const result = sampleSize([1, 2, 3], 2)
* // result will be an array containing two of the elements from the array.
* // [1, 2] or [1, 3] or [2, 3]
*/
function sampleSize$1(array, size) {
	if (size > array.length) throw new Error("Size must be less than or equal to the length of array.");
	const result = new Array(size);
	const selected = /* @__PURE__ */ new Set();
	for (let step = array.length - size, resultIndex = 0; step < array.length; step++, resultIndex++) {
		let index = randomInt(0, step + 1);
		if (selected.has(index)) index = step;
		selected.add(index);
		result[resultIndex] = array[index];
	}
	return result;
}
__name(sampleSize$1, "sampleSize");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/tail.mjs
/**
* Returns a new array with all elements except for the first.
*
* This function takes an array and returns a new array containing all the elements
* except for the first one. If the input array is empty or has only one element,
* an empty array is returned.
*
* @template T - The type of elements in the array.
* @param arr - The array to get the tail of.
* @returns A new array containing all elements of the input array except for the first one.
*
* @example
* const arr1 = [1, 2, 3];
* const result = tail(arr1);
* // result will be [2, 3]
*
* const arr2 = [1];
* const result2 = tail(arr2);
* // result2 will be []
*
* const arr3 = [];
* const result3 = tail(arr3);
* // result3 will be []
*/
function tail$1(arr) {
	return arr.slice(1);
}
__name(tail$1, "tail");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/take.mjs
/**
* Returns a new array containing the first `count` elements from the input array `arr`.
* If `count` is greater than the length of `arr`, the entire array is returned.
*
* @template T - Type of elements in the input array.
*
* @param arr - The array to take elements from.
* @param count - The number of elements to take.
* @returns A new array containing the first `count` elements from `arr`.
*
* @example
* // Returns [1, 2, 3]
* take([1, 2, 3, 4, 5], 3);
*
* @example
* // Returns ['a', 'b']
* take(['a', 'b', 'c'], 2);
*
* @example
* // Returns [1, 2, 3]
* take([1, 2, 3], 5);
*/
function take$1(arr, count) {
	return arr.slice(0, count);
}
__name(take$1, "take");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/takeRight.mjs
/**
* Returns a new array containing the last `count` elements from the input array `arr`.
* If `count` is greater than the length of `arr`, the entire array is returned.
*
* @template T - The type of elements in the array.
* @param arr - The array to take elements from.
* @param count - The number of elements to take.
* @returns A new array containing the last `count` elements from `arr`.
*
* @example
* // Returns [4, 5]
* takeRight([1, 2, 3, 4, 5], 2);
*
* @example
* // Returns ['b', 'c']
* takeRight(['a', 'b', 'c'], 2);
*
* @example
* // Returns [1, 2, 3]
* takeRight([1, 2, 3], 5);
*/
function takeRight$1(arr, count) {
	if (count <= 0 || arr.length === 0) return [];
	return arr.slice(-count);
}
__name(takeRight$1, "takeRight");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/uniqWith.mjs
/**
* Returns a new array containing only the unique elements from the original array,
* based on the values returned by the comparator function.
*
* @template T - The type of elements in the array.
* @param arr - The array to process.
* @param areItemsEqual - The function used to compare the array elements.
* @returns A new array containing only the unique elements from the original array, based on the values returned by the comparator function.
*
* @example
* ```ts
* uniqWith([1.2, 1.5, 2.1, 3.2, 5.7, 5.3, 7.19], (a, b) => Math.abs(a - b) < 1);
* // [1.2, 3.2, 5.7, 7.19]
* ```
*/
function uniqWith$1(arr, areItemsEqual) {
	const result = [];
	for (let i = 0; i < arr.length; i++) {
		const item = arr[i];
		if (result.every((v) => !areItemsEqual(v, item))) result.push(item);
	}
	return result;
}
__name(uniqWith$1, "uniqWith");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/unzip.mjs
/**
* Gathers elements in the same position in an internal array
* from a grouped array of elements and returns them as a new array.
*
* @template T - The type of elements in the nested array.
* @param zipped - The nested array to unzip.
* @returns A new array of unzipped elements.
*
* @example
* const zipped = [['a', true, 1],['b', false, 2]];
* const result = unzip(zipped);
* // result will be [['a', 'b'], [true, false], [1, 2]]
*/
function unzip$1(zipped) {
	let maxLen = 0;
	for (let i = 0; i < zipped.length; i++) if (zipped[i].length > maxLen) maxLen = zipped[i].length;
	const result = new Array(maxLen);
	for (let i = 0; i < maxLen; i++) {
		result[i] = new Array(zipped.length);
		for (let j = 0; j < zipped.length; j++) result[i][j] = zipped[j][i];
	}
	return result;
}
__name(unzip$1, "unzip");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/windowed.mjs
/**
* Creates an array of sub-arrays (windows) from the input array, each of the specified size.
* The windows can overlap depending on the step size provided.
*
* By default, only full windows are included in the result, and any leftover elements that can't form a full window are ignored.
*
* If the `partialWindows` option is set to true in the options object, the function will also include partial windows at the end of the result.
* Partial windows are smaller sub-arrays created when there aren't enough elements left in the input array to form a full window.
*
* @template T
* @param arr - The input array to create windows from.
* @param size - The size of each window. Must be a positive integer.
* @param [step=1] - The step size between the start of each window. Must be a positive integer.
* @param [options={}] - Options object to configure the behavior of the function.
* @param [options.partialWindows=false] - Whether to include partial windows at the end of the array.
* @returns An array of windows (sub-arrays) created from the input array.
* @throws {Error} If the size or step is not a positive integer.
*
* @example
* windowed([1, 2, 3, 4], 2);
* // => [[1, 2], [2, 3], [3, 4]]
*
* @example
* windowed([1, 2, 3, 4, 5, 6], 3, 2);
* // => [[1, 2, 3], [3, 4, 5]]
*
* @example
* windowed([1, 2, 3, 4, 5, 6], 3, 2, { partialWindows: true });
* // => [[1, 2, 3], [3, 4, 5], [5, 6]]
*/
function windowed(arr, size, step = 1, { partialWindows = false } = {}) {
	if (size <= 0 || !Number.isInteger(size)) throw new Error("Size must be a positive integer.");
	if (step <= 0 || !Number.isInteger(step)) throw new Error("Step must be a positive integer.");
	const result = [];
	const end = partialWindows ? arr.length : arr.length - size + 1;
	for (let i = 0; i < end; i += step) result.push(arr.slice(i, i + size));
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/zip.mjs
/**
* Combines multiple arrays into a single array of tuples.
*
* This function takes multiple arrays and returns a new array where each element is a tuple
* containing the corresponding elements from the input arrays. If the input arrays are of
* different lengths, the resulting array will have the length of the longest input array,
* with undefined values for missing elements.
*
* @template T
* @param arrs - The arrays to zip together.
* @returns A new array of tuples containing the corresponding elements from the input arrays.
*
* @example
* const arr1 = [1, 2, 3];
* const arr2 = ['a', 'b', 'c'];
* const arr3 = [true, false];
* const result = zip(arr1, arr2, arr3);
* // result will be [[1, 'a', true], [2, 'b', false], [3, 'c', undefined]]
*/
function zip$1(...arrs) {
	let rowCount = 0;
	for (let i = 0; i < arrs.length; i++) if (arrs[i].length > rowCount) rowCount = arrs[i].length;
	const columnCount = arrs.length;
	const result = Array(rowCount);
	for (let i = 0; i < rowCount; ++i) {
		const row = Array(columnCount);
		for (let j = 0; j < columnCount; ++j) row[j] = arrs[j][i];
		result[i] = row;
	}
	return result;
}
__name(zip$1, "zip");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/function/after.mjs
/**
* Creates a function that only executes starting from the `n`-th call.
* The provided function will be invoked starting from the `n`-th call.
*
* This is particularly useful for scenarios involving events or asynchronous operations
* where an action should occur only after a certain number of invocations.
*
* @template F - The type of the function to be invoked.
* @param n - The number of calls required for `func` to execute.
* @param func - The function to be invoked.
* @returns A new function that:
* - Tracks the number of calls.
* - Invokes `func` starting from the `n`-th call.
* - Returns `undefined` if fewer than `n` calls have been made.
* @throws {Error} - Throws an error if `n` is negative.
* @example
*
* const afterFn = after(3, () => {
*  console.log("called")
* });
*
* // Will not log anything.
* afterFn()
* // Will not log anything.
* afterFn()
* // Will log 'called'.
* afterFn()
*/
function after$1(n, func) {
	if (!Number.isInteger(n) || n < 0) throw new Error(`n must be a non-negative integer.`);
	let counter = 0;
	return (...args) => {
		if (++counter >= n) return func(...args);
	};
}
__name(after$1, "after");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/function/ary.mjs
/**
* Creates a function that invokes func, with up to n arguments, ignoring any additional arguments.
*
* @template F - The type of the function.
* @param func - The function to cap arguments for.
* @param n - The arity cap.
* @returns Returns the new capped function.
*
* @example
* function fn(a: number, b: number, c: number) {
*   return Array.from(arguments);
* }
*
* ary(fn, 0)(1, 2, 3) // []
* ary(fn, 1)(1, 2, 3) // [1]
* ary(fn, 2)(1, 2, 3) // [1, 2]
* ary(fn, 3)(1, 2, 3) // [1, 2, 3]
*/
function ary$1(func, n) {
	return function(...args) {
		return func.apply(this, args.slice(0, n));
	};
}
__name(ary$1, "ary");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/function/flow.mjs
/**
* Creates a new function that executes the given functions in sequence. The return value of the previous function is passed as an argument to the next function.
*
* The `this` context of the returned function is also passed to the functions provided as parameters.
*
* @param funcs The functions to invoke.
* @returns Returns the new composite function.
*
* @example
* const add = (x: number, y: number) => x + y;
* const square = (n: number) => n * n;
*
* const combined = flow(add, square);
* console.log(combined(1, 2)); // 9
*/
function flow$1(...funcs) {
	return function(...args) {
		let result = funcs.length ? funcs[0].apply(this, args) : args[0];
		for (let i = 1; i < funcs.length; i++) result = funcs[i].call(this, result);
		return result;
	};
}
__name(flow$1, "flow");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/function/flowRight.mjs
/**
* Creates a new function that executes the given functions in sequence from right to left. The return value of the previous function is passed as an argument to the next function.
*
* The `this` context of the returned function is also passed to the functions provided as parameters.
*
* This method is like `flow` except that it creates a function that invokes the given functions from right to left.
*
* @param funcs The functions to invoke.
* @returns Returns the new composite function.
*
* @example
* const add = (x: number, y: number) => x + y;
* const square = (n: number) => n * n;
*
* const combined = flowRight(square, add);
* console.log(combined(1, 2)); // 9
*/
function flowRight$1(...funcs) {
	return flow$1(...funcs.reverse());
}
__name(flowRight$1, "flowRight");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/function/negate.mjs
/**
* Creates a function that negates the result of the predicate function.
*
* @template F - The type of the function to negate.
* @param func - The function to negate.
* @returns The new negated function, which negates the boolean result of `func`.
*
* @example
* const array = [1, 2, 3, 4, 5, 6];
* const isEven = (n: number) => n % 2 === 0;
* const result = array.filter(negate(isEven));
* // result will be [1, 3, 5]
*/
function negate$1(func) {
	return ((...args) => !func(...args));
}
__name(negate$1, "negate");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/function/partial.mjs
/**
* Creates a function that invokes `func` with `partialArgs` prepended to the arguments it receives. This method is like `bind` except it does not alter the `this` binding.
*
* The partial.placeholder value, which defaults to a `symbol`, may be used as a placeholder for partially applied arguments.
*
* Note: This method doesn't set the `length` property of partially applied functions.
*
* @template F The type of the function to partially apply.
* @param func The function to partially apply arguments to.
* @param partialArgs The arguments to be partially applied.
* @returns Returns the new partially applied function.
*
* @example
* function greet(greeting, name) {
*   return greeting + ' ' + name;
* }
*
* const sayHelloTo = partial(greet, 'hello');
* sayHelloTo('fred');
* // => 'hello fred'
*
* // Partially applied with placeholders.
* const greetFred = partial(greet, partial.placeholder, 'fred');
* greetFred('hi');
* // => 'hi fred'
*/
function partial$1(func, ...partialArgs) {
	return partialImpl(func, placeholderSymbol$1, ...partialArgs);
}
__name(partial$1, "partial");
function partialImpl(func, placeholder, ...partialArgs) {
	const partialed = function(...providedArgs) {
		let providedArgsIndex = 0;
		const substitutedArgs = partialArgs.slice().map((arg) => arg === placeholder ? providedArgs[providedArgsIndex++] : arg);
		const remainingArgs = providedArgs.slice(providedArgsIndex);
		return func.apply(this, substitutedArgs.concat(remainingArgs));
	};
	if (func.prototype) partialed.prototype = Object.create(func.prototype);
	return partialed;
}
var placeholderSymbol$1 = Symbol("partial.placeholder");
partial$1.placeholder = placeholderSymbol$1;
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/function/partialRight.mjs
/**
* This method is like `partial` except that partially applied arguments are appended to the arguments it receives.
*
* The partialRight.placeholder value, which defaults to a `symbol`, may be used as a placeholder for partially applied arguments.
*
* Note: This method doesn't set the `length` property of partially applied functions.
*
* @template F The type of the function to partially apply.
* @param func The function to partially apply arguments to.
* @param partialArgs The arguments to be partially applied.
* @returns Returns the new partially applied function.
*
* @example
* function greet(greeting, name) {
*   return greeting + ' ' + name;
* }
*
* const greetFred = partialRight(greet, 'fred');
* greetFred('hi');
* // => 'hi fred'
*
* // Partially applied with placeholders.
* const sayHelloTo = partialRight(greet, 'hello', partialRight.placeholder);
* sayHelloTo('fred');
* // => 'hello fred'
*/
function partialRight$1(func, ...partialArgs) {
	return partialRightImpl(func, placeholderSymbol, ...partialArgs);
}
__name(partialRight$1, "partialRight");
function partialRightImpl(func, placeholder, ...partialArgs) {
	const partialedRight = function(...providedArgs) {
		const placeholderLength = partialArgs.filter((arg) => arg === placeholder).length;
		const rangeLength = Math.max(providedArgs.length - placeholderLength, 0);
		const remainingArgs = providedArgs.slice(0, rangeLength);
		let providedArgsIndex = rangeLength;
		const substitutedArgs = partialArgs.slice().map((arg) => arg === placeholder ? providedArgs[providedArgsIndex++] : arg);
		return func.apply(this, remainingArgs.concat(substitutedArgs));
	};
	if (func.prototype) partialedRight.prototype = Object.create(func.prototype);
	return partialedRight;
}
var placeholderSymbol = Symbol("partialRight.placeholder");
partialRight$1.placeholder = placeholderSymbol;
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/function/rest.mjs
/**
* Creates a function that transforms the arguments of the provided function `func`.
* The transformed arguments are passed to `func` such that the arguments starting from a specified index
* are grouped into an array, while the previous arguments are passed as individual elements.
*
* @template F - The type of the function being transformed.
* @param func - The function whose arguments are to be transformed.
* @param [startIndex=func.length - 1] - The index from which to start grouping the remaining arguments into an array.
*                                            Defaults to `func.length - 1`, grouping all arguments after the last parameter.
* @returns A new function that, when called, returns the result of calling `func` with the transformed arguments.
*
* The transformed arguments are:
* - The first `start` arguments as individual elements.
* - The remaining arguments from index `start` onward grouped into an array.
* @example
* function fn(a, b, c) {
*   return [a, b, c];
* }
*
* // Using default start index (func.length - 1, which is 2 in this case)
* const transformedFn = rest(fn);
* console.log(transformedFn(1, 2, 3, 4)); // [1, 2, [3, 4]]
*
* // Using start index 1
* const transformedFnWithStart = rest(fn, 1);
* console.log(transformedFnWithStart(1, 2, 3, 4)); // [1, [2, 3, 4]]
*
* // With fewer arguments than the start index
* console.log(transformedFn(1)); // [1, undefined, []]
*/
function rest$1(func, startIndex = func.length - 1) {
	return function(...args) {
		const rest = args.slice(startIndex);
		const params = args.slice(0, startIndex);
		while (params.length < startIndex) params.push(void 0);
		return func.apply(this, [...params, rest]);
	};
}
__name(rest$1, "rest");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/math/inRange.mjs
/**
* Checks if the value is within a specified range.
*
* @param value The value to check.
* @param minimum The lower bound of the range (inclusive).
* @param maximum The upper bound of the range (exclusive).
* @returns `true` if the value is within the specified range, otherwise `false`.
* @throws {Error} Throws an error if the `minimum` is greater or equal than the `maximum`.
*
* @example
* const result1 = inRange(3, 5); // result1 will be true.
* const result2 = inRange(1, 2, 5); // result2 will be false.
* const result3 = inRange(1, 5, 2); // If the minimum is greater or equal than the maximum, an error is thrown.
*/
function inRange$1(value, minimum, maximum) {
	if (maximum == null) {
		maximum = minimum;
		minimum = 0;
	}
	if (minimum >= maximum) throw new Error("The maximum value must be greater than the minimum value.");
	return minimum <= value && value < maximum;
}
__name(inRange$1, "inRange");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/math/meanBy.mjs
/**
* Calculates the average of an array of numbers when applying
* the `getValue` function to each element.
*
* If the array is empty, this function returns `NaN`.
*
* @template T - The type of elements in the array.
* @param items An array to calculate the average.
* @param getValue A function that selects a numeric value from each element.
* @returns The average of all the numbers as determined by the `getValue` function.
*
* @example
* meanBy([{ a: 1 }, { a: 2 }, { a: 3 }], x => x.a); // Returns: 2
* meanBy([], x => x.a); // Returns: NaN
*/
function meanBy$1(items, getValue) {
	return sumBy$1(items, (item) => getValue(item)) / items.length;
}
__name(meanBy$1, "meanBy");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/object/findKey.mjs
/**
* Finds the key of the first element in the object that satisfies the provided testing function.
*
* @param obj - The object to search.
* @param predicate - The function to execute on each value in the object. It takes three arguments:
*   - value: The current value being processed in the object.
*   - key: The key of the current value being processed in the object.
*   - obj: The object that findKey was called upon.
* @returns The key of the first element in the object that passes the test, or undefined if no element passes.
*
* @example
* const users = {
*   'barney':  { 'age': 36, 'active': true },
*   'fred':    { 'age': 40, 'active': false },
*   'pebbles': { 'age': 1,  'active': true }
* };
* findKey(users, function(o) { return o.age < 40; }); => 'barney'
*/
function findKey$1(obj, predicate) {
	return Object.keys(obj).find((key) => predicate(obj[key], key, obj));
}
__name(findKey$1, "findKey");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/object/invert.mjs
/**
* Inverts the keys and values of an object. The keys of the input object become the values of the output object and vice versa.
*
* This function takes an object and creates a new object by inverting its keys and values. If the input object has duplicate values,
* the key of the last occurrence will be used as the value for the new key in the output object. It effectively creates a reverse mapping
* of the input object's key-value pairs.
*
* @template K - Type of the keys in the input object (string, number, symbol)
* @template V - Type of the values in the input object (string, number, symbol)
* @param obj - The input object whose keys and values are to be inverted
* @returns A new object with keys and values inverted
*
* @example
* invert({ a: 1, b: 2, c: 3 }); // { 1: 'a', 2: 'b', 3: 'c' }
* invert({ 1: 'a', 2: 'b', 3: 'c' }); // { a: '1', b: '2', c: '3' }
* invert({ a: 1, 2: 'b', c: 3, 4: 'd' }); // { 1: 'a', b: '2', 3: 'c', d: '4' }
* invert({ a: Symbol('sym1'), b: Symbol('sym2') }); // { [Symbol('sym1')]: 'a', [Symbol('sym2')]: 'b' }
*/
function invert$1(obj) {
	const result = {};
	const keys = Object.keys(obj);
	for (let i = 0; i < keys.length; i++) {
		const key = keys[i];
		const value = obj[key];
		result[value] = key;
	}
	return result;
}
__name(invert$1, "invert");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/object/omit.mjs
/**
* Creates a new object with specified keys omitted.
*
* This function takes an object and an array of keys, and returns a new object that
* excludes the properties corresponding to the specified keys.
*
* @template T - The type of object.
* @template K - The type of keys in object.
* @param obj - The object to omit keys from.
* @param keys - An array of keys to be omitted from the object.
* @returns A new object with the specified keys omitted.
*
* @example
* const obj = { a: 1, b: 2, c: 3 };
* const result = omit(obj, ['b', 'c']);
* // result will be { a: 1 }
*/
function omit$1(obj, keys) {
	const result = { ...obj };
	for (let i = 0; i < keys.length; i++) {
		const key = keys[i];
		delete result[key];
	}
	return result;
}
__name(omit$1, "omit");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/string/capitalize.mjs
/**
* Converts the first character of string to upper case and the remaining to lower case.
*
* @template T - Literal type of the string.
* @param str - The string to be converted to uppercase.
* @returns The capitalized string.
*
* @example
* const result = capitalize('fred') // returns 'Fred'
* const result2 = capitalize('FRED') // returns 'Fred'
*/
function capitalize$1(str) {
	return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
}
__name(capitalize$1, "capitalize");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/string/words.mjs
/**
* Regular expression pattern to split strings into words for various case conversions
*
* This pattern matches sequences of characters in a string, considering the following cases:
* - Sequences of two or more uppercase letters followed by an uppercase letter and lowercase letters or digits (for acronyms)
* - Sequences of one uppercase letter optionally followed by lowercase letters and digits
* - Single uppercase letters
* - Sequences of digits
* - Emojis and other Unicode characters
*
* The resulting match can be used to convert camelCase, snake_case, kebab-case, and other mixed formats into
* a consistent format like snake case. It also supports emojis and other Unicode characters.
*
* @example
* const matches = 'camelCaseHTTPRequest🚀'.match(CASE_SPLIT_PATTERN);
* // matches: ['camel', 'Case', 'HTTP', 'Request', '🚀']
*/
var CASE_SPLIT_PATTERN = /\p{Lu}?\p{Ll}+|[0-9]+|\p{Lu}+(?!\p{Ll})|\p{Emoji_Presentation}|\p{Extended_Pictographic}|\p{L}+/gu;
/**
* Splits `string` into an array of its words, treating spaces and punctuation marks as separators.
*
* @param str The string to inspect.
* @param [pattern] The pattern to match words.
* @returns Returns the words of `string`.
*
* @example
* words('fred, barney, & pebbles');
* // => ['fred', 'barney', 'pebbles']
*
* words('camelCaseHTTPRequest🚀');
* // => ['camel', 'Case', 'HTTP', 'Request', '🚀']
*
* words('Lunedì 18 Set')
* // => ['Lunedì', '18', 'Set']
*/
function words$1(str) {
	return Array.from(str.match(CASE_SPLIT_PATTERN) ?? []);
}
__name(words$1, "words");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/string/camelCase.mjs
/**
* Converts a string to camel case.
*
* Camel case is the naming convention in which the first word is written in lowercase and
* each subsequent word begins with a capital letter, concatenated without any separator characters.
*
* @param str - The string that is to be changed to camel case.
* @returns The converted string to camel case.
*
* @example
* const convertedStr1 = camelCase('camelCase') // returns 'camelCase'
* const convertedStr2 = camelCase('some whitespace') // returns 'someWhitespace'
* const convertedStr3 = camelCase('hyphen-text') // returns 'hyphenText'
* const convertedStr4 = camelCase('HTTPRequest') // returns 'httpRequest'
* const convertedStr5 = camelCase('Keep unicode 😅') // returns 'keepUnicode😅'
*/
function camelCase$1(str) {
	const words$1$3 = words$1(str);
	if (words$1$3.length === 0) return "";
	const [first, ...rest] = words$1$3;
	return `${first.toLowerCase()}${rest.map((word) => capitalize$1(word)).join("")}`;
}
__name(camelCase$1, "camelCase");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isArray.mjs
/**
* Checks if the given value is an array.
*
* This function tests whether the provided value is an array or not.
* It returns `true` if the value is an array, and `false` otherwise.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to an array.
*
* @param value - The value to test if it is an array.
* @returns `true` if the value is an array, `false` otherwise.
*
* @example
* const value1 = [1, 2, 3];
* const value2 = 'abc';
* const value3 = () => {};
*
* console.log(isArray(value1)); // true
* console.log(isArray(value2)); // false
* console.log(isArray(value3)); // false
*/
function isArray(value) {
	return Array.isArray(value);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/string/snakeCase.mjs
/**
* Converts a string to snake case.
*
* Snake case is the naming convention in which each word is written in lowercase and separated by an underscore (_) character.
*
* @param str - The string that is to be changed to snake case.
* @returns The converted string to snake case.
*
* @example
* const convertedStr1 = snakeCase('camelCase') // returns 'camel_case'
* const convertedStr2 = snakeCase('some whitespace') // returns 'some_whitespace'
* const convertedStr3 = snakeCase('hyphen-text') // returns 'hyphen_text'
* const convertedStr4 = snakeCase('HTTPRequest') // returns 'http_request'
*/
function snakeCase$1(str) {
	return words$1(str).map((word) => word.toLowerCase()).join("_");
}
__name(snakeCase$1, "snakeCase");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/predicate/isArrayBuffer.mjs
/**
* Checks if a given value is `ArrayBuffer`.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to `ArrayBuffer`.
*
* @param value The value to check if it is a `ArrayBuffer`.
* @returns Returns `true` if `value` is a `ArrayBuffer`, else `false`.
*
* @example
* const value1 = new ArrayBuffer();
* const value2 = new Array();
* const value3 = new Map();
*
* console.log(isArrayBuffer(value1)); // true
* console.log(isArrayBuffer(value2)); // false
* console.log(isArrayBuffer(value3)); // false
*/
function isArrayBuffer$1(value) {
	return value instanceof ArrayBuffer;
}
__name(isArrayBuffer$1, "isArrayBuffer");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/predicate/isDate.mjs
/**
* Checks if `value` is a Date object.
*
* @param value The value to check.
* @returns Returns `true` if `value` is a Date object, `false` otherwise.
*
* @example
* const value1 = new Date();
* const value2 = '2024-01-01';
*
* console.log(isDate(value1)); // true
* console.log(isDate(value2)); // false
*/
function isDate$1(value) {
	return value instanceof Date;
}
__name(isDate$1, "isDate");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/predicate/isFunction.mjs
/**
* Checks if `value` is a function.
*
* @param value The value to check.
* @returns Returns `true` if `value` is a function, else `false`.
*
* @example
* isFunction(Array.prototype.slice); // true
* isFunction(async function () {}); // true
* isFunction(function* () {}); // true
* isFunction(Proxy); // true
* isFunction(Int8Array); // true
*/
function isFunction$1(value) {
	return typeof value === "function";
}
__name(isFunction$1, "isFunction");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/predicate/isMap.mjs
/**
* Checks if a given value is `Map`.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to `Map`.
*
* @param value The value to check if it is a `Map`.
* @returns Returns `true` if `value` is a `Map`, else `false`.
*
* @example
* const value1 = new Map();
* const value2 = new Set();
* const value3 = new WeakMap();
*
* console.log(isMap(value1)); // true
* console.log(isMap(value2)); // false
* console.log(isMap(value3)); // false
*/
function isMap$1(value) {
	return value instanceof Map;
}
__name(isMap$1, "isMap");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/predicate/isNil.mjs
/**
* Checks if a given value is null or undefined.
*
* This function tests whether the provided value is either `null` or `undefined`.
* It returns `true` if the value is `null` or `undefined`, and `false` otherwise.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to `null` or `undefined`.
*
* @param x - The value to test for null or undefined.
* @returns `true` if the value is null or undefined, `false` otherwise.
*
* @example
* const value1 = null;
* const value2 = undefined;
* const value3 = 42;
* const result1 = isNil(value1); // true
* const result2 = isNil(value2); // true
* const result3 = isNil(value3); // false
*/
function isNil$1(x) {
	return x == null;
}
__name(isNil$1, "isNil");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/predicate/isNull.mjs
/**
* Checks if the given value is null.
*
* This function tests whether the provided value is strictly equal to `null`.
* It returns `true` if the value is `null`, and `false` otherwise.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to `null`.
*
* @param x - The value to test if it is null.
* @returns True if the value is null, false otherwise.
*
* @example
* const value1 = null;
* const value2 = undefined;
* const value3 = 42;
*
* console.log(isNull(value1)); // true
* console.log(isNull(value2)); // false
* console.log(isNull(value3)); // false
*/
function isNull$1(x) {
	return x === null;
}
__name(isNull$1, "isNull");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/predicate/isRegExp.mjs
/**
* Checks if `value` is a RegExp.
*
* @param value The value to check.
* @returns Returns `true` if `value` is a RegExp, `false` otherwise.
*
* @example
* const value1 = /abc/;
* const value2 = '/abc/';
*
* console.log(isRegExp(value1)); // true
* console.log(isRegExp(value2)); // false
*/
function isRegExp$1(value) {
	return value instanceof RegExp;
}
__name(isRegExp$1, "isRegExp");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/predicate/isSet.mjs
/**
* Checks if a given value is `Set`.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to `Set`.
*
* @param value The value to check if it is a `Set`.
* @returns Returns `true` if `value` is a `Set`, else `false`.
*
* @example
* const value1 = new Set();
* const value2 = new Map();
* const value3 = new WeakSet();
*
* console.log(isSet(value1)); // true
* console.log(isSet(value2)); // false
* console.log(isSet(value3)); // false
*/
function isSet$1(value) {
	return value instanceof Set;
}
__name(isSet$1, "isSet");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/predicate/isSymbol.mjs
/**
* Check whether a value is a symbol.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to `symbol`.
*
* @param value The value to check.
* @returns Returns `true` if `value` is a symbol, else `false`.
*
* @example
* import { isSymbol } from 'es-toolkit/predicate';
*
* isSymbol(Symbol('a')); // true
* isSymbol(Symbol.for('a')); // true
* isSymbol(Symbol.iterator); // true
*
* isSymbol(null); // false
* isSymbol(undefined); // false
* isSymbol('123'); // false
* isSymbol(false); // false
* isSymbol(123n); // false
* isSymbol({}); // false
* isSymbol([1, 2, 3]); // false
*/
function isSymbol(value) {
	return typeof value === "symbol";
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/predicate/isUndefined.mjs
/**
* Checks if the given value is undefined.
*
* This function tests whether the provided value is strictly equal to `undefined`.
* It returns `true` if the value is `undefined`, and `false` otherwise.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to `undefined`.
*
* @param x - The value to test if it is undefined.
* @returns true if the value is undefined, false otherwise.
*
* @example
* const value1 = undefined;
* const value2 = null;
* const value3 = 42;
*
* console.log(isUndefined(value1)); // true
* console.log(isUndefined(value2)); // false
* console.log(isUndefined(value3)); // false
*/
function isUndefined$1(x) {
	return x === void 0;
}
__name(isUndefined$1, "isUndefined");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/predicate/isWeakMap.mjs
/**
* Checks if the given value is a `WeakMap`.
*
* This function tests whether the provided value is an instance of `WeakMap`.
* It returns `true` if the value is a `WeakMap`, and `false` otherwise.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to `WeakMap`.
*
* @param value - The value to test if it is a `WeakMap`.
* @returns true if the value is a `WeakMap`, false otherwise.
*
* @example
* const value1 = new WeakMap();
* const value2 = new Map();
* const value3 = new Set();
*
* console.log(isWeakMap(value1)); // true
* console.log(isWeakMap(value2)); // false
* console.log(isWeakMap(value3)); // false
*/
function isWeakMap$1(value) {
	return value instanceof WeakMap;
}
__name(isWeakMap$1, "isWeakMap");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/predicate/isWeakSet.mjs
/**
* Checks if the given value is a `WeakSet`.
*
* This function tests whether the provided value is an instance of `WeakSet`.
* It returns `true` if the value is a `WeakSet`, and `false` otherwise.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to `WeakSet`.
*
* @param value - The value to test if it is a `WeakSet`.
* @returns true if the value is a `WeakSet`, false otherwise.
*
* @example
* const value1 = new WeakSet();
* const value2 = new Map();
* const value3 = new Set();
*
* console.log(isWeakSet(value1)); // true
* console.log(isWeakSet(value2)); // false
* console.log(isWeakSet(value3)); // false
*/
function isWeakSet$1(value) {
	return value instanceof WeakSet;
}
__name(isWeakSet$1, "isWeakSet");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/string/escape.mjs
var htmlEscapes = {
	"&": "&amp;",
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"'": "&#39;"
};
/**
* Converts the characters "&", "<", ">", '"', and "'" in `str` to their corresponding HTML entities.
* For example, "<" becomes "&lt;".
*
* @param str  The string to escape.
* @returns Returns the escaped string.
*
* @example
* escape('This is a <div> element.'); // returns 'This is a &lt;div&gt; element.'
* escape('This is a "quote"'); // returns 'This is a &quot;quote&quot;'
* escape("This is a 'quote'"); // returns 'This is a &#39;quote&#39;'
* escape('This is a & symbol'); // returns 'This is a &amp; symbol'
*/
function escape$1(str) {
	return str.replace(/[&<>"']/g, (match) => htmlEscapes[match]);
}
__name(escape$1, "escape");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/string/escapeRegExp.mjs
/**
* Escapes the RegExp special characters "^", "$", "\\", ".", "*", "+", "?", "(", ")", "[", "]", "{", "}", and "|" in `str`.
*
* @param str The string to escape.
* @returns Returns the escaped string.
*
* @example
* import { escapeRegExp } from 'es-toolkit/string';
*
* escapeRegExp('[es-toolkit](https://es-toolkit.dev/)'); // returns '\[es-toolkit\]\(https://es-toolkit\.dev/\)'
*/
function escapeRegExp$1(str) {
	return str.replace(/[\\^$.*+?()[\]{}|]/g, "\\$&");
}
__name(escapeRegExp$1, "escapeRegExp");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/string/kebabCase.mjs
/**
* Converts a string to kebab case.
*
* Kebab case is the naming convention in which each word is written in lowercase and separated by a dash (-) character.
*
* @param str - The string that is to be changed to kebab case.
* @returns The converted string to kebab case.
*
* @example
* const convertedStr1 = kebabCase('camelCase') // returns 'camel-case'
* const convertedStr2 = kebabCase('some whitespace') // returns 'some-whitespace'
* const convertedStr3 = kebabCase('hyphen-text') // returns 'hyphen-text'
* const convertedStr4 = kebabCase('HTTPRequest') // returns 'http-request'
*/
function kebabCase$1(str) {
	return words$1(str).map((word) => word.toLowerCase()).join("-");
}
__name(kebabCase$1, "kebabCase");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/string/lowerCase.mjs
/**
* Converts a string to lower case.
*
* Lower case is the naming convention in which each word is written in lowercase and separated by an space ( ) character.
*
* @param str - The string that is to be changed to lower case.
* @returns The converted string to lower case.
*
* @example
* const convertedStr1 = lowerCase('camelCase') // returns 'camel case'
* const convertedStr2 = lowerCase('some whitespace') // returns 'some whitespace'
* const convertedStr3 = lowerCase('hyphen-text') // returns 'hyphen text'
* const convertedStr4 = lowerCase('HTTPRequest') // returns 'http request'
*/
function lowerCase$1(str) {
	return words$1(str).map((word) => word.toLowerCase()).join(" ");
}
__name(lowerCase$1, "lowerCase");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/string/lowerFirst.mjs
/**
* Converts the first character of string to lower case.
*
* @param str - The string that is to be changed
* @returns The converted string.
*
* @example
* const convertedStr1 = lowerCase('fred') // returns 'fred'
* const convertedStr2 = lowerCase('Fred') // returns 'fred'
* const convertedStr3 = lowerCase('FRED') // returns 'fRED'
*/
function lowerFirst$1(str) {
	return str.substring(0, 1).toLowerCase() + str.substring(1);
}
__name(lowerFirst$1, "lowerFirst");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/string/pad.mjs
/**
* Pads string on the left and right sides if it's shorter than length. Padding characters are truncated if they can't be evenly divided by length.
* If the length is less than or equal to the original string's length, or if the padding character is an empty string, the original string is returned unchanged.
*
* @param str - The string to pad.
* @param [length] - The length of the resulting string once padded.
* @param [chars] - The character(s) to use for padding.
* @returns The padded string, or the original string if padding is not required.
*
* @example
* const result1 = pad('abc', 8);         // result will be '  abc   '
* const result2 = pad('abc', 8, '_-');   // result will be '_-abc_-_'
* const result3 = pad('abc', 3);         // result will be 'abc'
* const result4 = pad('abc', 2);         // result will be 'abc'
*
*/
function pad$1(str, length, chars = " ") {
	return str.padStart(Math.floor((length - str.length) / 2) + str.length, chars).padEnd(length, chars);
}
__name(pad$1, "pad");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/string/trimStart.mjs
/**
* Removes leading whitespace or specified characters from a string.
*
* If `chars` is a string, it should be a single character. To trim a string with multiple characters,
* provide an array instead.
*
* @param str - The string from which leading characters will be trimmed.
* @param chars - The character(s) to remove from the start of the string.
* @returns The resulting string after the specified leading character has been removed.
*
* @example
* const trimmedStr1 = trimStart('---hello', '-') // returns 'hello'
* const trimmedStr2 = trimStart('000123', '0') // returns '123'
* const trimmedStr3 = trimStart('abcabcabc', 'a') // returns 'bcabcabc'
* const trimmedStr4 = trimStart('xxxtrimmed', 'x') // returns 'trimmed'
*/
function trimStart$1(str, chars) {
	if (chars === void 0) return str.trimStart();
	let startIndex = 0;
	switch (typeof chars) {
		case "string":
			if (chars.length !== 1) throw new Error(`The 'chars' parameter should be a single character string.`);
			while (startIndex < str.length && str[startIndex] === chars) startIndex++;
			break;
		case "object": while (startIndex < str.length && chars.includes(str[startIndex])) startIndex++;
	}
	return str.substring(startIndex);
}
__name(trimStart$1, "trimStart");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/string/trim.mjs
/**
* Removes leading and trailing whitespace or specified characters from a string.
*
* @param str - The string from which characters will be trimmed.
* @param chars - The character(s) to remove from the string. Can be a single character or an array of characters.
* @returns The resulting string after the specified characters have been removed.
*
* @example
* trim("  hello  "); // "hello"
* trim("--hello--", "-"); // "hello"
* trim("##hello##", ["#", "o"]); // "hell"
*/
function trim$1(str, chars) {
	if (chars === void 0) return str.trim();
	return trimStart$1(trimEnd$1(str, chars), chars);
}
__name(trim$1, "trim");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/string/unescape.mjs
var htmlUnescapes = {
	"&amp;": "&",
	"&lt;": "<",
	"&gt;": ">",
	"&quot;": "\"",
	"&#39;": "'"
};
/**
* Converts the HTML entities `&amp;`, `&lt;`, `&gt;`, `&quot;`, and `&#39;` in `str` to their corresponding characters.
* It is the inverse of `escape`.
*
* @param str The string to unescape.
* @returns Returns the unescaped string.
*
* @example
* unescape('This is a &lt;div&gt; element.'); // returns 'This is a <div> element.'
* unescape('This is a &quot;quote&quot;'); // returns 'This is a "quote"'
* unescape('This is a &#39;quote&#39;'); // returns 'This is a 'quote''
* unescape('This is a &amp; symbol'); // returns 'This is a & symbol'
*/
function unescape$1(str) {
	return str.replace(/&(?:amp|lt|gt|quot|#(0+)?39);/g, (match) => htmlUnescapes[match] || "'");
}
__name(unescape$1, "unescape");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/string/upperCase.mjs
/**
* Converts a string to upper case.
*
* Upper case is the naming convention in which each word is written in uppercase and separated by an space ( ) character.
*
* @param str - The string that is to be changed to upper case.
* @returns The converted string to upper case.
*
* @example
* const convertedStr1 = upperCase('camelCase') // returns 'CAMEL CASE'
* const convertedStr2 = upperCase('some whitespace') // returns 'SOME WHITESPACE'
* const convertedStr3 = upperCase('hyphen-text') // returns 'HYPHEN TEXT'
* const convertedStr4 = upperCase('HTTPRequest') // returns 'HTTP REQUEST'
*/
function upperCase$1(str) {
	const words$1$2 = words$1(str);
	let result = "";
	for (let i = 0; i < words$1$2.length; i++) {
		result += words$1$2[i].toUpperCase();
		if (i < words$1$2.length - 1) result += " ";
	}
	return result;
}
__name(upperCase$1, "upperCase");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/string/upperFirst.mjs
/**
* Converts the first character of string to upper case.
*
* @param str - The string that is to be changed
* @returns The converted string.
*
* @example
* const convertedStr1 = upperFirst('fred') // returns 'Fred'
* const convertedStr2 = upperFirst('Fred') // returns 'Fred'
* const convertedStr3 = upperFirst('FRED') // returns 'FRED'
*/
function upperFirst$1(str) {
	return str.substring(0, 1).toUpperCase() + str.substring(1);
}
__name(upperFirst$1, "upperFirst");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/castArray.mjs
/**
* Casts value as an array if it's not one.
*
* @template T The type of elements in the array.
* @param value The value to be cast to an array.
* @returns An array containing the input value if it wasn't an array, or the original array if it was.
*
* @example
* const arr1 = castArray(1);
* // Returns: [1]
*
* const arr2 = castArray([1]);
* // Returns: [1]
*
* const arr3 = castArray({'a': 1});
* // Returns: [{'a': 1}]
*
* const arr4 = castArray(null);
* // Returns: [null]
*
* const arr5 = castArray(undefined);
* // Returns: [undefined]
*
* const arr6 = castArray();
* // Returns: []
*/
function castArray(value) {
	if (arguments.length === 0) return [];
	return Array.isArray(value) ? value : [value];
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/chunk.mjs
/**
* Splits an array into smaller arrays of a specified length.
*
* This function takes an input array and divides it into multiple smaller arrays,
* each of a specified length. If the input array cannot be evenly divided,
* the final sub-array will contain the remaining elements.
*
* @template T The type of elements in the array.
* @param arr - The array to be chunked into smaller arrays.
* @param size - The size of each smaller array. Must be a positive integer.
* @returns A two-dimensional array where each sub-array has a maximum length of `size`.
*
* @example
* // Splits an array of numbers into sub-arrays of length 2
* chunk([1, 2, 3, 4, 5], 2);
* // Returns: [[1, 2], [3, 4], [5]]
*
* @example
* // Splits an array of strings into sub-arrays of length 3
* chunk(['a', 'b', 'c', 'd', 'e', 'f', 'g'], 3);
* // Returns: [['a', 'b', 'c'], ['d', 'e', 'f'], ['g']]
*/
function chunk(arr, size = 1) {
	size = Math.max(Math.floor(size), 0);
	if (size === 0 || !isArrayLike(arr) || Number.isNaN(size)) return [];
	const array = toArray$1(arr);
	if (!isFinite(size)) return [array];
	return chunk$1(array, size);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/compact.mjs
/**
* Removes falsey values (false, null, 0, 0n, '', undefined, NaN) from an array.
*
* @template T - The type of elements in the array.
* @param arr - The input array to remove falsey values.
* @returns A new array with all falsey values removed.
*
* @example
* compact([0, 0n, 1, false, 2, '', 3, null, undefined, 4, NaN, 5]);
* Returns: [1, 2, 3, 4, 5]
*/
function compact(arr) {
	if (!isArrayLike(arr)) return [];
	return compact$1(Array.from(arr));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/concat.mjs
/**
* Concatenates multiple arrays and values into a single array.
*
* @template T The type of elements in the array.
* @param values - The values and/or arrays to concatenate.
* @returns A new array containing all the input values.
*
* @example
* // Concatenate individual values
* concat(1, 2, 3);
* // returns [1, 2, 3]
*
* @example
* // Concatenate arrays of values
* concat([1, 2], [3, 4]);
* // returns [1, 2, 3, 4]
*
* @example
* // Concatenate a mix of individual values and arrays
* concat(1, [2, 3], 4);
* // returns [1, 2, 3, 4]
*
* @example
* // Concatenate nested arrays
* concat([1, [2, 3]], 4);
* // returns [1, [2, 3], 4]
*/
function concat(...values) {
	return flatten(values);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/countBy.mjs
function countBy(collection, iteratee$1) {
	if (collection == null) return {};
	const array = isArrayLike(collection) ? Array.from(collection) : Object.values(collection);
	const mapper = iteratee(iteratee$1 ?? void 0);
	const result = Object.create(null);
	for (let i = 0; i < array.length; i++) {
		const item = array[i];
		const key = mapper(item);
		result[key] = (result[key] ?? 0) + 1;
	}
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/difference.mjs
/**
* Computes the difference between an array and multiple arrays.
*
* @template T
* @param arr - The primary array from which to derive the difference. This is the main array
* from which elements will be compared and filtered.
* @param values - Multiple arrays containing elements to be excluded from the primary array.
* These arrays will be flattened into a single array, and each element in this array will be checked against the primary array.
* If a match is found, that element will be excluded from the result.
* @returns A new array containing the elements that are present in the primary array but not
* in the flattened array.
*
* @example
* const array1 = [1, 2, 3, 4, 5];
* const array2 = [2, 4];
* const array3 = [5, 6];
* const result = difference(array1, array2, array3);
* // result will be [1, 3] since 2, 4, and 5 are in the other arrays and are excluded from the result.
*
* @example
* const arrayLike1 = { 0: 1, 1: 2, 2: 3, length: 3 };
* const arrayLike2 = { 0: 2, 1: 4, length: 2 };
* const result = difference(arrayLike1, arrayLike2);
* // result will be [1, 3] since 2 is in both array-like objects and is excluded from the result.
*/
function difference(arr, ...values) {
	if (!isArrayLikeObject(arr)) return [];
	const arr1 = Array.from(arr);
	const arr2 = [];
	for (let i = 0; i < values.length; i++) {
		const value = values[i];
		if (isArrayLikeObject(value)) arr2.push(...Array.from(value));
	}
	return difference$1(arr1, arr2);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/last.mjs
/**
* Returns the last element of an array.
*
* This function takes an array and returns the last element of the array.
* If the array is empty, the function returns `undefined`.
*
* Unlike some implementations, this function is optimized for performance
* by directly accessing the last index of the array.
*
* @template T - The type of elements in the array.
* @param arr - The array from which to get the last element.
* @returns The last element of the array, or `undefined` if the array is empty.
*
* @example
* const arr = [1, 2, 3];
* const lastElement = last(arr);
* // lastElement will be 3
*
* const emptyArr: number[] = [];
* const noElement = last(emptyArr);
* // noElement will be undefined
*/
function last(array) {
	if (!isArrayLike(array)) return;
	return last$1(toArray$1(array));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/_internal/flattenArrayLike.mjs
function flattenArrayLike(values) {
	const result = [];
	for (let i = 0; i < values.length; i++) {
		const arrayLike = values[i];
		if (!isArrayLikeObject(arrayLike)) continue;
		for (let j = 0; j < arrayLike.length; j++) result.push(arrayLike[j]);
	}
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/differenceBy.mjs
/**
* Computes the difference between an array and multiple arrays using an iteratee function.
*
* @template T
* @param array - The primary array from which to derive the difference.
* @param values - Multiple arrays containing elements to be excluded from the primary array.
* @returns A new array containing the elements that are present in the primary array but not in the values arrays.
*/
function differenceBy(array, ..._values) {
	if (!isArrayLikeObject(array)) return [];
	const iteratee$1 = last(_values);
	const values = flattenArrayLike(_values);
	if (isArrayLikeObject(iteratee$1)) return difference$1(Array.from(array), values);
	return differenceBy$1(Array.from(array), values, iteratee(iteratee$1));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/differenceWith.mjs
/**
* Computes the difference between the primary array and one or more arrays using an optional comparator function.
*
* @template T
* @param array - The primary array to compare elements against.
* @param values - One or more arrays to compare with the primary array, and an optional comparator function to determine if two elements are considered equal.
* @returns A new array containing the elements from the primary array that do not match any elements in the provided arrays or those compared using the comparator function.
*
* @example
* // Example with a comparator function
* const array = [{ id: 1 }, { id: 2 }, { id: 3 }];
* const values1 = [{ id: 2 }];
* const values2 = [{ id: 3 }];
* const comparator = (a, b) => a.id === b.id;
*
* const result = differenceWith(array, values1, values2, comparator);
* // result will be [{ id: 1 }]
*
* @example
* // Example without a comparator function
* const array = [1, 2, 3];
* const values1 = [2];
* const values2 = [3];
*
* const result = differenceWith(array, values1, values2);
* // result will be [1]
*/
function differenceWith(array, ...values) {
	if (!isArrayLikeObject(array)) return [];
	const comparator = last(values);
	const flattenedValues = flattenArrayLike(values);
	if (typeof comparator === "function") return differenceWith$1(Array.from(array), flattenedValues, comparator);
	return difference$1(Array.from(array), flattenedValues);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/toFinite.mjs
/**
* Converts `value` to a finite number.
*
* @param value - The value to convert.
* @returns Returns the number.
*
* @example
* toFinite(3.2); // => 3.2
* toFinite(Number.MIN_VALUE); // => 5e-324
* toFinite(Infinity); // => 1.7976931348623157e+308
* toFinite('3.2'); // => 3.2
* toFinite(Symbol.iterator); // => 0
* toFinite(NaN); // => 0
*/
function toFinite(value) {
	if (!value) return value === 0 ? value : 0;
	value = toNumber(value);
	if (value === Infinity || value === -Infinity) return (value < 0 ? -1 : 1) * Number.MAX_VALUE;
	return value === value ? value : 0;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/toInteger.mjs
/**
* Converts `value` to an integer.
*
* This function first converts `value` to a finite number. If the result has any decimal places,
* they are removed by rounding down to the nearest whole number.
*
* @param value - The value to convert.
* @returns Returns the number.
*
* @example
* toInteger(3.2); // => 3
* toInteger(Number.MIN_VALUE); // => 0
* toInteger(Infinity); // => 1.7976931348623157e+308
* toInteger('3.2'); // => 3
* toInteger(Symbol.iterator); // => 0
* toInteger(NaN); // => 0
*/
function toInteger(value) {
	const finite = toFinite(value);
	const remainder = finite % 1;
	return remainder ? finite - remainder : finite;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/drop.mjs
function drop(array, itemsCount = 1, guard) {
	if (!isArrayLike(array)) return [];
	itemsCount = guard ? 1 : toInteger(itemsCount);
	return drop$1(toArray$1(array), itemsCount);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/dropRight.mjs
/**
* Removes a specified number of elements from the end of an array and returns the rest.
*
* This function takes an array and a number, and returns a new array with the specified number
* of elements removed from the end.
*
* @template T - The type of elements in the array.
* @param collection - The array from which to drop elements.
* @param itemsCount - The number of elements to drop from the end of the array.
* @param [guard] - Enables use as an iteratee for methods like `_.map`.
* @returns A new array with the specified number of elements removed from the end.
*
* @example
* const array = [1, 2, 3, 4, 5];
* const result = dropRight(array, 2);
* // result will be [1, 2, 3] since the last two elements are dropped.
*/
function dropRight(collection, itemsCount = 1, guard) {
	if (!isArrayLike(collection)) return [];
	itemsCount = guard ? 1 : toInteger(itemsCount);
	return dropRight$1(toArray$1(collection), itemsCount);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/dropRightWhile.mjs
/**
* Removes elements from the end of an array until the predicate returns false.
*
* This function iterates over an array and drops elements from the end until the provided
* predicate function returns false. It then returns a new array with the remaining elements.
*
* @template T - The type of elements in the array.
* @param array - The array from which to drop elements.
* @param predicate - A predicate function that determines
* whether to continue dropping elements. The function is called with each element, index, and array, and dropping
* continues as long as it returns true.
* @returns A new array with the elements remaining after the predicate returns false.
*
* @example
* const array = [3, 2, 1];
* const result = dropRightWhile(array, (item, index, arr) => index >= 1);
* // Returns: [3]
*/
function dropRightWhile(array, predicate = identity$1) {
	if (!isArrayLike(array)) return [];
	return dropRightWhileImpl(toArray$1(array), predicate);
}
function dropRightWhileImpl(arr, predicate) {
	switch (typeof predicate) {
		case "function": return dropRightWhile$1(arr, (item, index, arr) => Boolean(predicate(item, index, arr)));
		case "object": if (Array.isArray(predicate) && predicate.length === 2) {
			const key = predicate[0];
			const value = predicate[1];
			return dropRightWhile$1(arr, matchesProperty(key, value));
		} else return dropRightWhile$1(arr, matches(predicate));
		case "symbol":
		case "number":
		case "string": return dropRightWhile$1(arr, property(predicate));
	}
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/dropWhile.mjs
/**
* Creates a slice of array excluding elements dropped from the beginning.
* Elements are dropped until predicate returns falsey.
* The predicate is invoked with three arguments: (value, index, array).
*
* @template T - The type of elements in the array
* @param array - The array to query
* @param [predicate=identity] - The function invoked per iteration
* @returns Returns the slice of array
*
* @example
* dropWhile([1, 2, 3], n => n < 3)
* // => [3]
*
* dropWhile([{ a: 1, b: 2 }, { a: 1, b: 3 }], { a: 1 })
* // => []
*
* dropWhile([{ a: 1, b: 2 }, { a: 1, b: 3 }], ['a', 1])
* // => []
*
* dropWhile([{ a: 1, b: 2 }, { a: 1, b: 3 }], 'a')
* // => []
*/
function dropWhile(array, predicate = identity$1) {
	if (!isArrayLike(array)) return [];
	return dropWhileImpl(toArray$1(array), predicate);
}
function dropWhileImpl(arr, predicate) {
	switch (typeof predicate) {
		case "function": return dropWhile$1(arr, (item, index, arr) => Boolean(predicate(item, index, arr)));
		case "object": if (Array.isArray(predicate) && predicate.length === 2) {
			const key = predicate[0];
			const value = predicate[1];
			return dropWhile$1(arr, matchesProperty(key, value));
		} else return dropWhile$1(arr, matches(predicate));
		case "number":
		case "symbol":
		case "string": return dropWhile$1(arr, property(predicate));
	}
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/forEach.mjs
/**
* Iterates over each element of the object invoking the provided callback function for each property.
*
* @template T - The type of object.
* @param object - The object to iterate over.
* @param [callback] - The function invoked for each property.
* The callback function receives three arguments:
*  - 'value': The current property being processed in the object.
*  - 'key': The key of the current property being processed in the object.
*  - 'object': The object 'forEach' was called upon.
* @returns Returns the original object.
*
* @example
* forEach({'a': 1, 'b': 2 }, (value, key, object) => console.log(value, key));
* // Output:
* // 1 'a'
* // 2 'b'
*/
function forEach(collection, callback = identity$1) {
	if (!collection) return collection;
	const keys = isArrayLike(collection) || Array.isArray(collection) ? range$1(0, collection.length) : Object.keys(collection);
	for (let i = 0; i < keys.length; i++) {
		const key = keys[i];
		const value = collection[key];
		if (callback(value, key, collection) === false) break;
	}
	return collection;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/forEachRight.mjs
/**
* Iterates over elements of 'array' from right to left and invokes 'callback' for each element.
*
* @template T - The type of object.
* @param object - The object to iterate over.
* @param [callback] - The function invoked for each property.
* The callback function receives three arguments:
*  - 'value': The current property being processed in the object.
*  - 'key': The key of the current property being processed in the object.
*  - 'object': The object 'forEachRight' was called upon.
* @returns Returns the original object.
*
* @example
* forEachRight({'a': 1, 'b': 2 }, (value, key, object) => console.log(value, key));
* // Output:
* // 2 'b'
* // 1 'a'
*/
function forEachRight(collection, callback = identity$1) {
	if (!collection) return collection;
	const keys = isArrayLike(collection) ? range$1(0, collection.length) : Object.keys(collection);
	for (let i = keys.length - 1; i >= 0; i--) {
		const key = keys[i];
		const value = collection[key];
		if (callback(value, key, collection) === false) break;
	}
	return collection;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isString.mjs
/**
* Checks if a given value is string.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to `string`.
*
* @param value The value to check if it is string.
* @returns Returns `true` if `value` is a string, else `false`.
*
* @example
* const value1 = 'abc';
* const value2 = 123;
* const value3 = true;
*
* console.log(isString(value1)); // true
* console.log(isString(value2)); // false
* console.log(isString(value3)); // false
*/
function isString(value) {
	return typeof value === "string" || value instanceof String;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/fill.mjs
/**
* Fills elements of an array with a specified value from the start position up to, but not including, the end position.
*
* This function mutates the original array and replaces its elements with the provided value, starting from the specified
* start index up to the end index (non-inclusive). If the start or end indices are not provided, it defaults to filling the
* entire array.
*
* @template T, U
* @param array - The array to fill.
* @param value - The value to fill the array with.
* @param [start=0] - The start position. Defaults to 0.
* @param [end=arr.length] - The end position. Defaults to the array's length.
* @returns The array with the filled values.
*
* @example
* fill([1, 2, 3], 'a');
* // => ['a', 'a', 'a']
*
* fill(Array(3), 2);
* // => [2, 2, 2]
*
* fill([4, 6, 8, 10], '*', 1, 3);
* // => [4, '*', '*', 10]
*
* fill([1, 2, 3], '*', -2, -1);
* // => [1, '*', 3]
*/
function fill(array, value, start = 0, end = array ? array.length : 0) {
	if (!isArrayLike(array)) return [];
	if (isString(array)) return array;
	start = Math.floor(start);
	end = Math.floor(end);
	if (!start) start = 0;
	if (!end) end = 0;
	return fill$1(array, value, start, end);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/find.mjs
/**
* Finds the first item in an object that has a specific property, where the property name is provided as a PropertyKey.
*
* @template T
* @param source - The source array or object to search through.
* @param doesMatch - The criteria to match. It can be a function, a partial object, a key-value pair, or a property name.
* @param [fromIndex=0] - The index to start the search from, defaults to 0.
* @returns The first property value that has the specified property, or `undefined` if no match is found.
*
* @example
* // Using a property name
* const obj = { a: { id: 1, name: 'Alice' }, b: { id: 2, name: 'Bob' } };
* const result = find(obj, 'name');
* console.log(result); // { id: 1, name: 'Alice' }
*/
function find(source, _doesMatch = identity$1, fromIndex = 0) {
	if (!source) return;
	if (fromIndex < 0) fromIndex = Math.max(source.length + fromIndex, 0);
	const doesMatch = iteratee(_doesMatch);
	if (!Array.isArray(source)) {
		const keys = Object.keys(source);
		for (let i = fromIndex; i < keys.length; i++) {
			const key = keys[i];
			const value = source[key];
			if (doesMatch(value, key, source)) return value;
		}
		return;
	}
	return source.slice(fromIndex).find(doesMatch);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/identity.mjs
function identity(x) {
	return x;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/findIndex.mjs
/**
* Finds the index of the first item in an array that has a specific property, where the property name is provided as a PropertyKey.
*
* @template T
* @param arr - The array to search through.
* @param doesMatch - The criteria to match against the items in the array. This can be a function, a partial object, a key-value pair, or a property name.
* @param propertyToCheck - The property name to check for in the items of the array.
* @param [fromIndex=0] - The index to start the search from, defaults to 0.
* @returns The index of the first item that has the specified property, or `-1` if no match is found.
*
* @example
* // Using a property name
* const items = [{ id: 1, name: 'Alice' }, { id: 2, name: 'Bob' }];
* const result = findIndex(items, 'name');
* console.log(result); // 0
*/
function findIndex(arr, doesMatch = identity, fromIndex = 0) {
	if (!arr) return -1;
	if (fromIndex < 0) fromIndex = Math.max(arr.length + fromIndex, 0);
	const subArray = Array.from(arr).slice(fromIndex);
	let index = -1;
	switch (typeof doesMatch) {
		case "function":
			index = subArray.findIndex(doesMatch);
			break;
		case "object":
			if (Array.isArray(doesMatch) && doesMatch.length === 2) {
				const key = doesMatch[0];
				const value = doesMatch[1];
				index = subArray.findIndex(matchesProperty(key, value));
			} else index = subArray.findIndex(matches(doesMatch));
			break;
		case "number":
		case "symbol":
		case "string": index = subArray.findIndex(property(doesMatch));
	}
	return index === -1 ? -1 : index + fromIndex;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/findLast.mjs
/**
* Finds the last item in an object that has a specific property, where the property name is provided as a PropertyKey.
*
* @template T
* @param source - The source array or object to search through.
* @param doesMatch - The criteria to match. It can be a function, a partial object, a key-value pair, or a property name.
* @param [fromIndex] - The index to start the search from, defaults to source.length-1 for arrays or Object.keys(source).length-1 for objects.
* @returns The last property value that has the specified property, or `undefined` if no match is found.
*
* @example
* // Using a property name
* const obj = { a: { id: 1, name: 'Alice' }, b: { id: 2 }, c: { id: 3, name: 'Bob' } };
* const result = findLast(obj, 'name');
* console.log(result); // { id: 3, name: 'Bob' }
*/
function findLast(source, _doesMatch = identity$1, fromIndex) {
	if (!source) return;
	const length = Array.isArray(source) ? source.length : Object.keys(source).length;
	fromIndex = toInteger(fromIndex ?? length - 1);
	if (fromIndex < 0) fromIndex = Math.max(length + fromIndex, 0);
	else fromIndex = Math.min(fromIndex, length - 1);
	const doesMatch = iteratee(_doesMatch);
	if (!Array.isArray(source)) {
		const keys = Object.keys(source);
		for (let i = fromIndex; i >= 0; i--) {
			const key = keys[i];
			const value = source[key];
			if (doesMatch(value, key, source)) return value;
		}
		return;
	}
	return source.slice(0, fromIndex + 1).findLast(doesMatch);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/findLastIndex.mjs
/**
* Finds the index of the last element in the array that satisfies the predicate.
*
* @template T
* @param arr - The array to search through.
* @param doesMatch - The predicate function, partial object, property-value pair, or property name.
* @param [fromIndex=arr.length - 1] - The index to start the search from, defaults to the last index of the array.
* @returns The index of the last matching element, or -1 if not found.
*
* @example
* const items = [{ id: 1, name: 'Alice' }, { id: 2, name: 'Bob' }];
* findLastIndex(items, 'name');
* // => 1
*/
function findLastIndex(arr, doesMatch = identity$1, fromIndex = arr ? arr.length - 1 : 0) {
	if (!arr) return -1;
	if (fromIndex < 0) fromIndex = Math.max(arr.length + fromIndex, 0);
	else fromIndex = Math.min(fromIndex, arr.length - 1);
	const subArray = toArray$1(arr).slice(0, fromIndex + 1);
	switch (typeof doesMatch) {
		case "function": return subArray.findLastIndex(doesMatch);
		case "object": if (Array.isArray(doesMatch) && doesMatch.length === 2) {
			const key = doesMatch[0];
			const value = doesMatch[1];
			return subArray.findLastIndex(matchesProperty(key, value));
		} else return subArray.findLastIndex(matches(doesMatch));
		case "number":
		case "symbol":
		case "string": return subArray.findLastIndex(property(doesMatch));
	}
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/flattenDepth.mjs
/**
* Recursively flattens array up to depth times.
*
* @template T
* @param array - The array to flatten.
* @param [depth=1] - The maximum recursion depth.
* @returns Returns the new flattened array.
*
* @example
* const array = [1, [2, [3, [4]], 5]];
*
* flattenDepth(array, 1);
* // => [1, 2, [3, [4]], 5]
*
* flattenDepth(array, 2);
* // => [1, 2, 3, [4], 5]
*/
function flattenDepth(array, depth = 1) {
	return flatten$1(array, depth);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/flatMap.mjs
/**
* Creates a flattened array of values by running each element in collection through iteratee and flattening the mapped results.
*
* @template R
* @param collection - The collection to iterate over.
* @param [iteratee] - The function invoked per iteration.
* @returns Returns the new flattened array.
*
* @example
* flatMap([1, 2], n => [n, n * 2]);
* // => [1, 2, 2, 4]
*/
function flatMap(collection, iteratee) {
	if (isNil$1(collection)) return [];
	return flattenDepth(isNil$1(iteratee) ? map(collection) : map(collection, iteratee), 1);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/flatMapDeep.mjs
/**
* Creates a flattened array of values by running each element through iteratee and recursively flattening the mapped results.
*
* @template T, R
* @param collection - The array or object to iterate over.
* @param [iteratee] - The function that produces the new array elements.
* @returns A new array that has been deeply flattened.
*
* @example
* flatMapDeep([1, 2, 3], n => [[n, n]]);
* // => [1, 1, 2, 2, 3, 3]
*/
function flatMapDeep(collection, iteratee) {
	return flatMapDepth(collection, iteratee, Infinity);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/flattenDeep.mjs
/**
* Recursively flattens array.
*
* @template T
* @param array - The array to flatten.
* @returns Returns the new flattened array.
*
* @example
* flattenDeep([1, [2, [3, [4]], 5]]);
* // => [1, 2, 3, 4, 5]
*/
function flattenDeep(value) {
	return flattenDepth(value, Infinity);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/includes.mjs
/**
* Checks if a specified value exists within a given source, which can be an array, an object, or a string.
*
* The comparison uses SameValueZero to check for inclusion.
*
* @param source - The source to search in. It can be an array, an object, or a string.
* @param [target] - The value to search for in the source.
* @param [fromIndex=0] - The index to start searching from. If negative, it is treated as an offset from the end of the source.
* @returns `true` if the value is found in the source, `false` otherwise.
*
* @example
* includes([1, 2, 3], 2); // true
* includes({ a: 1, b: 'a', c: NaN }, 'a'); // true
* includes('hello world', 'world'); // true
* includes('hello world', 'test'); // false
*/
function includes(source, target, fromIndex, guard) {
	if (source == null) return false;
	if (guard || !fromIndex) fromIndex = 0;
	else fromIndex = toInteger(fromIndex);
	if (isString(source)) {
		if (fromIndex > source.length || target instanceof RegExp) return false;
		if (fromIndex < 0) fromIndex = Math.max(0, source.length + fromIndex);
		return source.includes(target, fromIndex);
	}
	if (Array.isArray(source)) return source.includes(target, fromIndex);
	const keys = Object.keys(source);
	if (fromIndex < 0) fromIndex = Math.max(0, keys.length + fromIndex);
	for (let i = fromIndex; i < keys.length; i++) if (isEqualsSameValueZero(Reflect.get(source, keys[i]), target)) return true;
	return false;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/indexOf.mjs
/**
* Finds the index of the first occurrence of a value in an array.
*
* This method is similar to `Array.prototype.indexOf`, but it also finds `NaN` values.
* It uses strict equality (`===`) to compare elements.
*
* @template T - The type of elements in the array.
* @param array - The array to search.
* @param searchElement - The value to search for.
* @param [fromIndex] - The index to start the search at.
* @returns The index (zero-based) of the first occurrence of the value in the array, or `-1` if the value is not found.
*
* @example
* const array = [1, 2, 3, NaN];
* indexOf(array, 3); // => 2
* indexOf(array, NaN); // => 3
*/
function indexOf(array, searchElement, fromIndex) {
	if (!isArrayLike(array)) return -1;
	if (Number.isNaN(searchElement)) {
		fromIndex = fromIndex ?? 0;
		if (fromIndex < 0) fromIndex = Math.max(0, array.length + fromIndex);
		for (let i = fromIndex; i < array.length; i++) if (Number.isNaN(array[i])) return i;
		return -1;
	}
	return Array.from(array).indexOf(searchElement, fromIndex);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/initial.mjs
/**
* Returns a new array containing all elements except the last one from the input array.
* If the input array is empty or has only one element, the function returns an empty array.
*
* @template T The type of elements in the array.
* @param arr - The input array.
* @returns A new array containing all but the last element of the input array.
*
* @example
* const arr = [1, 2, 3, 4];
* const result = initial(arr);
* // result will be [1, 2, 3]
*/
function initial(arr) {
	if (!isArrayLike(arr)) return [];
	return initial$1(Array.from(arr));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/intersection.mjs
/**
* Returns the intersection of multiple arrays.
*
* This function takes multiple arrays and returns a new array containing the elements that are
* present in all provided arrays. It effectively filters out any elements that are not found
* in every array.
*
* @template T - The type of elements in the arrays.
* @param arrays - The arrays to compare.
* @returns A new array containing the elements that are present in all arrays.
*
* @example
* const array1 = [1, 2, 3, 4, 5];
* const array2 = [3, 4, 5, 6, 7];
* const result = intersection(array1, array2);
* // result will be [3, 4, 5] since these elements are in both arrays.
*/
function intersection(...arrays) {
	if (arrays.length === 0) return [];
	if (!isArrayLikeObject(arrays[0])) return [];
	let result = uniq(Array.from(arrays[0]));
	for (let i = 1; i < arrays.length; i++) {
		const array = arrays[i];
		if (!isArrayLikeObject(array)) return [];
		result = intersection$1(result, Array.from(array));
	}
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/intersectionBy.mjs
/**
* Returns the intersection of multiple arrays after applying the iteratee function to their elements.
*
* This function takes multiple arrays and an optional iteratee function (or property key)
* to compare the elements after transforming them. It returns a new array containing the elements from
* the first array that are present in all subsequent arrays after applying the iteratee to each element.
* If no iteratee is provided, the identity function is used.
*
* If the first array is `null` or `undefined`, an empty array is returned.
*
* @template T
* @param array - The first array to compare.
* @param values - The arrays to compare, or the iteratee function.
* @returns A new array containing the elements from the first array that are present
*  in all subsequent arrays after applying the iteratee.
*
* @example
* const array1 = [{ x: 1 }, { x: 2 }, { x: 3 }];
* const array2 = [{ x: 2 }, { x: 3 }];
* const result = intersectionBy(array1, array2, 'x');
* // result will be [{ x: 2 }, { x: 3 }] since these elements have the same `x` property.
*
* @example
* const array1 = [1.1, 2.2, 3.3];
* const array2 = [2.3, 3.3];
* const result = intersectionBy(array1, array2, Math.floor);
* // result will be [2.3, 3.3] since it shares the same integer part when `Math.floor` is applied.
*/
function intersectionBy(array, ...values) {
	if (!isArrayLikeObject(array)) return [];
	const lastValue = last$1(values);
	if (lastValue === void 0) return Array.from(array);
	let result = uniq(Array.from(array));
	const count = isArrayLikeObject(lastValue) ? values.length : values.length - 1;
	for (let i = 0; i < count; ++i) {
		const value = values[i];
		if (!isArrayLikeObject(value)) return [];
		if (isArrayLikeObject(lastValue)) result = intersectionBy$1(result, Array.from(value), identity$1);
		else if (typeof lastValue === "function") result = intersectionBy$1(result, Array.from(value), (value) => lastValue(value));
		else if (typeof lastValue === "string") result = intersectionBy$1(result, Array.from(value), property(lastValue));
	}
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/intersectionWith.mjs
/**
* Returns the intersection of multiple arrays based on a custom equality function.
*
* @template T - The type of elements in the arrays
* @param firstArr - The first array to compare
* @param otherArrs - Additional arrays and optional equality function
* @returns Elements from first array that match in all arrays
*
* @example
* const arr1 = [{id: 1}, {id: 2}];
* const arr2 = [{id: 2}, {id: 3}];
* const result = intersectionWith(arr1, arr2, (a, b) => a.id === b.id);
* // result is [{id: 2}]
*/
function intersectionWith(firstArr, ...otherArrs) {
	if (firstArr == null) return [];
	const _comparator = last(otherArrs);
	let comparator = isEqualsSameValueZero;
	let uniq$1$1 = uniq$1;
	if (typeof _comparator === "function") {
		comparator = _comparator;
		uniq$1$1 = uniqPreserve0;
		otherArrs.pop();
	}
	let result = uniq$1$1(Array.from(firstArr));
	for (let i = 0; i < otherArrs.length; ++i) {
		const otherArr = otherArrs[i];
		if (otherArr == null) return [];
		result = intersectionWith$1(result, Array.from(otherArr), comparator);
	}
	return result;
}
/**
* This function is to preserve the sign of `-0`, which is a behavior in lodash.
*/
function uniqPreserve0(arr) {
	const result = [];
	const added = /* @__PURE__ */ new Set();
	for (let i = 0; i < arr.length; i++) {
		const item = arr[i];
		if (added.has(item)) continue;
		result.push(item);
		added.add(item);
	}
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/invokeMap.mjs
/**
* Invokes the method at path of each element in collection.
*
* @template T, R
* @param collection - The collection to iterate over.
* @param path - The path of the method to invoke or the method to invoke.
* @param args - The arguments to invoke each method with.
* @returns Returns the array of results.
*
* @example
* invokeMap([[5, 1, 7], [3, 2, 1]], 'sort');
* // => [[1, 5, 7], [1, 2, 3]]
*/
function invokeMap(collection, path, ...args) {
	if (isNil$1(collection)) return [];
	const values = isArrayLike(collection) ? Array.from(collection) : Object.values(collection);
	const result = [];
	for (let i = 0; i < values.length; i++) {
		const value = values[i];
		if (isFunction$1(path)) {
			result.push(path.apply(value, args));
			continue;
		}
		const method = get(value, path);
		let thisContext = value;
		if (Array.isArray(path)) {
			const pathExceptLast = path.slice(0, -1);
			if (pathExceptLast.length > 0) thisContext = get(value, pathExceptLast);
		} else if (typeof path === "string" && path.includes(".")) thisContext = get(value, path.split(".").slice(0, -1).join("."));
		result.push(method == null ? void 0 : method.apply(thisContext, args));
	}
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/join.mjs
/**
* Joins elements of an array into a string.
*
* @param array - The array to join.
* @param [separator=','] - The separator used to join the elements, default is common separator `,`.
* @returns Returns a string containing all elements of the array joined by the specified separator.
*
* @example
* const arr = ["a", "b", "c"];
* const result = join(arr, "~");
* console.log(result); // Output: "a~b~c"
*/
function join(array, separator) {
	if (!isArrayLike(array)) return "";
	return Array.from(array).join(separator);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/reduce.mjs
/**
* Reduces a collection to a single value using an iteratee function.
*
* @param collection - The collection to iterate over.
* @param iteratee - The function invoked per iteration or the key to reduce over.
* @param initialValue - The initial value.
* @returns Returns the accumulated value.
*
* @example
* // Using a reducer function
* const array = [1, 2, 3];
* reduce(array, (acc, value) => acc + value, 0); // => 6
*
* @example
* // Using a reducer function with initialValue
* const array = [1, 2, 3];
* reduce(array, (acc, value) => acc + value % 2 === 0, true); // => false
*
* @example
* // Using an object as the collection
* const obj = { a: 1, b: 2, c: 3 };
* reduce(obj, (acc, value) => acc + value, 0); // => 6
*/
function reduce(collection, iteratee = identity$1, accumulator) {
	const hasAccumulator = arguments.length >= 3;
	if (!collection) return accumulator;
	let keys;
	let startIndex = 0;
	if (isArrayLike(collection)) {
		keys = range$1(0, collection.length);
		if (!hasAccumulator && collection.length > 0) {
			accumulator = collection[0];
			startIndex += 1;
		}
	} else {
		keys = Object.keys(collection);
		if (!hasAccumulator && keys.length > 0) {
			accumulator = collection[keys[0]];
			startIndex += 1;
		}
	}
	for (let i = startIndex; i < keys.length; i++) {
		const key = keys[i];
		const value = collection[key];
		accumulator = iteratee(accumulator, value, key, collection);
	}
	return accumulator;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/keyBy.mjs
/**
* Maps each element of an array or an object based on a provided key-generating function.
*
* This function takes an array or object and a function that generates a key from each element or value. It returns
* an object where the keys are the generated keys and the values are the corresponding elements or values.
* If there are multiple elements or values generating the same key, the last one among them is used
* as the value.
*
* @param collection - The collection to iterate over.
* @param [iteratee] - The iteratee to transform keys.
*   - If a function is provided, it's invoked for each element in the collection.
*   - If a property name (string) is provided, that property of each element is used as the key.
*   - If a property-value pair (array) is provided, elements with matching property values are used.
*   - If a partial object is provided, elements with matching properties are used.
*   - If omitted, the identity function is used.
* @returns Returns the composed aggregate object.
*
* @example
* // Using an array of objects
* keyBy([{ id: 'a' }, { id: 'b' }], 'id');
* // => { a: { id: 'a' }, b: { id: 'b' } }
*
* @example
* // Using a function iteratee
* keyBy(['a', 'b', 'c'], val => val.toUpperCase());
* // => { A: 'a', B: 'b', C: 'c' }
*/
function keyBy(collection, iteratee$1) {
	if (!isArrayLike(collection) && !isObjectLike(collection)) return {};
	const keyFn = iteratee(iteratee$1 ?? identity$1);
	return reduce(collection, (result, value) => {
		const key = keyFn(value);
		result[key] = value;
		return result;
	}, {});
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/lastIndexOf.mjs
function lastIndexOf(array, searchElement, fromIndex) {
	if (!isArrayLike(array) || array.length === 0) return -1;
	const length = array.length;
	let index = fromIndex ?? length - 1;
	if (fromIndex != null) index = index < 0 ? Math.max(length + index, 0) : Math.min(index, length - 1);
	if (Number.isNaN(searchElement)) {
		for (let i = index; i >= 0; i--) if (Number.isNaN(array[i])) return i;
	}
	return Array.from(array).lastIndexOf(searchElement, index);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/nth.mjs
/**
* Gets the element at index `n` of `array`. If `n` is negative, the nth element from the end is returned.
*
* @param array - The array to query.
* @param [n=0] - The index of the element to return.
* @return {T | undefined} Returns the nth element of `array`.
*
* @example
* nth([1, 2, 3], 1); // => 2
* nth([1, 2, 3], -1); // => 3
*/
function nth(array, n = 0) {
	if (!isArrayLikeObject(array) || array.length === 0) return;
	n = toInteger(n);
	if (n < 0) n += array.length;
	return array[n];
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/_internal/compareValues.mjs
function getPriority(a) {
	if (typeof a === "symbol") return 1;
	if (a === null) return 2;
	if (a === void 0) return 3;
	if (a !== a) return 4;
	return 0;
}
var compareValues = (a, b, order) => {
	if (a !== b) {
		const aPriority = getPriority(a);
		const bPriority = getPriority(b);
		if (aPriority === bPriority && aPriority === 0) {
			if (a < b) return order === "desc" ? 1 : -1;
			if (a > b) return order === "desc" ? -1 : 1;
		}
		return order === "desc" ? bPriority - aPriority : aPriority - bPriority;
	}
	return 0;
};
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/_internal/isKey.mjs
/**  Matches any deep property path. (e.g. `a.b[0].c`)*/
var regexIsDeepProp = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/;
/**  Matches any word character (alphanumeric & underscore).*/
var regexIsPlainProp = /^\w*$/;
/**
* Checks if `value` is a property name and not a property path. (It's ok that the `value` is not in the keys of the `object`)
* @param {unknown} value The value to check.
* @param {unknown} object The object to query.
* @returns {boolean} Returns `true` if `value` is a property name, else `false`.
*
* @example
* isKey('a', { a: 1 });
* // => true
*
* isKey('a.b', { a: { b: 2 } });
* // => false
*/
function isKey(value, object) {
	if (Array.isArray(value)) return false;
	if (typeof value === "number" || typeof value === "boolean" || value == null || isSymbol$1(value)) return true;
	return typeof value === "string" && (regexIsPlainProp.test(value) || !regexIsDeepProp.test(value)) || object != null && Object.hasOwn(object, value);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/orderBy.mjs
/**
* Sorts an array of objects based on multiple properties and their corresponding order directions.
*
* This function takes an array of objects, an array of criteria to sort by, and an array of order directions.
* It returns the sorted array, ordering by each key according to its corresponding direction ('asc' for ascending or 'desc' for descending).
* If values for a key are equal, it moves to the next key to determine the order.
*
* @template T - The type of elements in the array.
* @param collection - The array of objects to be sorted.
* @param criteria - An array of criteria (property names or property paths or custom key functions) to sort by.
* @param orders - An array of order directions ('asc' for ascending or 'desc' for descending).
* @param [guard] Enables use as an iteratee for methods like `_.reduce`.
* @returns The sorted array.
*
* @example
* // Sort an array of objects by 'user' in ascending order and 'age' in descending order.
* const users = [
*   { user: 'fred', age: 48 },
*   { user: 'barney', age: 34 },
*   { user: 'fred', age: 40 },
*   { user: 'barney', age: 36 },
* ];
* const result = orderBy(users, ['user', (item) => item.age], ['asc', 'desc']);
* // result will be:
* // [
* //   { user: 'barney', age: 36 },
* //   { user: 'barney', age: 34 },
* //   { user: 'fred', age: 48 },
* //   { user: 'fred', age: 40 },
* // ]
*/
function orderBy(collection, criteria, orders, guard) {
	if (collection == null) return [];
	orders = guard ? void 0 : orders;
	if (!Array.isArray(collection)) collection = Object.values(collection);
	if (!Array.isArray(criteria)) criteria = criteria == null ? [null] : [criteria];
	if (criteria.length === 0) criteria = [null];
	if (!Array.isArray(orders)) orders = orders == null ? [] : [orders];
	orders = orders.map((order) => String(order));
	const getValueByNestedPath = (object, path) => {
		let target = object;
		for (let i = 0; i < path.length && target != null; ++i) target = target[path[i]];
		return target;
	};
	const getValueByCriterion = (criterion, object) => {
		if (object == null || criterion == null) return object;
		if (typeof criterion === "object" && "key" in criterion) {
			if (Object.hasOwn(object, criterion.key)) return object[criterion.key];
			return getValueByNestedPath(object, criterion.path);
		}
		if (typeof criterion === "function") return criterion(object);
		if (Array.isArray(criterion)) return getValueByNestedPath(object, criterion);
		if (typeof object === "object") return object[criterion];
		return object;
	};
	const preparedCriteria = criteria.map((criterion) => {
		if (Array.isArray(criterion) && criterion.length === 1) criterion = criterion[0];
		if (criterion == null || typeof criterion === "function" || Array.isArray(criterion) || isKey(criterion)) return criterion;
		return {
			key: criterion,
			path: toPath(criterion)
		};
	});
	return collection.map((item) => ({
		original: item,
		criteria: preparedCriteria.map((criterion) => getValueByCriterion(criterion, item))
	})).slice().sort((a, b) => {
		for (let i = 0; i < preparedCriteria.length; i++) {
			const comparedResult = compareValues(a.criteria[i], b.criteria[i], orders[i]);
			if (comparedResult !== 0) return comparedResult;
		}
		return 0;
	}).map((item) => item.original);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/partition.mjs
/**
* Creates an array of elements split into two groups, the first of which contains elements
* `predicate` returns truthy for, the second of which contains elements
* `predicate` returns falsy for. The predicate is invoked with one argument: (value).
*
* @template T
* @param source - The array or object to iterate over.
* @param [predicate=identity] - The function invoked per iteration.
* @returns Returns the array of grouped elements.
*
* @example
* partition([{ a: 1 }, { a: 2 }, { b: 1 }], 'a');
* // => [[{ a: 1 }, { a: 2 }], [{ b: 1 }]]
*
* partition([{ a: 1 }, { a: 2 }, { b: 1 }], { b: 1 });
* // => [[{ b: 1 }], [{ a: 1 }, { a: 2 }]]
*
* partition({ item1: { a: 0, b: true }, item2: { a: 1, b: true }, item3: { a: 2, b: false }}, { b: false })
* // => [[{ a: 2, b: false }], [{ a: 0, b: true }, { a: 1, b: true }]]
*
* partition([{ a: 1 }, { a: 2 }, { a: 3 }], ['a', 2]);
* // => [[{ a: 2 }], [{ a: 1 }, { a: 3 }]]
*/
function partition(source, predicate = identity$1) {
	if (!source) return [[], []];
	const collection = isArrayLike(source) ? source : Object.values(source);
	predicate = iteratee(predicate);
	const matched = [];
	const unmatched = [];
	for (let i = 0; i < collection.length; i++) {
		const value = collection[i];
		if (predicate(value)) matched.push(value);
		else unmatched.push(value);
	}
	return [matched, unmatched];
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/pull.mjs
/**
* Removes all specified values from an array.
*
* This function changes `arr` in place.
* If you want to remove values without modifying the original array, use `difference`.
*
* @template T
* @param arr - The array to modify.
* @param valuesToRemove - The values to remove from the array.
* @returns The modified array with the specified values removed.
*
* @example
* const numbers = [1, 2, 3, 4, 5, 2, 4];
* pull(numbers, [2, 4]);
* console.log(numbers); // [1, 3, 5]
*/
function pull(arr, ...valuesToRemove) {
	return pull$1(arr, valuesToRemove);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/pullAll.mjs
/**
* Removes all specified values from an array.
*
* This function changes `arr` in place.
* If you want to remove values without modifying the original array, use `difference`.
*
* @template T
* @param arr - The array to modify.
* @param valuesToRemove - The values to remove from the array.
* @returns The modified array with the specified values removed.
*
* @example
* const numbers = [1, 2, 3, 4, 5, 2, 4];
* pullAll(numbers, [2, 4]);
* console.log(numbers); // [1, 3, 5]
*/
function pullAll(arr, valuesToRemove = []) {
	return pull$1(arr, Array.from(valuesToRemove));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/pullAllBy.mjs
/**
* Removes all specified values from an array using an iteratee function.
*
* This function changes `arr` in place.
* If you want to remove values without modifying the original array, use `differenceBy`.
*
* @template T
* @param arr - The array to modify.
* @param valuesToRemove - The values to remove from the array.
* @param getValue - The key of the property to match against each element.
* @returns The modified array with the specified values removed.
*
* @example
* // Using a iteratee function
* const items = [{ value: 1 }, { value: 2 }, { value: 3 }, { value: 1 }];
* const result = pullAllBy(items, [{ value: 1 }, { value: 3 }], obj => obj.value);
* console.log(result); // [{ value: 2 }]
*
* // Using a property name
* const items = [{ value: 1 }, { value: 2 }, { value: 3 }, { value: 1 }];
* const result = pullAllBy(items, [{ value: 1 }, { value: 3 }], 'value');
* console.log(result); // [{ value: 2 }]
*/
function pullAllBy(arr, valuesToRemove, _getValue) {
	const getValue = iteratee(_getValue);
	const valuesSet = new Set(Array.from(valuesToRemove).map((x) => getValue(x)));
	let resultIndex = 0;
	for (let i = 0; i < arr.length; i++) {
		const value = getValue(arr[i]);
		if (valuesSet.has(value)) continue;
		if (!Object.hasOwn(arr, i)) {
			delete arr[resultIndex++];
			continue;
		}
		arr[resultIndex++] = arr[i];
	}
	arr.length = resultIndex;
	return arr;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/_internal/copyArray.mjs
/**
* Copies the values of `source` to `array`.
*
* @template T
* @param {ArrayLike<T>} source The array to copy values from.
* @param {T[]} [array=[]] The array to copy values to.
* @returns {T[]} Returns `array`.
*/
function copyArray(source, array) {
	const length = source.length;
	if (array == null) array = Array(length);
	for (let i = 0; i < length; i++) array[i] = source[i];
	return array;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/pullAllWith.mjs
/**
* Removes and returns elements from an array using a provided comparison function to determine which elements to remove.
*
* @template T
* @param array - The array to modify.
* @param values - The values to remove from the array.
* @param comparator - The function to compare elements of `array` with elements of `values`. Should return `true` if the two elements are considered equal.
* @returns The array with specified values removed.
*
* @example
* import pullAllWith from './pullAllWith';
* import isEqual from '../predicate';
*
* const array = [{ x: 1, y: 2 }, { x: 3, y: 4 }, { x: 5, y: 6 }];
* const valuesToRemove = [{ x: 3, y: 4 }];
*
* const result = pullAllWith(array, valuesToRemove, isEqual);
*
* console.log(result); // [{ x: 1, y: 2 }, { x: 5, y: 6 }]
* console.log(array);  // [{ x: 1, y: 2 }, { x: 5, y: 6 }]
*/
function pullAllWith(array, values, comparator) {
	if (array?.length == null || values?.length == null) return array;
	if (array === values) values = copyArray(values);
	let resultLength = 0;
	if (comparator == null) comparator = (a, b) => isEqualsSameValueZero(a, b);
	const valuesArray = Array.isArray(values) ? values : Array.from(values);
	const hasUndefined = valuesArray.includes(void 0);
	for (let i = 0; i < array.length; i++) {
		if (i in array) {
			if (!valuesArray.some((value) => comparator(array[i], value))) array[resultLength++] = array[i];
			continue;
		}
		if (!hasUndefined) delete array[resultLength++];
	}
	array.length = resultLength;
	return array;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/at.mjs
/**
* Returns an array of values corresponding to `paths` of `object`.
*
* @template T - The type of the object.
* @param object - The object to iterate over.
* @param [paths] - The property paths to pick.
* @returns Returns the picked values.
*
* @example
* ```js
* const object = { 'a': [{ 'b': { 'c': 3 } }, 4] };
*
* at(object, ['a[0].b.c', 'a[1]']);
* // => [3, 4]
* ```
*/
function at(object, ...paths) {
	if (paths.length === 0) return [];
	const allPaths = [];
	for (let i = 0; i < paths.length; i++) {
		const path = paths[i];
		if (!isArrayLike(path) || isString(path)) {
			allPaths.push(path);
			continue;
		}
		for (let j = 0; j < path.length; j++) allPaths.push(path[j]);
	}
	const result = [];
	for (let i = 0; i < allPaths.length; i++) result.push(get(object, allPaths[i]));
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/unset.mjs
/**
* Removes the property at the given path of the object.
*
* @param obj - The object to modify.
* @param path - The path of the property to unset.
* @returns Returns true if the property is deleted, else false.
*
* @example
* const obj = { a: { b: { c: 42 } } };
* unset(obj, 'a.b.c'); // true
* console.log(obj); // { a: { b: {} } }
*
* @example
* const obj = { a: { b: { c: 42 } } };
* unset(obj, ['a', 'b', 'c']); // true
* console.log(obj); // { a: { b: {} } }
*/
function unset(obj, path) {
	if (obj == null) return true;
	switch (typeof path) {
		case "symbol":
		case "number":
		case "object":
			if (Array.isArray(path)) return unsetWithPath(obj, path);
			if (typeof path === "number") path = toKey(path);
			else if (typeof path === "object") if (Object.is(path?.valueOf(), -0)) path = "-0";
			else path = String(path);
			if (isUnsafeProperty(path)) return false;
			if (obj?.[path] === void 0) return true;
			try {
				delete obj[path];
				return true;
			} catch {
				return false;
			}
		case "string":
			if (obj?.[path] === void 0 && isDeepKey(path)) return unsetWithPath(obj, toPath(path));
			if (isUnsafeProperty(path)) return false;
			try {
				delete obj[path];
				return true;
			} catch {
				return false;
			}
	}
}
function unsetWithPath(obj, path) {
	const parent = path.length === 1 ? obj : get(obj, path.slice(0, -1));
	const lastKey = path[path.length - 1];
	if (parent?.[lastKey] === void 0) return true;
	if (isUnsafeProperty(lastKey)) return false;
	try {
		delete parent[lastKey];
		return true;
	} catch {
		return false;
	}
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/pullAt.mjs
/**
* Removes elements from an array at specified indices and returns the removed elements.
*
* @template T
* @param array - The array from which elements will be removed.
* @param _indices - An array of indices specifying the positions of elements to remove.
* @returns An array containing the elements that were removed from the original array.
*
* @example
* const numbers = [10, 20, 30, 40, 50];
* const removed = pullAt(numbers, [1, 3, 4]);
* console.log(removed); // [20, 40, 50]
* console.log(numbers); // [10, 30]
*/
function pullAt(array, ..._indices) {
	const indices = flattenDepth(_indices, 1);
	if (!array) return Array(indices.length);
	const result = at(array, indices);
	const indicesToPull = indices.map((index) => isIndex(index, array.length) ? Number(index) : index).sort((a, b) => b - a);
	for (const index of new Set(indicesToPull)) {
		if (isIndex(index, array.length)) {
			Array.prototype.splice.call(array, index, 1);
			continue;
		}
		if (isKey(index, array)) {
			delete array[toKey(index)];
			continue;
		}
		unset(array, isArray(index) ? index : toPath(index));
	}
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/reduceRight.mjs
/**
* Reduces a collection to a single value using an iteratee function, starting from the right.
*
* @param collection - The collection to iterate over.
* @param iteratee - The function invoked per iteration or the key to reduce over.
* @param initialValue - The initial value.
* @returns Returns the accumulated value.
*
* @example
* // Using a reducer function
* const array = [1, 2, 3];
* reduceRight(array, (acc, value) => acc + value, 0); // => 6
*
* @example
* // Using a reducer function with initialValue
* const array = [1, 2, 3];
* reduceRight(array, (acc, value) => acc + value % 2 === 0, true); // => false
*
* @example
* // Using an object as the collection
* const obj = { a: 1, b: 2, c: 3 };
* reduceRight(obj, (acc, value) => acc + value, 0); // => 6
*/
function reduceRight(collection, iteratee = identity$1, accumulator) {
	const hasAccumulator = arguments.length >= 3;
	if (!collection) return accumulator;
	let keys;
	let startIndex;
	if (isArrayLike(collection)) {
		keys = range$1(0, collection.length).reverse();
		if (!hasAccumulator && collection.length > 0) {
			accumulator = collection[collection.length - 1];
			startIndex = 1;
		} else startIndex = 0;
	} else {
		keys = Object.keys(collection).reverse();
		if (!hasAccumulator && keys.length > 0) {
			accumulator = collection[keys[0]];
			startIndex = 1;
		} else startIndex = 0;
	}
	for (let i = startIndex; i < keys.length; i++) {
		const key = keys[i];
		const value = collection[key];
		accumulator = iteratee(accumulator, value, key, collection);
	}
	return accumulator;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/negate.mjs
/**
* Creates a function that negates the result of the predicate function.
*
* @template F - The type of the function to negate.
* @param func - The function to negate.
* @returns The new negated function, which negates the boolean result of `func`.
*
* @example
* const array = [1, 2, 3, 4, 5, 6];
* const isEven = (n: number) => n % 2 === 0;
* const result = array.filter(negate(isEven));
* // result will be [1, 3, 5]
*/
function negate(func) {
	if (typeof func !== "function") throw new TypeError("Expected a function");
	return function(...args) {
		return !func.apply(this, args);
	};
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/reject.mjs
/**
* Iterates over the collection and rejects elements based on the given predicate.
* If a function is provided, it is invoked for each element in the collection.
*
* @template T
* @param source - The array or object to iterate over.
* @param [predicate=identity] - The function invoked per iteration.
* @returns Returns a new array of elements that do not satisfy the predicate.
*
* @example
* reject([{ a: 1 }, { a: 2 }, { b: 1 }], 'a');
* // => [{ b: 1 }]
*
* reject([{ a: 1 }, { a: 2 }, { b: 1 }], { b: 1 });
* // => [{ a: 1 }, { a: 2 }]
*
* reject({ item1: { a: 0, b: true }, item2: { a: 1, b: true }, item3: { a: 2, b: false }}, { b: false })
* // => [{ a: 0, b: true }, { a: 1, b: true }]
*
* reject([{ a: 1 }, { a: 2 }, { a: 3 }], ['a', 2]);
* // => [{ a: 1 }, { a: 3 }]
*/
function reject(source, predicate = identity$1) {
	return filter(source, negate(iteratee(predicate)));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/remove.mjs
/**
* Removes elements from an array based on various criteria.
*
* @param arr - The array to iterate over.
* @param shouldRemoveElement - The function invoked per iteration, a partial object, a property-value pair, or a key to match against each element.
* @returns Returns the modified array with the specified elements removed.
*
* @example
* // Using a predicate function
* const numbers = [1, 2, 3, 4, 5];
* remove(numbers, value => value % 2 === 0); // => [1, 3, 5]
*
* @example
* // Using a partial object
* const objects = [{ a: 1 }, { a: 2 }, { a: 3 }];
* remove(objects, { a: 1 }); // => [{ a: 2 }, { a: 3 }]
*
* @example
* // Using a property-value pair
* const objects = [{ a: 1 }, { a: 2 }, { a: 3 }];
* remove(objects, ['a', 1]); // => [{ a: 2 }, { a: 3 }]
*
* @example
* // Using a property key
* const objects = [{ a: 0 }, { a: 1 }];
* remove(objects, 'a'); // => [{ a: 0 }]
*/
function remove(arr, shouldRemoveElement = identity$1) {
	return remove$1(arr, iteratee(shouldRemoveElement));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/reverse.mjs
/**
* Reverses the elements of an array in place.
*
* This function takes an array and reverses its elements in place, modifying the original array.
* If the input is `null` or `undefined`, it returns the input as is.
*
* @template T - The type of elements in the array.
* @param array - The array to reverse. If `null` or `undefined`, the input is returned as is.
* @returns The reversed array, or `null`/`undefined` if the input was `null`/`undefined`.
*
* @example
* const array = [1, 2, 3, 4, 5];
* const reversedArray = reverse(array);
* // reversedArray is [5, 4, 3, 2, 1], and array is also modified to [5, 4, 3, 2, 1].
*
* const emptyArray = reverse([]);
* // emptyArray is [].
*
* const nullArray = reverse(null);
* // nullArray is null.
*/
function reverse(array) {
	if (array == null) return array;
	return array.reverse();
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/sample.mjs
/**
* The implementation for the overloaded sample function.
*
* This function takes an array, string, or object and returns a single element selected randomly.
* If the input is empty, or if it's null or undefined, the function returns `undefined`.
*
* @template T - The type of elements in the collection.
* @param collection - The collection to sample from.
* @returns A random element from the collection, or `undefined` if the collection is empty or invalid.
*/
function sample(collection) {
	if (collection == null) return;
	if (isArrayLike(collection)) return sample$1(toArray$1(collection));
	return sample$1(Object.values(collection));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isMap.mjs
/**
* Checks if a given value is `Map`.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to `Map`.
*
* @param value The value to check if it is a `Map`.
* @returns Returns `true` if `value` is a `Map`, else `false`.
*
* @example
* const value1 = new Map();
* const value2 = new Set();
* const value3 = new WeakMap();
*
* console.log(isMap(value1)); // true
* console.log(isMap(value2)); // false
* console.log(isMap(value3)); // false
*/
function isMap(value) {
	return isMap$1(value);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/toArray.mjs
/**
* Converts a value to an array.
*
* @param value - The value to convert.
* @returns Returns the converted array.
*
* @example
* toArray({ 'a': 1, 'b': 2 }) // => returns [1,2]
* toArray('abc') // => returns ['a', 'b', 'c']
* toArray(1) // => returns []
* toArray(null) // => returns []
*/
function toArray(value) {
	if (value == null) return [];
	if (isArrayLike(value) || isMap(value)) return Array.from(value);
	if (typeof value === "object") return Object.values(value);
	return [];
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/sampleSize.mjs
/**
* Returns a sample element array of a specified `size`.
*
* This function takes an array and a number, and returns an array containing the sampled elements using Floyd's algorithm.
*
* {@link https://www.nowherenearithaca.com/2013/05/robert-floyds-tiny-and-beautiful.html Floyd's algorithm}
*
* @template T - The type of elements in the array.
* @param collection - The array to sample from.
* @param size - The size of sample.
* @returns A new array with sample size applied.
*
* @example
* const result = sampleSize([1, 2, 3], 2)
* // result will be an array containing two of the elements from the collection.
* // [1, 2] or [1, 3] or [2, 3]
*/
function sampleSize(collection, size, guard) {
	const arrayCollection = toArray(collection);
	if (guard ? isIterateeCall(collection, size, guard) : size === void 0) size = 1;
	else size = clamp(toInteger(size), 0, arrayCollection.length);
	return sampleSize$1(arrayCollection, size);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/values.mjs
/**
* Creates an array of the own enumerable property values of `object`.
*
* @param object The object to query.
* @returns Returns an array of property values.
* @example
* const obj = { a: 1, b: 2, c: 3 };
* values(obj); // => [1, 2, 3]
*/
function values(object) {
	if (object == null) return [];
	return Object.values(object);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isNil.mjs
/**
* Checks if a given value is null or undefined.
*
* This function tests whether the provided value is either `null` or `undefined`.
* It returns `true` if the value is `null` or `undefined`, and `false` otherwise.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to `null` or `undefined`.
*
* @param x - The value to test for null or undefined.
* @returns `true` if the value is null or undefined, `false` otherwise.
*
* @example
* const value1 = null;
* const value2 = undefined;
* const value3 = 42;
* const result1 = isNil(value1); // true
* const result2 = isNil(value2); // true
* const result3 = isNil(value3); // false
*/
function isNil(x) {
	return x == null;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/shuffle.mjs
/**
* Randomizes the order of elements in an `collection` using the Fisher-Yates algorithm.
*
* This function takes an `collection` and returns a new `collection` with its elements shuffled in a random order.
*
* @template T - The type of elements in the `collection`.
* @param collection - The `collection` to shuffle.
* @returns A new `collection` with its elements shuffled in random order.
*/
function shuffle(collection) {
	if (isNil(collection)) return [];
	if (isArray(collection)) return shuffle$1(collection);
	if (isArrayLike(collection)) return shuffle$1(Array.from(collection));
	if (isObjectLike(collection)) return shuffle$1(values(collection));
	return [];
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/size.mjs
function size(target) {
	if (isNil$1(target)) return 0;
	if (isArrayLike(target)) return target.length;
	if (target instanceof Map || target instanceof Set) return target.size;
	return Object.keys(target).length;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/slice.mjs
/**
* Create a slice of `array` from `start` up to, but not including, `end`.
*
* It does not return a dense array for sparse arrays unlike the native `Array.prototype.slice`.
*
* @template T - The type of the array elements.
* @param array - The array to slice.
* @param [start=0] - The start position.
* @param [end=array.length] - The end position.
* @returns Returns the slice of `array`.
*
* @example
* slice([1, 2, 3], 1, 2); // => [2]
* slice(new Array(3)); // => [undefined, undefined, undefined]
*/
function slice(array, start, end) {
	if (!isArrayLike(array)) return [];
	const length = array.length;
	if (end === void 0) end = length;
	else if (typeof end !== "number" && isIterateeCall(array, start, end)) {
		start = 0;
		end = length;
	}
	start = toInteger(start);
	end = toInteger(end);
	if (start < 0) start = Math.max(length + start, 0);
	else start = Math.min(start, length);
	if (end < 0) end = Math.max(length + end, 0);
	else end = Math.min(end, length);
	const resultLength = Math.max(end - start, 0);
	const result = new Array(resultLength);
	for (let i = 0; i < resultLength; ++i) result[i] = array[start + i];
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/some.mjs
/**
* Checks if there is an element in an array that matches the given predicate.
*
* Iteration is stopped once there is an element that matches `predicate`.
*
* @template T
* @param source The source to iterate over.
* @param [predicate=identity] The function invoked per iteration.
* If a property name or an object is provided it will be used to create a predicate function.
* @returns Returns `true` if any element passes the predicate check, else `false`.
*
* @example
* some([1, 2, 3, 4], n => n % 2 === 0);
* // => true
*
* some([{ a: 1 }, { a: 2 }, { a: 3 }], { a: 2 });
* // => true
*
* some([{ a: 1 }, { a: 2 }, { a: 3 }], ['a', 2]);
* // => true
*
* some([{ a: 1 }, { a: 2 }, { a: 3 }], 'a');
* // => true
*
* some({ a: 1, b: 2, c: 3 }, n => n % 2 === 0);
* // => true
*
* some({ a: { id: 1, name: 'Alice' }, b: { id: 2, name: 'Bob' } }, { name: 'Bob' });
* // => true
*
* some({ a: { id: 1, name: 'Alice' }, b: { id: 2, name: 'Bob' } }, ['name', 'Alice']);
* // => true
*
* some({ a: { id: 1, name: 'Alice' }, b: { id: 2, name: 'Bob' } }, 'name');
* // => true
*/
function some(source, predicate, guard) {
	if (!source) return false;
	if (guard != null) predicate = void 0;
	if (predicate == null) predicate = identity$1;
	const values = Array.isArray(source) ? source : Object.values(source);
	switch (typeof predicate) {
		case "function":
			if (!Array.isArray(source)) {
				const keys = Object.keys(source);
				for (let i = 0; i < keys.length; i++) {
					const key = keys[i];
					const value = source[key];
					if (predicate(value, key, source)) return true;
				}
				return false;
			}
			for (let i = 0; i < source.length; i++) if (predicate(source[i], i, source)) return true;
			return false;
		case "object": if (Array.isArray(predicate) && predicate.length === 2) {
			const key = predicate[0];
			const value = predicate[1];
			const matchFunc = matchesProperty(key, value);
			if (Array.isArray(source)) {
				for (let i = 0; i < source.length; i++) if (matchFunc(source[i])) return true;
				return false;
			}
			return values.some(matchFunc);
		} else {
			const matchFunc = matches(predicate);
			if (Array.isArray(source)) {
				for (let i = 0; i < source.length; i++) if (matchFunc(source[i])) return true;
				return false;
			}
			return values.some(matchFunc);
		}
		case "number":
		case "symbol":
		case "string": {
			const propFunc = property(predicate);
			if (Array.isArray(source)) {
				for (let i = 0; i < source.length; i++) if (propFunc(source[i])) return true;
				return false;
			}
			return values.some(propFunc);
		}
	}
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/sortBy.mjs
function sortBy(collection, ...criteria) {
	const length = criteria.length;
	if (length > 1 && isIterateeCall(collection, criteria[0], criteria[1])) criteria = [];
	else if (length > 2 && isIterateeCall(criteria[0], criteria[1], criteria[2])) criteria = [criteria[0]];
	return orderBy(collection, flatten(criteria), ["asc"]);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isNumber.mjs
/**
* Checks if a given value is a number.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to `number`.
*
* @param value The value to check if it is a number.
* @returns Returns `true` if `value` is a number, else `false`.
*
* @example
* const value1 = 123;
* const value2 = 'abc';
* const value3 = true;
*
* console.log(isNumber(value1)); // true
* console.log(isNumber(value2)); // false
* console.log(isNumber(value3)); // false
*/
function isNumber(value) {
	return typeof value === "number" || isObjectLike(value) && getTag(value) === "[object Number]";
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isNaN.mjs
/**
* Checks if the value is NaN.
*
* @param value - The value to check.
* @returns `true` if the value is NaN, `false` otherwise.
*
* @example
* isNaN(NaN); // true
* isNaN(0); // false
* isNaN('NaN'); // false
* isNaN(undefined); // false
*/
function isNaN(value) {
	return isNumber(value) && Number.isNaN(Number(value));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/sortedIndexBy.mjs
var MAX_ARRAY_INDEX = 4294967294;
/**
* This method is like `sortedIndex` except that it accepts `iteratee`
* which is invoked for `value` and each element of `array` to compute their
* sort ranking. The iteratee is invoked with one argument: (value).
*
* @param array The sorted array to inspect.
* @param value The value to evaluate.
* @param iteratee The iteratee invoked per element.
* @returns Returns the index at which `value` should be inserted
*  into `array`.
* @example
* const objects = [{ 'n': 4 }, { 'n': 5 }]
* sortedIndexBy(objects, { 'n': 4 }, ({ n }) => n)
* // => 0
*/
function sortedIndexBy(array, value, iteratee$1 = identity, retHighest) {
	if (isNil(array) || array.length === 0) return 0;
	let low = 0;
	let high = array.length;
	const iterateeFunction = iteratee(iteratee$1);
	const transformedValue = iterateeFunction(value);
	const valIsNaN = isNaN(transformedValue);
	const valIsNull = isNull$1(transformedValue);
	const valIsSymbol = isSymbol$1(transformedValue);
	const valIsUndefined = isUndefined$1(transformedValue);
	while (low < high) {
		let setLow;
		const mid = Math.floor((low + high) / 2);
		const computed = iterateeFunction(array[mid]);
		const othIsDefined = !isUndefined$1(computed);
		const othIsNull = isNull$1(computed);
		const othIsReflexive = !isNaN(computed);
		const othIsSymbol = isSymbol$1(computed);
		if (valIsNaN) setLow = retHighest || othIsReflexive;
		else if (valIsUndefined) setLow = othIsReflexive && (retHighest || othIsDefined);
		else if (valIsNull) setLow = othIsReflexive && othIsDefined && (retHighest || !othIsNull);
		else if (valIsSymbol) setLow = othIsReflexive && othIsDefined && !othIsNull && (retHighest || !othIsSymbol);
		else if (othIsNull || othIsSymbol) setLow = false;
		else setLow = retHighest ? computed <= transformedValue : computed < transformedValue;
		if (setLow) low = mid + 1;
		else high = mid;
	}
	return Math.min(high, MAX_ARRAY_INDEX);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/sortedIndex.mjs
var HALF_MAX_ARRAY_LENGTH$1 = 2147483647;
/**
* Uses a binary search to determine the lowest index at which `value`
* should be inserted into `array` in order to maintain its sort order.
*
* @category Array
* @param array The sorted array to inspect.
* @param value The value to evaluate.
* @returns Returns the index at which `value` should be inserted
*  into `array`.
* @example
* sortedIndex([30, 50], 40)
* // => 1
*/
function sortedIndex(array, value) {
	if (isNil$1(array)) return 0;
	let low = 0;
	let high = array.length;
	if (isNumber(value) && value === value && high <= HALF_MAX_ARRAY_LENGTH$1) {
		while (low < high) {
			const mid = low + high >>> 1;
			const compute = array[mid];
			if (!isNull$1(compute) && !isSymbol(compute) && compute < value) low = mid + 1;
			else high = mid;
		}
		return high;
	}
	return sortedIndexBy(array, value, (value) => value);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/sortedIndexOf.mjs
/**
* Finds the index of the first occurrence of a value in a sorted array, similar to how `Array#indexOf` works, but specifically for sorted arrays.
*
* Make sure to provide a sorted array to this function, as it uses a binary search to quickly find the index.
*
* @param array The sorted array to inspect.
* @param value The value to search for.
* @returns Returns the index of the matched value, else -1.
*
* @example
* const numbers = [1, 2, 3, 4, 5];
* sortedIndexOf(numbers, 11); // Return value: 0
* sortedIndexOf(numbers, 30); // Return value: -1
*
* // If the value is duplicated, it returns the first index of the value.
* const duplicateNumbers = [1, 2, 2, 3, 3, 3, 4];
* sortedIndexOf(duplicateNumbers, 3); // Return value: 3
*
* // If the array is unsorted, it can return the wrong index.
* const unSortedArray = [55, 33, 22, 11, 44];
* sortedIndexOf(unSortedArray, 11); // Return value: -1
*
* // -0 and 0 are treated the same
* const mixedZeroArray = [-0, 0];
* sortedIndexOf(mixedZeroArray, 0); // Return value: 0
* sortedIndexOf(mixedZeroArray, -0); // Return value: 0
*
* // It works with array-like objects
* const arrayLike = { length: 3, 0: 10, 1: 20, 2: 30 };
* sortedIndexOf(arrayLike, 20); // Return value: 1
*/
function sortedIndexOf(array, value) {
	if (!array?.length) return -1;
	const index = sortedIndex(array, value);
	if (index < array.length && isEqualsSameValueZero(array[index], value)) return index;
	return -1;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/sortedLastIndexBy.mjs
/**
* This method is like `sortedLastIndex` except that it accepts `iteratee`
* which is invoked for `value` and each element of `array` to compute their
* sort ranking. The iteratee is invoked with one argument: (value).
*
* @param array The sorted array to inspect.
* @param value The value to evaluate.
* @param iteratee The iteratee invoked per element.
* @returns Returns the highest index at which `value` should be inserted
*  into `array`.
* @example
* const objects = [{ 'n': 4 }, { 'n': 5 }]
* sortedLastIndexBy(objects, { 'n': 4 }, ({ n }) => n)
* // => 1
*/
function sortedLastIndexBy(array, value, iteratee) {
	return sortedIndexBy(array, value, iteratee, true);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/sortedLastIndex.mjs
var HALF_MAX_ARRAY_LENGTH = 2147483647;
/**
* Uses a binary search to determine the highest index at which `value`
* should be inserted into `array` in order to maintain its sort order.
*
* @category Array
* @param array The sorted array to inspect.
* @param value The value to evaluate.
* @returns Returns the index at which `value` should be inserted
*  into `array`.
* @example
* sortedLastIndex([4, 5, 5, 5, 6], 5)
* // => 4
*/
function sortedLastIndex(array, value) {
	if (isNil$1(array)) return 0;
	let high = array.length;
	if (!isNumber(value) || Number.isNaN(value) || high > HALF_MAX_ARRAY_LENGTH) return sortedLastIndexBy(array, value, (value) => value);
	let low = 0;
	while (low < high) {
		const mid = low + high >>> 1;
		const compute = array[mid];
		if (!isNull$1(compute) && !isSymbol(compute) && compute <= value) low = mid + 1;
		else high = mid;
	}
	return high;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/sortedLastIndexOf.mjs
/**
* Finds the index of the last occurrence of a value in a sorted array.
* This function is similar to `Array#lastIndexOf` but is specifically designed for sorted arrays.
*
* Make sure to provide a sorted array to this function, as it uses a binary search to quickly find the index.
*
* @param array The sorted array to inspect.
* @param value The value to search for.
* @returns Returns the index of the last matched value, else -1.
*
* @example
* const numbers = [1, 2, 3, 4, 5];
* sortedLastIndexOf(numbers, 3); // Return value: 2
* sortedLastIndexOf(numbers, 6); // Return value: -1
*
* // If the value is duplicated, it returns the last index of the value.
* const duplicateNumbers = [1, 2, 2, 3, 3, 3, 4];
* sortedLastIndexOf(duplicateNumbers, 3); // Return value: 5
*
* // If the array is unsorted, it can return the wrong index.
* const unSortedArray = [55, 33, 22, 11, 44];
* sortedLastIndexOf(unSortedArray, 11); // Return value: -1
*
* // -0 and 0 are treated the same
* const mixedZeroArray = [-0, 0];
* sortedLastIndexOf(mixedZeroArray, 0); // Return value: 1
* sortedLastIndexOf(mixedZeroArray, -0); // Return value: 1
*
* // It works with array-like objects
* const arrayLike = { length: 3, 0: 10, 1: 20, 2: 20 };
* sortedLastIndexOf(arrayLike, 20); // Return value: 2
*/
function sortedLastIndexOf(array, value) {
	if (!array?.length) return -1;
	const index = sortedLastIndex(array, value) - 1;
	if (index >= 0 && isEqualsSameValueZero(array[index], value)) return index;
	return -1;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/tail.mjs
/**
* Returns a new array with all elements except for the first.
*
* This function takes an array and returns a new array containing all the elements
* except for the first one. If the input array is empty or has only one element,
* an empty array is returned.
*
* @template T - The type of elements in the array.
* @param arr - The array to get the tail of.
* @returns A new array containing all elements of the input array except for the first one.
*
* @example
* const arr1 = [1, 2, 3];
* const result = tail(arr1);
* // result will be [2, 3]
*
* const arr2 = [1];
* const result2 = tail(arr2);
* // result2 will be []
*
* const arr3 = [];
* const result3 = tail(arr3);
* // result3 will be []
*/
function tail(arr) {
	if (!isArrayLike(arr)) return [];
	return tail$1(toArray$1(arr));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/take.mjs
/**
* Returns a new array containing the first `count` elements from the input array `arr`.
* If `count` is greater than the length of `arr`, the entire array is returned.
*
* @template T - Type of elements in the input array.
*
* @param arr - The array to take elements from.
* @param [count=1] - The number of elements to take.
* @param [guard] - Enables use as an iteratee for methods like `_.map`.
* @returns A new array containing the first `count` elements from `arr`.
*
* @example
* // Returns [1, 2, 3]
* take([1, 2, 3, 4, 5], 3);
*
* @example
* // Returns ['a', 'b']
* take(['a', 'b', 'c'], 2);
*
* @example
* // Returns [1, 2, 3]
* take([1, 2, 3], 5);
*/
function take(arr, count = 1, guard) {
	count = guard || count === void 0 ? 1 : toInteger(count);
	if (count < 1 || !isArrayLike(arr)) return [];
	return take$1(toArray$1(arr), count);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/takeRight.mjs
/**
* Returns a new array containing the last `count` elements from the input array `arr`.
* If `count` is greater than the length of `arr`, the entire array is returned.
*
* @template T - The type of elements in the array.
* @param arr - The array to take elements from.
* @param [count=1] - The number of elements to take.
* @param [guard] - Enables use as an iteratee for methods like `_.map`.
* @returns A new array containing the last `count` elements from `arr`.
*
* @example
* // Returns [4, 5]
* takeRight([1, 2, 3, 4, 5], 2);
*
* @example
* // Returns ['b', 'c']
* takeRight(['a', 'b', 'c'], 2);
*
* @example
* // Returns [1, 2, 3]
* takeRight([1, 2, 3], 5);
*/
function takeRight(arr, count = 1, guard) {
	count = guard ? 1 : toInteger(count);
	if (count <= 0 || !isArrayLike(arr)) return [];
	return takeRight$1(toArray$1(arr), count);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/takeRightWhile.mjs
/**
* Creates a slice of the array with elements taken from the end while the specified predicate is satisfied.
* If no predicate is provided, the identity function is used by default.
* If the array is `null` or `undefined`, returns an empty array.
*
* @template T
* @param array - The array to process.
* @param [predicate] - The condition used to determine elements to include. Can be:
* - A function invoked per iteration.
* - A partial object to match properties.
* - A key-value pair as a tuple.
* - A property key to check for truthy values.
* Defaults to the identity function if not provided.
* @returns A slice of the array with elements taken from the end or an empty array if `array` is `null` or `undefined`.
*
* @example
* // Using a predicate function
* const items = [1, 2, 3, 4, 5];
* const result = takeRightWhile(items, (item) => item > 3);
* console.log(result); // [4, 5]
*
* // Using a partial object
* const items2 = [{ id: 10 }, { id: 20 }, { id: 30 }];
* const result2 = takeRightWhile(items2, { id: 30 });
* console.log(result2); // [{ id: 30 }]
*
* // Using a key-value pair
* const items3 = [{ name: 'Alice' }, { name: 'Bob' }, { name: 'Alice' }];
* const result3 = takeRightWhile(items3, ['name', 'Alice']);
* console.log(result3); // [{ name: 'Alice' }]
*
* // Using a property key
* const items4 = [{ active: false }, { active: true }, { active: true }];
* const result4 = takeRightWhile(items4, 'active');
* console.log(result4); // [{ active: true }, { active: true }]
*
* // No predicate provided
* const items5 = [false, true];
* const result5 = takeRightWhile(items5);
* console.log(result5); // [true]
*
* // null or undefined array
* const result6 = takeRightWhile(null);
* console.log(result6); // []
*/
function takeRightWhile(_array, predicate) {
	if (!isArrayLikeObject(_array)) return [];
	const array = toArray$1(_array);
	const index = array.findLastIndex(negate$1(iteratee(predicate ?? identity$1)));
	return array.slice(index + 1);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/takeWhile.mjs
/**
* Creates a slice of the array with elements taken from the beginning while the specified predicate is satisfied.
* If no predicate is provided, the identity function is used by default.
* If the array is `null` or `undefined`, returns an empty array.
*
* @template T
* @param array - The array to process.
* @param [predicate] - The condition used to determine elements to include. Can be:
* - A function invoked per iteration.
* - A partial object to match properties.
* - A key-value pair as a tuple.
* - A property key to check for truthy values.
* Defaults to the identity function if not provided.
* @returns A slice of the array with elements taken from the beginning or an empty array if `array` is `null` or `undefined`.
*
* @example
* // Using a predicate function
* const items = [1, 2, 3, 4, 5];
* const result = takeWhile(items, (item) => item < 3);
* console.log(result); // [1, 2]
*
* // Using a partial object
* const items2 = [{ id: 30 }, { id: 20 }, { id: 10 }];
* const result2 = takeWhile(items2, { id: 30 });
* console.log(result2); // [{ id: 30 }]
*
* // Using a key-value pair
* const items3 = [{ name: 'Alice' }, { name: 'Bob' }, { name: 'Alice' }];
* const result3 = takeWhile(items3, ['name', 'Alice']);
* console.log(result3); // [{ name: 'Alice' }]
*
* // Using a property key
* const items4 = [{ active: true }, { active: true }, { active: false }];
* const result4 = takeWhile(items4, 'active');
* console.log(result4); // [{ active: true }, { active: true }]
*
* // No predicate provided
* const items5 = [true, false];
* const result5 = takeWhile(items5);
* console.log(result5); // [true]
*
* // null or undefined array
* const result6 = takeWhile(null);
* console.log(result6); // []
**/
function takeWhile(array, predicate) {
	if (!isArrayLikeObject(array)) return [];
	const _array = toArray$1(array);
	const index = _array.findIndex(negate(iteratee(predicate ?? identity)));
	return index === -1 ? _array : _array.slice(0, index);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/unionBy.mjs
/**
* This function takes multiple arrays and returns a new array containing only the unique values
* from all input arrays, preserving the order of their first occurrence.
* An iteratee function can be provided for comparison and it output values from the first possible array
*
* @template T - The type of elements in the arrays.
* @param values - The arrays to inspect, or the iteratee function.
* @returns Returns the new array of combined unique values.
*
* @example
* // Returns [2.1, 1.2]
* unionBy([2.1], [1.2, 2.3], Math.floor);
*
* @example
* // Returns [{ x: 1 }, { x: 2 }]
* unionBy([{ x: 1 }], [{ x: 2 }, { x: 1 }], 'x');
*
* @example
* // Returns [{ x: 1, y: 1 }]
* unionBy([{ x: 1, y: 1 }], [{ x: 1, y: 2 }], 'x');
*/
function unionBy(...values) {
	const lastValue = last$1(values);
	const flattened = flattenArrayLike(values);
	if (isArrayLikeObject(lastValue) || lastValue == null) return uniq(flattened);
	return uniqBy$1(flattened, ary$1(iteratee(lastValue), 1));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/unionWith.mjs
/**
* This function takes multiple arrays and returns a new array containing only the unique values
* from all input arrays, preserving the order of their first occurrence.
* A comparator function can be provided for comparison and it output values from the first possible array
*
* @template T - The type of elements in the arrays.
* @param values - The arrays to inspect, or the comparator function.
* @returns Returns the new array of combined unique values.
*
* @example
* const objects = [
*   { x: 1, y: 2 },
*   { x: 2, y: 1 },
* ];
* const others = [
*   { x: 1, y: 1 },
*   { x: 1, y: 2 },
* ];
* // Returns [objects[0], objects[1], others[0]]
* unionWith(objects, others, isEqual);
*
* @example
* const objects = [{ x: 1, y: 1 }];
* const others = [{ x: 1, y: 2 }];
* // Returns [{ x: 1, y: 1 }]
* unionWith(objects, others, (a, b) => a.x === b.x);
*/
function unionWith(...values) {
	const lastValue = last$1(values);
	const flattened = flattenArrayLike(values);
	if (isArrayLikeObject(lastValue) || lastValue == null) return uniq(flattened);
	return uniqWith$1(flattened, lastValue);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/uniqBy.mjs
function uniqBy(array, iteratee$1 = identity$1) {
	if (!isArrayLikeObject(array)) return [];
	return uniqBy$1(Array.from(array), ary$1(iteratee(iteratee$1), 1));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/uniqWith.mjs
/**
* This method is like `uniq`, except that it accepts a `comparator` which is used to determine the equality of elements.
*
* It creates a duplicate-free version of an array, in which only the first occurrence of each element is kept.
* If a `comparator` is provided, it will be invoked with two arguments: `(arrVal, othVal)` to compare elements.
* If no comparator is provided, shallow equality is used.
*
* The order of result values is determined by the order they appear in the input array.
*
* @template T - The type of elements in the array.
* @param arr  - The array to process.
* @param [comparator] - Optional function to compare elements for equality.
* @returns A new array with only unique values based on the comparator.
*
* @example
* const array = [1, 2, 2, 3];
* const result = uniqWith(array);
* // result will be [1, 2, 3]
*
* const array = [1, 2, 3];
* const result = uniqWith(array, (a, b) => a % 2 === b % 2)
* // result will be [1, 2]
*/
function uniqWith(arr, comparator) {
	if (!isArrayLike(arr)) return [];
	if (typeof comparator !== "function") return uniq$1(Array.from(arr));
	return uniqWith$1(Array.from(arr), (kept, candidate) => comparator(candidate, kept));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/unzip.mjs
/**
* Gathers elements in the same position in an internal array
* from a grouped array of elements and returns them as a new array.
*
* @template T - The type of elements in the nested array.
* @param array - The nested array to unzip.
* @returns A new array of unzipped elements.
*
* @example
* const zipped = [['a', true, 1],['b', false, 2]];
* const result = unzip(zipped);
* // result will be [['a', 'b'], [true, false], [1, 2]]
*/
function unzip(array) {
	if (!isArrayLikeObject(array) || !array.length) return [];
	array = isArray(array) ? array : Array.from(array);
	array = array.filter((item) => isArrayLikeObject(item));
	return unzip$1(array);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/unzipWith.mjs
/**
* Unzips an array of arrays, applying an `iteratee` function to regrouped elements.
*
* If the array is `null` or `undefined`, returns an empty array.
*
* @template T
* @param array - The nested array to unzip. This is an array of arrays,
* where each inner array contains elements to be unzipped.
* @param iteratee - A function to transform the unzipped elements.
* @returns A new array of unzipped and transformed elements.
*
* @example
* const nestedArray = [[1, 2], [3, 4], [5, 6]];
* const result = unzipWith(nestedArray, (a, b) => a + b);
* console.log(result); // [9, 12]
*/
function unzipWith(array, iteratee) {
	if (!isArrayLikeObject(array) || !array.length) return [];
	const unzipped = isArray(array) ? unzip$1(array) : unzip$1(Array.from(array, (value) => Array.from(value)));
	if (!iteratee) return unzipped;
	const result = new Array(unzipped.length);
	for (let i = 0; i < unzipped.length; i++) {
		const value = unzipped[i];
		result[i] = iteratee(...value);
	}
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/without.mjs
/**
* Creates an array that excludes all specified values.
*
* It correctly excludes `NaN`, as it compares values using [SameValueZero](https://tc39.es/ecma262/multipage/abstract-operations.html#sec-samevaluezero).
*
* @template T The type of elements in the array.
* @param array - The array to filter.
* @param values - The values to exclude.
* @returns A new array without the specified values.
*
* @example
* // Removes the specified values from the array
* without([1, 2, 3, 4, 5], 2, 4);
* // Returns: [1, 3, 5]
*
* @example
* // Removes specified string values from the array
* without(['a', 'b', 'c', 'a'], 'a');
* // Returns: ['b', 'c']
*/
function without(array, ...values) {
	if (!isArrayLikeObject(array)) return [];
	return without$1(Array.from(array), ...values);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/xor.mjs
/**
* Computes the symmetric difference of the provided arrays, returning an array of elements
* that exist in only one of the arrays.
*
* @template T - The type of elements in the arrays.
* @param arrays - The arrays to compare.
* @returns An array containing the elements that are present in only one of the provided `arrays`.
*
* @example
* // Returns [1, 2, 5, 6]
* xor([1, 2, 3, 4], [3, 4, 5, 6]);
*
* @example
* // Returns ['a', 'c']
* xor(['a', 'b'], ['b', 'c']);
*
* @example
* // Returns [1, 3, 5]
* xor([1, 2], [2, 3], [4, 5]);
*/
function xor(...arrays) {
	const itemCounts = /* @__PURE__ */ new Map();
	for (let i = 0; i < arrays.length; i++) {
		const array = arrays[i];
		if (!isArrayLikeObject(array)) continue;
		const itemSet = new Set(toArray(array));
		for (const item of itemSet) if (!itemCounts.has(item)) itemCounts.set(item, 1);
		else itemCounts.set(item, itemCounts.get(item) + 1);
	}
	const result = [];
	for (const [item, count] of itemCounts) if (count === 1) result.push(item);
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/xorBy.mjs
/**
* Computes the symmetric difference between two arrays using a custom mapping function.
* The symmetric difference is the set of elements which are in either of the arrays,
* but not in their intersection, determined by the result of the mapping function.
*
* @template T - Type of elements in the input arrays.
* @template U - Type of the values returned by the mapping function.
*
* @param values - The arrays to inspect, or the function to map array elements to comparison values.
* @returns An array containing the elements that are present in either `arr1` or `arr2` but not in both, based on the values returned by the mapping function.
*
* @example
* // Custom mapping function for objects with an 'id' property
* const idMapper = obj => obj.id;
* xorBy([{ id: 1 }, { id: 2 }], [{ id: 2 }, { id: 3 }], idMapper);
* // Returns [{ id: 1 }, { id: 3 }]
*/
function xorBy(...values) {
	const lastValue = last(values);
	let mapper = identity$1;
	if (!isArrayLikeObject(lastValue) && lastValue != null) {
		mapper = iteratee(lastValue);
		values = values.slice(0, -1);
	}
	const arrays = values.filter(isArrayLikeObject);
	return differenceBy(unionBy(...arrays, mapper), unionBy(...windowed(arrays, 2).map(([arr1, arr2]) => intersectionBy(arr1, arr2, mapper)), mapper), mapper);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/xorWith.mjs
/**
* Creates an array of unique values that is the symmetric difference of the given arrays using a custom comparator function.
*
* The symmetric difference is the set of elements which are in either of the arrays,
* but not in their intersection, determined by the comparator function.
*
* @template T - Type of elements in the input arrays.
*
* @param values - The arrays to inspect, or the comparator function.
* @returns An array containing the elements that are present in exactly one of the arrays
*  as determined by the comparator.
*
* @example
* // Custom comparator function for objects with an 'id' property
* const idComparator = (a, b) => a.id === b.id;
* xorWith([{ id: 1 }, { id: 2 }], [{ id: 2 }, { id: 3 }], idComparator);
* // Returns [{ id: 1 }, { id: 3 }]
*/
function xorWith(...values) {
	const lastValue = last(values);
	let comparator = (a, b) => a === b;
	if (typeof lastValue === "function") {
		comparator = lastValue;
		values = values.slice(0, -1);
	}
	const arrays = values.filter(isArrayLikeObject);
	return differenceWith(unionWith(...arrays, comparator), unionWith(...windowed(arrays, 2).map(([arr1, arr2]) => intersectionWith(arr1, arr2, comparator)), comparator), comparator);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/zip.mjs
/**
* Combines multiple arrays into a single array of tuples.
*
* This function takes multiple arrays and returns a new array where each element is a tuple
* containing the corresponding elements from the input arrays. If the input arrays are of
* different lengths, the resulting array will have the length of the longest input array,
* with undefined values for missing elements.
*
* @template T
* @param arrays - The arrays to zip.
* @returns A new array of tuples containing the corresponding elements from the input arrays.
*
* @example
* const arr1 = [1, 2, 3];
* const arr2 = ['a', 'b', 'c'];
* const arr3 = [true, false];
* const arr4 = [null, null, null];
* const arr5 = [undefined, undefined, undefined];
* const result = zip(arr1, arr2, arr3, arr4, arr5);
* // result will be [[1, 'a', true, null, undefined], [2, 'b', false, null, undefined], [3, 'c', undefined, null, undefined]]
*/
function zip(...arrays) {
	if (!arrays.length) return [];
	return zip$1(...arrays.filter((group) => isArrayLikeObject(group)));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/_internal/assignValue.mjs
var assignValue = (object, key, value) => {
	const objValue = object[key];
	if (!(Object.hasOwn(object, key) && isEqualsSameValueZero(objValue, value)) || value === void 0 && !(key in object)) object[key] = value;
};
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/zipObject.mjs
/**
* Combines two arrays, one of property names and one of corresponding values, into a single object.
*
* This function takes two arrays: one containing property names and another containing corresponding values.
* It returns a new object where the property names from the first array are keys, and the corresponding elements
* from the second array are values. If the `keys` array is longer than the `values` array, the remaining keys will
* have `undefined` as their values.
*
* @template P - The type of elements in the array.
* @template V - The type of elements in the array.
* @param keys - An array of property names.
* @param values - An array of values corresponding to the property names.
* @returns A new object composed of the given property names and values.
*
* @example
* const keys = ['a', 'b', 'c'];
* const values = [1, 2, 3];
* const result = zipObject(keys, values);
* // result will be { a: 1, b: 2, c: 3 }
*
* const keys2 = ['a', 'b', 'c'];
* const values2 = [1, 2];
* const result2 = zipObject(keys2, values2);
* // result2 will be { a: 1, b: 2, c: undefined }
*
* const keys2 = ['a', 'b'];
* const values2 = [1, 2, 3];
* const result2 = zipObject(keys2, values2);
* // result2 will be { a: 1, b: 2 }
*/
function zipObject(keys = [], values = []) {
	const result = {};
	for (let i = 0; i < keys.length; i++) assignValue(result, keys[i], values[i]);
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/updateWith.mjs
/**
* Updates the value at the specified path of the given object using an updater function and a customizer.
* If any part of the path does not exist, it will be created.
*
* @template T - The type of the object.
* @template R - The type of the return value.
* @param obj - The object to modify.
* @param path - The path of the property to update.
* @param updater - The function to produce the updated value.
* @param customizer - The function to customize the update process.
* @returns The modified object.
*
* @example
* const object = { 'a': [{ 'b': { 'c': 3 } }] };
* updateWith(object, 'a[0].b.c', (n) => n * n);
* // => { 'a': [{ 'b': { 'c': 9 } }] }
*/
function updateWith(obj, path, updater, customizer) {
	if (obj == null && !isObject(obj)) return obj;
	let resolvedPath;
	if (isKey(path, obj)) resolvedPath = [path];
	else if (Array.isArray(path)) resolvedPath = path;
	else resolvedPath = toPath(path);
	const updateValue = updater(get(obj, resolvedPath));
	let current = obj;
	for (let i = 0; i < resolvedPath.length && current != null; i++) {
		const key = toKey(resolvedPath[i]);
		if (isUnsafeProperty(key)) continue;
		let newValue;
		if (i === resolvedPath.length - 1) newValue = updateValue;
		else {
			const objValue = current[key];
			const customizerResult = customizer?.(objValue, key, obj);
			newValue = customizerResult !== void 0 ? customizerResult : isObject(objValue) ? objValue : isIndex(resolvedPath[i + 1]) ? [] : {};
		}
		assignValue(current, key, newValue);
		current = current[key];
	}
	return obj;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/set.mjs
/**
* Sets the value at the specified path of the given object. If any part of the path does not exist, it will be created.
*
* @template T - The type of the object.
* @param obj - The object to modify.
* @param path - The path of the property to set.
* @param value - The value to set.
* @returns The modified object.
*
* @example
* // Set a value in a nested object
* const obj = { a: { b: { c: 3 } } };
* set(obj, 'a.b.c', 4);
* console.log(obj.a.b.c); // 4
*
* @example
* // Set a value in an array
* const arr = [1, 2, 3];
* set(arr, 1, 4);
* console.log(arr[1]); // 4
*
* @example
* // Create non-existent path and set value
* const obj = {};
* set(obj, 'a.b.c', 4);
* console.log(obj); // { a: { b: { c: 4 } } }
*/
function set(obj, path, value) {
	return updateWith(obj, path, () => value, () => void 0);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/zipObjectDeep.mjs
/**
* Creates a deeply nested object given arrays of paths and values.
*
* This function takes two arrays: one containing arrays of property paths, and the other containing corresponding values.
* It returns a new object where paths from the first array are used as key paths to set values, with corresponding elements from the second array as values.
* Paths can be dot-separated strings or arrays of property names.
*
* If the `keys` array is longer than the `values` array, the remaining keys will have `undefined` as their values.
*
* @template P - The type of property paths.
* @template V - The type of values corresponding to the property paths.
* @param keys - An array of property paths, each path can be a dot-separated string or an array of property names.
* @param values - An array of values corresponding to the property paths.
* @returns A new object composed of the given property paths and values.
*
* @example
* const paths = ['a.b.c', 'd.e.f'];
* const values = [1, 2];
* const result = zipObjectDeep(paths, values);
* // result will be { a: { b: { c: 1 } }, d: { e: { f: 2 } } }
*
* @example
* const paths = [['a', 'b', 'c'], ['d', 'e', 'f']];
* const values = [1, 2];
* const result = zipObjectDeep(paths, values);
* // result will be { a: { b: { c: 1 } }, d: { e: { f: 2 } } }
*
* @example
* const paths = ['a.b[0].c', 'a.b[1].d'];
* const values = [1, 2];
* const result = zipObjectDeep(paths, values);
* // result will be { 'a': { 'b': [{ 'c': 1 }, { 'd': 2 }] } }
*/
function zipObjectDeep(keys, values) {
	const result = {};
	if (!isArrayLike(keys)) return result;
	if (!isArrayLike(values)) values = [];
	const zipped = zip$1(Array.from(keys), Array.from(values));
	for (let i = 0; i < zipped.length; i++) {
		const [key, value] = zipped[i];
		if (key != null) set(result, key, value);
	}
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/array/zipWith.mjs
/**
* Combines multiple arrays into a single array using a custom combiner function.
*
* This function takes one array and a variable number of additional arrays,
* applying the provided combiner function to the corresponding elements of each array.
* If the input arrays are of different lengths, the resulting array will have the length
* of the longest input array, with undefined values for missing elements.
*
* @template T - The type of elements in the input arrays.
* @template R - The type of elements in the resulting array.
* @param combine - The combiner function that takes corresponding elements from each array and returns a single value.
* @returns A new array where each element is the result of applying the combiner function to the corresponding elements of the input arrays.
*
* @example
* const arr1 = [1, 2, 3];
* const arr2 = ['a', 'b', 'c'];
* const result = zipWith(arr1, arr2, (num, char) => `${num}${char}`);
* // result will be ['1a', '2b', '3c']
*/
function zipWith(...combine) {
	let iteratee = combine.pop();
	if (!isFunction$1(iteratee)) {
		combine.push(iteratee);
		iteratee = void 0;
	}
	if (!combine?.length) return [];
	const result = unzip(combine);
	if (iteratee == null) return result;
	return result.map((group) => iteratee(...group));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/after.mjs
/**
* The opposite of `_.before`; this method creates a function that invokes
* `func` once it's called `n` or more times.
*
* @template TFunc - The type of the function to be invoked.
* @param n - The number of calls before `func` is invoked.
* @param func - The function to restrict.
* @returns Returns the new restricted function.
* @throws {TypeError} - If `func` is not a function.
*
* @example
* const saves = ['profile', 'settings'];
* const done = after(saves.length, () => {
*   console.log('done saving!');
* });
*
* saves.forEach(type => {
*   asyncSave({ 'type': type, 'complete': done });
* });
* // => Logs 'done saving!' after the two async saves have completed.
*/
function after(n, func) {
	if (typeof func !== "function") throw new TypeError("Expected a function");
	n = toInteger(n);
	return function(...args) {
		if (--n < 1) return func.apply(this, args);
	};
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/ary.mjs
/**
* Creates a function that invokes func, with up to `n` arguments, ignoring any additional arguments.
*
* @template F - The type of the function.
* @param func - The function to cap arguments for.
* @param n - The arity cap.
* @param guard - The value to guard the arity cap.
* @returns Returns the new capped function.
*
* @example
* function fn(a: number, b: number, c: number) {
*   return Array.from(arguments);
* }
*
* ary(fn, 0)(1, 2, 3); // []
* ary(fn, 1)(1, 2, 3); // [1]
* ary(fn, 2)(1, 2, 3); // [1, 2]
* ary(fn, 3)(1, 2, 3); // [1, 2, 3]
*/
function ary(func, n = func.length, guard) {
	if (guard) n = func.length;
	if (Number.isNaN(n) || n < 0) n = 0;
	return ary$1(func, n);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/attempt.mjs
/**
* Attempts to execute a function with the provided arguments.
* If the function throws an error, it catches the error and returns it.
* If the caught error is not an instance of Error, it wraps it in a new Error.
*
* @param func - The function to be executed.
* @param args - The arguments to pass to the function.
* @returns The return value of the function if successful, or an Error if an exception is thrown.
*
* @template R - The type of the function return value.
*
* @example
* // Example 1: Successful execution
* const result = attempt((x, y) => x + y, 2, 3);
* console.log(result); // Output: 5
*
* @example
* // Example 2: Function throws an error
* const errorResult = attempt(() => {
*   throw new Error("Something went wrong");
* });
* console.log(errorResult); // Output: Error: Something went wrong
*
* @example
* // Example 3: Non-Error thrown
* const nonErrorResult = attempt(() => {
*   throw "This is a string error";
* });
* console.log(nonErrorResult); // Output: Error: This is a string error
*/
function attempt(func, ...args) {
	try {
		return func(...args);
	} catch (e) {
		return e instanceof Error ? e : new Error(e);
	}
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/before.mjs
/**
* Creates a function that invokes `func`, with the `this` binding and arguments
* of the created function, while it's called less than `n` times. Subsequent
* calls to the created function return the result of the last `func` invocation.
*
* @template F - The type of the function to be invoked.
* @param n - The number of times the returned function is allowed to call `func` before stopping.
* - If `n` is 0, `func` will never be called.
* - If `n` is a positive integer, `func` will be called up to `n-1` times.
* @param func - The function to be called with the limit applied.
* @returns A new function that:
* - Tracks the number of calls.
* - Invokes `func` until the `n-1`-th call.
* - Returns last result of `func`, if `n` is reached.
* @throws {TypeError} - If `func` is not a function.
* @example
* let count = 0;
* const before3 = before(3, () => ++count);
*
* before3(); // => 1
* before3(); // => 2
* before3(); // => 2
*/
function before(n, func) {
	if (typeof func !== "function") throw new TypeError("Expected a function");
	let result;
	n = toInteger(n);
	return function(...args) {
		if (--n > 0) result = func.apply(this, args);
		if (n <= 1 && func) func = void 0;
		return result;
	};
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/bind.mjs
/**
* Creates a function that invokes `func` with the `this` binding of `thisArg` and `partials` prepended to the arguments it receives.
*
* The `bind.placeholder` value, which defaults to a `symbol`, may be used as a placeholder for partially applied arguments.
*
* Note: Unlike native `Function#bind`, this method doesn't set the `length` property of bound functions.
*
* @param func - The function to bind.
* @param thisObj - The `this` binding of `func`.
* @param partialArgs - The arguments to be partially applied.
* @returns Returns the new bound function.
*
* @example
* function greet(greeting, punctuation) {
*   return greeting + ' ' + this.user + punctuation;
* }
* const object = { user: 'fred' };
* let bound = bind(greet, object, 'hi');
* bound('!');
* // => 'hi fred!'
*
* bound = bind(greet, object, bind.placeholder, '!');
* bound('hi');
* // => 'hi fred!'
*/
function bind(func, thisObj, ...partialArgs) {
	const bound = function(...providedArgs) {
		const args = [];
		let startIndex = 0;
		for (let i = 0; i < partialArgs.length; i++) {
			const arg = partialArgs[i];
			if (arg === bind.placeholder) args.push(providedArgs[startIndex++]);
			else args.push(arg);
		}
		for (let i = startIndex; i < providedArgs.length; i++) args.push(providedArgs[i]);
		if (this instanceof bound) return new func(...args);
		return func.apply(thisObj, args);
	};
	return bound;
}
bind.placeholder = Symbol("bind.placeholder");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/bindKey.mjs
/**
* Creates a function that invokes the method at `object[key]` with `partialArgs` prepended to the arguments it receives.
*
* This method differs from `bind` by allowing bound functions to reference methods that may be redefined or don't yet exist.
*
* The `bindKey.placeholder` value, which defaults to a `symbol`, may be used as a placeholder for partially applied arguments.
*
* @template T - The type of the object to bind.
* @template K - The type of the key to bind.
* @param object - The object to invoke the method on.
* @param key - The key of the method.
* @param partialArgs - The arguments to be partially applied.
* @returns Returns the new bound function.
*
* @example
* const object = {
*   user: 'fred',
*   greet: function (greeting, punctuation) {
*     return greeting + ' ' + this.user + punctuation;
*   },
* };
*
* let bound = bindKey(object, 'greet', 'hi');
* bound('!');
* // => 'hi fred!'
*
* object.greet = function (greeting, punctuation) {
*   return greeting + 'ya ' + this.user + punctuation;
* };
*
* bound('!');
* // => 'hiya fred!'
*
* // Bound with placeholders.
* bound = bindKey(object, 'greet', bindKey.placeholder, '!');
* bound('hi');
* // => 'hiya fred!'
*/
function bindKey(object, key, ...partialArgs) {
	const bound = function(...providedArgs) {
		const args = [];
		let startIndex = 0;
		for (let i = 0; i < partialArgs.length; i++) {
			const arg = partialArgs[i];
			if (arg === bindKey.placeholder) args.push(providedArgs[startIndex++]);
			else args.push(arg);
		}
		for (let i = startIndex; i < providedArgs.length; i++) args.push(providedArgs[i]);
		if (this instanceof bound) return new object[key](...args);
		return object[key].apply(object, args);
	};
	return bound;
}
bindKey.placeholder = Symbol("bindKey.placeholder");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/curry.mjs
/**
* Creates a function that accepts arguments of `func` and either invokes `func` returning its result, if at least `arity` number of arguments have been provided, or returns a function that accepts the remaining `func` arguments, and so on.
* The arity of `func` may be specified if `func.length` is not sufficient.
*
* The `curry.placeholder` value, which defaults to a `symbol`, may be used as a placeholder for partially applied arguments.
*
* Note: This method doesn't set the `length` property of curried functions.
*
* @param func - The function to curry.
* @param arity - The arity of func.
* @param guard - Enables use as an iteratee for methods like `Array#map`.
* @returns} - Returns the new curried function.
*
* @example
* const abc = function(a, b, c) {
*   return Array.from(arguments);
* };
*
* let curried = curry(abc);
*
* curried(1)(2)(3);
* // => [1, 2, 3]
*
* curried(1, 2)(3);
* // => [1, 2, 3]
*
* curried(1, 2, 3);
* // => [1, 2, 3]
*
* // Curried with placeholders.
* curried(1)(curry.placeholder, 3)(2);
* // => [1, 2, 3]
*
* // Curried with arity.
* curried = curry(abc, 2);
*
* curried(1)(2);
* // => [1, 2]
*/
function curry(func, arity = func.length, guard) {
	arity = guard ? func.length : arity;
	arity = Number.parseInt(arity, 10);
	if (Number.isNaN(arity) || arity < 1) arity = 0;
	const wrapper = function(...partialArgs) {
		const holders = partialArgs.filter((item) => item === curry.placeholder);
		const length = partialArgs.length - holders.length;
		if (length < arity) return makeCurry(func, arity - length, partialArgs);
		if (this instanceof wrapper) return new func(...partialArgs);
		return func.apply(this, partialArgs);
	};
	wrapper.placeholder = curryPlaceholder;
	return wrapper;
}
function makeCurry(func, arity, partialArgs) {
	function wrapper(...providedArgs) {
		const holders = providedArgs.filter((item) => item === curry.placeholder);
		const length = providedArgs.length - holders.length;
		providedArgs = composeArgs$1(providedArgs, partialArgs);
		if (length < arity) return makeCurry(func, arity - length, providedArgs);
		if (this instanceof wrapper) return new func(...providedArgs);
		return func.apply(this, providedArgs);
	}
	wrapper.placeholder = curryPlaceholder;
	return wrapper;
}
function composeArgs$1(providedArgs, partialArgs) {
	const args = [];
	let startIndex = 0;
	for (let i = 0; i < partialArgs.length; i++) {
		const arg = partialArgs[i];
		if (arg === curry.placeholder && startIndex < providedArgs.length) args.push(providedArgs[startIndex++]);
		else args.push(arg);
	}
	for (let i = startIndex; i < providedArgs.length; i++) args.push(providedArgs[i]);
	return args;
}
__name(composeArgs$1, "composeArgs");
var curryPlaceholder = Symbol("curry.placeholder");
curry.placeholder = curryPlaceholder;
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/curryRight.mjs
/**
* Creates a function that accepts arguments of `func` and either invokes `func` returning its result, if at least `arity` number of arguments have been provided, or returns a function that accepts the remaining `func` arguments, and so on.
* The arity of `func` may be specified if `func.length` is not sufficient.
*
* Unlike `curry`, this function curries the function from right to left.
*
* The `curryRight.placeholder` value, which defaults to a `symbol`, may be used as a placeholder for partially applied arguments.
*
* Note: This method doesn't set the `length` property of curried functions.
*
* @param func - The function to curry.
* @param arity - The arity of func.
* @param guard - Enables use as an iteratee for methods like `Array#map`.
* @returns} - Returns the new curried function.
*
* @example
* const abc = function(a, b, c) {
*   return Array.from(arguments);
* };
*
* let curried = curryRight(abc);
*
* curried(3)(2)(1);
* // => [1, 2, 3]
*
* curried(2, 3)(1);
* // => [1, 2, 3]
*
* curried(1, 2, 3);
* // => [1, 2, 3]
*
* // Curried with placeholders.
* curried(3)(curryRight.placeholder, 2)(1);
* // => [1, 2, 3]
*
* // Curried with arity.
* curried = curryRight(abc, 2);
*
* curried(2)(1);
* // => [1, 2]
*/
function curryRight(func, arity = func.length, guard) {
	arity = guard ? func.length : arity;
	arity = Number.parseInt(arity, 10);
	if (Number.isNaN(arity) || arity < 1) arity = 0;
	const wrapper = function(...partialArgs) {
		const holders = partialArgs.filter((item) => item === curryRight.placeholder);
		const length = partialArgs.length - holders.length;
		if (length < arity) return makeCurryRight(func, arity - length, partialArgs);
		if (this instanceof wrapper) return new func(...partialArgs);
		return func.apply(this, partialArgs);
	};
	wrapper.placeholder = curryRightPlaceholder;
	return wrapper;
}
function makeCurryRight(func, arity, partialArgs) {
	function wrapper(...providedArgs) {
		const holders = providedArgs.filter((item) => item === curryRight.placeholder);
		const length = providedArgs.length - holders.length;
		providedArgs = composeArgs(providedArgs, partialArgs);
		if (length < arity) return makeCurryRight(func, arity - length, providedArgs);
		if (this instanceof wrapper) return new func(...providedArgs);
		return func.apply(this, providedArgs);
	}
	wrapper.placeholder = curryRightPlaceholder;
	return wrapper;
}
function composeArgs(providedArgs, partialArgs) {
	const placeholderLength = partialArgs.filter((arg) => arg === curryRight.placeholder).length;
	const rangeLength = Math.max(providedArgs.length - placeholderLength, 0);
	const args = [];
	let providedIndex = 0;
	for (let i = 0; i < rangeLength; i++) args.push(providedArgs[providedIndex++]);
	for (let i = 0; i < partialArgs.length; i++) {
		const arg = partialArgs[i];
		if (arg === curryRight.placeholder) if (providedIndex < providedArgs.length) args.push(providedArgs[providedIndex++]);
		else args.push(arg);
		else args.push(arg);
	}
	return args;
}
var curryRightPlaceholder = Symbol("curryRight.placeholder");
curryRight.placeholder = curryRightPlaceholder;
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/defer.mjs
/**
* Defers invoking the `func` until the current call stack has cleared. Any additional arguments are provided to func when it's invoked.
*
* @param func The function to defer.
* @param args The arguments to invoke `func` with.
* @returns Returns the timer id.
*
* @example
* defer((text) => {
*   console.log(text);
* }, 'deferred');
* // => Logs 'deferred' after the current call stack has cleared.
*/
function defer(func, ...args) {
	if (typeof func !== "function") throw new TypeError("Expected a function");
	return setTimeout(func, 1, ...args);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/delay.mjs
/**
* Invokes the specified function after a delay of the given number of milliseconds.
* Any additional arguments are passed to the function when it is invoked.
*
* @param func - The function to delay.
* @param wait - The number of milliseconds to delay the invocation.
* @param args - The arguments to pass to the function when it is invoked.
* @returns Returns the timer id.
* @throws {TypeError} If the first argument is not a function.
*
* @example
* // Example 1: Delayed function execution
* const timerId = delay(
*   (greeting, recipient) => {
*     console.log(`${greeting}, ${recipient}!`);
*   },
*   1000,
*   'Hello',
*   'Alice'
* );
* // => 'Hello, Alice!' will be logged after one second.
*
* // Example 2: Clearing the timeout before execution
* clearTimeout(timerId);
* // The function will not be executed because the timeout was cleared.
*/
function delay(func, wait, ...args) {
	if (typeof func !== "function") throw new TypeError("Expected a function");
	return setTimeout(func, toNumber(wait) || 0, ...args);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/flip.mjs
/**
* Reverses the order of arguments for a given function.
*
* @template F - The type of the function being flipped.
* @param func - The function whose arguments will be reversed.
* @returns A new function that takes the
* reversed arguments and returns the result of calling `func`.
*
* @example
* function fn(a: string, b: string, c: string, d: string) {
*   return [a, b, c, d];
* }
*
* const flipped = flip(fn);
* flipped('a', 'b', 'c', 'd'); // => ['d', 'c', 'b', 'a']
*/
function flip(func) {
	return function(...args) {
		return func.apply(this, args.reverse());
	};
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/flow.mjs
/**
* Creates a new function that executes the given functions in sequence. The return value of the previous function is passed as an argument to the next function.
*
* The `this` context of the returned function is also passed to the functions provided as parameters.
*
* @param funcs The functions to invoke.
* @returns Returns the new composite function.
*
* @example
* const add = (x: number, y: number) => x + y;
* const square = (n: number) => n * n;
* const double = (n: number) => n * 2;
*
* const combined = flow([add, square], double);
* console.log(combined(1, 2)); // 18
*/
function flow(...funcs) {
	const flattenFuncs = flatten(funcs, 1);
	if (flattenFuncs.some((func) => typeof func !== "function")) throw new TypeError("Expected a function");
	return flow$1(...flattenFuncs);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/flowRight.mjs
/**
* Creates a new function that executes the given functions in sequence from right to left. The return value of the previous function is passed as an argument to the next function.
*
* The `this` context of the returned function is also passed to the functions provided as parameters.
*
* This method is like `flow` except that it creates a function that invokes the given functions from right to left.
*
* @param funcs The functions to invoke.
* @returns Returns the new composite function.
*
* @example
* const add = (x: number, y: number) => x + y;
* const square = (n: number) => n * n;
* const double = (n: number) => n * 2;
*
* const combined = flowRight(double, [square, add]);
* console.log(combined(1, 2)); // 18
*/
function flowRight(...funcs) {
	const flattenFuncs = flatten(funcs, 1);
	if (flattenFuncs.some((func) => typeof func !== "function")) throw new TypeError("Expected a function");
	return flowRight$1(...flattenFuncs);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/nthArg.mjs
/**
* Creates a function that retrieves the argument at the specified index `n`.
*
* If `n` is negative, the nth argument from the end is returned.
*
* @param [n=0] - The index of the argument to retrieve.
*   If negative, counts from the end of the arguments list.
* @returns A new function that returns the argument at the specified index.
*
* @example
* const getSecondArg = nthArg(1);
* const result = getSecondArg('a', 'b', 'c');
* console.log(result); // => 'b'
*
* @example
* const getLastArg = nthArg(-1);
* const result = getLastArg('a', 'b', 'c');
* console.log(result); // => 'c'
*/
function nthArg(n = 0) {
	return function(...args) {
		return args.at(toInteger(n));
	};
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/once.mjs
function once(func) {
	return once$1(func);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/overArgs.mjs
/**
* Creates a function that invokes `func` with its arguments transformed by corresponding transform functions.
*
* Transform functions can be:
* - Functions that accept and return a value
* - Property names (strings) to get a property value from each argument
* - Objects to check if arguments match the object properties
* - Arrays of [property, value] to check if argument properties match values
*
* If a transform is nullish, the identity function is used instead.
* Only transforms arguments up to the number of transform functions provided.
*
* @param func - The function to wrap
* @param transforms - The functions to transform arguments. Each transform can be:
*   - A function that accepts and returns a value
*   - A string to get a property value (e.g. 'name' gets the name property)
*   - An object to check if arguments match its properties
*   - An array of [property, value] to check property matches
* @returns A new function that transforms arguments before passing them to func
* @throws {TypeError} If func is not a function.
* @example
* ```ts
* function doubled(n: number) {
*   return n * 2;
* }
*
* function square(n: number) {
*   return n * n;
* }
*
* const func = overArgs((x, y) => [x, y], [doubled, square]);
*
* func(5, 3);
* // => [10, 9]
*
* // With property shorthand
* const user = { name: 'John', age: 30 };
* const getUserInfo = overArgs(
*   (name, age) => `${name} is ${age} years old`,
*   ['name', 'age']
* );
* getUserInfo(user, user);
* // => "John is 30 years old"
* ```
*/
function overArgs(func, ..._transforms) {
	if (typeof func !== "function") throw new TypeError("Expected a function");
	const transforms = _transforms.flat();
	return function(...args) {
		const length = Math.min(args.length, transforms.length);
		const transformedArgs = [...args];
		for (let i = 0; i < length; i++) transformedArgs[i] = iteratee(transforms[i] ?? identity$1).call(this, args[i]);
		return func.apply(this, transformedArgs);
	};
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/partial.mjs
/**
* Creates a function that invokes `func` with `partialArgs` prepended to the arguments it receives. This method is like `bind` except it does not alter the `this` binding.
*
* The partial.placeholder value, which defaults to a `symbol`, may be used as a placeholder for partially applied arguments.
*
* Note: This method doesn't set the `length` property of partially applied functions.
*
* @template F The type of the function to partially apply.
* @param func The function to partially apply arguments to.
* @param partialArgs The arguments to be partially applied.
* @returns Returns the new partially applied function.
*
* @example
* function greet(greeting, name) {
*   return greeting + ' ' + name;
* }
*
* const sayHelloTo = partial(greet, 'hello');
* sayHelloTo('fred');
* // => 'hello fred'
*
* // Partially applied with placeholders.
* const greetFred = partial(greet, partial.placeholder, 'fred');
* greetFred('hi');
* // => 'hi fred'
*/
function partial(func, ...partialArgs) {
	return partialImpl(func, partial.placeholder, ...partialArgs);
}
partial.placeholder = Symbol("compat.partial.placeholder");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/partialRight.mjs
/**
* This method is like `partial` except that partially applied arguments are appended to the arguments it receives.
*
* The partialRight.placeholder value, which defaults to a `symbol`, may be used as a placeholder for partially applied arguments.
*
* Note: This method doesn't set the `length` property of partially applied functions.
*
* @template F The type of the function to partially apply.
* @param func The function to partially apply arguments to.
* @param partialArgs The arguments to be partially applied.
* @returns Returns the new partially applied function.
*
* @example
* function greet(greeting, name) {
*   return greeting + ' ' + name;
* }
*
* const greetFred = partialRight(greet, 'fred');
* greetFred('hi');
* // => 'hi fred'
*
* // Partially applied with placeholders.
* const sayHelloTo = partialRight(greet, 'hello', partialRight.placeholder);
* sayHelloTo('fred');
* // => 'hello fred'
*/
function partialRight(func, ...partialArgs) {
	return partialRightImpl(func, partialRight.placeholder, ...partialArgs);
}
partialRight.placeholder = Symbol("compat.partialRight.placeholder");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/rearg.mjs
/**
* Creates a function that invokes `func` with arguments arranged according to the specified `indices`
* where the argument value at the first index is provided as the first argument,
* the argument value at the second index is provided as the second argument, and so on.
*
* @param func The function to rearrange arguments for.
* @param indices The arranged argument indices.
* @returns Returns the new function.
*
* @example
* const greet = (greeting: string, name: string) => `${greeting}, ${name}!`;
* const rearrangedGreet = rearg(greet, 1, 0);
* console.log(rearrangedGreet('World', 'Hello')); // Output: "Hello, World!"
*/
function rearg(func, ...indices) {
	const flattenIndices = flatten$1(indices);
	return function(...args) {
		const reorderedArgs = flattenIndices.map((i) => args[i]).slice(0, args.length);
		for (let i = reorderedArgs.length; i < args.length; i++) reorderedArgs.push(args[i]);
		return func.apply(this, reorderedArgs);
	};
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/rest.mjs
/**
* Creates a function that transforms the arguments of the provided function `func`.
* The transformed arguments are passed to `func` such that the arguments starting from a specified index
* are grouped into an array, while the previous arguments are passed as individual elements.
*
* @param func - The function whose arguments are to be transformed.
* @param [start=func.length - 1] - The index from which to start grouping the remaining arguments into an array.
*                                            Defaults to `func.length - 1`, grouping all arguments after the last parameter.
* @returns A new function that, when called, returns the result of calling `func` with the transformed arguments.
*
* The transformed arguments are:
* - The first `start` arguments as individual elements.
* - The remaining arguments from index `start` onward grouped into an array.
* @example
* function fn(a, b, c) {
*   return [a, b, c];
* }
*
* // Using default start index (func.length - 1, which is 2 in this case)
* const transformedFn = rest(fn);
* console.log(transformedFn(1, 2, 3, 4)); // [1, 2, [3, 4]]
*
* // Using start index 1
* const transformedFnWithStart = rest(fn, 1);
* console.log(transformedFnWithStart(1, 2, 3, 4)); // [1, [2, 3, 4]]
*
* // With fewer arguments than the start index
* console.log(transformedFn(1)); // [1, undefined, []]
*/
function rest(func, start = func.length - 1) {
	start = Number.parseInt(start, 10);
	if (Number.isNaN(start) || start < 0) start = func.length - 1;
	return rest$1(func, start);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/spread.mjs
/**
* Creates a new function that spreads elements of an array argument into individual arguments
* for the original function. The array argument is positioned based on the `argsIndex` parameter.
*
* @template F - A function type with any number of parameters and any return type.
* @param func - The function to be transformed. It can be any function with any number of arguments.
* @param [argsIndex=0] - The index where the array argument is positioned among the other arguments.
*   If `argsIndex` is negative or `NaN`, it defaults to `0`. If it's a fractional number, it is rounded to the nearest integer.
* @returns A new function that takes multiple arguments, including an array of arguments at the specified `argsIndex`,
*   and returns the result of calling the original function with those arguments.
*
* @example
* function add(a, b) {
*   return a + b;
* }
*
* const spreadAdd = spread(add);
* console.log(spreadAdd([1, 2])); // Output: 3
*
* @example
* // Example function to spread arguments over
* function add(a, b) {
*   return a + b;
* }
*
* // Create a new function that uses `spread` to combine arguments
* const spreadAdd = spread(add, 1);
*
* // Calling `spreadAdd` with an array as the second argument
* console.log(spreadAdd(1, [2])); // Output: 3
*
* @example
* // Function with default arguments
* function greet(name, greeting = 'Hello') {
*   return `${greeting}, ${name}!`;
* }
*
* // Create a new function that uses `spread` to position the argument array at index 0
* const spreadGreet = spread(greet, 0);
*
* // Calling `spreadGreet` with an array of arguments
* console.log(spreadGreet(['Alice'])); // Output: Hello, Alice!
* console.log(spreadGreet(['Bob', 'Hi'])); // Output: Hi, Bob!
*/
function spread(func, argsIndex = 0) {
	argsIndex = Number.parseInt(argsIndex, 10);
	if (Number.isNaN(argsIndex) || argsIndex < 0) argsIndex = 0;
	return function(...args) {
		const array = args[argsIndex];
		const params = args.slice(0, argsIndex);
		if (array) params.push(...array);
		return func.apply(this, params);
	};
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/throttle.mjs
/**
* Creates a throttled function that only invokes the provided function at most once
* per every `throttleMs` milliseconds. Subsequent calls to the throttled function
* within the wait time will not trigger the execution of the original function.
*
* @template F - The type of function.
* @param func - The function to throttle.
* @param throttleMs - The number of milliseconds to throttle executions to.
* @param options - The options object
* @param options.signal - An optional AbortSignal to cancel the throttled function.
* @param options.leading - If `true`, the function will be invoked on the leading edge of the timeout.
* @param options.trailing - If `true`, the function will be invoked on the trailing edge of the timeout.
* @returns A new throttled function that accepts the same parameters as the original function.
*
* @example
* const throttledFunction = throttle(() => {
*   console.log('Function executed');
* }, 1000);
*
* // Will log 'Function executed' immediately
* throttledFunction();
*
* // Will not log anything as it is within the throttle time
* throttledFunction();
*
* // After 1 second
* setTimeout(() => {
*   throttledFunction(); // Will log 'Function executed'
* }, 1000);
*/
function throttle(func, throttleMs = 0, options = {}) {
	const { leading = true, trailing = true } = options;
	return debounce(func, throttleMs, {
		leading,
		maxWait: throttleMs,
		trailing
	});
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/unary.mjs
/**
* Creates a function that accepts up to one argument, ignoring any additional arguments.
*
* @template F - The type of the function.
* @param func - The function to cap arguments for.
* @returns Returns the new capped function.
*
* @example
* function fn(a, b, c) {
*   console.log(arguments);
* }
*
* unary(fn)(1, 2, 3); // [Arguments] { '0': 1 }
*/
function unary(func) {
	return ary(func, 1);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/wrap.mjs
/**
* Creates a new function that wraps the given function `func`.
* In this process, you can apply additional logic defined in the `wrapper` function before and after the execution of the original function.
*
* If a `value` is provided instead of a function, this value is passed as the first argument to the `wrapper` function.
*
* @template T - The type of the value being wrapped.
* @template U - The type of the arguments being passed to the `wrapper` function.
* @template V - The type of the return value of the `wrapper` function.
* @param value - The value to be wrapped.
* @param wrapper - The function to wrap the value with.
* @returns A new function that wraps the value with the `wrapper` function.
*
* @example
* // Wrap a function
* const greet = (name: string) => `Hi, ${name}`;
* const wrapped = wrap(greet, (value, name) => `[LOG] ${value(name)}`);
* wrapped('Bob'); // => "[LOG] Hi, Bob"
*
* @example
* // Wrap a primitive value
* const wrapped = wrap('value', v => `<p>${v}</p>`);
* wrapped(); // => "<p>value</p>"
*/
function wrap(value, wrapper) {
	return function(...args) {
		return (isFunction$1(wrapper) ? wrapper : identity$1).apply(this, [value, ...args]);
	};
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/math/add.mjs
/**
* Adds two numbers while safely handling `NaN` values.
*
* This function takes two numbers and returns their sum. If either of the numbers is `NaN`,
* the function returns `NaN`.
*
* @param value - The first number to add.
* @param other - The second number to add.
* @returns The sum of the two numbers, or `NaN` if any input is `NaN`.
*
* @example
* const result1 = add(2, 3);    // result1 will be 5
* const result2 = add(5, NaN);  // result2 will be NaN
* const result3 = add(NaN, 10); // result3 will be NaN
*/
function add(value, other) {
	if (value === void 0 && other === void 0) return 0;
	if (value === void 0 || other === void 0) return value ?? other;
	if (typeof value === "string" || typeof other === "string") {
		value = toString(value);
		other = toString(other);
	} else {
		value = toNumber(value);
		other = toNumber(other);
	}
	return value + other;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/_internal/decimalAdjust.mjs
function decimalAdjust(type, number, precision = 0) {
	number = Number(number);
	if (Object.is(number, -0)) number = "-0";
	precision = Math.min(Number.parseInt(precision, 10), 292);
	if (precision && Number.isFinite(Number(number))) {
		const [magnitude, exponent = 0] = number.toString().split("e");
		let adjustedValue = Math[type](Number(`${magnitude}e${Number(exponent) + precision}`));
		if (Object.is(adjustedValue, -0)) adjustedValue = "-0";
		const [newMagnitude, newExponent = 0] = adjustedValue.toString().split("e");
		return Number(`${newMagnitude}e${Number(newExponent) - precision}`);
	}
	return Math[type](Number(number));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/math/ceil.mjs
/**
* Computes number rounded up to precision.
*
* @param number The number to round up.
* @param precision The precision to round up to.
* @returns Returns the rounded up number.
*
* @example
* ceil(4.006); // => 5
* ceil(6.004, 2); // => 6.01
* ceil(6040, -2); // => 6100
*/
function ceil(number, precision = 0) {
	return decimalAdjust("ceil", number, precision);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/math/divide.mjs
/**
* Divide two numbers.
*
* If either of the numbers is `NaN`, the function returns `NaN`.
*
* @param value The first number in a division.
* @param other The second number in a division.
* @returns The quotient of value and other.
*
* @example
* divide(6, 3); // => 2
* divide(2, NaN); // => NaN
* divide(NaN, 3); // => NaN
* divide(NaN, NaN); // => NaN
*/
function divide(value, other) {
	if (value === void 0 && other === void 0) return 1;
	if (value === void 0 || other === void 0) return value ?? other;
	if (typeof value === "string" || typeof other === "string") {
		value = toString(value);
		other = toString(other);
	} else {
		value = toNumber(value);
		other = toNumber(other);
	}
	return value / other;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/math/floor.mjs
/**
* Computes number rounded down to precision.
*
* @param number The number to round down.
* @param precision The precision to round down to.
* @returns Returns the rounded down number.
*
* @example
* floor(4.006); // => 4
* floor(0.046, 2); // => 0.04
* floor(4060, -2); // => 4000
*/
function floor(number, precision = 0) {
	return decimalAdjust("floor", number, precision);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/math/inRange.mjs
/**
* Checks if the value is within a specified range.
*
* @param value The value to check.
* @param minimum The lower bound of the range (inclusive).
* @param maximum The upper bound of the range (exclusive).
* @returns `true` if the value is within the specified range, otherwise `false`.
* @throws {Error} Throws an error if the `minimum` is greater or equal than the `maximum`.
*
* @example
* const result1 = inRange(3, 5); // result1 will be true.
* const result2 = inRange(1, 2, 5); // result2 will be false.
* const result3 = inRange(1, 5, 2); // If the minimum is greater or equal than the maximum, an error is thrown.
*/
function inRange(value, minimum, maximum) {
	if (!minimum) minimum = 0;
	if (maximum != null && !maximum) maximum = 0;
	if (minimum != null && typeof minimum !== "number") minimum = Number(minimum);
	if (maximum == null && minimum === 0) return false;
	if (maximum != null && typeof maximum !== "number") maximum = Number(maximum);
	if (maximum != null && minimum > maximum) [minimum, maximum] = [maximum, minimum];
	if (minimum === maximum) return false;
	return inRange$1(value, minimum, maximum);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/math/max.mjs
/**
* Finds the element in an array that has the maximum value.
*
* @template T - The type of elements in the array.
* @param [items] - The array of elements to search. Defaults to an empty array.
* @returns The element with the maximum value, or undefined if the array is empty.
*/
function max(items) {
	if (!items || items.length === 0) return;
	let maxResult = void 0;
	for (let i = 0; i < items.length; i++) {
		const current = items[i];
		if (current == null || Number.isNaN(current) || typeof current === "symbol") continue;
		if (maxResult === void 0 || current > maxResult) maxResult = current;
	}
	return maxResult;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/math/maxBy.mjs
/**
* Finds the element in an array that has the maximum value when applying
* the `iteratee` to each element.
*
* @template T - The type of elements in the array.
* @param items The array of elements to search.
* @param iteratee
* The criteria used to determine the maximum value.
*  - If a **function** is provided, it extracts a numeric value from each element.
*  - If a **string** is provided, it is treated as a key to extract values from the objects.
*  - If a **[key, value]** pair is provided, it matches elements with the specified key-value pair.
*  - If an **object** is provided, it matches elements that contain the specified properties.
* @returns The element with the maximum value as determined by the `iteratee`.
* @example
* maxBy([{ a: 1 }, { a: 2 }, { a: 3 }], x => x.a); // Returns: { a: 3 }
* maxBy([], x => x.a); // Returns: undefined
* maxBy(
*   [
*     { name: 'john', age: 30 },
*     { name: 'jane', age: 28 },
*     { name: 'joe', age: 26 },
*   ],
*   x => x.age
* ); // Returns: { name: 'john', age: 30 }
* maxBy([{ a: 1 }, { a: 2 }], 'a'); // Returns: { a: 2 }
* maxBy([{ a: 1 }, { a: 2 }], ['a', 1]); // Returns: { a: 1 }
* maxBy([{ a: 1 }, { a: 2 }], { a: 1 }); // Returns: { a: 1 }
*/
function maxBy(items, iteratee$1) {
	if (items == null) return;
	return maxBy$1(Array.from(items), iteratee(iteratee$1 ?? identity$1));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/math/sumBy.mjs
/**
* Computes the sum of the values that are returned by the `iteratee` function.
*
* It does not coerce values to `number`.
*
* @template T - The type of the array elements.
* @param array - The array to iterate over.
* @param iteratee - The function invoked per iteration.
* @returns Returns the sum.
*
* @example
* sumBy([1, undefined, 2], value => value); // => 3
* sumBy(null); // => 0
* sumBy(undefined); // => 0
* sumBy([1, 2, 3]); // => 6
* sumBy([1n, 2n, 3n]); // => 6n
* sumBy([{ a: "1" }, { a: "2" }], object => object.a); // => "12"
*/
function sumBy(array, iteratee$1) {
	if (!array || !array.length) return 0;
	if (iteratee$1 != null) iteratee$1 = iteratee(iteratee$1);
	let result = void 0;
	for (let i = 0; i < array.length; i++) {
		const current = iteratee$1 ? iteratee$1(array[i]) : array[i];
		if (current !== void 0) if (result === void 0) result = current;
		else result += current;
	}
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/math/sum.mjs
/**
* Computes the sum of the values that are returned by the `iteratee` function.
*
* It does not coerce values to `number`.
*
* @param array - The array to iterate over.
* @returns Returns the sum.
*
* @example
* sum([1, 2, 3]); // => 6
* sum([1n, 2n, 3n]); // => 6n
* sum(["1", "2"]); // => "12"
* sum([1, undefined, 2]); // => 3
* sum(null); // => 0
* sum(undefined); // => 0
*/
function sum(array) {
	return sumBy(array);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/math/mean.mjs
/**
* Calculates the average of an array of numbers.
*
* If the array is empty, this function returns `NaN`.
*
* @param nums - An array of numbers to calculate the average.
* @returns The average of all the numbers in the array.
*
* @example
* const numbers = [1, 2, 3, 4, 5];
* const result = mean(numbers);
* // result will be 3
*/
function mean(nums) {
	const length = nums ? nums.length : 0;
	return length === 0 ? NaN : sum(nums) / length;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/math/meanBy.mjs
/**
* Calculates the average of an array of numbers when applying
* the `iteratee` function to each element.
*
* If the array is empty, this function returns `NaN`.
*
* @template T - The type of elements in the array.
* @param items An array to calculate the average.
* @param iteratee
* The criteria used to determine the maximum value.
*  - If a **function** is provided, it extracts a numeric value from each element.
*  - If a **string** is provided, it is treated as a key to extract values from the objects.
*  - If a **[key, value]** pair is provided, it matches elements with the specified key-value pair.
*  - If an **object** is provided, it matches elements that contain the specified properties.
* @returns The average of all the numbers as determined by the `iteratee` function.
*
* @example
* meanBy([{ a: 1 }, { a: 2 }, { a: 3 }], x => x.a); // Returns: 2
* meanBy([], x => x.a); // Returns: NaN
* meanBy([[2], [3], [1]], 0); // Returns: 2
* meanBy([{ a: 2 }, { a: 3 }, { a: 1 }], 'a'); // Returns: 2
*/
function meanBy(items, iteratee$1) {
	if (items == null) return NaN;
	return meanBy$1(Array.from(items), iteratee(iteratee$1 ?? identity$1));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/math/min.mjs
/**
* Finds the element in an array that has the minimum value.
*
* @template T - The type of elements in the array.
* @param [items] - The array of elements to search. Defaults to an empty array.
* @returns The element with the minimum value, or undefined if the array is empty.
*/
function min(items) {
	if (!items || items.length === 0) return;
	let minResult = void 0;
	for (let i = 0; i < items.length; i++) {
		const current = items[i];
		if (current == null || Number.isNaN(current) || typeof current === "symbol") continue;
		if (minResult === void 0 || current < minResult) minResult = current;
	}
	return minResult;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/math/minBy.mjs
/**
* Finds the element in an array that has the minimum value when applying
* the `iteratee` to each element.
*
* @template T - The type of elements in the array.
* @param items The array of elements to search.
* @param iteratee
* The criteria used to determine the minimum value.
*  - If a **function** is provided, it extracts a numeric value from each element.
*  - If a **string** is provided, it is treated as a key to extract values from the objects.
*  - If a **[key, value]** pair is provided, it matches elements with the specified key-value pair.
*  - If an **object** is provided, it matches elements that contain the specified properties.
* @returns The element with the minimum value as determined by the `iteratee`.
* @example
* minBy([{ a: 1 }, { a: 2 }, { a: 3 }], x => x.a); // Returns: { a: 1 }
* minBy([], x => x.a); // Returns: undefined
* minBy(
*   [
*     { name: 'john', age: 30 },
*     { name: 'jane', age: 28 },
*     { name: 'joe', age: 26 },
*   ],
*   x => x.age
* ); // Returns: { name: 'joe', age: 26 }
* minBy([{ a: 1 }, { a: 2 }], 'a'); // Returns: { a: 1 }
* minBy([{ a: 1 }, { a: 2 }], ['a', 1]); // Returns: { a: 2 }
* minBy([{ a: 1 }, { a: 2 }], { a: 1 }); // Returns: { a: 2 }
*/
function minBy(items, iteratee$1) {
	if (items == null) return;
	return minBy$1(Array.from(items), iteratee(iteratee$1 ?? identity$1));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/math/multiply.mjs
/**
* Multiply two numbers.
*
* If either of the numbers is `NaN`, the function returns `NaN`.
*
* @param value The first number in a multiplication
* @param other The second number in a multiplication
* @returns The product of value and other
*
* @example
* multiply(2, 3); // => 6
* multiply(2, NaN); // => NaN
* multiply(NaN, 3); // => NaN
* multiply(NaN, NaN); // => NaN
*/
function multiply(value, other) {
	if (value === void 0 && other === void 0) return 1;
	if (value === void 0 || other === void 0) return value ?? other;
	if (typeof value === "string" || typeof other === "string") {
		value = toString(value);
		other = toString(other);
	} else {
		value = toNumber(value);
		other = toNumber(other);
	}
	return value * other;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/math/parseInt.mjs
/**
* Converts `string` to an integer of the specified radix. If `radix` is undefined or 0, a `radix` of 10 is used unless `string` is a hexadecimal, in which case a `radix` of 16 is used.
*
* @param string The string to convert to an integer.
* @param radix The radix to use when converting the string to an integer. Defaults to `0`.
* @param guard Enables use as an iteratee for methods like `Array#map`.
* @returns Returns the converted integer.
*
* @example
* parseInt('08'); // => 8
* parseInt('0x20'); // => 32
*
* parseInt('08', 10); // => 8
* parseInt('0x20', 16); // => 32
*
* ['6', '08', '10'].map(parseInt); // => [6, 8, 10]
*/
function parseInt$1(string, radix = 0, guard) {
	if (guard) radix = 0;
	return Number.parseInt(toString(string), radix);
}
__name(parseInt$1, "parseInt");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/math/random.mjs
/**
* Generate a random number within the given range.
*
* @param minimum - The lower bound (inclusive).
* @param maximum - The upper bound (exclusive).
* @returns A random number between minimum (inclusive) and maximum (exclusive). The number can be an integer or a decimal.
* @throws {Error} Throws an error if `maximum` is not greater than `minimum`.
*
* @example
* const result1 = random(0, 5); // Returns a random number between 0 and 5.
* const result2 = random(5, 0); // If the minimum is greater than the maximum, an error is thrown.
* const result3 = random(5, 5); // If the minimum is equal to the maximum, an error is thrown.
*/
function random(...args) {
	let minimum = 0;
	let maximum = 1;
	let floating = false;
	switch (args.length) {
		case 1:
			if (typeof args[0] === "boolean") floating = args[0];
			else maximum = args[0];
			break;
		case 2: if (typeof args[1] === "boolean") {
			maximum = args[0];
			floating = args[1];
			break;
		} else {
			minimum = args[0];
			maximum = args[1];
		}
		case 3: if (typeof args[2] === "object" && args[2] != null && args[2][args[1]] === args[0]) {
			minimum = 0;
			maximum = args[0];
			floating = false;
		} else {
			minimum = args[0];
			maximum = args[1];
			floating = args[2];
		}
	}
	if (typeof minimum !== "number") minimum = Number(minimum);
	if (typeof maximum !== "number") maximum = Number(maximum);
	if (!minimum) minimum = 0;
	if (!maximum) maximum = 0;
	if (minimum > maximum) [minimum, maximum] = [maximum, minimum];
	if (!floating && (!Number.isInteger(minimum) || !Number.isInteger(maximum))) floating = true;
	minimum = clamp(minimum, -Number.MAX_SAFE_INTEGER, Number.MAX_SAFE_INTEGER);
	maximum = clamp(maximum, -Number.MAX_SAFE_INTEGER, Number.MAX_SAFE_INTEGER);
	if (minimum === maximum) return minimum;
	if (floating) return random$1(minimum, maximum);
	else return randomInt(minimum, maximum + 1);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/math/range.mjs
/**
* Returns an array of numbers from `start` (inclusive) to `end` (exclusive), incrementing by `step`.
*
* @param start - The starting number of the range (inclusive).
* @param end - The end number of the range (exclusive).
* @param step - The step value for the range.
* @returns An array of numbers from `start` (inclusive) to `end` (exclusive) with the specified `step`.
*
* @example
* // Returns [0, 1, 2, 3]
* range(4);
*
* @example
* // Returns [0, -1, -2, -3]
* range(0, -4, -1);
*/
function range(start, end, step) {
	if (step && typeof step !== "number" && isIterateeCall(start, end, step)) end = step = void 0;
	start = toFinite(start);
	if (end === void 0) {
		end = start;
		start = 0;
	} else end = toFinite(end);
	step = step === void 0 ? start < end ? 1 : -1 : toFinite(step);
	const length = Math.max(Math.ceil((end - start) / (step || 1)), 0);
	const result = new Array(length);
	for (let index = 0; index < length; index++) {
		result[index] = start;
		start += step;
	}
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/math/rangeRight.mjs
/**
* Returns an array of numbers from `end` (exclusive) to `start` (inclusive), decrementing by `step`.
*
* @param start - The starting number of the range (inclusive).
* @param end - The end number of the range (exclusive).
* @param step - The step value for the range.
* @returns An array of numbers from `end` (exclusive) to `start` (inclusive) with the specified `step`.
* @throws {Error} Throws an error if the step value is not a non-zero integer.
*
* @example
* // Returns [3, 2, 1, 0]
* rangeRight(4);
*
* @example
* // Returns [-3, -2, -1, 0]
* rangeRight(0, -4, -1);
*/
function rangeRight(start, end, step) {
	if (step && typeof step !== "number" && isIterateeCall(start, end, step)) end = step = void 0;
	start = toFinite(start);
	if (end === void 0) {
		end = start;
		start = 0;
	} else end = toFinite(end);
	step = step === void 0 ? start < end ? 1 : -1 : toFinite(step);
	const length = Math.max(Math.ceil((end - start) / (step || 1)), 0);
	const result = new Array(length);
	for (let index = length - 1; index >= 0; index--) {
		result[index] = start;
		start += step;
	}
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/math/round.mjs
/**
* Computes number rounded to precision.
*
* @param number  The number to round.
* @param precision The precision to round to.
* @returns Returns the rounded number.
*
* @example
* round(4.006); // => 4
* round(4.006, 2); // => 4.01
* round(4060, -2); // => 4100
*/
function round(number, precision = 0) {
	return decimalAdjust("round", number, precision);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/math/subtract.mjs
/**
* Subtracts one number from another.
*
* If either of the numbers is `NaN`, the function returns `NaN`.
*
* @param value The first number. (minuend)
* @param other The second number.(subtrahend)
* @returns The difference of the two numbers, or `NaN` if any input is `NaN`.
*
* @example
* subtract(6, 3); // => 3
* subtract(6, NaN); // => NaN
* subtract(NaN, 3); // => NaN
*/
function subtract(value, other) {
	if (value === void 0 && other === void 0) return 0;
	if (value === void 0 || other === void 0) return value ?? other;
	if (typeof value === "string" || typeof other === "string") {
		value = toString(value);
		other = toString(other);
	} else {
		value = toNumber(value);
		other = toNumber(other);
	}
	return value - other;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/function/noop.mjs
/**
* A no-operation function that does nothing.
* This can be used as a placeholder or default function.
*
* @example
* noop(); // Does nothing
*
* @returns This function does not return anything.
*/
function noop(..._) {}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/times.mjs
/**
* Invokes the getValue function n times, returning an array of the results.
*
* @template R The return type of the getValue function.
* @param n - The number of times to invoke getValue.
* @param getValue - The function to invoke for each index.
* @returns An array containing the results of invoking getValue n times.
* @example
* times(3, (i) => i * 2); // => [0, 2, 4]
* times(2, () => 'es-toolkit'); // => ['es-toolkit', 'es-toolkit']
*/
function times(n, getValue) {
	n = toInteger(n);
	if (n < 1 || !Number.isSafeInteger(n)) return [];
	const result = new Array(n);
	for (let i = 0; i < n; i++) result[i] = typeof getValue === "function" ? getValue(i) : i;
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/keys.mjs
/**
* Creates an array of the own enumerable property names of `object`.
*
* Non-object values are coerced to objects.
*
* @param object The object to query.
* @returns Returns the array of property names.
* @example
* function Foo() {
*   this.a = 1;
*   this.b = 2;
* }
* Foo.prototype.c = 3;
* keys(new Foo); // ['a', 'b'] (iteration order is not guaranteed)
*
* keys('hi'); // ['0', '1']
* keys([1, 2, 3]); // ['0', '1', '2']
* keys({ a: 1, b: 2 }); // ['a', 'b']
*/
function keys(object) {
	if (isArrayLike(object)) return arrayLikeKeys(object);
	const result = Object.keys(Object(object));
	if (!isPrototype(object)) return result;
	return result.filter((key) => key !== "constructor");
}
function arrayLikeKeys(object) {
	const indices = times(object.length, (index) => `${index}`);
	const filteredKeys = new Set(indices);
	if (isBuffer$1(object)) {
		filteredKeys.add("offset");
		filteredKeys.add("parent");
	}
	if (isTypedArray(object)) {
		filteredKeys.add("buffer");
		filteredKeys.add("byteLength");
		filteredKeys.add("byteOffset");
	}
	const inheritedKeys = Object.keys(object).filter((key) => !filteredKeys.has(key));
	if (Array.isArray(object)) return [...indices, ...inheritedKeys];
	return [...indices.filter((index) => Object.hasOwn(object, index)), ...inheritedKeys];
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/assign.mjs
/**
* Assigns properties from multiple source objects to a target object.
*
* This function merges the properties of the source objects into the target object.
* If a property in the source objects is equal to the corresponding property in the target object,
* it will not be overwritten.
*
* @param object - The target object to which properties will be assigned.
* @param sources - The source objects whose properties will be assigned to the target object.
* @returns The updated target object with properties from the source objects assigned.
*
* @example
* const target = { a: 1 };
* const result = assign(target, { b: 2 }, { c: 3 });
* console.log(result); // Output: { a: 1, b: 2, c: 3 }
*/
function assign(object, ...sources) {
	for (let i = 0; i < sources.length; i++) assignImpl(object, sources[i]);
	return object;
}
function assignImpl(object, source) {
	const keys$1 = keys(source);
	for (let i = 0; i < keys$1.length; i++) {
		const key = keys$1[i];
		if (!(key in object) || !isEqualsSameValueZero(object[key], source[key])) object[key] = source[key];
	}
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/keysIn.mjs
/**
* This function retrieves the names of string-keyed properties from an object, including those inherited from its prototype.
*
* - If the value is not an object, it is converted to an object.
* - Array-like objects are treated like arrays.
* - Sparse arrays with some missing indices are treated like dense arrays.
* - If the value is `null` or `undefined`, an empty array is returned.
* - When handling prototype objects, the `constructor` property is excluded from the results.
*
* @param [object] - The object to inspect for keys.
* @returns An array of string keys from the object.
*
* @example
* const obj = { a: 1, b: 2 };
* console.log(keysIn(obj)); // ['a', 'b']
*
* const arr = [1, 2, 3];
* console.log(keysIn(arr)); // ['0', '1', '2']
*
* function Foo() {}
* Foo.prototype.a = 1;
* console.log(keysIn(new Foo())); // ['a']
*/
function keysIn(object) {
	if (object == null) return [];
	switch (typeof object) {
		case "object":
		case "function":
			if (isArrayLike(object)) return arrayLikeKeysIn(object);
			if (isPrototype(object)) return prototypeKeysIn(object);
			return keysInImpl(object);
		default: return keysInImpl(Object(object));
	}
}
function keysInImpl(object) {
	const result = [];
	for (const key in object) result.push(key);
	return result;
}
function prototypeKeysIn(object) {
	return keysInImpl(object).filter((key) => key !== "constructor");
}
function arrayLikeKeysIn(object) {
	const indices = times(object.length, (index) => `${index}`);
	const filteredKeys = new Set(indices);
	if (isBuffer$1(object)) {
		filteredKeys.add("offset");
		filteredKeys.add("parent");
	}
	if (isTypedArray(object)) {
		filteredKeys.add("buffer");
		filteredKeys.add("byteLength");
		filteredKeys.add("byteOffset");
	}
	const inheritedKeys = keysInImpl(object).filter((key) => !filteredKeys.has(key));
	if (Array.isArray(object)) return [...indices, ...inheritedKeys];
	return [...indices.filter((index) => Object.hasOwn(object, index)), ...inheritedKeys];
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/assignIn.mjs
/**
* Assigns properties from multiple source objects to a target object.
*
* This function merges the properties of the source objects into the target object,
* including properties from the prototype chain. If a property in the source objects
* is equal to the corresponding property in the target object, it will not be overwritten.
*
* @param object - The target object to which properties will be assigned.
* @param sources - The source objects whose properties will be assigned to the target object.
* @returns The updated target object with properties from the source objects assigned.
*
* @example
* const target = { a: 1 };
* const result = assignIn(target, { b: 2 }, { c: 3 });
* console.log(result); // Output: { a: 1, b: 2, c: 3 }
*/
function assignIn(object, ...sources) {
	for (let i = 0; i < sources.length; i++) assignInImpl(object, sources[i]);
	return object;
}
function assignInImpl(object, source) {
	const keys = keysIn(source);
	for (let i = 0; i < keys.length; i++) {
		const key = keys[i];
		if (!(key in object) || !isEqualsSameValueZero(object[key], source[key])) object[key] = source[key];
	}
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/assignInWith.mjs
/**
* Assigns properties from multiple source objects to a target object.
* You can provide a `getValueToAssign` function to determine what value will be assigned for each property.
*
* This function merges the properties of the source objects into the target object,
* including properties from the prototype chain. If a property in the source objects
* is equal to the corresponding property in the target object, it will not be overwritten.
*
* Unlike `assignIn`, this method accepts a `getValueToAssign` function that determines
* the final value to be assigned to each property in the target object. The return value
* of this function will be directly assigned to the corresponding property. This allows for
* more precise control over how properties are merged between objects. If not provided,
* the default behavior is equivalent to using the identity function (returning the source value).
*
* @param object - The target object to which properties will be assigned.
* @param sources - The source objects whose properties will be assigned to the target object.
* @returns The updated target object with properties from the source objects assigned.
*
* @example
* const target = { a: 1 };
* const result = assignInWith(target, { b: 2 }, { c: 3 }, function(objValue, srcValue) {
*   return objValue === undefined ? srcValue : objValue;
* });
* console.log(result); // Output: { a: 1, b: 2, c: 3 }
*/
function assignInWith(object, ...sources) {
	let getValueToAssign = sources[sources.length - 1];
	if (typeof getValueToAssign === "function") sources.pop();
	else getValueToAssign = void 0;
	for (let i = 0; i < sources.length; i++) assignInWithImpl(object, sources[i], getValueToAssign);
	return object;
}
function assignInWithImpl(object, source, getValueToAssign) {
	const keys = keysIn(source);
	for (let i = 0; i < keys.length; i++) {
		const key = keys[i];
		const objValue = object[key];
		const srcValue = source[key];
		const newValue = getValueToAssign?.(objValue, srcValue, key, object, source) ?? srcValue;
		if (!(key in object) || !isEqualsSameValueZero(objValue, newValue)) object[key] = newValue;
	}
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/assignWith.mjs
/**
* Assigns properties from multiple source objects to a target object.
* You can provide a `getValueToAssign` function to determine what value will be assigned for each property.
*
* This function merges the properties of the source objects into the target object.
* If a property in the source objects is equal to the corresponding property in the target object,
* it will not be overwritten.
*
* Unlike `assign`, this method accepts a `getValueToAssign` function that determines
* the final value to be assigned to each property in the target object. The return value
* of this function will be directly assigned to the corresponding property. This allows for
* more precise control over how properties are merged between objects. If not provided,
* the default behavior is equivalent to using the identity function (returning the source value).
*
* @param object - The target object to which properties will be assigned.
* @param sources - The source objects whose properties will be assigned to the target object.
* @returns The updated target object with properties from the source objects assigned.
*
* @example
* const target = { a: 1 };
* const result = assignWith(target, { b: 2 }, { c: 3 }, function(objValue, srcValue) {
*   return objValue === undefined ? srcValue : objValue;
* });
* console.log(result); // Output: { a: 1, b: 2, c: 3 }
*/
function assignWith(object, ...sources) {
	let getValueToAssign = sources[sources.length - 1];
	if (typeof getValueToAssign === "function") sources.pop();
	else getValueToAssign = void 0;
	for (let i = 0; i < sources.length; i++) assignWithImpl(object, sources[i], getValueToAssign);
	return object;
}
function assignWithImpl(object, source, getValueToAssign) {
	const keys$1 = keys(source);
	for (let i = 0; i < keys$1.length; i++) {
		const key = keys$1[i];
		const objValue = object[key];
		const srcValue = source[key];
		const newValue = getValueToAssign?.(objValue, srcValue, key, object, source) ?? srcValue;
		if (!(key in object) || !isEqualsSameValueZero(objValue, newValue)) object[key] = newValue;
	}
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/clone.mjs
/**
* Creates a shallow clone of the given object.
*
* @template T - The type of the object.
* @param obj - The object to clone.
* @returns A shallow clone of the given object.
*
* @example
* // Clone a primitive object
* const num = 29;
* const clonedNum = clone(num);
* console.log(clonedNum); // 29
* console.log(clonedNum === num); // true
*
* @example
* // Clone an array
* const arr = [1, 2, 3];
* const clonedArr = clone(arr);
* console.log(clonedArr); // [1, 2, 3]
* console.log(clonedArr === arr); // false
*
* @example
* // Clone an object
* const obj = { a: 1, b: 'es-toolkit', c: [1, 2, 3] };
* const clonedObj = clone(obj);
* console.log(clonedObj); // { a: 1, b: 'es-toolkit', c: [1, 2, 3] }
* console.log(clonedObj === obj); // false
*/
function clone$1(obj) {
	if (isPrimitive(obj)) return obj;
	const tag = getTag(obj);
	if (!isCloneableObject(obj)) return {};
	if (isArray(obj)) {
		const result = Array.from(obj);
		if (obj.length > 0 && typeof obj[0] === "string" && Object.hasOwn(obj, "index")) {
			result.index = obj.index;
			result.input = obj.input;
		}
		return result;
	}
	if (isTypedArray(obj)) {
		const typedArray = obj;
		const Ctor = typedArray.constructor;
		return new Ctor(typedArray.buffer, typedArray.byteOffset, typedArray.length);
	}
	if (tag === "[object ArrayBuffer]") return new ArrayBuffer(obj.byteLength);
	if (tag === "[object DataView]") {
		const dataView = obj;
		const buffer = dataView.buffer;
		const byteOffset = dataView.byteOffset;
		const byteLength = dataView.byteLength;
		const clonedBuffer = new ArrayBuffer(byteLength);
		const srcView = new Uint8Array(buffer, byteOffset, byteLength);
		new Uint8Array(clonedBuffer).set(srcView);
		return new DataView(clonedBuffer);
	}
	if (tag === "[object Boolean]" || tag === "[object Number]" || tag === "[object String]") {
		const Ctor = obj.constructor;
		const clone = new Ctor(obj.valueOf());
		if (tag === "[object String]") cloneStringObjectProperties(clone, obj);
		else copyOwnProperties(clone, obj);
		return clone;
	}
	if (tag === "[object Date]") return new Date(Number(obj));
	if (tag === "[object RegExp]") {
		const regExp = obj;
		const clone = new RegExp(regExp.source, regExp.flags);
		clone.lastIndex = regExp.lastIndex;
		return clone;
	}
	if (tag === "[object Symbol]") return Object(Symbol.prototype.valueOf.call(obj));
	if (tag === "[object Map]") {
		const map = obj;
		const result = /* @__PURE__ */ new Map();
		map.forEach((obj, key) => {
			result.set(key, obj);
		});
		return result;
	}
	if (tag === "[object Set]") {
		const set = obj;
		const result = /* @__PURE__ */ new Set();
		set.forEach((obj) => {
			result.add(obj);
		});
		return result;
	}
	if (tag === "[object Arguments]") {
		const args = obj;
		const result = {};
		copyOwnProperties(result, args);
		result.length = args.length;
		result[Symbol.iterator] = args[Symbol.iterator];
		return result;
	}
	const result = {};
	copyPrototype(result, obj);
	copyOwnProperties(result, obj);
	copySymbolProperties(result, obj);
	return result;
}
__name(clone$1, "clone");
function isCloneableObject(object) {
	switch (getTag(object)) {
		case argumentsTag:
		case arrayTag:
		case arrayBufferTag:
		case dataViewTag:
		case booleanTag:
		case dateTag:
		case float32ArrayTag:
		case float64ArrayTag:
		case int8ArrayTag:
		case int16ArrayTag:
		case int32ArrayTag:
		case mapTag:
		case numberTag:
		case objectTag:
		case regexpTag:
		case setTag:
		case stringTag:
		case symbolTag:
		case uint8ArrayTag:
		case uint8ClampedArrayTag:
		case uint16ArrayTag:
		case uint32ArrayTag: return true;
		default: return false;
	}
}
function copyOwnProperties(target, source) {
	for (const key in source) if (Object.hasOwn(source, key)) target[key] = source[key];
}
function copySymbolProperties(target, source) {
	const symbols = Object.getOwnPropertySymbols(source);
	for (let i = 0; i < symbols.length; i++) {
		const symbol = symbols[i];
		if (Object.prototype.propertyIsEnumerable.call(source, symbol)) target[symbol] = source[symbol];
	}
}
function cloneStringObjectProperties(target, source) {
	const stringLength = source.valueOf().length;
	for (const key in source) if (Object.hasOwn(source, key) && (Number.isNaN(Number(key)) || Number(key) >= stringLength)) target[key] = source[key];
}
function copyPrototype(target, source) {
	const proto = Object.getPrototypeOf(source);
	if (proto !== null) {
		if (typeof source.constructor === "function") Object.setPrototypeOf(target, proto);
	}
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/cloneWith.mjs
/**
* Creates a shallow clone of the given object with customization.
* This method is like `_.clone` except that it accepts a customizer which
* is invoked to produce the cloned value. If customizer returns undefined,
* cloning is handled by the method instead.
*
* If no customizer is provided, it behaves like `clone`.
*
* @template T - The type of the object.
* @param value - The value to clone.
* @param [customizer] - The function to customize cloning.
* @returns A shallow clone of the given object.
*
* @example
* // Clone a primitive value
* const num = 29;
* const clonedNum = cloneWith(num);
* console.log(clonedNum); // 29
* console.log(clonedNum === num); // true
*
* @example
* // Clone an array
* const arr = [1, 2, 3];
* const clonedArr = cloneWith(arr);
* console.log(clonedArr); // [1, 2, 3]
* console.log(clonedArr === arr); // false
*
* @example
* // Clone an object
* const obj = { a: 1, b: 'es-toolkit', c: [1, 2, 3] };
* const clonedObj = cloneWith(obj);
* console.log(clonedObj); // { a: 1, b: 'es-toolkit', c: [1, 2, 3] }
* console.log(clonedObj === obj); // false
*
* @example
* // Clone an object with a customizer
* const obj = { a: 1, b: 2 };
* const clonedObj = cloneWith(obj, (value) => {
*   if (typeof value === 'number') {
*     return value * 2; // Double the number
*   }
*   // Returning undefined uses the default cloning
* });
* console.log(clonedObj); // { a: 2, b: 4 }
*/
function cloneWith(value, customizer) {
	if (!customizer) return clone$1(value);
	const result = customizer(value);
	if (result !== void 0) return result;
	return clone$1(value);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/create.mjs
/**
* Creates an object that inherits from the prototype object.
*
* If `properties` are provided, they will be added to the new object.
* Only string-keyed enumerable properties directly owned by the `properties` object are copied.
* Inherited properties or those with `Symbol` keys are not copied.
*
* @template T - The prototype object type.
* @template U - The properties object type.
* @param prototype - The object to inherit from.
* @param properties - The properties to assign to the created object.
* @returns The new object.
*/
function create(prototype, properties) {
	const proto = isObject(prototype) ? Object.create(prototype) : {};
	if (properties != null) {
		const propsKeys = keys(properties);
		for (let i = 0; i < propsKeys.length; i++) {
			const key = propsKeys[i];
			const propsValue = properties[key];
			assignValue(proto, key, propsValue);
		}
	}
	return proto;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/defaults.mjs
/**
* Assigns default values to an `object`, ensuring that certain properties do not remain `undefined`.
* It sets default values for properties that are either `undefined` or inherited from `Object.prototype`.
*
* You can pass in multiple objects to define these default values,
* and they will be applied in order from left to right.
* Once a property has been assigned a value, any subsequent values for that property will be ignored.
*
* Note: This function modifies the first argument, `object`. If you want to keep `object` unchanged, consider using `toDefaulted` instead.
*
* @template T - The type of the object being processed.
* @template S - The type of the objects that provides default values.
* @param object - The target object that will receive default values.
* @param source - The objects that specifies the default values to apply.
* @returns The `object` that has been updated with default values from `sources`, ensuring that all properties are defined and none are left as `undefined`.
*
* @example
* defaults({ a: 1 }, { a: 2, b: 2 }, { c: 3 }); // { a: 1, b: 2, c: 3 }
* defaults({ a: 1, b: 2 }, { b: 3 }, { c: 3 }); // { a: 1, b: 2, c: 3 }
* defaults({ a: null }, { a: 1 }); // { a: null }
* defaults({ a: undefined }, { a: 1 }); // { a: 1 }
*/
function defaults(object, ...sources) {
	object = Object(object);
	const objectProto = Object.prototype;
	let length = sources.length;
	const guard = length > 2 ? sources[2] : void 0;
	if (guard && isIterateeCall(sources[0], sources[1], guard)) length = 1;
	for (let i = 0; i < length; i++) {
		if (isNil$1(sources[i])) continue;
		const source = sources[i];
		const keys = Object.keys(source);
		for (let j = 0; j < keys.length; j++) {
			const key = keys[j];
			const value = object[key];
			if (value === void 0 || !Object.hasOwn(object, key) && isEqualsSameValueZero(value, objectProto[key])) object[key] = source[key];
		}
	}
	return object;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/defaultsDeep.mjs
/**
* Recursively assigns default values to an `object`, ensuring that certain properties do not remain `undefined`.
* It sets default values for properties that are either `undefined` or inherited from `Object.prototype`.
*
* Similar to `defaults` but recursively applies default values to nested objects.
* Source objects are applied in order from left to right, and once a property has been assigned a value,
* any subsequent values for that property will be ignored.
*
* Note: This function modifies the first argument, `object`.
*
* @template T - The type of the object being processed.
* @param target - The target object that will receive default values.
* @param sources - One or more source objects that specify default values to apply.
* @returns The `object` that has been updated with default values from all sources, recursively merging nested objects.
*
* @example
* defaultsDeep({ a: { b: 2 } }, { a: { b: 3, c: 3 }, d: 4 }); // { a: { b: 2, c: 3 }, d: 4 }
* defaultsDeep({ a: { b: undefined } }, { a: { b: 1 } }); // { a: { b: 1 } }
* defaultsDeep({ a: null }, { a: { b: 1 } }); // { a: null }
*/
function defaultsDeep(target, ...sources) {
	target = Object(target);
	for (let i = 0; i < sources.length; i++) {
		const source = sources[i];
		if (source != null) defaultsDeepRecursive(target, source, /* @__PURE__ */ new WeakMap());
	}
	return target;
}
function defaultsDeepRecursive(target, source, stack) {
	for (const key in source) {
		const sourceValue = source[key];
		const targetValue = target[key];
		if (targetValue === void 0 || !Object.hasOwn(target, key)) {
			target[key] = handleMissingProperty(sourceValue, stack);
			continue;
		}
		if (stack.get(sourceValue) === targetValue) continue;
		handleExistingProperty(targetValue, sourceValue, stack);
	}
}
function handleMissingProperty(sourceValue, stack) {
	if (stack.has(sourceValue)) return stack.get(sourceValue);
	if (isPlainObject(sourceValue)) {
		const newObj = {};
		stack.set(sourceValue, newObj);
		defaultsDeepRecursive(newObj, sourceValue, stack);
		return newObj;
	}
	return sourceValue;
}
function handleExistingProperty(targetValue, sourceValue, stack) {
	if (isPlainObject(targetValue) && isPlainObject(sourceValue)) {
		stack.set(sourceValue, targetValue);
		defaultsDeepRecursive(targetValue, sourceValue, stack);
		return;
	}
	if (Array.isArray(targetValue) && Array.isArray(sourceValue)) {
		stack.set(sourceValue, targetValue);
		mergeArrays(targetValue, sourceValue, stack);
	}
}
function mergeArrays(targetArray, sourceArray, stack) {
	const minLength = Math.min(sourceArray.length, targetArray.length);
	for (let i = 0; i < minLength; i++) if (isPlainObject(targetArray[i]) && isPlainObject(sourceArray[i])) defaultsDeepRecursive(targetArray[i], sourceArray[i], stack);
	for (let i = minLength; i < sourceArray.length; i++) targetArray.push(sourceArray[i]);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/findKey.mjs
/**
* Finds the key of the first element that matches the given predicate.
*
* This function determines the type of the predicate and delegates the search
* to the appropriate helper function. It supports predicates as functions, objects,
* arrays, or strings.
*
* @template T - The type of the object.
* @param obj - The object to inspect.
* @param predicate - The predicate to match.
* @returns Returns the key of the matched element, else `undefined`.
*/
function findKey(obj, predicate) {
	if (!isObject(obj)) return;
	return findKey$1(obj, iteratee(predicate ?? identity));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/findLastKey.mjs
/**
* Finds the key of the last element that matches the given predicate.
*
* This function determines the type of the predicate and delegates the search
* to the appropriate helper function. It supports predicates as functions, objects,
* arrays, or strings.
*
* @template T - The type of the object.
* @param obj - The object to inspect.
* @param predicate - The predicate to match.
* @returns Returns the key of the matched element, else `undefined`.
*/
function findLastKey(obj, predicate) {
	if (!isObject(obj)) return;
	const iteratee$1 = iteratee(predicate ?? identity);
	return Object.keys(obj).findLast((key) => iteratee$1(obj[key], key, obj));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/forIn.mjs
/**
* Iterates over an object and invokes the `iteratee` function for each property.
*
* Iterates over string keyed properties including inherited properties.
*
* The iteration is terminated early if the `iteratee` function returns `false`.
*
* @template T - The type of the object
* @param object - The object to iterate over
* @param iteratee - The function invoked per iteration
* @returns Returns the object
*
* @example
* // Iterate over all properties including inherited ones
* const obj = { a: 1, b: 2 };
* forIn(obj, (value, key) => {
*   console.log(key, value);
* });
* // Output: 'a' 1, 'b' 2
*
* // Early termination
* forIn(obj, (value, key) => {
*   console.log(key, value);
*   return key !== 'a'; // stop after 'a'
* });
* // Output: 'a' 1
*/
function forIn(object, iteratee = identity$1) {
	if (object == null) return object;
	for (const key in object) if (iteratee(object[key], key, object) === false) break;
	return object;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/forInRight.mjs
/**
* Iterates over an object in reverse order and invokes the `iteratee` function for each property.
*
* Iterates over string keyed properties including inherited properties in reverse order.
*
* The iteration is terminated early if the `iteratee` function returns `false`.
*
* @template T - The type of the object
* @param object - The object to iterate over
* @param iteratee - The function invoked per iteration
* @returns Returns the object
*
* @example
* // Iterate over all properties including inherited ones
* const obj = { a: 1, b: 2 };
* forInRight(obj, (value, key) => {
*   console.log(key, value);
* });
* // Output: 'b' 2, 'a' 1
*
* // Early termination
* forInRight(obj, (value, key) => {
*   console.log(key, value);
*   return key !== 'a'; // stop after 'a'
* });
* // Output: 'b' 2
*/
function forInRight(object, iteratee = identity$1) {
	if (object == null) return object;
	const keys = [];
	for (const key in object) keys.push(key);
	for (let i = keys.length - 1; i >= 0; i--) {
		const key = keys[i];
		if (iteratee(object[key], key, object) === false) break;
	}
	return object;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/forOwn.mjs
/**
* Iterates over an object's properties and calls the `iteratee` function for each property.
*
* It only iterates over the object's own properties, not including inherited properties or properties with `Symbol` keys.
*
* The `iteratee` function can terminate the iteration early by returning `false`.
*
* @template T - The type of the object.
* @param object The object to iterate over.
* @param [iteratee=identity] The function invoked per iteration. If not provided, the identity function will be used.
* @return {T | null | undefined} Returns object.
*
* @example
* function Foo() {
*   this.a = 1;
*   this.b = 2;
* }
*
* Foo.prototype.c = 3;
*
* forOwn(new Foo(), function(value, key) {
*   console.log(key);
* });
* // => Logs 'a' then 'b' (iteration order is not guaranteed).
*/
function forOwn(object, iteratee = identity$1) {
	if (object == null) return object;
	const iterable = Object(object);
	const keys$1 = keys(object);
	for (let i = 0; i < keys$1.length; ++i) {
		const key = keys$1[i];
		if (iteratee(iterable[key], key, iterable) === false) break;
	}
	return object;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/forOwnRight.mjs
/**
* Iterates over an object's properties in reverse order and calls the `iteratee` function for each property.
*
* It only iterates over the object's own properties, not including inherited properties or properties with `Symbol` keys.
*
* The `iteratee` function can terminate the iteration early by returning `false`.
*
* @template T - The type of the object.
* @param object The object to iterate over.
* @param [iteratee=identity] The function invoked per iteration. If not provided, the identity function will be used.
* @return {T | null | undefined} Returns object.
*
* @example
* function Foo() {
*   this.a = 1;
*   this.b = 2;
* }
*
* Foo.prototype.c = 3;
*
* forOwnRight(new Foo(), function(value, key) {
*   console.log(key);
* });
* // => Logs 'b' then 'a' (iteration order is not guaranteed).
*/
function forOwnRight(object, iteratee = identity$1) {
	if (object == null) return object;
	const iterable = Object(object);
	const keys$1 = keys(object);
	for (let i = keys$1.length - 1; i >= 0; --i) {
		const key = keys$1[i];
		if (iteratee(iterable[key], key, iterable) === false) break;
	}
	return object;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/fromPairs.mjs
/**
* Converts an array of key-value pairs into an object.
*
* @template T - The type of the keys in the resulting object. It must extend `PropertyKey`.
* @template U - The type of the values in the resulting object.
*
* @param pairs - An array of key-value pairs where each key is a `PropertyKey` and each value is of type `U`.
* @returns An object where the keys are of type `T` and the values are of type `U`.
*
* @example
* const pairs = [['a', 1], ['b', 2]];
* const result = fromPairs(pairs);
* // result will be: { a: 1, b: 2 }
*/
function fromPairs(pairs) {
	if (!isArrayLike(pairs)) return {};
	const result = {};
	for (let i = 0; i < pairs.length; i++) {
		const [key, value] = pairs[i];
		result[key] = value;
	}
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/functions.mjs
/**
* Creates an array of property names from an object where the property values are functions.
*
* Only checks for own properties with string keys. Inherited properties or
* properties with Symbol keys are not included.
*
* @param object The object to inspect.
* @returns An array of function property names.
*
* @example
*
* function Foo() {
*   this.a = () => 'a'
*   this.b = () => 'b'
* }
*
* Foo.prototype.c = () => 'c'
*
* functions(new Foo)
* // => ['a', 'b']
*/
function functions(object) {
	if (object == null) return [];
	return keys(object).filter((key) => typeof object[key] === "function");
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/functionsIn.mjs
/**
* Returns an array of property names whose values are functions, including inherited properties.
*
* @param object The object to inspect.
* @returns Returns the function names.
* @example
*
* function Foo() {
*   this.a = function() { return 'a'; };
*   this.b = function() { return 'b'; };
* }
*
* Foo.prototype.c = function() { return 'c'; };
*
* functionsIn(new Foo);
* // => ['a', 'b', 'c']
*/
function functionsIn(object) {
	if (object == null) return [];
	const result = [];
	for (const key in object) if (isFunction$1(object[key])) result.push(key);
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/hasIn.mjs
/**
* Checks if a given path exists in an object, **including inherited properties**.
*
* You can provide the path as a single property key, an array of property keys,
* or a string representing a deep path.
*
* Unlike `has`, which only checks for own properties, `hasIn` also checks for properties
* in the prototype chain.
*
* If the path is an index and the object is an array or an arguments object, the function will verify
* if the index is valid and within the bounds of the array or arguments object, even if the array or
* arguments object is sparse (i.e., not all indexes are defined).
*
* @template T
* @param object - The object to query.
* @param path - The path to check. This can be a single property key,
*        an array of property keys, or a string representing a deep path.
* @returns Returns `true` if the path exists (own or inherited), `false` otherwise.
*
* @example
*
* const obj = { a: { b: { c: 3 } } };
*
* hasIn(obj, 'a'); // true
* hasIn(obj, ['a', 'b']); // true
* hasIn(obj, ['a', 'b', 'c']); // true
* hasIn(obj, 'a.b.c'); // true
* hasIn(obj, 'a.b.d'); // false
* hasIn(obj, ['a', 'b', 'c', 'd']); // false
*
* // Example with inherited properties:
* function Rectangle() {}
* Rectangle.prototype.area = function() {};
*
* const rect = new Rectangle();
* hasIn(rect, 'area'); // true
* has(rect, 'area'); // false - has only checks own properties
*/
function hasIn(object, path) {
	if (object == null) return false;
	let resolvedPath;
	if (Array.isArray(path)) resolvedPath = path;
	else if (typeof path === "string" && isDeepKey(path) && object[path] == null) resolvedPath = toPath(path);
	else resolvedPath = [path];
	if (resolvedPath.length === 0) return false;
	let current = object;
	for (let i = 0; i < resolvedPath.length; i++) {
		const key = resolvedPath[i];
		if (current == null || !(key in Object(current))) {
			if (!((Array.isArray(current) || isArguments(current)) && isIndex(key) && key < current.length)) return false;
		}
		current = current[key];
	}
	return true;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/invert.mjs
/**
* Inverts the keys and values of an object. The keys of the input object become the values of the output object and vice versa.
*
* This function takes an object and creates a new object by inverting its keys and values. If the input object has duplicate values,
* the key of the last occurrence will be used as the value for the new key in the output object. It effectively creates a reverse mapping
* of the input object's key-value pairs.
*
* @template K - Type of the keys in the input object (string, number, symbol)
* @template V - Type of the values in the input object (string, number, symbol)
* @param obj - The input object whose keys and values are to be inverted
* @returns A new object with keys and values inverted
*
* @example
* invert({ a: 1, b: 2, c: 3 }); // { 1: 'a', 2: 'b', 3: 'c' }
* invert({ 1: 'a', 2: 'b', 3: 'c' }); // { a: '1', b: '2', c: '3' }
* invert({ a: 1, 2: 'b', c: 3, 4: 'd' }); // { 1: 'a', b: '2', 3: 'c', d: '4' }
* invert({ a: Symbol('sym1'), b: Symbol('sym2') }); // { [Symbol('sym1')]: 'a', [Symbol('sym2')]: 'b' }
*/
function invert(obj) {
	return invert$1(obj);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/invertBy.mjs
/**
* Creates a new object that reverses the keys and values of the given object, similar to the invert.
*
* The `iteratee` function specifies how the values are reversed into keys. If no `iteratee` function is provided, the values are used as keys as-is.
*
* The values of the new object are arrays of keys that correspond to the value returned by the `iteratee` function.
*
* @param object - The object to iterate over.
* @param [iteratee] - Optional. A function that generates a key based on each value in the object.
* If not provided, the function defaults to using the value as a string.
*
* @returns An object where the keys are generated by the iteratee, and the values
* are arrays of property names (keys) from the input object that correspond to those keys.
*
* @example
* const obj = { a: 1, b: 2, c: 1 };
* const result = invertBy(obj);
* // result => { '1': ['a', 'c'], '2': ['b'] }
*
* @example
* const obj = { a: 1, b: 2, c: 1 };
* const result = invertBy(obj, value => `group${value}`);
* // result => { 'group1': ['a', 'c'], 'group2': ['b'] }
*/
function invertBy(object, iteratee$1) {
	const result = {};
	if (isNil$1(object)) return result;
	if (iteratee$1 == null) iteratee$1 = identity$1;
	const keys = Object.keys(object);
	const getString = iteratee(iteratee$1);
	for (let i = 0; i < keys.length; i++) {
		const key = keys[i];
		const value = object[key];
		const valueStr = getString(value);
		if (Array.isArray(result[valueStr])) result[valueStr].push(key);
		else result[valueStr] = [key];
	}
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/mapKeys.mjs
/**
* Creates a new object with the same values as the given object, but with keys generated
* by running each own enumerable property of the object through the iteratee function.
*
* @template T - The type of the object.
* @template K1 - The type of the keys in the object.
* @template K2 - The type of the new keys generated by the iteratee function.
*
* @param object - The object to iterate over.
* @param [getNewKey] - The function invoked per own enumerable property, or a path to generate new keys.
* @returns Returns the new mapped object.
*
* @example
* // Example usage:
* const obj = { a: 1, b: 2 };
* const result = mapKeys(obj, (value, key) => key + value);
* console.log(result); // { a1: 1, b2: 2 }
*/
function mapKeys(object, getNewKey = identity$1) {
	if (object == null) return {};
	return mapKeys$1(object, iteratee(getNewKey));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/mapValues.mjs
/**
* Creates a new object with the same keys as the given object, but with values generated
* by running each own enumerable property of the object through the iteratee function.
*
* @template T - The type of the object.
* @template K - The type of the keys in the object.
* @template V - The type of the new values generated by the iteratee function.
*
* @param object - The object to iterate over.
* @param [getNewValue] -
*        The function invoked per own enumerable property, or a path to generate new values.
* @returns Returns the new mapped object.
*
* @example
* // Example usage:
* const obj = { a: 1, b: 2 };
* const result = mapValues(obj, (value) => value * 2);
* console.log(result); // { a: 2, b: 4 }
*/
function mapValues(object, getNewValue = identity$1) {
	if (object == null) return {};
	return mapValues$1(object, iteratee(getNewValue));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/_internal/getSymbolsIn.mjs
function getSymbolsIn(object) {
	const result = [];
	while (object) {
		result.push(...getSymbols(object));
		object = Object.getPrototypeOf(object);
	}
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/omit.mjs
/**
* Creates a new object with specified keys omitted.
*
* This function takes an object and a variable number of keys, and returns a new object that
* excludes the properties corresponding to the specified keys. Note that keys can be deep.
*
* Deep keys can be specified for keys.
*
* @template T - The type of object.
* @param obj - The object to omit keys from.
* @param keysArr - A variable number of keys to be omitted from the object.
* @returns A new object with the specified keys omitted.
*
* @example
* omit({ a: 1, b: 2, c: 3 }, 'a', 'b');
* // => { c: 3 }
*
* omit({ a: { b: 1, c: 2 }, d: 3 }, 'a.b', 'd');
* // => { a: { c: 2 } }
*/
function omit(obj, ...keysArr) {
	if (obj == null) return {};
	keysArr = flatten$1(keysArr);
	const result = cloneInOmit(obj, keysArr);
	for (let i = 0; i < keysArr.length; i++) {
		let keys = keysArr[i];
		switch (typeof keys) {
			case "object":
				if (!Array.isArray(keys)) keys = Array.from(keys);
				for (let j = 0; j < keys.length; j++) {
					const key = keys[j];
					unset(result, key);
				}
				break;
			case "string":
			case "symbol":
			case "number": unset(result, keys);
		}
	}
	return result;
}
function cloneInOmit(obj, keys) {
	if (keys.some((key) => Array.isArray(key) || isDeepKey(key))) return deepCloneInOmit(obj);
	return shallowCloneInOmit(obj);
}
function shallowCloneInOmit(obj) {
	const result = {};
	const keysToCopy = [...keysIn(obj), ...getSymbolsIn(obj)];
	for (let i = 0; i < keysToCopy.length; i++) {
		const key = keysToCopy[i];
		result[key] = obj[key];
	}
	return result;
}
function deepCloneInOmit(obj) {
	const result = {};
	const keysToCopy = [...keysIn(obj), ...getSymbolsIn(obj)];
	for (let i = 0; i < keysToCopy.length; i++) {
		const key = keysToCopy[i];
		result[key] = cloneDeepWith(obj[key], (valueToClone) => {
			if (isPlainObject(valueToClone)) return;
			return valueToClone;
		});
	}
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/omitBy.mjs
/**
* Creates a new object composed of the properties that do not satisfy the predicate function.
*
* This function takes an object and a predicate function, and returns a new object that
* includes only the properties for which the predicate function returns false.
*
* @template T - The type of object.
* @param obj - The object to omit properties from.
* @param shouldOmit - A predicate function that determines
* whether a property should be omitted. It takes the property's value, key, and the source object as arguments and returns `true`
* if the property should be omitted, and `false` otherwise.
* @returns Returns the new object.
*
* @example
* const obj = { a: 1, b: 'omit', c: 3 };
* const shouldOmit = (value) => typeof value === 'string';
* const result = omitBy(obj, shouldOmit);
* // result will be { a: 1, c: 3 }
*/
function omitBy(object, shouldOmit) {
	if (object == null) return {};
	const result = {};
	const predicate = iteratee(shouldOmit ?? identity);
	const keys = [...keysIn(object), ...getSymbolsIn(object)];
	for (let i = 0; i < keys.length; i++) {
		const key = isSymbol$1(keys[i]) ? keys[i] : keys[i].toString();
		const value = object[key];
		if (!predicate(value, key, object)) result[key] = value;
	}
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/pick.mjs
/**
* Creates a new object composed of the picked object properties.
*
* This function takes an object and an array of keys, and returns a new object that
* includes only the properties corresponding to the specified keys.
*
* @template T - The type of object.
* @template U - The type of keys to pick.
* @param object - The object to pick keys from.
* @param props - An array of keys to be picked from the object. received keys goes through a flattening process before being used.
* @returns A new object with the specified keys picked.
*
* @example
* const obj = { a: 1, b: 2, c: 3 };
* const result = pick(obj, ['a', 'c']);
* // result will be { a: 1, c: 3 }
*
* // each path can be passed individually as an argument
* const obj = { a: 1, b: 2, c: 3 };
* const result = pick(obj, 'a', 'c');
* // result will be { a: 1, c: 3 }
*
* // pick a key over a path
* const obj = { 'a.b': 1, a: { b: 2 } };
* const result = pick(obj, 'a.b');
* // result will be { 'a.b': 1 }
*/
function pick(object, ...keysArr) {
	if (isNil(object)) return {};
	const result = {};
	for (let i = 0; i < keysArr.length; i++) {
		let keys = keysArr[i];
		switch (typeof keys) {
			case "object":
				if (!Array.isArray(keys)) if (isArrayLike(keys)) keys = Array.from(keys);
				else keys = [keys];
				break;
			case "string":
			case "symbol":
			case "number": keys = [keys];
		}
		for (const key of keys) {
			const value = get(object, key);
			if (value === void 0 && !has(object, key)) continue;
			if (typeof key === "string" && Object.hasOwn(object, key)) result[key] = object[key];
			else set(result, key, value);
		}
	}
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/pickBy.mjs
/**
* Creates a new object composed of the properties that satisfy the predicate function.
*
* This function takes an object and a predicate function, and returns a new object that
* includes only the properties for which the predicate function returns true.
*
* @template T - The type of object.
* @param obj - The object to pick properties from.
* @param [shouldPick] - A predicate function that determines
* whether a property should be picked. It takes the property's key and value as arguments and returns `true`
* if the property should be picked, and `false` otherwise.
* @returns A new object with the properties that satisfy the predicate function.
*
* @example
* const obj = { a: 1, b: 'pick', c: 3 };
* const shouldPick = (value) => typeof value === 'string';
* const result = pickBy(obj, shouldPick);
* // result will be { b: 'pick' }
*/
function pickBy(obj, shouldPick) {
	if (obj == null) return {};
	const predicate = iteratee(shouldPick ?? identity);
	const result = {};
	const keys = isArrayLike(obj) ? range$1(0, obj.length) : [...keysIn(obj), ...getSymbolsIn(obj)];
	for (let i = 0; i < keys.length; i++) {
		const key = isSymbol$1(keys[i]) ? keys[i] : keys[i].toString();
		const value = obj[key];
		if (predicate(value, key, obj)) result[key] = value;
	}
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/propertyOf.mjs
/**
* Creates a function that returns the value at a given path of an object.
*
* Unlike `property`, which creates a function bound to a specific path and allows you to query different objects,
* `propertyOf` creates a function bound to a specific object and allows you to query different paths within that object.
*
* @template T - The type of object.
* @param object - The object to query.
* @returns Returns a new function that takes a path and retrieves the value from the object at the specified path.
*
* @example
* const getValue = propertyOf({ a: { b: { c: 3 } } });
* const result = getValue('a.b.c');
* console.log(result); // => 3
*
* @example
* const getValue = propertyOf({ a: { b: { c: 3 } } });
* const result = getValue(['a', 'b', 'c']);
* console.log(result); // => 3
*/
function propertyOf(object) {
	return function(path) {
		return get(object, path);
	};
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/result.mjs
/**
* Retrieves the value at a given path of an object.
* If the resolved value is a function, it is invoked with the object as its `this` context.
* If the value is `undefined`, the `defaultValue` is returned.
*
* @template T - The type of object.
* @template R - The type of the value to return.
* @param object - The object to query.
* @param path - The path of the property to get.
* @param [defaultValue] - The value returned if the resolved value is `undefined`.
* @returns Returns the resolved value.
*
* @example
* const obj = { a: { b: { c: 3 } } };
* result(obj, 'a.b.c');
* // => 3
*
* @example
* const obj = { a: () => 5 };
* result(obj, 'a');
* // => 5 (calls the function `a` and returns its result)
*
* @example
* const obj = { a: { b: null } };
* result(obj, 'a.b.c', 'default');
* // => 'default'
*
* @example
* const obj = { a: { b: { c: 3 } } };
* result(obj, 'a.b.d', () => 'default');
* // => 'default'
*/
function result(object, path, defaultValue) {
	if (isKey(path, object)) path = [path];
	else if (!Array.isArray(path)) path = toPath(toString(path));
	const pathLength = Math.max(path.length, 1);
	for (let index = 0; index < pathLength; index++) {
		const value = object == null ? void 0 : object[toKey(path[index])];
		if (value === void 0) return typeof defaultValue === "function" ? defaultValue.call(object) : defaultValue;
		object = typeof value === "function" ? value.call(object) : value;
	}
	return object;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/setWith.mjs
/**
* Sets the value at the specified path of the given object using a customizer function.
* If any part of the path does not exist, it will be created based on the customizer's result.
*
* The customizer is invoked to produce the objects of the path. If the customizer returns
* a value, that value is used for the current path segment. If the customizer returns
* `undefined`, the method will create an appropriate object based on the path - an array
* if the next path segment is a valid array index, or an object otherwise.
*
* @template T - The type of the object.
* @template R - The type of the return value.
* @param obj - The object to modify.
* @param path - The path of the property to set.
* @param value - The value to set.
* @param [customizer] - The function to customize assigned values.
* @returns The modified object.
*
* @example
* // Set a value with a customizer that creates arrays for numeric path segments
* const object = {};
* setWith(object, '[0][1]', 'a', (value) => Array.isArray(value) ? value : []);
* // => { '0': [, 'a'] }
*/
function setWith(obj, path, value, customizer) {
	let customizerFn;
	if (typeof customizer === "function") customizerFn = customizer;
	else customizerFn = () => void 0;
	return updateWith(obj, path, () => value, customizerFn);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/toDefaulted.mjs
/**
* Creates a new object based on the provided `object`, applying default values from the `sources` to ensure that no properties are left `undefined`.
* It assigns default values to properties that are either `undefined` or come from `Object.prototype`.
*
* You can provide multiple source objects to set these default values,
* and they will be applied in the order they are given, from left to right.
* Once a property has been set, any later values for that property will be ignored.
*
* Note: This function creates a new object. If you want to modify the `object`, use the `defaults` function instead.
*
* @template T - The type of the object being processed.
* @template S - The type of the objects that provides default values.
* @param object - The target object that will receive default values.
* @param sources - The objects that specifies the default values to apply.
* @returns A new object that combines the target and default values, ensuring no properties are left undefined.
*
* @example
* toDefaulted({ a: 1 }, { a: 2, b: 2 }, { c: 3 }); // { a: 1, b: 2, c: 3 }
* toDefaulted({ a: 1, b: 2 }, { b: 3 }, { c: 3 }); // { a: 1, b: 2, c: 3 }
* toDefaulted({ a: null }, { a: 1 }); // { a: null }
* toDefaulted({ a: undefined }, { a: 1 }); // { a: 1 }
*/
function toDefaulted(object, ...sources) {
	return defaults(cloneDeep$1(object), ...sources);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/_internal/mapToEntries.mjs
function mapToEntries(map) {
	const arr = new Array(map.size);
	const keys = map.keys();
	const values = map.values();
	for (let i = 0; i < arr.length; i++) arr[i] = [keys.next().value, values.next().value];
	return arr;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/_internal/setToEntries.mjs
function setToEntries(set) {
	const arr = new Array(set.size);
	const values = set.values();
	for (let i = 0; i < arr.length; i++) {
		const value = values.next().value;
		arr[i] = [value, value];
	}
	return arr;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/toPairs.mjs
/**
* Creates an array of key-value pairs from an object, set, or map.
*
* @template T
* @param object - The object, set, or map to query.
* @returns Returns the array of key-value pairs.
*
* @example
* const object = { a: 1, b: 2 };
* toPairs(object); // [['a', 1], ['b', 2]]
*
* const set = new Set([1, 2]);
* toPairs(set); // [[1, 1], [2, 2]]
*
* const map = new Map();
* map.set('a', 1);
* map.set('b', 2);
* toPairs(map); // [['a', 1], ['b', 2]]
*/
function toPairs(object) {
	if (object == null) return [];
	if (object instanceof Set) return setToEntries(object);
	if (object instanceof Map) return mapToEntries(object);
	const keys$1 = keys(object);
	const result = new Array(keys$1.length);
	for (let i = 0; i < keys$1.length; i++) {
		const key = keys$1[i];
		result[i] = [key, object[key]];
	}
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/toPairsIn.mjs
/**
* Creates an array of key-value pairs from an object, set, or map, including inherited properties.
*
* @param object The object, set, or map to query.
* @returns Returns the array of key-value pairs.
* @example
* const object = { a: 1, b: 2 };
* toPairsIn(object); // [['a', 1], ['b', 2]]
*
* const set = new Set([1, 2]);
* toPairsIn(set); // [[1, 1], [2, 2]]
*
* const map = new Map();
* map.set('a', 1);
* map.set('b', 2);
* toPairsIn(map); // [['a', 1], ['b', 2]]
*/
function toPairsIn(object) {
	if (object == null) return [];
	if (object instanceof Set) return setToEntries(object);
	if (object instanceof Map) return mapToEntries(object);
	const keys = keysIn(object);
	const result = new Array(keys.length);
	for (let i = 0; i < keys.length; i++) {
		const key = keys[i];
		result[i] = [key, object[key]];
	}
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isBuffer.mjs
/**
* Checks if the given value is a Buffer instance.
*
* This function tests whether the provided value is an instance of Buffer.
* It returns `true` if the value is a Buffer, and `false` otherwise.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to `Buffer`.
*
* @param x - The value to check if it is a Buffer.
* @returns Returns `true` if `x` is a Buffer, else `false`.
*
* @example
* const buffer = Buffer.from("test");
* console.log(isBuffer(buffer)); // true
*
* const notBuffer = "not a buffer";
* console.log(isBuffer(notBuffer)); // false
*/
function isBuffer(x) {
	return isBuffer$1(x);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/transform.mjs
/**
* Traverses object values and creates a new object by accumulating them in the desired form.
*
* If no initial value is provided for `accumulator`, it creates a new array or object with the same prototype.
*
The traversal is interrupted when the `iteratee` function returns `false`.
*
* @template T - The type of object.
* @template U - The type of accumulator.
* @param object - The object to iterate over.
* @param [iteratee] - The function invoked per iteration.
* @param [accumulator] - The initial value.
* @returns Returns the accumulated value.
*
* @example
* // Transform an array
* const array = [2, 3, 4];
* transform(array, (acc, value) => { acc += value; return value % 2 === 0; }, 0) // => 5
*
* @example
* // Transform an object
* const obj = { 'a': 1, 'b': 2, 'c': 1 };
* transform(obj, (result, value, key) => { (result[value] || (result[value] = [])).push(key) }, {}) // => { '1': ['a', 'c'], '2': ['b'] }
*/
function transform(object, iteratee$1 = identity$1, accumulator) {
	const isArrayOrBufferOrTypedArray = Array.isArray(object) || isBuffer(object) || isTypedArray(object);
	iteratee$1 = iteratee(iteratee$1);
	if (accumulator == null) if (isArrayOrBufferOrTypedArray) accumulator = [];
	else if (isObject(object) && isFunction$1(object.constructor)) accumulator = Object.create(Object.getPrototypeOf(object));
	else accumulator = {};
	if (object == null) return accumulator;
	forEach(object, (value, key, object) => iteratee$1(accumulator, value, key, object));
	return accumulator;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/update.mjs
/**
* Updates the value at the specified path of the given object using an updater function.
* If any part of the path does not exist, it will be created.
*
* @param obj - The object to modify.
* @param path - The path of the property to update.
* @param updater - The function to produce the updated value.
* @returns The modified object.
*/
function update(obj, path, updater) {
	return updateWith(obj, path, updater, () => void 0);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/object/valuesIn.mjs
/**
* Retrieves the values from an object, including those inherited from its prototype.
*
* - If the value is not an object, it is converted to an object.
* - Array-like objects are treated like arrays.
* - Sparse arrays with some missing indices are treated like dense arrays.
* - If the value is `null` or `undefined`, an empty array is returned.
* - When handling prototype objects, the `constructor` property is excluded from the results.
*
* @param object The object to query.
* @returns Returns an array of property values.
* @example
* const obj = { a: 1, b: 2, c: 3 };
* valuesIn(obj); // => [1, 2, 3]
*/
function valuesIn(object) {
	const keys = keysIn(object);
	const result = new Array(keys.length);
	for (let i = 0; i < keys.length; i++) result[i] = object[keys[i]];
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isFunction.mjs
/**
* Checks if `value` is a function.
*
* @param value The value to check.
* @returns Returns `true` if `value` is a function, else `false`.
*
* @example
* isFunction(Array.prototype.slice); // true
* isFunction(async function () {}); // true
* isFunction(function* () {}); // true
* isFunction(Proxy); // true
* isFunction(Int8Array); // true
*/
function isFunction(value) {
	return typeof value === "function";
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isLength.mjs
/**
* Checks if a given value is a valid length.
*
* A valid length is of type `number`, is a non-negative integer, and is less than or equal to
* JavaScript's maximum safe integer (`Number.MAX_SAFE_INTEGER`).
* It returns `true` if the value is a valid length, and `false` otherwise.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the
* argument to a valid length (`number`).
*
* @param value The value to check.
* @returns Returns `true` if `value` is a valid length, else `false`.
*
* @example
* isLength(0); // true
* isLength(42); // true
* isLength(-1); // false
* isLength(1.5); // false
* isLength(Number.MAX_SAFE_INTEGER); // true
* isLength(Number.MAX_SAFE_INTEGER + 1); // false
*/
function isLength(value) {
	return Number.isSafeInteger(value) && value >= 0;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isNative.mjs
var functionToString = Function.prototype.toString;
/** Used to detect if a method is native. */
var IS_NATIVE_FUNCTION_REGEXP = RegExp(`^${functionToString.call(Object.prototype.hasOwnProperty).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?")}$`);
/**
* Checks if a given value is a native function.
*
* This function tests whether the provided value is a native function implemented by the JavaScript engine.
* It returns `true` if the value is a native function, and `false` otherwise.
*
* @param value - The value to test for native function.
* @returns `true` if the value is a native function, `false` otherwise.
*
* @example
* const value1 = Array.prototype.push;
* const value2 = () => {};
* const result1 = isNative(value1); // true
* const result2 = isNative(value2); // false
*/
function isNative(value) {
	if (typeof value !== "function") return false;
	if (globalThis?.["__core-js_shared__"] != null) throw new Error("Unsupported core-js use. Try https://npms.io/search?q=ponyfill.");
	return IS_NATIVE_FUNCTION_REGEXP.test(functionToString.call(value));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isNull.mjs
/**
* Checks if `value` is `null`.
*
* @param value - The value to check.
* @returns Returns `true` if `value` is `null`, else `false`.
*
* @example
* isNull(null); // true
* isNull(undefined); // false
* isNull(0); // false
*/
function isNull(value) {
	return value === null;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isUndefined.mjs
/**
* Checks if the given value is undefined.
*
* This function tests whether the provided value is strictly equal to `undefined`.
* It returns `true` if the value is `undefined`, and `false` otherwise.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to `undefined`.
*
* @param x - The value to test if it is undefined.
* @returns true if the value is undefined, false otherwise.
*
* @example
* const value1 = undefined;
* const value2 = null;
* const value3 = 42;
*
* console.log(isUndefined(value1)); // true
* console.log(isUndefined(value2)); // false
* console.log(isUndefined(value3)); // false
*/
function isUndefined(x) {
	return isUndefined$1(x);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/conformsTo.mjs
/**
* Checks if `object` conforms to `source` by invoking the predicate properties of `source` with the corresponding property values of `object`.
*
* Note: This method is equivalent to `conforms` when source is partially applied.
*
* @template T - The type of the target object.
* @param target The object to inspect.
* @param source The object of property predicates to conform to.
* @returns Returns `true` if `object` conforms, else `false`.
*
* @example
*
* const object = { 'a': 1, 'b': 2 };
* const source = {
*   'a': (n) => n > 0,
*   'b': (n) => n > 1
* };
*
* console.log(conformsTo(object, source)); // => true
*
* const source2 = {
*   'a': (n) => n > 1,
*   'b': (n) => n > 1
* };
*
* console.log(conformsTo(object, source2)); // => false
*/
function conformsTo(target, source) {
	if (source == null) return true;
	if (target == null) return Object.keys(source).length === 0;
	const keys = Object.keys(source);
	for (let i = 0; i < keys.length; i++) {
		const key = keys[i];
		const predicate = source[key];
		const value = target[key];
		if (value === void 0 && !(key in target)) return false;
		if (typeof predicate === "function" && !predicate(value)) return false;
	}
	return true;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/conforms.mjs
/**
* Creates a function that invokes the predicate properties of `source` with the corresponding property values of a given object, returning `true` if all predicates return truthy, else `false`.
*
* Note: The created function is equivalent to `conformsTo` with source partially applied.
*
* @param source The object of property predicates to conform to.
* @returns Returns the new spec function.
*
* @example
* const isPositive = (n) => n > 0;
* const isEven = (n) => n % 2 === 0;
* const predicates = { a: isPositive, b: isEven };
* const conform = conforms(predicates);
*
* console.log(conform({ a: 2, b: 4 })); // true
* console.log(conform({ a: -1, b: 4 })); // false
* console.log(conform({ a: 2, b: 3 })); // false
* console.log(conform({ a: 0, b: 2 })); // false
*/
function conforms(source) {
	source = cloneDeep(source);
	return function(object) {
		return conformsTo(object, source);
	};
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isArrayBuffer.mjs
/**
* Checks if a given value is `ArrayBuffer`.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to `ArrayBuffer`.
*
* @param value The value to check if it is a `ArrayBuffer`.
* @returns Returns `true` if `value` is a `ArrayBuffer`, else `false`.
*
* @example
* const value1 = new ArrayBuffer();
* const value2 = new Array();
* const value3 = new Map();
*
* console.log(isArrayBuffer(value1)); // true
* console.log(isArrayBuffer(value2)); // false
* console.log(isArrayBuffer(value3)); // false
*/
function isArrayBuffer(value) {
	return isArrayBuffer$1(value);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isBoolean.mjs
/**
* Checks if the given value is boolean.
*
* This function tests whether the provided value is strictly `boolean`.
* It returns `true` if the value is `boolean`, and `false` otherwise.
*
*  This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to `boolean`.
*
* @param value - The Value to test if it is boolean.
* @returns True if the value is boolean, false otherwise.
*
* @example
*
* const value1 = true;
* const value2 = 0;
* const value3 = 'abc';
*
* console.log(isBoolean(value1)); // true
* console.log(isBoolean(value2)); // false
* console.log(isBoolean(value3)); // false
*
*/
function isBoolean(value) {
	return typeof value === "boolean" || value instanceof Boolean;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isDate.mjs
/**
* Checks if `value` is a Date object.
*
* @param value The value to check.
* @returns Returns `true` if `value` is a Date object, `false` otherwise.
*
* @example
* const value1 = new Date();
* const value2 = '2024-01-01';
*
* console.log(isDate(value1)); // true
* console.log(isDate(value2)); // false
*/
function isDate(value) {
	return isDate$1(value);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isElement.mjs
/**
* Checks if `value` is likely a DOM element.
*
* @param value The value to check.
* @returns Returns `true` if `value` is a DOM element, else `false`.
*
* @example
* console.log(isElement(document.body)); // true
* console.log(isElement('<body>')); // false
*/
function isElement(value) {
	return isObjectLike(value) && value.nodeType === 1 && !isPlainObject(value);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isEqualWith.mjs
/**
* Compares two values for equality using a custom comparison function.
*
* The custom function allows for fine-tuned control over the comparison process. If it returns a boolean, that result determines the equality. If it returns undefined, the function falls back to the default equality comparison.
*
* This function also uses the custom equality function to compare values inside objects,
* arrays, maps, sets, and other complex structures, ensuring a deep comparison.
*
* This approach provides flexibility in handling complex comparisons while maintaining efficient default behavior for simpler cases.
*
* The custom comparison function can take up to six parameters:
* - `x`: The value from the first object `a`.
* - `y`: The value from the second object `b`.
* - `property`: The property key used to get `x` and `y`.
* - `xParent`: The parent of the first value `x`.
* - `yParent`: The parent of the second value `y`.
* - `stack`: An internal stack (Map) to handle circular references.
*
* @param a - The first value to compare.
* @param b - The second value to compare.
* @param [areValuesEqual=noop] - A function to customize the comparison.
*   If it returns a boolean, that result will be used. If it returns undefined,
*   the default equality comparison will be used.
* @returns `true` if the values are equal according to the customizer, otherwise `false`.
*
* @example
* const customizer = (a, b) => {
*   if (typeof a === 'string' && typeof b === 'string') {
*     return a.toLowerCase() === b.toLowerCase();
*   }
* };
* isEqualWith('Hello', 'hello', customizer); // true
* isEqualWith({ a: 'Hello' }, { a: 'hello' }, customizer); // true
* isEqualWith([1, 2, 3], [1, 2, 3], customizer); // true
*/
function isEqualWith(a, b, areValuesEqual) {
	if (typeof areValuesEqual !== "function") areValuesEqual = () => void 0;
	return isEqualWith$1(a, b, (...args) => {
		const result = areValuesEqual(...args);
		if (result !== void 0) return Boolean(result);
		if (a instanceof Map && b instanceof Map) return isEqualWith(Array.from(a), Array.from(b), after$1(2, areValuesEqual));
		if (a instanceof Set && b instanceof Set) return isEqualWith(Array.from(a), Array.from(b), after$1(2, areValuesEqual));
	});
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isError.mjs
/**
* Checks if `value` is an Error object.
*
* @param value The value to check.
* @returns Returns `true` if `value` is an Error object, `false` otherwise.
*
* @example
* ```typescript
* console.log(isError(new Error())); // true
* console.log(isError('Error')); // false
* console.log(isError({ name: 'Error', message: '' })); // false
* ```
*/
function isError(value) {
	return getTag(value) === "[object Error]";
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isFinite.mjs
/**
* Checks if `value` is a finite number.
*
* Acts as a type guard for `number` values — returning `true` only when `value`
* is of type `number` and finite (not `Infinity`, `-Infinity`, or `NaN`).
*
* @param value The value to check.
* @returns Returns `true` if `value` is a finite number, `false` otherwise.
*
* @example
* ```typescript
* const value1 = 100;
* const value2 = Infinity;
* const value3 = '100';
*
* console.log(isFinite(value1)); // true
* console.log(isFinite(value2)); // false
* console.log(isFinite(value3)); // false
*
* if (isFinite(value1)) {
*   console.log(value1.toFixed(2));
* }
* ```
*/
function isFinite$1(value) {
	return Number.isFinite(value);
}
__name(isFinite$1, "isFinite");
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isInteger.mjs
/**
* Checks if `value` is an integer.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to `number`.
*
* @param value - The value to check
* @returns `true` if `value` is integer, otherwise `false`.
*
* @example
* isInteger(3); // Returns: true
* isInteger(Infinity); // Returns: false
* isInteger('3'); // Returns: false
* isInteger([]); // Returns: false
*/
function isInteger(value) {
	return Number.isInteger(value);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isRegExp.mjs
/**
* Checks if `value` is a RegExp.
*
* @param value The value to check.
* @returns Returns `true` if `value` is a RegExp, `false` otherwise.
*
* @example
* const value1 = /abc/;
* const value2 = '/abc/';
*
* console.log(isRegExp(value1)); // true
* console.log(isRegExp(value2)); // false
*/
function isRegExp(value) {
	return isRegExp$1(value);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isSafeInteger.mjs
/**
* Checks if `value` is a safe integer (between -(2^53 – 1) and (2^53 – 1), inclusive).
*
* A safe integer is an integer that can be precisely represented as a `number` in JavaScript,
* without any other integer being rounded to it.
*
* This function also serves as a type predicate in TypeScript,
* narrowing the type of the argument to `number`.
*
* @param value - The value to check
* @returns `true` if `value` is an integer and between the safe values, otherwise `false`
*
* @example
* isSafeInteger(3); // Returns: true
* isSafeInteger(Number.MIN_SAFE_INTEGER - 1); // Returns: false
* isSafeInteger(1n); // Returns: false
* isSafeInteger('1'); // Returns: false
*/
function isSafeInteger(value) {
	return Number.isSafeInteger(value);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isSet.mjs
/**
* Checks if a given value is `Set`.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to `Set`.
*
* @param value The value to check if it is a `Set`.
* @returns Returns `true` if `value` is a `Set`, else `false`.
*
* @example
* const value1 = new Set();
* const value2 = new Map();
* const value3 = new WeakSet();
*
* console.log(isSet(value1)); // true
* console.log(isSet(value2)); // false
* console.log(isSet(value3)); // false
*/
function isSet(value) {
	return isSet$1(value);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isWeakMap.mjs
/**
* Checks if the given value is a `WeakMap`.
*
* This function tests whether the provided value is an instance of `WeakMap`.
* It returns `true` if the value is a `WeakMap`, and `false` otherwise.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to `WeakMap`.
*
* @param value - The value to test if it is a `WeakMap`.
* @returns true if the value is a `WeakMap`, false otherwise.
*
* @example
* const value1 = new WeakMap();
* const value2 = new Map();
* const value3 = new Set();
*
* console.log(isWeakMap(value1)); // true
* console.log(isWeakMap(value2)); // false
* console.log(isWeakMap(value3)); // false
*/
function isWeakMap(value) {
	return isWeakMap$1(value);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/predicate/isWeakSet.mjs
/**
* Checks if the given value is a `WeakSet`.
*
* This function tests whether the provided value is an instance of `WeakSet`.
* It returns `true` if the value is a `WeakSet`, and `false` otherwise.
*
* This function can also serve as a type predicate in TypeScript, narrowing the type of the argument to `WeakSet`.
*
* @param value - The value to test if it is a `WeakSet`.
* @returns true if the value is a `WeakSet`, false otherwise.
*
* @example
* const value1 = new WeakSet();
* const value2 = new Map();
* const value3 = new Set();
*
* console.log(isWeakSet(value1)); // true
* console.log(isWeakSet(value2)); // false
* console.log(isWeakSet(value3)); // false
*/
function isWeakSet(value) {
	return isWeakSet$1(value);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/capitalize.mjs
/**
* Converts the first character of string to upper case and the remaining to lower case.
*
* @param string - The string to capitalize.
* @returns The capitalized string.
*
* @example
* const convertedStr1 = capitalize('fred') // returns 'Fred'
* const convertedStr2 = capitalize('FRED') // returns 'Fred'
* const convertedStr3 = capitalize('') // returns ''
*/
function capitalize(str) {
	return capitalize$1(toString(str));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/bindAll.mjs
/**
* Binds methods of an object to the object itself, overwriting the existing method.
* Method names may be specified as individual arguments or as arrays of method names.
*
* @template T - The type of the object.
* @param object - The object to bind methods to.
* @param [methodNames] - The method names to bind, specified individually or in arrays.
* @returns Returns the object.
*
* @example
* const view = {
*   'label': 'docs',
*   'click': function() {
*     console.log('clicked ' + this.label);
*   }
* };
*
* bindAll(view, ['click']);
* jQuery(element).on('click', view.click);
* // => Logs 'clicked docs' when clicked.
*
* @example
* // Using individual method names
* bindAll(view, 'click');
* // => Same as above
*/
function bindAll(object, ...methodNames) {
	if (object == null) return object;
	if (!isObject(object)) return object;
	if (isArray(object) && methodNames.length === 0) return object;
	const methods = [];
	for (let i = 0; i < methodNames.length; i++) {
		const name = methodNames[i];
		if (isArray(name)) methods.push(...name);
		else if (name && typeof name === "object" && "length" in name) methods.push(...Array.from(name));
		else methods.push(name);
	}
	if (methods.length === 0) return object;
	for (let i = 0; i < methods.length; i++) {
		const key = methods[i];
		const stringKey = toString(key);
		const func = object[stringKey];
		if (isFunction$1(func)) object[stringKey] = func.bind(object);
	}
	return object;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/deburr.mjs
/**
* Converts a string by replacing special characters and diacritical marks with their ASCII equivalents.
* For example, "Crème brûlée" becomes "Creme brulee".
*
* @param str - The input string to be deburred.
* @returns The deburred string with special characters replaced by their ASCII equivalents.
*
* @example
* // Basic usage:
* deburr('Æthelred') // returns 'Aethelred'
*
* @example
* // Handling diacritical marks:
* deburr('München') // returns 'Munchen'
*
* @example
* // Special characters:
* deburr('Crème brûlée') // returns 'Creme brulee'
*/
function deburr(str) {
	return deburr$1(toString(str));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/_internal/normalizeForCase.mjs
function normalizeForCase(str) {
	if (typeof str !== "string") str = toString(str);
	return str.replace(/['\u2019]/g, "");
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/camelCase.mjs
/**
* Converts a string to camel case.
*
* Camel case is the naming convention in which the first word is written in lowercase and
* each subsequent word begins with a capital letter, concatenated without any separator characters.
*
* @param str - The string that is to be changed to camel case.
* @returns The converted string to camel case.
*
* @example
* const convertedStr1 = camelCase('camelCase') // returns 'camelCase'
* const convertedStr2 = camelCase('some whitespace') // returns 'someWhitespace'
* const convertedStr3 = camelCase('hyphen-text') // returns 'hyphenText'
* const convertedStr4 = camelCase('HTTPRequest') // returns 'httpRequest'
*/
function camelCase(str) {
	return camelCase$1(normalizeForCase(deburr(str)));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/endsWith.mjs
/**
* Checks if a string contains another string at the end of the string.
*
* Checks if one string endsWith another string. Optional position parameter to offset searching before a certain index.
*
* @param str - The string that might contain the target string.
* @param target - The string to search for.
* @param position - An optional position from the start to search up to this index
* @returns True if the str string ends with the target string.
*
* @example
* const isPrefix = endsWith('fooBar', 'foo') // returns true
* const isPrefix = endsWith('fooBar', 'bar') // returns false
* const isPrefix = endsWith('fooBar', 'abc') // returns false
* const isPrefix = endsWith('fooBar', 'foo', 3) // returns true
* const isPrefix = endsWith('fooBar', 'abc', 5) // returns false
*/
function endsWith(str, target, position) {
	if (str == null || target == null) return false;
	if (position == null) position = str.length;
	return str.endsWith(target, position);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/escape.mjs
/**
* Converts the characters "&", "<", ">", '"', and "'" in `str` to their corresponding HTML entities.
* For example, "<" becomes "&lt;".
*
* @param str  The string to escape.
* @returns Returns the escaped string.
*
* @example
* escape('This is a <div> element.'); // returns 'This is a &lt;div&gt; element.'
* escape('This is a "quote"'); // returns 'This is a &quot;quote&quot;'
* escape("This is a 'quote'"); // returns 'This is a &#39;quote&#39;'
* escape('This is a & symbol'); // returns 'This is a &amp; symbol'
*/
function escape(string) {
	return escape$1(toString(string));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/escapeRegExp.mjs
/**
* Escapes the RegExp special characters "^", "$", "\\", ".", "*", "+", "?", "(", ")", "[", "]", "{", "}", and "|" in `str`.
*
* @param str The string to escape.
* @returns Returns the escaped string.
*
* @example
* import { escapeRegExp } from 'es-toolkit/string';
*
* escapeRegExp('[es-toolkit](https://es-toolkit.dev/)'); // returns '\[es-toolkit\]\(https://es-toolkit\.dev/\)'
*/
function escapeRegExp(str) {
	return escapeRegExp$1(toString(str));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/kebabCase.mjs
/**
* Converts a string to kebab case.
*
* Kebab case is the naming convention in which each word is written in lowercase and separated by a dash (-) character.
*
* @param str - The string that is to be changed to kebab case.
* @returns The converted string to kebab case.
*
* @example
* const convertedStr1 = kebabCase('camelCase') // returns 'camel-case'
* const convertedStr2 = kebabCase('some whitespace') // returns 'some-whitespace'
* const convertedStr3 = kebabCase('hyphen-text') // returns 'hyphen-text'
* const convertedStr4 = kebabCase('HTTPRequest') // returns 'http-request'
*/
function kebabCase(str) {
	return kebabCase$1(normalizeForCase(deburr(str)));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/lowerCase.mjs
/**
* Converts a string to lower case.
*
* Lower case is the naming convention in which each word is written in lowercase and separated by an space ( ) character.
*
* @param str - The string that is to be changed to lower case.
* @returns The converted string to lower case.
*
* @example
* const convertedStr1 = lowerCase('camelCase') // returns 'camel case'
* const convertedStr2 = lowerCase('some whitespace') // returns 'some whitespace'
* const convertedStr3 = lowerCase('hyphen-text') // returns 'hyphen text'
* const convertedStr4 = lowerCase('HTTPRequest') // returns 'http request'
*/
function lowerCase(str) {
	return lowerCase$1(normalizeForCase(deburr(str)));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/lowerFirst.mjs
/**
* Converts the first character of string to lower case.
*
* @param str - The string that is to be changed
* @returns The converted string.
*
* @example
* const convertedStr1 = lowerCase('fred') // returns 'fred'
* const convertedStr2 = lowerCase('Fred') // returns 'fred'
* const convertedStr3 = lowerCase('FRED') // returns 'fRED'
*/
function lowerFirst(str) {
	return lowerFirst$1(toString(str));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/pad.mjs
/**
* Pads string on the left and right sides if it's shorter than length. Padding characters are truncated if they can't be evenly divided by length.
* If the length is less than or equal to the original string's length, or if the padding character is an empty string, the original string is returned unchanged.
*
* @param str - The string to pad.
* @param [length] - The length of the resulting string once padded.
* @param [chars] - The character(s) to use for padding.
* @returns The padded string, or the original string if padding is not required.
*
* @example
* const result1 = pad('abc', 8);         // result will be '  abc   '
* const result2 = pad('abc', 8, '_-');   // result will be '_-abc_-_'
* const result3 = pad('abc', 3);         // result will be 'abc'
* const result4 = pad('abc', 2);         // result will be 'abc'
*
*/
function pad(str, length, chars) {
	return pad$1(toString(str), length, chars);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/padEnd.mjs
/**
* Pads the end of a string with a given character until it reaches the specified length.
*
* If the length is less than or equal to the original string's length, or if the padding character is an empty string,
* the original string is returned unchanged.
*
* @param str - The string to pad.
* @param [length] - The length of the resulting string once padded.
* @param [chars] - The character(s) to use for padding.
* @returns The padded string, or the original string if padding is not required.
*
* @example
* const result1 = padEnd('abc', 6);          // result will be 'abc   '
* const result2 = padEnd('abc', 6, '_-');    // result will be 'abc_-_'
* const result3 = padEnd('abc', 3);          // result will be 'abc'
* const result4 = padEnd('abc', 2);          // result will be 'abc'
*/
function padEnd(str, length = 0, chars = " ") {
	return toString(str).padEnd(length, chars);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/padStart.mjs
/**
* Pads the start of a string with a given character until it reaches the specified length.
*
* If the length is less than or equal to the original string's length, or if the padding character is an empty string,
* the original string is returned unchanged.
*
* @param str - The string to pad.
* @param [length] - The length of the resulting string once padded.
* @param [chars] - The character(s) to use for padding.
* @returns The padded string, or the original string if padding is not required.
*
* @example
* const result1 = padStart('abc', 6);          // result will be '   abc'
* const result2 = padStart('abc', 6, '_-');    // result will be '_-_abc'
* const result3 = padStart('abc', 3);          // result will be 'abc'
* const result4 = padStart('abc', 2);          // result will be 'abc'
*/
function padStart(str, length = 0, chars = " ") {
	return toString(str).padStart(length, chars);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/_internal/MAX_SAFE_INTEGER.mjs
var MAX_SAFE_INTEGER = Number.MAX_SAFE_INTEGER;
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/repeat.mjs
/**
* Repeats the given string n times.
*
* If n is less than 1, an empty string is returned, or if the string is an empty string,
* the original string is returned unchanged.
*
* @param str - The string to repeat.
* @param n - The number of times to repeat the string.
* @returns The repeated string, or an empty string if n is less than 1.
*
* @example
* repeat('abc', 0); // ''
* repeat('abc', 2); // 'abcabc'
*/
function repeat(str, n, guard) {
	if (guard ? isIterateeCall(str, n, guard) : n === void 0) n = 1;
	else n = toInteger(n);
	if (n < 1 || n > MAX_SAFE_INTEGER) return "";
	return toString(str).repeat(n);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/replace.mjs
/**
* Replaces the matched pattern with the replacement string.
*
* @param {} target - The target string.
* @param {} pattern - The pattern to match.
* @param {} replacement - The replacement string or a function that returns the replacement string.
* @returns The new string with the matched pattern replaced.
*
* @example
* replace('abcde', 'de', '123'); // 'abc123'
* replace('abcde', /[bd]/g, '-'); // 'a-c-e'
* replace('abcde', 'de', substring => substring.toUpperCase()); // 'abcDE'
* replace('abcde', /[bd]/g, substring => substring.toUpperCase()); // 'aBcDe'
*/
function replace(target, pattern, replacement) {
	if (arguments.length < 3) return toString(target);
	return toString(target).replace(pattern, replacement);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/snakeCase.mjs
/**
* Converts a string to snake case.
*
* Snake case is the naming convention in which each word is written in lowercase and separated by an underscore (_) character.
*
* @param str - The string that is to be changed to snake case.
* @returns The converted string to snake case.
*
* @example
* const convertedStr1 = snakeCase('camelCase') // returns 'camel_case'
* const convertedStr2 = snakeCase('some whitespace') // returns 'some_whitespace'
* const convertedStr3 = snakeCase('hyphen-text') // returns 'hyphen_text'
* const convertedStr4 = snakeCase('HTTPRequest') // returns 'http_request'
*/
function snakeCase(str) {
	return snakeCase$1(normalizeForCase(deburr(str)));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/split.mjs
function split(string, separator, limit) {
	return toString(string).split(separator, limit);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/startCase.mjs
/**
* Converts the first character of each word in a string to uppercase and the remaining characters to lowercase.
*
* Start case is the naming convention in which each word is written with an initial capital letter.
* @param str - The string to convert.
* @returns The converted string.
*
* @example
* const result1 = startCase('hello world');  // result will be 'Hello World'
* const result2 = startCase('HELLO WORLD');  // result will be 'HELLO WORLD'
* const result3 = startCase('hello-world');  // result will be 'Hello World'
* const result4 = startCase('hello_world');  // result will be 'Hello World'
*/
function startCase(str) {
	const words$1$1 = words$1(normalizeForCase(deburr(str)).trim());
	let result = "";
	for (let i = 0; i < words$1$1.length; i++) {
		const word = words$1$1[i];
		if (result) result += " ";
		if (word === word.toUpperCase()) result += word;
		else result += word[0].toUpperCase() + word.slice(1).toLowerCase();
	}
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/startsWith.mjs
/**
* Checks if a string contains another string at the beginning of the string.
*
* Checks if one string startsWith another string. Optional position parameter to start searching from a certain index.
*
* @param str - The string that might contain the target string.
* @param target - The string to search for.
* @param position - An optional offset to start searching in the str string
* @returns True if the str string starts with the target string.
*
* @example
* const isPrefix = startsWith('fooBar', 'foo') // returns true
* const isPrefix = startsWith('fooBar', 'bar') // returns false
* const isPrefix = startsWith('fooBar', 'abc') // returns false
* const isPrefix = startsWith('fooBar', 'Bar', 2) // returns true
* const isPrefix = startsWith('fooBar', 'Bar', 5) // returns false
*/
function startsWith(str, target, position) {
	if (str == null || target == null) return false;
	if (position == null) position = 0;
	return str.startsWith(target, position);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/template.mjs
var esTemplateRegExp = /\$\{([^\\}]*(?:\\.[^\\}]*)*)\}/g;
var unEscapedRegExp = /['\n\r\u2028\u2029\\]/g;
var noMatchExp = /($^)/;
var escapeMap = /* @__PURE__ */ new Map([
	["\\", "\\"],
	["'", "'"],
	["\n", "n"],
	["\r", "r"],
	["\u2028", "u2028"],
	["\u2029", "u2029"]
]);
function escapeString(match) {
	return `\\${escapeMap.get(match)}`;
}
var defaultInterpolateRegExp = /<%=([\s\S]+?)%>/g;
var templateSettings = {
	escape: /<%-([\s\S]+?)%>/g,
	evaluate: /<%([\s\S]+?)%>/g,
	interpolate: defaultInterpolateRegExp,
	variable: "",
	imports: { _: {
		escape,
		template
	} }
};
/**
* Compiles a template string into a function that can interpolate data properties.
*
* This function allows you to create a template with custom delimiters for escaping,
* evaluating, and interpolating values. It can also handle custom variable names and
* imported functions.
*
* @param string - The template string.
* @param [options] - The options object.
* @param [options.escape] - The regular expression for "escape" delimiter.
* @param [options.evaluate] - The regular expression for "evaluate" delimiter.
* @param [options.interpolate] - The regular expression for "interpolate" delimiter.
* @param [options.variable] - The data object variable name.
* @param [options.imports] - The object of imported functions.
* @param [options.sourceURL] - The source URL of the template.
* @param [guard] - The guard to detect if the function is called with `options`.
* @returns Returns the compiled template function.
*
* @example
* // Use the "escape" delimiter to escape data properties.
* const compiled = template('<%- value %>');
* compiled({ value: '<div>' }); // returns '&lt;div&gt;'
*
* @example
* // Use the "interpolate" delimiter to interpolate data properties.
* const compiled = template('<%= value %>');
* compiled({ value: 'Hello, World!' }); // returns 'Hello, World!'
*
* @example
* // Use the "evaluate" delimiter to evaluate JavaScript code.
* const compiled = template('<% if (value) { %>Yes<% } else { %>No<% } %>');
* compiled({ value: true }); // returns 'Yes'
*
* @example
* // Use the "variable" option to specify the data object variable name.
* const compiled = template('<%= data.value %>', { variable: 'data' });
* compiled({ value: 'Hello, World!' }); // returns 'Hello, World!'
*
* @example
* // Use the "imports" option to import functions.
* const compiled = template('<%= _.toUpper(value) %>', { imports: { _: { toUpper } } });
* compiled({ value: 'hello, world!' }); // returns 'HELLO, WORLD!'
*
* @example
* // Use the custom "escape" delimiter.
* const compiled = template('<@ value @>', { escape: /<@([\s\S]+?)@>/g });
* compiled({ value: '<div>' }); // returns '&lt;div&gt;'
*
* @example
* // Use the custom "evaluate" delimiter.
* const compiled = template('<# if (value) { #>Yes<# } else { #>No<# } #>', { evaluate: /<#([\s\S]+?)#>/g });
* compiled({ value: true }); // returns 'Yes'
*
* @example
* // Use the custom "interpolate" delimiter.
* const compiled = template('<$ value $>', { interpolate: /<\$([\s\S]+?)\$>/g });
* compiled({ value: 'Hello, World!' }); // returns 'Hello, World!'
*
* @example
* // Use the "sourceURL" option to specify the source URL of the template.
* const compiled = template('hello <%= user %>!', { sourceURL: 'template.js' });
*/
function template(string, options, guard) {
	string = toString(string);
	if (guard) options = templateSettings;
	options = defaults({ ...options }, templateSettings);
	const delimitersRegExp = new RegExp([
		options.escape?.source ?? noMatchExp.source,
		options.interpolate?.source ?? noMatchExp.source,
		options.interpolate === defaultInterpolateRegExp ? esTemplateRegExp.source : noMatchExp.source,
		options.evaluate?.source ?? noMatchExp.source,
		"$"
	].join("|"), "g");
	let lastIndex = 0;
	let isEvaluated = false;
	let source = `__p += ''`;
	for (const match of string.matchAll(delimitersRegExp)) {
		const [fullMatch, escapeValue, interpolateValue, esTemplateValue, evaluateValue] = match;
		const { index } = match;
		source += ` + '${string.slice(lastIndex, index).replace(unEscapedRegExp, escapeString)}'`;
		if (escapeValue) source += ` + _.escape(${escapeValue})`;
		if (interpolateValue) source += ` + ((${interpolateValue}) == null ? '' : ${interpolateValue})`;
		else if (esTemplateValue) source += ` + ((${esTemplateValue}) == null ? '' : ${esTemplateValue})`;
		if (evaluateValue) {
			source += `;\n${evaluateValue};\n __p += ''`;
			isEvaluated = true;
		}
		lastIndex = index + fullMatch.length;
	}
	const imports = defaults({ ...options.imports }, templateSettings.imports);
	const importsKeys = Object.keys(imports);
	const importValues = Object.values(imports);
	const sourceURL = `//# sourceURL=${options.sourceURL ? String(options.sourceURL).replace(/[\r\n]/g, " ") : `es-toolkit.templateSource[${Date.now()}]`}\n`;
	const compiledFunction = `function(${options.variable || "obj"}) {
    let __p = '';
    ${options.variable ? "" : "if (obj == null) { obj = {}; }"}
    ${isEvaluated ? `function print() { __p += Array.prototype.join.call(arguments, ''); }` : ""}
    ${options.variable ? source : `with(obj) {\n${source}\n}`}
    return __p;
  }`;
	const result = attempt(() => new Function(...importsKeys, `${sourceURL}return ${compiledFunction}`)(...importValues));
	result.source = compiledFunction;
	if (result instanceof Error) throw result;
	return result;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/toLower.mjs
/**
* Converts the given value to a string and transforms it to lower case.
* The function can handle various input types by first converting them to strings.
*
* @param [value=''] The value to convert.
* @returns Returns the lower cased string.
* @example
*
* toLower('--FOO-BAR--');
* // => '--foo-bar--'
*
* toLower(null);
* // => ''
*
* toLower([1, 2, 3]);
* // => '1,2,3'
*/
function toLower(value) {
	return toString(value).toLowerCase();
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/toUpper.mjs
/**
* Converts `string`, as a whole, to upper case just like
* [String#toUpperCase](https://mdn.io/toUpperCase).
*
* @param [value=''] The value to convert.
* @returns Returns the upper cased string.
* @example
*
* toUpper('--foo-bar--');
* // => '--FOO-BAR--'
*
* toUpper(null);
* // => ''
*
* toUpper([1, 2, 3]);
* // => '1,2,3'
*/
function toUpper(value) {
	return toString(value).toUpperCase();
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/trim.mjs
function trim(str, chars, guard) {
	if (str == null) return "";
	if (guard != null || chars == null) return str.toString().trim();
	switch (typeof chars) {
		case "object": if (Array.isArray(chars)) return trim$1(str, chars.flatMap((x) => x.toString().split("")));
		else return trim$1(str, chars.toString().split(""));
		default: return trim$1(str, chars.toString().split(""));
	}
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/trimEnd.mjs
/**
* Removes trailing whitespace or specified characters from a string.
*
* @param str - The string from which trailing characters will be trimmed.
* @param chars - The character(s) to remove from the end of the string.
* @param guard - Enables use as an iteratee for methods like `map`.
* @returns Returns the trimmed string.
*
* @example
* trimEnd('  abc  ');
* // => '  abc'
*
* trimEnd('-_-abc-_-', '_-');
* // => '-_-abc'
*/
function trimEnd(str, chars, guard) {
	if (str == null) return "";
	if (guard != null || chars == null) return str.toString().trimEnd();
	return trimEnd$1(str, chars.toString().split(""));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/trimStart.mjs
/**
* Removes leading whitespace or specified characters from a string.
*
* @param str - The string from which leading characters will be trimmed.
* @param chars - The character(s) to remove from the start of the string.
* @param guard - Enables use as an iteratee for methods like `map`.
* @returns Returns the trimmed string.
*
* @example
* trimStart('  abc  ');
* // => 'abc  '
*
* trimStart('-_-abc-_-', '_-');
* // => 'abc-_-'
*/
function trimStart(str, chars, guard) {
	if (str == null) return "";
	if (guard != null || chars == null) return str.toString().trimStart();
	return trimStart$1(str, chars.toString().split(""));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/unescape.mjs
/**
* Converts the HTML entities `&amp;`, `&lt;`, `&gt;`, `&quot;`, and `&#39;` in `str` to their corresponding characters.
* It is the inverse of `escape`.
*
* @param str The string to unescape.
* @returns Returns the unescaped string.
*
* @example
* unescape('This is a &lt;div&gt; element.'); // returns 'This is a <div> element.'
* unescape('This is a &quot;quote&quot;'); // returns 'This is a "quote"'
* unescape('This is a &#39;quote&#39;'); // returns 'This is a 'quote''
* unescape('This is a &amp; symbol'); // returns 'This is a & symbol'
*/
function unescape(str) {
	return unescape$1(toString(str));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/upperCase.mjs
/**
* Converts a string to upper case.
*
* Upper case is the naming convention in which each word is written in uppercase and separated by an space ( ) character.
*
* @param str - The string that is to be changed to upper case.
* @returns The converted string to upper case.
*
* @example
* const convertedStr1 = upperCase('camelCase') // returns 'CAMEL CASE'
* const convertedStr2 = upperCase('some whitespace') // returns 'SOME WHITESPACE'
* const convertedStr3 = upperCase('hyphen-text') // returns 'HYPHEN TEXT'
* const convertedStr4 = upperCase('HTTPRequest') // returns 'HTTP REQUEST'
*/
function upperCase(str) {
	return upperCase$1(normalizeForCase(deburr(str)));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/upperFirst.mjs
/**
* Converts the first character of string to upper case.
*
* @param str - The string that is to be changed
* @returns The converted string.
*
* @example
* const convertedStr1 = upperFirst('fred') // returns 'Fred'
* const convertedStr2 = upperFirst('Fred') // returns 'Fred'
* const convertedStr3 = upperFirst('FRED') // returns 'FRED'
*/
function upperFirst(str) {
	return upperFirst$1(toString(str));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/string/words.mjs
var rNonCharLatin = "\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf\\xd7\\xf7";
var rUnicodeUpper = "\\p{Lu}";
var rUnicodeLower = "\\p{Ll}";
var rMisc = "(?:[\\p{Lm}\\p{Lo}]\\p{M}*)";
var rNumber = "\\d";
var rUnicodeOptContrLower = "(?:['’](?:d|ll|m|re|s|t|ve))?";
var rUnicodeOptContrUpper = "(?:['’](?:D|LL|M|RE|S|T|VE))?";
var rUnicodeBreak = `[\\p{Z}\\p{P}${rNonCharLatin}]`;
var rUnicodeMiscUpper = `(?:${rUnicodeUpper}|${rMisc})`;
var rUnicodeMiscLower = `(?:${rUnicodeLower}|${rMisc})`;
var rUnicodeWord = RegExp([
	`${rUnicodeUpper}?${rUnicodeLower}+${rUnicodeOptContrLower}(?=${rUnicodeBreak}|${rUnicodeUpper}|$)`,
	`${rUnicodeMiscUpper}+${rUnicodeOptContrUpper}(?=${rUnicodeBreak}|${rUnicodeUpper}${rUnicodeMiscLower}|$)`,
	`${rUnicodeUpper}?${rUnicodeMiscLower}+${rUnicodeOptContrLower}`,
	`${rUnicodeUpper}+${rUnicodeOptContrUpper}`,
	`${rNumber}*(?:1ST|2ND|3RD|(?![123])${rNumber}TH)(?=\\b|[a-z_])`,
	`${rNumber}*(?:1st|2nd|3rd|(?![123])${rNumber}th)(?=\\b|[A-Z_])`,
	`${rNumber}+`,
	"\\p{Emoji_Presentation}",
	"\\p{Extended_Pictographic}"
].join("|"), "gu");
/**
* Splits `string` into an array of its words.
*
* @param str - The string or object that is to be split into words.
* @param [pattern] - The pattern to match words.
* @returns Returns the words of `string`.
*
* @example
* const wordsArray1 = words('fred, barney, & pebbles');
* // => ['fred', 'barney', 'pebbles']
*/
function words(str, pattern = rUnicodeWord, guard) {
	const input = toString(str);
	if (guard) pattern = rUnicodeWord;
	if (typeof pattern === "number") pattern = pattern.toString();
	return Array.from(input.match(pattern) ?? []).filter((x) => x !== "");
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/cond.mjs
function cond(pairs) {
	const length = pairs.length;
	const processedPairs = pairs.map((pair) => {
		const predicate = pair[0];
		const func = pair[1];
		if (!isFunction$1(func)) throw new TypeError("Expected a function");
		return [iteratee(predicate), func];
	});
	return function(...args) {
		for (let i = 0; i < length; i++) {
			const pair = processedPairs[i];
			const predicate = pair[0];
			const func = pair[1];
			if (predicate.apply(this, args)) return func.apply(this, args);
		}
	};
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/constant.mjs
/**
* Creates a new function that always returns `value`.
*
* @template T - The type of the value to return.
* @param value - The value to return from the new function.
* @returns Returns the new constant function.
*
* @example
* const object = { a: 1 };
* const returnsObject = constant(object);
*
* returnsObject(); // => { a: 1 }
* returnsObject() === object; // => true
*/
function constant(value) {
	return () => value;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/defaultTo.mjs
/**
* Returns the default value for `null`, `undefined`, and `NaN`.
*
* @template T - The type of the value parameter
* @template D - The type of the defaultValue parameter
* @param value - The value to check.
* @param defaultValue - The default value to return if the first value is null, undefined, or NaN.
* @returns Returns either the first value or the default value.
*
* @example
* defaultTo(null, 'default') // returns 'default'
* defaultTo(undefined, 42) // returns 42
* defaultTo(NaN, 0) // returns 0
* defaultTo('actual', 'default') // returns 'actual'
* defaultTo(123, 0) // returns 123
*/
function defaultTo(value, defaultValue) {
	if (value == null || Number.isNaN(value)) return defaultValue;
	return value;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/gt.mjs
/**
* Checks if value is greater than other.
*
* @param value The value to compare.
* @param other The other value to compare.
* @returns Returns `true` if value is greater than other, else `false`.
*
* @example
* gt(3, 1); // true
* gt(3, 3); // false
* gt(1, 3); // false
*/
function gt(value, other) {
	if (typeof value === "string" && typeof other === "string") return value > other;
	return toNumber(value) > toNumber(other);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/gte.mjs
/**
* Checks if value is greater than or equal to other.
*
* @param value The value to compare.
* @param other The other value to compare.
* @returns Returns `true` if value is greater than or equal to other, else `false`.
*
* @example
* gte(3, 1); // => true
* gte(3, 3); // => true
* gte(1, 3); // => false
*/
function gte(value, other) {
	if (typeof value === "string" && typeof other === "string") return value >= other;
	return toNumber(value) >= toNumber(other);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/invoke.mjs
/**
* Invokes the method at `path` of `object` with the given arguments.
*
* @param object - The object to query.
* @param path - The path of the method to invoke.
* @param args - The arguments to invoke the method with.
* @returns Returns the result of the invoked method.
*
* @example
* const object = {
*   a: {
*     b: function (x, y) {
*       return x + y;
*     }
*   }
* };
*
* invoke(object, 'a.b', [1, 2]); // => 3
* invoke(object, ['a', 'b'], [1, 2]); // => 3
*/
function invoke(object, path, ...args) {
	args = args.flat(1);
	if (object == null) return;
	switch (typeof path) {
		case "string":
			if (typeof object === "object" && Object.hasOwn(object, path)) return invokeImpl(object, [path], args);
			return invokeImpl(object, toPath(path), args);
		case "number":
		case "symbol": return invokeImpl(object, [path], args);
		default: if (Array.isArray(path)) return invokeImpl(object, path, args);
		else return invokeImpl(object, [path], args);
	}
}
function invokeImpl(object, path, args) {
	const parent = get(object, path.slice(0, -1), object);
	if (parent == null) return;
	let lastKey = last(path);
	const lastValue = lastKey?.valueOf();
	if (typeof lastValue === "number") lastKey = toKey(lastValue);
	else lastKey = String(lastKey);
	return get(parent, lastKey)?.apply(parent, args);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/lt.mjs
/**
* Checks if value is less than other.
*
* @param value The value to compare.
* @param other The other value to compare.
* @returns Returns `true` if value is less than other, else `false`.
*
* @example
* lt(1, 3); // true
* lt(3, 3); // false
* lt(3, 1); // false
*/
function lt(value, other) {
	if (typeof value === "string" && typeof other === "string") return value < other;
	return toNumber(value) < toNumber(other);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/lte.mjs
/**
* Checks if value is less than or equal to other.
*
* @param value The value to compare.
* @param other The other value to compare.
* @returns Returns `true` if value is less than or equal to other, else `false`.
*
* @example
* lte(1, 3); // => true
* lte(3, 3); // => true
* lte(3, 1); // => false
*/
function lte(value, other) {
	if (typeof value === "string" && typeof other === "string") return value <= other;
	return toNumber(value) <= toNumber(other);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/method.mjs
/**
* Creates a function that invokes the method at `path` of a given object with the provided arguments.
*
* @param path - The path of the method to invoke.
* @param args - The arguments to invoke the method with.
* @returns Returns a new function that takes an object and invokes the method at `path` with `args`.
*
* @example
* const object = {
*   a: {
*     b: function (x, y) {
*       return x + y;
*     }
*   }
* };
*
* const add = method('a.b', 1, 2);
* console.log(add(object)); // => 3
*/
function method(path, ...args) {
	return function(object) {
		return invoke(object, path, args);
	};
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/methodOf.mjs
/**
* Creates a function that invokes the method at a given path of `object` with the provided arguments.
*
* @param object - The object to query.
* @param args - The arguments to invoke the method with.
* @returns Returns a new function that takes a path and invokes the method at `path` with `args`.
*
* @example
* const object = {
*  a: {
*   b: function (x, y) {
*    return x + y;
*    }
*   }
* };
*
* const add = methodOf(object, 1, 2);
* console.log(add('a.b')); // => 3
*/
function methodOf(object, ...args) {
	return function(path) {
		return invoke(object, path, args);
	};
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/now.mjs
/**
* Returns the number of milliseconds elapsed since January 1, 1970 00:00:00 UTC.
*
* @returns The current time in milliseconds.
*
* @example
* const currentTime = now();
* console.log(currentTime); // Outputs the current time in milliseconds
*
* @example
* const startTime = now();
* // Some time-consuming operation
* const endTime = now();
* console.log(`Operation took ${endTime - startTime} milliseconds`);
*/
function now() {
	return Date.now();
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/over.mjs
/**
* Creates a function that invokes given functions and returns their results as an array.
*
* @param iteratees - The iteratees to invoke.
* @returns Returns the new function.
*
* @example
* const func = over([Math.max, Math.min]);
* const func2 = over(Math.max, Math.min); // same as above
* func(1, 2, 3, 4);
* // => [4, 1]
* func2(1, 2, 3, 4);
* // => [4, 1]
*
* const func = over(['a', 'b']);
* func({ a: 1, b: 2 });
* // => [1, 2]
*
* const func = over([{ a: 1 }, { b: 2 }]);
* func({ a: 1, b: 2 });
* // => [true, true]
*
* const func = over([['a', 1], ['b', 2]]);
* func({ a: 1, b: 2 });
* // => [true, true]
*/
function over(...iteratees) {
	if (iteratees.length === 1 && Array.isArray(iteratees[0])) iteratees = iteratees[0];
	const funcs = iteratees.map((item) => iteratee(item));
	return function(...args) {
		return funcs.map((func) => func.apply(this, args));
	};
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/overEvery.mjs
/**
* Creates a function that checks if all of the given predicates return truthy for the provided values.
*
* This function takes multiple predicates, which can either be individual predicate functions or arrays of predicates,
* and returns a new function that checks if all of the predicates return truthy when called with the provided values.
*
* @template T - The type of the values to be checked.
*
* @param predicates -
*   A list of predicates or arrays of predicates. Each predicate is a function that takes one or more values of
*   type `T` and returns a boolean indicating whether the condition is satisfied for those values.
*
* @returns A function that takes a list of values and returns `true` if all of the
*   predicates return truthy for the provided values, and `false` otherwise.
*
* @example
* const func = overEvery(
*   (value) => typeof value === 'string',
*   (value) => value.length > 3
* );
*
* func("hello"); // true
* func("hi"); // false
* func(42); // false
*
* @example
* const func = overEvery([
*   (value) => value.a > 0,
*   (value) => value.b > 0
* ]);
*
* func({ a: 1, b: 2 }); // true
* func({ a: 0, b: 2 }); // false
*
* @example
* const func = overEvery(
*   (a, b) => typeof a === 'string' && typeof b === 'string',
*   (a, b) => a.length > 3 && b.length > 3
* );
*
* func("hello", "world"); // true
* func("hi", "world"); // false
* func(1, 10); // false
*/
function overEvery(...predicates) {
	return function(...values) {
		for (let i = 0; i < predicates.length; ++i) {
			const predicate = predicates[i];
			if (!Array.isArray(predicate)) {
				if (!iteratee(predicate).apply(this, values)) return false;
				continue;
			}
			for (let j = 0; j < predicate.length; ++j) if (!iteratee(predicate[j]).apply(this, values)) return false;
		}
		return true;
	};
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/overSome.mjs
/**
* Creates a function that checks if any of the given predicates return truthy for the provided values.
*
* This function takes multiple predicates, which can either be individual predicate functions or arrays of predicates,
* and returns a new function that checks if any of the predicates return truthy when called with the provided values.
*
* @template T - The type of the values to be checked.
*
* @param predicates -
*   A list of predicates or arrays of predicates. Each predicate is a function that takes one or more values of
*   type `T` and returns a boolean indicating whether the condition is satisfied for those values.
*
* @returns A function that takes a list of values and returns `true` if any of the
*   predicates return truthy for the provided values, and `false` otherwise.
*
* @example
* const func = overSome(
*   (value) => typeof value === 'string',
*   (value) => typeof value === 'number',
*   (value) => typeof value === 'symbol'
* );
*
* func("hello"); // true
* func(42); // true
* func(Symbol()); // true
* func([]); // false
*
* @example
* const func = overSome([
*   (value) => value.a > 0,
*   (value) => value.b > 0
* ]);
*
* func({ a: 0, b: 2 }); // true
* func({ a: 0, b: 0 }); // false
*
* @example
* const func = overSome(
*   (a, b) => typeof a === 'string' && typeof b === 'string',
*   (a, b) => a > 0 && b > 0
* );
*
* func("hello", "world"); // true
* func(1, 10); // true
* func(0, 2); // false
*/
function overSome(...predicates) {
	return function(...values) {
		for (let i = 0; i < predicates.length; ++i) {
			const predicate = predicates[i];
			if (!Array.isArray(predicate)) {
				if (iteratee(predicate).apply(this, values)) return true;
				continue;
			}
			for (let j = 0; j < predicate.length; ++j) if (iteratee(predicate[j]).apply(this, values)) return true;
		}
		return false;
	};
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/stubArray.mjs
function stubArray() {
	return [];
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/stubFalse.mjs
function stubFalse() {
	return false;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/stubObject.mjs
/**
* Returns an empty object.
*
* @returns An empty object.
* @example
* stubObject() // Returns {}
*/
function stubObject() {
	return {};
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/stubString.mjs
function stubString() {
	return "";
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/stubTrue.mjs
function stubTrue() {
	return true;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/_internal/MAX_ARRAY_LENGTH.mjs
var MAX_ARRAY_LENGTH = 4294967295;
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/toLength.mjs
/**
* Converts the value to a valid index. A valid index is an integer that is greater than or equal to `0` and less than or equal to `2^32 - 1`.
*
* It converts the given value to an integer. If the value is less than `0`, it returns `0`. If the value exceeds `2^32 - 1`, it returns `2^32 - 1`. Values that cannot be converted to a number (such as `NaN` or non-numeric strings) return `0`.
*
* @param value - The value to convert to a valid index.
* @returns The converted value.
*
* @example
* toLength(3.2)  // => 3
* toLength(-1)   // => 0
* toLength(1.9)  // => 1
* toLength('42') // => 42
* toLength(null) // => 0
* toLength('a')  // => 0
*/
function toLength(value) {
	if (value == null) return 0;
	return clamp(toInteger(value), 0, MAX_ARRAY_LENGTH);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/toPlainObject.mjs
/**
* Converts value to a plain object flattening inherited enumerable string keyed properties of value to own properties of the plain object.
*
* @param value The value to convert.
* @returns Returns the converted plain object.
*
* @example
* function Foo() {
*   this.b = 2;
* }
* Foo.prototype.c = 3;
* toPlainObject(new Foo()); // { b: 2, c: 3 }
*/
function toPlainObject(value) {
	const plainObject = {};
	const valueKeys = keysIn(value);
	for (let i = 0; i < valueKeys.length; i++) {
		const key = valueKeys[i];
		const objValue = value[key];
		if (key === "__proto__") Object.defineProperty(plainObject, key, {
			configurable: true,
			enumerable: true,
			value: objValue,
			writable: true
		});
		else plainObject[key] = objValue;
	}
	return plainObject;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/toSafeInteger.mjs
/**
* Converts `value` to a safe integer.
*
* A safe integer can be compared and represented correctly.
*
* @param value - The value to convert.
* @returns Returns the value converted to a safe integer.
*
* @example
* toSafeInteger(3.2); // => 3
* toSafeInteger(Number.MAX_VALUE); // => 9007199254740991
* toSafeInteger(Infinity); // => 9007199254740991
* toSafeInteger('3.2'); // => 3
* toSafeInteger(NaN); // => 0
* toSafeInteger(null); // => 0
* toSafeInteger(-Infinity); // => -9007199254740991
*/
function toSafeInteger(value) {
	if (value == null) return 0;
	return clamp(toInteger(value), -MAX_SAFE_INTEGER, MAX_SAFE_INTEGER);
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/util/uniqueId.mjs
/** Counter used to generate unique numeric identifiers. */
var idCounter = 0;
/**
* Generates a unique identifier, optionally prefixed with a given string.
*
* @param [prefix] - An optional string to prefix the unique identifier.
*                            If not provided or not a string, only the unique
*                            numeric identifier is returned.
* @returns A string containing the unique identifier, with the optional
*                   prefix if provided.
*
* @example
* // Generate a unique ID with a prefix
* uniqueId('user_');  // => 'user_1'
*
* @example
* // Generate a unique ID without a prefix
* uniqueId();  // => '2'
*
* @example
* // Subsequent calls increment the internal counter
* uniqueId('item_');  // => 'item_3'
* uniqueId();         // => '4'
*/
function uniqueId(prefix = "") {
	return `${prefix}${++idCounter}`;
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/_virtual/_rolldown/runtime.mjs
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/compat.mjs
var compat_exports = /* @__PURE__ */ __exportAll({
	add: () => add,
	after: () => after,
	ary: () => ary,
	assign: () => assign,
	assignIn: () => assignIn,
	assignInWith: () => assignInWith,
	assignWith: () => assignWith,
	at: () => at,
	attempt: () => attempt,
	before: () => before,
	bind: () => bind,
	bindAll: () => bindAll,
	bindKey: () => bindKey,
	camelCase: () => camelCase,
	capitalize: () => capitalize,
	castArray: () => castArray,
	ceil: () => ceil,
	chunk: () => chunk,
	clamp: () => clamp,
	clone: () => clone$1,
	cloneDeep: () => cloneDeep$1,
	cloneDeepWith: () => cloneDeepWith,
	cloneWith: () => cloneWith,
	compact: () => compact,
	concat: () => concat,
	cond: () => cond,
	conforms: () => conforms,
	conformsTo: () => conformsTo,
	constant: () => constant,
	countBy: () => countBy,
	create: () => create,
	curry: () => curry,
	curryRight: () => curryRight,
	debounce: () => debounce,
	deburr: () => deburr,
	defaultTo: () => defaultTo,
	defaults: () => defaults,
	defaultsDeep: () => defaultsDeep,
	defer: () => defer,
	delay: () => delay,
	difference: () => difference,
	differenceBy: () => differenceBy,
	differenceWith: () => differenceWith,
	divide: () => divide,
	drop: () => drop,
	dropRight: () => dropRight,
	dropRightWhile: () => dropRightWhile,
	dropWhile: () => dropWhile,
	each: () => forEach,
	eachRight: () => forEachRight,
	endsWith: () => endsWith,
	eq: () => isEqualsSameValueZero,
	escape: () => escape,
	escapeRegExp: () => escapeRegExp,
	every: () => every,
	extend: () => assignIn,
	extendWith: () => assignInWith,
	fill: () => fill,
	filter: () => filter,
	find: () => find,
	findIndex: () => findIndex,
	findKey: () => findKey,
	findLast: () => findLast,
	findLastIndex: () => findLastIndex,
	findLastKey: () => findLastKey,
	first: () => head,
	flatMap: () => flatMap,
	flatMapDeep: () => flatMapDeep,
	flatMapDepth: () => flatMapDepth,
	flatten: () => flatten$1,
	flattenDeep: () => flattenDeep,
	flattenDepth: () => flattenDepth,
	flip: () => flip,
	floor: () => floor,
	flow: () => flow,
	flowRight: () => flowRight,
	forEach: () => forEach,
	forEachRight: () => forEachRight,
	forIn: () => forIn,
	forInRight: () => forInRight,
	forOwn: () => forOwn,
	forOwnRight: () => forOwnRight,
	fromPairs: () => fromPairs,
	functions: () => functions,
	functionsIn: () => functionsIn,
	get: () => get,
	groupBy: () => groupBy,
	gt: () => gt,
	gte: () => gte,
	has: () => has,
	hasIn: () => hasIn,
	head: () => head,
	identity: () => identity,
	inRange: () => inRange,
	includes: () => includes,
	indexOf: () => indexOf,
	initial: () => initial,
	intersection: () => intersection,
	intersectionBy: () => intersectionBy,
	intersectionWith: () => intersectionWith,
	invert: () => invert,
	invertBy: () => invertBy,
	invoke: () => invoke,
	invokeMap: () => invokeMap,
	isArguments: () => isArguments,
	isArray: () => isArray,
	isArrayBuffer: () => isArrayBuffer,
	isArrayLike: () => isArrayLike,
	isArrayLikeObject: () => isArrayLikeObject,
	isBoolean: () => isBoolean,
	isBuffer: () => isBuffer,
	isDate: () => isDate,
	isElement: () => isElement,
	isEmpty: () => isEmpty,
	isEqual: () => isEqual,
	isEqualWith: () => isEqualWith,
	isError: () => isError,
	isFinite: () => isFinite$1,
	isFunction: () => isFunction,
	isInteger: () => isInteger,
	isLength: () => isLength,
	isMap: () => isMap,
	isMatch: () => isMatch,
	isMatchWith: () => isMatchWith,
	isNaN: () => isNaN,
	isNative: () => isNative,
	isNil: () => isNil,
	isNull: () => isNull,
	isNumber: () => isNumber,
	isObject: () => isObject,
	isObjectLike: () => isObjectLike,
	isPlainObject: () => isPlainObject,
	isRegExp: () => isRegExp,
	isSafeInteger: () => isSafeInteger,
	isSet: () => isSet,
	isString: () => isString,
	isSymbol: () => isSymbol$1,
	isTypedArray: () => isTypedArray,
	isUndefined: () => isUndefined,
	isWeakMap: () => isWeakMap,
	isWeakSet: () => isWeakSet,
	iteratee: () => iteratee,
	join: () => join,
	kebabCase: () => kebabCase,
	keyBy: () => keyBy,
	keys: () => keys,
	keysIn: () => keysIn,
	last: () => last,
	lastIndexOf: () => lastIndexOf,
	lowerCase: () => lowerCase,
	lowerFirst: () => lowerFirst,
	lt: () => lt,
	lte: () => lte,
	map: () => map,
	mapKeys: () => mapKeys,
	mapValues: () => mapValues,
	matches: () => matches,
	matchesProperty: () => matchesProperty,
	max: () => max,
	maxBy: () => maxBy,
	mean: () => mean,
	meanBy: () => meanBy,
	memoize: () => memoize,
	merge: () => merge,
	mergeWith: () => mergeWith,
	method: () => method,
	methodOf: () => methodOf,
	min: () => min,
	minBy: () => minBy,
	multiply: () => multiply,
	negate: () => negate,
	noop: () => noop,
	now: () => now,
	nth: () => nth,
	nthArg: () => nthArg,
	omit: () => omit,
	omitBy: () => omitBy,
	once: () => once,
	orderBy: () => orderBy,
	over: () => over,
	overArgs: () => overArgs,
	overEvery: () => overEvery,
	overSome: () => overSome,
	pad: () => pad,
	padEnd: () => padEnd,
	padStart: () => padStart,
	parseInt: () => parseInt$1,
	partial: () => partial,
	partialRight: () => partialRight,
	partition: () => partition,
	pick: () => pick,
	pickBy: () => pickBy,
	property: () => property,
	propertyOf: () => propertyOf,
	pull: () => pull,
	pullAll: () => pullAll,
	pullAllBy: () => pullAllBy,
	pullAllWith: () => pullAllWith,
	pullAt: () => pullAt,
	random: () => random,
	range: () => range,
	rangeRight: () => rangeRight,
	rearg: () => rearg,
	reduce: () => reduce,
	reduceRight: () => reduceRight,
	reject: () => reject,
	remove: () => remove,
	repeat: () => repeat,
	replace: () => replace,
	rest: () => rest,
	result: () => result,
	reverse: () => reverse,
	round: () => round,
	sample: () => sample,
	sampleSize: () => sampleSize,
	set: () => set,
	setWith: () => setWith,
	shuffle: () => shuffle,
	size: () => size,
	slice: () => slice,
	snakeCase: () => snakeCase,
	some: () => some,
	sortBy: () => sortBy,
	sortedIndex: () => sortedIndex,
	sortedIndexBy: () => sortedIndexBy,
	sortedIndexOf: () => sortedIndexOf,
	sortedLastIndex: () => sortedLastIndex,
	sortedLastIndexBy: () => sortedLastIndexBy,
	sortedLastIndexOf: () => sortedLastIndexOf,
	split: () => split,
	spread: () => spread,
	startCase: () => startCase,
	startsWith: () => startsWith,
	stubArray: () => stubArray,
	stubFalse: () => stubFalse,
	stubObject: () => stubObject,
	stubString: () => stubString,
	stubTrue: () => stubTrue,
	subtract: () => subtract,
	sum: () => sum,
	sumBy: () => sumBy,
	tail: () => tail,
	take: () => take,
	takeRight: () => takeRight,
	takeRightWhile: () => takeRightWhile,
	takeWhile: () => takeWhile,
	template: () => template,
	templateSettings: () => templateSettings,
	throttle: () => throttle,
	times: () => times,
	toArray: () => toArray,
	toDefaulted: () => toDefaulted,
	toFinite: () => toFinite,
	toInteger: () => toInteger,
	toLength: () => toLength,
	toLower: () => toLower,
	toNumber: () => toNumber,
	toPairs: () => toPairs,
	toPairsIn: () => toPairsIn,
	toPath: () => toPath,
	toPlainObject: () => toPlainObject,
	toSafeInteger: () => toSafeInteger,
	toString: () => toString,
	toUpper: () => toUpper,
	transform: () => transform,
	trim: () => trim,
	trimEnd: () => trimEnd,
	trimStart: () => trimStart,
	truncate: () => truncate,
	unary: () => unary,
	unescape: () => unescape,
	union: () => union,
	unionBy: () => unionBy,
	unionWith: () => unionWith,
	uniq: () => uniq$1,
	uniqBy: () => uniqBy,
	uniqWith: () => uniqWith,
	uniqueId: () => uniqueId,
	unset: () => unset,
	unzip: () => unzip,
	unzipWith: () => unzipWith,
	update: () => update,
	updateWith: () => updateWith,
	upperCase: () => upperCase,
	upperFirst: () => upperFirst,
	values: () => values,
	valuesIn: () => valuesIn,
	without: () => without,
	words: () => words,
	wrap: () => wrap,
	xor: () => xor,
	xorBy: () => xorBy,
	xorWith: () => xorWith,
	zip: () => zip,
	zipObject: () => zipObject,
	zipObjectDeep: () => zipObjectDeep,
	zipWith: () => zipWith
});
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/compat/toolkit.mjs
var toolkit = ((value) => {
	return value;
});
Object.assign(toolkit, compat_exports);
toolkit.partial.placeholder = toolkit;
toolkit.partialRight.placeholder = toolkit;
//#endregion
//#region src/renderer/core/canvas/useCanvasScheduler.ts
var import_quick_lru = /* @__PURE__ */ __toESM(require_quick_lru(), 1);
function createCanvasScheduler() {
	const canvasStore = useCanvasStore();
	const queue = [];
	function targetOf(operation) {
		return operation.element ?? canvasStore.canvas?.canvas;
	}
	function isVisible(element) {
		return element?.offsetParent != null && element.offsetWidth > 0 && element.offsetHeight > 0;
	}
	function isStale(operation) {
		if (operation.isCurrent?.() === false) return true;
		const { element } = operation;
		return Boolean(element && element !== canvasStore.canvas?.canvas && !element.isConnected);
	}
	function run(operation) {
		try {
			operation.run();
		} catch (error) {
			reportError(error, {
				errorType: "canvas_scheduled_operation_failed",
				surface: "graph"
			});
		}
	}
	function flush() {
		for (const operation of queue.splice(0)) {
			if (isStale(operation)) continue;
			if (isVisible(targetOf(operation))) run(operation);
			else queue.push(operation);
		}
	}
	function schedule(operation) {
		if (operation.isCurrent?.() === false) return;
		const existingIndex = operation.key ? queue.findIndex(({ key }) => key === operation.key) : -1;
		if (existingIndex === -1) queue.push(operation);
		else queue[existingIndex] = operation;
		if (isVisible(targetOf(operation))) flush();
	}
	function cancel(key) {
		const index = queue.findIndex((operation) => operation.key === key);
		if (index !== -1) queue.splice(index, 1);
	}
	return {
		schedule,
		flush,
		cancel
	};
}
var useCanvasScheduler = createSharedComposable(createCanvasScheduler);
//#endregion
//#region src/core/graph/litegraphServiceAccess.ts
/** `useLitegraphService` for the modules it imports, which cannot import it back. */
var useLitegraphServiceAccess;
/** Called by `litegraphService` when it loads. */
function provideLitegraphService(useService) {
	useLitegraphServiceAccess = useService;
}
//#endregion
//#region src/stores/subgraphNavigationStore.ts
var useWorkflowService;
/** Called by `workflowService` when it loads; it imports this store. */
function provideWorkflowService(useService) {
	useWorkflowService = useService;
}
/**
* Stores the current subgraph navigation state; a stack representing subgraph
* navigation history from the root graph to the subgraph that is currently
* open.
*/
var useSubgraphNavigationStore = defineStore("subgraphNavigation", () => {
	const workflowStore = useWorkflowStore();
	const canvasStore = useCanvasStore();
	const canvasScheduler = useCanvasScheduler();
	const router = useRouter();
	const routeHash = useRouteHash();
	/** The currently opened subgraph. */
	const activeSubgraph = shallowRef();
	/** The stack of subgraph IDs from the root graph to the currently opened subgraph. */
	const idStack = ref([]);
	/** LRU cache for viewport states. Key: `workflowPath:graphId` */
	const viewportCache = new import_quick_lru.default({ maxSize: 32 });
	/** Get the ID of the root graph for the currently active workflow. */
	const getCurrentRootGraphId = () => {
		return canvasStore.canvas?.graph?.rootGraph.id ?? "root";
	};
	/**
	* Set by saveCurrentViewport() (called from beforeLoadNewGraph) to
	* prevent onNavigated from re-saving a stale viewport during the
	* workflow switch transition. Uses setTimeout instead of rAF so the
	* flag resets even when the tab is backgrounded.
	*/
	let isWorkflowSwitching = false;
	/** Build a workflow-scoped cache key. */
	function buildCacheKey(graphId, workflowRef) {
		return `${(workflowRef ?? workflowStore.activeWorkflow)?.path ?? ""}:${graphId}`;
	}
	/** ID of the graph currently shown on the canvas. */
	function getActiveGraphId() {
		return canvasStore.canvas?.subgraph?.id ?? getCurrentRootGraphId();
	}
	/**
	* A stack representing subgraph navigation history from the root graph to
	* the current opened subgraph.
	*/
	const navigationStack = computed(() => idStack.value.map((id) => useApp().rootGraph.subgraphs.get(id)).filter(isNonNullish));
	/**
	* Restore the navigation stack from a list of subgraph IDs.
	* @see exportState
	*/
	const restoreState = (subgraphIds) => {
		idStack.value.length = 0;
		for (const id of subgraphIds) idStack.value.push(id);
	};
	/**
	* Export the navigation stack as a list of subgraph IDs.
	* @see restoreState
	*/
	const exportState = () => [...idStack.value];
	/** Get the current viewport state, or null if the canvas is not available. */
	const getCurrentViewport = () => {
		const canvas = canvasStore.canvas;
		if (!canvas) return null;
		return {
			scale: canvas.ds.state.scale,
			offset: [...canvas.ds.state.offset]
		};
	};
	/** Save the current viewport state for a graph. */
	function saveViewport(graphId, workflowRef) {
		const viewport = getCurrentViewport();
		if (!viewport) return;
		viewportCache.set(buildCacheKey(graphId, workflowRef), viewport);
	}
	/** Apply a viewport state to the canvas. */
	function applyViewport(viewport) {
		const canvas = canvasStore.canvas;
		if (!canvas) return;
		canvas.ds.scale = viewport.scale;
		canvas.ds.offset[0] = viewport.offset[0];
		canvas.ds.offset[1] = viewport.offset[1];
		canvas.setDirty(true, true);
	}
	function restoreViewport(graphId) {
		const canvas = canvasStore.canvas;
		if (!canvas) return;
		if (getActiveGraphId() === graphId) canvasScheduler.cancel("subgraph-navigation-fit");
		const expectedKey = buildCacheKey(graphId);
		const viewport = viewportCache.get(expectedKey);
		if (viewport) {
			applyViewport(viewport);
			return;
		}
		canvasScheduler.schedule({
			key: "subgraph-navigation-fit",
			isCurrent: () => getActiveGraphId() === graphId,
			run: () => {
				if (!canvas.graph?.nodes.length) return;
				useLitegraphServiceAccess().fitView();
			}
		});
	}
	function onNavigated(subgraph, prevSubgraph) {
		if (!isWorkflowSwitching) {
			if (prevSubgraph) saveViewport(prevSubgraph.id);
			else if (subgraph) saveViewport(getCurrentRootGraphId());
		}
		if (!subgraph) {
			idStack.value.length = 0;
			restoreViewport(getCurrentRootGraphId());
			return;
		}
		const path = findSubgraphPathById(subgraph.rootGraph, subgraph.id);
		if (!!path) idStack.value = [...path];
		else idStack.value = [subgraph.id];
		restoreViewport(subgraph.id);
	}
	watch(() => workflowStore.activeSubgraph, (newValue, oldValue) => {
		onNavigated(newValue, oldValue);
	}, { flush: "sync" });
	let blockNavDepth = 0;
	let initialLoad = true;
	let hashUpdateTail = Promise.resolve();
	const routeWriteStateKey = "comfySubgraphNavigationWrite";
	const pendingRouteWrites = /* @__PURE__ */ new Map();
	let deferredNavigationIntent;
	let latestNavigationIntent;
	let navigationIntentId = 0;
	let routeWriteId = 0;
	let blockedRouteHash;
	let pendingWorkflowResetGraph;
	function createNavigationIntent(hash, source) {
		const intent = {
			id: ++navigationIntentId,
			hash,
			source
		};
		latestNavigationIntent = intent;
		return intent;
	}
	function beginWorkflowNavigation() {
		const intent = {
			id: ++navigationIntentId,
			source: "workflow"
		};
		latestNavigationIntent = intent;
		return intent.id;
	}
	/**
	* Releases a workflow-load intent whose load FAILED: while it stays the
	* newest intent it suppresses the surviving graph's hash forever, so
	* clear it and republish the live graph.
	*/
	function endWorkflowNavigation(navigationId) {
		if (latestNavigationIntent?.source !== "workflow" || latestNavigationIntent.id !== navigationId) return;
		latestNavigationIntent = void 0;
		updateHash("graph");
	}
	async function withNavBlocked(op, blockedHash) {
		const previousBlockedRouteHash = blockedRouteHash;
		blockedRouteHash = blockedHash;
		blockNavDepth++;
		try {
			return await op();
		} finally {
			blockNavDepth--;
			blockedRouteHash = previousBlockedRouteHash;
		}
	}
	function ensureCanvasOnRoot() {
		const root = useApp().rootGraphOrUndefined;
		const canvas = canvasStore.canvas;
		if (!root || !canvas) return;
		if (canvas.graph?.id !== root.id) canvas.setGraph(root);
	}
	async function redirectToRoot(reason, navigationId) {
		if (navigationId !== navigationIntentId) return;
		const rootHash = "#" + useApp().rootGraph.id;
		console.warn(`[subgraphNavigation] ${reason}; redirecting to root graph`);
		try {
			await withNavBlocked(() => writeRouteHash(rootHash, true), rootHash);
		} finally {
			if (navigationId === navigationIntentId) ensureCanvasOnRoot();
		}
	}
	async function navigateToHash(newHash, navigationId, initiator) {
		const root = useApp().rootGraph;
		const locatorId = newHash.slice(1) || root.id;
		const canvas = canvasStore.getCanvas();
		const targetGraph = locatorId === root.id ? root : isUuidShapedSubgraphId(locatorId) ? root.subgraphs.get(locatorId) : void 0;
		if (targetGraph) {
			if (canvas.graph?.id === targetGraph.id) return;
			return withNavBlocked(async () => {
				canvas.setGraph(targetGraph);
			}, newHash);
		}
		for (const workflow of workflowStore.openWorkflows) {
			const { activeState } = workflow;
			if (!activeState) continue;
			const subgraphs = activeState.definitions?.subgraphs ?? [];
			for (const graph of [activeState, ...subgraphs]) {
				if (graph.id !== locatorId) continue;
				try {
					await withNavBlocked(() => useWorkflowService().openWorkflow(workflow, {
						navigationIntentId: navigationId,
						initiator
					}), newHash);
				} catch (err) {
					if (navigationId !== navigationIntentId) return;
					reportError(err, {
						surface: "graph",
						errorType: "workflow_navigation_failure",
						level: "warning",
						context: { stage: "recovery" }
					});
					return redirectToRoot("workflow load failed", navigationId);
				}
				if (navigationId !== navigationIntentId) return;
				const loadedGraph = useApp().rootGraph.id === locatorId ? useApp().rootGraph : useApp().rootGraph.subgraphs.get(locatorId);
				if (!loadedGraph) return redirectToRoot("subgraph not found after workflow load", navigationId);
				if (canvas.graph?.id === loadedGraph.id) return;
				return withNavBlocked(async () => {
					canvas.setGraph(loadedGraph);
				}, newHash);
			}
		}
		await redirectToRoot(`subgraph not found: ${locatorId}`, navigationId);
	}
	async function safeRouterCall(op, label) {
		try {
			return !isNavigationFailure(await op());
		} catch (err) {
			if (!isNavigationFailure(err, NavigationFailureType.duplicated) && !isNavigationFailure(err, NavigationFailureType.cancelled)) console.warn(`[subgraphNavigation] ${label} rejected`, err);
			return false;
		}
	}
	async function writeRouteHash(hash, replace) {
		const writeId = ++routeWriteId;
		pendingRouteWrites.set(writeId, hash);
		const target = {
			hash,
			state: { [routeWriteStateKey]: writeId }
		};
		try {
			return await safeRouterCall(() => replace ? router.replace(target) : router.push(target), replace ? "router.replace" : "router.push");
		} finally {
			pendingRouteWrites.delete(writeId);
		}
	}
	async function syncGraphHash(intent) {
		if (intent.id !== navigationIntentId) return false;
		if (!routeHash.value) {
			if (!await writeRouteHash("#" + useApp().rootGraph.id, true)) return false;
			if (intent.id !== navigationIntentId) return false;
		}
		const currentId = routeHash.value?.slice(1);
		if (intent.hash.slice(1) === currentId) return true;
		return writeRouteHash(intent.hash, false);
	}
	function queueGraphHash(intent) {
		const result = hashUpdateTail.then(() => syncGraphHash(intent));
		hashUpdateTail = result.then(() => void 0, () => void 0);
		return result;
	}
	async function applyNavigationIntent(intent) {
		await navigateToHash(intent.hash, intent.id, intent.source === "route" ? "user" : void 0);
		if (blockNavDepth > 0) return;
		const deferredIntent = deferredNavigationIntent;
		if (deferredIntent?.id === navigationIntentId) {
			deferredNavigationIntent = void 0;
			return applyNavigationIntent(deferredIntent);
		}
		if (intent.source === "graph" && intent.id === navigationIntentId) await queueGraphHash(intent);
	}
	async function navigateToGraph(targetGraph) {
		const canvas = canvasStore.canvas;
		const targetId = targetGraph.id;
		const belongsToCurrentWorkflow = targetGraph === useApp().rootGraph || targetGraph.rootGraph === useApp().rootGraph && useApp().rootGraph.subgraphs.get(targetId) === targetGraph;
		if (!canvas?.graph || !targetId || !belongsToCurrentWorkflow) return false;
		if (canvas.graph === targetGraph) return true;
		const previousGraph = canvas.graph;
		const intent = createNavigationIntent("#" + targetId, "graph");
		await withNavBlocked(async () => canvas.setGraph(targetGraph), intent.hash);
		if (intent.id !== navigationIntentId) return false;
		const hashWritten = await queueGraphHash(intent);
		if (!hashWritten && intent.id === navigationIntentId && canvas.graph === targetGraph) await withNavBlocked(async () => canvas.setGraph(previousGraph), "#" + previousGraph.id);
		return hashWritten && intent.id === navigationIntentId && canvas.graph === targetGraph;
	}
	async function updateHash(source = "graph", workflowNavigationId, currentGraph) {
		const graph = currentGraph ?? canvasStore.getCanvas().graph;
		if (source === "workflow-load") {
			pendingWorkflowResetGraph = void 0;
			if (blockNavDepth > 0 && workflowNavigationId === navigationIntentId && latestNavigationIntent?.source === "workflow" && graph?.id) {
				deferredNavigationIntent = {
					id: workflowNavigationId,
					hash: "#" + graph.id,
					source: "graph"
				};
				return Promise.resolve();
			}
			if (blockNavDepth > 0) return Promise.resolve();
			if (workflowNavigationId !== void 0) {
				if (workflowNavigationId !== navigationIntentId) {
					const latestIntent = latestNavigationIntent;
					return latestIntent && latestIntent.source !== "workflow" ? applyNavigationIntent(latestIntent) : Promise.resolve();
				}
			}
		}
		if (graph === pendingWorkflowResetGraph) {
			pendingWorkflowResetGraph = void 0;
			return Promise.resolve();
		}
		const newId = graph?.id ?? "";
		if (initialLoad) {
			initialLoad = false;
			if (!routeHash.value) return Promise.resolve();
			return applyNavigationIntent(createNavigationIntent(routeHash.value, "restore")).then(() => {
				const activeGraph = canvasStore.getCanvas().graph;
				if (isSubgraph(activeGraph)) workflowStore.activeSubgraph = activeGraph;
			});
		}
		if (!newId) return Promise.resolve();
		const newHash = "#" + newId;
		if (newHash === routeHash.value) return Promise.resolve();
		if (blockNavDepth > 0 && newHash === blockedRouteHash) return Promise.resolve();
		const intent = createNavigationIntent(newHash, "graph");
		if (blockNavDepth > 0) {
			deferredNavigationIntent = intent;
			return Promise.resolve();
		}
		await queueGraphHash(intent);
	}
	watch(() => canvasStore.currentGraph, (graph) => void updateHash("graph", void 0, graph), { flush: "sync" });
	watch(routeHash, (newHash) => {
		initialLoad = false;
		const hash = String(newHash);
		const stateWriteId = router.options.history.state[routeWriteStateKey];
		if (typeof stateWriteId === "number" && pendingRouteWrites.get(stateWriteId) === hash) {
			pendingRouteWrites.delete(stateWriteId);
			return;
		}
		const intent = createNavigationIntent(hash, "route");
		if (blockNavDepth > 0) {
			deferredNavigationIntent = intent;
			return;
		}
		applyNavigationIntent(intent);
	}, { flush: "sync" });
	/** Save the current viewport for the active graph/workflow. Called by
	*  workflowService.beforeLoadNewGraph() before the canvas is overwritten. */
	function saveCurrentViewport(suppressWorkflowReset = true) {
		saveViewport(getActiveGraphId());
		const graph = canvasStore.getCanvas().graph;
		pendingWorkflowResetGraph = suppressWorkflowReset && graph !== useApp().rootGraph ? useApp().rootGraph : void 0;
		isWorkflowSwitching = true;
		setTimeout(() => {
			isWorkflowSwitching = false;
		}, 0);
	}
	return {
		activeSubgraph,
		navigationStack,
		restoreState,
		exportState,
		saveViewport,
		restoreViewport,
		saveCurrentViewport,
		beginWorkflowNavigation,
		endWorkflowNavigation,
		navigateToGraph,
		updateHash,
		/** @internal Exposed for test assertions only. */
		viewportCache
	};
});
//#endregion
//#region src/scripts/nodeHistoryWidgetValues.ts
function isRecord$1(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
__name(isRecord$1, "isRecord");
function nodeHistoryOwnedWidgets(widgets) {
	const owned = widgets.filter(ownsNodeHistory);
	const mirrored = LiteGraph.vueNodesMode ? owned.flatMap((widget) => widget.linkedWidgets ?? []) : [];
	return /* @__PURE__ */ new Set([...owned, ...mirrored]);
}
function collectNodeHistoryWidgets(rootGraph) {
	return new Map([rootGraph, ...rootGraph.subgraphs.values()].flatMap((graph) => graph.nodes.flatMap((node) => {
		const widgets = node.widgets ?? [];
		const owned = nodeHistoryOwnedWidgets(widgets);
		return widgets.filter((widget) => widget.serialize !== false).flatMap((widget, slot) => owned.has(widget) ? [[widgetId(graph.id, node.id, widget.name), slot]] : []);
	})));
}
function nodeKey(graphId, nodeId) {
	return `${graphId}:${String(nodeId)}`;
}
function serializedNodes(state, rootGraphId) {
	const subgraphs = collectSubgraphDefinitions(parseFlattenableSubgraphDefinitions(state.definitions?.subgraphs ?? []));
	const graphs = [[rootGraphId, state.nodes], ...subgraphs.map((subgraph) => [subgraph.id, subgraph.nodes])];
	return new Map(graphs.flatMap(([graphId, nodes]) => nodes.map((node) => [nodeKey(graphId, node.id), node])));
}
function namedValues(node) {
	return isRecord$1(node.widgets_values_named) ? node.widgets_values_named : void 0;
}
function serializedWidgetValue(nodes, widget) {
	const { graphId, nodeId, name } = parseWidgetId(widget);
	const node = nodes.get(nodeKey(graphId, nodeId));
	return node && namedValues(node)?.[name];
}
function slotCount(node) {
	return Array.isArray(node.widgets_values) ? node.widgets_values.length : void 0;
}
function writeWidgetValue(node, { name, slot, liveSlotCount }, value) {
	const named = namedValues(node);
	const positional = node.widgets_values;
	if (!named || !(name in named) || !Array.isArray(positional)) return;
	if (positional.length !== liveSlotCount) return;
	named[name] = cloneDeep(value);
	positional[slot] = cloneDeep(value);
}
function nodeHistoryValuesChanged(previous, current, widgets, rootGraphId) {
	const previousNodes = serializedNodes(previous, rootGraphId);
	const currentNodes = serializedNodes(current, rootGraphId);
	return [...widgets.keys()].some((widget) => !isEqual(serializedWidgetValue(previousNodes, widget), serializedWidgetValue(currentNodes, widget)));
}
function withNodeHistoryValuesFrom(target, source, widgets, rootGraphId) {
	if (!widgets.size) return target;
	const result = cloneDeep(target);
	const targetNodes = serializedNodes(result, rootGraphId);
	const sourceNodes = serializedNodes(source, rootGraphId);
	const ownedByNode = groupBy$1([...widgets].map(([widget, slot]) => ({
		...parseWidgetId(widget),
		slot
	})), ({ graphId, nodeId }) => nodeKey(graphId, nodeId));
	for (const [key, nodeWidgets] of Object.entries(ownedByNode)) {
		const targetNode = targetNodes.get(key);
		const sourceNode = sourceNodes.get(key);
		const sourceValues = sourceNode && namedValues(sourceNode);
		if (!targetNode || !sourceNode || !sourceValues) continue;
		const owned = nodeWidgets.map(({ name }) => name);
		if (!isEqual(omit$1(namedValues(targetNode) ?? {}, owned), omit$1(sourceValues, owned))) continue;
		const liveSlotCount = slotCount(sourceNode);
		for (const { name, slot } of nodeWidgets) if (name in sourceValues) writeWidgetValue(targetNode, {
			name,
			slot,
			liveSlotCount
		}, sourceValues[name]);
	}
	return result;
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.nodeHistoryWidgetValues = window.comfyAPI.nodeHistoryWidgetValues || {};
window.comfyAPI.nodeHistoryWidgetValues.collectNodeHistoryWidgets = collectNodeHistoryWidgets;
window.comfyAPI.nodeHistoryWidgetValues.nodeHistoryValuesChanged = nodeHistoryValuesChanged;
window.comfyAPI.nodeHistoryWidgetValues.withNodeHistoryValuesFrom = withNodeHistoryValuesFrom;
//#endregion
//#region src/scripts/clipspace.ts
/**
* Content clipboard shared by the mask editor and clipspace extensions.
* `ComfyApp` exposes it as static members for custom-node compatibility.
*/
var clipspace = {
	current: null,
	invalidateHandler: null,
	returnNode: null,
	maskEditorIsOpened: null
};
function copyToClipspace(node) {
	let widgets = null;
	if (node.widgets) widgets = node.widgets.map(({ type, name, value }) => ({
		type,
		name,
		value
	}));
	let imgs = void 0;
	let orig_imgs = void 0;
	if (node.imgs != void 0) {
		imgs = [];
		orig_imgs = [];
		for (let i = 0; i < node.imgs.length; i++) {
			imgs[i] = new Image();
			imgs[i].src = node.imgs[i].src;
			orig_imgs[i] = imgs[i];
		}
	}
	let selectedIndex = 0;
	if (node.imageIndex) selectedIndex = node.imageIndex;
	const paintedIndex = imgs ? imgs.length + 1 : 1;
	const combinedIndex = imgs ? imgs.length + 2 : 2;
	const images = useNodeOutputStore().getNodeOutputs(node)?.images;
	clipspace.current = {
		widgets,
		imgs,
		original_imgs: orig_imgs,
		images,
		selectedIndex,
		img_paste_mode: "selected",
		paintedIndex,
		combinedIndex
	};
	clipspace.returnNode = null;
	if (clipspace.invalidateHandler) clipspace.invalidateHandler();
}
function pasteFromClipspace(node) {
	if (clipspace.current) {
		let combinedImgSrc;
		if (clipspace.current.combinedIndex !== void 0 && clipspace.current.imgs && clipspace.current.combinedIndex < clipspace.current.imgs.length) combinedImgSrc = clipspace.current.imgs[clipspace.current.combinedIndex].src;
		const selectedImage = clipspace.current.images?.[clipspace.current.selectedIndex];
		if (clipspace.current.images) {
			if (clipspace.current.img_paste_mode !== "selected") useNodeOutputStore().setNodeOutputImages(node, clipspace.current.images);
			else if (selectedImage) useNodeOutputStore().setNodeOutputImages(node, [selectedImage]);
		}
		if (clipspace.current.imgs && node.imgs) {
			if (clipspace.current["img_paste_mode"] == "selected") {
				const selectedPreview = clipspace.current.imgs.at(clipspace.current.selectedIndex);
				if (clipspace.current.selectedIndex >= 0 && selectedPreview) {
					const img = new Image();
					img.src = selectedPreview.src;
					node.imgs = [img];
					node.imageIndex = 0;
				}
			} else {
				const imgs = [];
				for (let i = 0; i < clipspace.current.imgs.length; i++) {
					imgs[i] = new Image();
					imgs[i].src = clipspace.current.imgs[i].src;
					node.imgs = imgs;
				}
			}
		}
		if (clipspace.current.imgs?.[clipspace.current.paintedIndex] && node.imgs) {
			const paintedImg = new Image();
			paintedImg.src = clipspace.current.imgs[clipspace.current.paintedIndex].src;
			node.imgs.push(paintedImg);
		}
		if (node.imgs && combinedImgSrc) {
			const combinedImg = new Image();
			combinedImg.src = combinedImgSrc;
			node.imgs = [combinedImg];
		}
		if (node.widgets) {
			if (selectedImage) {
				const index = node.widgets.findIndex((obj) => obj.name === "image");
				if (index >= 0) {
					if (node.widgets[index].type != "image" && typeof node.widgets[index].value == "string" && selectedImage.filename) node.widgets[index].value = (selectedImage.subfolder ? selectedImage.subfolder + "/" : "") + selectedImage.filename + (selectedImage.type ? ` [${selectedImage.type}]` : "");
					else node.widgets[index].value = selectedImage;
				}
			}
			if (clipspace.current.widgets) clipspace.current.widgets.forEach(({ type, name, value }) => {
				const prop = node.widgets?.find((obj) => obj.type === type && obj.name === name);
				if (prop && prop.type != "button") {
					const valueObj = value;
					if (prop.type != "image" && typeof prop.value == "string" && valueObj?.filename) {
						const resultItem = value;
						prop.value = (resultItem.subfolder ? resultItem.subfolder + "/" : "") + resultItem.filename + (resultItem.type ? ` [${resultItem.type}]` : "");
					} else {
						prop.value = value;
						prop.callback?.(value);
					}
				}
			});
		}
		useApp().canvas.setDirty(true);
	}
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.clipspace = window.comfyAPI.clipspace || {};
window.comfyAPI.clipspace.clipspace = clipspace;
window.comfyAPI.clipspace.copyToClipspace = copyToClipspace;
window.comfyAPI.clipspace.pasteFromClipspace = pasteFromClipspace;
//#endregion
//#region src/scripts/changeTracker.ts
function clone(obj) {
	return JSON.parse(JSON.stringify(obj));
}
function withoutExecutionOrder(nodes) {
	return nodes.map((node) => toolkit.omit(node, ["order"]));
}
function withNormalizedNodeSizes(state) {
	const comparable = clone(state);
	const subgraphs = collectSubgraphDefinitions(parseFlattenableSubgraphDefinitions(comparable.definitions?.subgraphs ?? []));
	const nodes = [...comparable.nodes, ...subgraphs.flatMap((subgraph) => subgraph.nodes)];
	for (const node of nodes) if ("size" in node) node.size = [0, 0];
	return comparable;
}
function matchesRestoredTarget(actual, target, previous) {
	if (ChangeTracker.graphEqual(actual, target)) return true;
	const comparableTarget = withNormalizedNodeSizes(target);
	return ChangeTracker.graphEqual(withNormalizedNodeSizes(actual), comparableTarget) && !ChangeTracker.graphEqual(comparableTarget, withNormalizedNodeSizes(previous));
}
function differsOnlyInNodeHistoryWidgets(previous, current, widgets) {
	const { rootGraph } = useApp();
	return widgets.size > 0 && nodeHistoryValuesChanged(previous, current, widgets, rootGraph.id) && ChangeTracker.graphEqual(withNodeHistoryValuesFrom(previous, current, widgets, rootGraph.id), current);
}
function keepingLiveNodeHistoryValues(target) {
	const { rootGraph } = useApp();
	const widgets = collectNodeHistoryWidgets(rootGraph);
	if (!widgets.size) return target;
	return withNodeHistoryValuesFrom(target, clone(rootGraph.serialize()), widgets, rootGraph.id);
}
function forgetRemovedNodeHistories(widgets) {
	useWidgetHistoryStore().retainLive(useApp().rootGraph.id, widgets);
}
function isActiveTracker(tracker) {
	return useWorkflowStore().activeWorkflow?.changeTracker === tracker;
}
function historyShortcut(e) {
	if (!(e.ctrlKey || e.metaKey) || e.altKey) return;
	const key = e.key.toUpperCase();
	if (key === "Y" && !e.shiftKey) return "redo";
	if (key === "Z") return e.shiftKey ? "redo" : "undo";
}
function isAutoQueueOnChange() {
	const { ui } = useApp();
	return useQueueSettingsStore().mode === "change" || ui.autoQueueEnabled && ui.autoQueueMode === "change";
}
var nonExecutionGraphProperties = /* @__PURE__ */ new Set([
	"id",
	"revision",
	"last_node_id",
	"last_link_id",
	"state",
	"groups",
	"config",
	"extra",
	"version",
	"models",
	"reroutes",
	"floatingLinks",
	"subgraphs",
	"definitions",
	"name",
	"description",
	"category",
	"essentials_category"
]);
var nonExecutionNodeProperties = /* @__PURE__ */ new Set([
	"pos",
	"size",
	"flags",
	"order",
	"color",
	"bgcolor",
	"boxcolor",
	"shape",
	"showAdvanced",
	"title"
]);
var nonExecutionSlotProperties = /* @__PURE__ */ new Set([
	"localized_name",
	"label",
	"shape",
	"color_off",
	"color_on",
	"pos",
	"link",
	"links",
	"linkIds",
	"slot_index"
]);
var nonExecutionBoundaryNodeProperties = /* @__PURE__ */ new Set(["bounding", "pinned"]);
var nonExecutableNodeTypes = /* @__PURE__ */ new Set(["Note", "MarkdownNote"]);
function isRecord(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function asRecord(value) {
	return isRecord(value) ? value : null;
}
function omitProperties(record, properties) {
	return Object.fromEntries(Object.entries(record).filter(([key]) => !properties.has(key)));
}
function getExecutionSlotState(value) {
	const slot = asRecord(value);
	return slot ? omitProperties(slot, nonExecutionSlotProperties) : value;
}
function getExecutionNodeState(value) {
	const node = asRecord(value);
	if (!node) return value;
	const executionNode = omitProperties(node, nonExecutionNodeProperties);
	if ("id" in node) executionNode.id = normalizeNodeId(node.id);
	if (Array.isArray(node.inputs)) executionNode.inputs = node.inputs.map(getExecutionSlotState);
	if (Array.isArray(node.outputs)) executionNode.outputs = node.outputs.map(getExecutionSlotState);
	return executionNode;
}
function getExecutionBoundaryNodeState(value) {
	const node = asRecord(value);
	if (!node) return value;
	const executionNode = omitProperties(node, nonExecutionBoundaryNodeProperties);
	if ("id" in node) executionNode.id = normalizeNodeId(node.id);
	return executionNode;
}
function getExecutionLinkState(value) {
	if (Array.isArray(value)) return [
		normalizeNodeId(value[1]),
		normalizeSlotIndex(value[2]),
		normalizeNodeId(value[3]),
		normalizeSlotIndex(value[4])
	];
	const link = asRecord(value);
	if (!link) return value;
	return [
		normalizeNodeId(link.origin_id),
		normalizeSlotIndex(link.origin_slot),
		normalizeNodeId(link.target_id),
		normalizeSlotIndex(link.target_slot)
	];
}
function normalizeNodeId(value) {
	return typeof value === "number" || typeof value === "string" ? serializeNodeId(value) : value;
}
function normalizeSlotIndex(value) {
	if (typeof value !== "string") return value;
	const index = parseInt(value);
	return Number.isNaN(index) ? value : index;
}
function isExecutableNodeState(value) {
	const node = asRecord(value);
	return !node || typeof node.type !== "string" || !nonExecutableNodeTypes.has(node.type);
}
function getExecutionDefinitionsState(value) {
	const definitions = asRecord(value);
	if (!definitions || !Array.isArray(definitions.subgraphs)) return value;
	return {
		...definitions,
		subgraphs: toolkit.sortBy(definitions.subgraphs, (subgraph) => asRecord(subgraph)?.id).map(getExecutionGraphState)
	};
}
function getExecutionGraphState(value) {
	const graph = asRecord(value);
	if (!graph) return value;
	const executionGraph = omitProperties(graph, nonExecutionGraphProperties);
	if (Array.isArray(graph.nodes)) executionGraph.nodes = toolkit.sortBy(graph.nodes.filter(isExecutableNodeState).map(getExecutionNodeState), (node) => asRecord(node)?.id);
	if (Array.isArray(graph.links)) executionGraph.links = toolkit.sortBy(graph.links.map(getExecutionLinkState), (link) => JSON.stringify(link));
	else if (!("links" in graph)) executionGraph.links = [];
	if (Array.isArray(graph.inputs)) executionGraph.inputs = graph.inputs.map(getExecutionSlotState);
	if (Array.isArray(graph.outputs)) executionGraph.outputs = graph.outputs.map(getExecutionSlotState);
	if ("inputNode" in graph) executionGraph.inputNode = getExecutionBoundaryNodeState(graph.inputNode);
	if ("outputNode" in graph) executionGraph.outputNode = getExecutionBoundaryNodeState(graph.outputNode);
	if ("definitions" in graph) executionGraph.definitions = getExecutionDefinitionsState(graph.definitions);
	return executionGraph;
}
var reportedInactiveCalls = /* @__PURE__ */ new Set();
function reportInactiveTrackerCall(method, workflowPath) {
	const key = `${method}:${workflowPath}`;
	if (reportedInactiveCalls.has(key)) return;
	reportedInactiveCalls.add(key);
	assert(false, `ChangeTracker.${method}() called on inactive tracker`);
}
var ChangeTracker = class ChangeTracker {
	workflow;
	initialState;
	static MAX_HISTORY = 50;
	/**
	* Guard flag to prevent captureCanvasState from running during loadGraphData.
	* Between rootGraph.configure() and afterLoadNewGraph(), the rootGraph
	* contains the NEW workflow's data while activeWorkflow still points to
	* the OLD workflow. Any captureCanvasState call in that window would
	* serialize the wrong graph into the old workflow's activeState, corrupting it.
	*/
	static isLoadingGraph = false;
	/**
	* The active state of the workflow.
	*/
	activeState;
	undoQueue = [];
	redoQueue = [];
	changeCount = 0;
	/**
	* Whether the redo/undo restoring is in progress.
	*/
	_restoringState = false;
	restoreChain;
	ds;
	nodeOutputs;
	subgraphState;
	constructor(workflow, initialState) {
		this.workflow = workflow;
		this.initialState = initialState;
		this.activeState = initialState;
	}
	/**
	* Save the current state as the initial state.
	*/
	reset(state) {
		if (state) this.activeState = clone(state);
		if (this._restoringState) return;
		this.initialState = clone(this.activeState);
	}
	store() {
		const { ds } = useApp().canvas;
		this.ds = {
			scale: ds.scale,
			offset: [ds.offset[0], ds.offset[1]]
		};
		this.nodeOutputs = useNodeOutputStore().snapshotOutputs();
		const navigation = useSubgraphNavigationStore().exportState();
		this.subgraphState = { navigation };
	}
	/**
	* Freeze this tracker's state before the workflow goes inactive.
	* Always calls store() to preserve viewport/outputs. Calls
	* captureCanvasState() only when not in undo/redo (to avoid
	* corrupting undo history with intermediate graph state).
	*
	* PRECONDITION: must be called while this workflow is still the active one
	* (before the activeWorkflow pointer is moved). If called after the pointer
	* has already moved, this is a no-op to avoid freezing wrong viewport data.
	*
	* @internal Not part of the public extension API.
	*/
	deactivate() {
		if (!isActiveTracker(this)) {
			reportInactiveTrackerCall("deactivate", this.workflow.path);
			return;
		}
		if (!this._restoringState) this.captureCanvasState();
		this.store();
	}
	/**
	* Ensure activeState is up-to-date for persistence.
	* Active workflow: flushes canvas → activeState.
	* Inactive workflow: no-op (activeState was frozen by deactivate()).
	*
	* @internal Not part of the public extension API.
	*/
	prepareForSave() {
		if (isActiveTracker(this)) this.captureCanvasState();
	}
	restore() {
		const app = useApp();
		if (this.ds) {
			app.canvas.ds.scale = this.ds.scale;
			app.canvas.ds.offset = this.ds.offset;
		}
		if (this.nodeOutputs) useNodeOutputStore().restoreOutputs(this.nodeOutputs);
		if (this.subgraphState) {
			const { navigation } = this.subgraphState;
			const firstInvalidIndex = navigation.findIndex((id) => !app.rootGraph.subgraphs.has(id));
			if (firstInvalidIndex !== -1) navigation.splice(firstInvalidIndex);
			useSubgraphNavigationStore().restoreState(navigation);
			const activeId = navigation.at(-1);
			if (activeId) {
				const subgraph = app.rootGraph.subgraphs.get(activeId);
				if (subgraph) app.canvas.setGraph(subgraph);
			} else app.canvas.setGraph(app.rootGraph);
		}
	}
	updateModified(previousState) {
		const workflow = useWorkflowStore().getWorkflowByPath(this.workflow.path);
		if (workflow) workflow.isModified = !ChangeTracker.graphEqual(this.initialState, this.activeState);
		const autoQueueGraphChanged = !!previousState && isAutoQueueOnChange() && !toolkit.isEqual(getExecutionGraphState(previousState), getExecutionGraphState(this.activeState));
		api.dispatchCustomEvent("graphChanged", this.activeState);
		if (autoQueueGraphChanged) api.dispatchCustomEvent("autoQueueGraphChanged");
	}
	/**
	* Snapshot the current canvas state into activeState and push undo.
	* INVARIANT: only the active workflow's tracker may read from the canvas.
	* Calling this on an inactive tracker would capture the wrong graph.
	*/
	captureCanvasState() {
		const isUndoRedoing = this._restoringState;
		const isInsideChangeTransaction = this.changeCount > 0;
		if (!useApp().isGraphReady || isInsideChangeTransaction || isUndoRedoing || ChangeTracker.isLoadingGraph) return;
		if (!isActiveTracker(this)) {
			reportInactiveTrackerCall("captureCanvasState", this.workflow.path);
			return;
		}
		const currentState = clone(useApp().rootGraph.serialize());
		if (!ChangeTracker.graphEqual(this.activeState, currentState)) {
			const previousState = this.activeState;
			const nodeHistoryWidgets = collectNodeHistoryWidgets(useApp().rootGraph);
			if (!differsOnlyInNodeHistoryWidgets(previousState, currentState, nodeHistoryWidgets)) {
				this.undoQueue.push(previousState);
				if (this.undoQueue.length > ChangeTracker.MAX_HISTORY) this.undoQueue.shift();
				this.redoQueue.length = 0;
			}
			this.activeState = currentState;
			this.updateModified(previousState);
			forgetRemovedNodeHistories(nodeHistoryWidgets);
			this.squashState();
		}
	}
	squashState = useDebounceFn(() => {
		if (this !== useWorkflowStore().activeWorkflow?.changeTracker || ChangeTracker.isLoadingGraph) return;
		const currentState = clone(useApp().rootGraph.serialize());
		if (ChangeTracker.graphEqual(this.activeState, currentState)) return;
		const previousState = this.activeState;
		this.activeState = currentState;
		this.updateModified(previousState);
	}, 50);
	/** @deprecated Use {@link captureCanvasState} instead. */
	checkState() {
		if (!ChangeTracker._checkStateWarned) {
			ChangeTracker._checkStateWarned = true;
			console.warn("checkState() is deprecated — use captureCanvasState() instead.");
		}
		this.captureCanvasState();
	}
	static _checkStateWarned = false;
	static resetCheckStateWarningForTest() {
		ChangeTracker._checkStateWarned = false;
	}
	async updateState(source, target) {
		const restore = async () => {
			if (this._restoringState || source.length === 0) return;
			const prevState = source.pop();
			if (prevState) {
				const previousState = this.activeState;
				const targetState = keepingLiveNodeHistoryValues(prevState);
				const restoresSavedState = ChangeTracker.graphEqual(targetState, this.initialState);
				let restored = false;
				this._restoringState = true;
				try {
					const result = await useApp().loadGraphData(targetState, false, false, this.workflow, {
						checkForRerouteMigration: false,
						silentAssetErrors: true
					});
					restored = result !== false && result !== void 0;
				} finally {
					this._restoringState = false;
					restored ||= !ChangeTracker.graphEqual(this.activeState, previousState) && matchesRestoredTarget(this.activeState, targetState, previousState);
					if (restored) {
						target.push(previousState);
						if (restoresSavedState) this.initialState = clone(this.activeState);
					} else source.push(prevState);
					if (restored) {
						this.updateModified(previousState);
						forgetRemovedNodeHistories(collectNodeHistoryWidgets(useApp().rootGraph));
					}
				}
			}
		};
		this.restoreChain = (this.restoreChain ?? Promise.resolve()).then(restore, restore);
		return this.restoreChain;
	}
	async undo() {
		await this.updateState(this.undoQueue, this.redoQueue);
	}
	async redo() {
		await this.updateState(this.redoQueue, this.undoQueue);
	}
	async undoRedo(e, selectOnly = isSelectOnly(useApp().canvas)) {
		const shortcut = historyShortcut(e);
		if (!shortcut) return;
		if (!selectOnly) await (shortcut === "redo" ? this.redo() : this.undo());
		return true;
	}
	beforeChange() {
		this.changeCount++;
	}
	afterChange() {
		if (!--this.changeCount) this.captureCanvasState();
	}
	static init() {
		const getCurrentChangeTracker = () => useWorkflowStore().activeWorkflow?.changeTracker;
		const captureState = () => getCurrentChangeTracker()?.captureCanvasState();
		const dialogStore = useDialogStore();
		let keyIgnored = false;
		window.addEventListener("keydown", (e) => {
			if (e.repeat) return;
			if (clipspace.maskEditorIsOpened?.()) return;
			const activeEl = document.activeElement;
			if (!isAutoQueueOnChange() && (activeEl?.tagName === "INPUT" || activeEl?.tagName === "TEXTAREA" || activeEl instanceof HTMLElement && activeEl.isContentEditable)) return;
			if (isModalOpen(dialogStore.dialogStack.length)) return;
			if (useDialogStore().isDialogOpen("global-layer-editor")) return;
			keyIgnored = e.key === "Control" || e.key === "Shift" || e.key === "Alt" || e.key === "Meta";
			if (keyIgnored) return;
			const selectOnlyAtKeydown = isSelectOnly(useApp().canvas);
			requestAnimationFrame(async () => {
				let bindInputEl = null;
				if (!isAutoQueueOnChange()) bindInputEl = activeEl;
				const changeTracker = getCurrentChangeTracker();
				if (!changeTracker) return;
				if (await changeTracker.undoRedo(e, selectOnlyAtKeydown)) return;
				if (ChangeTracker.bindInput(bindInputEl)) return;
				changeTracker.captureCanvasState();
			});
		}, true);
		window.addEventListener("keyup", () => {
			if (keyIgnored) {
				keyIgnored = false;
				captureState();
			}
		});
		window.addEventListener("mouseup", () => {
			captureState();
		});
		api.addEventListener("promptQueued", () => {
			captureState();
		});
		api.addEventListener("graphCleared", () => {
			captureState();
		});
		const processMouseUp = LGraphCanvas.prototype.processMouseUp;
		LGraphCanvas.prototype.processMouseUp = function(e) {
			const v = processMouseUp.apply(this, [e]);
			captureState();
			return v;
		};
		const prompt = LGraphCanvas.prototype.prompt;
		LGraphCanvas.prototype.prompt = function(title, value, callback, event) {
			const extendedCallback = (v) => {
				callback(v);
				captureState();
			};
			return prompt.apply(this, [
				title,
				value,
				extendedCallback,
				event
			]);
		};
		const close = LiteGraph.ContextMenu.prototype.close;
		LiteGraph.ContextMenu.prototype.close = function(e) {
			const v = close.apply(this, [e]);
			captureState();
			return v;
		};
		document.addEventListener("litegraph:canvas", (e) => {
			const detail = e.detail;
			if (detail.subType === "before-change") getCurrentChangeTracker()?.beforeChange();
			else if (detail.subType === "after-change") getCurrentChangeTracker()?.afterChange();
		});
		api.addEventListener("executed", (e) => {
			const detail = e.detail;
			const changeTracker = (useExecutionStore().queuedJobs[detail.prompt_id]?.workflow)?.changeTracker;
			if (!changeTracker) return;
			changeTracker.nodeOutputs ??= {};
			const nodeOutputs = changeTracker.nodeOutputs;
			const output = nodeOutputs[detail.node];
			if (detail.merge && output) for (const k in detail.output) {
				const v = output[k];
				if (v instanceof Array) output[k] = v.concat(detail.output[k]);
				else output[k] = detail.output[k];
			}
			else nodeOutputs[detail.node] = detail.output;
		});
	}
	static bindInput(activeEl) {
		if (!activeEl || activeEl.tagName === "CANVAS" || activeEl.tagName === "BODY") return false;
		for (const evt of [
			"change",
			"input",
			"blur"
		]) {
			const htmlElement = activeEl;
			if (`on${evt}` in htmlElement) {
				const listener = () => {
					useWorkflowStore().activeWorkflow?.changeTracker.captureCanvasState();
					htmlElement.removeEventListener(evt, listener);
				};
				htmlElement.addEventListener(evt, listener);
				return true;
			}
		}
		return false;
	}
	static graphEqual(a, b) {
		if (a === b) return true;
		if (!toolkit.isEqualWith(withoutExecutionOrder(a.nodes), withoutExecutionOrder(b.nodes), (arrA, arrB) => {
			if (Array.isArray(arrA) && Array.isArray(arrB)) return toolkit.isEqual(new Set(arrA), new Set(arrB));
		})) return false;
		if (!toolkit.isEqual(toolkit.omit(a.extra ?? {}, ["ds"]), toolkit.omit(b.extra ?? {}, ["ds"]))) return false;
		for (const key of [
			"links",
			"floatingLinks",
			"reroutes",
			"groups",
			"definitions",
			"subgraphs"
		]) if (!toolkit.isEqual(a[key], b[key])) return false;
		return true;
	}
};
provideChangeTracker(ChangeTracker);
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.changeTracker = window.comfyAPI.changeTracker || {};
window.comfyAPI.changeTracker.ChangeTracker = ChangeTracker;
//#endregion
//#region src/stores/appModeStore.ts
function findWidgetByEntityId(rootGraph, widgetId) {
	for (const node of rootGraph.nodes) {
		const widget = node.widgets?.find((w) => getWidgetIdForNode(node, w) === widgetId);
		if (widget) return widget;
	}
}
function nodeTypeValidForApp(type) {
	return !["Note", "MarkdownNote"].includes(type);
}
var useAppModeStore = defineStore("appMode", () => {
	const { getCanvas } = useCanvasStore();
	const settingStore = useSettingStore();
	const workflowStore = useWorkflowStore();
	const { mode, setMode, isAppMode, isBuilderMode, isSelectMode } = useAppMode();
	const showVueNodeSwitchPopup = ref(false);
	const viewMode = computed(() => isAppMode.value ? "app" : "graph");
	/**
	* Frame-lagged mirror of {@link viewMode} driving the view-mode toggle's
	* segment morph. The two-frame lag lets a toggle that mounts mid-switch
	* render the previous mode first, then animate in. Kept in the store so it
	* outlives the graph-mode toggle unmounting as the app toggle replaces it.
	*/
	const displayViewMode = ref(viewMode.value);
	let outerFrame;
	let innerFrame;
	watch(viewMode, (next) => {
		if (outerFrame !== void 0) cancelAnimationFrame(outerFrame);
		if (innerFrame !== void 0) cancelAnimationFrame(innerFrame);
		outerFrame = requestAnimationFrame(() => {
			innerFrame = requestAnimationFrame(() => {
				displayViewMode.value = next;
			});
		});
	});
	const selectedInputs = ref([]);
	const selectedOutputs = ref([]);
	const hasOutputs = computed(() => !!selectedOutputs.value.length);
	const hasNodes = computed(() => {
		workflowStore.activeWorkflow;
		mode.value;
		const app = useApp();
		return app.isGraphReady && app.rootGraph.nodes.length > 0;
	});
	function pruneLinearData(data) {
		const rawInputs = data?.inputs ?? [];
		const rawOutputs = data?.outputs ?? [];
		const app = useApp();
		const rootGraph = app.isGraphReady ? app.rootGraph : void 0;
		if (!rootGraph) return {
			inputs: rawInputs,
			outputs: rawOutputs.flatMap((nodeId) => {
				const parsedNodeId = parseNodeId(nodeId);
				return parsedNodeId ? [parsedNodeId] : [];
			})
		};
		return {
			inputs: rawInputs.map((input) => upgradeAndValidateInput(input, rootGraph)).filter((entry) => entry !== null),
			outputs: rawOutputs.flatMap((nodeId) => {
				const parsedNodeId = parseNodeId(nodeId);
				if (!parsedNodeId) return [];
				return ChangeTracker.isLoadingGraph || resolveNode(parsedNodeId) ? [parsedNodeId] : [];
			})
		};
	}
	function buildEntry(widgetId, name, config) {
		return config === void 0 ? [widgetId, name] : [
			widgetId,
			name,
			config
		];
	}
	function upgradeAndValidateInput(input, rootGraph) {
		const [storedId, widgetName, config] = input;
		if (typeof storedId === "string" && isWidgetId(storedId)) {
			if (findWidgetByEntityId(rootGraph, storedId)) return buildEntry(storedId, widgetName, config);
			const { nodeId } = parseWidgetId(storedId);
			if (rootGraph.getNodeById(nodeId)) return buildEntry(storedId, widgetName, config);
			return null;
		}
		if (typeof storedId === "string" && storedId.includes(":")) {
			const [, widget] = resolveNodeWidget(storedId, widgetName);
			if (!widget?.widgetId) return null;
			return buildEntry(widget.widgetId, widgetName, config);
		}
		const directNodeId = parseNodeId(storedId);
		const directNode = directNodeId ? rootGraph.getNodeById(directNodeId) : null;
		const directWidget = directNode?.widgets?.find((w) => w.name === widgetName);
		if (directNode && directWidget) {
			const derivedId = getWidgetIdForNode(directNode, directWidget);
			if (derivedId) return buildEntry(derivedId, widgetName, config);
		}
		const matches = rootGraph.nodes.flatMap((node) => {
			if (!(node instanceof SubgraphNode)) return [];
			return node.inputs.flatMap((inputSlot) => {
				if (!inputSlot.widgetId) return [];
				const target = resolveSubgraphInputTarget(node, inputSlot.name);
				if (target?.nodeId !== String(storedId) || target.widgetName !== widgetName) return [];
				return [buildEntry(inputSlot.widgetId, inputSlot.name, config)];
			});
		});
		if (matches.length === 1) return matches[0];
		if (matches.length > 1) {
			console.warn("[appModeStore] dropping ambiguous legacy selectedInput tuple", {
				storedId,
				widgetName
			});
			return null;
		}
		console.warn("[appModeStore] dropping legacy selectedInput tuple — no canonical identity available", {
			storedId,
			widgetName
		});
		return null;
	}
	function warnOnUninterpretableAppConfig(data, resolvedInputs, resolvedOutputs) {
		if (ChangeTracker.isLoadingGraph) return;
		const app = useApp();
		if (!app.isGraphReady || !app.rootGraph.nodes.length) return;
		if (!!!(data?.inputs?.length || data?.outputs?.length) || resolvedInputs.length || resolvedOutputs.length) return;
		console.warn("[appModeStore] app config could not be interpreted; no inputs or outputs resolved from linearData", {
			inputs: data.inputs,
			outputs: data.outputs
		});
	}
	function loadSelections(data) {
		const { inputs, outputs } = pruneLinearData(data);
		selectedInputs.value = inputs;
		selectedOutputs.value = outputs;
		warnOnUninterpretableAppConfig(data, inputs, outputs);
	}
	function resetSelectedToWorkflow() {
		const { activeWorkflow } = workflowStore;
		if (!activeWorkflow) return;
		loadSelections(activeWorkflow.changeTracker.activeState.extra?.linearData ?? activeWorkflow.initialState.extra?.linearData);
	}
	useEventListener(() => {
		const app = useApp();
		return app.isGraphReady ? app.rootGraph.events : void 0;
	}, "configured", resetSelectedToWorkflow);
	watch(() => isBuilderMode.value ? {
		inputs: selectedInputs.value,
		outputs: selectedOutputs.value
	} : null, (data) => {
		if (!data || ChangeTracker.isLoadingGraph) return;
		if (!useApp().isGraphReady) return;
		const extra = useApp().rootGraph.extra;
		extra.linearData = {
			inputs: data.inputs.map(([id, name, config]) => config ? [
				id,
				name,
				JSON.parse(JSON.stringify(config))
			] : [id, name]),
			outputs: [...data.outputs]
		};
		workflowStore.activeWorkflow?.changeTracker.captureCanvasState();
	}, { deep: true });
	let unwatchReadOnly;
	function enforceReadOnly(inSelect) {
		const canvas = getCanvas();
		canvas.read_only = inSelect;
		unwatchReadOnly?.();
		if (inSelect) unwatchReadOnly = watch(() => canvas.read_only, () => canvas.read_only = true);
	}
	function autoEnableVueNodes(inSelect) {
		if (!inSelect) return;
		if (!settingStore.get("Comfy.VueNodes.Enabled")) {
			settingStore.set("Comfy.VueNodes.Enabled", true);
			if (!settingStore.get("Comfy.AppBuilder.VueNodeSwitchDismissed")) showVueNodeSwitchPopup.value = true;
		}
	}
	watch(isSelectMode, (inSelect) => {
		enforceReadOnly(inSelect);
		autoEnableVueNodes(inSelect);
	});
	function enterBuilder() {
		resetSelectedToWorkflow();
		useSidebarTabStore().activeSidebarTabId = null;
		setMode(mode.value === "app" && hasOutputs.value ? "builder:arrange" : "builder:inputs");
	}
	function exitBuilder() {
		resetSelectedToWorkflow();
		setMode("graph");
	}
	function removeSelectedInput(widget) {
		const targetEntityId = widget.widgetId;
		if (!targetEntityId) return;
		const index = selectedInputs.value.findIndex(([id]) => id === targetEntityId);
		if (index !== -1) selectedInputs.value.splice(index, 1);
	}
	function updateInputConfig(widget, config) {
		const targetEntityId = widget.widgetId;
		if (!targetEntityId) return;
		const index = selectedInputs.value.findIndex(([id]) => id === targetEntityId);
		if (index === -1) return;
		const [id, type, options] = selectedInputs.value[index];
		selectedInputs.value.splice(index, 1, [
			id,
			type,
			{
				...options,
				...config
			}
		]);
	}
	return {
		enterBuilder,
		exitBuilder,
		hasNodes,
		hasOutputs,
		loadSelections,
		pruneLinearData,
		removeSelectedInput,
		resetSelectedToWorkflow,
		selectedInputs,
		selectedOutputs,
		updateInputConfig,
		showVueNodeSwitchPopup,
		viewMode,
		displayViewMode
	};
});
//#endregion
export { trim$1 as A, partition as C, flatMap as D, intersection as E, take$1 as F, maxBy$1 as I, intersection$1 as L, capitalize$1 as M, omit$1 as N, find as O, uniqWith$1 as P, isNil as S, keyBy as T, clone$1 as _, copyToClipspace as a, uniqBy as b, useSubgraphNavigationStore as c, useCanvasScheduler as d, toolkit as f, mapKeys as g, omit as h, clipspace as i, snakeCase$1 as j, upperFirst$1 as k, provideLitegraphService as l, pick as m, useAppModeStore as n, pasteFromClipspace as o, pickBy as p, ChangeTracker as r, provideWorkflowService as s, nodeTypeValidForApp as t, useLitegraphServiceAccess as u, keys as v, orderBy as w, some as x, zip as y };
