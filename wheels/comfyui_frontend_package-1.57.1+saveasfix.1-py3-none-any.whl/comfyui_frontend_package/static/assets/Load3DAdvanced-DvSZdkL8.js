import "./rolldown-runtime-xtsTai4I.js";
import { G as defineComponent, I as createBlock, ct as openBlock } from "./vendor-vue-core-CuN1excl.js";
import { t as Load3D_default } from "./Load3D-CfQgntdn.js";
//#endregion
//#region src/extensions/core/load3d/components/Load3DAdvanced.vue
var Load3DAdvanced_default = /* @__PURE__ */ defineComponent({
	__name: "Load3DAdvanced",
	props: {
		widget: {},
		nodeId: {}
	},
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createBlock(Load3D_default, {
				widget: __props.widget,
				"node-id": __props.nodeId,
				"can-use-recording": false,
				"can-use-hdri": false,
				"can-use-background-image": false
			}, null, 8, ["widget", "node-id"]);
		};
	}
});
//#endregion
export { Load3DAdvanced_default as default };
