import "./rolldown-runtime-xtsTai4I.js";
import { F as createBaseVNode, G as defineComponent, H as createTextVNode, I as createBlock, L as createCommentVNode, R as createElementBlock, Yt as toDisplayString, ct as openBlock, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { t as Badge_default } from "./Badge-BUm0jxSy.js";
//#region src/platform/billing/components/PricingTierHeading.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "flex items-center justify-between gap-2 font-bold" };
var _hoisted_2 = { class: "text-base/normal" };
//#endregion
//#region src/platform/billing/components/PricingTierHeading.vue
var PricingTierHeading_default = /* @__PURE__ */ defineComponent({
	__name: "PricingTierHeading",
	props: {
		name: {},
		isPopular: {
			type: Boolean,
			default: false
		}
	},
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1, [createBaseVNode("span", _hoisted_2, toDisplayString(__props.name), 1), __props.isPopular ? (openBlock(), createBlock(Badge_default, {
				key: 0,
				variant: "pill",
				severity: "contrast",
				class: "font-bold tracking-tight uppercase"
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("subscription.mostPopular")), 1)]),
				_: 1
			})) : createCommentVNode("", true)]);
		};
	}
});
//#endregion
export { PricingTierHeading_default as t };
