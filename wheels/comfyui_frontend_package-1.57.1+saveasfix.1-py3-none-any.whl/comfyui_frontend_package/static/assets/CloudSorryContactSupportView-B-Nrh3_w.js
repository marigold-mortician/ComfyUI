import "./rolldown-runtime-xtsTai4I.js";
import { F as createBaseVNode, G as defineComponent, R as createElementBlock, Wt as unref, Yt as toDisplayString, ct as openBlock } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as _plugin_vue_export_helper_default } from "./_plugin-vue_export-helper-DEKQMRQ4.js";
//#region src/platform/cloud/onboarding/CloudSorryContactSupportView.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "cloud-sorry-contact-support" };
//#endregion
//#region src/platform/cloud/onboarding/CloudSorryContactSupportView.vue
var CloudSorryContactSupportView_default = /*#__PURE__*/ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "CloudSorryContactSupportView",
	setup(__props) {
		const { t } = useI18n();
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1, [createBaseVNode("h1", null, toDisplayString(unref(t)("cloudSorryContactSupport_title")), 1)]);
		};
	}
}), [["__scopeId", "data-v-c3fa108d"]]);
//#endregion
export { CloudSorryContactSupportView_default as default };
