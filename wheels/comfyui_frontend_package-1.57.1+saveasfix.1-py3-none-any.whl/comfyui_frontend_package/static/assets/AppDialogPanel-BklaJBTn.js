import "./rolldown-runtime-xtsTai4I.js";
import { B as createSlots, F as createBaseVNode, G as defineComponent, I as createBlock, Kt as normalizeClass, L as createCommentVNode, R as createElementBlock, U as createVNode, Wt as unref, ct as openBlock, dt as renderSlot, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { t as DialogTitle_default } from "./DialogTitle-CWOHHLwH.js";
import { t as Card_default } from "./Card-lRVBegiG.js";
//#endregion
//#region src/components/ui/card/CardFooter.vue
var CardFooter_default = /* @__PURE__ */ defineComponent({
	__name: "CardFooter",
	props: { class: { type: [
		Boolean,
		null,
		String,
		Object,
		Array
	] } },
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", { class: normalizeClass(unref(cn)("flex items-center justify-end gap-4 p-4", __props.class)) }, [renderSlot(_ctx.$slots, "default")], 2);
		};
	}
});
//#endregion
//#region src/components/ui/card/CardHeader.vue
var CardHeader_default = /* @__PURE__ */ defineComponent({
	__name: "CardHeader",
	props: { class: { type: [
		Boolean,
		null,
		String,
		Object,
		Array
	] } },
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", { class: normalizeClass(unref(cn)("flex h-12 shrink-0 items-center justify-between gap-2 border-b px-4", __props.class)) }, [renderSlot(_ctx.$slots, "default")], 2);
		};
	}
});
//#endregion
//#region src/components/ui/dialog/DialogPanel.vue
var DialogPanel_default = /* @__PURE__ */ defineComponent({
	__name: "DialogPanel",
	props: {
		closeLabel: {},
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] },
		onClose: { type: Function }
	},
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createBlock(Card_default, { class: normalizeClass(unref(cn)("flex flex-col shadow-lg", __props.class)) }, {
				default: withCtx(() => [
					createVNode(CardHeader_default, null, {
						default: withCtx(() => [createVNode(DialogTitle_default, { class: "m-0 flex items-center gap-2 text-sm font-normal" }, {
							default: withCtx(() => [renderSlot(_ctx.$slots, "title")]),
							_: 3
						}), __props.onClose ? (openBlock(), createBlock(Button_default, {
							key: 0,
							size: "icon",
							variant: "muted-textonly",
							"aria-label": __props.closeLabel,
							onClick: __props.onClose
						}, {
							default: withCtx(() => [..._cache[0] || (_cache[0] = [createBaseVNode("i", { class: "icon-[lucide--x] size-4" }, null, -1)])]),
							_: 1
						}, 8, ["aria-label", "onClick"])) : createCommentVNode("", true)]),
						_: 3
					}),
					renderSlot(_ctx.$slots, "default"),
					_ctx.$slots.footer ? (openBlock(), createBlock(CardFooter_default, { key: 0 }, {
						default: withCtx(() => [renderSlot(_ctx.$slots, "footer")]),
						_: 3
					})) : createCommentVNode("", true)
				]),
				_: 3
			}, 8, ["class"]);
		};
	}
});
//#endregion
//#region src/components/dialog/AppDialogPanel.vue
var AppDialogPanel_default = /* @__PURE__ */ defineComponent({
	__name: "AppDialogPanel",
	props: {
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] },
		onClose: { type: Function },
		size: { default: "default" },
		bodyClass: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] },
		unpadded: {
			type: Boolean,
			default: false
		}
	},
	setup(__props) {
		const { t } = useI18n();
		return (_ctx, _cache) => {
			return openBlock(), createBlock(DialogPanel_default, {
				"close-label": unref(t)("g.close"),
				"on-close": __props.onClose,
				class: normalizeClass(unref(cn)("w-full", __props.size === "compact" ? "max-w-90" : "max-w-lg", __props.class))
			}, createSlots({
				title: withCtx(() => [renderSlot(_ctx.$slots, "title")]),
				default: withCtx(() => [__props.unpadded ? renderSlot(_ctx.$slots, "default", {}, void 0, void 0, 0) : (openBlock(), createElementBlock("div", {
					key: 1,
					class: normalizeClass(unref(cn)("p-4", __props.bodyClass))
				}, [renderSlot(_ctx.$slots, "default")], 2))]),
				_: 2
			}, [_ctx.$slots.footer ? {
				name: "footer",
				fn: withCtx(() => [renderSlot(_ctx.$slots, "footer")]),
				key: "0"
			} : void 0]), 1032, [
				"close-label",
				"on-close",
				"class"
			]);
		};
	}
});
//#endregion
export { AppDialogPanel_default as t };
