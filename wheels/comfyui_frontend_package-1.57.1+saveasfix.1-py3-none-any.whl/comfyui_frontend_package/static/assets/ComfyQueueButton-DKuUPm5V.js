import { t as ComfyQueueButton_default } from "./ComfyQueueButton-ae5V2jgh.js";
export { ComfyQueueButton_default as default };
