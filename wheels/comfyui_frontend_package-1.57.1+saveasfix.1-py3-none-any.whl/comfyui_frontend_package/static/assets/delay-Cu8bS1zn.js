import "./rolldown-runtime-xtsTai4I.js";
import { t as globalThis_ } from "./globalThis-B6Vbq1EF.js";
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/_internal/DOMException.mjs
var DOMException = typeof globalThis_.DOMException !== "undefined" ? globalThis_.DOMException : Error;
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/error/AbortError.mjs
/**
* An error class representing an aborted operation.
* @augments DOMException
*/
var AbortError = class extends DOMException {
	constructor(message = "The operation was aborted") {
		super(message);
	}
};
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/promise/delay.mjs
/**
* Delays the execution of code for a specified number of milliseconds.
*
* This function returns a Promise that resolves after the specified delay, allowing you to use it
* with async/await to pause execution.
*
* @param ms - The number of milliseconds to delay.
* @param options - The options object.
* @param options.signal - An optional AbortSignal to cancel the delay.
* @returns A Promise that resolves after the specified delay.
*
* @example
* async function foo() {
*   console.log('Start');
*   await delay(1000); // Delays execution for 1 second
*   console.log('End');
* }
*
* foo();
*
* // With AbortSignal
* const controller = new AbortController();
* const { signal } = controller;
*
* setTimeout(() => controller.abort(), 50); // Will cancel the delay after 50ms
* try {
*   await delay(100, { signal });
*  } catch (error) {
*   console.error(error); // Will log 'AbortError'
*  }
* }
*/
function delay(ms, { signal } = {}) {
	return new Promise((resolve, reject) => {
		const abortError = () => {
			reject(new AbortError());
		};
		const abortHandler = () => {
			clearTimeout(timeoutId);
			abortError();
		};
		if (signal?.aborted) return abortError();
		const timeoutId = setTimeout(() => {
			signal?.removeEventListener("abort", abortHandler);
			resolve();
		}, ms);
		signal?.addEventListener("abort", abortHandler, { once: true });
	});
}
//#endregion
export { DOMException as n, delay as t };
