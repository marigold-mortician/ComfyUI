import "./rolldown-runtime-xtsTai4I.js";
import { $ as mergeModels, B as createSlots, G as defineComponent, Ht as toValue, I as createBlock, U as createVNode, Wt as unref, _t as useModel, ct as openBlock, dt as renderSlot, et as mergeProps, q as guardReactiveProps, qt as normalizeProps, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { Ft as ContextMenuContent_default, It as ContextMenuRoot_default, Nt as ContextMenuTrigger_default, Pt as ContextMenuPortal_default } from "./vendor-reka-ui-NRTk7aIV.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { n as menuContentClass } from "./menuStyles-BC25qUwO.js";
import { n as MenuItems_default } from "./Menu-iX8QWfwR.js";
//#endregion
//#region src/components/ui/menu/ContextMenu.vue
var ContextMenu_default = /* @__PURE__ */ defineComponent({
	inheritAttrs: false,
	__name: "ContextMenu",
	props: /*@__PURE__*/ mergeModels({
		id: {},
		model: {}
	}, {
		"open": {
			type: Boolean,
			default: false
		},
		"openModifiers": {}
	}),
	emits: ["update:open"],
	setup(__props) {
		const open = useModel(__props, "open");
		function setOpen(value) {
			open.value = value && __props.model.some((item) => toValue(item.visible) !== false);
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(ContextMenuRoot_default), {
				open: open.value,
				modal: false,
				"onUpdate:open": setOpen
			}, {
				default: withCtx(() => [createVNode(unref(ContextMenuTrigger_default), { "as-child": "" }, {
					default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
					_: 3
				}), (openBlock(), createBlock(unref(ContextMenuPortal_default), { key: Number(open.value) }, {
					default: withCtx(() => [createVNode(unref(ContextMenuContent_default), mergeProps({ id: __props.id }, _ctx.$attrs, { class: unref(cn)(unref(menuContentClass), "max-h-(--reka-context-menu-content-available-height)", _ctx.$attrs.class) }), {
						default: withCtx(() => [createVNode(MenuItems_default, {
							items: __props.model,
							onSelect: _cache[0] || (_cache[0] = ($event) => open.value = false)
						}, createSlots({ _: 2 }, [_ctx.$slots.item ? {
							name: "item",
							fn: withCtx((slotProps) => [renderSlot(_ctx.$slots, "item", normalizeProps(guardReactiveProps(slotProps)))]),
							key: "0"
						} : void 0]), 1032, ["items"])]),
						_: 3
					}, 16, ["id", "class"])]),
					_: 3
				}))]),
				_: 3
			}, 8, ["open"]);
		};
	}
});
//#endregion
export { ContextMenu_default as t };
