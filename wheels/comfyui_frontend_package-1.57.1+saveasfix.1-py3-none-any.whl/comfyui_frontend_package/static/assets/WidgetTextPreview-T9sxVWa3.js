import { t as WidgetTextPreview_default } from "./WidgetTextPreview-CGUnZGup.js";
export { WidgetTextPreview_default as default };
