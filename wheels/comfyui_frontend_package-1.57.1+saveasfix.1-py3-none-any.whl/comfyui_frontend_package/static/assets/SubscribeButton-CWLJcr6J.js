import "./rolldown-runtime-xtsTai4I.js";
import { t as useBillingContext } from "./useBillingContext-Cc-YANxo.js";
import { Ft as ref, G as defineComponent, H as createTextVNode, I as createBlock, Kt as normalizeClass, Wt as unref, Yt as toDisplayString, bt as watch, ct as openBlock, rt as onBeforeUnmount, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { n as useTelemetry } from "./telemetry-IkzvF0TI.js";
import { t as useSubscriptionPaywall } from "./useSubscriptionPaywall-DbqkouMv.js";
//#endregion
//#region src/platform/billing/subscription/components/SubscribeButton.vue
var SubscribeButton_default = /* @__PURE__ */ defineComponent({
	__name: "SubscribeButton",
	props: {
		label: {},
		size: { default: "lg" },
		buttonVariant: { default: "default" },
		fluid: {
			type: Boolean,
			default: true
		},
		disabled: {
			type: Boolean,
			default: false
		}
	},
	emits: ["subscribed"],
	setup(__props, { emit: __emit }) {
		const { canAccessSubscriptionFeatures, tier } = useBillingContext();
		const { showSubscriptionDialog } = useSubscriptionPaywall();
		const isAwaitingStripeSubscription = ref(false);
		watch([isAwaitingStripeSubscription, canAccessSubscriptionFeatures], ([awaiting, isActive]) => {});
		const handleSubscribe = () => {
			useTelemetry()?.trackSubscription("subscribe_clicked", {
				current_tier: tier.value?.toLowerCase(),
				reason: "subscribe_now_button"
			});
			isAwaitingStripeSubscription.value = true;
			showSubscriptionDialog({ reason: "subscribe_now_button" });
		};
		onBeforeUnmount(() => {
			isAwaitingStripeSubscription.value = false;
		});
		return (_ctx, _cache) => {
			return openBlock(), createBlock(Button_default, {
				size: __props.size,
				disabled: __props.disabled,
				variant: __props.buttonVariant === "subscribe" ? "subscribe" : "primary",
				class: normalizeClass(unref(cn)("font-bold", __props.fluid && "w-full")),
				onClick: handleSubscribe
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(__props.label || _ctx.$t("subscription.required.subscribe")), 1)]),
				_: 1
			}, 8, [
				"size",
				"disabled",
				"variant",
				"class"
			]);
		};
	}
});
//#endregion
export { SubscribeButton_default as t };
