import "./rolldown-runtime-xtsTai4I.js";
import { $ as mergeModels, F as createBaseVNode, Ft as ref, G as defineComponent, I as createBlock, Kt as normalizeClass, U as createVNode, Wt as unref, _t as useModel, ct as openBlock, et as mergeProps, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { i as InputGroup_default, n as InputGroupButton_default, r as InputGroupAddon_default, t as InputGroupInput_default } from "./InputGroupInput-Dt4EVVbN.js";
//#endregion
//#region src/components/ui/input/PasswordInput.vue
var PasswordInput_default = /* @__PURE__ */ defineComponent({
	inheritAttrs: false,
	__name: "PasswordInput",
	props: /*@__PURE__*/ mergeModels({
		hidePasswordLabel: {},
		showPasswordLabel: {},
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] },
		disabled: {
			type: Boolean,
			default: false
		}
	}, {
		"modelValue": {},
		"modelModifiers": {}
	}),
	emits: ["update:modelValue"],
	setup(__props) {
		const modelValue = useModel(__props, "modelValue");
		const visible = ref(false);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(InputGroup_default, { class: normalizeClass(__props.class) }, {
				default: withCtx(() => [createVNode(InputGroupInput_default, mergeProps({
					modelValue: modelValue.value,
					"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => modelValue.value = $event)
				}, _ctx.$attrs, {
					type: visible.value ? "text" : "password",
					disabled: __props.disabled
				}), null, 16, [
					"modelValue",
					"type",
					"disabled"
				]), createVNode(InputGroupAddon_default, { align: "inline-end" }, {
					default: withCtx(() => [createVNode(InputGroupButton_default, {
						size: "icon-sm",
						disabled: __props.disabled,
						"aria-label": visible.value ? __props.hidePasswordLabel : __props.showPasswordLabel,
						"aria-pressed": visible.value,
						onClick: _cache[1] || (_cache[1] = ($event) => visible.value = !visible.value)
					}, {
						default: withCtx(() => [createBaseVNode("i", { class: normalizeClass([visible.value ? "icon-[lucide--eye-off]" : "icon-[lucide--eye]", "size-4"]) }, null, 2)]),
						_: 1
					}, 8, [
						"disabled",
						"aria-label",
						"aria-pressed"
					])]),
					_: 1
				})]),
				_: 1
			}, 8, ["class"]);
		};
	}
});
//#endregion
//#region src/components/common/AppPasswordInput.vue
var AppPasswordInput_default = /* @__PURE__ */ defineComponent({
	__name: "AppPasswordInput",
	props: {
		"modelValue": {},
		"modelModifiers": {}
	},
	emits: ["update:modelValue"],
	setup(__props) {
		const modelValue = useModel(__props, "modelValue");
		const { t } = useI18n();
		return (_ctx, _cache) => {
			return openBlock(), createBlock(PasswordInput_default, {
				modelValue: modelValue.value,
				"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => modelValue.value = $event),
				"show-password-label": unref(t)("auth.showPassword"),
				"hide-password-label": unref(t)("auth.hidePassword")
			}, null, 8, [
				"modelValue",
				"show-password-label",
				"hide-password-label"
			]);
		};
	}
});
//#endregion
export { AppPasswordInput_default as t };
