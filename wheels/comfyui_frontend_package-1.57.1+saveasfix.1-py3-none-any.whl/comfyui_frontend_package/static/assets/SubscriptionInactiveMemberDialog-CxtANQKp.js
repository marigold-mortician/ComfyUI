import "./rolldown-runtime-xtsTai4I.js";
import { F as createBaseVNode, G as defineComponent, H as createTextVNode, I as createBlock, U as createVNode, Yt as toDisplayString, ct as openBlock, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as AppDialogPanel_default } from "./AppDialogPanel-BklaJBTn.js";
//#region src/platform/billing/components/SubscriptionInactiveMemberDialog.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "m-0 text-sm text-muted-foreground" };
//#endregion
//#region src/platform/billing/components/SubscriptionInactiveMemberDialog.vue
var SubscriptionInactiveMemberDialog_default = /* @__PURE__ */ defineComponent({
	__name: "SubscriptionInactiveMemberDialog",
	props: { onClose: { type: Function } },
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createBlock(AppDialogPanel_default, {
				size: "compact",
				"data-testid": "member-resubscribe-message",
				onClose: __props.onClose
			}, {
				title: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("subscription.inactive.memberTitle")), 1)]),
				footer: withCtx(() => [createVNode(Button_default, {
					variant: "secondary",
					size: "lg",
					onClick: __props.onClose
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("subscription.inactive.memberCta")), 1)]),
					_: 1
				}, 8, ["onClick"])]),
				default: withCtx(() => [createBaseVNode("p", _hoisted_1, toDisplayString(_ctx.$t("subscription.inactive.memberDescription")), 1)]),
				_: 1
			}, 8, ["onClose"]);
		};
	}
});
//#endregion
export { SubscriptionInactiveMemberDialog_default as default };
