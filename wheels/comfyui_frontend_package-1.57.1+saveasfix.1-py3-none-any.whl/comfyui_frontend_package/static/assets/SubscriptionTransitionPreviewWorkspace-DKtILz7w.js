import "./rolldown-runtime-xtsTai4I.js";
import { A as useBillingRouting, O as createBillingPortalReporter, _ as resolveEntrySource, d as bindOperationToCheckoutJourney, g as resolveCheckoutJourney, h as resolveCheckoutAssignment, i as useBillingOperationStore, k as registerRefreshOnReturn, m as getActiveCheckoutJourney, o as SettledOperationError, r as useSubscriptionRail, s as billingClientOf, t as useBillingContext, u as openHostedBillingTab } from "./useBillingContext-uo5ceiak.js";
import { r as workspaceApi, t as useTeamWorkspaceStore } from "./teamWorkspaceStore-BNm5cZOK.js";
import { i as api } from "./api-BdJmXw98.js";
import { $ as mergeModels, C as vModelText, E as withModifiers, F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, I as createBlock, Kt as normalizeClass, L as createCommentVNode, Mt as onScopeDispose, O as Fragment, P as computed, R as createElementBlock, Tt as withDirectives, U as createVNode, Wt as unref, Yt as toDisplayString, _t as useModel, at as onMounted, b as vModelCheckbox, bt as watch, ct as openBlock, dt as renderSlot, gt as useId, rt as onBeforeUnmount, tt as nextTick, ut as renderList, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { B as SelectPortal_default, Dn as injectDialogRootContext, F as SelectViewport_default, G as SelectContent_default, H as SelectItemIndicator_default, I as SelectValue_default, K as SelectRoot_default, L as SelectTrigger_default, U as SelectItem_default, V as SelectItemText_default } from "./vendor-reka-ui-NRTk7aIV.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { r as buttonVariants, t as Button_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { n as useTelemetry } from "./telemetry-IkzvF0TI.js";
import { t as useToast } from "./toastStore-Dg65fRgL.js";
import { r as reportError } from "./reportError-BHgDVvfb.js";
import { t as getErrorMessage } from "./errorUtil-DoQyAUQC.js";
import { r as useAuthStore } from "./authStore-D2cL6XhN.js";
import { r as getComfyPlatformBaseUrl } from "./comfyApi-CXw0-V35.js";
import { c as getTierPrice, m as toTierKey, o as getTierCredits } from "./tierPricing-Dm5JzLf8.js";
import { l as categorizeBillingApiError, n as openBillingUrl } from "./useAuthActions-_rhVfmiU.js";
import { o as useBillingReadRail, s as readOnRail, t as useBillingCapabilities } from "./useBillingCapabilities-x1h7nBmq.js";
import { n as useBillingDialogsAccess } from "./billingDialogsAccess-BbNj81q5.js";
import { t as useWorkspaceUI } from "./useWorkspaceUI-rAENEr3F.js";
import { i as savePendingSubscriptionCheckout, n as clearPendingSubscriptionCheckoutIfTerminal } from "./pendingSubscriptionCheckout-CwZ4vFuG.js";
import { n as trackCheckoutJourneyPhase, r as useCheckoutJourneyExit, t as handOffCheckoutJourney } from "./checkoutJourneyTelemetry-afzrfER1.js";
import { a as selectItemVariants, o as selectTriggerVariants, r as selectDropdownClass, s as stopEscapeToDocument, t as selectContentClass } from "./select.variants-BBeExFA3.js";
import { a as formatRenewalAmount, c as isYearlyCheckout, i as formatQuoteMoney, l as resolveRenewalDate, n as formatAmountDueToday, o as formatUsdFromCents, r as formatNumber, s as isAnnualDuration, t as amountDueTodayChanged } from "./checkoutQuote-BtwiXuaq.js";
import { t as InviteMembersForm_default } from "./InviteMembersForm-arxB0rLs.js";
//#region node_modules/.pnpm/@stripe+stripe-js@9.12.1/node_modules/@stripe/stripe-js/dist/pure.mjs
function _typeof(obj) {
	"@babel/helpers - typeof";
	if (typeof Symbol === "function" && typeof Symbol.iterator === "symbol") _typeof = function(obj) {
		return typeof obj;
	};
	else _typeof = function(obj) {
		return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
	};
	return _typeof(obj);
}
var RELEASE_TRAIN = "dahlia";
var runtimeVersionToUrlVersion = function runtimeVersionToUrlVersion(version) {
	return version === 3 ? "v3" : version;
};
var ORIGIN = "https://js.stripe.com";
var STRIPE_JS_URL = "".concat(ORIGIN, "/").concat(RELEASE_TRAIN, "/stripe.js");
var V3_URL_REGEX = /^https:\/\/js\.stripe\.com\/v3\/?(\?.*)?$/;
var STRIPE_JS_URL_REGEX = /^https:\/\/js\.stripe\.com\/(v3|[a-z]+)\/stripe\.js(\?.*)?$/;
var EXISTING_SCRIPT_MESSAGE = "loadStripe.setLoadParameters was called but an existing Stripe.js script already exists in the document; existing script parameters will be used";
var isStripeJSURL = function isStripeJSURL(url) {
	return V3_URL_REGEX.test(url) || STRIPE_JS_URL_REGEX.test(url);
};
var findScript = function findScript() {
	var scripts = document.querySelectorAll("script[src^=\"".concat(ORIGIN, "\"]"));
	for (var i = 0; i < scripts.length; i++) {
		var script = scripts[i];
		if (!isStripeJSURL(script.src)) continue;
		return script;
	}
	return null;
};
var injectScript = function injectScript(params) {
	var queryString = params && !params.advancedFraudSignals ? "?advancedFraudSignals=false" : "";
	var script = document.createElement("script");
	script.src = "".concat(STRIPE_JS_URL).concat(queryString);
	var headOrBody = document.head || document.body;
	if (!headOrBody) throw new Error("Expected document.body not to be null. Stripe.js requires a <body> element.");
	headOrBody.appendChild(script);
	return script;
};
var registerWrapper = function registerWrapper(stripe, startTime) {
	if (!stripe || !stripe._registerWrapper) return;
	stripe._registerWrapper({
		name: "stripe-js",
		version: "9.12.1",
		startTime
	});
};
var stripePromise = null;
var onErrorListener = null;
var onLoadListener = null;
var onError = function onError(reject) {
	return function(cause) {
		reject(new Error("Failed to load Stripe.js", { cause }));
	};
};
var onLoad = function onLoad(resolve, reject) {
	return function() {
		if (window.Stripe) resolve(window.Stripe);
		else reject(/* @__PURE__ */ new Error("Stripe.js not available"));
	};
};
var loadScript = function loadScript(params) {
	if (stripePromise !== null) return stripePromise;
	stripePromise = new Promise(function(resolve, reject) {
		if (typeof window === "undefined" || typeof document === "undefined") {
			resolve(null);
			return;
		}
		if (window.Stripe && params) console.warn(EXISTING_SCRIPT_MESSAGE);
		if (window.Stripe) {
			resolve(window.Stripe);
			return;
		}
		try {
			var script = findScript();
			if (script && params) console.warn(EXISTING_SCRIPT_MESSAGE);
			else if (!script) script = injectScript(params);
			else if (script && onLoadListener !== null && onErrorListener !== null) {
				var _script$parentNode;
				script.removeEventListener("load", onLoadListener);
				script.removeEventListener("error", onErrorListener);
				(_script$parentNode = script.parentNode) === null || _script$parentNode === void 0 || _script$parentNode.removeChild(script);
				script = injectScript(params);
			}
			onLoadListener = onLoad(resolve, reject);
			onErrorListener = onError(reject);
			script.addEventListener("load", onLoadListener);
			script.addEventListener("error", onErrorListener);
		} catch (error) {
			reject(error);
			return;
		}
	});
	return stripePromise["catch"](function(error) {
		stripePromise = null;
		return Promise.reject(error);
	});
};
var initStripe = function initStripe(maybeStripe, args, startTime) {
	if (maybeStripe === null) return null;
	var pk = args[0];
	if (typeof pk !== "string") throw new Error("Expected publishable key to be of type string, got type ".concat(_typeof(pk), " instead."));
	var isTestKey = pk.match(/^pk_test/);
	var version = runtimeVersionToUrlVersion(maybeStripe.version);
	var expectedVersion = RELEASE_TRAIN;
	if (isTestKey && version !== expectedVersion) console.warn("Stripe.js@".concat(version, " was loaded on the page, but @stripe/stripe-js@").concat("9.12.1", " expected Stripe.js@").concat(expectedVersion, ". This may result in unexpected behavior. For more information, see https://docs.stripe.com/sdks/stripejs-versioning"));
	var stripe = maybeStripe.apply(void 0, args);
	registerWrapper(stripe, startTime);
	return stripe;
};
var validateLoadParams = function validateLoadParams(params) {
	var errorMessage = "invalid load parameters; expected object of shape\n\n    {advancedFraudSignals: boolean}\n\nbut received\n\n    ".concat(JSON.stringify(params), "\n");
	if (params === null || _typeof(params) !== "object") throw new Error(errorMessage);
	if (Object.keys(params).length === 1 && typeof params.advancedFraudSignals === "boolean") return params;
	throw new Error(errorMessage);
};
var loadParams;
var loadStripeCalled = false;
var loadStripe = function loadStripe() {
	for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) args[_key] = arguments[_key];
	loadStripeCalled = true;
	var startTime = Date.now();
	return loadScript(loadParams).then(function(maybeStripe) {
		return initStripe(maybeStripe, args, startTime);
	});
};
loadStripe.setLoadParameters = function(params) {
	if (loadStripeCalled && loadParams) {
		var validatedParams = validateLoadParams(params);
		if (Object.keys(validatedParams).reduce(function(previousValue, currentValue) {
			var _loadParams;
			return previousValue && params[currentValue] === ((_loadParams = loadParams) === null || _loadParams === void 0 ? void 0 : _loadParams[currentValue]);
		}, true)) return;
	}
	if (loadStripeCalled) throw new Error("You cannot change load parameters after calling loadStripe");
	loadParams = validateLoadParams(params);
};
//#endregion
//#region packages/account-ui/src/billing/stripe/StripePaymentForm.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$16 = {
	key: 0,
	class: "flex items-start justify-between gap-4"
};
var _hoisted_2$13 = ["id"];
var _hoisted_3$10 = { class: "m-0 mt-1 max-w-md text-sm text-muted-foreground" };
var _hoisted_4$9 = {
	key: 1,
	class: "rounded-lg border border-destructive bg-destructive/10 px-3 py-2 text-sm text-destructive"
};
var _hoisted_5$6 = [
	"aria-labelledby",
	"aria-label",
	"inert"
];
var _hoisted_6$3 = { class: "flex flex-col gap-3" };
var _hoisted_7$3 = {
	key: 0,
	class: "flex items-start gap-3 rounded-xl bg-background/60 px-4 py-3 text-xs text-muted-foreground"
};
var _hoisted_8$3 = { class: "m-0" };
//#endregion
//#region packages/account-ui/src/billing/stripe/StripePaymentForm.vue
var StripePaymentForm_default = /* @__PURE__ */ defineComponent({
	__name: "StripePaymentForm",
	props: {
		publishableKey: {},
		amountCents: {},
		currency: {},
		copy: {},
		paymentMethodConfigurationId: { default: "" },
		isLoading: {
			type: Boolean,
			default: false
		},
		verificationPending: {
			type: Boolean,
			default: false
		},
		canSubmit: {
			type: Boolean,
			default: true
		},
		locked: {
			type: Boolean,
			default: false
		},
		themeKey: { default: "" },
		pageLayout: {
			type: Boolean,
			default: false
		},
		payOnce: {
			type: Boolean,
			default: false
		}
	},
	emits: [
		"confirm",
		"submittingChange",
		"phase"
	],
	setup(__props, { emit: __emit }) {
		/**
		* The provider-bound half of checkout: mounts Stripe's Payment and Address
		* Elements, validates them, and turns them into a confirmation token the
		* caller hands to `subscribe`. Everything host-shaped arrives as an input —
		* the publishable key, the copy, the pay button through the `submit` slot —
		* and every observation leaves as a `phase` event, so the package chooses no
		* design system, no i18n runtime and no telemetry sink.
		*/
		const emit = __emit;
		const headingId = useId();
		let isUnmounted = false;
		function reportPhase(phase) {
			if (isUnmounted) return;
			emit("phase", phase);
		}
		const paymentElementTarget = ref();
		const addressElementTarget = ref();
		const stripeElements = ref();
		const configurationError = ref("");
		const isSubmitting = ref(false);
		const selectedMethodType = ref("");
		let stripe = null;
		let paymentElement;
		let addressElement;
		const submitDisabled = computed(() => !stripeElements.value || !__props.canSubmit || __props.verificationPending);
		const submitBlocked = computed(() => submitDisabled.value || isSubmitting.value || __props.isLoading);
		function failElementInit() {
			configurationError.value = __props.copy.unavailable;
			reportPhase({
				phase: "payment_element_failed",
				element: "payment",
				element_phase: "init"
			});
		}
		function failSubmit(submitPhase, error) {
			configurationError.value = error?.message ?? __props.copy.genericError;
			reportPhase({
				phase: "payment_submit_failed",
				submit_phase: submitPhase,
				...error?.code && { error_code: error.code }
			});
		}
		function mountPaymentElement(elements, target) {
			paymentElement = elements.create("payment", {
				layout: {
					type: "accordion",
					defaultCollapsed: false,
					radios: "always",
					spacedAccordionItems: true
				},
				fields: { billingDetails: { address: "never" } },
				terms: { card: "never" }
			});
			paymentElement.mount(target);
			paymentElement.on("ready", () => {
				reportPhase({
					phase: "payment_element_ready",
					element: "payment"
				});
			});
			paymentElement.on("loaderror", (event) => {
				reportPhase({
					phase: "payment_element_failed",
					element: "payment",
					element_phase: "mount",
					...event.error?.code && { error_code: event.error.code }
				});
			});
			paymentElement.on("change", (event) => {
				selectedMethodType.value = event.value?.type ?? "";
			});
		}
		/**
		* A full billing address feeds AVS to the issuer and Radar. In billing mode
		* every field is required, and because the address shares the Payment
		* Element's group, createConfirmationToken folds it into the token's
		* billing_details.
		*/
		function mountAddressElement(elements, target) {
			addressElement = elements.create("address", { mode: "billing" });
			addressElement.mount(target);
			addressElement.on("ready", () => {
				reportPhase({
					phase: "payment_element_ready",
					element: "address"
				});
			});
			addressElement.on("loaderror", (event) => {
				reportPhase({
					phase: "payment_element_failed",
					element: "address",
					element_phase: "mount",
					...event.error?.code && { error_code: event.error.code }
				});
			});
		}
		function intentOptions() {
			return __props.payOnce ? { mode: "payment" } : {
				mode: "subscription",
				setupFutureUsage: "off_session"
			};
		}
		onMounted(async () => {
			if (!__props.publishableKey || !__props.paymentMethodConfigurationId) {
				failElementInit();
				return;
			}
			if (__props.amountCents <= 0) return;
			try {
				stripe = await loadStripe(__props.publishableKey);
			} catch {
				failElementInit();
				return;
			}
			if (!stripe || !paymentElementTarget.value || isUnmounted) {
				failElementInit();
				return;
			}
			stripeElements.value = stripe.elements({
				...intentOptions(),
				amount: __props.amountCents,
				currency: __props.currency.toLowerCase(),
				paymentMethodConfiguration: __props.paymentMethodConfigurationId,
				appearance: resolveAppearance(paymentElementTarget.value)
			});
			mountPaymentElement(stripeElements.value, paymentElementTarget.value);
			if (addressElementTarget.value) mountAddressElement(stripeElements.value, addressElementTarget.value);
		});
		watch([() => __props.amountCents, () => __props.currency], ([amount, nextCurrency]) => {
			if (!stripeElements.value || amount <= 0) return;
			stripeElements.value.update({
				amount,
				currency: nextCurrency.toLowerCase()
			}).catch(() => {
				if (isUnmounted) return;
				configurationError.value = __props.copy.genericError;
				reportPhase({
					phase: "payment_element_failed",
					element: "payment",
					element_phase: "update"
				});
			});
		});
		watch(() => __props.themeKey, () => {
			if (!stripeElements.value || !paymentElementTarget.value) return;
			stripeElements.value.update({ appearance: resolveAppearance(paymentElementTarget.value) }).catch(() => {
				reportPhase({
					phase: "payment_element_failed",
					element: "payment",
					element_phase: "update"
				});
			});
		}, { flush: "post" });
		onBeforeUnmount(() => {
			isUnmounted = true;
			paymentElement?.destroy();
			addressElement?.destroy();
		});
		async function mintConfirmationToken(elements, client) {
			let submitResult;
			try {
				submitResult = await elements.submit();
			} catch {
				failSubmit("validation");
				return;
			}
			if (submitResult.error) {
				failSubmit("validation", submitResult.error);
				return;
			}
			const result = await client.createConfirmationToken({ elements });
			if (result.error) {
				failSubmit("token_creation", result.error);
				return;
			}
			return {
				id: result.confirmationToken.id,
				paymentMethodType: result.confirmationToken.payment_method_preview.type
			};
		}
		async function submit() {
			if (submitBlocked.value || !stripeElements.value || !stripe) return;
			isSubmitting.value = true;
			emit("submittingChange", true);
			configurationError.value = "";
			reportPhase({ phase: "payment_submit_attempted" });
			try {
				const confirmationToken = await mintConfirmationToken(stripeElements.value, stripe);
				if (confirmationToken && !isUnmounted) emit("confirm", confirmationToken.id, confirmationToken.paymentMethodType);
			} catch {
				failSubmit("token_creation");
			} finally {
				isSubmitting.value = false;
				if (!isUnmounted) emit("submittingChange", false);
			}
		}
		/**
		* Stripe takes appearance as concrete values, so every token is resolved
		* against the form's own theme root, where the host's theme class applies.
		*/
		function resolveAppearance(themeRoot) {
			const resolveThemeColor = (variable) => resolveColorIn(themeRoot, variable);
			return {
				variables: {
					colorPrimary: resolveThemeColor("--foreground"),
					colorBackground: resolveThemeColor("--background"),
					colorText: resolveThemeColor("--foreground"),
					colorTextSecondary: resolveThemeColor("--muted-foreground"),
					colorDanger: resolveThemeColor("--destructive"),
					colorSuccess: resolveThemeColor("--primary"),
					fontFamily: getComputedStyle(themeRoot).fontFamily,
					borderRadius: "10px",
					spacingUnit: "5px"
				},
				rules: {
					".AccordionItem": {
						backgroundColor: resolveThemeColor("--background"),
						border: "1px solid transparent",
						boxShadow: "none"
					},
					".AccordionItem--selected": { borderColor: resolveThemeColor("--foreground") },
					".Input": {
						backgroundColor: resolveThemeColor("--input"),
						borderColor: resolveThemeColor("--border"),
						boxShadow: "none"
					},
					".Input:focus": {
						borderColor: resolveThemeColor("--primary"),
						boxShadow: `0 0 0 1px ${resolveThemeColor("--primary")}`
					},
					".Label": { fontWeight: "500" }
				}
			};
		}
		function resolveColorIn(themeRoot, variable) {
			const probe = document.createElement("span");
			probe.style.color = `var(${variable})`;
			themeRoot.append(probe);
			const color = getComputedStyle(probe).color;
			probe.remove();
			return color;
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("form", {
				class: "flex min-h-0 flex-col gap-6 xl:flex-1",
				onSubmit: withModifiers(submit, ["prevent"])
			}, [
				!__props.pageLayout ? (openBlock(), createElementBlock("div", _hoisted_1$16, [createBaseVNode("div", null, [createBaseVNode("h3", {
					id: unref(headingId),
					class: "m-0 text-base font-semibold text-foreground"
				}, toDisplayString(__props.copy.paymentMethod), 9, _hoisted_2$13), createBaseVNode("p", _hoisted_3$10, toDisplayString(__props.copy.methodChoice), 1)])])) : createCommentVNode("", true),
				configurationError.value ? (openBlock(), createElementBlock("div", _hoisted_4$9, toDisplayString(configurationError.value), 1)) : createCommentVNode("", true),
				createBaseVNode("div", {
					role: "group",
					"aria-labelledby": __props.pageLayout ? void 0 : unref(headingId),
					"aria-label": __props.pageLayout ? __props.copy.paymentMethod : void 0,
					inert: __props.locked,
					class: "flex flex-col gap-6 xl:min-h-0 xl:flex-1 xl:overflow-x-hidden xl:overflow-y-auto xl:pr-1"
				}, [
					createBaseVNode("div", {
						ref_key: "paymentElementTarget",
						ref: paymentElementTarget
					}, null, 512),
					createBaseVNode("div", _hoisted_6$3, [createBaseVNode("h4", { class: normalizeClass(unref(cn)("m-0 text-foreground", __props.pageLayout ? "text-base font-normal" : "text-sm font-medium")) }, toDisplayString(__props.copy.billingAddress), 3), createBaseVNode("div", {
						ref_key: "addressElementTarget",
						ref: addressElementTarget
					}, null, 512)]),
					selectedMethodType.value === "alipay" ? (openBlock(), createElementBlock("div", _hoisted_7$3, [_cache[0] || (_cache[0] = createBaseVNode("i", { class: "mt-0.5 icon-[lucide--shield-check] size-4 shrink-0 text-(--success-foreground)" }, null, -1)), createBaseVNode("p", _hoisted_8$3, toDisplayString(__props.copy.alipayRenewalNote), 1)])) : createCommentVNode("", true)
				], 8, _hoisted_5$6),
				renderSlot(_ctx.$slots, "submit", {
					disabled: submitDisabled.value,
					loading: __props.isLoading || isSubmitting.value,
					verificationPending: __props.verificationPending
				})
			], 32);
		};
	}
});
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutButton.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$15 = [
	"type",
	"disabled",
	"aria-busy"
];
var _hoisted_2$12 = {
	key: 0,
	class: "pi pi-spin pi-spinner",
	"aria-hidden": "true"
};
var _hoisted_3$9 = {
	key: 1,
	class: "sr-only"
};
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutButton.vue
var CheckoutButton_default = /* @__PURE__ */ defineComponent({
	__name: "CheckoutButton",
	props: {
		type: { default: "button" },
		variant: {},
		size: {},
		class: {
			type: [
				Boolean,
				null,
				String,
				Object,
				Array
			],
			default: ""
		},
		loading: {
			type: Boolean,
			default: false
		},
		disabled: {
			type: Boolean,
			default: false
		}
	},
	setup(__props) {
		/**
		* The cloud app's Button, as a native button: same variant classes, same
		* loading treatment (spinner with the label kept for screen readers).
		*/
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("button", {
				type: __props.type,
				disabled: __props.disabled || __props.loading,
				"aria-busy": __props.loading || void 0,
				class: normalizeClass(unref(cn)(unref(buttonVariants)({
					variant: __props.variant,
					size: __props.size
				}), __props.class))
			}, [__props.loading ? (openBlock(), createElementBlock("i", _hoisted_2$12)) : createCommentVNode("", true), __props.loading ? (openBlock(), createElementBlock("span", _hoisted_3$9, [renderSlot(_ctx.$slots, "default")])) : renderSlot(_ctx.$slots, "default", {}, void 0, void 0, 2)], 10, _hoisted_1$15);
		};
	}
});
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutPaymentForm.vue
var CheckoutPaymentForm_default = /* @__PURE__ */ defineComponent({
	__name: "CheckoutPaymentForm",
	props: {
		publishableKey: {},
		amountCents: {},
		currency: {},
		copy: {},
		submitLabel: {},
		paymentMethodConfigurationId: { default: "" },
		isLoading: {
			type: Boolean,
			default: false
		},
		verificationPending: {
			type: Boolean,
			default: false
		},
		canSubmit: {
			type: Boolean,
			default: true
		},
		themeKey: {}
	},
	emits: [
		"confirm",
		"submittingChange",
		"phase"
	],
	setup(__props, { emit: __emit }) {
		/**
		* The payment form with the checkout's pay button: the card entry both the
		* cloud app and billing-web show when no saved method stands in for it.
		*/
		const emit = __emit;
		return (_ctx, _cache) => {
			return openBlock(), createBlock(StripePaymentForm_default, {
				"publishable-key": __props.publishableKey,
				"amount-cents": __props.amountCents,
				currency: __props.currency,
				copy: __props.copy,
				"payment-method-configuration-id": __props.paymentMethodConfigurationId,
				"is-loading": __props.isLoading,
				"verification-pending": __props.verificationPending,
				"can-submit": __props.canSubmit,
				"theme-key": __props.themeKey,
				onConfirm: _cache[0] || (_cache[0] = (token, methodType) => emit("confirm", token, methodType)),
				onSubmittingChange: _cache[1] || (_cache[1] = ($event) => emit("submittingChange", $event)),
				onPhase: _cache[2] || (_cache[2] = ($event) => emit("phase", $event))
			}, {
				submit: withCtx(({ disabled, loading, verificationPending: pending }) => [createVNode(CheckoutButton_default, {
					type: "submit",
					variant: pending ? "tertiary" : "inverted",
					size: "lg",
					class: "w-full rounded-lg",
					disabled,
					loading
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(__props.submitLabel), 1)]),
					_: 1
				}, 8, [
					"variant",
					"disabled",
					"loading"
				])]),
				_: 1
			}, 8, [
				"publishable-key",
				"amount-cents",
				"currency",
				"copy",
				"payment-method-configuration-id",
				"is-loading",
				"verification-pending",
				"can-submit",
				"theme-key"
			]);
		};
	}
});
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutSavedMethodSelect.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$14 = { class: "flex flex-1 items-center gap-2 overflow-hidden py-2 pl-2 text-sm" };
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutSavedMethodSelect.vue
var CheckoutSavedMethodSelect_default = /* @__PURE__ */ defineComponent({
	__name: "CheckoutSavedMethodSelect",
	props: /*@__PURE__*/ mergeModels({
		label: {},
		options: {}
	}, {
		"modelValue": { required: true },
		"modelModifiers": {}
	}),
	emits: ["update:modelValue"],
	setup(__props) {
		/**
		* The cloud app's single select, reduced to what the saved-method picker
		* uses: the large trigger and a flat option list.
		*/
		const selected = useModel(__props, "modelValue");
		const isOpen = ref(false);
		function onContentKeydown(event) {
			if (event.key === "Escape") {
				stopEscapeToDocument(event);
				isOpen.value = false;
			}
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(SelectRoot_default), {
				modelValue: selected.value,
				"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => selected.value = $event),
				open: isOpen.value,
				"onUpdate:open": _cache[1] || (_cache[1] = ($event) => isOpen.value = $event)
			}, {
				default: withCtx(() => [createVNode(unref(SelectTrigger_default), {
					"aria-label": __props.label,
					class: normalizeClass(unref(selectTriggerVariants)({
						size: "lg",
						border: "none"
					}))
				}, {
					default: withCtx(() => [createBaseVNode("div", _hoisted_1$14, [createVNode(unref(SelectValue_default), { class: "truncate" })]), createBaseVNode("div", { class: normalizeClass(unref(selectDropdownClass)) }, [..._cache[2] || (_cache[2] = [createBaseVNode("i", { class: "icon-[lucide--chevron-down] text-muted-foreground" }, null, -1)])], 2)]),
					_: 1
				}, 8, ["aria-label", "class"]), createVNode(unref(SelectPortal_default), null, {
					default: withCtx(() => [createVNode(unref(SelectContent_default), {
						position: "popper",
						"side-offset": 8,
						align: "start",
						class: normalizeClass(unref(cn)(unref(selectContentClass), "min-w-(--reka-select-trigger-width)")),
						onKeydown: onContentKeydown
					}, {
						default: withCtx(() => [createVNode(unref(SelectViewport_default), {
							style: { maxHeight: "min(28rem, 50vh)" },
							class: "scrollbar-custom w-full"
						}, {
							default: withCtx(() => [(openBlock(true), createElementBlock(Fragment, null, renderList(__props.options, (option) => {
								return openBlock(), createBlock(unref(SelectItem_default), {
									key: option.value,
									value: option.value,
									class: normalizeClass(unref(selectItemVariants)({ layout: "single" }))
								}, {
									default: withCtx(() => [createVNode(unref(SelectItemText_default), { class: "truncate" }, {
										default: withCtx(() => [createTextVNode(toDisplayString(option.name), 1)]),
										_: 2
									}, 1024), createVNode(unref(SelectItemIndicator_default), { class: "flex shrink-0 items-center justify-center" }, {
										default: withCtx(() => [..._cache[3] || (_cache[3] = [createBaseVNode("i", {
											class: "icon-[lucide--check] text-foreground",
											"aria-hidden": "true"
										}, null, -1)])]),
										_: 1
									})]),
									_: 2
								}, 1032, ["value", "class"]);
							}), 128))]),
							_: 1
						})]),
						_: 1
					}, 8, ["class"])]),
					_: 1
				})]),
				_: 1
			}, 8, ["modelValue", "open"]);
		};
	}
});
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutSavedMethods.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$13 = { class: "flex flex-col gap-2 pt-6" };
var _hoisted_2$11 = { class: "text-sm text-muted-foreground" };
var _hoisted_3$8 = {
	key: 0,
	class: "flex h-10 items-center gap-3 rounded-lg bg-secondary px-4"
};
var _hoisted_4$8 = { class: "text-sm text-foreground tabular-nums" };
var ADD_NEW = "add-new";
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutSavedMethods.vue
var CheckoutSavedMethods_default = /* @__PURE__ */ defineComponent({
	__name: "CheckoutSavedMethods",
	props: /*@__PURE__*/ mergeModels({
		methods: {},
		copy: {}
	}, {
		"selectedMethodId": { default: null },
		"selectedMethodIdModifiers": {}
	}),
	emits: /*@__PURE__*/ mergeModels(["changePaymentMethod"], ["update:selectedMethodId"]),
	setup(__props, { emit: __emit }) {
		/**
		* The saved payment methods standing in for the card form. One method shows
		* a Change affordance; two or more become a picker whose last option adds a
		* new method. Cards carry brand + last4; Alipay is a linked account with
		* neither.
		*/
		const emit = __emit;
		const selectedMethodId = useModel(__props, "selectedMethodId");
		function methodLabel(method) {
			if (method.type === "alipay") return __props.copy.alipay;
			return `${method.brand} •••• ${method.last4}`;
		}
		const options = computed(() => [...__props.methods.map((method) => ({
			name: methodLabel(method),
			value: method.id
		})), {
			name: __props.copy.addNewPaymentMethod,
			value: ADD_NEW
		}]);
		const selectedMethod = computed({
			get: () => selectedMethodId.value ?? "",
			set: (value) => {
				if (value === ADD_NEW) {
					selectedMethodId.value = null;
					emit("changePaymentMethod");
					return;
				}
				selectedMethodId.value = value;
			}
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$13, [createBaseVNode("span", _hoisted_2$11, toDisplayString(__props.copy.savedPaymentMethod), 1), __props.methods.length === 1 ? (openBlock(), createElementBlock("div", _hoisted_3$8, [
				createBaseVNode("i", { class: normalizeClass(unref(cn)("size-4 shrink-0", __props.methods[0].type === "alipay" ? "icon-[lucide--wallet]" : "icon-[lucide--credit-card]")) }, null, 2),
				createBaseVNode("span", _hoisted_4$8, toDisplayString(methodLabel(__props.methods[0])), 1),
				createVNode(CheckoutButton_default, {
					variant: "link",
					size: "lg",
					class: "ml-auto px-0",
					onClick: _cache[0] || (_cache[0] = ($event) => emit("changePaymentMethod"))
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(__props.copy.changePaymentMethod), 1)]),
					_: 1
				})
			])) : (openBlock(), createBlock(CheckoutSavedMethodSelect_default, {
				key: 1,
				modelValue: selectedMethod.value,
				"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => selectedMethod.value = $event),
				label: __props.copy.selectLabel,
				options: options.value
			}, null, 8, [
				"modelValue",
				"label",
				"options"
			]))]);
		};
	}
});
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutPromotionCode.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$12 = { class: "flex gap-2 pt-6" };
var _hoisted_2$10 = [
	"aria-label",
	"disabled",
	"placeholder"
];
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutPromotionCode.vue
var CheckoutPromotionCode_default = /* @__PURE__ */ defineComponent({
	__name: "CheckoutPromotionCode",
	props: {
		appliedCode: {},
		disabled: {
			type: Boolean,
			default: false
		},
		copy: {}
	},
	emits: ["apply", "invalidate"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const code = ref(__props.appliedCode ?? "");
		watch(() => __props.appliedCode, (applied) => {
			code.value = applied ?? "";
		});
		function invalidateEditedCode() {
			if (code.value !== (__props.appliedCode ?? "")) emit("invalidate");
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$12, [withDirectives(createBaseVNode("input", {
				"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => code.value = $event),
				"aria-label": __props.copy.promoCodePlaceholder,
				disabled: __props.disabled,
				class: "h-10 min-w-0 flex-1 rounded-lg border bg-secondary px-3 text-foreground",
				placeholder: __props.copy.promoCodePlaceholder,
				onInput: invalidateEditedCode
			}, null, 40, _hoisted_2$10), [[vModelText, code.value]]), createVNode(CheckoutButton_default, {
				variant: "secondary",
				size: "lg",
				disabled: __props.disabled,
				onClick: _cache[1] || (_cache[1] = ($event) => emit("apply", code.value))
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(__props.copy.applyPromoCode), 1)]),
				_: 1
			}, 8, ["disabled"])]);
		};
	}
});
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutPaymentNotices.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$11 = {
	key: 0,
	class: "rounded-lg border bg-secondary p-4"
};
var _hoisted_2$9 = { class: "m-0 font-semibold text-foreground" };
var _hoisted_3$7 = { class: "m-0 mt-1 text-sm text-muted-foreground" };
var _hoisted_4$7 = { class: "font-mono" };
var _hoisted_5$5 = {
	key: 1,
	role: "alert",
	class: "rounded-lg border bg-secondary p-4 text-sm text-foreground"
};
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutPaymentNotices.vue
var CheckoutPaymentNotices_default = /* @__PURE__ */ defineComponent({
	__name: "CheckoutPaymentNotices",
	props: {
		embeddedCheckoutEnabled: { type: Boolean },
		reconciliationOperationId: {},
		authenticationState: {},
		authenticationError: {},
		copy: {}
	},
	setup(__props) {
		/** What an earlier payment attempt left for the customer to read. */
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock(Fragment, null, [__props.embeddedCheckoutEnabled && __props.reconciliationOperationId ? (openBlock(), createElementBlock("div", _hoisted_1$11, [createBaseVNode("p", _hoisted_2$9, toDisplayString(__props.copy.reconciliationTitle), 1), createBaseVNode("p", _hoisted_3$7, [createTextVNode(toDisplayString(__props.copy.reconciliationDetail) + " ", 1), createBaseVNode("span", _hoisted_4$7, toDisplayString(__props.reconciliationOperationId), 1)])])) : createCommentVNode("", true), __props.embeddedCheckoutEnabled && __props.authenticationState === "failed_retryable" ? (openBlock(), createElementBlock("div", _hoisted_5$5, toDisplayString(__props.authenticationError || __props.copy.authenticationFailedDetail), 1)) : createCommentVNode("", true)], 64);
		};
	}
});
//#endregion
//#region packages/account-ui/src/billing/checkout/checkoutCopy.ts
/**
* Splits `text` at each `{key}` so a template can render the surrounding
* prose as text and each placeholder as its own element.
*/
function splitPlaceholders(text, keys) {
	const pattern = new RegExp(`\\{(${keys.join("|")})\\}`, "g");
	const segments = [];
	let cursor = 0;
	for (const match of text.matchAll(pattern)) {
		if (match.index > cursor) segments.push({
			kind: "text",
			text: text.slice(cursor, match.index)
		});
		const key = keys.find((candidate) => candidate === match[1]);
		if (key !== void 0) segments.push({
			kind: "slot",
			key
		});
		cursor = match.index + match[0].length;
	}
	if (cursor < text.length) segments.push({
		kind: "text",
		text: text.slice(cursor)
	});
	return segments;
}
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutTermsNote.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$10 = { class: "m-0 text-center text-xs text-muted-foreground" };
var _hoisted_2$8 = ["href"];
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutTermsNote.vue
var CheckoutTermsNote_default = /* @__PURE__ */ defineComponent({
	__name: "CheckoutTermsNote",
	props: { copy: {} },
	setup(__props) {
		const LINKS = {
			terms: "https://comfy.org/terms-of-service/",
			privacy: "https://comfy.org/privacy-policy/"
		};
		const segments = computed(() => splitPlaceholders(__props.copy.agreement, ["terms", "privacy"]));
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("p", _hoisted_1$10, [createBaseVNode("span", null, [(openBlock(true), createElementBlock(Fragment, null, renderList(segments.value, (segment, index) => {
				return openBlock(), createElementBlock(Fragment, { key: index }, [segment.kind === "text" ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [createTextVNode(toDisplayString(segment.text), 1)], 64)) : (openBlock(), createElementBlock("a", {
					key: 1,
					href: LINKS[segment.key],
					target: "_blank",
					rel: "noopener noreferrer",
					class: "underline hover:text-foreground"
				}, toDisplayString(segment.key === "terms" ? __props.copy.terms : __props.copy.privacyPolicy), 9, _hoisted_2$8))], 64);
			}), 128))])]);
		};
	}
});
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutVerificationPrompt.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$9 = {
	role: "status",
	class: "m-0 text-sm text-muted-foreground"
};
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutVerificationPrompt.vue
var CheckoutVerificationPrompt_default = /* @__PURE__ */ defineComponent({
	__name: "CheckoutVerificationPrompt",
	props: {
		actionUrl: {},
		copy: {}
	},
	setup(__props) {
		/**
		* A pending 3DS verification is the only actionable step, so it leads the
		* footer and opens the bank's page in a new tab.
		*/
		function openVerification() {
			window.open(__props.actionUrl, "_blank", "noopener,noreferrer");
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock(Fragment, null, [createBaseVNode("p", _hoisted_1$9, toDisplayString(__props.copy.pendingVerificationDetail), 1), createVNode(CheckoutButton_default, {
				variant: "inverted",
				size: "lg",
				class: "w-full rounded-lg",
				onClick: openVerification
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(__props.copy.completeVerification), 1)]),
				_: 1
			})], 64);
		};
	}
});
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutSubscribeActions.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$8 = {
	key: 0,
	class: "flex flex-col gap-2"
};
var _hoisted_2$7 = {
	role: "alert",
	class: "rounded-lg border bg-secondary p-4 text-sm text-foreground"
};
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutSubscribeActions.vue
var CheckoutSubscribeActions_default = /* @__PURE__ */ defineComponent({
	__name: "CheckoutSubscribeActions",
	props: {
		payAction: {},
		copy: {},
		planName: {},
		previewData: {},
		publishableKey: {},
		themeKey: {},
		isLoading: { type: Boolean },
		payDisabled: { type: Boolean },
		verificationUrl: {},
		verificationPending: { type: Boolean },
		quoteIsCurrent: { type: Boolean },
		embeddedCheckoutEnabled: { type: Boolean },
		reconciliationOperationId: {},
		authenticationState: {},
		authenticationError: {}
	},
	emits: [
		"addCreditCard",
		"confirmPayment",
		"submittingChange",
		"paymentPhase"
	],
	setup(__props, { emit: __emit }) {
		/**
		* The new-subscription confirm's pay column: what an earlier attempt left to
		* read or finish, then the one way to pay `payAction` names, then the terms.
		*/
		const emit = __emit;
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock(Fragment, null, [
				createVNode(CheckoutPaymentNotices_default, {
					"embedded-checkout-enabled": __props.embeddedCheckoutEnabled,
					"reconciliation-operation-id": __props.reconciliationOperationId,
					"authentication-state": __props.authenticationState,
					"authentication-error": __props.authenticationError,
					copy: __props.copy
				}, null, 8, [
					"embedded-checkout-enabled",
					"reconciliation-operation-id",
					"authentication-state",
					"authentication-error",
					"copy"
				]),
				__props.payAction === "parked" ? (openBlock(), createElementBlock("div", _hoisted_1$8, [createBaseVNode("div", _hoisted_2$7, toDisplayString(__props.copy.parkedCheckoutDetail), 1), createVNode(CheckoutButton_default, {
					variant: "inverted",
					size: "lg",
					class: "w-full rounded-lg",
					loading: __props.isLoading,
					disabled: __props.payDisabled,
					onClick: _cache[0] || (_cache[0] = ($event) => emit("addCreditCard"))
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(__props.copy.completePayment), 1)]),
					_: 1
				}, 8, ["loading", "disabled"])])) : createCommentVNode("", true),
				__props.verificationUrl ? (openBlock(), createBlock(CheckoutVerificationPrompt_default, {
					key: 1,
					"action-url": __props.verificationUrl,
					copy: __props.copy
				}, null, 8, ["action-url", "copy"])) : createCommentVNode("", true),
				__props.payAction === "form" && __props.previewData ? (openBlock(), createBlock(CheckoutPaymentForm_default, {
					key: `${__props.previewData.quote_id}:${__props.previewData.quote_version}`,
					"publishable-key": __props.publishableKey,
					"amount-cents": __props.previewData.amount_due_cents ?? 0,
					currency: __props.previewData.currency ?? "",
					copy: __props.copy.payment,
					"submit-label": __props.copy.payAndSubscribe,
					"payment-method-configuration-id": __props.previewData.payment_method_configuration_id ?? "",
					"is-loading": __props.isLoading,
					"verification-pending": __props.verificationPending,
					"can-submit": __props.quoteIsCurrent,
					"theme-key": __props.themeKey,
					onSubmittingChange: _cache[1] || (_cache[1] = ($event) => emit("submittingChange", $event)),
					onConfirm: _cache[2] || (_cache[2] = (token, methodType) => emit("confirmPayment", token, methodType)),
					onPhase: _cache[3] || (_cache[3] = ($event) => emit("paymentPhase", $event))
				}, null, 8, [
					"publishable-key",
					"amount-cents",
					"currency",
					"copy",
					"submit-label",
					"payment-method-configuration-id",
					"is-loading",
					"verification-pending",
					"can-submit",
					"theme-key"
				])) : createCommentVNode("", true),
				__props.payAction === "pay" || __props.payAction === "subscribe" ? (openBlock(), createBlock(CheckoutButton_default, {
					key: 3,
					variant: __props.payAction === "pay" ? "inverted" : "tertiary",
					size: "lg",
					class: "w-full rounded-lg",
					loading: __props.isLoading,
					disabled: __props.payDisabled,
					onClick: _cache[4] || (_cache[4] = ($event) => emit("addCreditCard"))
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(__props.payAction === "pay" ? __props.copy.payAndSubscribe : __props.copy.subscribeToPlan(__props.planName)), 1)]),
					_: 1
				}, 8, [
					"variant",
					"loading",
					"disabled"
				])) : createCommentVNode("", true),
				createVNode(CheckoutTermsNote_default, {
					class: "mt-2",
					copy: __props.copy.terms
				}, null, 8, ["copy"])
			], 64);
		};
	}
});
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutSubscribeSummary.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$7 = { class: "flex flex-col gap-2" };
var _hoisted_2$6 = { class: "text-sm text-foreground" };
var _hoisted_3$6 = { class: "flex items-baseline gap-2 text-foreground" };
var _hoisted_4$6 = { class: "text-2xl font-semibold tabular-nums" };
var _hoisted_5$4 = { class: "text-base" };
var _hoisted_6$2 = { class: "text-muted-foreground" };
var _hoisted_7$2 = { class: "text-muted-foreground" };
var _hoisted_8$2 = { class: "flex items-center justify-between" };
var _hoisted_9$2 = { class: "text-foreground" };
var _hoisted_10$2 = { class: "flex items-center gap-1" };
var _hoisted_11$2 = { class: "font-bold text-foreground tabular-nums" };
var _hoisted_12$1 = { class: "flex items-center justify-between text-base text-foreground" };
var _hoisted_13 = { class: "font-bold tabular-nums" };
var _hoisted_14 = { class: "text-sm text-muted-foreground" };
var _hoisted_15 = {
	key: 1,
	class: "flex flex-col gap-2 pt-4 text-sm"
};
var _hoisted_16 = { class: "text-foreground" };
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutSubscribeSummary.vue
var CheckoutSubscribeSummary_default = /* @__PURE__ */ defineComponent({
	__name: "CheckoutSubscribeSummary",
	props: {
		plan: {},
		copy: {},
		locale: {},
		previewData: {},
		billingCycle: {},
		compact: {
			type: Boolean,
			default: false
		}
	},
	setup(__props) {
		/**
		* The new-subscription confirm's money block: the plan and its price, the
		* credits a period refills, today's charge with the renewal terms, and the
		* discounts the quote applied.
		*/
		const isYearly = computed(() => isYearlyCheckout(__props.previewData?.new_plan.duration, __props.billingCycle));
		const quotedPrice = computed(() => __props.plan.pricedByQuote ? __props.previewData?.new_plan : void 0);
		const displayPrice = computed(() => {
			if (quotedPrice.value) {
				const cents = quotedPrice.value.price_cents;
				return ((isYearly.value ? cents / 12 : cents) / 100).toFixed(0);
			}
			return formatNumber(isYearly.value ? __props.plan.monthlyPriceUsd.yearly : __props.plan.monthlyPriceUsd.monthly, __props.locale);
		});
		const billedLabel = computed(() => {
			if (!isYearly.value) return __props.copy.billedMonthly;
			const usd = quotedPrice.value ? quotedPrice.value.price_cents / 100 : __props.plan.yearlyChargeUsd ?? __props.plan.monthlyPriceUsd.yearly * 12;
			return __props.copy.billedYearly(`$${formatNumber(usd, __props.locale)}`);
		});
		const refillLabel = computed(() => isYearly.value ? __props.copy.eachYearCreditsRefill : __props.copy.eachMonthCreditsRefill);
		const refillCredits = computed(() => formatNumber(isYearly.value ? __props.plan.monthlyCredits * 12 : __props.plan.monthlyCredits, __props.locale));
		const totalDueToday = computed(() => __props.previewData ? formatAmountDueToday(__props.previewData, __props.locale) : "");
		const renewalTerms = computed(() => {
			if (!__props.previewData) return "";
			const amount = formatRenewalAmount(__props.previewData, __props.locale);
			if (!amount) return "";
			const renewsAt = resolveRenewalDate(__props.previewData);
			if (!renewsAt) return __props.copy.renewsAtAmount(amount);
			const date = new Date(renewsAt).toLocaleDateString(__props.locale, {
				month: "short",
				day: "numeric",
				year: "numeric",
				timeZone: "UTC"
			});
			return __props.copy.renewsAt(amount, date);
		});
		const discounts = computed(() => (__props.previewData?.discounts ?? []).map((discount) => ({
			key: `${discount.kind}:${discount.code}`,
			label: __props.copy.discount[discount.kind],
			name: discount.name || discount.code,
			amount: discount.amount_off_cents ? formatQuoteMoney(discount.amount_off_cents, __props.previewData?.currency, __props.locale) : ""
		})));
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock(Fragment, null, [
				createBaseVNode("div", _hoisted_1$7, [
					createBaseVNode("span", _hoisted_2$6, toDisplayString(__props.plan.name), 1),
					createBaseVNode("div", _hoisted_3$6, [createBaseVNode("span", _hoisted_4$6, " $" + toDisplayString(displayPrice.value), 1), createBaseVNode("span", _hoisted_5$4, toDisplayString(__props.copy.usdPerMonth), 1)]),
					createBaseVNode("span", _hoisted_6$2, toDisplayString(billedLabel.value), 1),
					createBaseVNode("span", _hoisted_7$2, toDisplayString(__props.copy.startingToday), 1)
				]),
				createBaseVNode("div", { class: normalizeClass(unref(cn)("flex flex-col gap-3 pt-16 pb-8", __props.compact && "xl:pt-6 xl:pb-4")) }, [createBaseVNode("div", _hoisted_8$2, [createBaseVNode("span", _hoisted_9$2, toDisplayString(refillLabel.value), 1), createBaseVNode("div", _hoisted_10$2, [_cache[0] || (_cache[0] = createBaseVNode("i", { class: "icon-[lucide--coins] size-4 shrink-0 bg-credit" }, null, -1)), createBaseVNode("span", _hoisted_11$2, toDisplayString(refillCredits.value), 1)])])], 2),
				totalDueToday.value ? (openBlock(), createElementBlock("div", {
					key: 0,
					class: normalizeClass(unref(cn)("flex flex-col gap-2 border-t border-border/50 pt-8", __props.compact && "xl:pt-6"))
				}, [createBaseVNode("div", _hoisted_12$1, [createBaseVNode("span", null, toDisplayString(__props.copy.totalDueToday), 1), createBaseVNode("span", _hoisted_13, toDisplayString(totalDueToday.value), 1)]), createBaseVNode("span", _hoisted_14, toDisplayString(renewalTerms.value), 1)], 2)) : createCommentVNode("", true),
				discounts.value.length ? (openBlock(), createElementBlock("div", _hoisted_15, [(openBlock(true), createElementBlock(Fragment, null, renderList(discounts.value, (discount) => {
					return openBlock(), createElementBlock("div", {
						key: discount.key,
						class: "flex items-center justify-between text-muted-foreground"
					}, [createBaseVNode("span", null, toDisplayString(discount.label), 1), createBaseVNode("span", _hoisted_16, [createTextVNode(toDisplayString(discount.name), 1), discount.amount ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [createTextVNode(" · −" + toDisplayString(discount.amount), 1)], 64)) : createCommentVNode("", true)])]);
				}), 128))])) : createCommentVNode("", true)
			], 64);
		};
	}
});
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutTitle.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$6 = ["id"];
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutTitle.vue
var CheckoutTitle_default = /* @__PURE__ */ defineComponent({
	__name: "CheckoutTitle",
	setup(__props) {
		const dialogRoot = injectDialogRootContext(null);
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("h2", { id: unref(dialogRoot)?.titleId }, [renderSlot(_ctx.$slots, "default")], 8, _hoisted_1$6);
		};
	}
});
//#endregion
//#region packages/account-ui/src/billing/checkout/checkoutRecovery.ts
/** A 3DS link is on offer unless the last attempt at it already failed. */
function isVerificationOffered({ actionUrl, authenticationState }) {
	return Boolean(actionUrl) && authenticationState !== "failed_retryable";
}
/**
* While an earlier payment still needs the customer (a verification to
* finish, a failed one to retry, or a charge awaiting reconciliation), the
* pay action stays disabled so a second charge cannot start beside it.
*/
function isVerificationRecoveryActive(state) {
	return isVerificationOffered(state) || state.embeddedCheckoutEnabled && (state.authenticationState === "requires_action" || state.authenticationState === "failed_retryable" || Boolean(state.reconciliationOperationId));
}
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutSubscribeConfirm.vue
var CheckoutSubscribeConfirm_default = /* @__PURE__ */ defineComponent({
	__name: "CheckoutSubscribeConfirm",
	props: /*@__PURE__*/ mergeModels({
		plan: {},
		copy: {},
		locale: {},
		publishableKey: {},
		themeKey: {},
		billingCycle: { default: "monthly" },
		isLoading: {
			type: Boolean,
			default: false
		},
		previewData: { default: null },
		actionUrl: { default: null },
		authenticationState: { default: null },
		authenticationError: { default: null },
		reconciliationOperationId: { default: null },
		parkedCheckoutRecovery: {
			type: Boolean,
			default: false
		},
		usePaymentElement: {
			type: Boolean,
			default: false
		},
		savedMethods: { default: null },
		quoteIsCurrent: {
			type: Boolean,
			default: false
		},
		isApplyingPromotionCode: {
			type: Boolean,
			default: false
		},
		embeddedCheckoutEnabled: {
			type: Boolean,
			default: false
		},
		summaryReplaced: {
			type: Boolean,
			default: false
		}
	}, {
		"selectedSavedMethodId": { default: null },
		"selectedSavedMethodIdModifiers": {}
	}),
	emits: /*@__PURE__*/ mergeModels([
		"addCreditCard",
		"confirmPayment",
		"back",
		"changePaymentMethod",
		"applyPromotionCode",
		"invalidateQuote",
		"paymentPhase"
	], ["update:selectedSavedMethodId"]),
	setup(__props, { emit: __emit }) {
		/**
		* The confirm step of a new subscription: the plan and today's charge on one
		* side, and the way to pay on the other — the card form, the saved methods
		* that stand in for it, or a hosted continuation the host opens. A host
		* following a payment it did not quote here replaces the plan and charge
		* through the `summary` slot and `summaryReplaced`.
		*/
		const emit = __emit;
		const selectedSavedMethodId = useModel(__props, "selectedSavedMethodId");
		const captureMode = computed(() => __props.usePaymentElement && !__props.savedMethods?.length);
		const showSavedMethods = computed(() => __props.embeddedCheckoutEnabled && Boolean(__props.savedMethods?.length));
		const layout = computed(() => {
			const split = captureMode.value;
			return {
				root: cn("mx-auto flex h-full min-h-0 max-w-[400px] flex-col items-stretch justify-between overflow-y-auto text-sm motion-safe:animate-in motion-safe:duration-300 motion-safe:fade-in motion-safe:slide-in-from-bottom-2", split && "xl:min-h-0 xl:w-full xl:max-w-none xl:flex-1 xl:flex-row xl:items-stretch xl:gap-0 xl:overflow-visible"),
				summary: cn(split && "xl:w-[42%] xl:shrink-0 xl:border-r xl:border-border/50 xl:bg-background xl:px-12 xl:py-10", split && "max-xl:-mx-4 max-xl:-mt-6 max-xl:rounded-t-2xl max-xl:bg-background max-xl:p-6"),
				header: cn("mb-8 flex items-center gap-3", split && "xl:mb-10"),
				title: cn("m-0 flex-1 text-center text-xl font-semibold text-foreground lg:text-2xl", split && "xl:text-left xl:text-base xl:font-medium xl:text-muted-foreground"),
				footer: cn("flex flex-col gap-2 pt-8 pb-4", split && "xl:min-h-0 xl:min-w-0 xl:flex-1 xl:px-16 xl:py-10", split && "max-xl:px-2")
			};
		});
		const amountDueCents = computed(() => __props.previewData?.amount_due_cents ?? 0);
		const quoteReady = computed(() => amountDueCents.value > 0 && Boolean(__props.previewData?.currency) && Boolean(__props.previewData?.quote_id) && __props.previewData?.quote_version !== void 0);
		const recoveryState = computed(() => ({
			actionUrl: __props.actionUrl,
			authenticationState: __props.authenticationState,
			reconciliationOperationId: __props.reconciliationOperationId,
			embeddedCheckoutEnabled: __props.embeddedCheckoutEnabled
		}));
		const verificationOffered = computed(() => isVerificationOffered(recoveryState.value));
		const verificationRecoveryActive = computed(() => isVerificationRecoveryActive(recoveryState.value));
		const quoteIsUsable = computed(() => !__props.embeddedCheckoutEnabled || __props.quoteIsCurrent);
		const stripeSubmissionPending = ref(false);
		const interactionLocked = computed(() => __props.isLoading || __props.isApplyingPromotionCode || stripeSubmissionPending.value);
		const payAction = computed(() => {
			if (__props.parkedCheckoutRecovery) return "parked";
			if (captureMode.value) return quoteReady.value ? "form" : "pay";
			return __props.savedMethods?.length ? "pay" : "subscribe";
		});
		const payDisabled = computed(() => interactionLocked.value || !quoteIsUsable.value || verificationRecoveryActive.value);
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", { class: normalizeClass(layout.value.root) }, [createBaseVNode("div", { class: normalizeClass(layout.value.summary) }, [
				createBaseVNode("div", { class: normalizeClass(layout.value.header) }, [createVNode(CheckoutButton_default, {
					size: "icon",
					variant: "muted-textonly",
					class: "shrink-0 rounded-full",
					"aria-label": __props.copy.back,
					disabled: interactionLocked.value,
					onClick: _cache[0] || (_cache[0] = ($event) => emit("back"))
				}, {
					default: withCtx(() => [..._cache[9] || (_cache[9] = [createBaseVNode("i", { class: "pi pi-arrow-left text-base" }, null, -1)])]),
					_: 1
				}, 8, ["aria-label", "disabled"]), createVNode(CheckoutTitle_default, { class: normalizeClass(layout.value.title) }, {
					default: withCtx(() => [createTextVNode(toDisplayString(__props.copy.confirmPayment), 1)]),
					_: 1
				}, 8, ["class"])], 2),
				__props.summaryReplaced ? renderSlot(_ctx.$slots, "summary", {}, void 0, void 0, 0) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [createVNode(CheckoutSubscribeSummary_default, {
					plan: __props.plan,
					copy: __props.copy,
					locale: __props.locale,
					"preview-data": __props.previewData,
					"billing-cycle": __props.billingCycle,
					compact: __props.usePaymentElement
				}, null, 8, [
					"plan",
					"copy",
					"locale",
					"preview-data",
					"billing-cycle",
					"compact"
				]), __props.embeddedCheckoutEnabled ? (openBlock(), createBlock(CheckoutPromotionCode_default, {
					key: 0,
					"applied-code": __props.previewData?.promotion_code,
					disabled: interactionLocked.value,
					copy: __props.copy,
					onApply: _cache[1] || (_cache[1] = ($event) => emit("applyPromotionCode", $event)),
					onInvalidate: _cache[2] || (_cache[2] = ($event) => emit("invalidateQuote"))
				}, null, 8, [
					"applied-code",
					"disabled",
					"copy"
				])) : createCommentVNode("", true)], 64)),
				showSavedMethods.value && __props.savedMethods ? (openBlock(), createBlock(CheckoutSavedMethods_default, {
					key: 2,
					"selected-method-id": selectedSavedMethodId.value,
					"onUpdate:selectedMethodId": _cache[3] || (_cache[3] = ($event) => selectedSavedMethodId.value = $event),
					methods: __props.savedMethods,
					copy: __props.copy.savedMethod,
					onChangePaymentMethod: _cache[4] || (_cache[4] = ($event) => emit("changePaymentMethod"))
				}, null, 8, [
					"selected-method-id",
					"methods",
					"copy"
				])) : createCommentVNode("", true)
			], 2), createBaseVNode("div", { class: normalizeClass(layout.value.footer) }, [createVNode(CheckoutSubscribeActions_default, {
				"pay-action": payAction.value,
				copy: __props.copy,
				"plan-name": __props.plan.name,
				"preview-data": __props.previewData,
				"publishable-key": __props.publishableKey,
				"theme-key": __props.themeKey,
				"is-loading": __props.isLoading,
				"pay-disabled": payDisabled.value,
				"verification-url": verificationOffered.value ? __props.actionUrl : null,
				"verification-pending": Boolean(__props.actionUrl) || verificationRecoveryActive.value,
				"quote-is-current": __props.quoteIsCurrent,
				"embedded-checkout-enabled": __props.embeddedCheckoutEnabled,
				"reconciliation-operation-id": __props.reconciliationOperationId,
				"authentication-state": __props.authenticationState,
				"authentication-error": __props.authenticationError,
				onAddCreditCard: _cache[5] || (_cache[5] = ($event) => emit("addCreditCard")),
				onConfirmPayment: _cache[6] || (_cache[6] = (token, type) => emit("confirmPayment", token, type)),
				onSubmittingChange: _cache[7] || (_cache[7] = ($event) => stripeSubmissionPending.value = $event),
				onPaymentPhase: _cache[8] || (_cache[8] = ($event) => emit("paymentPhase", $event))
			}, null, 8, [
				"pay-action",
				"copy",
				"plan-name",
				"preview-data",
				"publishable-key",
				"theme-key",
				"is-loading",
				"pay-disabled",
				"verification-url",
				"verification-pending",
				"quote-is-current",
				"embedded-checkout-enabled",
				"reconciliation-operation-id",
				"authentication-state",
				"authentication-error"
			])], 2)], 2);
		};
	}
});
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutSuccess.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$5 = { class: "mx-auto flex h-full min-h-0 max-w-[400px] flex-col justify-between overflow-y-auto text-sm motion-safe:animate-in motion-safe:duration-300 motion-safe:fade-in motion-safe:slide-in-from-bottom-2" };
var _hoisted_2$5 = { class: "flex flex-col items-center gap-4 pt-8" };
var _hoisted_3$5 = { class: "m-0 text-center text-muted-foreground" };
var _hoisted_4$5 = { class: "text-foreground" };
var _hoisted_5$3 = { class: "flex items-baseline gap-1 text-foreground" };
var _hoisted_6$1 = { class: "text-2xl font-semibold tabular-nums" };
var _hoisted_7$1 = { class: "flex items-center gap-1 text-muted-foreground" };
var _hoisted_8$1 = { class: "tabular-nums" };
var _hoisted_9$1 = {
	key: 0,
	class: "m-0 text-center text-muted-foreground tabular-nums"
};
var _hoisted_10$1 = { class: "font-medium text-foreground" };
var _hoisted_11$1 = { class: "flex flex-col gap-2 pt-8 pb-4" };
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutSuccess.vue
var CheckoutSuccess_default = /* @__PURE__ */ defineComponent({
	__name: "CheckoutSuccess",
	props: {
		plan: {},
		copy: {},
		locale: {},
		previewData: { default: null },
		billingCycle: { default: "monthly" },
		darkSurface: {
			type: Boolean,
			default: false
		},
		promoApplied: { default: null },
		closeDemoted: {
			type: Boolean,
			default: false
		},
		planReplaced: {
			type: Boolean,
			default: false
		}
	},
	emits: ["close"],
	setup(__props, { emit: __emit }) {
		/**
		* The step after a successful subscribe: what the customer now has. A host
		* adds its own follow-up (the cloud app's team invite) through the
		* `details` and `actions` slots, demoting Close when it leads with another
		* action, and names a plan it did not quote here through the `plan` slot and
		* `planReplaced`.
		*/
		const emit = __emit;
		const isYearly = computed(() => isYearlyCheckout(__props.previewData?.new_plan?.duration, __props.billingCycle));
		const displayPrice = computed(() => {
			if (__props.previewData?.new_plan) {
				const amountUsd = __props.previewData.new_plan.price_cents / 100;
				return !__props.plan.pricedByQuote && isYearly.value && !Number.isInteger(amountUsd) ? amountUsd.toFixed(2) : amountUsd.toFixed(0);
			}
			if (__props.plan.pricedByQuote) return "0";
			return String(isYearly.value ? __props.plan.yearlyChargeUsd ?? __props.plan.monthlyPriceUsd.yearly * 12 : __props.plan.monthlyPriceUsd.monthly);
		});
		const displayCredits = computed(() => formatNumber(isYearly.value ? __props.plan.monthlyCredits * 12 : __props.plan.monthlyCredits, __props.locale));
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$5, [createBaseVNode("div", _hoisted_2$5, [
				_cache[2] || (_cache[2] = createBaseVNode("i", { class: "pi pi-check-circle text-5xl text-success" }, null, -1)),
				createVNode(CheckoutTitle_default, { class: "m-0 text-center text-xl font-semibold text-foreground lg:text-2xl" }, {
					default: withCtx(() => [createTextVNode(toDisplayString(__props.copy.allSet), 1)]),
					_: 1
				}),
				createBaseVNode("p", _hoisted_3$5, toDisplayString(__props.copy.planUpdated) + " " + toDisplayString(__props.copy.receiptEmailed), 1),
				__props.planReplaced ? renderSlot(_ctx.$slots, "plan", {}, void 0, void 0, 0) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [createBaseVNode("div", { class: normalizeClass(unref(cn)("mt-4 flex w-full flex-col gap-1 rounded-xl border bg-background p-4", __props.darkSurface && "border-none bg-secondary")) }, [
					createBaseVNode("span", _hoisted_4$5, toDisplayString(__props.plan.name), 1),
					createBaseVNode("div", _hoisted_5$3, [createBaseVNode("span", _hoisted_6$1, " $" + toDisplayString(displayPrice.value), 1), createBaseVNode("span", null, toDisplayString(isYearly.value ? __props.copy.usdPerYear : __props.copy.usdPerMonth), 1)]),
					createBaseVNode("div", _hoisted_7$1, [_cache[1] || (_cache[1] = createBaseVNode("i", { class: "icon-[lucide--coins] size-4 shrink-0 bg-credit" }, null, -1)), createBaseVNode("span", _hoisted_8$1, toDisplayString(displayCredits.value) + " " + toDisplayString(isYearly.value ? __props.copy.perYear : __props.copy.perMonth), 1)])
				], 2), __props.promoApplied ? (openBlock(), createElementBlock("p", _hoisted_9$1, [createBaseVNode("span", _hoisted_10$1, toDisplayString(__props.copy.promoApplied(__props.promoApplied.code)), 1), createTextVNode(" " + toDisplayString(__props.copy.promoRenews(__props.promoApplied.renewalAmount, __props.promoApplied.renewalDate)), 1)])) : createCommentVNode("", true)], 64)),
				renderSlot(_ctx.$slots, "details")
			]), createBaseVNode("div", _hoisted_11$1, [renderSlot(_ctx.$slots, "actions"), createVNode(CheckoutButton_default, {
				variant: __props.closeDemoted ? "muted-textonly" : "secondary",
				size: "lg",
				class: "w-full rounded-lg",
				onClick: _cache[0] || (_cache[0] = ($event) => emit("close"))
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(__props.copy.close), 1)]),
				_: 1
			}, 8, ["variant"])])]);
		};
	}
});
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutReactivationBanner.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$4 = { class: "mb-6 flex gap-3 rounded-2xl border border-warning bg-warning/20 p-4" };
var _hoisted_2$4 = { class: "flex flex-col gap-2 text-muted-foreground" };
var _hoisted_3$4 = { class: "m-0 font-bold text-foreground" };
var _hoisted_4$4 = { class: "m-0" };
var _hoisted_5$2 = {
	key: 0,
	class: "flex items-center gap-2 pt-1"
};
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutReactivationBanner.vue
var CheckoutReactivationBanner_default = /* @__PURE__ */ defineComponent({
	__name: "CheckoutReactivationBanner",
	props: /*@__PURE__*/ mergeModels({
		title: {},
		segments: {},
		checkboxLabel: {}
	}, {
		"confirmed": {
			type: Boolean,
			required: true
		},
		"confirmedModifiers": {}
	}),
	emits: ["update:confirmed"],
	setup(__props) {
		/**
		* The plan-change confirm's disclosure that the change reactivates a
		* subscription set to end. A charge above the current monthly price is
		* emphasised and has to be acknowledged (`checkboxLabel` set).
		*/
		const confirmed = useModel(__props, "confirmed");
		const amountClass = computed(() => cn("font-bold text-foreground", __props.checkboxLabel !== null && "text-base font-extrabold"));
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$4, [_cache[1] || (_cache[1] = createBaseVNode("div", { class: "flex size-8 shrink-0 items-center justify-center rounded-full text-warning" }, [createBaseVNode("i", { class: "pi pi-info-circle" })], -1)), createBaseVNode("div", _hoisted_2$4, [
				createBaseVNode("p", _hoisted_3$4, toDisplayString(__props.title), 1),
				createBaseVNode("p", _hoisted_4$4, [createBaseVNode("span", null, [(openBlock(true), createElementBlock(Fragment, null, renderList(__props.segments, (segment, index) => {
					return openBlock(), createElementBlock(Fragment, { key: index }, [segment.emphasis ? (openBlock(), createElementBlock("span", {
						key: 0,
						class: normalizeClass(amountClass.value)
					}, toDisplayString(segment.text), 3)) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [createTextVNode(toDisplayString(segment.text), 1)], 64))], 64);
				}), 128))])]),
				__props.checkboxLabel ? (openBlock(), createElementBlock("label", _hoisted_5$2, [withDirectives(createBaseVNode("input", {
					"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => confirmed.value = $event),
					type: "checkbox",
					class: "size-4 rounded-sm"
				}, null, 512), [[vModelCheckbox, confirmed.value]]), createTextVNode(" " + toDisplayString(__props.checkboxLabel), 1)])) : createCommentVNode("", true)
			])]);
		};
	}
});
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutTransitionSummary.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$3 = { class: "flex flex-col gap-2" };
var _hoisted_2$3 = { class: "font-semibold text-foreground" };
var _hoisted_3$3 = { class: "flex items-baseline gap-2 text-foreground" };
var _hoisted_4$3 = { class: "text-2xl font-semibold tabular-nums" };
var _hoisted_5$1 = { class: "text-base" };
var _hoisted_6 = { class: "flex flex-col gap-2 pt-10" };
var _hoisted_7 = {
	key: 0,
	class: "text-xs font-semibold tracking-wide text-muted-foreground uppercase"
};
var _hoisted_8 = { class: "flex items-center justify-between" };
var _hoisted_9 = { class: "text-foreground" };
var _hoisted_10 = { class: "flex items-center gap-1" };
var _hoisted_11 = { class: "font-bold text-foreground tabular-nums" };
var _hoisted_12 = {
	key: 1,
	class: "text-muted-foreground"
};
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutTransitionSummary.vue
var CheckoutTransitionSummary_default = /* @__PURE__ */ defineComponent({
	__name: "CheckoutTransitionSummary",
	props: {
		planName: {},
		heroPrice: {},
		usdPerMonth: {},
		details: {},
		heading: { default: "" },
		refillLabel: {},
		refillCredits: {},
		note: { default: "" }
	},
	setup(__props) {
		/**
		* The plan-change confirm's plan block: the plan switched to, when it takes
		* effect, and the credits it refills — with the "after that" heading a
		* scheduled change carries.
		*/
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock(Fragment, null, [createBaseVNode("div", _hoisted_1$3, [
				createBaseVNode("span", _hoisted_2$3, toDisplayString(__props.planName), 1),
				createBaseVNode("div", _hoisted_3$3, [createBaseVNode("span", _hoisted_4$3, " $" + toDisplayString(__props.heroPrice), 1), createBaseVNode("span", _hoisted_5$1, toDisplayString(__props.usdPerMonth), 1)]),
				(openBlock(true), createElementBlock(Fragment, null, renderList(__props.details, (line) => {
					return openBlock(), createElementBlock("span", {
						key: line,
						class: "text-muted-foreground"
					}, toDisplayString(line), 1);
				}), 128))
			]), createBaseVNode("div", _hoisted_6, [
				__props.heading ? (openBlock(), createElementBlock("span", _hoisted_7, toDisplayString(__props.heading), 1)) : createCommentVNode("", true),
				createBaseVNode("div", _hoisted_8, [createBaseVNode("span", _hoisted_9, toDisplayString(__props.refillLabel), 1), createBaseVNode("div", _hoisted_10, [_cache[0] || (_cache[0] = createBaseVNode("i", { class: "icon-[lucide--coins] size-4 shrink-0 bg-credit" }, null, -1)), createBaseVNode("span", _hoisted_11, toDisplayString(__props.refillCredits), 1)])]),
				__props.note ? (openBlock(), createElementBlock("span", _hoisted_12, toDisplayString(__props.note), 1)) : createCommentVNode("", true)
			])], 64);
		};
	}
});
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutTransitionTotal.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$2 = { class: "flex items-center justify-between text-muted-foreground" };
var _hoisted_2$2 = { class: "text-foreground" };
var _hoisted_3$2 = { class: "flex items-center justify-between text-base text-foreground" };
var _hoisted_4$2 = { class: "font-bold tabular-nums" };
var _hoisted_5 = { class: "text-muted-foreground" };
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutTransitionTotal.vue
var CheckoutTransitionTotal_default = /* @__PURE__ */ defineComponent({
	__name: "CheckoutTransitionTotal",
	props: {
		discounts: {},
		discountComposition: {},
		totalDueToday: {},
		amountDueToday: {},
		renewalTerms: {},
		scheduled: {
			type: Boolean,
			default: false
		}
	},
	setup(__props) {
		/**
		* The plan-change confirm's charge block: the discounts an immediate change
		* applies, today's total, and the renewal terms.
		*/
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", { class: normalizeClass(unref(cn)("flex flex-col gap-2 border-t border-border/50 pt-6", __props.scheduled && "mt-10")) }, [
				__props.discounts.length ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [createBaseVNode("div", _hoisted_1$2, [createBaseVNode("span", null, toDisplayString(__props.discountComposition), 1)]), (openBlock(true), createElementBlock(Fragment, null, renderList(__props.discounts, (discount) => {
					return openBlock(), createElementBlock("div", {
						key: discount.key,
						class: "flex items-center justify-between text-muted-foreground"
					}, [createBaseVNode("span", null, toDisplayString(discount.label), 1), createBaseVNode("span", _hoisted_2$2, [createTextVNode(toDisplayString(discount.name), 1), discount.amount ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [createTextVNode(" · −" + toDisplayString(discount.amount), 1)], 64)) : createCommentVNode("", true)])]);
				}), 128))], 64)) : createCommentVNode("", true),
				createBaseVNode("div", _hoisted_3$2, [createBaseVNode("span", null, toDisplayString(__props.totalDueToday), 1), createBaseVNode("span", _hoisted_4$2, toDisplayString(__props.amountDueToday), 1)]),
				createBaseVNode("span", _hoisted_5, toDisplayString(__props.renewalTerms), 1)
			], 2);
		};
	}
});
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutTransitionConfirm.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$1 = { class: "mx-auto flex h-full min-h-0 max-w-[400px] flex-col justify-between overflow-y-auto text-sm motion-safe:animate-in motion-safe:duration-300 motion-safe:fade-in motion-safe:slide-in-from-bottom-2" };
var _hoisted_2$1 = { class: "mb-8 flex items-center gap-3" };
var _hoisted_3$1 = { class: "flex flex-col gap-2 pt-8 pb-4" };
var _hoisted_4$1 = {
	key: 0,
	role: "alert",
	class: "m-0 text-destructive"
};
//#endregion
//#region packages/account-ui/src/billing/checkout/CheckoutTransitionConfirm.vue
var CheckoutTransitionConfirm_default = /* @__PURE__ */ defineComponent({
	__name: "CheckoutTransitionConfirm",
	props: {
		previewData: {},
		plan: {},
		currentPlanName: {},
		copy: {},
		locale: {},
		subscriptionLoaded: { type: Boolean },
		subscriptionCancelled: {
			type: Boolean,
			default: false
		},
		subscriptionEndDate: { default: null },
		isLoading: {
			type: Boolean,
			default: false
		},
		actionUrl: { default: null },
		forceReactivation: {
			type: Boolean,
			default: false
		},
		authenticationState: { default: null },
		authenticationError: { default: null },
		reconciliationOperationId: { default: null },
		quoteIsCurrent: {
			type: Boolean,
			default: false
		},
		isApplyingPromotionCode: {
			type: Boolean,
			default: false
		},
		embeddedCheckoutEnabled: {
			type: Boolean,
			default: false
		},
		summaryReplaced: {
			type: Boolean,
			default: false
		},
		paymentCancelable: {
			type: Boolean,
			default: false
		},
		cancelingPayment: {
			type: Boolean,
			default: false
		},
		cancelPaymentError: { default: null }
	},
	emits: [
		"confirm",
		"back",
		"applyPromotionCode",
		"invalidateQuote",
		"cancelPayment"
	],
	setup(__props, { emit: __emit }) {
		/**
		* The confirm step of a change to an existing subscription: what it switches
		* to and when, what is charged today, and — for a subscription set to end —
		* the reactivation the change implies, which a large enough charge has to be
		* acknowledged before the confirm unlocks. A host following a payment it did
		* not quote here replaces the plan and charge through the `summary` slot and
		* `summaryReplaced`.
		*/
		const emit = __emit;
		const recoveryState = computed(() => ({
			actionUrl: __props.actionUrl,
			authenticationState: __props.authenticationState,
			reconciliationOperationId: __props.reconciliationOperationId,
			embeddedCheckoutEnabled: __props.embeddedCheckoutEnabled
		}));
		const verificationUrl = computed(() => isVerificationOffered(recoveryState.value) ? __props.actionUrl : null);
		const verificationRecoveryActive = computed(() => isVerificationRecoveryActive(recoveryState.value));
		const quoteIsUsable = computed(() => !__props.embeddedCheckoutEnabled || __props.quoteIsCurrent);
		const interactionLocked = computed(() => __props.isLoading || __props.isApplyingPromotionCode);
		function formatDate(date) {
			return new Intl.DateTimeFormat("en-US", {
				month: "short",
				day: "numeric",
				year: "numeric",
				timeZone: "UTC"
			}).format(typeof date === "string" ? new Date(date) : date);
		}
		const isImmediate = computed(() => __props.previewData.is_immediate);
		const newIsYearly = computed(() => isAnnualDuration(__props.previewData.new_plan.duration));
		const currentIsYearly = computed(() => isAnnualDuration(__props.previewData.current_plan?.duration));
		const isCancelled = computed(() => __props.forceReactivation || !__props.embeddedCheckoutEnabled && __props.subscriptionCancelled);
		const reactivationVariant = computed(() => {
			if (!isCancelled.value) return null;
			switch (__props.previewData.transition_type) {
				case "upgrade": return "upgrade";
				case "downgrade": return "downgrade";
				case "duration_change": return "duration_change";
				default: return null;
			}
		});
		const cancelAt = computed(() => __props.subscriptionEndDate ?? __props.previewData.current_plan?.period_end);
		const isReactivating = computed(() => isCancelled.value && reactivationVariant.value !== null && !!cancelAt.value && !!__props.previewData.current_plan);
		const currentMonthlyPriceCents = computed(() => {
			const current = __props.previewData.current_plan;
			if (!current) return 0;
			const totalCents = current.seat_summary.total_cost_cents;
			return currentIsYearly.value ? totalCents / 12 : totalCents;
		});
		const chargeCents = computed(() => __props.previewData.amount_due_cents ?? __props.previewData.cost_today_cents);
		const exceedsMonthlyThreshold = computed(() => isReactivating.value && reactivationVariant.value !== "downgrade" && chargeCents.value > currentMonthlyPriceCents.value);
		const chargeDisplay = computed(() => `$${formatUsdFromCents(chargeCents.value)}`);
		const reactivationConfirmed = ref(false);
		watch(() => __props.previewData, () => {
			reactivationConfirmed.value = false;
		});
		const confirmDisabled = computed(() => !__props.subscriptionLoaded || exceedsMonthlyThreshold.value && !reactivationConfirmed.value);
		const confirmBlocked = computed(() => confirmDisabled.value || !quoteIsUsable.value || verificationRecoveryActive.value);
		const confirmReactivation = computed(() => isReactivating.value && (!exceedsMonthlyThreshold.value || reactivationConfirmed.value));
		const bannerTitle = computed(() => reactivationVariant.value === "duration_change" && newIsYearly.value ? __props.copy.reactivation.titleAnnual : __props.copy.reactivation.title);
		const bannerBody = computed(() => {
			const bodies = nextPaymentDate.value === void 0 ? __props.copy.reactivation.withoutRenewalDate : __props.copy.reactivation;
			switch (reactivationVariant.value) {
				case "upgrade": return bodies.upgradeBody;
				case "downgrade": return bodies.downgradeBody;
				case "duration_change": return newIsYearly.value ? bodies.durationChangeBody : bodies.durationChangeBodyMonthly;
				default: return "";
			}
		});
		const bannerSegments = computed(() => splitPlaceholders(bannerBody.value, [
			"plan",
			"date",
			"newPlan",
			"nextDate",
			"amount"
		]).map((segment) => {
			if (segment.kind === "text") return {
				text: segment.text,
				emphasis: false
			};
			if (segment.key === "amount") return {
				text: chargeDisplay.value,
				emphasis: true
			};
			return {
				text: bannerValues.value[segment.key],
				emphasis: false
			};
		}));
		const newMonthlyUsd = computed(() => {
			const cents = __props.previewData.new_plan.price_cents;
			return (newIsYearly.value ? cents / 12 : cents) / 100;
		});
		const heroPrice = computed(() => newMonthlyUsd.value.toFixed(0));
		const annualTotalFormatted = computed(() => `$${formatNumber(__props.previewData.new_plan.price_cents / 100, __props.locale)}`);
		const refillCredits = computed(() => formatNumber(newIsYearly.value ? __props.plan.monthlyCredits * 12 : __props.plan.monthlyCredits, __props.locale));
		const refillLabel = computed(() => {
			if (isImmediate.value) return newIsYearly.value ? __props.copy.creditsYoullGetToday : __props.copy.eachMonthCreditsRefill;
			return newIsYearly.value ? __props.copy.eachYearCreditsRefill : __props.copy.creditsRefillMonthlyTo;
		});
		const billedLabel = computed(() => newIsYearly.value ? __props.copy.billedYearly(annualTotalFormatted.value) : __props.copy.billedMonthly);
		const planDetails = computed(() => isImmediate.value ? [billedLabel.value, __props.copy.switchesToday] : [__props.copy.startsOn(effectiveDateLabel.value)]);
		const refillNote = computed(() => {
			if (isImmediate.value) return newIsYearly.value ? __props.copy.refillReplacesNote : "";
			return newIsYearly.value ? __props.copy.billedYearly(annualTotalFormatted.value) : __props.copy.billedEachMonth(`$${formatNumber(newMonthlyUsd.value, __props.locale)}`);
		});
		const discounts = computed(() => isImmediate.value ? (__props.previewData.discounts ?? []).map((discount) => ({
			key: `${discount.kind}:${discount.code}`,
			label: __props.copy.discount[discount.kind],
			name: discount.name || discount.code,
			amount: discount.amount_off_cents ? `$${formatUsdFromCents(discount.amount_off_cents)}` : ""
		})) : []);
		const effectiveDateLabel = computed(() => formatDate(__props.previewData.effective_at));
		const nextPaymentDate = computed(() => {
			const renewsAt = resolveRenewalDate(__props.previewData);
			return renewsAt ? formatDate(renewsAt) : void 0;
		});
		const bannerValues = computed(() => ({
			plan: __props.currentPlanName,
			date: cancelAt.value ? formatDate(cancelAt.value) : "",
			newPlan: __props.plan.name,
			nextDate: nextPaymentDate.value ?? ""
		}));
		const confirmTitle = computed(() => isImmediate.value ? __props.copy.confirmUpgradeTitle : __props.copy.confirmChangeTitle);
		const confirmCta = computed(() => {
			if (!isReactivating.value) return isImmediate.value ? __props.copy.confirmUpgradeCta : __props.copy.confirmChange;
			if (reactivationVariant.value === "downgrade") return __props.copy.reactivation.confirmButton;
			return __props.copy.reactivation.confirmButtonWithCharge(chargeDisplay.value);
		});
		const amountDueToday = computed(() => formatAmountDueToday(__props.previewData, __props.locale) || __props.copy.quoteUnavailable);
		const renewalTerms = computed(() => {
			const amount = formatRenewalAmount(__props.previewData, __props.locale);
			if (!amount) return __props.copy.quoteUnavailable;
			const renewsAt = resolveRenewalDate(__props.previewData);
			if (!renewsAt) return __props.copy.renewsAtAmount(amount);
			return __props.copy.renewsAt(amount, formatDate(renewsAt));
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$1, [createBaseVNode("div", null, [
				createBaseVNode("div", _hoisted_2$1, [
					createVNode(CheckoutButton_default, {
						size: "icon",
						variant: "muted-textonly",
						class: "shrink-0 rounded-full",
						"aria-label": __props.copy.back,
						disabled: interactionLocked.value,
						onClick: _cache[0] || (_cache[0] = ($event) => emit("back"))
					}, {
						default: withCtx(() => [..._cache[6] || (_cache[6] = [createBaseVNode("i", { class: "pi pi-arrow-left text-base" }, null, -1)])]),
						_: 1
					}, 8, ["aria-label", "disabled"]),
					createVNode(CheckoutTitle_default, { class: "m-0 flex-1 text-center text-xl font-semibold text-foreground lg:text-2xl" }, {
						default: withCtx(() => [createTextVNode(toDisplayString(confirmTitle.value), 1)]),
						_: 1
					}),
					_cache[7] || (_cache[7] = createBaseVNode("div", {
						class: "size-8 shrink-0",
						"aria-hidden": "true"
					}, null, -1))
				]),
				isReactivating.value ? (openBlock(), createBlock(CheckoutReactivationBanner_default, {
					key: 0,
					confirmed: reactivationConfirmed.value,
					"onUpdate:confirmed": _cache[1] || (_cache[1] = ($event) => reactivationConfirmed.value = $event),
					title: bannerTitle.value,
					segments: bannerSegments.value,
					"checkbox-label": exceedsMonthlyThreshold.value ? __props.copy.reactivation.checkboxLabel(chargeDisplay.value) : null
				}, null, 8, [
					"confirmed",
					"title",
					"segments",
					"checkbox-label"
				])) : createCommentVNode("", true),
				__props.summaryReplaced ? renderSlot(_ctx.$slots, "summary", {}, void 0, void 0, 1) : (openBlock(), createElementBlock(Fragment, { key: 2 }, [
					createVNode(CheckoutTransitionSummary_default, {
						"plan-name": __props.plan.name,
						"hero-price": heroPrice.value,
						"usd-per-month": __props.copy.usdPerMonth,
						details: planDetails.value,
						heading: isImmediate.value ? "" : __props.copy.afterThat,
						"refill-label": refillLabel.value,
						"refill-credits": refillCredits.value,
						note: refillNote.value
					}, null, 8, [
						"plan-name",
						"hero-price",
						"usd-per-month",
						"details",
						"heading",
						"refill-label",
						"refill-credits",
						"note"
					]),
					createVNode(CheckoutTransitionTotal_default, {
						discounts: discounts.value,
						"discount-composition": __props.copy.discountComposition,
						"total-due-today": __props.copy.totalDueToday,
						"amount-due-today": amountDueToday.value,
						"renewal-terms": renewalTerms.value,
						scheduled: !isImmediate.value
					}, null, 8, [
						"discounts",
						"discount-composition",
						"total-due-today",
						"amount-due-today",
						"renewal-terms",
						"scheduled"
					]),
					__props.embeddedCheckoutEnabled ? (openBlock(), createBlock(CheckoutPromotionCode_default, {
						key: 0,
						"applied-code": __props.previewData.promotion_code,
						disabled: interactionLocked.value,
						copy: __props.copy,
						onApply: _cache[2] || (_cache[2] = ($event) => emit("applyPromotionCode", $event)),
						onInvalidate: _cache[3] || (_cache[3] = ($event) => emit("invalidateQuote"))
					}, null, 8, [
						"applied-code",
						"disabled",
						"copy"
					])) : createCommentVNode("", true)
				], 64))
			]), createBaseVNode("div", _hoisted_3$1, [
				createVNode(CheckoutPaymentNotices_default, {
					"embedded-checkout-enabled": __props.embeddedCheckoutEnabled,
					"reconciliation-operation-id": __props.reconciliationOperationId,
					"authentication-state": __props.authenticationState,
					"authentication-error": __props.authenticationError,
					copy: __props.copy
				}, null, 8, [
					"embedded-checkout-enabled",
					"reconciliation-operation-id",
					"authentication-state",
					"authentication-error",
					"copy"
				]),
				verificationUrl.value ? (openBlock(), createBlock(CheckoutVerificationPrompt_default, {
					key: 0,
					"action-url": verificationUrl.value,
					copy: __props.copy
				}, null, 8, ["action-url", "copy"])) : createCommentVNode("", true),
				__props.paymentCancelable ? (openBlock(), createElementBlock(Fragment, { key: 1 }, [createVNode(CheckoutButton_default, {
					variant: "secondary",
					size: "lg",
					class: "w-full rounded-lg",
					loading: __props.cancelingPayment,
					onClick: _cache[4] || (_cache[4] = ($event) => emit("cancelPayment"))
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(__props.copy.cancelPaymentAndRetry), 1)]),
					_: 1
				}, 8, ["loading"]), __props.cancelPaymentError ? (openBlock(), createElementBlock("p", _hoisted_4$1, toDisplayString(__props.cancelPaymentError), 1)) : createCommentVNode("", true)], 64)) : createCommentVNode("", true),
				createVNode(CheckoutButton_default, {
					variant: __props.actionUrl ? "tertiary" : "inverted",
					size: "lg",
					class: "w-full rounded-lg",
					loading: __props.isLoading,
					disabled: confirmBlocked.value,
					onClick: _cache[5] || (_cache[5] = ($event) => emit("confirm", confirmReactivation.value))
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(confirmCta.value), 1)]),
					_: 1
				}, 8, [
					"variant",
					"loading",
					"disabled"
				]),
				createVNode(CheckoutTermsNote_default, {
					class: "mt-2",
					copy: __props.copy.terms
				}, null, 8, ["copy"])
			])]);
		};
	}
});
//#endregion
//#region src/platform/billing/subscription/constants/teamPlanCreditStops.ts
/**
* Team-plan credit-subscription slider stops — OSS / pre-deploy fallback.
*
* The live set comes from `GET /api/billing/plans → team_credit_stops` (mapped
* via `mapApiTeamCreditStops`); these hardcoded DES-197 breakpoints render only
* when the API doesn't supply them. The slider snaps to exactly these 5 fixed
* breakpoints — the user cannot select a value in between. The `credits` figures
* equal `usdToCredits(usd)` at the current rate (`CREDITS_PER_USD = 211`); a unit
* test guards against rate drift silently changing the designed values.
*/
var TEAM_PLAN_CREDIT_STOPS = [
	{
		usd: 200,
		credits: 42200,
		discountPercentYearly: 0
	},
	{
		usd: 400,
		credits: 84400,
		discountPercentYearly: 5
	},
	{
		usd: 700,
		credits: 147700,
		discountPercentYearly: 10
	},
	{
		usd: 1400,
		credits: 295400,
		discountPercentYearly: 15
	},
	{
		usd: 2500,
		credits: 527500,
		discountPercentYearly: 20
	}
];
/**
* Per-credit Team plan slug for a billing cadence (cloud catalog). The slug
* encodes the cadence; `POST /api/billing/subscribe` reads `plan_slug` +
* `team_credit_stop_id` and resolves all amounts server-side from the stop.
*/
function getTeamPlanSlug(billingCycle) {
	return billingCycle === "yearly" ? "team_per_credit_annual" : "team_per_credit_monthly";
}
//#endregion
//#region src/platform/billing/utils/workspaceCheckoutTelemetry.ts
function trackWorkspaceCheckoutStarted({ tier, cycle, checkoutType, billingOpId, paymentIntentSource }) {
	const { userId } = useAuthStore();
	if (!userId) return;
	useTelemetry()?.trackBeginCheckout({
		user_id: userId,
		tier,
		cycle,
		checkout_type: checkoutType,
		billing_op_id: billingOpId,
		...paymentIntentSource ? { payment_intent_source: paymentIntentSource } : {}
	});
}
//#endregion
//#region src/platform/billing/composables/useSubscriptionCheckout.ts
var BILLING_PORTAL_ORIGINS = /* @__PURE__ */ new Set(["https://billing.stripe.com", "https://checkout.comfy.org"]);
function parseBillingPortalUrl(url) {
	if (typeof url !== "string") return null;
	try {
		const portalUrl = new URL(url);
		return BILLING_PORTAL_ORIGINS.has(portalUrl.origin) ? portalUrl : null;
	} catch {
		return null;
	}
}
var stopPaymentRecoveryReturnRefresh = null;
function armPaymentRecoveryReturnRefresh() {
	stopPaymentRecoveryReturnRefresh?.();
	const { fetchStatus } = useBillingContext();
	stopPaymentRecoveryReturnRefresh = registerRefreshOnReturn(fetchStatus);
}
/** Thrown by `assertReactivationAmountUnchanged` when a fresh preview no
*  longer matches the billing state the reactivation banner showed and the
*  user consented to. Caught by the surrounding try/catch and surfaced
*  through the same toast as any other subscribe failure. */
var ReactivationAmountChangedError = class extends Error {};
function findPlanSlug(plans, tierKey, billingCycle) {
	const apiDuration = billingCycle === "yearly" ? "ANNUAL" : "MONTHLY";
	const apiTier = tierKey.toUpperCase();
	return plans.find((p) => p.tier === apiTier && p.duration === apiDuration)?.slug ?? null;
}
function useSubscriptionCheckout(emit, paymentIntentSource, { tierPlanType = "personal" } = {}) {
	const { t } = useI18n();
	const toast = useToast();
	const { subscribe, previewSubscribe, plans, fetchPlans, fetchStatus, isTeamPlan, resubscribe, subscription } = useBillingContext();
	const { shouldUseWorkspaceBilling } = useBillingRouting();
	const { canSubscribeSelfServe, canChangeSeats, canDowngradeToPersonal } = useBillingCapabilities();
	const { permissions, canReactivatePlan } = useWorkspaceUI();
	const telemetry = useTelemetry();
	const billingOperationStore = useBillingOperationStore();
	const workspaceStore = useTeamWorkspaceStore();
	const subscriptionRail = useSubscriptionRail();
	const checkoutStep = ref("pricing");
	const isLoadingPreview = ref(false);
	const loadingTier = ref(null);
	const isSubscribing = ref(false);
	const isResubscribing = ref(false);
	const previewData = ref(null);
	const selectedTierKey = ref(null);
	const selectedTeamCheckout = ref(null);
	let teamPreviewRequestId = 0;
	let checkoutMutationOwner = 0;
	let checkoutMutationSeq = 0;
	let activeCheckoutAttemptStartedAt;
	let lastEmittedPreviewRevision;
	const paymentRecoveryToasts = [];
	function dismissToasts(ids) {
		for (const id of ids.splice(0)) toast.dismiss(id);
	}
	onScopeDispose(() => dismissToasts(paymentRecoveryToasts));
	useCheckoutJourneyExit();
	const reactivationRequired = ref(false);
	const selectedBillingCycle = ref("yearly");
	const activeCheckoutOperationId = ref(null);
	const activeCheckoutOperation = computed(() => {
		const operationId = activeCheckoutOperationId.value;
		if (!operationId) return subscriptionRail?.subscriptionActionOperation ?? billingOperationStore.subscriptionActionOperation;
		const operation = subscriptionRail?.getOperation(operationId) ?? billingOperationStore.getOperation(operationId);
		return operation?.workspaceId === workspaceStore.activeWorkspaceId ? operation : void 0;
	});
	const activeCheckoutActionUrl = computed(() => activeCheckoutOperation.value?.actionUrl ?? subscriptionRail?.subscriptionActionUrl ?? null);
	const parkedCheckoutRecovery = computed(() => activeCheckoutOperation.value?.phase === "awaiting_payment_method");
	const authenticationState = computed(() => activeCheckoutOperation.value?.authenticationState ?? null);
	const isPolling = computed(() => {
		const operation = activeCheckoutOperation.value;
		if (!operation) return false;
		if (operation.status === "succeeded") return true;
		if (operation.status !== "pending") return false;
		if (operation.isAuthenticating) return true;
		if (operation.phase === "awaiting_payment_method") return false;
		return operation.authenticationState !== "failed_retryable" && operation.authenticationState !== "requires_action";
	});
	const cancelablePaymentId = computed(() => {
		const opId = activeCheckoutOperation.value?.opId;
		return opId && subscriptionRail?.getOperation(opId)?.cancelable ? opId : null;
	});
	const paymentCancelable = computed(() => cancelablePaymentId.value !== null);
	const isCancelingPayment = ref(false);
	const cancelPaymentError = ref(null);
	async function cancelPayment() {
		const opId = cancelablePaymentId.value;
		if (!opId || !subscriptionRail || isCancelingPayment.value) return;
		isCancelingPayment.value = true;
		cancelPaymentError.value = null;
		const outcome = await subscriptionRail.cancelOperation(opId);
		isCancelingPayment.value = false;
		if (outcome.status === "error") cancelPaymentError.value = outcome.error.message;
		else if (outcome.status === "unavailable") cancelPaymentError.value = t("billingOperation.cancelPaymentFailed");
	}
	function beginCheckoutMutation() {
		if (checkoutMutationOwner !== 0) return 0;
		checkoutMutationOwner = ++checkoutMutationSeq;
		return checkoutMutationOwner;
	}
	function finishCheckoutMutation(token) {
		if (token !== 0 && checkoutMutationOwner === token) checkoutMutationOwner = 0;
	}
	const selectedTeamStop = computed(() => selectedTeamCheckout.value?.stop ?? null);
	const isTeamCheckout = computed(() => selectedTeamCheckout.value !== null);
	function isSubscriptionCancelled() {
		return subscription.value?.isCancelled ?? false;
	}
	function previewRequiresReactivation(preview) {
		return preview?.requires_reactivation_confirmation ?? isSubscriptionCancelled();
	}
	function hasQuoteIdentity(preview) {
		return Boolean(preview.quote_id) && preview.quote_version !== void 0;
	}
	function installPreview(preview) {
		if (!preview.allowed) return false;
		previewData.value = preview;
		const journey = getActiveCheckoutJourney();
		if (journey) {
			const revision = hasQuoteIdentity(preview) ? `${preview.quote_id}:${preview.quote_version}` : void 0;
			if (revision === void 0 || revision !== lastEmittedPreviewRevision) {
				lastEmittedPreviewRevision = revision;
				trackCheckoutJourneyPhase(journey, {
					phase: "preview_ready",
					...revision !== void 0 && { preview_revision: revision }
				});
			}
		}
		return true;
	}
	function requiresReactivationConfirmation() {
		return isSubscriptionCancelled() || reactivationRequired.value;
	}
	function withCurrentPromotion(options = {}) {
		const promotionCode = previewData.value?.promotion_code;
		return {
			...options,
			...promotionCode && { promotionCode }
		};
	}
	function notifyReactivationConfirmationRequired() {
		toast.error(t("g.error"), { description: t("subscription.preview.reactivation.confirmationRequired") });
	}
	function isExistingPlanPreview(preview) {
		return !!preview?.allowed && preview.transition_type !== "new_subscription";
	}
	function isReactivationCapablePreview(preview) {
		return isExistingPlanPreview(preview) && !!preview.current_plan && !!(subscription.value?.endDate ?? preview.current_plan.period_end);
	}
	function isUsableTeamPreview(preview, checkoutType) {
		if (isSubscriptionCancelled()) return isReactivationCapablePreview(preview);
		return checkoutType === "change" ? isExistingPlanPreview(preview) : Boolean(preview?.allowed);
	}
	function reactivationMaterialSnapshot(preview, ignoreTimeDerivedTodayValues = false) {
		const planSnapshot = (plan) => {
			if (!plan) return null;
			const { seat_summary: seatSummary } = plan;
			return [
				plan.slug,
				plan.tier,
				plan.duration,
				plan.price_cents,
				plan.credits_cents,
				seatSummary?.seat_count,
				seatSummary?.total_cost_cents,
				seatSummary?.total_credits_cents,
				plan.period_start,
				plan.period_end
			];
		};
		return JSON.stringify([
			preview.allowed,
			preview.transition_type,
			preview.is_immediate,
			preview.is_immediate ? null : preview.effective_at,
			preview.cost_next_period_cents,
			ignoreTimeDerivedTodayValues ? null : preview.credits_today_cents,
			preview.credits_next_period_cents,
			planSnapshot(preview.current_plan),
			planSnapshot(preview.new_plan)
		]);
	}
	async function assertReactivationAmountUnchanged(planSlug, options) {
		const confirmedPreview = previewData.value;
		const freshPreview = await previewSubscribe(planSlug, withCurrentPromotion(options));
		if (!freshPreview?.allowed) throw new Error(freshPreview?.reason || t("subscription.subscribeFailed"));
		if (confirmedPreview?.proration_at) {
			const isImmediateTransition = confirmedPreview.is_immediate;
			const amountChanged = isImmediateTransition ? freshPreview.cost_today_cents > confirmedPreview.cost_today_cents : freshPreview.cost_today_cents !== confirmedPreview.cost_today_cents;
			const materialChanged = reactivationMaterialSnapshot(freshPreview, isImmediateTransition) !== reactivationMaterialSnapshot(confirmedPreview, isImmediateTransition);
			if (amountChanged || materialChanged) {
				installPreview(freshPreview);
				throw new ReactivationAmountChangedError(t(amountChanged ? "subscription.preview.reactivation.amountChanged" : "subscription.preview.reactivation.confirmationRequired"));
			}
			return;
		}
		const amountChanged = freshPreview.cost_today_cents !== (confirmedPreview?.cost_today_cents ?? 0);
		const materialChanged = !!confirmedPreview && reactivationMaterialSnapshot(freshPreview) !== reactivationMaterialSnapshot(confirmedPreview);
		installPreview(freshPreview);
		if (amountChanged || materialChanged) throw new ReactivationAmountChangedError(t(amountChanged ? "subscription.preview.reactivation.amountChanged" : "subscription.preview.reactivation.confirmationRequired"));
	}
	function hasErrorCode(error, code) {
		return typeof error === "object" && error !== null && "code" in error && error.code === code;
	}
	/**
	* The portal URL for recovery, from whichever rail owns the subscription.
	* An `unavailable` route is not deployed here, so the legacy client answers;
	* a failure throws into the caller's catch, where a legacy throw already
	* lands.
	*/
	async function readPaymentPortalUrl(returnUrl) {
		if (subscriptionRail) {
			const outcome = await subscriptionRail.openPaymentPortal(returnUrl);
			if (outcome.status === "ok") return {
				url: outcome.value,
				billingClient: "sdk"
			};
			if (outcome.status === "error") throw outcome.error;
		}
		const { url } = await workspaceApi.getPaymentPortalUrl(returnUrl);
		return {
			url,
			billingClient: "legacy"
		};
	}
	async function recoverOutstandingPayment(error, isCurrent = () => true) {
		const readRail = useBillingReadRail();
		const hasPaymentRecoveryCode = hasErrorCode(error, "SUBSCRIPTION_PAYMENT_REQUIRED") || hasErrorCode(error, "OUTSTANDING_PAYMENT_REQUIRED");
		let requiresRecovery = hasPaymentRecoveryCode;
		if (!requiresRecovery && hasErrorCode(error, "TRANSITION_NOT_ALLOWED")) try {
			const status = readRail === null ? await workspaceApi.getBillingStatus() : await readOnRail(readRail.readStatus, "getBillingStatus");
			requiresRecovery = status?.billing_status === "payment_failed" || status?.billing_status === "paused";
		} catch {
			return null;
		}
		if (!requiresRecovery || !isCurrent()) return null;
		const portal = createBillingPortalReporter(telemetry, "payment_recovery");
		let billingClient;
		try {
			const portalResponse = await readPaymentPortalUrl(`${globalThis.location.origin}${globalThis.location.pathname}`);
			billingClient = portalResponse.billingClient;
			const portalUrl = parseBillingPortalUrl(portalResponse.url);
			if (!isCurrent()) return null;
			if (!portalUrl) throw new Error(t("toastMessages.failedToAccessBillingPortal", { error: t("toastMessages.invalidBillingPortalUrl") }));
			if (!openBillingUrl(portalUrl.href)) {
				portal.blocked(billingClient);
				paymentRecoveryToasts.push(toast.warning(t("g.warning"), {
					description: t("subscription.preview.paymentPopupBlocked"),
					action: {
						label: t("subscription.planLoadErrorRetry"),
						onClick: () => {
							if (!isCurrent()) return;
							if (openBillingUrl(portalUrl.href)) portal.opened(billingClient);
							else portal.blocked(billingClient);
							armPaymentRecoveryReturnRefresh();
						}
					}
				}));
				return "blocked";
			}
			portal.opened(billingClient);
			armPaymentRecoveryReturnRefresh();
			return "opened";
		} catch (portalError) {
			if (!isCurrent()) return null;
			portal.failed(portalError, billingClient);
			reportError(portalError, {
				surface: "workspace",
				errorType: "billing_portal_open_failure"
			});
			showSubscribeError(hasPaymentRecoveryCode ? error : portalError);
			return "failed";
		}
	}
	async function refreshExpiredProrationQuote(error, planSlug, options) {
		if (!hasErrorCode(error, "PRORATION_QUOTE_EXPIRED")) return false;
		let freshPreview;
		try {
			freshPreview = await previewSubscribe(planSlug, withCurrentPromotion(options));
		} catch (previewError) {
			if (!await recoverOutstandingPayment(previewError)) showSubscribeError(previewError);
			return true;
		}
		if (!isReactivationCapablePreview(freshPreview)) {
			resetToPricing();
			toast.error(t("g.error"), { description: t("subscription.preview.reactivation.unavailable") });
			return true;
		}
		const amountChanged = !previewData.value || amountDueTodayChanged(previewData.value, freshPreview);
		installPreview(freshPreview);
		toast.error(t("g.error"), { description: t(amountChanged ? "subscription.preview.reactivation.amountChanged" : "subscription.preview.reactivation.confirmationRequired") });
		return true;
	}
	async function refreshPreviewOnReactivationBlock(planSlug, options) {
		let freshPreview = null;
		try {
			freshPreview = await previewSubscribe(planSlug, withCurrentPromotion(options));
		} catch (error) {
			const recovery = await recoverOutstandingPayment(error);
			if (recovery === "failed") resetToPricing();
			if (recovery) return true;
		}
		if (freshPreview?.requires_reactivation_confirmation !== false && isReactivationCapablePreview(freshPreview)) {
			installPreview(freshPreview);
			reactivationRequired.value = true;
			notifyReactivationConfirmationRequired();
			return true;
		}
		if (freshPreview?.allowed && freshPreview.transition_type === "new_subscription" && !isSubscriptionCancelled() && !previewRequiresReactivation(freshPreview)) {
			const amountChanged = !!previewData.value && amountDueTodayChanged(previewData.value, freshPreview);
			installPreview(freshPreview);
			if (!amountChanged) return false;
			toast.error(t("g.error"), { description: t("subscription.preview.reactivation.amountChanged") });
			return true;
		}
		reactivationRequired.value = false;
		resetToPricing();
		toast.error(t("g.error"), { description: t("subscription.preview.reactivation.unavailable") });
		return true;
	}
	function canSelectTierPlan() {
		return tierPlanType === "team" || !isTeamPlan.value || permissions.value.canDowngradeToPersonal;
	}
	function canPerformCheckout(checkoutType) {
		return permissions.value.canManageSubscription;
	}
	function needsTeamToPersonalDowngrade() {
		return tierPlanType !== "team" && isTeamPlan.value;
	}
	async function showTeamToPersonalDowngrade(planSlug, tierKey) {
		const result = await useBillingDialogsAccess().showDowngradeToPersonalDialog({
			planName: t(`subscription.tiers.${tierKey}.name`),
			planSlug,
			paymentIntentSource
		});
		if (!result) return;
		previewData.value = result.preview;
		trackWorkspaceCheckoutStarted({
			tier: tierKey,
			cycle: selectedBillingCycle.value,
			checkoutType: "change",
			billingOpId: result.response.billing_op_id,
			paymentIntentSource
		});
		await handleSubscribeResponse(result.response, {
			tier: tierKey,
			cycle: selectedBillingCycle.value,
			checkoutType: "change"
		}, false);
	}
	const previewVariant = computed(() => {
		if (selectedTeamCheckout.value) return selectedTeamCheckout.value.checkoutType === "change" || previewData.value && previewData.value.transition_type !== "new_subscription" ? "team-change" : "team-new";
		if (previewData.value) return previewData.value.transition_type === "new_subscription" ? "personal-new" : "personal-change";
		return null;
	});
	function getApiPlanSlug(tierKey, billingCycle) {
		return findPlanSlug(plans.value, tierKey, billingCycle);
	}
	async function handleSubscribeClick(payload) {
		if (isSubscribing.value || !canSelectTierPlan() || (isTeamPlan.value && tierPlanType !== "team" ? !permissions.value.canDowngradeToPersonal : false)) return;
		telemetry?.trackBillingEvent({
			operation: "subscription_checkout",
			stage: "intent",
			outcome: "pending",
			tier: payload.tierKey,
			cycle: payload.billingCycle,
			payment_intent_source: paymentIntentSource
		});
		const { tierKey, billingCycle } = payload;
		reactivationRequired.value = false;
		isLoadingPreview.value = true;
		loadingTier.value = tierKey;
		selectedTierKey.value = tierKey;
		selectedBillingCycle.value = billingCycle;
		const enteredJourney = enterCheckoutJourney(`${tierKey}:${billingCycle}`);
		try {
			let planSlug = getApiPlanSlug(tierKey, billingCycle);
			if (!planSlug) {
				await fetchPlans();
				planSlug = getApiPlanSlug(tierKey, billingCycle);
			}
			if (!planSlug) {
				toast.error(t("subscription.unableToSubscribe"), { description: t("subscription.planNotAvailable") });
				return;
			}
			if (needsTeamToPersonalDowngrade()) {
				await showTeamToPersonalDowngrade(planSlug, tierKey);
				return;
			}
			if (openHostedBillingTab("checkout", {
				plan: planSlug,
				source: paymentIntentSource,
				journeyId: enteredJourney?.journey_id
			})) {
				handOffCheckoutJourney();
				emit("close", false);
				return;
			}
			const response = await previewSubscribe(planSlug);
			if (!response || !response.allowed) {
				const journey = getActiveCheckoutJourney();
				if (journey) trackCheckoutJourneyPhase(journey, {
					phase: "preview_failed",
					failure_category: "unknown"
				});
				toast.error(t("subscription.unableToSubscribe"), { description: response?.reason || t("subscription.planNotAvailable") });
				return;
			}
			if (!canPerformCheckout(response.transition_type === "new_subscription" ? "new" : "change")) return;
			installPreview(response);
			checkoutStep.value = "preview";
		} catch (error) {
			if (await recoverOutstandingPayment(error)) return;
			const journey = getActiveCheckoutJourney();
			if (journey) trackCheckoutJourneyPhase(journey, {
				phase: "preview_failed",
				failure_category: categorizeBillingApiError(error)
			});
			toast.error(t("g.error"), { description: getErrorMessage(error) ?? t("subscription.previewLoadFailed") });
		} finally {
			isLoadingPreview.value = false;
			loadingTier.value = null;
		}
	}
	/**
	* Team-plan checkout entry. A fresh subscribe has nothing to prorate and shows
	* the display-only "Confirm your payment" step. An existing subscriber changing
	* their credit commitment gets a prorated transition preview when the backend
	* can describe it; until `preview-subscribe` accepts a team stop the attempt
	* falls back to the same display-only step.
	*/
	async function handleSubscribeTeamClick(payload) {
		const checkoutType = payload.isChange ? "change" : "new";
		if (isSubscribing.value || !canPerformCheckout(checkoutType)) return;
		telemetry?.trackBillingEvent({
			operation: "subscription_checkout",
			stage: "intent",
			outcome: "pending",
			tier: "team",
			cycle: payload.billingCycle,
			checkout_type: checkoutType,
			payment_intent_source: paymentIntentSource
		});
		const previewRequestId = ++teamPreviewRequestId;
		reactivationRequired.value = false;
		selectedTeamCheckout.value = {
			stop: payload.stop,
			checkoutType
		};
		selectedBillingCycle.value = payload.billingCycle;
		selectedTierKey.value = null;
		previewData.value = null;
		const enteredJourney = enterCheckoutJourney(`team:${payload.stop.id}:${payload.billingCycle}`);
		if (payload.stop.id && openHostedBillingTab("checkout", {
			plan: getTeamPlanSlug(payload.billingCycle),
			teamCreditStopId: payload.stop.id,
			source: paymentIntentSource,
			journeyId: enteredJourney?.journey_id
		})) {
			handOffCheckoutJourney();
			emit("close", false);
			return;
		}
		const teamCreditStopId = payload.stop.id;
		if (!teamCreditStopId) {
			toast.error(t("subscription.teamPlan.name"), { description: t("subscription.teamPlan.unavailable") });
			resetToPricing();
			return;
		}
		isLoadingPreview.value = true;
		let response = null;
		let previewError;
		try {
			response = await previewSubscribe(getTeamPlanSlug(payload.billingCycle), { teamCreditStopId });
		} catch (error) {
			previewError = error;
			const recovery = await recoverOutstandingPayment(error, () => previewRequestId === teamPreviewRequestId);
			if (recovery === "failed") {
				resetToPricing();
				return;
			}
			if (recovery) return;
		} finally {
			if (previewRequestId === teamPreviewRequestId) isLoadingPreview.value = false;
		}
		if (previewRequestId !== teamPreviewRequestId) return;
		if (isUsableTeamPreview(response, checkoutType)) {
			installPreview(response);
			checkoutStep.value = "preview";
			return;
		}
		toast.error(t("subscription.teamPlan.name"), { description: getErrorMessage(previewError) ?? (response?.reason || t("subscription.subscribeFailed")) });
		checkoutStep.value = "pricing";
		selectedTeamCheckout.value = null;
	}
	function resetToPricing() {
		teamPreviewRequestId += 1;
		isLoadingPreview.value = false;
		reactivationRequired.value = false;
		checkoutStep.value = "pricing";
		previewData.value = null;
		selectedTeamCheckout.value = null;
		activeCheckoutOperationId.value = null;
		activeCheckoutAttemptStartedAt = void 0;
		dismissToasts(paymentRecoveryToasts);
	}
	function handleBackToPricing() {
		if (isPolling.value || isSubscribing.value) return;
		resetToPricing();
	}
	function handleSuccessClose() {
		emit("close", true);
	}
	async function handleSubscription(confirmReactivation = false) {
		if (!canSelectTierPlan()) return;
		const mutationToken = beginCheckoutMutation();
		if (!mutationToken) return;
		const tierKey = selectedTierKey.value;
		if (!tierKey) {
			finishCheckoutMutation(mutationToken);
			return;
		}
		const billingCycle = selectedBillingCycle.value;
		const planSlug = getApiPlanSlug(tierKey, billingCycle);
		if (!planSlug) {
			finishCheckoutMutation(mutationToken);
			return;
		}
		const checkoutType = previewData.value && previewData.value.transition_type !== "new_subscription" ? "change" : "new";
		if (!canPerformCheckout(checkoutType)) {
			finishCheckoutMutation(mutationToken);
			return;
		}
		isSubscribing.value = true;
		try {
			if (needsTeamToPersonalDowngrade()) {
				await showTeamToPersonalDowngrade(planSlug, tierKey);
				return;
			}
			await fetchStatus();
			if (!confirmReactivation && requiresReactivationConfirmation()) {
				if (await refreshPreviewOnReactivationBlock(planSlug)) return;
			}
			const attemptStartedAt = trackSubscriptionStarted({
				tier: tierKey,
				cycle: billingCycle,
				checkoutType
			});
			if (confirmReactivation && requiresReactivationConfirmation()) await assertReactivationAmountUnchanged(planSlug);
			const submittingJourney = getActiveCheckoutJourney();
			if (submittingJourney) trackCheckoutJourneyPhase(submittingJourney, { phase: "submitted" });
			const stopReleasing = releaseSubmitOnceParked(mutationToken);
			const response = await subscribe(planSlug, {
				returnUrl: `${getComfyPlatformBaseUrl()}/payment/success`,
				cancelUrl: `${getComfyPlatformBaseUrl()}/payment/failed`,
				confirmReactivation,
				prorationAt: previewData.value?.is_immediate ? previewData.value.proration_at : void 0,
				attemptStartedAt
			}).finally(stopReleasing);
			if (response) {
				linkSubmittingJourneyToOperation(submittingJourney, response.billing_op_id);
				trackWorkspaceCheckoutStarted({
					tier: tierKey,
					cycle: billingCycle,
					checkoutType,
					billingOpId: response.billing_op_id,
					paymentIntentSource
				});
			}
			await handleSubscribeResponse(response, {
				tier: tierKey,
				cycle: billingCycle,
				checkoutType,
				attemptStartedAt
			}, true, mutationToken);
			activeCheckoutAttemptStartedAt = void 0;
		} catch (error) {
			if (hasErrorCode(error, "REACTIVATION_CONFIRMATION_REQUIRED") && await refreshPreviewOnReactivationBlock(planSlug)) return;
			trackSubscriptionFailure({
				tier: tierKey,
				cycle: billingCycle,
				checkoutType,
				attemptStartedAt: activeCheckoutAttemptStartedAt
			}, error);
			activeCheckoutAttemptStartedAt = void 0;
			if (await recoverOutstandingPayment(error)) return;
			if (await refreshExpiredProrationQuote(error, planSlug)) return;
			showSubscribeError(error);
		} finally {
			releaseSubmit(mutationToken);
		}
	}
	const attemptErrorToasts = [];
	function showSubscribeError(error) {
		attemptErrorToasts.push(toast.error(t("g.error"), { description: getErrorMessage(error) ?? t("subscription.subscribeFailed") }));
	}
	watch(checkoutStep, (step) => {
		if (step !== "success") return;
		dismissToasts(attemptErrorToasts);
	});
	function currentSubscriptionEntryFlow() {
		return subscription.value?.isActive && subscription.value.tier !== "FREE" ? "paid_upgrade" : "initial_subscription";
	}
	function enterCheckoutJourney(intent) {
		const workspaceId = workspaceStore.activeWorkspaceId;
		const ownerUid = useAuthStore().userId;
		if (!workspaceId || !ownerUid) return null;
		const entrySource = resolveEntrySource(paymentIntentSource, "pricing");
		const resolved = resolveCheckoutJourney({
			actorUid: ownerUid,
			workspaceId,
			entryFlow: currentSubscriptionEntryFlow(),
			entrySource,
			paymentIntentSource,
			intent: `${entrySource}:${intent}`,
			uiMode: "hosted",
			assignment: resolveCheckoutAssignment(api.getServerFeatures())
		});
		if (resolved.status === "blocked") return null;
		if (!resolved.resumed) trackCheckoutJourneyPhase(resolved.record, { phase: "entered" });
		return resolved.record;
	}
	function linkSubmittingJourneyToOperation(submittingJourney, billingOpId) {
		if (!submittingJourney || getActiveCheckoutJourney()?.journey_id !== submittingJourney.journey_id) return;
		const linked = bindOperationToCheckoutJourney(billingOpId);
		if (linked) trackCheckoutJourneyPhase(linked, {
			phase: "operation_linked",
			billing_op_id: billingOpId
		});
	}
	function trackSubscriptionStarted(context) {
		if (activeCheckoutAttemptStartedAt !== void 0) return activeCheckoutAttemptStartedAt;
		if (!shouldUseWorkspaceBilling.value) return void 0;
		activeCheckoutAttemptStartedAt = Date.now();
		telemetry?.trackBillingEvent({
			operation: "subscription_checkout",
			stage: "started",
			outcome: "pending",
			tier: context.tier,
			cycle: context.cycle,
			checkout_type: context.checkoutType,
			payment_intent_source: paymentIntentSource
		});
		telemetry?.trackBillingEvent({
			operation: "operation",
			stage: "started",
			outcome: "pending",
			operation_type: "subscription",
			billing_client: billingClientOf(useSubscriptionRail()),
			tier: context.tier,
			cycle: context.cycle,
			checkout_type: context.checkoutType,
			payment_intent_source: paymentIntentSource
		});
		return activeCheckoutAttemptStartedAt;
	}
	function trackSubscriptionFailure(context, error, errorCode) {
		if (context.attemptStartedAt === void 0) return;
		const failureCategory = errorCode ? "unknown" : categorizeBillingApiError(error);
		telemetry?.trackBillingEvent({
			operation: "subscription_checkout",
			stage: "failed",
			outcome: "failure",
			tier: context.tier,
			cycle: context.cycle,
			checkout_type: context.checkoutType,
			payment_intent_source: paymentIntentSource,
			failure_category: failureCategory,
			...errorCode && { error_code: errorCode },
			duration_ms: Date.now() - context.attemptStartedAt
		});
		if (error instanceof SettledOperationError) return;
		telemetry?.trackBillingEvent({
			operation: "operation",
			stage: "failed",
			outcome: "failure",
			operation_type: "subscription",
			billing_client: billingClientOf(useSubscriptionRail()),
			tier: context.tier,
			cycle: context.cycle,
			checkout_type: context.checkoutType,
			payment_intent_source: paymentIntentSource,
			failure_category: failureCategory,
			...errorCode && { error_code: errorCode },
			duration_ms: Date.now() - context.attemptStartedAt
		});
	}
	async function handleSubscribeResponse(response, context, shouldTrackSubscriptionSuccess = true, mutationToken = 0) {
		if (!response) {
			trackSubscriptionFailure(context, void 0, "missing_checkout_response");
			return;
		}
		if (response.status === "subscribed") {
			if (shouldTrackSubscriptionSuccess && context.attemptStartedAt !== void 0) {
				const durationMs = Date.now() - context.attemptStartedAt;
				telemetry?.trackBillingEvent({
					operation: "subscription_checkout",
					stage: "succeeded",
					outcome: "success",
					tier: context.tier,
					cycle: context.cycle,
					checkout_type: context.checkoutType,
					payment_intent_source: paymentIntentSource,
					billing_op_id: response.billing_op_id,
					duration_ms: durationMs
				});
				if (!response.operationObserved) telemetry?.trackBillingEvent({
					operation: "operation",
					stage: "succeeded",
					outcome: "success",
					operation_type: "subscription",
					billing_client: billingClientOf(useSubscriptionRail()),
					tier: context.tier,
					cycle: context.cycle,
					checkout_type: context.checkoutType,
					payment_intent_source: paymentIntentSource,
					billing_op_id: response.billing_op_id,
					duration_ms: durationMs
				});
				if (response.requiredPayment) telemetry?.trackMonthlySubscriptionSucceeded({
					tier: context.tier,
					cycle: context.cycle,
					checkout_type: context.checkoutType,
					payment_intent_source: paymentIntentSource,
					billing_op_id: response.billing_op_id
				});
			}
			if (response.requiredPayment) toast.success(t("billingOperation.subscriptionSuccess"), { duration: 5e3 });
			checkoutStep.value = "success";
			return;
		}
		savePendingCheckout(response.billing_op_id, context);
		let initialActionUrl;
		if (response.status === "needs_payment_method") {
			if (!response.payment_method_url) throw new Error(t("subscription.preview.stripeUnavailable"));
			initialActionUrl = response.payment_method_url;
			if (!openBillingUrl(initialActionUrl)) {
				const paymentMethodUrl = initialActionUrl;
				const opId = response.billing_op_id;
				paymentRecoveryToasts.push(toast.warning(t("g.warning"), {
					description: t("subscription.preview.paymentPopupBlocked"),
					action: {
						label: t("subscription.planLoadErrorRetry"),
						onClick: () => {
							if (activeCheckoutOperationId.value !== opId) return;
							window.open(paymentMethodUrl, "_blank");
						}
					}
				}));
			}
		}
		await advanceToSuccessOnOperation(response.billing_op_id, context, initialActionUrl, mutationToken);
	}
	function savePendingCheckout(operationId, context) {
		const workspaceId = workspaceStore.activeWorkspaceId;
		const ownerUid = useAuthStore().userId;
		if (!workspaceId || !ownerUid) return;
		const attemptedAt = context.attemptStartedAt ?? Date.now();
		if (context.tier === "team") {
			const teamCreditStopId = selectedTeamCheckout.value?.stop.id;
			if (!teamCreditStopId) return;
			savePendingSubscriptionCheckout({
				operationId,
				workspaceId,
				ownerUid,
				selection: {
					planMode: "team",
					teamCreditStopId,
					billingCycle: context.cycle
				},
				attemptedAt
			});
			return;
		}
		savePendingSubscriptionCheckout({
			operationId,
			workspaceId,
			ownerUid,
			selection: {
				planMode: "personal",
				tierKey: context.tier,
				billingCycle: context.cycle
			},
			attemptedAt
		});
	}
	async function advanceToSuccessOnOperation(opId, context, initialActionUrl, mutationToken) {
		activeCheckoutOperationId.value = opId;
		const metadata = {
			tier: context.tier,
			cycle: context.cycle,
			checkoutType: context.checkoutType,
			paymentIntentSource,
			attemptStartedAt: context.attemptStartedAt
		};
		const terminalOperation = initialActionUrl ? billingOperationStore.startOperation(opId, "subscription", metadata, initialActionUrl) : billingOperationStore.startOperation(opId, "subscription", metadata);
		isSubscribing.value = false;
		finishCheckoutMutation(mutationToken);
		const operation = await terminalOperation;
		clearPendingSubscriptionCheckoutIfTerminal(opId, operation.status);
		if (operation.status === "succeeded" && activeCheckoutOperationId.value === opId && operation.workspaceId === workspaceStore.activeWorkspaceId) checkoutStep.value = "success";
	}
	function releaseSubmitOnceParked(mutationToken) {
		if (!subscriptionRail) return () => {};
		const stop = watch(() => subscriptionRail.subscriptionActionOperation, (operation) => {
			if (!operation) return;
			stop();
			releaseSubmit(mutationToken);
		});
		return stop;
	}
	function releaseSubmit(mutationToken) {
		if (checkoutMutationOwner !== mutationToken) return;
		isSubscribing.value = false;
		finishCheckoutMutation(mutationToken);
	}
	async function handleTeamSubscription(confirmReactivation = false) {
		if (isLoadingPreview.value || isSubscribing.value || !selectedTeamCheckout.value || !canPerformCheckout(selectedTeamCheckout.value.checkoutType)) return;
		const mutationToken = beginCheckoutMutation();
		if (!mutationToken) return;
		const teamCheckout = selectedTeamCheckout.value;
		if (!teamCheckout.stop.id) {
			toast.error(t("subscription.teamPlan.name"), { description: t("subscription.teamPlan.unavailable") });
			finishCheckoutMutation(mutationToken);
			return;
		}
		const { stop, checkoutType } = teamCheckout;
		const billingCycle = selectedBillingCycle.value;
		const planSlug = getTeamPlanSlug(billingCycle);
		isSubscribing.value = true;
		try {
			await fetchStatus();
			if (!confirmReactivation && requiresReactivationConfirmation()) {
				if (await refreshPreviewOnReactivationBlock(planSlug, { teamCreditStopId: stop.id })) return;
			}
			const attemptStartedAt = trackSubscriptionStarted({
				tier: "team",
				cycle: billingCycle,
				checkoutType
			});
			if (confirmReactivation && requiresReactivationConfirmation()) await assertReactivationAmountUnchanged(planSlug, { teamCreditStopId: stop.id });
			const submittingJourney = getActiveCheckoutJourney();
			if (submittingJourney) trackCheckoutJourneyPhase(submittingJourney, { phase: "submitted" });
			const stopReleasing = releaseSubmitOnceParked(mutationToken);
			const response = await subscribe(planSlug, {
				teamCreditStopId: stop.id,
				billingCycle,
				returnUrl: `${getComfyPlatformBaseUrl()}/payment/success`,
				cancelUrl: `${getComfyPlatformBaseUrl()}/payment/failed`,
				confirmReactivation,
				prorationAt: previewData.value?.is_immediate ? previewData.value.proration_at : void 0,
				attemptStartedAt
			}).finally(stopReleasing);
			if (response) {
				linkSubmittingJourneyToOperation(submittingJourney, response.billing_op_id);
				trackWorkspaceCheckoutStarted({
					tier: "team",
					cycle: billingCycle,
					checkoutType,
					billingOpId: response.billing_op_id,
					paymentIntentSource
				});
			}
			await handleSubscribeResponse(response, {
				tier: "team",
				cycle: billingCycle,
				checkoutType,
				attemptStartedAt
			}, true, mutationToken);
			activeCheckoutAttemptStartedAt = void 0;
		} catch (error) {
			if (hasErrorCode(error, "REACTIVATION_CONFIRMATION_REQUIRED") && await refreshPreviewOnReactivationBlock(planSlug, { teamCreditStopId: stop.id })) return;
			trackSubscriptionFailure({
				tier: "team",
				cycle: billingCycle,
				checkoutType,
				attemptStartedAt: activeCheckoutAttemptStartedAt
			}, error);
			activeCheckoutAttemptStartedAt = void 0;
			if (await recoverOutstandingPayment(error)) return;
			if (await refreshExpiredProrationQuote(error, planSlug, { teamCreditStopId: stop.id })) return;
			showSubscribeError(error);
		} finally {
			releaseSubmit(mutationToken);
		}
	}
	async function handleResubscribe() {
		if (!canReactivatePlan.value) return;
		if (openHostedBillingTab("subscription", { source: paymentIntentSource })) {
			emit("close", false);
			return;
		}
		const source = "pricing_dialog";
		const startedAt = Date.now();
		const isWorkspaceResubscribe = shouldUseWorkspaceBilling.value;
		telemetry?.trackResubscribeClicked({
			source,
			payment_intent_source: paymentIntentSource
		});
		telemetry?.trackBillingEvent({
			operation: "resubscribe",
			stage: "started",
			outcome: "pending",
			source,
			payment_intent_source: paymentIntentSource
		});
		isResubscribing.value = true;
		try {
			await resubscribe({ source });
			if (isWorkspaceResubscribe) telemetry?.trackBillingEvent({
				operation: "resubscribe",
				stage: "succeeded",
				outcome: "success",
				source,
				payment_intent_source: paymentIntentSource,
				duration_ms: Date.now() - startedAt
			});
			toast.success(t("subscription.resubscribeSuccess"), { duration: 5e3 });
			emit("close", true);
		} catch (error) {
			telemetry?.trackBillingEvent({
				operation: "resubscribe",
				stage: "failed",
				outcome: "failure",
				source,
				payment_intent_source: paymentIntentSource,
				failure_category: categorizeBillingApiError(error),
				...isWorkspaceResubscribe && { duration_ms: Date.now() - startedAt }
			});
			toast.error(t("g.error"), { description: getErrorMessage(error) ?? t("subscription.resubscribeFailed") });
		} finally {
			isResubscribing.value = false;
		}
	}
	return {
		checkoutStep,
		isLoadingPreview,
		loadingTier,
		isSubscribing,
		isResubscribing,
		previewData,
		reactivationRequired,
		selectedTierKey,
		selectedTeamStop,
		selectedBillingCycle,
		activeCheckoutActionUrl,
		authenticationState,
		parkedCheckoutRecovery,
		isPolling,
		paymentCancelable,
		isCancelingPayment,
		cancelPaymentError,
		cancelPayment,
		isTeamCheckout,
		previewVariant,
		handleSubscribeClick,
		handleSubscribeTeamClick,
		handleBackToPricing,
		handleSuccessClose,
		handleAddCreditCard: handleSubscription,
		handleConfirmTransition: handleSubscription,
		handleTeamSubscribe: handleTeamSubscription,
		handleResubscribe
	};
}
//#endregion
//#region src/platform/billing/composables/useCheckoutCopy.ts
/**
* The app's translations and catalog for the shared checkout steps.
* Sentences that wrap an element around a placeholder keep their `{name}`
* tokens for the component to split.
*/
function useCheckoutCopy() {
	const { t } = useI18n();
	const keepTokens = (keys) => Object.fromEntries(keys.map((key) => [key, `{${key}}`]));
	const reactivationTokens = keepTokens([
		"plan",
		"date",
		"newPlan",
		"nextDate",
		"amount"
	]);
	const copy = computed(() => ({
		back: t("g.back"),
		usdPerMonth: t("subscription.usdPerMonth"),
		billedMonthly: t("subscription.billedMonthly"),
		billedYearly: (total) => t("subscription.billedYearly", { total }),
		eachMonthCreditsRefill: t("subscription.preview.eachMonthCreditsRefill"),
		eachYearCreditsRefill: t("subscription.preview.eachYearCreditsRefill"),
		totalDueToday: t("subscription.preview.totalDueToday"),
		renewsAt: (amount, date) => t("subscription.preview.renewsAt", {
			amount,
			date
		}),
		renewsAtAmount: (amount) => t("subscription.preview.renewsAtAmount", { amount }),
		discount: {
			plan: t("subscription.preview.discount.plan"),
			promotion: t("subscription.preview.discount.promotion")
		},
		promoCodePlaceholder: t("subscription.preview.promoCodePlaceholder"),
		applyPromoCode: t("subscription.preview.applyPromoCode"),
		reconciliationTitle: t("billingOperation.reconciliationTitle"),
		reconciliationDetail: t("billingOperation.reconciliationDetail"),
		authenticationFailedDetail: t("billingOperation.authenticationFailedDetail"),
		pendingVerificationDetail: t("subscription.preview.pendingVerificationDetail"),
		completeVerification: t("subscription.preview.completeVerification"),
		cancelPaymentAndRetry: t("subscription.preview.cancelPaymentAndRetry"),
		confirmPayment: t("subscription.preview.confirmPayment"),
		startingToday: t("subscription.preview.startingToday"),
		parkedCheckoutDetail: t("subscription.preview.parkedCheckoutDetail"),
		completePayment: t("subscription.preview.completePayment"),
		payAndSubscribe: t("subscription.preview.payAndSubscribe"),
		subscribeToPlan: (plan) => t("subscription.preview.subscribeToPlan", { plan }),
		confirmUpgradeTitle: t("subscription.preview.confirmUpgradeTitle"),
		confirmChangeTitle: t("subscription.preview.confirmChangeTitle"),
		switchesToday: t("subscription.preview.switchesToday"),
		startsOn: (date) => t("subscription.preview.startsOn", { date }),
		creditsYoullGetToday: t("subscription.preview.creditsYoullGetToday"),
		refillReplacesNote: t("subscription.preview.refillReplacesNote"),
		afterThat: t("subscription.preview.afterThat"),
		creditsRefillMonthlyTo: t("subscription.preview.creditsRefillMonthlyTo"),
		billedEachMonth: (amount) => t("subscription.preview.billedEachMonth", { amount }),
		discountComposition: t("subscription.preview.discountComposition"),
		quoteUnavailable: t("subscription.preview.quoteUnavailable"),
		confirmUpgradeCta: t("subscription.preview.confirmUpgradeCta"),
		confirmChange: t("subscription.preview.confirmChange"),
		reactivation: {
			title: t("subscription.preview.reactivation.title"),
			titleAnnual: t("subscription.preview.reactivation.titleAnnual"),
			upgradeBody: t("subscription.preview.reactivation.upgradeBody", reactivationTokens),
			downgradeBody: t("subscription.preview.reactivation.downgradeBody", reactivationTokens),
			durationChangeBody: t("subscription.preview.reactivation.durationChangeBody", reactivationTokens),
			durationChangeBodyMonthly: t("subscription.preview.reactivation.durationChangeBodyMonthly", reactivationTokens),
			withoutRenewalDate: {
				upgradeBody: t("subscription.preview.reactivation.withoutRenewalDate.upgradeBody", reactivationTokens),
				downgradeBody: t("subscription.preview.reactivation.withoutRenewalDate.downgradeBody", reactivationTokens),
				durationChangeBody: t("subscription.preview.reactivation.withoutRenewalDate.durationChangeBody", reactivationTokens),
				durationChangeBodyMonthly: t("subscription.preview.reactivation.withoutRenewalDate.durationChangeBodyMonthly", reactivationTokens)
			},
			confirmButton: t("subscription.preview.reactivation.confirmButton"),
			confirmButtonWithCharge: (amount) => t("subscription.preview.reactivation.confirmButtonWithCharge", { amount }),
			checkboxLabel: (amount) => t("subscription.preview.reactivation.checkboxLabel", { amount })
		},
		savedMethod: {
			savedPaymentMethod: t("subscription.preview.savedPaymentMethod"),
			changePaymentMethod: t("subscription.preview.changePaymentMethod"),
			addNewPaymentMethod: t("subscription.preview.addNewPaymentMethod"),
			alipay: t("subscription.preview.alipay"),
			selectLabel: t("g.singleSelectDropdown")
		},
		terms: {
			agreement: t("subscription.preview.termsAgreement", keepTokens(["terms", "privacy"])),
			terms: t("subscription.preview.terms"),
			privacyPolicy: t("subscription.preview.privacyPolicy")
		},
		payment: {
			paymentMethod: t("subscription.preview.paymentMethod"),
			methodChoice: t("subscription.preview.stripeMethodChoice"),
			billingAddress: t("subscription.preview.billingAddress"),
			alipayRenewalNote: t("subscription.preview.alipayRenewalNote"),
			unavailable: t("subscription.preview.stripeUnavailable"),
			genericError: t("g.error")
		}
	}));
	const successCopy = computed(() => ({
		allSet: t("subscription.success.allSet"),
		planUpdated: t("subscription.success.planUpdated"),
		receiptEmailed: t("subscription.success.receiptEmailed"),
		usdPerMonth: t("subscription.usdPerMonth"),
		usdPerYear: t("subscription.usdPerYear"),
		perMonth: t("subscription.perMonth"),
		perYear: t("subscription.perYear"),
		promoApplied: (code) => t("subscription.success.promoApplied", { code }),
		promoRenews: (amount, date) => t("subscription.success.promoRenews", {
			amount,
			date
		}),
		close: t("g.close")
	}));
	function checkoutPlan(tierKey, teamPlan) {
		if (teamPlan) return {
			name: t("subscription.teamPlan.name"),
			monthlyPriceUsd: {
				monthly: teamPlan.discountedUsd,
				yearly: teamPlan.discountedUsd
			},
			monthlyCredits: teamPlan.credits,
			yearlyChargeUsd: teamPlan.periodChargeUsd?.yearly,
			pricedByQuote: false
		};
		return {
			name: t(`subscription.tiers.${tierKey}.name`),
			monthlyPriceUsd: {
				monthly: tierKey ? getTierPrice(tierKey, false) : 0,
				yearly: tierKey ? getTierPrice(tierKey, true) : 0
			},
			monthlyCredits: tierKey ? getTierCredits(tierKey) ?? 0 : 0,
			pricedByQuote: true
		};
	}
	return {
		copy,
		successCopy,
		checkoutPlan
	};
}
//#endregion
//#region src/platform/billing/components/SubscriptionAddPaymentPreviewWorkspace.vue
var SubscriptionAddPaymentPreviewWorkspace_default = /* @__PURE__ */ defineComponent({
	__name: "SubscriptionAddPaymentPreviewWorkspace",
	props: {
		tierKey: {},
		billingCycle: { default: "monthly" },
		isLoading: {
			type: Boolean,
			default: false
		},
		previewData: { default: null },
		teamPlan: { default: null },
		actionUrl: { default: null },
		authenticationState: { default: null },
		parkedCheckoutRecovery: {
			type: Boolean,
			default: false
		}
	},
	emits: ["addCreditCard", "back"],
	setup(__props, { emit: __emit }) {
		/**
		* The cloud app's binding of the shared new-subscription confirm: its tier
		* and team-stop catalog and its translations (ADR BILLING-WEB-0038).
		*/
		const emit = __emit;
		const { locale } = useI18n();
		const { copy, checkoutPlan } = useCheckoutCopy();
		const plan = computed(() => checkoutPlan(__props.tierKey, __props.teamPlan));
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(CheckoutSubscribeConfirm_default), {
				plan: plan.value,
				copy: unref(copy),
				locale: unref(locale),
				"publishable-key": "",
				"billing-cycle": __props.billingCycle,
				"is-loading": __props.isLoading,
				"preview-data": __props.previewData,
				"action-url": __props.actionUrl,
				"authentication-state": __props.authenticationState,
				"parked-checkout-recovery": __props.parkedCheckoutRecovery,
				onAddCreditCard: _cache[0] || (_cache[0] = ($event) => emit("addCreditCard")),
				onBack: _cache[1] || (_cache[1] = ($event) => emit("back"))
			}, null, 8, [
				"plan",
				"copy",
				"locale",
				"billing-cycle",
				"is-loading",
				"preview-data",
				"action-url",
				"authentication-state",
				"parked-checkout-recovery"
			]);
		};
	}
});
//#endregion
//#region src/platform/billing/components/SubscriptionSuccessWorkspace.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = {
	key: 0,
	class: "mt-4 flex w-full flex-col gap-2"
};
var _hoisted_2 = { class: "m-0 text-base font-normal" };
var _hoisted_3 = { class: "m-0 text-muted-foreground" };
var _hoisted_4 = { "aria-live": "polite" };
//#endregion
//#region src/platform/billing/components/SubscriptionSuccessWorkspace.vue
var SubscriptionSuccessWorkspace_default = /* @__PURE__ */ defineComponent({
	__name: "SubscriptionSuccessWorkspace",
	props: {
		tierKey: {},
		previewData: { default: null },
		teamPlan: { default: null },
		billingCycle: { default: "monthly" },
		promoApplied: { default: null }
	},
	emits: ["close"],
	setup(__props) {
		/**
		* The cloud app's binding of the shared success step, plus the team invite
		* that follows a multi-seat upgrade (ADR BILLING-WEB-0038).
		*/
		const { locale } = useI18n();
		const { successCopy, checkoutPlan } = useCheckoutCopy();
		const { maxSeats, occupiedSeats } = useBillingContext();
		const inviteFormMaxSeats = computed(() => maxSeats.value);
		const inviteFormOccupiedSeats = computed(() => occupiedSeats.value);
		const showInviteBlock = computed(() => maxSeats.value === 0 || (maxSeats.value ?? 0) > 1);
		const invitedEmails = ref([]);
		const invitedMessage = ref();
		const inviteForm = ref();
		const canSendInvites = computed(() => maxSeats.value !== null && occupiedSeats.value !== null && (inviteForm.value?.canSubmit ?? false));
		const isSendingInvites = computed(() => inviteForm.value?.loading ?? false);
		function handleSendInvites() {
			if (maxSeats.value === null || occupiedSeats.value === null) return;
			inviteForm.value?.submit()?.catch(console.error);
		}
		async function onInvited(emails) {
			invitedEmails.value = emails;
			await nextTick();
			invitedMessage.value?.focus();
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(CheckoutSuccess_default), {
				plan: unref(checkoutPlan)(__props.tierKey, __props.teamPlan),
				copy: unref(successCopy),
				locale: unref(locale),
				"preview-data": __props.previewData,
				"billing-cycle": __props.billingCycle,
				"promo-applied": __props.promoApplied,
				"close-demoted": showInviteBlock.value && invitedEmails.value.length === 0,
				onClose: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("close"))
			}, {
				details: withCtx(() => [showInviteBlock.value ? (openBlock(), createElementBlock("div", _hoisted_1, [
					createBaseVNode("h3", _hoisted_2, toDisplayString(_ctx.$t("subscription.success.inviteTitle")), 1),
					createBaseVNode("p", _hoisted_3, toDisplayString(_ctx.$t("subscription.success.inviteSubtext")), 1),
					createBaseVNode("div", _hoisted_4, [invitedEmails.value.length > 0 ? (openBlock(), createElementBlock("p", {
						key: 0,
						ref_key: "invitedMessage",
						ref: invitedMessage,
						tabindex: "-1",
						class: "m-0 text-success"
					}, toDisplayString(_ctx.$t("workspacePanel.inviteMemberDialog.invitedMessage", { emails: invitedEmails.value.join(", ") }, invitedEmails.value.length)), 513)) : (openBlock(), createBlock(InviteMembersForm_default, {
						key: 1,
						ref_key: "inviteForm",
						ref: inviteForm,
						"show-submit": false,
						source: "post_upgrade_success",
						"submit-label": _ctx.$t("subscription.success.sendInvites"),
						placeholder: _ctx.$t("subscription.success.inviteEmailsPlaceholder"),
						"max-seats": inviteFormMaxSeats.value,
						"occupied-seats": inviteFormOccupiedSeats.value,
						onSubmitted: onInvited
					}, null, 8, [
						"submit-label",
						"placeholder",
						"max-seats",
						"occupied-seats"
					]))])
				])) : createCommentVNode("", true)]),
				actions: withCtx(() => [showInviteBlock.value && invitedEmails.value.length === 0 ? (openBlock(), createBlock(Button_default, {
					key: 0,
					variant: "tertiary",
					size: "lg",
					class: "w-full",
					disabled: !canSendInvites.value,
					loading: isSendingInvites.value,
					onClick: handleSendInvites
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("subscription.success.sendInvites")), 1)]),
					_: 1
				}, 8, ["disabled", "loading"])) : createCommentVNode("", true)]),
				_: 1
			}, 8, [
				"plan",
				"copy",
				"locale",
				"preview-data",
				"billing-cycle",
				"promo-applied",
				"close-demoted"
			]);
		};
	}
});
//#endregion
//#region src/platform/billing/components/SubscriptionTransitionPreviewWorkspace.vue
var SubscriptionTransitionPreviewWorkspace_default = /* @__PURE__ */ defineComponent({
	__name: "SubscriptionTransitionPreviewWorkspace",
	props: {
		previewData: {},
		isLoading: {
			type: Boolean,
			default: false
		},
		teamPlan: { default: null },
		actionUrl: { default: null },
		forceReactivation: {
			type: Boolean,
			default: false
		},
		authenticationState: { default: null },
		paymentCancelable: {
			type: Boolean,
			default: false
		},
		cancelingPayment: {
			type: Boolean,
			default: false
		},
		cancelPaymentError: { default: null }
	},
	emits: [
		"confirm",
		"back",
		"cancelPayment"
	],
	setup(__props, { emit: __emit }) {
		/**
		* The cloud app's binding of the shared plan-change confirm: its tier names
		* and credits, its translations, and the subscription status that decides
		* whether the change reactivates a cancelled plan (ADR BILLING-WEB-0038).
		*/
		const emit = __emit;
		const { locale, t, te } = useI18n();
		const { copy } = useCheckoutCopy();
		const { subscription } = useBillingContext();
		function formatTierName(tier) {
			const nameKey = `subscription.tiers.${tier.toLowerCase()}.name`;
			if (te(nameKey)) return t(nameKey);
			return tier.toLowerCase().split(/[_-]+/).filter(Boolean).map((word) => word.charAt(0).toUpperCase() + word.slice(1)).join(" ");
		}
		function tierMonthlyCredits(tier) {
			const tierKey = toTierKey(tier);
			return tierKey ? getTierCredits(tierKey) ?? 0 : 0;
		}
		const plan = computed(() => __props.teamPlan ? {
			name: t("subscription.teamPlan.name"),
			monthlyCredits: __props.teamPlan.credits
		} : {
			name: formatTierName(__props.previewData.new_plan.tier),
			monthlyCredits: tierMonthlyCredits(__props.previewData.new_plan.tier)
		});
		const currentTierName = computed(() => {
			const tier = __props.previewData.current_plan?.tier;
			if (!tier) return "";
			return tier.toUpperCase() === "TEAM" ? t("subscription.teamPlan.name") : formatTierName(tier);
		});
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(CheckoutTransitionConfirm_default), {
				"preview-data": __props.previewData,
				plan: plan.value,
				"current-plan-name": currentTierName.value,
				copy: unref(copy),
				locale: unref(locale),
				"subscription-loaded": unref(subscription) !== null,
				"subscription-cancelled": unref(subscription)?.isCancelled ?? false,
				"subscription-end-date": unref(subscription)?.endDate,
				"is-loading": __props.isLoading,
				"action-url": __props.actionUrl,
				"force-reactivation": __props.forceReactivation,
				"authentication-state": __props.authenticationState,
				"payment-cancelable": __props.paymentCancelable,
				"canceling-payment": __props.cancelingPayment,
				"cancel-payment-error": __props.cancelPaymentError,
				onCancelPayment: _cache[0] || (_cache[0] = ($event) => emit("cancelPayment")),
				onConfirm: _cache[1] || (_cache[1] = ($event) => emit("confirm", $event)),
				onBack: _cache[2] || (_cache[2] = ($event) => emit("back"))
			}, null, 8, [
				"preview-data",
				"plan",
				"current-plan-name",
				"copy",
				"locale",
				"subscription-loaded",
				"subscription-cancelled",
				"subscription-end-date",
				"is-loading",
				"action-url",
				"force-reactivation",
				"authentication-state",
				"payment-cancelable",
				"canceling-payment",
				"cancel-payment-error"
			]);
		};
	}
});
//#endregion
export { TEAM_PLAN_CREDIT_STOPS as a, useSubscriptionCheckout as i, SubscriptionSuccessWorkspace_default as n, SubscriptionAddPaymentPreviewWorkspace_default as r, SubscriptionTransitionPreviewWorkspace_default as t };
