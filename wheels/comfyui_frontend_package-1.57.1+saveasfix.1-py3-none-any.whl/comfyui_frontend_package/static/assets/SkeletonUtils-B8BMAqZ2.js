import { _ as clone, v as retarget, y as retargetClip } from "./vendor-three-B-UiePqj.js";
export { clone, retarget, retargetClip };
