import "./rolldown-runtime-xtsTai4I.js";
import { F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, I as createBlock, P as computed, T as withKeys, U as createVNode, Wt as unref, Yt as toDisplayString, bt as watch, ct as openBlock, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as useToast } from "./toastStore-Dg65fRgL.js";
import { t as getErrorMessage } from "./errorUtil-DoQyAUQC.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
import { t as Input_default } from "./Input-12QxL1XI.js";
import { o as formatUsdFromCents } from "./creditsUtil-DxLnYjvD.js";
import { t as AppDialogPanel_default } from "./AppDialogPanel-BklaJBTn.js";
//#region src/platform/billing/components/dialogs/DowngradeRemoveMembersDialogContent.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "m-0" };
var _hoisted_2 = { class: "flex flex-col gap-2" };
//#endregion
//#region src/platform/billing/components/dialogs/DowngradeRemoveMembersDialogContent.vue
var DowngradeRemoveMembersDialogContent_default = /* @__PURE__ */ defineComponent({
	__name: "DowngradeRemoveMembersDialogContent",
	props: {
		planName: {},
		planSlug: {},
		requiresRemoval: {
			type: Boolean,
			default: false
		},
		requiresReactivation: {
			type: Boolean,
			default: false
		},
		chargeCents: { default: 0 },
		onConfirm: { type: Function }
	},
	setup(__props) {
		const { t } = useI18n();
		const dialogStore = useDialogStore();
		const toast = useToast();
		const phrase = t("subscription.downgrade.confirmationPhrase");
		const typedValue = ref("");
		const isLoading = ref(false);
		watch([() => __props.requiresReactivation, () => __props.chargeCents], () => {
			typedValue.value = "";
		});
		const isConfirmed = computed(() => typedValue.value === phrase);
		const chargeDisplay = computed(() => `$${formatUsdFromCents({ cents: __props.chargeCents })}`);
		const bodyText = computed(() => {
			if (__props.requiresRemoval && __props.requiresReactivation) return t("subscription.downgrade.bodyRemovalAndReactivation", { amount: chargeDisplay.value });
			if (__props.requiresReactivation) return t("subscription.downgrade.bodyReactivation", { amount: chargeDisplay.value });
			return t("subscription.downgrade.body");
		});
		function onClose() {
			if (isLoading.value) return;
			dialogStore.closeDialog({ key: "downgrade-remove-members" });
		}
		async function onConfirmDowngrade() {
			if (!isConfirmed.value || isLoading.value) return;
			isLoading.value = true;
			try {
				await __props.onConfirm(__props.planSlug, __props.requiresReactivation);
				dialogStore.closeDialog({ key: "downgrade-remove-members" });
			} catch (error) {
				toast.error(t("subscription.downgrade.failed"), { description: getErrorMessage(error) ?? t("g.unknownError") });
			} finally {
				isLoading.value = false;
			}
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(AppDialogPanel_default, {
				"body-class": "flex flex-col gap-4 text-sm text-muted-foreground",
				class: "w-full max-w-[400px]",
				onClose
			}, {
				title: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("subscription.downgrade.title", { plan: __props.planName })), 1)]),
				footer: withCtx(() => [createVNode(Button_default, {
					variant: "muted-textonly",
					disabled: isLoading.value,
					onClick: onClose
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("g.cancel")), 1)]),
					_: 1
				}, 8, ["disabled"]), createVNode(Button_default, {
					variant: "destructive",
					size: "lg",
					disabled: !isConfirmed.value,
					loading: isLoading.value,
					onClick: onConfirmDowngrade
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("subscription.downgrade.confirm")), 1)]),
					_: 1
				}, 8, ["disabled", "loading"])]),
				default: withCtx(() => [createBaseVNode("p", _hoisted_1, toDisplayString(bodyText.value), 1), createBaseVNode("label", _hoisted_2, [createTextVNode(toDisplayString(_ctx.$t("subscription.downgrade.confirmationPrompt", { phrase: unref(phrase) })) + " ", 1), createVNode(Input_default, {
					modelValue: typedValue.value,
					"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => typedValue.value = $event),
					type: "text",
					placeholder: unref(phrase),
					disabled: isLoading.value,
					autofocus: "",
					onKeyup: withKeys(onConfirmDowngrade, ["enter"])
				}, null, 8, [
					"modelValue",
					"placeholder",
					"disabled"
				])])]),
				_: 1
			});
		};
	}
});
//#endregion
export { DowngradeRemoveMembersDialogContent_default as default };
