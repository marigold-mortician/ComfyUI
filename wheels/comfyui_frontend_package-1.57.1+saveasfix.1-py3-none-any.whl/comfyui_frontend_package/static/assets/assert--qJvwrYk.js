import "./rolldown-runtime-xtsTai4I.js";
//#region src/base/assert.ts
var ASSERTION_FAILURE_PREFIX = "[Assertion failed]: ";
var reporter = null;
/**
* Register a reporter for assertion failures in non-DEV environments.
* Called once at app startup by platform/ or higher layers to wire in
* Sentry, toast notifications, etc.
*/
function setAssertReporter(fn, options = {}) {
	reporter = fn;
	fn !== null && options.forwardsToRum;
}
/**
* Centralized invariant assertion.
*
* - Always: console.error
* - DEV: throws (surfaces bugs immediately)
* - Otherwise: delegates to registered reporter (Sentry, toast, etc.)
*
* Reporters forward `message` to external telemetry, so it must be a static
* description of the invariant. Put diagnostic values in `context` so they do
* not affect grouping or deduplication.
*/
function assert(condition, message, context) {
	if (condition) return;
	const formatted = `${ASSERTION_FAILURE_PREFIX}${message}`;
	console.error(formatted);
	try {
		reporter?.(formatted, context);
	} catch (error) {
		console.error("[Assertion reporter failed]", error);
	}
}
//#endregion
export { setAssertReporter as n, assert as t };
