import "./rolldown-runtime-xtsTai4I.js";
import { t as isPlainObject } from "./isPlainObject-6prWdO5v.js";
//#region src/platform/remote/comfyui/errors.ts
/** Code reported when an error payload carries no machine-readable code. */
var UNKNOWN_ERROR_CODE = "UNKNOWN_ERROR";
/**
* Upper bound on a raw non-JSON body surfaced as the user-facing message.
* Short text/plain proxy errors (e.g. "upstream connect error") stay useful;
* oversized bodies (e.g. a full HTML gateway page) degrade to the clean
* status-derived fallback instead of dumping markup into a toast.
*/
var MAX_RAW_MESSAGE_LENGTH = 500;
/**
* A body opening with a tag is a markup document, never a usable message —
* however short the page happens to be. Anchored so prose that merely
* mentions a bracketed token (e.g. "connection to <backend-01> refused")
* still surfaces.
*/
var MARKUP_DOCUMENT = /^<[a-z!/]/i;
var CODE_SHAPE = /^[A-Z][A-Z0-9_]*$/;
/** Refusal of a legacy `/customers/*` call for a workspace not on the legacy rail. */
function isWorkspaceBillingRequiredError(err) {
	return err instanceof Error && "status" in err && err.status === 409 && "code" in err && err.code === "WORKSPACE_BILLING_REQUIRED";
}
/**
* Flat `{ error, message }` bodies (the /customers/* shape) carry the code in
* `error`; a prose value there (e.g. "Forbidden") is not a code.
*/
function codeFromRecord(record) {
	const raw = record.code ?? (typeof record.error === "string" && CODE_SHAPE.test(record.error) ? record.error : void 0);
	return typeof raw === "string" && raw !== "" ? raw : UNKNOWN_ERROR_CODE;
}
function usableText(body, fallbackMessage) {
	const trimmed = body.trim();
	return trimmed !== "" && trimmed.length <= MAX_RAW_MESSAGE_LENGTH && !MARKUP_DOCUMENT.test(trimmed) ? trimmed : fallbackMessage;
}
/**
* Coerce an already-parsed error body into the canonical
* `ErrorResponse { code, message, details? }` shape.
*
* The API emits this shape for all error responses; this helper is the
* single place that tolerates legacy/partial flat `ErrorResponse` payloads
* (missing `code`, missing `message`, non-object bodies) so call sites never
* shape-sniff. Nested/domain error envelopes (e.g. `PromptExecutionError`)
* are out of scope.
*
* @param body - The parsed response body (any JSON value, or `undefined`)
* @param fallbackMessage - Used when the body carries no usable message
*/
function errorResponseFromBody(body, fallbackMessage) {
	if (typeof body === "string") return {
		code: UNKNOWN_ERROR_CODE,
		message: usableText(body, fallbackMessage)
	};
	const record = isPlainObject(body) ? body : {};
	const code = codeFromRecord(record);
	const message = typeof record.message === "string" && record.message !== "" ? record.message : fallbackMessage;
	const details = isPlainObject(record.details) ? record.details : void 0;
	return details !== void 0 ? {
		code,
		message,
		details
	} : {
		code,
		message
	};
}
/**
* Parse JSON when possible, otherwise surface the raw text. A blank or
* whitespace-only body yields `undefined` so callers fall through to a
* status-derived fallback.
*/
function parseJsonOrText(text) {
	if (text.trim() === "") return void 0;
	try {
		return JSON.parse(text);
	} catch {
		return text;
	}
}
/**
* Parse a failed HTTP `Response` into the canonical
* `ErrorResponse { code, message, details? }` shape.
*
* Never throws: the body is read as text and JSON-parsed when possible, so
* plain-text error bodies (e.g. from a proxy) survive as the message. Empty
* or unreadable bodies degrade to a status-derived message and the
* `UNKNOWN_ERROR` code.
*/
async function parseErrorResponse(response) {
	const fallbackMessage = response.statusText || `HTTP ${response.status}`;
	return errorResponseFromBody(parseJsonOrText(await response.text().catch((err) => {
		console.warn("parseErrorResponse: failed to read response body", err);
		return "";
	})), fallbackMessage);
}
//#endregion
export { parseErrorResponse as i, errorResponseFromBody as n, isWorkspaceBillingRequiredError as r, UNKNOWN_ERROR_CODE as t };
