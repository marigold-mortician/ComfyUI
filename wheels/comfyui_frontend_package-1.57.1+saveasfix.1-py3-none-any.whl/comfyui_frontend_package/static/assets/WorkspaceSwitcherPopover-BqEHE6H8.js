import "./rolldown-runtime-xtsTai4I.js";
import { t as useBillingContext } from "./useBillingContext-uo5ceiak.js";
import { t as useTeamWorkspaceStore } from "./teamWorkspaceStore-BNm5cZOK.js";
import { F as createBaseVNode, G as defineComponent, H as createTextVNode, Kt as normalizeClass, L as createCommentVNode, O as Fragment, P as computed, R as createElementBlock, U as createVNode, Wt as unref, Yt as toDisplayString, ct as openBlock, p as storeToRefs, ut as renderList, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { a as TooltipTrigger_default, o as TooltipContent_default, s as Tooltip_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { t as useWorkspaceTierLabel } from "./useWorkspaceTierLabel-CvZFdEik.js";
import { t as WorkspaceProfilePic_default } from "./WorkspaceProfilePic-BHe-oqM-.js";
import { t as useWorkspaceSwitch } from "./useWorkspaceSwitch-7YpNV13f.js";
//#region src/platform/workspace/components/WorkspaceSwitcherPopover.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "flex max-h-96 w-80 flex-col overflow-hidden rounded-lg" };
var _hoisted_2 = {
	class: "flex scrollbar-custom min-h-0 flex-1 flex-col",
	"data-testid": "workspace-switcher-list"
};
var _hoisted_3 = {
	key: 0,
	class: "flex flex-col gap-2 p-2"
};
var _hoisted_4 = ["disabled", "onClick"];
var _hoisted_5 = { class: "flex min-w-0 flex-1 flex-col items-start gap-1" };
var _hoisted_6 = { class: "flex max-w-full min-w-0 items-center gap-1.5" };
var _hoisted_7 = ["title"];
var _hoisted_8 = {
	key: 0,
	class: "shrink-0 rounded-full bg-foreground px-1 py-0.5 text-2xs font-bold text-background uppercase"
};
var _hoisted_9 = { class: "text-xs text-muted-foreground" };
var _hoisted_10 = {
	key: 0,
	class: "pi pi-check shrink-0 text-sm text-foreground"
};
var _hoisted_11 = {
	key: 0,
	class: "flex shrink-0 items-center gap-2 px-4 py-2 text-xs text-muted-foreground"
};
var _hoisted_12 = {
	key: 1,
	class: "shrink-0 border-t p-2"
};
var _hoisted_13 = { class: "flex min-w-0 flex-1 flex-col text-sm text-muted-foreground" };
var _hoisted_14 = { key: 0 };
var _hoisted_15 = { key: 1 };
//#endregion
//#region src/platform/workspace/components/WorkspaceSwitcherPopover.vue
var WorkspaceSwitcherPopover_default = /* @__PURE__ */ defineComponent({
	__name: "WorkspaceSwitcherPopover",
	emits: ["select", "create"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const { t } = useI18n();
		const { switchWorkspace } = useWorkspaceSwitch();
		const { subscription } = useBillingContext();
		const { formatTierName, getTierLabel } = useWorkspaceTierLabel();
		const currentSubscriptionTierName = computed(() => {
			const tier = subscription.value?.tier;
			if (!tier) return "";
			const isYearly = subscription.value?.duration === "ANNUAL";
			return formatTierName(tier, isYearly);
		});
		const workspaceStore = useTeamWorkspaceStore();
		const { workspaceId, workspaces, canCreateWorkspace, workspacesManagedByOrganization, isFetchingWorkspaces, isSwitching } = storeToRefs(workspaceStore);
		const availableWorkspaces = computed(() => workspaces.value.map((w) => ({
			id: w.id,
			name: w.name,
			type: w.type,
			role: w.role,
			isSubscribed: w.isSubscribed,
			subscriptionPlan: w.subscriptionPlan,
			subscriptionTier: w.subscriptionTier
		})));
		function isCurrentWorkspace(workspace) {
			return workspace.id === workspaceId.value;
		}
		function getRoleLabel(role) {
			if (role === "owner") return t("workspaceSwitcher.roleOwner");
			if (role === "member") return t("workspaceSwitcher.roleMember");
			return "";
		}
		function resolveTierLabel(workspace) {
			if (workspace.type !== "personal") return null;
			if (isCurrentWorkspace(workspace)) return currentSubscriptionTierName.value || null;
			return getTierLabel(workspace);
		}
		async function handleSelectWorkspace(workspace) {
			if (await switchWorkspace(workspace.id)) emit("select", workspace);
		}
		function handleCreateWorkspace() {
			emit("create");
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1, [
				createBaseVNode("div", _hoisted_2, [unref(isFetchingWorkspaces) ? (openBlock(), createElementBlock("div", _hoisted_3, [(openBlock(), createElementBlock(Fragment, null, renderList(2, (i) => {
					return createBaseVNode("div", {
						key: i,
						class: "flex h-[54px] animate-pulse items-center gap-2 rounded-sm px-2 py-4"
					}, [..._cache[1] || (_cache[1] = [createBaseVNode("div", { class: "size-8 rounded-full bg-secondary" }, null, -1), createBaseVNode("div", { class: "flex flex-1 flex-col gap-1" }, [createBaseVNode("div", { class: "h-4 w-24 rounded-sm bg-secondary" }), createBaseVNode("div", { class: "h-3 w-16 rounded-sm bg-secondary" })], -1)])]);
				}), 64))])) : (openBlock(true), createElementBlock(Fragment, { key: 1 }, renderList(availableWorkspaces.value, (workspace) => {
					return openBlock(), createElementBlock("div", {
						key: workspace.id,
						class: "border-b p-2"
					}, [createBaseVNode("div", { class: normalizeClass(unref(cn)("group flex h-[54px] w-full items-center gap-2 rounded-sm px-2 py-4", "hover:bg-accent", isCurrentWorkspace(workspace) && "bg-secondary")) }, [createBaseVNode("button", {
						class: "flex min-w-0 flex-1 cursor-pointer items-center gap-2 border-none bg-transparent p-0",
						disabled: !unref(false) && unref(isSwitching),
						onClick: ($event) => handleSelectWorkspace(workspace)
					}, [
						createVNode(WorkspaceProfilePic_default, {
							class: "size-8 shrink-0 text-sm",
							"workspace-name": workspace.name,
							"subscription-tier": workspace.subscriptionTier
						}, null, 8, ["workspace-name", "subscription-tier"]),
						createBaseVNode("div", _hoisted_5, [createBaseVNode("div", _hoisted_6, [createBaseVNode("span", {
							title: workspace.name,
							class: "min-w-0 truncate text-sm text-foreground"
						}, toDisplayString(workspace.name), 9, _hoisted_7), resolveTierLabel(workspace) ? (openBlock(), createElementBlock("span", _hoisted_8, toDisplayString(resolveTierLabel(workspace)), 1)) : createCommentVNode("", true)]), createBaseVNode("span", _hoisted_9, toDisplayString(getRoleLabel(workspace.role)), 1)]),
						isCurrentWorkspace(workspace) ? (openBlock(), createElementBlock("i", _hoisted_10)) : createCommentVNode("", true)
					], 8, _hoisted_4)], 2)]);
				}), 128))]),
				!unref(false) ? (openBlock(), createElementBlock("div", _hoisted_11, [createVNode(Tooltip_default, null, {
					default: withCtx(() => [createVNode(TooltipTrigger_default, { "as-child": "" }, {
						default: withCtx(() => [..._cache[2] || (_cache[2] = [createBaseVNode("i", { class: "pi pi-info-circle text-xs" }, null, -1)])]),
						_: 1
					}), createVNode(TooltipContent_default, { side: "left" }, {
						default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspaceSwitcher.scopeTooltip")), 1)]),
						_: 1
					})]),
					_: 1
				}), createBaseVNode("span", null, toDisplayString(_ctx.$t("workspaceSwitcher.scopeCaption")), 1)])) : createCommentVNode("", true),
				unref(false) ? (openBlock(), createElementBlock("div", _hoisted_12, [createBaseVNode("div", {
					class: normalizeClass(unref(cn)("flex h-12 w-full items-center gap-2 rounded-sm p-2", unref(canCreateWorkspace) ? "cursor-pointer hover:bg-accent" : "cursor-default")),
					onClick: _cache[0] || (_cache[0] = ($event) => unref(canCreateWorkspace) && handleCreateWorkspace())
				}, [createBaseVNode("div", { class: normalizeClass(unref(cn)("flex size-8 items-center justify-center rounded-full bg-secondary", !unref(canCreateWorkspace) && "opacity-50")) }, [..._cache[3] || (_cache[3] = [createBaseVNode("i", { class: "pi pi-plus text-sm text-muted-foreground" }, null, -1)])], 2), createBaseVNode("div", _hoisted_13, [unref(canCreateWorkspace) ? (openBlock(), createElementBlock("span", _hoisted_14, toDisplayString(_ctx.$t("workspaceSwitcher.createWorkspace")), 1)) : (openBlock(), createElementBlock("span", _hoisted_15, toDisplayString(unref(workspacesManagedByOrganization) ? _ctx.$t("workspaceSwitcher.managedByOrganization") : _ctx.$t("workspaceSwitcher.maxWorkspacesReached")), 1))])], 2)])) : createCommentVNode("", true)
			]);
		};
	}
});
//#endregion
export { WorkspaceSwitcherPopover_default as t };
