import "./rolldown-runtime-xtsTai4I.js";
import { n as createRequestAuthorizer } from "./requestAuth-COoKVLz2.js";
import { A as createWebVisibilityPort, D as presentSsoRequired, f as useWorkspaceAuthStore, k as createWebCrossTabRefreshPort, t as useTeamWorkspaceStore } from "./teamWorkspaceStore-BNm5cZOK.js";
import { E as provideWebSessionRequests, F as SessionTokenError, I as createSessionTokenMint, M as deleteWebSession, N as readWebSession, P as revokeAllWebSessions, T as fetchOnWebSession, _ as webSessionUser, i as api, j as createWebSession, v as firebaseIdentity, w as WebSessionTokenError } from "./api-BdJmXw98.js";
import { Mt as onScopeDispose, P as computed, Rt as shallowRef, bt as watch, d as defineStore } from "./vendor-vue-core-CuN1excl.js";
import { Nr as createEventHook, Ur as until } from "./vendor-reka-ui-NRTk7aIV.js";
import { n as useTelemetry } from "./telemetry-IkzvF0TI.js";
import { S as object, T as string, a as _enum, f as discriminatedUnion, u as boolean, v as literal, x as number } from "./vendor-zod-Del_rmdp.js";
import { t as useToast } from "./toastStore-Dg65fRgL.js";
import { d as t } from "./i18n-BRluoVl-.js";
import { r as reportError } from "./reportError-BHgDVvfb.js";
import { t as useFeatureFlags } from "./useFeatureFlags-B3zg5FdZ.js";
import { a as trackSsoSignInCompleted, n as endSsoFlow } from "./ssoTelemetry-DZUrpShr.js";
import { l as webSessionTelemetryHooks } from "./telemetry-CRUTYyCh.js";
//#region packages/account-core/src/core/webSessionIdentity.ts
/**
* The session-backed identity source: boots a site from `GET /auth/session`
* and follows the server's answer. It keeps no record of past sessions, and
* the remembered provider login is an opaque port, so no provider leaks in.
*/
var read = { type: "read" };
var signOutLocally = { type: "sign_out_locally" };
function signOutDifferentLogin(session, rememberedUserId) {
	return rememberedUserId !== null && rememberedUserId !== session.user.id ? [signOutLocally] : [];
}
function settleSignedIn(session, rememberedUserId, outcome) {
	return {
		state: {
			phase: "signed_in",
			session
		},
		effects: [...signOutDifferentLogin(session, rememberedUserId), {
			type: "report",
			outcome
		}]
	};
}
function settleSignedOut(outcome) {
	return {
		state: {
			phase: "signed_out",
			outcome
		},
		effects: [...outcome === "revoked" ? [signOutLocally] : [], {
			type: "report",
			outcome
		}]
	};
}
function waitToRetry(failures) {
	return {
		state: {
			phase: "retry_wait",
			failures
		},
		effects: [{
			type: "schedule_retry",
			failures
		}]
	};
}
function isNoLiveSession(failure) {
	return failure.code === "NO_SESSION" || failure.code === "SESSION_EXPIRED";
}
function applyReadAnswered(failures, result, rememberedUserId) {
	if (result.status === "ok") return settleSignedIn(result.session, rememberedUserId, "signed_in");
	if (result.retryable) return waitToRetry(failures + 1);
	if (result.code === "SESSION_REVOKED") return settleSignedOut("revoked");
	if (!isNoLiveSession(result)) return settleSignedOut("signed_out");
	if (rememberedUserId === null) return settleSignedOut("signed_out");
	return {
		state: {
			phase: "restoring",
			failures
		},
		effects: [{
			type: "restore",
			expectedUserId: rememberedUserId
		}]
	};
}
function applyRestoreAnswered(failures, result, rememberedUserId) {
	if (result.status === "ok") return settleSignedIn(result.session, rememberedUserId, "restored");
	if (result.retryable) return waitToRetry(failures + 1);
	if (result.code === "SESSION_REVOKED") return settleSignedOut("revoked");
	return settleSignedOut("restore_failed");
}
function leaveAccount(outcome, effects = []) {
	return {
		state: {
			phase: "signed_out",
			outcome
		},
		effects: [...effects, {
			type: "account_changed",
			change: {
				reason: "signed_out",
				outcome
			}
		}]
	};
}
function replaceSession(held, session, effects = []) {
	const state = {
		phase: "signed_in",
		session
	};
	if (session.user.id === held.user.id) return {
		state,
		effects: []
	};
	return {
		state,
		effects: [...effects, {
			type: "account_changed",
			change: {
				reason: "user_changed",
				session
			}
		}]
	};
}
/** A read never signs out on doubt: only revoked or no live session does. */
function observeWhileSignedIn(state, result, rememberedUserId, restored, ownRead) {
	if (result.status === "ok") return replaceSession(state.session, result.session, signOutDifferentLogin(result.session, rememberedUserId));
	if (result.retryable) return {
		state,
		effects: []
	};
	if (result.code === "SESSION_REVOKED") return leaveAccount("revoked", ownRead ? [signOutLocally, { type: "report_signed_out_remotely" }] : [signOutLocally]);
	if (restored) return leaveAccount("restore_failed");
	if (!isNoLiveSession(result)) return {
		state,
		effects: []
	};
	if (rememberedUserId === null) return leaveAccount("signed_out");
	return {
		state,
		effects: [{
			type: "restore",
			expectedUserId: rememberedUserId
		}]
	};
}
function transitionSignedIn(state, event) {
	switch (event.type) {
		case "session_observed": return observeWhileSignedIn(state, event.result, event.rememberedUserId, false, event.from === "this_tab");
		case "restore_answered": return observeWhileSignedIn(state, event.result, event.rememberedUserId, true, true);
		case "session_created": return replaceSession(state.session, event.session);
		case "proof_missing": return leaveAccount("restore_failed");
		case "sign_out_requested": return leaveAccount("signed_out", [signOutLocally]);
		default: return {
			state,
			effects: []
		};
	}
}
function transitionRestoring(state, event) {
	switch (event.type) {
		case "restore_answered": return applyRestoreAnswered(state.failures, event.result, event.rememberedUserId);
		case "proof_missing": return settleSignedOut("restore_failed");
		case "proof_errored":
		case "login_errored": return waitToRetry(state.failures + 1);
		default: return {
			state,
			effects: []
		};
	}
}
function transitionBoot(state, event) {
	switch (state.phase) {
		case "reading":
			if (event.type === "login_errored") return waitToRetry(state.failures + 1);
			return event.type === "read_answered" ? applyReadAnswered(state.failures, event.result, event.rememberedUserId) : {
				state,
				effects: []
			};
		case "retry_wait": return event.type === "retry_due" ? {
			state: {
				...state,
				phase: "reading"
			},
			effects: [read]
		} : {
			state,
			effects: []
		};
		case "restoring": return transitionRestoring(state, event);
		default: return {
			state,
			effects: []
		};
	}
}
function transitionSettling(state, event) {
	switch (event.type) {
		case "session_observed": {
			const { result } = event;
			const adoptable = state.phase === "retry_wait" || state.phase === "signed_out" && event.from === "sibling_sign_in";
			if (result.status !== "ok" || !adoptable) return {
				state,
				effects: []
			};
			return {
				state: {
					phase: "signed_in",
					session: result.session
				},
				effects: signOutDifferentLogin(result.session, event.rememberedUserId)
			};
		}
		case "session_created": return {
			state: {
				phase: "signed_in",
				session: event.session
			},
			effects: []
		};
		case "sign_out_requested": return state.phase === "signed_out" ? {
			state,
			effects: []
		} : {
			state: {
				phase: "signed_out",
				outcome: "signed_out"
			},
			effects: [signOutLocally]
		};
		default: return transitionBoot(state, event);
	}
}
/** Pure: an event that means nothing in the current phase changes nothing. */
function transitionWebSessionIdentity(state, event) {
	switch (state.phase) {
		case "idle": return event.type === "boot" ? {
			state: {
				phase: "reading",
				failures: 0
			},
			effects: [read]
		} : {
			state,
			effects: []
		};
		case "api_key": return {
			state,
			effects: []
		};
		case "signed_in": return transitionSignedIn(state, event);
		default: return transitionSettling(state, event);
	}
}
var HEARTBEAT_KEY = "@comfyorg/account-core web-session heartbeat";
var HEARTBEAT_INTERVAL_MS = 6e5;
var zSharedResult = discriminatedUnion("status", [object({
	status: literal("ok"),
	session: object({
		user: object({
			id: string(),
			email: string(),
			name: string().optional(),
			emailVerified: boolean(),
			signInProvider: string().optional(),
			hasPersonalWorkspace: boolean().optional()
		}),
		csrfToken: string(),
		expiresAt: number(),
		absoluteExpiresAt: number()
	})
}), object({
	status: literal("error"),
	code: literal("SESSION_REVOKED"),
	retryable: literal(false)
})]);
/**
* Every tab of a site reads the same host-only cookie, so a sibling's answer
* is this tab's own session observed elsewhere; that is what makes adopting
* it safe. A per-tab session scope would break this assumption.
*/
var zSharedMessage = object({
	from: _enum([
		"heartbeat",
		"sign_in",
		"sign_out"
	]),
	result: zSharedResult
});
var revoked = {
	status: "error",
	code: "SESSION_REVOKED",
	retryable: false
};
var scheduleWithTimer = (run, delayMs) => {
	const timer = setTimeout(run, delayMs);
	return () => clearTimeout(timer);
};
function reportLocalSignOutFailure(error) {
	console.warn("webSessionIdentity: local sign-out failed", error);
}
function createApiKeyIdentity() {
	const state = { phase: "api_key" };
	return {
		getState: () => state,
		subscribe: (listener) => {
			listener(state);
			return () => void 0;
		},
		boot: () => void 0,
		signedIn: async () => ({
			status: "error",
			code: "SESSION_REQUEST_REFUSED",
			retryable: false
		}),
		signOut: async () => ({ status: "ok" }),
		refresh: async () => state,
		getEpoch: () => 0,
		dispose: () => void 0
	};
}
function createAccountIdentity(options, login) {
	const schedule = options.schedule ?? scheduleWithTimer;
	const retryBaseMs = options.retryBaseMs ?? 1e3;
	const retryMaxMs = options.retryMaxMs ?? 6e4;
	const heartbeat = options.heartbeat;
	const listeners = /* @__PURE__ */ new Set();
	let state = { phase: "idle" };
	let epoch = 0;
	let signOuts = 0;
	let signIns = 0;
	let liveSignIn = 0;
	let cancelRetry;
	let cancelBeat;
	let releaseLeadership;
	let stopWatching = [];
	let restoring = {
		epoch,
		settled: Promise.resolve()
	};
	function dispatch(event) {
		const next = transitionWebSessionIdentity(state, event);
		const changed = next.state !== state;
		state = next.state;
		next.effects.forEach(run);
		if (changed) listeners.forEach((listener) => listener(state));
		syncLeadership();
	}
	function publish(from, result) {
		heartbeat?.crossTab?.publishCredential(HEARTBEAT_KEY, {
			from,
			result
		});
	}
	async function answer(started, answered, request) {
		const result = await request();
		const remembered = await login.currentUserId().then((value) => ({ value }), () => void 0);
		if (started !== epoch) return;
		if (remembered === void 0 && result.status !== "ok") return dispatch({ type: "login_errored" });
		dispatch({
			...answered,
			result,
			rememberedUserId: remembered?.value ?? null
		});
	}
	function beat() {
		const started = epoch;
		return answer(started, {
			type: "session_observed",
			from: "this_tab"
		}, async () => {
			const result = await readWebSession(options.session);
			if ((result.status === "ok" || result.code === "SESSION_REVOKED") && started === epoch) publish("heartbeat", result);
			return result;
		});
	}
	function invalidatePendingSignIns() {
		signOuts += 1;
		liveSignIn = 0;
	}
	function adopt(message) {
		const parsed = zSharedMessage.safeParse(message);
		if (!parsed.success) return;
		const { from, result } = parsed.data;
		if (from === "sign_out") invalidatePendingSignIns();
		const observed = {
			type: "session_observed",
			from: `sibling_${from}`
		};
		answer(epoch, observed, async () => result);
	}
	function wantsBeat() {
		return stopWatching.length > 0 && state.phase === "signed_in" && heartbeat?.visibility.isVisible() === true;
	}
	function armBeat() {
		cancelBeat = schedule(() => {
			beat();
			armBeat();
		}, heartbeat?.intervalMs ?? HEARTBEAT_INTERVAL_MS);
	}
	function lead() {
		if (wantsBeat() && cancelBeat === void 0) armBeat();
	}
	function syncLeadership() {
		const wanted = wantsBeat();
		if (wanted && releaseLeadership === void 0) {
			const port = heartbeat?.crossTab;
			if (port) releaseLeadership = port.requestLeadership(HEARTBEAT_KEY, lead);
			else {
				releaseLeadership = () => void 0;
				lead();
			}
		} else if (!wanted && releaseLeadership !== void 0) {
			releaseLeadership();
			releaseLeadership = void 0;
			cancelBeat?.();
			cancelBeat = void 0;
		}
	}
	function watch() {
		if (heartbeat === void 0) return;
		const { visibility, crossTab } = heartbeat;
		stopWatching = [visibility.onChange((visible) => {
			if (visible && state.phase === "signed_in") beat();
			syncLeadership();
		}), ...crossTab ? [crossTab.onCredential(HEARTBEAT_KEY, adopt)] : []];
	}
	async function restore(started, expectedUserId) {
		const proof = await login.getProof().then((value) => ({ value }), () => void 0);
		if (started !== epoch) return;
		if (proof === void 0) return dispatch({ type: "proof_errored" });
		const { value } = proof;
		if (value === null) return dispatch({ type: "proof_missing" });
		await answer(started, { type: "restore_answered" }, () => createWebSession(options.session, async () => value, { expectedUserId }));
	}
	function run(effect) {
		switch (effect.type) {
			case "read":
				answer(epoch, { type: "read_answered" }, () => readWebSession(options.session));
				return;
			case "restore":
				restoring = {
					epoch,
					settled: restore(epoch, effect.expectedUserId)
				};
				return;
			case "schedule_retry":
				cancelRetry = schedule(() => {
					cancelRetry = void 0;
					dispatch({ type: "retry_due" });
				}, Math.min(retryBaseMs * 2 ** (effect.failures - 1), retryMaxMs));
				return;
			case "sign_out_locally":
				login.signOutLocally().catch(reportLocalSignOutFailure);
				return;
			default: notify(effect);
		}
	}
	function notify(effect) {
		switch (effect.type) {
			case "report":
				options.onBootstrap?.({
					outcome: effect.outcome,
					origin: options.origin
				});
				return;
			case "account_changed":
				epoch += 1;
				options.onAccountChanged?.({
					...effect.change,
					epoch
				});
				return;
			case "report_signed_out_remotely": options.onSignedOutRemotely?.({ origin: options.origin });
		}
	}
	function stopHeartbeat() {
		stopWatching.forEach((stop) => stop());
		stopWatching = [];
		syncLeadership();
	}
	return {
		getState: () => state,
		subscribe: (listener) => {
			listeners.add(listener);
			listener(state);
			return () => {
				listeners.delete(listener);
			};
		},
		boot: () => {
			if (state.phase !== "idle") return;
			watch();
			dispatch({ type: "boot" });
		},
		signedIn: async (getProof) => {
			const signOutsAtStart = signOuts;
			const signIn = ++signIns;
			const result = await createWebSession(options.session, getProof);
			if (result.status !== "ok") return result;
			if (signOuts !== signOutsAtStart) {
				if (liveSignIn > signIn) return revoked;
				const cleanup = await deleteWebSession(options.session);
				return cleanup.status === "ok" ? revoked : cleanup;
			}
			liveSignIn = signIn;
			dispatch({
				type: "session_created",
				session: result.session
			});
			publish("sign_in", result);
			return result;
		},
		signOut: async () => {
			invalidatePendingSignIns();
			dispatch({ type: "sign_out_requested" });
			const result = await deleteWebSession(options.session);
			if (result.status === "ok") publish("sign_out", revoked);
			return result;
		},
		refresh: async (expectedUserId) => {
			if (state.phase !== "signed_in") return state;
			if ((expectedUserId ?? state.session.user.id) !== state.session.user.id) return state;
			await beat();
			if (restoring.epoch === epoch) await restoring.settled;
			return state;
		},
		getEpoch: () => epoch,
		dispose: () => {
			epoch += 1;
			cancelRetry?.();
			cancelRetry = void 0;
			stopHeartbeat();
			state = { phase: "idle" };
			listeners.forEach((listener) => listener(state));
		}
	};
}
/** Inert until `boot()`: constructing it sends no request and arms no timer. */
function createWebSessionIdentity(options) {
	return options.principal.kind === "api_key" ? createApiKeyIdentity() : createAccountIdentity(options, options.principal.rememberedLogin);
}
//#endregion
//#region src/platform/auth/session/interactiveSignInMarker.ts
var STORAGE_KEY = "Comfy.WebSession.InteractiveSignIn";
var MAX_AGE_MS = 12e4;
var zMarker = object({
	uid: string(),
	at: number()
});
function clearInteractiveSignIn() {
	try {
		sessionStorage.removeItem(STORAGE_KEY);
	} catch {
		return;
	}
}
/** True once, and only for a fresh marker written for this Firebase user. */
function takeInteractiveSignIn(uid) {
	let json;
	try {
		const raw = sessionStorage.getItem(STORAGE_KEY);
		clearInteractiveSignIn();
		if (raw === null) return false;
		json = JSON.parse(raw);
	} catch {
		return false;
	}
	const marker = zMarker.safeParse(json);
	return marker.success && marker.data.uid === uid && Date.now() - marker.data.at >= 0 && Date.now() - marker.data.at <= MAX_AGE_MS;
}
//#endregion
//#region src/platform/auth/session/ssoReentryStorage.ts
var HINT_KEY = "Comfy.WebSession.SsoHint";
var ATTEMPT_KEY = "Comfy.WebSession.SsoReentryAt";
var ATTEMPT_WINDOW_MS = 3e5;
var SSO_SIGN_IN_PROVIDERS = /* @__PURE__ */ new Set(["saml.workos", "oidc.workos"]);
var zHint = object({ email: string().min(1) });
var zAttemptAt = number();
function parseJson(raw) {
	if (raw === null) return void 0;
	try {
		return JSON.parse(raw);
	} catch {
		return;
	}
}
function forgetSsoHint() {
	try {
		localStorage.removeItem(HINT_KEY);
	} catch {
		return;
	}
}
function isSsoSession(user) {
	return SSO_SIGN_IN_PROVIDERS.has(user.signInProvider ?? "");
}
/** Keyed on the provider the server reports, so only an SSO session leaves a hint. */
function rememberSignedInSession(user) {
	if (!isSsoSession(user)) {
		forgetSsoHint();
		return;
	}
	const hint = { email: user.email };
	try {
		localStorage.setItem(HINT_KEY, JSON.stringify(hint));
	} catch {
		return;
	}
}
function readSsoHint() {
	let raw;
	try {
		raw = localStorage.getItem(HINT_KEY);
	} catch {
		return null;
	}
	const hint = zHint.safeParse(parseJson(raw));
	return hint.success ? hint.data : null;
}
/** Unreadable storage counts as recent, so a tab that cannot remember never loops. */
function hasRecentSsoReentry(now = Date.now()) {
	let raw;
	try {
		raw = sessionStorage.getItem(ATTEMPT_KEY);
	} catch {
		return true;
	}
	const at = zAttemptAt.safeParse(parseJson(raw));
	return at.success && now >= at.data && now - at.data < ATTEMPT_WINDOW_MS;
}
/** False when the attempt could not be recorded; the caller must not redirect. */
function markSsoReentry(now = Date.now()) {
	try {
		sessionStorage.setItem(ATTEMPT_KEY, JSON.stringify(now));
		return true;
	} catch {
		return false;
	}
}
//#endregion
//#region src/platform/auth/session/cloudWebSessionStore.ts
var BOOTING_PHASES = /* @__PURE__ */ new Set([
	"idle",
	"reading",
	"restoring"
]);
var UNDECIDED_PHASES = /* @__PURE__ */ new Set([...BOOTING_PHASES, "retry_wait"]);
var RECONNECTING_AFTER_MS = 1e4;
var TOKEN_FAILURE_COPY = {
	NO_SESSION: "auth.webSession.token.ended",
	SESSION_EXPIRED: "auth.webSession.token.ended",
	SESSION_REVOKED: "auth.webSession.token.ended",
	IDENTITY_CHANGED: "auth.webSession.token.identityChanged",
	SESSION_UNAVAILABLE: "auth.webSession.token.unavailable",
	CSRF_STALE: "auth.webSession.token.refused",
	WORKSPACE_ACCESS_DENIED: "auth.webSession.token.workspaceDenied",
	SESSION_REQUEST_REFUSED: "auth.webSession.token.refused",
	SSO_REQUIRED: "auth.webSession.token.refused"
};
function webSessionFailureMessage(code) {
	if (code === "SSO_REQUIRED" && useFeatureFlags().flags.ssoEnabled) return t("auth.webSession.token.ssoRequired");
	return t(TOKEN_FAILURE_COPY[code]);
}
var LIFECYCLE_RACES = /* @__PURE__ */ new Set(["NO_SESSION", "IDENTITY_CHANGED"]);
async function whenSettled(identity, unsettled) {
	let stop = () => {};
	await new Promise((resolve) => {
		stop = identity.subscribe((state) => {
			if (!unsettled.has(state.phase)) resolve();
		});
	});
	stop();
}
function resetForAccountChange(change) {
	useWorkspaceAuthStore().clearWorkspaceContext();
	useTeamWorkspaceStore().resetForIdentityChange();
	api.resetSocket();
	if (change.reason !== "user_changed") return;
	useToast().info(t("auth.accountChanged.title"), {
		description: t("auth.accountChanged.detail", { email: change.session.user.email }),
		duration: 8e3
	});
}
function selectedWorkspaceId() {
	const { currentWorkspace, deniedWorkspaceId } = useWorkspaceAuthStore();
	return currentWorkspace?.id ?? deniedWorkspaceId ?? void 0;
}
function sessionOptions() {
	return {
		apiBaseUrl: api.apiURL(""),
		fetchImpl: (input, init) => fetch(input, init)
	};
}
/** One read of the session cookie that leaves the page load undecided. */
async function readsSignedInWebSession() {
	return (await readWebSession(sessionOptions())).status === "ok";
}
function createCloudIdentity(onAccountChanged) {
	const visibility = createWebVisibilityPort();
	const crossTab = createWebCrossTabRefreshPort();
	return createWebSessionIdentity({
		session: sessionOptions(),
		principal: {
			kind: "account",
			rememberedLogin: {
				currentUserId: async () => firebaseIdentity.currentUser()?.uid ?? null,
				getProof: async () => await firebaseIdentity.currentUser()?.getIdToken() ?? null,
				signOutLocally: async () => {
					if (firebaseIdentity.currentUser()) await firebaseIdentity.signOut();
				}
			}
		},
		origin: window.location.origin,
		onAccountChanged,
		...webSessionTelemetryHooks((event) => useTelemetry()?.trackWebSessionEvent(event)),
		...visibility && { heartbeat: {
			visibility,
			...crossTab && { crossTab }
		} }
	});
}
/**
* The cloud app's side of the shared web session. `unified_web_session` is
* read once, on the first `start()`, and decides the whole page load.
*/
var useCloudWebSessionStore = defineStore("cloudWebSession", () => {
	let decided = false;
	let identity = null;
	let ready = Promise.resolve();
	let creating = Promise.resolve(void 0);
	let decidedForRequests = Promise.resolve();
	let reconnectTimer;
	let pendingSignIn = null;
	let releaseRequests = () => {};
	let signingOut = false;
	let signedOutHere = false;
	const signedOutElsewhere = createEventHook();
	const state = shallowRef({ phase: "idle" });
	const signedInUser = computed(() => state.value.phase === "signed_in" ? state.value.session.user : void 0);
	watch(() => signedInUser.value?.id && JSON.stringify([signedInUser.value.id, selectedWorkspaceId()]), (socketScope) => {
		if (socketScope) api.reconnectSocket();
	});
	watch(() => signedInUser.value?.id, (userId) => {
		if (userId) useWorkspaceAuthStore().clearUnifiedContext();
	});
	const reconnecting = shallowRef(false);
	const readsFailing = computed(() => "failures" in state.value && state.value.failures > 0);
	watch(readsFailing, (failing) => {
		clearTimeout(reconnectTimer);
		reconnecting.value = false;
		if (failing) reconnectTimer = setTimeout(() => {
			reconnecting.value = true;
		}, RECONNECTING_AFTER_MS);
	});
	onScopeDispose(() => {
		clearTimeout(reconnectTimer);
		releaseRequests();
		identity?.dispose();
	});
	/** Resolves the refusal's code when the session was not created. */
	async function createSession(session, getProof) {
		const result = await session.signedIn(getProof).catch(() => null);
		if (result?.status === "ok") {
			clearInteractiveSignIn();
			return;
		}
		reportError(/* @__PURE__ */ new Error("Web session creation failed"), {
			surface: "auth",
			errorType: "session_cookie_creation_failure",
			level: "warning"
		});
		return result?.code;
	}
	async function bootAfter(session, signIn) {
		const user = firebaseIdentity.currentUser();
		const reloaded = !signIn && user && takeInteractiveSignIn(user.uid);
		const interactive = signIn ?? (reloaded ? {
			uid: user.uid,
			getProof: () => user.getIdToken()
		} : null);
		if (interactive && interactive.uid === user?.uid) {
			creating = createSession(session, interactive.getProof);
			await creating;
		}
		session.boot();
	}
	/** Decides the flag for this page load; true when the session is on. */
	function start() {
		if (decided) return identity !== null;
		decided = true;
		if (!useFeatureFlags().flags.unifiedWebSessionEnabled) return false;
		const session = createCloudIdentity((change) => {
			resetForAccountChange(change);
			if (change.reason === "signed_out" && !signingOut) signedOutElsewhere.trigger();
		});
		identity = session;
		session.subscribe((next) => {
			state.value = next;
			webSessionUser.value = next.phase === "signed_in" ? next.session.user : void 0;
			followSsoHint(next);
		});
		const mint = createSessionTokenMint({
			...sessionOptions(),
			getSession: currentSession
		});
		const authorize = createRequestAuthorizer({ getWorkspaceToken: mint.getWorkspaceToken });
		releaseRequests = provideWebSessionRequests({
			scope: requestScope,
			workspaceId: () => currentSession() ? selectedWorkspaceId() : void 0,
			send: (url, init, scope) => send(url, init, scope, authorize),
			workspaceToken: async (scope) => settleScopedToken(scope, await mint.mint(scope.workspaceId)),
			remintWorkspaceToken: async (scope) => settleScopedToken(scope, await mint.remint(scope.workspaceId)),
			authorizeResource: async ({ session }) => {
				try {
					const { headers } = await authorize({
						kind: "session",
						session
					}, {
						target: "resource",
						method: "POST"
					});
					return headers;
				} catch (error) {
					if (!(error instanceof SessionTokenError)) throw error;
					const { failure } = error;
					if (failure.httpStatus !== 401 && !LIFECYCLE_RACES.has(failure.code)) reportError(error, {
						surface: "auth",
						errorType: "auth_session_token_mint_failure",
						level: "warning",
						tags: {
							code: failure.code,
							http_status: failure.httpStatus
						}
					});
					if (failure.code === "SSO_REQUIRED") presentSsoRequired("session_refused", { email: session.user.email });
					throw new WebSessionTokenError(error, webSessionFailureMessage(failure.code));
				}
			}
		});
		ready = whenSettled(session, BOOTING_PHASES);
		decidedForRequests = whenSettled(session, UNDECIDED_PHASES);
		bootAfter(session, pendingSignIn);
		pendingSignIn = null;
		return true;
	}
	function followSsoHint(next) {
		if (next.phase === "signed_in") {
			signedOutHere = false;
			if (useFeatureFlags().flags.ssoEnabled) {
				rememberSignedInSession(next.session.user);
				if (isSsoSession(next.session.user)) trackSsoSignInCompleted();
			}
		} else if (next.phase === "signed_out" && next.outcome === "revoked") forgetSsoHint();
	}
	function sessionEnd() {
		const current = identity?.getState();
		if (current?.phase !== "signed_out") return void 0;
		if (signedOutHere) return "signed_out_here";
		return current.outcome === "signed_out" ? "lapsed" : current.outcome;
	}
	/** Only after an interactive sign-in; a token refresh never calls this. */
	function signedInInteractively(user) {
		const getProof = () => user.getIdToken();
		endSsoFlow();
		if (identity) creating = createSession(identity, getProof);
		else if (!decided) pendingSignIn = {
			uid: user.uid,
			getProof
		};
	}
	async function signOut() {
		pendingSignIn = null;
		clearInteractiveSignIn();
		forgetSsoHint();
		signedOutHere = true;
		signingOut = true;
		const result = await identity?.signOut().finally(() => {
			signingOut = false;
		});
		if (result === void 0 || result.status === "ok") return;
		reportError(/* @__PURE__ */ new Error("Session cookie deletion failed"), {
			surface: "auth",
			errorType: "auth_session_cookie_delete_failed",
			level: "error"
		});
	}
	async function revokeAllSessions() {
		const session = currentSession();
		if (!session) return {
			status: "error",
			code: "NO_SESSION",
			retryable: false
		};
		return revokeAllWebSessions(sessionOptions(), session.csrfToken);
	}
	function currentSession() {
		const state = identity?.getState();
		return state?.phase === "signed_in" ? state.session : void 0;
	}
	/** The epoch moves on every account change, so it pins the scope's user. */
	function staleScopeFailure(scope) {
		if (!currentSession()) return {
			status: "error",
			code: "NO_SESSION",
			retryable: false
		};
		if (identity?.getEpoch() === scope.epoch) return void 0;
		return {
			status: "error",
			code: "IDENTITY_CHANGED",
			retryable: false
		};
	}
	function settleScopedToken(scope, result) {
		const stale = staleScopeFailure(scope);
		if (stale) return stale;
		dropRefusedWorkspace(scope, result);
		return result;
	}
	function dropRefusedWorkspace({ workspaceId }, result) {
		if (workspaceId !== void 0 && result.status === "error" && result.code === "WORKSPACE_ACCESS_DENIED") useWorkspaceAuthStore().dropDeniedWorkspace(workspaceId);
	}
	/** Undefined unless this tab is signed in on the session. */
	async function requestScope() {
		await decidedForRequests;
		const session = currentSession();
		if (!identity || !session) return void 0;
		const workspaceId = selectedWorkspaceId();
		return {
			session,
			epoch: identity.getEpoch(),
			...workspaceId && { workspaceId }
		};
	}
	async function refreshFor(scope) {
		const next = await identity?.refresh(scope.session.user.id);
		if (next?.phase !== "signed_in" || next.session === scope.session) return;
		if (identity?.getEpoch() !== scope.epoch) return;
		return {
			...scope,
			session: next.session
		};
	}
	function send(url, init, scope, authorize) {
		return fetchOnWebSession(url, init, scope, {
			authorize,
			refresh: refreshFor,
			workspaceDenied: (workspaceId) => useWorkspaceAuthStore().dropDeniedWorkspace(workspaceId),
			ssoRequired: ({ session }) => presentSsoRequired("session_refused", { email: session.user.email })
		});
	}
	async function whenDecided() {
		await until(state).toMatch(({ phase }) => phase === "signed_in" || phase === "signed_out");
		return state.value.phase === "signed_in" ? "signed_in" : "signed_out";
	}
	return {
		start,
		state,
		signedInUser,
		reconnecting,
		isActive: () => identity !== null,
		sessionEnd,
		whenReady: () => ready,
		whenSessionCreated: () => creating,
		whenDecided,
		/** The account left this tab without a sign-out here. */
		onSignedOutElsewhere: signedOutElsewhere.on,
		signedInInteractively,
		signOut,
		revokeAllSessions
	};
});
//#endregion
export { markSsoReentry as a, hasRecentSsoReentry as i, useCloudWebSessionStore as n, readSsoHint as o, webSessionFailureMessage as r, readsSignedInWebSession as t };
