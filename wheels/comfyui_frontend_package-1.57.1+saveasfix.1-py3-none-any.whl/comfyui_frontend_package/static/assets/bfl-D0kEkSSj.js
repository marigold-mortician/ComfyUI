//#region packages/design-system/src/icons/bfl.svg?raw
var bfl_default = "<svg width=\"512\" height=\"512\" viewBox=\"0 0 512 512\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n<g clip-path=\"url(#clip0_1471_12672)\">\n<path d=\"M365.047 229.802H310.584L256.118 153.072L86.2157 392.168H140.796L256.115 229.807H310.581L195.261 392.168H249.994L365.047 229.802L512 436.698H470.893V436.7H426.019V392.343L365.047 306.532L304.415 392.178V436.698H163.632L163.629 436.703H109.164L109.167 436.698H-0.105347L256.118 76L365.047 229.802Z\" fill=\"currentColor\"/>\n</g>\n<defs>\n<clipPath id=\"clip0_1471_12672\">\n<rect width=\"512\" height=\"512\" fill=\"white\"/>\n</clipPath>\n</defs>\n</svg>\n";
//#endregion
export { bfl_default as default };
