import "./rolldown-runtime-xtsTai4I.js";
import { D as union, S as object, T as string, u as boolean, v as literal } from "./vendor-zod-Del_rmdp.js";
import { l as RenderShape } from "./globalEnums-BPoISudO.js";
var arc_default = {
	id: "arc",
	name: "Arc",
	colors: {
		"node_slot": {
			"BOOLEAN": "",
			"CLIP": "#eacb8b",
			"CLIP_VISION": "#A8DADC",
			"CLIP_VISION_OUTPUT": "#ad7452",
			"CONDITIONING": "#cf876f",
			"CONTROL_NET": "#00d78d",
			"CONTROL_NET_WEIGHTS": "",
			"FLOAT": "",
			"GLIGEN": "",
			"IMAGE": "#80a1c0",
			"IMAGEUPLOAD": "",
			"INT": "",
			"LATENT": "#b38ead",
			"LATENT_KEYFRAME": "",
			"MASK": "#a3bd8d",
			"MODEL": "#8978a7",
			"SAMPLER": "",
			"SIGMAS": "",
			"STRING": "",
			"STYLE_MODEL": "#C2FFAE",
			"T2I_ADAPTER_WEIGHTS": "",
			"TAESD": "#DCC274",
			"TIMESTEP_KEYFRAME": "",
			"UPSCALE_MODEL": "",
			"VAE": "#be616b"
		},
		"litegraph_base": {
			"BACKGROUND_IMAGE": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAACXBIWXMAAAsTAAALEwEAmpwYAAABcklEQVR4nO3YMUoDARgF4RfxBqZI6/0vZqFn0MYtrLIQMFN8U6V4LAtD+Jm9XG/v30OGl2e/AP7yevz4+vx45nvgF/+QGITEICQGITEIiUFIjNNC3q43u3/YnRJyPOzeQ+0e220nhRzReC8e7R7bbdvl+Jal1Bs46jEIiUFIDEJiEBKDkBhKPbZT6qHdptRTu02p53DUYxASg5AYhMQgJAYhMZR6bKfUQ7tNqad2m1LP4ajHICQGITEIiUFIDEJiKPXYTqmHdptST+02pZ7DUY9BSAxCYhASg5AYhMRQ6rGdUg/tNqWe2m1KPYejHoOQGITEICQGITEIiaHUYzulHtptSj2125R6Dkc9BiExCIlBSAxCYhASQ6nHdko9tNuUemq3KfUcjnoMQmIQEoOQGITEICSGUo/tlHpotyn11G5T6jkc9RiExCAkBiExCIlBSAylHtsp9dBuU+qp3abUczjqMQiJQUgMQmIQEoOQGITE+AHFISNQrFTGuwAAAABJRU5ErkJggg==",
			"CLEAR_BACKGROUND_COLOR": "#2b2f38",
			"NODE_TITLE_COLOR": "#b2b7bd",
			"NODE_SELECTED_TITLE_COLOR": "#FFF",
			"NODE_TEXT_COLOR": "#AAA",
			"NODE_DEFAULT_COLOR": "#2b2f38",
			"NODE_DEFAULT_BGCOLOR": "#242730",
			"NODE_DEFAULT_BOXCOLOR": "#6e7581",
			"NODE_DEFAULT_SHAPE": 2,
			"NODE_BOX_OUTLINE_COLOR": "#FFF",
			"NODE_BYPASS_BGCOLOR": "#FF00FF",
			"NODE_ERROR_COLOUR": "#E00",
			"DEFAULT_SHADOW_COLOR": "rgba(0,0,0,0.5)",
			"WIDGET_BGCOLOR": "#2b2f38",
			"WIDGET_OUTLINE_COLOR": "#6e7581",
			"WIDGET_TEXT_COLOR": "#DDD",
			"WIDGET_SECONDARY_TEXT_COLOR": "#b2b7bd",
			"WIDGET_DISABLED_TEXT_COLOR": "#5c626d",
			"LINK_COLOR": "#9A9",
			"EVENT_LINK_COLOR": "#A86",
			"CONNECTING_LINK_COLOR": "#AFA"
		},
		"comfy_base": {
			"fg-color": "#fff",
			"bg-color": "#2b2f38",
			"comfy-menu-bg": "#242730",
			"comfy-menu-secondary-bg": "#22252E",
			"comfy-input-bg": "#2b2f38",
			"input-text": "#ddd",
			"descrip-text": "#b2b7bd",
			"drag-text": "#ccc",
			"error-text": "#ff4444",
			"border-color": "#6e7581",
			"tr-even-bg-color": "#2b2f38",
			"tr-odd-bg-color": "#242730",
			"content-bg": "#6e7581",
			"content-fg": "#fff",
			"content-hover-bg": "#2b2f38",
			"content-hover-fg": "#fff",
			"bar-shadow": "rgba(8, 8, 8, 0.75) 0 0 0.5rem"
		}
	}
};
var dark_default = {
	id: "dark",
	name: "Dark (Default)",
	colors: {
		"node_slot": {
			"CLIP": "#FFD500",
			"CLIP_VISION": "#A8DADC",
			"CLIP_VISION_OUTPUT": "#ad7452",
			"CONDITIONING": "#FFA931",
			"CONTROL_NET": "#6EE7B7",
			"IMAGE": "#64B5F6",
			"LATENT": "#FF9CF9",
			"MASK": "#81C784",
			"MODEL": "#B39DDB",
			"STYLE_MODEL": "#C2FFAE",
			"VAE": "#FF6E6E",
			"NOISE": "#B0B0B0",
			"GUIDER": "#66FFFF",
			"SAMPLER": "#ECB4B4",
			"SIGMAS": "#CDFFCD",
			"TAESD": "#DCC274"
		},
		"litegraph_base": {
			"BACKGROUND_IMAGE": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAIAAAD/gAIDAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAQBJREFUeNrs1rEKwjAUhlETUkj3vP9rdmr1Ysammk2w5wdxuLgcMHyptfawuZX4pJSWZTnfnu/lnIe/jNNxHHGNn//HNbbv+4dr6V+11uF527arU7+u63qfa/bnmh8sWLBgwYJlqRf8MEptXPBXJXa37BSl3ixYsGDBMliwFLyCV/DeLIMFCxYsWLBMwSt4Be/NggXLYMGCBUvBK3iNruC9WbBgwYJlsGApeAWv4L1ZBgsWLFiwYJmCV/AK3psFC5bBggULloJX8BpdwXuzYMGCBctgwVLwCl7Be7MMFixYsGDBsu8FH1FaSmExVfAxBa/gvVmwYMGCZbBg/W4vAQYA5tRF9QYlv/QAAAAASUVORK5CYII=",
			"CLEAR_BACKGROUND_COLOR": "#141414",
			"NODE_TITLE_COLOR": "#999",
			"NODE_SELECTED_TITLE_COLOR": "#FFF",
			"NODE_TEXT_COLOR": "#AAA",
			"NODE_TEXT_HIGHLIGHT_COLOR": "#FFF",
			"NODE_DEFAULT_COLOR": "#333",
			"NODE_DEFAULT_BGCOLOR": "#353535",
			"NODE_DEFAULT_BOXCOLOR": "#666",
			"NODE_DEFAULT_SHAPE": 2,
			"NODE_BOX_OUTLINE_COLOR": "#FFF",
			"NODE_BYPASS_BGCOLOR": "#FF00FF",
			"NODE_ERROR_COLOUR": "#E00",
			"DEFAULT_SHADOW_COLOR": "rgba(0,0,0,0.5)",
			"WIDGET_BGCOLOR": "#222",
			"WIDGET_OUTLINE_COLOR": "#666",
			"WIDGET_TEXT_COLOR": "#DDD",
			"WIDGET_SECONDARY_TEXT_COLOR": "#999",
			"WIDGET_DISABLED_TEXT_COLOR": "#666",
			"LINK_COLOR": "#9A9",
			"EVENT_LINK_COLOR": "#A86",
			"CONNECTING_LINK_COLOR": "#AFA",
			"BADGE_FG_COLOR": "#FFF",
			"BADGE_BG_COLOR": "#0F1F0F"
		},
		"comfy_base": {
			"fg-color": "#fff",
			"bg-color": "#202020",
			"comfy-menu-bg": "#171718",
			"comfy-menu-secondary-bg": "#303030",
			"comfy-input-bg": "#222",
			"input-text": "#ddd",
			"descrip-text": "#999",
			"drag-text": "#ccc",
			"error-text": "#ff4444",
			"border-color": "#4e4e4e",
			"tr-even-bg-color": "#222",
			"tr-odd-bg-color": "#353535",
			"content-bg": "#4e4e4e",
			"content-fg": "#fff",
			"content-hover-bg": "#222",
			"content-hover-fg": "#fff",
			"bar-shadow": "rgb(16 16 16 / 0.5) 0 0 0.5rem"
		},
		"theme": {
			"background": "#171718",
			"foreground": "#ffffff",
			"card": "#262729",
			"primary": "#0b8ce9",
			"secondary": "#262729",
			"muted": "#3c3d42",
			"muted-foreground": "#8a8a8a",
			"accent": "#313235",
			"destructive": "#b33a3a",
			"border": "#494a50",
			"node-foreground": "#a0a0a0",
			"node-header": "#202121",
			"node-border": "#55565e",
			"warning": "#fd9903",
			"shadow-color": "rgb(0 0 0 / 0.4)"
		}
	}
};
var fennec_default = {
	id: "fennec",
	name: "Fennec Girl",
	colors: {
		"node_slot": {},
		"litegraph_base": {
			"BACKGROUND_IMAGE": "/assets/images/fennec-daisies.png",
			"CLEAR_BACKGROUND_COLOR": "#191722",
			"LINK_COLOR": "#dc7f66",
			"CONNECTING_LINK_COLOR": "#f7e5bd"
		},
		"comfy_base": {},
		"theme": {
			"background": "#191722",
			"foreground": "#f7e5bd",
			"card": "#241f2e",
			"primary": "#2b5f9e",
			"secondary": "#2a2433",
			"muted": "#4a3828",
			"muted-foreground": "#d4b48a",
			"accent": "#2c2636",
			"destructive": "#c4473a",
			"border": "#7a5a36",
			"input": "#15131c",
			"ring": "#70a8c1",
			"node": "#1e1a27",
			"node-foreground": "#f4c86e",
			"node-header": "#74461f",
			"node-border": "#e9b864",
			"warning": "#ed9b3b",
			"shadow-color": "rgb(10 8 16 / 0.55)"
		}
	}
};
var github_default = {
	id: "github",
	name: "Github",
	colors: {
		"node_slot": {
			"BOOLEAN": "",
			"CLIP": "#eacb8b",
			"CLIP_VISION": "#A8DADC",
			"CLIP_VISION_OUTPUT": "#ad7452",
			"CONDITIONING": "#cf876f",
			"CONTROL_NET": "#00d78d",
			"CONTROL_NET_WEIGHTS": "",
			"FLOAT": "",
			"GLIGEN": "",
			"IMAGE": "#80a1c0",
			"IMAGEUPLOAD": "",
			"INT": "",
			"LATENT": "#b38ead",
			"LATENT_KEYFRAME": "",
			"MASK": "#a3bd8d",
			"MODEL": "#8978a7",
			"SAMPLER": "",
			"SIGMAS": "",
			"STRING": "",
			"STYLE_MODEL": "#C2FFAE",
			"T2I_ADAPTER_WEIGHTS": "",
			"TAESD": "#DCC274",
			"TIMESTEP_KEYFRAME": "",
			"UPSCALE_MODEL": "",
			"VAE": "#be616b"
		},
		"litegraph_base": {
			"BACKGROUND_IMAGE": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAIAAAD/gAIDAAAACXBIWXMAAAsTAAALEwEAmpwYAAAGlmlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgOS4xLWMwMDEgNzkuMTQ2Mjg5OSwgMjAyMy8wNi8yNS0yMDowMTo1NSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0RXZ0PSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VFdmVudCMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIDI1LjEgKFdpbmRvd3MpIiB4bXA6Q3JlYXRlRGF0ZT0iMjAyMy0xMS0xM1QwMDoxODowMiswMTowMCIgeG1wOk1vZGlmeURhdGU9IjIwMjMtMTEtMTVUMDI6MDQ6NTkrMDE6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMjMtMTEtMTVUMDI6MDQ6NTkrMDE6MDAiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOmIyYzRhNjA5LWJmYTctYTg0MC1iOGFlLTk3MzE2ZjM1ZGIyNyIgeG1wTU06RG9jdW1lbnRJRD0iYWRvYmU6ZG9jaWQ6cGhvdG9zaG9wOjk0ZmNlZGU4LTE1MTctZmQ0MC04ZGU3LWYzOTgxM2E3ODk5ZiIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOjIzMWIxMGIwLWI0ZmItMDI0ZS1iMTJlLTMwNTMwM2NkMDdjOCI+IDx4bXBNTTpIaXN0b3J5PiA8cmRmOlNlcT4gPHJkZjpsaSBzdEV2dDphY3Rpb249ImNyZWF0ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6MjMxYjEwYjAtYjRmYi0wMjRlLWIxMmUtMzA1MzAzY2QwN2M4IiBzdEV2dDp3aGVuPSIyMDIzLTExLTEzVDAwOjE4OjAyKzAxOjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgMjUuMSAoV2luZG93cykiLz4gPHJkZjpsaSBzdEV2dDphY3Rpb249InNhdmVkIiBzdEV2dDppbnN0YW5jZUlEPSJ4bXAuaWlkOjQ4OWY1NzlmLTJkNjUtZWQ0Zi04OTg0LTA4NGE2MGE1ZTMzNSIgc3RFdnQ6d2hlbj0iMjAyMy0xMS0xNVQwMjowNDo1OSswMTowMCIgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWRvYmUgUGhvdG9zaG9wIDI1LjEgKFdpbmRvd3MpIiBzdEV2dDpjaGFuZ2VkPSIvIi8+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDpiMmM0YTYwOS1iZmE3LWE4NDAtYjhhZS05NzMxNmYzNWRiMjciIHN0RXZ0OndoZW49IjIwMjMtMTEtMTVUMDI6MDQ6NTkrMDE6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyNS4xIChXaW5kb3dzKSIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8L3JkZjpTZXE+IDwveG1wTU06SGlzdG9yeT4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4OTe6GAAAAx0lEQVR42u3WMQoAIQxFwRzJys77X8vSLiRgITif7bYbgrwYc/mKXyBoY4VVBgsWLFiwYFmOlTv+9jfDOjHmr8u6eVkGCxYsWLBgmc5S8ApewXvgYRksWLBgKXidpeBdloL3wMOCBctgwVLwCl7BuyyDBQsWLFiwTGcpeAWv4D3wsAwWLFiwFLzOUvAuS8F74GHBgmWwYCl4Ba/gXZbBggULFixYprMUvIJX8B54WAYLFixYCl5nKXiXpeA98LBgwTJYsGC9tg1o8f4TTtqzNQAAAABJRU5ErkJggg==",
			"CLEAR_BACKGROUND_COLOR": "#040506",
			"NODE_TITLE_COLOR": "#999",
			"NODE_SELECTED_TITLE_COLOR": "#e5eaf0",
			"NODE_TEXT_COLOR": "#bcc2c8",
			"NODE_DEFAULT_COLOR": "#161b22",
			"NODE_DEFAULT_BGCOLOR": "#13171d",
			"NODE_DEFAULT_BOXCOLOR": "#30363d",
			"NODE_DEFAULT_SHAPE": 2,
			"NODE_BOX_OUTLINE_COLOR": "#e5eaf0",
			"NODE_BYPASS_BGCOLOR": "#FF00FF",
			"NODE_ERROR_COLOUR": "#E00",
			"DEFAULT_SHADOW_COLOR": "rgba(0,0,0,0.5)",
			"WIDGET_BGCOLOR": "#161b22",
			"WIDGET_OUTLINE_COLOR": "#30363d",
			"WIDGET_TEXT_COLOR": "#bcc2c8",
			"WIDGET_SECONDARY_TEXT_COLOR": "#999",
			"WIDGET_DISABLED_TEXT_COLOR": "#30363d",
			"LINK_COLOR": "#9A9",
			"EVENT_LINK_COLOR": "#A86",
			"CONNECTING_LINK_COLOR": "#AFA"
		},
		"comfy_base": {
			"fg-color": "#e5eaf0",
			"bg-color": "#161b22",
			"comfy-menu-bg": "#13171d",
			"comfy-menu-secondary-bg": "#11141A",
			"comfy-input-bg": "#161b22",
			"input-text": "#bcc2c8",
			"descrip-text": "#999",
			"drag-text": "#ccc",
			"error-text": "#ff4444",
			"border-color": "#30363d",
			"tr-even-bg-color": "#161b22",
			"tr-odd-bg-color": "#13171d",
			"content-bg": "#30363d",
			"content-fg": "#e5eaf0",
			"content-hover-bg": "#161b22",
			"content-hover-fg": "#e5eaf0",
			"bar-shadow": "rgba(0, 0, 0, 1) 0 0 0.5rem"
		}
	}
};
var light_default = {
	id: "light",
	name: "Light",
	light_theme: true,
	colors: {
		"node_slot": {
			"CLIP": "#FFA726",
			"CLIP_VISION": "#5C6BC0",
			"CLIP_VISION_OUTPUT": "#8D6E63",
			"CONDITIONING": "#EF5350",
			"CONTROL_NET": "#66BB6A",
			"IMAGE": "#42A5F5",
			"LATENT": "#AB47BC",
			"MASK": "#9CCC65",
			"MODEL": "#7E57C2",
			"STYLE_MODEL": "#D4E157",
			"VAE": "#FF7043",
			"NOISE": "#B0B0B0",
			"GUIDER": "#66FFFF",
			"SAMPLER": "#ECB4B4",
			"SIGMAS": "#CDFFCD",
			"TAESD": "#DCC274"
		},
		"litegraph_base": {
			"BACKGROUND_IMAGE": "data:image/gif;base64,R0lGODlhZABkALMAAAAAAP///+vr6+rq6ujo6Ofn5+bm5uXl5d3d3f///wAAAAAAAAAAAAAAAAAAAAAAACH5BAEAAAkALAAAAABkAGQAAAT/UMhJq7046827HkcoHkYxjgZhnGG6si5LqnIM0/fL4qwwIMAg0CAsEovBIxKhRDaNy2GUOX0KfVFrssrNdpdaqTeKBX+dZ+jYvEaTf+y4W66mC8PUdrE879f9d2mBeoNLfH+IhYBbhIx2jkiHiomQlGKPl4uZe3CaeZifnnijgkESBqipqqusra6vsLGys62SlZO4t7qbuby7CLa+wqGWxL3Gv3jByMOkjc2lw8vOoNSi0czAncXW3Njdx9Pf48/Z4Kbbx+fQ5evZ4u3k1fKR6cn03vHlp7T9/v8A/8Gbp4+gwXoFryXMB2qgwoMMHyKEqA5fxX322FG8tzBcRnMW/zlulPbRncmQGidKjMjyYsOSKEF2FBlJQMCbOHP6c9iSZs+UnGYCdbnSo1CZI5F64kn0p1KnTH02nSoV3dGTV7FFHVqVq1dtWcMmVQZTbNGu72zqXMuW7danVL+6e4t1bEy6MeueBYLXrNO5Ze36jQtWsOG97wIj1vt3St/DjTEORss4nNq2mDP3e7w4r1bFkSET5hy6s2TRlD2/mSxXtSHQhCunXo26NevCpmvD/UU6tuullzULH76q92zdZG/Ltv1a+W+osI/nRmyc+fRi1Xdbh+68+0vv10dH3+77KD/i6IdnX669/frn5Zsjh4/2PXju8+8bzc9/6fj27LFnX11/+IUnXWl7BJfegm79FyB9JOl3oHgSklefgxAC+FmFGpqHIYcCfkhgfCohSKKJVo044YUMttggiBkmp6KFXw1oII24oYhjiDByaKOOHcp3Y5BD/njikSkO+eBREQAAOw==",
			"CLEAR_BACKGROUND_COLOR": "lightgray",
			"NODE_TITLE_COLOR": "#222",
			"NODE_SELECTED_TITLE_COLOR": "#000",
			"NODE_TEXT_COLOR": "#444",
			"NODE_TEXT_HIGHLIGHT_COLOR": "#1e293b",
			"NODE_DEFAULT_COLOR": "#F7F7F7",
			"NODE_DEFAULT_BGCOLOR": "#F5F5F5",
			"NODE_DEFAULT_BOXCOLOR": "#CCC",
			"NODE_DEFAULT_SHAPE": 2,
			"NODE_BOX_OUTLINE_COLOR": "#000",
			"NODE_BYPASS_BGCOLOR": "#FF00FF",
			"NODE_ERROR_COLOUR": "#E00",
			"DEFAULT_SHADOW_COLOR": "rgba(0,0,0,0.1)",
			"WIDGET_BGCOLOR": "#D4D4D4",
			"WIDGET_OUTLINE_COLOR": "#999",
			"WIDGET_TEXT_COLOR": "#222",
			"WIDGET_SECONDARY_TEXT_COLOR": "#555",
			"WIDGET_DISABLED_TEXT_COLOR": "#999",
			"LINK_COLOR": "#4CAF50",
			"EVENT_LINK_COLOR": "#FF9800",
			"CONNECTING_LINK_COLOR": "#2196F3",
			"BADGE_FG_COLOR": "#000",
			"BADGE_BG_COLOR": "#FFF"
		},
		"comfy_base": {
			"fg-color": "#222",
			"bg-color": "#DDD",
			"comfy-menu-bg": "#FFFFFF",
			"comfy-menu-hover-bg": "#ccc",
			"comfy-menu-secondary-bg": "#EEE",
			"comfy-input-bg": "#C9C9C9",
			"input-text": "#222",
			"descrip-text": "#444",
			"drag-text": "#555",
			"error-text": "#F44336",
			"border-color": "#888",
			"tr-even-bg-color": "#f9f9f9",
			"tr-odd-bg-color": "#fff",
			"content-bg": "#e0e0e0",
			"content-fg": "#222",
			"content-hover-bg": "#adadad",
			"content-hover-fg": "#222",
			"bar-shadow": "rgba(16, 16, 16, 0.25) 0 0 0.5rem",
			"contrast-mix-color": "#000"
		},
		"theme": {
			"background": "#ffffff",
			"foreground": "#171718",
			"card": "#ffffff",
			"primary": "#31b9f4",
			"secondary": "#e9e9e9",
			"muted": "#d9d9d9",
			"muted-foreground": "#494a50",
			"accent": "#e1e1e1",
			"destructive": "#f75951",
			"border": "#b4b4b4",
			"ring": "#8a8a8a",
			"node-foreground": "#444444",
			"warning": "#c77700",
			"shadow-color": "rgb(0 0 0 / 0.15)"
		}
	}
};
//#endregion
//#region src/constants/coreColorPalettes.ts
var CORE_COLOR_PALETTES = {
	dark: dark_default,
	light: light_default,
	solarized: {
		id: "solarized",
		name: "Solarized",
		colors: {
			"node_slot": {
				"CLIP": "#2AB7CA",
				"CLIP_VISION": "#6c71c4",
				"CLIP_VISION_OUTPUT": "#859900",
				"CONDITIONING": "#d33682",
				"CONTROL_NET": "#d1ffd7",
				"IMAGE": "#5940bb",
				"LATENT": "#268bd2",
				"MASK": "#CCC9E7",
				"MODEL": "#dc322f",
				"STYLE_MODEL": "#1a998a",
				"UPSCALE_MODEL": "#054A29",
				"VAE": "#facfad"
			},
			"litegraph_base": {
				"NODE_TITLE_COLOR": "#fdf6e3",
				"NODE_SELECTED_TITLE_COLOR": "#A9D400",
				"NODE_TEXT_COLOR": "#657b83",
				"NODE_DEFAULT_COLOR": "#094656",
				"NODE_DEFAULT_BGCOLOR": "#073642",
				"NODE_DEFAULT_BOXCOLOR": "#839496",
				"NODE_DEFAULT_SHAPE": 2,
				"NODE_BOX_OUTLINE_COLOR": "#fdf6e3",
				"NODE_BYPASS_BGCOLOR": "#FF00FF",
				"NODE_ERROR_COLOUR": "#E00",
				"DEFAULT_SHADOW_COLOR": "rgba(0,0,0,0.5)",
				"WIDGET_BGCOLOR": "#002b36",
				"WIDGET_OUTLINE_COLOR": "#839496",
				"WIDGET_TEXT_COLOR": "#fdf6e3",
				"WIDGET_SECONDARY_TEXT_COLOR": "#93a1a1",
				"WIDGET_DISABLED_TEXT_COLOR": "#657b83",
				"LINK_COLOR": "#2aa198",
				"EVENT_LINK_COLOR": "#268bd2",
				"CONNECTING_LINK_COLOR": "#859900"
			},
			"comfy_base": {
				"fg-color": "#fdf6e3",
				"bg-color": "#002b36",
				"comfy-menu-bg": "#073642",
				"comfy-menu-secondary-bg": "#06323D",
				"comfy-input-bg": "#002b36",
				"input-text": "#93a1a1",
				"descrip-text": "#586e75",
				"drag-text": "#839496",
				"error-text": "#dc322f",
				"border-color": "#657b83",
				"tr-even-bg-color": "#002b36",
				"tr-odd-bg-color": "#073642",
				"content-bg": "#657b83",
				"content-fg": "#fdf6e3",
				"content-hover-bg": "#002b36",
				"content-hover-fg": "#fdf6e3",
				"bar-shadow": "rgba(16, 16, 16, 0.5) 0 0 0.5rem"
			}
		}
	},
	arc: arc_default,
	nord: {
		id: "nord",
		name: "Nord",
		colors: {
			"node_slot": {
				"BOOLEAN": "",
				"CLIP": "#eacb8b",
				"CLIP_VISION": "#A8DADC",
				"CLIP_VISION_OUTPUT": "#ad7452",
				"CONDITIONING": "#cf876f",
				"CONTROL_NET": "#00d78d",
				"CONTROL_NET_WEIGHTS": "",
				"FLOAT": "",
				"GLIGEN": "",
				"IMAGE": "#80a1c0",
				"IMAGEUPLOAD": "",
				"INT": "",
				"LATENT": "#b38ead",
				"LATENT_KEYFRAME": "",
				"MASK": "#a3bd8d",
				"MODEL": "#8978a7",
				"SAMPLER": "",
				"SIGMAS": "",
				"STRING": "",
				"STYLE_MODEL": "#C2FFAE",
				"T2I_ADAPTER_WEIGHTS": "",
				"TAESD": "#DCC274",
				"TIMESTEP_KEYFRAME": "",
				"UPSCALE_MODEL": "",
				"VAE": "#be616b"
			},
			"litegraph_base": {
				"BACKGROUND_IMAGE": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAIAAAD/gAIDAAAACXBIWXMAAAsTAAALEwEAmpwYAAAFu2lUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgOS4xLWMwMDEgNzkuMTQ2Mjg5OSwgMjAyMy8wNi8yNS0yMDowMTo1NSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0RXZ0PSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VFdmVudCMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIDI1LjEgKFdpbmRvd3MpIiB4bXA6Q3JlYXRlRGF0ZT0iMjAyMy0xMS0xM1QwMDoxODowMiswMTowMCIgeG1wOk1vZGlmeURhdGU9IjIwMjMtMTEtMTVUMDE6MjA6NDUrMDE6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMjMtMTEtMTVUMDE6MjA6NDUrMDE6MDAiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjUwNDFhMmZjLTEzNzQtMTk0ZC1hZWY4LTYxMzM1MTVmNjUwMCIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDoyMzFiMTBiMC1iNGZiLTAyNGUtYjEyZS0zMDUzMDNjZDA3YzgiIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDoyMzFiMTBiMC1iNGZiLTAyNGUtYjEyZS0zMDUzMDNjZDA3YzgiPiA8eG1wTU06SGlzdG9yeT4gPHJkZjpTZXE+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJjcmVhdGVkIiBzdEV2dDppbnN0YW5jZUlEPSJ4bXAuaWlkOjIzMWIxMGIwLWI0ZmItMDI0ZS1iMTJlLTMwNTMwM2NkMDdjOCIgc3RFdnQ6d2hlbj0iMjAyMy0xMS0xM1QwMDoxODowMiswMTowMCIgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWRvYmUgUGhvdG9zaG9wIDI1LjEgKFdpbmRvd3MpIi8+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo1MDQxYTJmYy0xMzc0LTE5NGQtYWVmOC02MTMzNTE1ZjY1MDAiIHN0RXZ0OndoZW49IjIwMjMtMTEtMTVUMDE6MjA6NDUrMDE6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyNS4xIChXaW5kb3dzKSIgc3RFdnQ6Y2hhbmdlZD0iLyIvPiA8L3JkZjpTZXE+IDwveG1wTU06SGlzdG9yeT4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz73jWg/AAAAyUlEQVR42u3WKwoAIBRFQRdiMb1idv9Lsxn9gEFw4Dbb8JCTojbbXEJwjJVL2HKwYMGCBQuWLbDmjr+9zrBGjHl1WVcvy2DBggULFizTWQpewSt4HzwsgwULFiwFr7MUvMtS8D54WLBgGSxYCl7BK3iXZbBgwYIFC5bpLAWv4BW8Dx6WwYIFC5aC11kK3mUpeB88LFiwDBYsBa/gFbzLMliwYMGCBct0loJX8AreBw/LYMGCBUvB6ywF77IUvA8eFixYBgsWrNfWAZPltufdad+1AAAAAElFTkSuQmCC",
				"CLEAR_BACKGROUND_COLOR": "#212732",
				"NODE_TITLE_COLOR": "#999",
				"NODE_SELECTED_TITLE_COLOR": "#e5eaf0",
				"NODE_TEXT_COLOR": "#bcc2c8",
				"NODE_DEFAULT_COLOR": "#2e3440",
				"NODE_DEFAULT_BGCOLOR": "#161b22",
				"NODE_DEFAULT_BOXCOLOR": "#545d70",
				"NODE_DEFAULT_SHAPE": 2,
				"NODE_BOX_OUTLINE_COLOR": "#e5eaf0",
				"NODE_BYPASS_BGCOLOR": "#FF00FF",
				"NODE_ERROR_COLOUR": "#E00",
				"DEFAULT_SHADOW_COLOR": "rgba(0,0,0,0.5)",
				"WIDGET_BGCOLOR": "#2e3440",
				"WIDGET_OUTLINE_COLOR": "#545d70",
				"WIDGET_TEXT_COLOR": "#bcc2c8",
				"WIDGET_SECONDARY_TEXT_COLOR": "#999",
				"WIDGET_DISABLED_TEXT_COLOR": "#545d70",
				"LINK_COLOR": "#9A9",
				"EVENT_LINK_COLOR": "#A86",
				"CONNECTING_LINK_COLOR": "#AFA"
			},
			"comfy_base": {
				"fg-color": "#e5eaf0",
				"bg-color": "#2e3440",
				"comfy-menu-bg": "#161b22",
				"comfy-menu-secondary-bg": "#14181F",
				"comfy-input-bg": "#2e3440",
				"input-text": "#bcc2c8",
				"descrip-text": "#999",
				"drag-text": "#ccc",
				"error-text": "#ff4444",
				"border-color": "#545d70",
				"tr-even-bg-color": "#2e3440",
				"tr-odd-bg-color": "#161b22",
				"content-bg": "#545d70",
				"content-fg": "#e5eaf0",
				"content-hover-bg": "#2e3440",
				"content-hover-fg": "#e5eaf0",
				"bar-shadow": "rgba(0, 0, 0, 0.75) 0 0 0.5rem"
			}
		}
	},
	github: github_default,
	spooky: {
		id: "spooky",
		name: "Spooky",
		colors: {
			"node_slot": {
				"CLIP": "#ffb020",
				"CLIP_VISION": "#9ad1d4",
				"CLIP_VISION_OUTPUT": "#b0764e",
				"CONDITIONING": "#ff7518",
				"CONTROL_NET": "#7cf29a",
				"IMAGE": "#6fa8ff",
				"LATENT": "#e07bff",
				"MASK": "#9be564",
				"MODEL": "#a78bfa",
				"STYLE_MODEL": "#d4f58a",
				"VAE": "#ff4d5e",
				"NOISE": "#b8aec4",
				"GUIDER": "#5ef2e6",
				"SAMPLER": "#f2a7c3",
				"SIGMAS": "#c9f7c4",
				"TAESD": "#e3c26b"
			},
			"litegraph_base": {
				"BACKGROUND_IMAGE": "/assets/images/spooky-webs.png",
				"CLEAR_BACKGROUND_COLOR": "#0c0910",
				"LINK_COLOR": "#b48ad8",
				"CONNECTING_LINK_COLOR": "#ffb020"
			},
			"comfy_base": {},
			"theme": {
				"background": "#0c0910",
				"foreground": "#f4e9dc",
				"card": "#19121f",
				"primary": "#e35d12",
				"secondary": "#22182c",
				"muted": "#3b2452",
				"muted-foreground": "#a894b8",
				"accent": "#2c1e3a",
				"destructive": "#c2253c",
				"border": "#45305a",
				"input": "#140e1a",
				"ring": "#ff8a2b",
				"node": "#140f19",
				"node-foreground": "#c8b6d6",
				"node-header": "#2b1640",
				"node-border": "#5a3a7a",
				"warning": "#ffb020",
				"shadow-color": "rgb(18 0 32 / 0.6)"
			}
		}
	},
	skeleton: {
		id: "skeleton",
		name: "Skeleton",
		colors: {
			"node_slot": {},
			"litegraph_base": {
				"BACKGROUND_IMAGE": "/assets/images/skeleton-bones.png",
				"CLEAR_BACKGROUND_COLOR": "#0d0e11",
				"LINK_COLOR": "#c9c0aa",
				"CONNECTING_LINK_COLOR": "#ece6d6"
			},
			"comfy_base": {},
			"theme": {
				"background": "#0d0e11",
				"foreground": "#ece6d6",
				"card": "#17181c",
				"primary": "#5d6b85",
				"secondary": "#1c1d22",
				"muted": "#33343b",
				"muted-foreground": "#9d978a",
				"accent": "#25262c",
				"destructive": "#a8323a",
				"border": "#3b3c44",
				"input": "#121317",
				"ring": "#c9c0aa",
				"node": "#131418",
				"node-foreground": "#c4bdab",
				"node-header": "#23242a",
				"node-border": "#45464f",
				"warning": "#d9a93a",
				"shadow-color": "rgb(0 0 0 / 0.55)"
			}
		}
	},
	witch: {
		id: "witch",
		name: "Witch",
		colors: {
			"node_slot": {},
			"litegraph_base": {
				"BACKGROUND_IMAGE": "/assets/images/witch-brew.png",
				"CLEAR_BACKGROUND_COLOR": "#0e0a14",
				"LINK_COLOR": "#7ee36a",
				"CONNECTING_LINK_COLOR": "#b8f27a"
			},
			"comfy_base": {},
			"theme": {
				"background": "#0e0a14",
				"foreground": "#efe6f7",
				"card": "#1a1224",
				"primary": "#2f8a3a",
				"secondary": "#21172d",
				"muted": "#382650",
				"muted-foreground": "#a99bbb",
				"accent": "#2a1d39",
				"destructive": "#c0304a",
				"border": "#43305c",
				"input": "#120c1a",
				"ring": "#7ee36a",
				"node": "#150f1e",
				"node-foreground": "#cdbfe0",
				"node-header": "#2a1a3e",
				"node-border": "#553a78",
				"warning": "#e3b23c",
				"shadow-color": "rgb(20 0 40 / 0.6)"
			}
		}
	},
	zombie: {
		id: "zombie",
		name: "Zombie",
		colors: {
			"node_slot": {},
			"litegraph_base": {
				"BACKGROUND_IMAGE": "/assets/images/zombie-brains.png",
				"CLEAR_BACKGROUND_COLOR": "#0c110c",
				"LINK_COLOR": "#a6d65a",
				"CONNECTING_LINK_COLOR": "#e39aa8"
			},
			"comfy_base": {},
			"theme": {
				"background": "#0c110c",
				"foreground": "#e3ecd6",
				"card": "#151d15",
				"primary": "#5e8a2c",
				"secondary": "#1b241a",
				"muted": "#2e3d2a",
				"muted-foreground": "#93a387",
				"accent": "#222d20",
				"destructive": "#b3342e",
				"border": "#364632",
				"input": "#0f160f",
				"ring": "#a6d65a",
				"node": "#121a12",
				"node-foreground": "#c1cfb3",
				"node-header": "#2d2027",
				"node-border": "#4a5a3e",
				"warning": "#d6b23a",
				"shadow-color": "rgb(0 10 0 / 0.55)"
			}
		}
	},
	fennec: fennec_default
};
var DEFAULT_COLOR_PALETTE = dark_default;
var DEFAULT_DARK_COLOR_PALETTE = dark_default;
var DEFAULT_LIGHT_COLOR_PALETTE = light_default;
//#endregion
//#region src/schemas/colorPaletteSchema.ts
var nodeSlotSchema = object({
	CLIP: string(),
	CLIP_VISION: string(),
	CLIP_VISION_OUTPUT: string(),
	CONDITIONING: string(),
	CONTROL_NET: string(),
	IMAGE: string(),
	LATENT: string(),
	MASK: string(),
	MODEL: string(),
	STYLE_MODEL: string(),
	VAE: string(),
	NOISE: string(),
	GUIDER: string(),
	SAMPLER: string(),
	SIGMAS: string(),
	TAESD: string()
});
var litegraphBaseSchema = object({
	BACKGROUND_IMAGE: string(),
	CLEAR_BACKGROUND_COLOR: string(),
	NODE_TITLE_COLOR: string(),
	NODE_SELECTED_TITLE_COLOR: string(),
	NODE_TEXT_COLOR: string(),
	NODE_TEXT_HIGHLIGHT_COLOR: string(),
	NODE_DEFAULT_COLOR: string(),
	NODE_DEFAULT_BGCOLOR: string(),
	NODE_DEFAULT_BOXCOLOR: string(),
	NODE_DEFAULT_SHAPE: union([
		literal(RenderShape.BOX),
		literal(RenderShape.ROUND),
		literal(RenderShape.CARD),
		string()
	]),
	NODE_BOX_OUTLINE_COLOR: string(),
	NODE_BYPASS_BGCOLOR: string(),
	NODE_ERROR_COLOUR: string(),
	DEFAULT_SHADOW_COLOR: string(),
	WIDGET_BGCOLOR: string(),
	WIDGET_OUTLINE_COLOR: string(),
	WIDGET_TEXT_COLOR: string(),
	WIDGET_SECONDARY_TEXT_COLOR: string(),
	WIDGET_DISABLED_TEXT_COLOR: string(),
	LINK_COLOR: string(),
	EVENT_LINK_COLOR: string(),
	CONNECTING_LINK_COLOR: string(),
	BADGE_FG_COLOR: string(),
	BADGE_BG_COLOR: string()
});
var comfyBaseSchema = object({
	["fg-color"]: string(),
	["bg-color"]: string(),
	["bg-img"]: string().optional(),
	["comfy-menu-bg"]: string(),
	["comfy-menu-secondary-bg"]: string(),
	["comfy-input-bg"]: string(),
	["input-text"]: string(),
	["descrip-text"]: string(),
	["drag-text"]: string(),
	["error-text"]: string(),
	["border-color"]: string(),
	["tr-even-bg-color"]: string(),
	["tr-odd-bg-color"]: string(),
	["content-bg"]: string(),
	["content-fg"]: string(),
	["content-hover-bg"]: string(),
	["content-hover-fg"]: string(),
	["bar-shadow"]: string(),
	["contrast-mix-color"]: string().optional(),
	["interface-stroke"]: string().optional(),
	["interface-panel-surface"]: string().optional(),
	["interface-panel-box-shadow"]: string().optional(),
	["interface-panel-drop-shadow"]: string().optional(),
	["interface-floating-panel-shadow"]: string().optional(),
	["interface-panel-hover-surface"]: string().optional(),
	["interface-panel-selected-surface"]: string().optional(),
	["interface-button-hover-surface"]: string().optional()
});
/** Design-system theme variables a palette may override: the shadcn/tweakcn contract plus the node layer. */
var themeSchema = object({
	background: string(),
	foreground: string(),
	card: string(),
	popover: string(),
	primary: string(),
	secondary: string(),
	muted: string(),
	["muted-foreground"]: string(),
	accent: string(),
	destructive: string(),
	border: string(),
	input: string(),
	ring: string(),
	node: string(),
	["node-foreground"]: string(),
	["node-header"]: string(),
	["node-border"]: string(),
	warning: string(),
	["shadow-color"]: string()
}).partial();
var colorsSchema = object({
	node_slot: nodeSlotSchema,
	litegraph_base: litegraphBaseSchema,
	comfy_base: comfyBaseSchema,
	theme: themeSchema.optional()
});
var partialColorsSchema = object({
	node_slot: nodeSlotSchema.partial(),
	litegraph_base: litegraphBaseSchema.partial(),
	comfy_base: comfyBaseSchema.partial(),
	theme: themeSchema.optional()
});
var paletteSchema = object({
	id: string(),
	name: string(),
	colors: partialColorsSchema,
	light_theme: boolean().optional()
}).passthrough();
object({
	id: string(),
	name: string(),
	colors: colorsSchema
}).passthrough();
//#endregion
//#region src/utils/colorPaletteTheme.ts
var THEME_KEYS = themeSchema.keyof().options;
/** Whether the palette is the built-in dark or light palette. */
function isCorePaletteId(colorPaletteId) {
	return colorPaletteId === "dark" || colorPaletteId === "light";
}
function deriveLegacyTheme({ comfy_base, litegraph_base }) {
	const surface = comfy_base["interface-panel-surface"] ?? comfy_base["comfy-menu-bg"];
	const contrast = comfy_base["contrast-mix-color"] ?? "#fff";
	const mixWithContrast = (surfacePercent) => `color-mix(in srgb, ${surface} ${surfacePercent}%, ${contrast})`;
	return {
		background: surface,
		foreground: comfy_base["fg-color"],
		"muted-foreground": comfy_base["descrip-text"],
		border: comfy_base["interface-stroke"] ?? mixWithContrast(75.5),
		accent: comfy_base["interface-panel-hover-surface"] ?? comfy_base["interface-button-hover-surface"] ?? mixWithContrast(92.5),
		muted: comfy_base["interface-panel-selected-surface"] ?? mixWithContrast(87.5),
		card: comfy_base["comfy-menu-secondary-bg"],
		secondary: litegraph_base.NODE_DEFAULT_COLOR,
		input: litegraph_base.WIDGET_BGCOLOR,
		node: litegraph_base.NODE_DEFAULT_BGCOLOR,
		"node-foreground": litegraph_base.NODE_TEXT_COLOR,
		"node-header": litegraph_base.NODE_DEFAULT_COLOR,
		"node-border": litegraph_base.WIDGET_OUTLINE_COLOR
	};
}
var DERIVED_THEME_DEFAULTS = {
	popover: "var(--background)",
	input: "var(--accent)",
	ring: "var(--muted-foreground)",
	node: "var(--card)",
	"node-foreground": "var(--muted-foreground)",
	"node-header": "var(--secondary)",
	"node-border": "var(--border)"
};
function resolvePaletteTheme(palette) {
	const base = palette.light_theme ? DEFAULT_LIGHT_COLOR_PALETTE.colors.theme : DEFAULT_DARK_COLOR_PALETTE.colors.theme;
	const legacy = isCorePaletteId(palette.id) ? {} : deriveLegacyTheme(palette.colors);
	return {
		...DERIVED_THEME_DEFAULTS,
		...base,
		...legacy,
		...palette.colors.theme
	};
}
/** The CSS color scheme a palette's theme renders in. */
function paletteColorScheme(palette) {
	return palette.light_theme ? "light" : "dark";
}
/** Applies a palette's theme variables and color scheme to an element's inline style. */
function applyPaletteTheme(style, palette) {
	const theme = resolvePaletteTheme(palette);
	for (const key of THEME_KEYS) {
		const value = theme[key];
		if (value) style.setProperty(`--${key}`, value);
		else style.removeProperty(`--${key}`);
	}
	style.colorScheme = paletteColorScheme(palette);
}
/** Applies the core dark palette's theme variables to an element's inline style. */
function applyDarkPaletteTheme(style) {
	applyPaletteTheme(style, DEFAULT_DARK_COLOR_PALETTE);
}
//#endregion
export { comfyBaseSchema as a, DEFAULT_COLOR_PALETTE as c, paletteColorScheme as i, DEFAULT_DARK_COLOR_PALETTE as l, applyPaletteTheme as n, paletteSchema as o, isCorePaletteId as r, CORE_COLOR_PALETTES as s, applyDarkPaletteTheme as t, DEFAULT_LIGHT_COLOR_PALETTE as u };
