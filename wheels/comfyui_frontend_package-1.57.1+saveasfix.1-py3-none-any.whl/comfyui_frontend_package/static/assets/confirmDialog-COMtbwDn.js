import "./rolldown-runtime-xtsTai4I.js";
import { Ft as ref, G as defineComponent, H as createTextVNode, Ht as toValue, Kt as normalizeClass, L as createCommentVNode, P as computed, R as createElementBlock, U as createVNode, Wt as unref, Yt as toDisplayString, ct as openBlock, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
//#region src/components/dialog/confirm/ConfirmBody.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$2 = { class: "flex flex-col border-t p-4 text-sm/5 wrap-break-word text-muted-foreground" };
//#endregion
//#region src/components/dialog/confirm/ConfirmBody.vue
var ConfirmBody_default = /* @__PURE__ */ defineComponent({
	__name: "ConfirmBody",
	props: {
		promptText: {},
		preserveNewlines: {
			type: Boolean,
			default: false
		}
	},
	setup(__props) {
		const promptTextReal = computed(() => toValue(__props.promptText));
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$2, [promptTextReal.value ? (openBlock(), createElementBlock("p", {
				key: 0,
				class: normalizeClass(unref(cn)("m-0", __props.preserveNewlines && "whitespace-pre-line"))
			}, toDisplayString(promptTextReal.value), 3)) : createCommentVNode("", true)]);
		};
	}
});
//#endregion
//#region src/components/dialog/confirm/ConfirmFooter.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$1 = { class: "flex w-full flex-wrap items-center justify-end gap-4 p-4" };
//#endregion
//#region src/components/dialog/confirm/ConfirmFooter.vue
var ConfirmFooter_default = /* @__PURE__ */ defineComponent({
	__name: "ConfirmFooter",
	props: {
		cancelText: {},
		confirmText: {},
		confirmClass: {},
		confirmVariant: {},
		optionsDisabled: {}
	},
	emits: ["cancel", "confirm"],
	setup(__props, { emit: __emit }) {
		const { t } = useI18n();
		const emit = __emit;
		const settled = ref(false);
		const confirmTextX = computed(() => __props.confirmText || t("g.confirm"));
		const cancelTextX = computed(() => __props.cancelText || t("g.cancel"));
		const disabled = computed(() => settled.value || toValue(__props.optionsDisabled));
		function settle(choice) {
			if (settled.value) return;
			settled.value = true;
			if (choice === "cancel") emit("cancel");
			else emit("confirm");
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("section", _hoisted_1$1, [createVNode(Button_default, {
				disabled: disabled.value,
				variant: "muted-textonly",
				size: "lg",
				autofocus: "",
				onClick: _cache[0] || (_cache[0] = ($event) => settle("cancel"))
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(cancelTextX.value), 1)]),
				_: 1
			}, 8, ["disabled"]), createVNode(Button_default, {
				disabled: disabled.value,
				variant: __props.confirmVariant ?? "textonly",
				size: "lg",
				class: normalizeClass(__props.confirmClass),
				onClick: _cache[1] || (_cache[1] = ($event) => settle("confirm"))
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(confirmTextX.value), 1)]),
				_: 1
			}, 8, [
				"disabled",
				"variant",
				"class"
			])]);
		};
	}
});
//#endregion
//#region src/components/dialog/confirm/ConfirmHeader.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "flex items-center gap-2 p-4 text-sm font-normal" };
var _hoisted_2 = {
	key: 1,
	class: "flex-auto"
};
//#endregion
//#region src/components/dialog/confirm/ConfirmHeader.vue
var ConfirmHeader_default = /* @__PURE__ */ defineComponent({
	__name: "ConfirmHeader",
	props: {
		title: {},
		icon: {}
	},
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1, [__props.icon ? (openBlock(), createElementBlock("i", {
				key: 0,
				class: normalizeClass(unref(cn)(__props.icon, "size-4")),
				"aria-hidden": "true"
			}, null, 2)) : createCommentVNode("", true), __props.title ? (openBlock(), createElementBlock("span", _hoisted_2, toDisplayString(__props.title), 1)) : createCommentVNode("", true)]);
		};
	}
});
//#endregion
//#region src/components/dialog/confirm/confirmDialog.ts
function showConfirmDialog(options = {}) {
	const dialogStore = useDialogStore();
	const { key, headerProps, props, footerProps } = options;
	return dialogStore.showDialog({
		key,
		headerComponent: ConfirmHeader_default,
		component: ConfirmBody_default,
		footerComponent: ConfirmFooter_default,
		headerProps,
		props,
		footerProps,
		dialogComponentProps: { flush: true }
	});
}
//#endregion
export { showConfirmDialog as t };
