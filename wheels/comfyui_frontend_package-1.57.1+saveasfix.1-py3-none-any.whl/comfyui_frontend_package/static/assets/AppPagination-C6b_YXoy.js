import "./rolldown-runtime-xtsTai4I.js";
import { $ as mergeModels, F as createBaseVNode, G as defineComponent, H as createTextVNode, I as createBlock, Kt as normalizeClass, L as createCommentVNode, O as Fragment, R as createElementBlock, U as createVNode, Wt as unref, Yt as toDisplayString, _t as useModel, ct as openBlock, ut as renderList, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { $ as PaginationList_default, Q as PaginationListItem_default, X as PaginationPrev_default, Z as PaginationNext_default, et as PaginationRoot_default, tt as PaginationEllipsis_default } from "./vendor-reka-ui-NRTk7aIV.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { a as Select_default, i as SelectContent_default, n as SelectTrigger_default, r as SelectItem_default, t as SelectValue_default } from "./SelectValue-Biyqru5w.js";
//#region src/components/ui/pagination/Pagination.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "flex flex-wrap items-center justify-center gap-2" };
var _hoisted_2 = {
	key: 0,
	class: "mr-2 flex items-center gap-2"
};
var _hoisted_3 = { class: "text-sm text-muted-foreground" };
var ellipsisClass = "inline-flex size-8 items-center justify-center text-sm text-muted-foreground";
//#endregion
//#region src/components/ui/pagination/Pagination.vue
var Pagination_default = /* @__PURE__ */ defineComponent({
	__name: "Pagination",
	props: /*@__PURE__*/ mergeModels({
		total: {},
		itemsPerPageLabel: {},
		previousLabel: {},
		nextLabel: {},
		formatPageLabel: { type: Function },
		itemsPerPageOptions: {}
	}, {
		"page": { default: 1 },
		"pageModifiers": {},
		"itemsPerPage": { default: 10 },
		"itemsPerPageModifiers": {}
	}),
	emits: ["update:page", "update:itemsPerPage"],
	setup(__props) {
		const page = useModel(__props, "page");
		const itemsPerPage = useModel(__props, "itemsPerPage");
		function updateItemsPerPage(value) {
			if (typeof value !== "number") return;
			itemsPerPage.value = value;
			page.value = 1;
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(PaginationRoot_default), {
				page: page.value,
				"onUpdate:page": _cache[0] || (_cache[0] = ($event) => page.value = $event),
				total: __props.total,
				"items-per-page": itemsPerPage.value,
				"sibling-count": 1,
				"show-edges": ""
			}, {
				default: withCtx(() => [createBaseVNode("div", _hoisted_1, [
					__props.itemsPerPageOptions?.length ? (openBlock(), createElementBlock("div", _hoisted_2, [createBaseVNode("span", _hoisted_3, toDisplayString(__props.itemsPerPageLabel), 1), createVNode(Select_default, {
						"model-value": itemsPerPage.value,
						"onUpdate:modelValue": updateItemsPerPage
					}, {
						default: withCtx(() => [createVNode(SelectTrigger_default, {
							size: "md",
							class: "w-20",
							"aria-label": __props.itemsPerPageLabel
						}, {
							default: withCtx(() => [createVNode(SelectValue_default)]),
							_: 1
						}, 8, ["aria-label"]), createVNode(SelectContent_default, null, {
							default: withCtx(() => [(openBlock(true), createElementBlock(Fragment, null, renderList(__props.itemsPerPageOptions, (option) => {
								return openBlock(), createBlock(SelectItem_default, {
									key: option,
									value: option
								}, {
									default: withCtx(() => [createTextVNode(toDisplayString(option), 1)]),
									_: 2
								}, 1032, ["value"]);
							}), 128))]),
							_: 1
						})]),
						_: 1
					}, 8, ["model-value"])])) : createCommentVNode("", true),
					createVNode(unref(PaginationPrev_default), { "as-child": "" }, {
						default: withCtx(() => [createVNode(Button_default, {
							variant: "muted-textonly",
							size: "md",
							class: "text-sm",
							"aria-label": __props.previousLabel
						}, {
							default: withCtx(() => [_cache[1] || (_cache[1] = createBaseVNode("i", { class: "icon-[lucide--chevron-left] size-4" }, null, -1)), createTextVNode(" " + toDisplayString(__props.previousLabel), 1)]),
							_: 1
						}, 8, ["aria-label"])]),
						_: 1
					}),
					createVNode(unref(PaginationList_default), { class: "flex items-center gap-1" }, {
						default: withCtx(({ items }) => [(openBlock(true), createElementBlock(Fragment, null, renderList(items, (item, index) => {
							return openBlock(), createElementBlock(Fragment, { key: index }, [item.type === "page" ? (openBlock(), createBlock(unref(PaginationListItem_default), {
								key: 0,
								value: item.value,
								"as-child": ""
							}, {
								default: withCtx(() => [createVNode(Button_default, {
									variant: item.value === page.value ? "secondary" : "muted-textonly",
									size: "icon",
									"aria-label": __props.formatPageLabel(item.value)
								}, {
									default: withCtx(() => [createTextVNode(toDisplayString(item.value), 1)]),
									_: 2
								}, 1032, ["variant", "aria-label"])]),
								_: 2
							}, 1032, ["value"])) : (openBlock(), createBlock(unref(PaginationEllipsis_default), {
								key: 1,
								index,
								class: normalizeClass(ellipsisClass)
							}, {
								default: withCtx(() => [..._cache[2] || (_cache[2] = [createTextVNode(" … ", -1)])]),
								_: 1
							}, 8, ["index"]))], 64);
						}), 128))]),
						_: 1
					}),
					createVNode(unref(PaginationNext_default), { "as-child": "" }, {
						default: withCtx(() => [createVNode(Button_default, {
							variant: "muted-textonly",
							size: "md",
							class: "text-sm",
							"aria-label": __props.nextLabel
						}, {
							default: withCtx(() => [createTextVNode(toDisplayString(__props.nextLabel) + " ", 1), _cache[3] || (_cache[3] = createBaseVNode("i", { class: "icon-[lucide--chevron-right] size-4" }, null, -1))]),
							_: 1
						}, 8, ["aria-label"])]),
						_: 1
					})
				])]),
				_: 1
			}, 8, [
				"page",
				"total",
				"items-per-page"
			]);
		};
	}
});
//#endregion
//#region src/components/common/AppPagination.vue
var AppPagination_default = /* @__PURE__ */ defineComponent({
	__name: "AppPagination",
	props: /*@__PURE__*/ mergeModels({
		total: {},
		itemsPerPageOptions: {}
	}, {
		"page": { default: 1 },
		"pageModifiers": {},
		"itemsPerPage": { default: 10 },
		"itemsPerPageModifiers": {}
	}),
	emits: ["update:page", "update:itemsPerPage"],
	setup(__props) {
		const page = useModel(__props, "page");
		const itemsPerPage = useModel(__props, "itemsPerPage");
		const { t } = useI18n();
		return (_ctx, _cache) => {
			return openBlock(), createBlock(Pagination_default, {
				page: page.value,
				"onUpdate:page": _cache[0] || (_cache[0] = ($event) => page.value = $event),
				"items-per-page": itemsPerPage.value,
				"onUpdate:itemsPerPage": _cache[1] || (_cache[1] = ($event) => itemsPerPage.value = $event),
				total: __props.total,
				"items-per-page-options": __props.itemsPerPageOptions,
				"items-per-page-label": unref(t)("g.itemsPerPage"),
				"previous-label": unref(t)("g.previous"),
				"next-label": unref(t)("g.next"),
				"format-page-label": (page) => unref(t)("g.pageNumber", { page })
			}, null, 8, [
				"page",
				"items-per-page",
				"total",
				"items-per-page-options",
				"items-per-page-label",
				"previous-label",
				"next-label",
				"format-page-label"
			]);
		};
	}
});
//#endregion
export { AppPagination_default as t };
