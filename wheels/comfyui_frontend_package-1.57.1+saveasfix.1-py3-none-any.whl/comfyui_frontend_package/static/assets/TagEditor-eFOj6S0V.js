import "./rolldown-runtime-xtsTai4I.js";
import { $ as mergeModels, E as withModifiers, F as createBaseVNode, Ft as ref, G as defineComponent, I as createBlock, Kt as normalizeClass, L as createCommentVNode, O as Fragment, P as computed, R as createElementBlock, T as withKeys, U as createVNode, Wt as unref, X as inject, _t as useModel, at as onMounted, ct as openBlock, dt as renderSlot, et as mergeProps, lt as provide, ot as onUnmounted, tt as nextTick, ut as renderList, wt as withCtx, z as createPropsRestProxy } from "./vendor-vue-core-CuN1excl.js";
import { C as TagsInputItem_default$1, Mn as useForwardPropsEmits, Nn as useForwardProps, Pn as useForwardExpose, S as TagsInputItemDelete_default$1, T as TagsInputRoot_default, Wn as onClickOutside, Zn as useCurrentElement, w as TagsInputInput_default$1, x as TagsInputItemText_default$1 } from "./vendor-reka-ui-NRTk7aIV.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { r as tagVariants, t as TagRemoveButton_default } from "./TagRemoveButton-DmMMh2ek.js";
//#region src/components/ui/tags-input/tagsInputContext.ts
var tagsInputFocusKey = Symbol("tagsInputFocus");
var tagsInputIsEditingKey = Symbol("tagsInputIsEditing");
//#endregion
//#region src/components/ui/tags-input/TagsInput.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = {
	key: 0,
	"aria-hidden": "true",
	class: "absolute right-2 bottom-2 icon-[lucide--square-pen] size-4 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100"
};
//#endregion
//#region src/components/ui/tags-input/TagsInput.vue
var TagsInput_default = /* @__PURE__ */ defineComponent({
	__name: "TagsInput",
	props: {
		modelValue: {},
		defaultValue: {},
		addOnPaste: { type: Boolean },
		addOnTab: { type: Boolean },
		addOnBlur: { type: Boolean },
		duplicate: { type: Boolean },
		disabled: {
			type: Boolean,
			default: false
		},
		delimiter: {},
		dir: {},
		max: {},
		id: {},
		convertValue: { type: Function },
		displayValue: { type: Function },
		asChild: { type: Boolean },
		as: {},
		name: {},
		required: { type: Boolean },
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] },
		alwaysEditing: {
			type: Boolean,
			default: false
		}
	},
	emits: [
		"update:modelValue",
		"invalid",
		"addTag",
		"removeTag"
	],
	setup(__props, { emit: __emit }) {
		const restProps = createPropsRestProxy(__props, [
			"disabled",
			"alwaysEditing",
			"class"
		]);
		const emits = __emit;
		const isEditing = ref(false);
		const rootEl = useCurrentElement();
		const focusInput = ref();
		provide(tagsInputFocusKey, (callback) => {
			focusInput.value = callback;
		});
		const isEditingEnabled = computed(() => __props.alwaysEditing || isEditing.value);
		provide(tagsInputIsEditingKey, isEditingEnabled);
		const internalDisabled = computed(() => __props.disabled || !isEditingEnabled.value);
		const delegatedProps = computed(() => ({
			...restProps,
			disabled: internalDisabled.value
		}));
		const forwarded = useForwardPropsEmits(delegatedProps, emits);
		async function enableEditing() {
			if (!__props.disabled && !__props.alwaysEditing && !isEditing.value) {
				isEditing.value = true;
				await nextTick();
				focusInput.value?.();
			}
		}
		onClickOutside(rootEl, () => {
			if (!__props.alwaysEditing) isEditing.value = false;
		});
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(TagsInputRoot_default), mergeProps(unref(forwarded), {
				class: unref(cn)("group relative flex flex-wrap items-center gap-2 rounded-lg bg-transparent p-2 text-xs text-foreground", !internalDisabled.value && "focus-within:bg-muted hover:bg-muted", !__props.disabled && !isEditingEnabled.value && "cursor-pointer", __props.class),
				onClick: enableEditing
			}), {
				default: withCtx(({ modelValue }) => [renderSlot(_ctx.$slots, "default", { isEmpty: modelValue.length === 0 }), !__props.disabled && !isEditingEnabled.value ? (openBlock(), createElementBlock("i", _hoisted_1)) : createCommentVNode("", true)]),
				_: 3
			}, 16, ["class"]);
		};
	}
});
//#endregion
//#region src/components/ui/tags-input/TagsInputInput.vue
var TagsInputInput_default = /* @__PURE__ */ defineComponent({
	__name: "TagsInputInput",
	props: {
		placeholder: {},
		autoFocus: { type: Boolean },
		maxLength: {},
		asChild: { type: Boolean },
		as: {},
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] },
		isEmpty: {
			type: Boolean,
			default: false
		}
	},
	setup(__props) {
		const restProps = createPropsRestProxy(__props, ["isEmpty", "class"]);
		const forwardedProps = useForwardProps(restProps);
		const isEditing = inject(tagsInputIsEditingKey, ref(true));
		const showInput = computed(() => isEditing.value || __props.isEmpty);
		const { forwardRef, currentElement } = useForwardExpose();
		const registerFocus = inject(tagsInputFocusKey, void 0);
		function handleEscape() {
			currentElement.value?.blur();
			isEditing.value = false;
		}
		onMounted(() => {
			registerFocus?.(() => currentElement.value?.focus());
		});
		onUnmounted(() => {
			registerFocus?.(void 0);
		});
		return (_ctx, _cache) => {
			return showInput.value ? (openBlock(), createBlock(unref(TagsInputInput_default$1), mergeProps({
				key: 0,
				ref: unref(forwardRef)
			}, unref(forwardedProps), {
				class: unref(cn)("min-h-6 flex-1 appearance-none border-none bg-transparent text-xs text-muted-foreground placeholder:text-muted-foreground focus:outline-none", !unref(isEditing) && "pointer-events-none", __props.class),
				onKeydown: withKeys(withModifiers(handleEscape, ["stop"]), ["escape"])
			}), null, 16, ["class", "onKeydown"])) : createCommentVNode("", true);
		};
	}
});
//#endregion
//#region src/components/ui/tags-input/TagsInputItem.vue
var TagsInputItem_default = /* @__PURE__ */ defineComponent({
	__name: "TagsInputItem",
	props: {
		value: {},
		disabled: { type: Boolean },
		asChild: { type: Boolean },
		as: {},
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	},
	setup(__props) {
		const restProps = createPropsRestProxy(__props, ["class"]);
		const forwardedProps = useForwardProps(restProps);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(TagsInputItem_default$1), mergeProps(unref(forwardedProps), { class: unref(cn)(unref(tagVariants)({ removable: true }), __props.class) }), {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
				_: 3
			}, 16, ["class"]);
		};
	}
});
//#endregion
//#region src/components/ui/tags-input/TagsInputItemDelete.vue
var TagsInputItemDelete_default = /* @__PURE__ */ defineComponent({
	__name: "TagsInputItemDelete",
	props: {
		asChild: { type: Boolean },
		as: {},
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	},
	setup(__props) {
		const restProps = createPropsRestProxy(__props, ["class"]);
		const forwardedProps = useForwardProps(restProps);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(TagsInputItemDelete_default$1), mergeProps(unref(forwardedProps), {
				as: TagRemoveButton_default,
				"aria-labelledby": void 0,
				class: __props.class
			}), {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default", {}, () => [_cache[0] || (_cache[0] = createBaseVNode("i", { class: "icon-[lucide--x] size-4" }, null, -1))])]),
				_: 3
			}, 16, ["class"]);
		};
	}
});
//#endregion
//#region src/components/ui/tags-input/TagsInputItemText.vue
var TagsInputItemText_default = /* @__PURE__ */ defineComponent({
	__name: "TagsInputItemText",
	props: {
		asChild: { type: Boolean },
		as: {},
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	},
	setup(__props) {
		const restProps = createPropsRestProxy(__props, ["class"]);
		const forwardedProps = useForwardProps(restProps);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(TagsInputItemText_default$1), mergeProps(unref(forwardedProps), { class: unref(cn)("min-w-0 truncate bg-transparent text-xs", __props.class) }), null, 16, ["class"]);
		};
	}
});
//#endregion
//#region src/components/common/TagEditor.vue
var TagEditor_default = /* @__PURE__ */ defineComponent({
	__name: "TagEditor",
	props: /*@__PURE__*/ mergeModels({
		addOnPaste: { type: Boolean },
		addOnTab: { type: Boolean },
		addOnBlur: { type: Boolean },
		duplicate: { type: Boolean },
		disabled: { type: Boolean },
		delimiter: {},
		dir: {},
		max: {},
		id: {},
		convertValue: { type: Function },
		displayValue: { type: Function },
		asChild: { type: Boolean },
		as: {},
		name: {},
		required: { type: Boolean },
		alwaysEditing: { type: Boolean },
		placeholder: {},
		itemClass: { type: [
			Boolean,
			null,
			String,
			Object,
			Array,
			Function
		] }
	}, {
		"modelValue": { default: () => [] },
		"modelModifiers": {}
	}),
	emits: ["update:modelValue"],
	setup(__props) {
		const rootProps = createPropsRestProxy(__props, ["placeholder", "itemClass"]);
		const tags = useModel(__props, "modelValue");
		const { t } = useI18n();
		return (_ctx, _cache) => {
			return openBlock(), createBlock(TagsInput_default, mergeProps({
				modelValue: tags.value,
				"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => tags.value = $event)
			}, rootProps), {
				default: withCtx(({ isEmpty }) => [(openBlock(true), createElementBlock(Fragment, null, renderList(tags.value, (tag) => {
					return openBlock(), createBlock(TagsInputItem_default, {
						key: tag,
						value: tag,
						class: normalizeClass(typeof __props.itemClass === "function" ? __props.itemClass(tag) : __props.itemClass)
					}, {
						default: withCtx(() => [createVNode(TagsInputItemText_default), createVNode(TagsInputItemDelete_default, { "aria-label": unref(t)("g.removeTag") }, null, 8, ["aria-label"])]),
						_: 1
					}, 8, ["value", "class"]);
				}), 128)), renderSlot(_ctx.$slots, "input", { isEmpty }, () => [createVNode(TagsInputInput_default, {
					"is-empty": isEmpty,
					placeholder: __props.placeholder
				}, null, 8, ["is-empty", "placeholder"])])]),
				_: 3
			}, 16, ["modelValue"]);
		};
	}
});
//#endregion
export { TagsInput_default as a, TagsInputInput_default as i, TagsInputItemText_default as n, TagsInputItem_default as r, TagEditor_default as t };
