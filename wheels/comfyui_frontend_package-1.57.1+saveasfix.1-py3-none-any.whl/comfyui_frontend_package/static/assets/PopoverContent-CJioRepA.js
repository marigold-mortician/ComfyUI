import "./rolldown-runtime-xtsTai4I.js";
import { G as defineComponent, I as createBlock, P as computed, U as createVNode, Wt as unref, ct as openBlock, dt as renderSlot, et as mergeProps, wt as withCtx, z as createPropsRestProxy } from "./vendor-vue-core-CuN1excl.js";
import { Dt as PopoverContent_default$1, Et as PopoverPortal_default, Mn as useForwardPropsEmits, Mt as injectPopoverRootContext } from "./vendor-reka-ui-NRTk7aIV.js";
import { t as cn } from "./src-BHQtMnZc.js";
//#endregion
//#region src/components/ui/popover/PopoverContent.vue
var PopoverContent_default = /* @__PURE__ */ defineComponent({
	inheritAttrs: false,
	__name: "PopoverContent",
	props: {
		forceMount: { type: Boolean },
		memoDependencies: {},
		side: {},
		sideOffset: { default: 4 },
		sideFlip: { type: Boolean },
		align: { default: "center" },
		alignOffset: {},
		alignFlip: { type: Boolean },
		avoidCollisions: { type: Boolean },
		collisionBoundary: {},
		collisionPadding: {},
		arrowPadding: {},
		hideShiftedArrow: { type: Boolean },
		sticky: {},
		hideWhenDetached: { type: Boolean },
		positionStrategy: {},
		updatePositionStrategy: {},
		disableUpdateOnLayoutShift: { type: Boolean },
		prioritizePosition: { type: Boolean },
		reference: {},
		dir: {},
		asChild: { type: Boolean },
		as: {},
		disableOutsidePointerEvents: { type: Boolean },
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	},
	emits: [
		"escapeKeyDown",
		"pointerDownOutside",
		"focusOutside",
		"interactOutside",
		"openAutoFocus",
		"closeAutoFocus"
	],
	setup(__props, { emit: __emit }) {
		const restProps = createPropsRestProxy(__props, [
			"align",
			"sideOffset",
			"class"
		]);
		const emits = __emit;
		const delegatedProps = computed(() => ({
			align: __props.align,
			sideOffset: __props.sideOffset,
			...restProps
		}));
		const forwarded = useForwardPropsEmits(delegatedProps, emits);
		const rootContext = injectPopoverRootContext();
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(PopoverPortal_default), { key: Number(restProps.forceMount || unref(rootContext).open.value) }, {
				default: withCtx(() => [createVNode(unref(PopoverContent_default$1), mergeProps({
					...unref(forwarded),
					..._ctx.$attrs
				}, { class: unref(cn)("z-overlay w-72 rounded-md border bg-background p-4 text-foreground shadow-md outline-none", "data-[state=closed]:animate-out data-[state=open]:animate-in", "data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", "data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", "data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2", "data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2", __props.class) }), {
					default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
					_: 3
				}, 16, ["class"])]),
				_: 3
			});
		};
	}
});
//#endregion
export { PopoverContent_default as t };
