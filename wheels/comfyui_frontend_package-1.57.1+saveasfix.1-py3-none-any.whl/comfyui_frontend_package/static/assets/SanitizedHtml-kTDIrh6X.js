import "./rolldown-runtime-xtsTai4I.js";
import { G as defineComponent, P as computed, R as createElementBlock, ct as openBlock, et as mergeProps } from "./vendor-vue-core-CuN1excl.js";
import { r as purify } from "./vendor-markdown-CtxqRwKg.js";
//#region src/components/common/SanitizedHtml.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = ["innerHTML"];
var _hoisted_2 = ["innerHTML"];
//#endregion
//#region src/components/common/SanitizedHtml.vue
var SanitizedHtml_default = /* @__PURE__ */ defineComponent({
	inheritAttrs: false,
	__name: "SanitizedHtml",
	props: {
		html: {},
		as: { default: "div" },
		profile: { default: "default" }
	},
	setup(__props) {
		const purifier = purify(window);
		purifier.addHook("uponSanitizeAttribute", (node, data) => {
			if (data.attrName !== "style") return;
			if (__props.profile !== "highlighted-code" || !(node instanceof HTMLSpanElement)) {
				data.keepAttr = false;
				return;
			}
			const source = document.createElement("span").style;
			const allowed = document.createElement("span").style;
			source.cssText = data.attrValue;
			for (const property of [
				"color",
				"font-style",
				"font-weight"
			]) allowed.setProperty(property, source.getPropertyValue(property));
			data.attrValue = allowed.cssText;
			data.keepAttr = data.attrValue.length > 0;
		});
		const sanitizedHtml = computed(() => purifier.sanitize(__props.html, {
			ADD_TAGS: ["video", "source"],
			ADD_ATTR: [
				"controls",
				"autoplay",
				"loop",
				"muted",
				"preload",
				"poster",
				"target",
				"rel"
			],
			FORBID_TAGS: [
				"form",
				"input",
				"button"
			],
			FORBID_ATTR: __props.profile === "highlighted-code" ? [] : ["style"]
		}));
		return (_ctx, _cache) => {
			return __props.as === "span" ? (openBlock(), createElementBlock("span", mergeProps({ key: 0 }, _ctx.$attrs, { innerHTML: sanitizedHtml.value }), null, 16, _hoisted_1)) : (openBlock(), createElementBlock("div", mergeProps({ key: 1 }, _ctx.$attrs, { innerHTML: sanitizedHtml.value }), null, 16, _hoisted_2));
		};
	}
});
//#endregion
export { SanitizedHtml_default as t };
