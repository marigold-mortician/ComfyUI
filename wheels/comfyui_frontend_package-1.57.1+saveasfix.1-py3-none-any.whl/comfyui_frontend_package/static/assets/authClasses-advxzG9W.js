//#region src/platform/cloud/onboarding/constants/authClasses.ts
var CLOUD_AUTH_FIELD_CLASS = "h-11 rounded-2xl bg-white/8 text-primary-warm-white placeholder:text-white/40 xl:h-12 **:data-[slot=input-group-control]:placeholder:text-white/40 **:data-[slot=input-group-button]:text-primary-comfy-canvas/70";
var CLOUD_AUTH_LABEL_CLASS = "text-base font-normal text-primary-comfy-canvas/70";
/** Buttons styled as links: they toggle form mode, they do not navigate. */
var CLOUD_AUTH_LINK_BUTTON_CLASS = "mt-2 cursor-pointer self-center border-none bg-transparent p-0 font-[inherit] text-base text-primary-comfy-canvas underline transition-all duration-300 hover:text-white sm:text-lg";
//#endregion
export { CLOUD_AUTH_LABEL_CLASS as n, CLOUD_AUTH_LINK_BUTTON_CLASS as r, CLOUD_AUTH_FIELD_CLASS as t };
