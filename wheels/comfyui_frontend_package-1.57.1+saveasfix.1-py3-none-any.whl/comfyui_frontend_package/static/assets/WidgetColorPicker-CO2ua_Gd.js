import "./rolldown-runtime-xtsTai4I.js";
import { $ as mergeModels, Ft as ref, G as defineComponent, I as createBlock, U as createVNode, Wt as unref, _t as useModel, bt as watch, ct as openBlock, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { c as isColorFormat, g as toHexFromFormat, r as hexToInt, s as intToHex } from "./colorUtil--RFe1UD6.js";
import { t as AppColorPicker_default } from "./AppColorPicker-DF4cO9Dd.js";
import { t as WidgetLayoutField_default } from "./WidgetLayoutField-CjkLdz-i.js";
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/components/WidgetColorPicker.vue
var WidgetColorPicker_default = /* @__PURE__ */ defineComponent({
	__name: "WidgetColorPicker",
	props: /*@__PURE__*/ mergeModels({ widget: {} }, {
		"modelValue": { required: true },
		"modelModifiers": {}
	}),
	emits: ["update:modelValue"],
	setup(__props) {
		const modelValue = useModel(__props, "modelValue");
		const format = __props.widget.options?.format === "int" || isColorFormat(__props.widget.options?.format) ? __props.widget.options.format : "hex";
		function toPickerValue(value) {
			if (format === "int") return typeof value === "number" ? intToHex(value) : "#000000";
			return toHexFromFormat(value || "#000000", format);
		}
		const localValue = ref(toPickerValue(modelValue.value));
		watch(modelValue, (newVal) => {
			localValue.value = toPickerValue(newVal);
		});
		function onUpdate(val) {
			localValue.value = val;
			modelValue.value = format === "int" ? hexToInt(val) : val;
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(WidgetLayoutField_default, { widget: __props.widget }, {
				default: withCtx(() => [createVNode(AppColorPicker_default, {
					modelValue: localValue.value,
					"onUpdate:modelValue": [_cache[0] || (_cache[0] = ($event) => localValue.value = $event), onUpdate],
					alpha: unref(format) !== "int"
				}, null, 8, ["modelValue", "alpha"])]),
				_: 1
			}, 8, ["widget"]);
		};
	}
});
//#endregion
export { WidgetColorPicker_default as default };
