import "./rolldown-runtime-xtsTai4I.js";
import { F as createBaseVNode, G as defineComponent, H as createTextVNode, I as createBlock, Kt as normalizeClass, L as createCommentVNode, O as Fragment, P as computed, R as createElementBlock, U as createVNode, Wt as unref, Yt as toDisplayString, ct as openBlock, dt as renderSlot, et as mergeProps, p as storeToRefs, rt as onBeforeUnmount, ut as renderList, wt as withCtx, z as createPropsRestProxy } from "./vendor-vue-core-CuN1excl.js";
import { Mn as useForwardPropsEmits, Nn as useForwardProps, _ as ToastRoot_default$1, b as ToastProvider_default, g as ToastTitle_default$1, h as ToastViewport_default$1, v as ToastDescription_default$1, y as ToastClose_default$1 } from "./vendor-reka-ui-NRTk7aIV.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { t as useToast } from "./toastStore-Dg65fRgL.js";
//#endregion
//#region src/components/ui/toast/ToastClose.vue
var ToastClose_default = /* @__PURE__ */ defineComponent({
	__name: "ToastClose",
	props: {
		asChild: { type: Boolean },
		as: {},
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	},
	setup(__props) {
		const restProps = createPropsRestProxy(__props, ["class"]);
		const forwardedProps = useForwardProps(restProps);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(ToastClose_default$1), mergeProps(unref(forwardedProps), { "as-child": "" }), {
				default: withCtx(() => [createVNode(Button_default, {
					variant: "muted-textonly",
					size: "icon-sm",
					class: normalizeClass(unref(cn)("ml-auto", __props.class))
				}, {
					default: withCtx(() => [..._cache[0] || (_cache[0] = [createBaseVNode("i", {
						class: "icon-[lucide--x] size-4",
						"aria-hidden": "true"
					}, null, -1)])]),
					_: 1
				}, 8, ["class"])]),
				_: 1
			}, 16);
		};
	}
});
//#endregion
//#region src/components/ui/toast/ToastDescription.vue
var ToastDescription_default = /* @__PURE__ */ defineComponent({
	__name: "ToastDescription",
	props: {
		asChild: { type: Boolean },
		as: {},
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	},
	setup(__props) {
		const restProps = createPropsRestProxy(__props, ["class"]);
		const forwardedProps = useForwardProps(restProps);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(ToastDescription_default$1), mergeProps(unref(forwardedProps), { class: unref(cn)("mt-1 text-sm wrap-break-word whitespace-pre-line text-muted-foreground", __props.class) }), {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
				_: 3
			}, 16, ["class"]);
		};
	}
});
//#endregion
//#region src/components/ui/toast/ToastRoot.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$1 = {
	class: "contents",
	"data-reka-toast-announce-exclude": ""
};
//#endregion
//#region src/components/ui/toast/ToastRoot.vue
var ToastRoot_default = /* @__PURE__ */ defineComponent({
	__name: "ToastRoot",
	props: {
		defaultOpen: { type: Boolean },
		forceMount: { type: Boolean },
		type: {},
		open: { type: Boolean },
		duration: {},
		toast: {},
		asChild: { type: Boolean },
		as: {},
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	},
	emits: [
		"escapeKeyDown",
		"pause",
		"resume",
		"swipeStart",
		"swipeMove",
		"swipeCancel",
		"swipeEnd",
		"update:open"
	],
	setup(__props, { emit: __emit }) {
		const restProps = createPropsRestProxy(__props, ["class"]);
		const forwarded = useForwardPropsEmits(restProps, __emit);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(ToastRoot_default$1), mergeProps(unref(forwarded), {
				"aria-live": "off",
				class: unref(cn)("pointer-events-auto relative grid w-full grid-cols-[auto_minmax(0,1fr)_auto] items-start gap-x-3 rounded-lg border bg-background p-4 shadow-lg", __props.class)
			}), {
				default: withCtx(() => [createBaseVNode("div", _hoisted_1$1, [renderSlot(_ctx.$slots, "default")])]),
				_: 3
			}, 16, ["class"]);
		};
	}
});
//#endregion
//#region src/components/ui/toast/ToastTitle.vue
var ToastTitle_default = /* @__PURE__ */ defineComponent({
	__name: "ToastTitle",
	props: {
		asChild: { type: Boolean },
		as: {},
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	},
	setup(__props) {
		const restProps = createPropsRestProxy(__props, ["class"]);
		const forwardedProps = useForwardProps(restProps);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(ToastTitle_default$1), mergeProps(unref(forwardedProps), { class: unref(cn)("text-sm font-medium wrap-break-word whitespace-pre-line", __props.class) }), {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
				_: 3
			}, 16, ["class"]);
		};
	}
});
//#endregion
//#region src/components/ui/toast/ToastViewport.vue
var ToastViewport_default = /* @__PURE__ */ defineComponent({
	__name: "ToastViewport",
	props: {
		hotkey: {},
		label: { type: [String, Function] },
		asChild: { type: Boolean },
		as: {},
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	},
	setup(__props) {
		const restProps = createPropsRestProxy(__props, ["class"]);
		const forwardedProps = useForwardProps(restProps);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(ToastViewport_default$1), mergeProps(unref(forwardedProps), { "as-child": "" }), {
				default: withCtx(() => [createBaseVNode("ol", { class: normalizeClass(["z-toast", unref(cn)("pointer-events-none fixed top-20 right-(--workspace-inset-right,0px) m-0 flex max-h-[calc(100dvh-5rem)] w-full max-w-sm flex-col gap-2 overflow-y-auto p-2 supports-[right:anchor(--a_right)]:top-[anchor(--graph-canvas-panel_top,0px)] supports-[right:anchor(--a_right)]:right-[anchor(--graph-canvas-panel_right,anchor(--docked-agent-panel_left,var(--workspace-inset-right,0px)))] [:root:has([data-reka-dialog-content][data-state=open]:not([data-maximized]))_&]:top-0", __props.class)]) }, null, 2)]),
				_: 1
			}, 16);
		};
	}
});
//#endregion
//#region src/components/ui/toast/Toaster.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "sr-only" };
var _hoisted_2 = ["aria-label"];
var _hoisted_3 = ["aria-label"];
//#endregion
//#region src/components/ui/toast/Toaster.vue
var Toaster_default = /* @__PURE__ */ defineComponent({
	__name: "Toaster",
	props: {
		regionLabel: {},
		closeLabel: {},
		formatViewportLabel: { type: Function }
	},
	setup(__props) {
		const toast = useToast();
		const { held, toasts } = storeToRefs(toast);
		onBeforeUnmount(toast.dismissAll);
		const shownToasts = computed(() => held.value ? [] : toasts.value);
		const isAssertive = (item) => item.kind === "error" || item.kind === "warning";
		const politeToasts = computed(() => toasts.value.filter((item) => !isAssertive(item)));
		const assertiveToasts = computed(() => toasts.value.filter(isAssertive));
		function announcement(item) {
			return [
				item.title,
				item.description,
				item.action?.label
			].filter(Boolean).join(". ");
		}
		let escapeToastId;
		function preserveToastOnEscape(event, id) {
			if (!event.defaultPrevented) escapeToastId = id;
		}
		function updateToastOpen(id, open) {
			if (open) return;
			if (escapeToastId === id) {
				escapeToastId = void 0;
				return;
			}
			toast.dismiss(id);
		}
		const icons = {
			success: "icon-[lucide--circle-check] text-success",
			error: "icon-[lucide--circle-x] text-destructive",
			info: "icon-[lucide--info] text-primary",
			warning: "icon-[lucide--triangle-alert] text-warning",
			loading: "icon-[lucide--loader-circle] motion-safe:animate-spin text-primary"
		};
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock(Fragment, null, [createBaseVNode("div", _hoisted_1, [createBaseVNode("div", {
				role: "status",
				"aria-live": "polite",
				"aria-atomic": "false",
				"aria-label": __props.regionLabel
			}, [(openBlock(true), createElementBlock(Fragment, null, renderList(politeToasts.value, (item) => {
				return openBlock(), createElementBlock("p", { key: item.id }, toDisplayString(announcement(item)), 1);
			}), 128))], 8, _hoisted_2), createBaseVNode("div", {
				role: "alert",
				"aria-live": "assertive",
				"aria-atomic": "false",
				"aria-label": __props.regionLabel
			}, [(openBlock(true), createElementBlock(Fragment, null, renderList(assertiveToasts.value, (item) => {
				return openBlock(), createElementBlock("p", { key: item.id }, toDisplayString(announcement(item)), 1);
			}), 128))], 8, _hoisted_3)]), shownToasts.value.length ? (openBlock(), createBlock(unref(ToastProvider_default), {
				key: 0,
				label: __props.regionLabel,
				"disable-swipe": ""
			}, {
				default: withCtx(() => [(openBlock(true), createElementBlock(Fragment, null, renderList(shownToasts.value, (item) => {
					return openBlock(), createBlock(ToastRoot_default, {
						key: item.instance,
						open: true,
						duration: item.duration,
						"data-testid": "toast",
						"data-toast-kind": item.kind,
						onEscapeKeyDown: ($event) => preserveToastOnEscape($event, item.id),
						"onUpdate:open": ($event) => updateToastOpen(item.id, $event)
					}, {
						default: withCtx(() => [
							createBaseVNode("i", {
								class: normalizeClass(unref(cn)(icons[item.kind], "col-start-1 row-start-1 size-5")),
								"aria-hidden": "true"
							}, null, 2),
							createVNode(ToastTitle_default, { class: "col-start-2 row-start-1" }, {
								default: withCtx(() => [createTextVNode(toDisplayString(item.title), 1)]),
								_: 2
							}, 1024),
							item.closable ? (openBlock(), createBlock(ToastClose_default, {
								key: 0,
								"aria-label": __props.closeLabel,
								class: "col-start-3 row-start-1",
								"data-testid": "toast-close"
							}, null, 8, ["aria-label"])) : createCommentVNode("", true),
							item.description ? (openBlock(), createBlock(ToastDescription_default, {
								key: 1,
								class: "col-start-2 row-start-2"
							}, {
								default: withCtx(() => [createTextVNode(toDisplayString(item.description), 1)]),
								_: 2
							}, 1024)) : createCommentVNode("", true),
							item.action ? (openBlock(), createBlock(Button_default, {
								key: 2,
								class: "col-span-2 col-start-2 row-start-3 mt-3 justify-self-end",
								size: "md",
								variant: "secondary",
								onClick: ($event) => item.action.onClick()
							}, {
								default: withCtx(() => [createTextVNode(toDisplayString(item.action.label), 1)]),
								_: 2
							}, 1032, ["onClick"])) : createCommentVNode("", true)
						]),
						_: 2
					}, 1032, [
						"duration",
						"data-toast-kind",
						"onEscapeKeyDown",
						"onUpdate:open"
					]);
				}), 128)), createVNode(ToastViewport_default, {
					label: __props.formatViewportLabel,
					"data-testid": "toast-viewport"
				}, null, 8, ["label"])]),
				_: 1
			}, 8, ["label"])) : createCommentVNode("", true)], 64);
		};
	}
});
//#endregion
//#region src/components/common/AppToaster.vue
var AppToaster_default = /* @__PURE__ */ defineComponent({
	__name: "AppToaster",
	props: {
		regionLabel: {},
		closeLabel: {},
		formatViewportLabel: { type: Function }
	},
	setup(__props) {
		const { t } = useI18n();
		return (_ctx, _cache) => {
			return openBlock(), createBlock(Toaster_default, {
				"close-label": __props.closeLabel ?? unref(t)("g.close"),
				"region-label": __props.regionLabel ?? unref(t)("toastMessages.notificationsLabel"),
				"format-viewport-label": __props.formatViewportLabel ?? ((hotkey) => unref(t)("toastMessages.notificationsViewportLabel", { hotkey }))
			}, null, 8, [
				"close-label",
				"region-label",
				"format-viewport-label"
			]);
		};
	}
});
//#endregion
export { AppToaster_default as t };
