const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./useLayerEditor-CNrN-oWG.js","./rolldown-runtime-xtsTai4I.js","./nodeOutputStore-DmbNgTmp.js","./litegraph-CgrqhFEE.js","./noop-CsGmlYWz.js","./cloneDeep-BX7AjX4w.js","./globalThis-B6Vbq1EF.js","./isPlainObject-6prWdO5v.js","./get-Bk-Y8oEe.js","./isObject-BDwzDI3k.js","./vendor-vue-core-CuN1excl.js","./vendor-reka-ui-NRTk7aIV.js","./colorUtil--RFe1UD6.js","./telemetry-IkzvF0TI.js","./vendor-zod-Del_rmdp.js","./i18n-BRluoVl-.js","./preload-helper-sJeoGctA.js","./vendor-i18n-pA_PV1p-.js","./formatUtil-DsZFGVbT.js","./commands-C9zyhK6Q.js","./main-BtaRoPyL.js","./nodeDefs-BUEI64H3.js","./settings-B3DInspu.js","./reportError-BHgDVvfb.js","./hostTelemetryEnabled-DM7ML37c.js","./remoteConfig-VmmsGxJZ.js","./vendor-sentry-zSXGkMPN.js","./errorUtil-DoQyAUQC.js","./rerouteId-1TDIYZkX.js","./graphTraversalUtil-BUK1cr2m.js","./globalEnums-BPoISudO.js","./assert--qJvwrYk.js","./vendor-markdown-CtxqRwKg.js","./widget-TCRFSGUe.js","./vendor-yjs-DzSvc5Ii.js","./litegraphUtil-B_WxWXjg.js","./iteratee-D-xtYlr8.js","./map--HGZfCRO.js","./appInstance-CiT6CpGM.js","./inputSpecTree-B0INjagH.js","./api-BdJmXw98.js","./requestAuth-COoKVLz2.js","./zod.gen-DzuaBm8H.js","./vendor-axios-QnwcNXlY.js","./requestTimeout-DkmiEk-h.js","./vendor-firebase-B37L--zT.js","./toastStore-Dg65fRgL.js","./workflowStore-DP6mciq-.js","./treeUtil-4aExWhwq.js","./settingStore-DRRi2kOn.js","./delay-Cu8bS1zn.js","./dialogService-CqZr0BhP.js","./commandStore-XD_i1hej.js","./useErrorHandling-WrECc0C0.js","./Button-CcqmlVQb.js","./src-BHQtMnZc.js","./dialogStore-Dm9z8_kv.js","./DialogTitle-CWOHHLwH.js","./useCopyToClipboard-DUbSOtYA.js","./systemStatsStore-DAY0RqGT.js","./Input-12QxL1XI.js","./storageIO-CAjGLygi.js","./colorPaletteTheme-BLTbQMIT.js","./utils-DPLBHlcF.js","./downloadUtil-PDRccee-.js","./layerEditorDialogKey-j8nal3kA.js","./layerEditorDialog-Djrjyxdb.js","./Load3D-p6d5xKyZ.js","./Load3D-Dyle5OtG.js","./constants-CcZ5JemZ.js","./menuStyles-BC25qUwO.js","./Slider-Ba9vS1t0.js","./AnimationControls-CuO05S2B.js","./SelectValue-Biyqru5w.js","./menuBarStyles-Bea0qWup.js","./Popover-Cjk42F0c.js","./PopoverContent-CJioRepA.js","./Load3dViewerContent-Djy3nboa.js","./ToggleGroupItem-B6sGt08k.js","./toggle-group-Cn40zTWz.js","./useLoad3dViewer-D3tgLU8i.js","./createLoad3d-DVjBd0bL.js","./vendor-three-B-UiePqj.js","./ViewHelperManager-BpbYuVKl.js","./sharedWebGLRenderer-BSlxZGp0.js","./quick-lru-CwZ_Nev1.js","./Load3dUtils-CF3OvEZx.js","./reportLoadModelOutcome-DAkHX512.js","./load3dHost-B4KoEUu1.js","./assetPreviewUtil-DBI8HYUU.js","./useFeatureFlags-B3zg5FdZ.js","./assetsStore-CNmOJwRQ.js","./teamWorkspaceStore-BNm5cZOK.js","./ssoTelemetry-DZUrpShr.js","./telemetry-CRUTYyCh.js","./comfyApi-CXw0-V35.js","./desktopHostSession-B3KqJnXo.js","./ssoRequiredDialogKey-DRv9w9ql.js","./errors-Bls3VadO.js","./agentPanelStore-DndzlR19.js","./clamp-C6J77Y5a.js","./nodeDefStore-CF96GLZA.js","./uniq-HSN5S90b.js","./vendor-vueuse-ehQVlHrl.js","./executionStore-DSsREODN.js","./executionErrorStore-MSMBxScr.js","./canvasStore-Dnz7OWvY.js","./assetMetadataUtils-IzKjxxiA.js","./cloudPreviewUtil-QoYZLRNr.js","./resultItemUrl-BV9Vi8QF.js","./hdrFormatUtil-rFvza1J0.js","./load3dInstances-ykQ7kIrj.js","./load3dService-GTTDHdYH.js","./load3dViewerDialog-D35Ppx7u.js","./LoadingOverlay-BMlANKim.js","./useLoad3d-Df_2HUt2.js","./app-CSsV1u1T.js","./appModeStore-D8l_HeOH.js","./shuffle-CnBsCH60.js","./debounce-CrddqoI1.js","./deburr-BNFMXPzm.js","./queueSettingsStore-BzKxsLQU.js","./sidebarTabStore-DSQyJJJG.js","./workflowFlattening-DY0Vs9rF.js","./modalUtil-Cmzr62_V.js","./useBillingContext-Cc-YANxo.js","./authStore-D2cL6XhN.js","./types-t0xJOOCt.js","./cloudWebSessionStore-DQXLFlJm.js","./refreshRemoteConfig-CEuxp20e.js","./tierPricing-Dm5JzLf8.js","./creditsUtil-DxLnYjvD.js","./useAuthActions-CFn_-tF2.js","./workspaceStore-B8_lz1QF.js","./markdownRendererUtil-BJj2U6Nd.js","./extensionStore-CYnV6tYr.js","./useCurrentUser-DjJaVYwd.js","./useBillingCapabilities-x1h7nBmq.js","./Badge-BUm0jxSy.js","./types-Co7511Rq.js","./useBillingDialogs-Bc5B2YTn.js","./billingActionNames-DwcV6mOp.js","./billingDialogsAccess-BbNj81q5.js","./Card-lRVBegiG.js","./AppDialogPanel-BklaJBTn.js","./usePaymentRecoveryDialog-DeFBWQ7b.js","./FormNumberField-BP7-goH4.js","./NumberFieldInput-CUxTsNZT.js","./useExternalLink-Cd0Jpjd8.js","./envUtil-Cq1k2k7n.js","./useSubscriptionDialog-C4Ac2Pav.js","./subscriptionDialogAccess-Igw8sX_b.js","./useWorkspaceUI-CALMkHxF.js","./billingPlanTelemetry-CgeXQYDa.js","./pendingSubscriptionCheckout-CwZ4vFuG.js","./checkoutJourneyTelemetry-CznsrcWK.js","./getExecutionContext-aSfqv9_8.js","./categoryUtil-DZVfz29_.js","./usePartnerNodesRunGate-CDN3pb24.js","./useAuthDialogs-AEcL-pGe.js","./keybindingService-CtLOmFQk.js","./useChainCallback-Bm3zfHjO.js","./resolveWidgetValueAsset-lF2h5jqq.js","./usePopoverSizing-ux16dO36.js","./select.variants-BBeExFA3.js","./missingModelScan-R_tynz92.js","./imageUtil-D14xOjDk.js","./mathUtil-BWeg2vFD.js","./Load3DAdvanced-q6EyCc4w.js","./CameraInfo-CCEAiKWG.js","./orbitDragMath-COuSsRvb.js","./cameraTransform-CzWnbV_-.js","./createViewport3d-LhTmoqJk.js","./TargetHandle-DsnsHetN.js","./CameraAngle-s9nvoAN6.js","./widgetBridge-CtPPORkY.js","./useLoad3d-btsY_FBU.js","./load3d-Bztforeb.js","./Load3DConfiguration-uEhzcQMA.js","./load3dSerialize-BUUpUnmC.js","./model3dOutput-Ci0Q44my.js","./load3dAdvanced-ChN-U8po.js","./load3dPreviewExtensions-BTywk1br.js","./saveMesh-G-hOAdLc.js","./cameraInfo-T4fIPsW0.js","./cameraAngle-q-D9oiPv.js","./lightInfo-Dzw5_wU6.js","./nodeTemplates-gKVQFylq.js","./ui-B5l6_yfh.js","./agentPanel-_EpIazfo.js","./onboardingTourStore-CEYmTJQo.js","./workflowTabActivityStore-HmsDc5E8.js","./firstRunEntry-Bol-W3Im.js","./nodeFilterUtil-CDjk3WM3.js","./useTransformState-D8y5m-4I.js","./agentComposerStore-SD86Kbe6.js","./skillReferenceText-Dr3UZVuB.js","./types-CnYEnJ8O.js"])))=>i.map(i=>d[i]);
import "./rolldown-runtime-xtsTai4I.js";
import { t as __vitePreload } from "./preload-helper-sJeoGctA.js";
import { i as SUPPORTED_EXTENSIONS_ACCEPT, n as LOAD3D_NONE_MODEL } from "./constants-CcZ5JemZ.js";
import { E as intersection, S as isNil, f as toolkit, v as keys } from "./appModeStore-D8l_HeOH.js";
import { Ct as useLinkStore, Dn as widgetId, J as LGraphGroup, Nt as graphScopeOf, Pn as once, Ut as require_loglevel, X as createWidgetRestorationState, Y as LGraphNode, Yt as isComboWidget, _t as outputHasLinks, at as NodeSlot, en as BaseWidget, in as slotTypeKey, ln as useWidgetValueStore, n as LGraphCanvas, q as selectedCanvasNodes, t as LiteGraph, xn as createBounds, yt as outputLinks } from "./litegraph-CgrqhFEE.js";
import { l as isImageNode } from "./litegraphUtil-B_WxWXjg.js";
import { n as useSettingStore } from "./settingStore-DRRi2kOn.js";
import { t as clamp } from "./clamp-C6J77Y5a.js";
import "./dialogService-CqZr0BhP.js";
import { t as useNodeOutputStore } from "./nodeOutputStore-DmbNgTmp.js";
import { i as api } from "./api-BdJmXw98.js";
import { It as shallowReactive, P as computed, W as defineAsyncComponent } from "./vendor-vue-core-CuN1excl.js";
import { E as union } from "./workflowStore-DP6mciq-.js";
import { t as useToast } from "./toastStore-Dg65fRgL.js";
import { d as t } from "./i18n-BRluoVl-.js";
import { O as processDynamicPrompt } from "./formatUtil-DsZFGVbT.js";
import { r as reportError } from "./reportError-BHgDVvfb.js";
import { t as getErrorMessage } from "./errorUtil-DoQyAUQC.js";
import { a as GET_CONFIG, i as CONFIG } from "./rerouteId-1TDIYZkX.js";
import { Z as parseNodeId, _ as getNodeByLocatorId } from "./graphTraversalUtil-BUK1cr2m.js";
import { i as LGraphEventMode } from "./globalEnums-BPoISudO.js";
import { c as resolveNodeRootGraphId } from "./widget-TCRFSGUe.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
import { _ as isMediaUploadComboInput, a as ownSlotTypes, d as getInputSpecType, f as isComboInputSpec, g as isIntInputSpec, h as isFloatInputSpec, l as transformNodeDefV1ToV2, r as inputSpecTree, u as getComboSpecComboOptions } from "./inputSpecTree-B0INjagH.js";
import { _ as collectSearchableOutputTypes, i as useNodeDefStore } from "./nodeDefStore-CF96GLZA.js";
import { l as applyTextReplacements, o as $el } from "./utils-DPLBHlcF.js";
import { t as useExtensionStore } from "./extensionStore-CYnV6tYr.js";
import { $ as useNodePaste, Ct as addValueControlWidgets, E as markCoreMediaMenuCallback, It as ComponentWidgetImpl, J as useExtensionService, Rt as addWidget, X as ComfyWidgets, Y as useWidgetStore, Z as isValidWidgetType, et as useNodeFileInput, l as deserialiseAndCreate, n as app, t as ComfyApp, tt as useNodeDragAndDrop, vt as createAssetWidget } from "./app-CSsV1u1T.js";
import { T as assetService } from "./assetsStore-CNmOJwRQ.js";
import { t as useChainCallback } from "./useChainCallback-Bm3zfHjO.js";
import "./envUtil-Cq1k2k7n.js";
import "./useExternalLink-Cd0Jpjd8.js";
import { a as lcm } from "./mathUtil-BWeg2vFD.js";
import { n as uploadTempFile, t as Load3dUtils } from "./Load3dUtils-CF3OvEZx.js";
import { t as ComfyDialog } from "./ui-B5l6_yfh.js";
import { f as resetCompositorStateWidgets, l as setCompositorLayers, n as clearCompositorPreviewOverride, t as clearCompositorLayers } from "./useCompositorLayers-Ce0qtW6-.js";
import { r as isThreeJsNode, t as reportLoadModelOutcome } from "./reportLoadModelOutcome-DAkHX512.js";
import { S as CAMERA_ANGLE_VIEW_WIDGET_NAME, t as isViewMode } from "./widgetBridge-CtPPORkY.js";
import { t as useMaskEditorStore } from "./maskEditorStore-7e3TTopr.js";
import { i as useMaskEditor, n as touchGesture, r as canvasOrReport } from "./touchPointerGuards-DnmFWWyc.js";
import { t as useCanvasTransform } from "./useCanvasTransform-CeVr70gB.js";
import { t as WidgetTextPreview_default } from "./WidgetTextPreview-CGUnZGup.js";
import { n as mediaRecorderConstructor, t as useAudioService } from "./audioService-Bv1MuuHG.js";
//#region src/extensions/core/clipspace.ts
var ClipspaceDialog = class ClipspaceDialog extends ComfyDialog {
	static items = [];
	static instance = null;
	static registerButton(name, contextPredicate, callback) {
		const item = $el("button", {
			type: "button",
			textContent: name,
			contextPredicate,
			onclick: callback
		});
		ClipspaceDialog.items.push(item);
	}
	static invalidatePreview() {
		if (ComfyApp.clipspace && ComfyApp.clipspace.imgs && ComfyApp.clipspace.imgs.length > 0) {
			const img_preview = document.getElementById("clipspace_preview");
			if (img_preview instanceof HTMLImageElement) {
				img_preview.src = ComfyApp.clipspace.imgs[ComfyApp.clipspace["selectedIndex"]].src;
				img_preview.style.maxHeight = "100%";
				img_preview.style.maxWidth = "100%";
			}
		}
	}
	static invalidate() {
		if (ClipspaceDialog.instance) {
			const self = ClipspaceDialog.instance;
			const imgSettings = self.createImgSettings();
			const children = $el("div.comfy-modal-content", [...imgSettings ? [imgSettings] : [], ...self.createButtons()]);
			self.element.replaceChildren(children);
			if (self.element.children[0].children.length <= 1) self.element.children[0].appendChild($el("p", {}, ["Unable to find the features to edit content of a format stored in the current Clipspace."]));
			ClipspaceDialog.invalidatePreview();
		}
	}
	constructor() {
		super();
	}
	createButtons() {
		const buttons = [];
		for (const item of ClipspaceDialog.items) if (!item.contextPredicate || item.contextPredicate()) buttons.push(item);
		buttons.push($el("button", {
			type: "button",
			textContent: "Close",
			onclick: () => {
				this.close();
			}
		}));
		return buttons;
	}
	createImgSettings() {
		if (ComfyApp.clipspace?.imgs) {
			const combo_items = [];
			const imgs = ComfyApp.clipspace.imgs;
			for (let i = 0; i < imgs.length; i++) combo_items.push($el("option", { value: i }, [`${i}`]));
			const combo1 = $el("select", {
				id: "clipspace_img_selector",
				onchange: (event) => {
					if (event.target && ComfyApp.clipspace) {
						ComfyApp.clipspace["selectedIndex"] = event.target.selectedIndex;
						ClipspaceDialog.invalidatePreview();
					}
				}
			}, combo_items);
			const row1 = $el("tr", {}, [$el("td", {}, [$el("font", { color: "white" }, ["Select Image"])]), $el("td", {}, [combo1])]);
			const combo2 = $el("select", {
				id: "clipspace_img_paste_mode",
				onchange: (event) => {
					if (event.target && ComfyApp.clipspace) ComfyApp.clipspace["img_paste_mode"] = event.target.value;
				}
			}, [$el("option", { value: "selected" }, "selected"), $el("option", { value: "all" }, "all")]);
			combo2.value = ComfyApp.clipspace["img_paste_mode"];
			const row2 = $el("tr", {}, [$el("td", {}, [$el("font", { color: "white" }, ["Paste Mode"])]), $el("td", {}, [combo2])]);
			const td = $el("td", {
				align: "center",
				width: "100px",
				height: "100px",
				colSpan: "2"
			}, [$el("img", {
				id: "clipspace_preview",
				ondragstart: () => false
			}, [])]);
			const row3 = $el("tr", {}, [td]);
			return $el("table", {}, [
				row1,
				row2,
				row3
			]);
		} else return null;
	}
	createImgPreview() {
		if (ComfyApp.clipspace?.imgs) return $el("img", {
			id: "clipspace_preview",
			ondragstart: () => false
		});
		else return null;
	}
	show() {
		ClipspaceDialog.invalidate();
		this.element.style.display = "block";
	}
};
var clipspaceExtension = {
	name: "Comfy.Clipspace",
	init() {
		app.openClipspace = function() {
			if (!ClipspaceDialog.instance) {
				ClipspaceDialog.instance = new ClipspaceDialog();
				ComfyApp.clipspace_invalidate_handler = ClipspaceDialog.invalidate;
			}
			if (ComfyApp.clipspace) ClipspaceDialog.instance.show();
			else app.ui.dialog.show("Clipspace is Empty!");
		};
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.clipspace = window.comfyAPI.clipspace || {};
window.comfyAPI.clipspace.clipspaceExtension = clipspaceExtension;
//#endregion
//#region src/extensions/core/contextMenuFilter.ts
function addFilter(ctx, values, options = {}) {
	if (options.className === "dark" && values.length > 4) {
		const filter = document.createElement("input");
		filter.classList.add("comfy-context-menu-filter");
		filter.placeholder = "Filter list";
		ctx.root.prepend(filter);
		const items = Array.from(ctx.root.querySelectorAll(".litemenu-entry"));
		let displayedItems = [...items];
		let itemCount = displayedItems.length;
		requestAnimationFrame(() => {
			const clickedComboValue = LGraphCanvas.active_canvas.current_node?.widgets?.filter(isComboWidget).find(({ options: { values: widgetValues } }) => Array.isArray(widgetValues) && widgetValues.length === values.length && widgetValues.every((v, i) => v === values[i]))?.value;
			let selectedIndex = clickedComboValue ? values.findIndex((v) => typeof v === "string" && v === clickedComboValue) : 0;
			if (selectedIndex < 0) selectedIndex = 0;
			let selectedItem = displayedItems.at(selectedIndex);
			updateSelected();
			function updateSelected() {
				selectedItem?.style.setProperty("background-color", "");
				selectedItem?.style.setProperty("color", "");
				selectedItem = displayedItems.at(selectedIndex);
				selectedItem?.style.setProperty("background-color", "#ccc", "important");
				selectedItem?.style.setProperty("color", "#000", "important");
			}
			const positionList = () => {
				if (ctx.root.getBoundingClientRect().top < 0) {
					const scale = 1 - ctx.root.getBoundingClientRect().height / ctx.root.clientHeight;
					const shift = ctx.root.clientHeight * scale / 2;
					ctx.root.style.top = -shift + "px";
				}
			};
			filter.addEventListener("keydown", (event) => {
				switch (event.key) {
					case "ArrowUp":
						event.preventDefault();
						if (selectedIndex === 0) selectedIndex = itemCount - 1;
						else selectedIndex--;
						updateSelected();
						break;
					case "ArrowRight":
						event.preventDefault();
						selectedIndex = itemCount - 1;
						updateSelected();
						break;
					case "ArrowDown":
						event.preventDefault();
						if (selectedIndex === itemCount - 1) selectedIndex = 0;
						else selectedIndex++;
						updateSelected();
						break;
					case "ArrowLeft":
						event.preventDefault();
						selectedIndex = 0;
						updateSelected();
						break;
					case "Enter":
						selectedItem?.click();
						break;
					case "Escape": ctx.close();
				}
			});
			filter.addEventListener("input", () => {
				const term = filter.value.toLocaleLowerCase();
				displayedItems = items.filter((item) => {
					const isVisible = !term || item.textContent.toLocaleLowerCase().includes(term);
					item.style.display = isVisible ? "block" : "none";
					return isVisible;
				});
				selectedIndex = Math.max(0, displayedItems.findIndex((d) => d === selectedItem));
				itemCount = displayedItems.length;
				updateSelected();
				if (options.event) {
					let top = options.event.clientY - 10;
					const bodyRect = document.body.getBoundingClientRect();
					const rootRect = ctx.root.getBoundingClientRect();
					if (bodyRect.height && top > bodyRect.height - rootRect.height - 10) top = Math.max(0, bodyRect.height - rootRect.height - 10);
					ctx.root.style.top = top + "px";
					positionList();
				}
			});
			requestAnimationFrame(() => {
				filter.focus();
				positionList();
			});
		});
	}
	return ctx;
}
var contextMenuFilterExtension = {
	name: "Comfy.ContextMenuFilter",
	init() {
		LiteGraph.ContextMenu = new Proxy(LiteGraph.ContextMenu, {
			construct: (target, args) => addFilter(new target(...args), ...args),
			apply: (target, _thisArg, args) => addFilter(new target(...args), ...args)
		});
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.contextMenuFilter = window.comfyAPI.contextMenuFilter || {};
window.comfyAPI.contextMenuFilter.contextMenuFilterExtension = contextMenuFilterExtension;
//#endregion
//#region src/extensions/core/createBoundingBoxes.ts
var INTERNAL_WIDGETS = /* @__PURE__ */ new Set(["last_incoming"]);
var createBoundingBoxesExtension = {
	name: "Comfy.CreateBoundingBoxes",
	nodeCreated(node) {
		if (node.constructor.comfyClass !== "CreateBoundingBoxes") return;
		const [oldWidth, oldHeight] = node.size;
		node.setSize([Math.max(oldWidth, 420), Math.max(oldHeight, 560)]);
		for (const widget of node.widgets ?? []) if (INTERNAL_WIDGETS.has(widget.name)) widget.hidden = true;
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.createBoundingBoxes = window.comfyAPI.createBoundingBoxes || {};
window.comfyAPI.createBoundingBoxes.createBoundingBoxesExtension = createBoundingBoxesExtension;
//#endregion
//#region src/extensions/core/widgetValuePropagation.ts
function applyFirstWidgetValueToGraph(node, extraLinks = [], transformValue) {
	const { graph } = node;
	if (!graph) return;
	const linked = [...useLinkStore().getOutputSlotLinks(graphScopeOf(graph), node.id, 0)];
	if (!linked.length) return;
	const sourceWidget = node.widgets?.[0];
	if (!sourceWidget) return;
	let value = sourceWidget.value;
	if (transformValue) value = transformValue(value);
	const graphMouse = app.canvas.graph_mouse;
	const endpoints = [...linked.map(({ targetNodeId, targetSlot }) => ({
		targetNodeId,
		targetSlot
	})), ...extraLinks.map((link) => ({
		targetNodeId: link.target_id,
		targetSlot: link.target_slot
	}))];
	for (const endpoint of endpoints) {
		const targetNode = graph.getNodeById(endpoint.targetNodeId);
		const input = targetNode?.inputs[endpoint.targetSlot];
		if (!targetNode || !input) {
			console.warn("Unable to resolve node or input for link", endpoint);
			continue;
		}
		const widgetName = input.widget?.name;
		if (!widgetName) {
			console.warn("Invalid widget or widget name", input.widget);
			continue;
		}
		const targetWidget = targetNode.widgets?.find((widget) => widget.name === widgetName);
		if (!targetWidget) {
			console.warn(`Unable to find widget "${widgetName}" on node [${targetNode.id}]`);
			continue;
		}
		targetWidget.value = value;
		targetWidget.callback?.(targetWidget.value, app.canvas, targetNode, graphMouse, {});
	}
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.widgetValuePropagation = window.comfyAPI.widgetValuePropagation || {};
window.comfyAPI.widgetValuePropagation.applyFirstWidgetValueToGraph = applyFirstWidgetValueToGraph;
//#endregion
//#region src/extensions/core/customWidgets.ts
function applyToGraph(extraLinks = []) {
	applyFirstWidgetValueToGraph(this, extraLinks);
}
function resolveChoiceValue(interiorNode, comboWidget, resolverNode = interiorNode) {
	const choiceInputIndex = interiorNode.inputs.findIndex((input) => input.widget?.name === comboWidget.name);
	if (choiceInputIndex < 0 || !("resolveInput" in resolverNode)) return comboWidget.value;
	const resolved = resolverNode.resolveInput(choiceInputIndex);
	return resolved?.widgetInfo ? resolved.widgetInfo.value : comboWidget.value;
}
function onCustomComboCreated() {
	this.applyToGraph = applyToGraph;
	const comboWidget = this.widgets[0];
	const values = shallowReactive([]);
	comboWidget.options.values = values;
	const updateCombo = () => {
		values.splice(0, values.length, ...this.widgets.filter((w) => w.name.startsWith("option") && w.value).map((w) => `${w.value}`));
		if (app.configuringGraph || !this.graph) return;
		if (values.includes(`${comboWidget.value}`)) return;
		comboWidget.value = values.at(0) ?? "";
		comboWidget.callback?.(comboWidget.value);
	};
	comboWidget.callback = useChainCallback(comboWidget.callback, () => this.applyToGraph());
	this.onAdded = useChainCallback(this.onAdded, function() {
		updateCombo();
	});
	function addOption(node) {
		if (!node.widgets) return;
		const widgetName = `option${node.widgets.length - 1}`;
		const widget = node.addWidget("string", widgetName, "", () => {});
		let localValue = `${widget.value ?? ""}`;
		Object.defineProperty(widget, "value", {
			get() {
				return useWidgetValueStore().getWidget(widgetId(app.rootGraph.id, node.id, widgetName))?.value ?? localValue;
			},
			set(v) {
				localValue = v;
				const state = useWidgetValueStore().getWidget(widgetId(app.rootGraph.id, node.id, widgetName));
				if (state) state.value = v;
				updateCombo();
				if (!node.widgets) return;
				const lastWidget = node.widgets.at(-1);
				if (lastWidget === this) {
					if (v) addOption(node);
					return;
				}
				if (v || node.widgets.at(-2) !== this || lastWidget?.value) return;
				node.widgets.pop();
				node.computeSize(node.size);
				this.callback(v);
			}
		});
	}
	const widgets = this.widgets;
	widgets.push({
		name: "index",
		type: "hidden",
		get value() {
			return widgets.slice(2).findIndex((w) => w.value === comboWidget.value);
		},
		set value(_) {},
		draw: () => void 0,
		hidden: true,
		options: {},
		y: 0,
		serializeValue: (resolverNode) => widgets.slice(2).findIndex((w) => w.value === resolveChoiceValue(this, comboWidget, resolverNode))
	});
	addOption(this);
}
var StubWidget = class extends BaseWidget {
	valueGetter;
	serialize = true;
	constructor(node, name, valueGetter) {
		super({
			name,
			node,
			options: { socketless: true },
			type: "hidden",
			y: 0
		});
		this.valueGetter = valueGetter;
	}
	drawWidget() {}
	onClick() {}
	get value() {
		return this.valueGetter();
	}
	set value(_) {}
};
function connectedInputsFor(node, prefix = "autogrow.") {
	return computed(() => node.inputs.filter((input) => input.name.startsWith(prefix) && input.link).map((input) => input.label ?? input.localized_name ?? input.name));
}
function onCustomIntCreated() {
	const valueWidget = this.widgets?.[0];
	if (!valueWidget) return;
	Object.defineProperty(valueWidget.options, "min", {
		get: () => this.properties.min ?? -(2 ** 63),
		set: (v) => {
			this.properties.min = v;
			valueWidget.callback?.(valueWidget.value);
		}
	});
	Object.defineProperty(valueWidget.options, "max", {
		get: () => this.properties.max ?? 2 ** 63,
		set: (v) => {
			this.properties.max = v;
			valueWidget.callback?.(valueWidget.value);
		}
	});
	Object.defineProperty(valueWidget.options, "step2", {
		get: () => this.properties.step ?? 1,
		set: (v) => {
			this.properties.step = v;
			valueWidget.callback?.(valueWidget.value);
		}
	});
}
var DISPLAY_WIDGET_TYPES = /* @__PURE__ */ new Set([
	"gradientslider",
	"slider",
	"knob"
]);
var finiteNumber = (value) => typeof value === "number" && Number.isFinite(value) ? value : void 0;
var positiveNumber = (value) => {
	const n = finiteNumber(value);
	return n !== void 0 && n > 0 ? n : void 0;
};
var fractionDigits = (value) => {
	const n = finiteNumber(value);
	return n === void 0 ? void 0 : clamp(Math.trunc(n), 0, 100);
};
var lastDecimalPlace = (places) => Number((10 ** -places).toFixed(places));
function onCustomFloatCreated() {
	const valueWidget = this.widgets?.[0];
	if (!valueWidget) return;
	const declaredPrecision = fractionDigits(valueWidget.options.precision) ?? 1;
	const declaredStep = positiveNumber(valueWidget.options.step2) ?? lastDecimalPlace(declaredPrecision);
	const declaredRound = valueWidget.options.round;
	const declaresRounding = positiveNumber(declaredRound) !== void 0;
	const nodePrecision = () => fractionDigits(this.properties.precision);
	let baseType = valueWidget.type;
	Object.defineProperty(valueWidget, "type", {
		get: () => {
			const display = this.properties.display;
			if (display && DISPLAY_WIDGET_TYPES.has(display)) return display;
			return baseType;
		},
		set: (v) => {
			baseType = v;
		}
	});
	Object.defineProperty(valueWidget.options, "gradient_stops", {
		enumerable: true,
		get: () => this.properties.gradient_stops,
		set: (v) => {
			this.properties.gradient_stops = v;
		}
	});
	Object.defineProperty(valueWidget.options, "min", {
		get: () => this.properties.min ?? -Infinity,
		set: (v) => {
			this.properties.min = v;
			valueWidget.callback?.(valueWidget.value);
		}
	});
	Object.defineProperty(valueWidget.options, "max", {
		get: () => this.properties.max ?? Infinity,
		set: (v) => {
			this.properties.max = v;
			valueWidget.callback?.(valueWidget.value);
		}
	});
	Object.defineProperty(valueWidget.options, "precision", {
		get: () => nodePrecision() ?? declaredPrecision,
		set: (v) => {
			this.properties.precision = v;
			valueWidget.callback?.(valueWidget.value);
		}
	});
	Object.defineProperty(valueWidget.options, "step2", {
		get: () => {
			const configured = positiveNumber(this.properties.step);
			if (configured !== void 0) return configured;
			const places = nodePrecision();
			return places === void 0 ? declaredStep : lastDecimalPlace(places);
		},
		set: (v) => this.properties.step = v
	});
	Object.defineProperty(valueWidget.options, "round", {
		get: () => {
			const configured = positiveNumber(this.properties.round);
			if (configured !== void 0) return configured;
			const places = nodePrecision();
			return places !== void 0 && declaresRounding ? lastDecimalPlace(places) : declaredRound;
		},
		set: (v) => {
			this.properties.round = v;
			valueWidget.callback?.(valueWidget.value);
		}
	});
}
var customWidgetsExtension = {
	name: "Comfy.CustomWidgets",
	beforeRegisterNodeDef(nodeType, nodeData) {
		if (nodeData.name === "CustomCombo") nodeType.prototype.onNodeCreated = useChainCallback(nodeType.prototype.onNodeCreated, onCustomComboCreated);
		else if (nodeData.name === "PrimitiveInt") nodeType.prototype.onNodeCreated = useChainCallback(nodeType.prototype.onNodeCreated, onCustomIntCreated);
		else if (nodeData.name === "PrimitiveFloat") nodeType.prototype.onNodeCreated = useChainCallback(nodeType.prototype.onNodeCreated, onCustomFloatCreated);
	},
	getCustomWidgets() {
		return {
			COMFY_BRANCH_INPUT_NAMES: function(node, inputName) {
				const connectedInputs = connectedInputsFor(node);
				const values = () => connectedInputs.value;
				node.addCustomWidget(new StubWidget(node, inputName, values));
			},
			COMFY_BRANCH_SELECTOR: function(node, inputName) {
				const connectedInputs = connectedInputsFor(node);
				const values = () => connectedInputs.value;
				const startValue = connectedInputs.value[0] ?? "";
				node.addWidget("combo", inputName, startValue, () => {}, { values });
				node.onInputAdded = useChainCallback(node.onInputAdded, (input) => {
					if (input.widget?.name !== inputName) return;
					input.widget[GET_CONFIG] = () => ["COMBO", { options: values }];
				});
			}
		};
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.customWidgets = window.comfyAPI.customWidgets || {};
window.comfyAPI.customWidgets.customWidgetsExtension = customWidgetsExtension;
//#endregion
//#region src/extensions/core/dynamicPrompts.ts
var dynamicPromptsExtension = {
	name: "Comfy.DynamicPrompts",
	nodeCreated(node) {
		if (node.widgets) {
			const widgets = node.widgets.filter((w) => w.dynamicPrompts);
			for (const widget of widgets) widget.serializeValue = () => {
				if (typeof widget.value !== "string") return widget.value;
				return processDynamicPrompt(widget.value);
			};
		}
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.dynamicPrompts = window.comfyAPI.dynamicPrompts || {};
window.comfyAPI.dynamicPrompts.dynamicPromptsExtension = dynamicPromptsExtension;
//#endregion
//#region src/extensions/core/editAttention.ts
function incrementWeight(weight, delta) {
	const floatWeight = parseFloat(weight);
	if (isNaN(floatWeight)) return weight;
	const newWeight = floatWeight + delta;
	return String(Number(newWeight.toFixed(10)));
}
function findNearestEnclosure(text, cursorPos) {
	let start = cursorPos;
	let end = cursorPos;
	let openCount = 0;
	let closeCount = 0;
	if (text[cursorPos] === "(") end = cursorPos + 1;
	else {
		while (start >= 0) {
			start--;
			if (text[start] === "(" && openCount === closeCount) break;
			if (text[start] === "(") openCount++;
			if (text[start] === ")") closeCount++;
		}
		if (start < 0) return null;
		openCount = 0;
		closeCount = 0;
	}
	while (end < text.length) {
		if (text[end] === ")" && openCount === closeCount) break;
		if (text[end] === "(") openCount++;
		if (text[end] === ")") closeCount++;
		end++;
	}
	if (end === text.length) return null;
	return {
		start: start + 1,
		end
	};
}
function addWeightToParentheses(text) {
	const parenMatch = text.match(/^\((.*)\)$/);
	if (!parenMatch) return text;
	const innerText = parenMatch[1];
	return !/(?:^|\s)\d{1,2}:\d{2}$/.test(innerText) && /:[+-]?(?:\d*\.)?\d+(?:[eE][+-]?\d+)?$/.test(innerText) ? text : `(${innerText}:1.0)`;
}
var editAttentionExtension = {
	name: "Comfy.EditAttention",
	init() {
		const editAttentionDelta = app.ui.settings.addSetting({
			id: "Comfy.EditAttention.Delta",
			category: [
				"Comfy",
				"EditTokenWeight",
				"Delta"
			],
			name: "Ctrl+up/down precision",
			type: "slider",
			attrs: {
				min: .01,
				max: .5,
				step: .01
			},
			defaultValue: .05
		});
		function editAttention(event) {
			const inputField = event.composedPath()[0];
			const delta = parseFloat(String(editAttentionDelta.value));
			if (!(inputField instanceof HTMLTextAreaElement)) return;
			if (!(event.key === "ArrowUp" || event.key === "ArrowDown")) return;
			if (!event.ctrlKey && !event.metaKey) return;
			event.preventDefault();
			let start = inputField.selectionStart;
			let end = inputField.selectionEnd;
			let selectedText = inputField.value.substring(start, end);
			if (!selectedText) {
				const nearestEnclosure = findNearestEnclosure(inputField.value, start);
				if (nearestEnclosure) {
					start = nearestEnclosure.start;
					end = nearestEnclosure.end;
					selectedText = inputField.value.substring(start, end);
				} else {
					const delimiters = " .,\\/!?%^*;:{}=-_`~()\r\n	";
					while (!delimiters.includes(inputField.value[start - 1]) && start > 0) start--;
					while (!delimiters.includes(inputField.value[end]) && end < inputField.value.length) end++;
					selectedText = inputField.value.substring(start, end);
					if (!selectedText) return;
				}
			}
			if (selectedText[selectedText.length - 1] === " ") {
				selectedText = selectedText.substring(0, selectedText.length - 1);
				end -= 1;
			}
			if (inputField.value[start - 1] === "(" && inputField.value[end] === ")") {
				start -= 1;
				end += 1;
				selectedText = inputField.value.substring(start, end);
			}
			if (selectedText[0] !== "(" || selectedText[selectedText.length - 1] !== ")") selectedText = `(${selectedText})`;
			selectedText = addWeightToParentheses(selectedText);
			const weightDelta = event.key === "ArrowUp" ? delta : -delta;
			const updatedText = selectedText.replace(/\((.*):([+-]?(?:\d*\.)?\d+(?:[eE][+-]?\d+)?)\)/, (_, text, weight) => {
				weight = incrementWeight(weight, weightDelta);
				if (weight == 1) return text;
				else return `(${text}:${weight})`;
			});
			inputField.setSelectionRange(start, end);
			document.execCommand("insertText", false, updatedText);
			inputField.setSelectionRange(start, start + updatedText.length);
		}
		window.addEventListener("keydown", editAttention);
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.editAttention = window.comfyAPI.editAttention || {};
window.comfyAPI.editAttention.incrementWeight = incrementWeight;
window.comfyAPI.editAttention.findNearestEnclosure = findNearestEnclosure;
window.comfyAPI.editAttention.addWeightToParentheses = addWeightToParentheses;
window.comfyAPI.editAttention.editAttentionExtension = editAttentionExtension;
require_loglevel();
//#endregion
//#region src/extensions/core/electronAdapter.ts
async function registerElectronAdapterExtension() {
	return false;
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.electronAdapter = window.comfyAPI.electronAdapter || {};
window.comfyAPI.electronAdapter.registerElectronAdapterExtension = registerElectronAdapterExtension;
//#endregion
//#region src/constants/groupNodeConstants.ts
/**
* Constants for group node type prefixes and separators
*
* v1 Prefix + Separator: workflow/
* v2 Prefix + Separator: workflow> (ComfyUI_frontend v1.2.63)
*/
var PREFIX = "workflow";
//#endregion
//#region src/utils/nodeDefUtil.ts
var IGNORE_KEYS = /* @__PURE__ */ new Set([
	"default",
	"forceInput",
	"defaultInput",
	"control_after_generate",
	"multiline",
	"tooltip",
	"dynamicPrompts"
]);
var getRange = (options) => {
	return {
		min: options.min ?? -Infinity,
		max: options.max ?? Infinity
	};
};
var mergeNumericInputSpec = (spec1, spec2) => {
	const type = spec1[0];
	const options1 = spec1[1] ?? {};
	const options2 = spec2[1] ?? {};
	const range1 = getRange(options1);
	const range2 = getRange(options2);
	if (range1.min > range2.max || range1.max < range2.min) return null;
	const step1 = options1.step ?? 1;
	const step2 = options2.step ?? 1;
	const mergedOptions = {
		min: Math.max(range1.min, range2.min),
		max: Math.min(range1.max, range2.max),
		step: lcm(step1, step2)
	};
	return mergeCommonInputSpec([type, {
		...options1,
		...mergedOptions
	}], [type, {
		...options2,
		...mergedOptions
	}]);
};
var mergeComboInputSpec = (spec1, spec2) => {
	const options1 = spec1[1] ?? {};
	const options2 = spec2[1] ?? {};
	const comboOptions1 = getComboSpecComboOptions(spec1);
	const comboOptions2 = getComboSpecComboOptions(spec2);
	const commonOptions = intersection(comboOptions1, comboOptions2);
	if (commonOptions.length === 0) return null;
	return mergeCommonInputSpec(["COMBO", {
		...options1,
		options: commonOptions
	}], ["COMBO", {
		...options2,
		options: commonOptions
	}]);
};
var mergeCommonInputSpec = (spec1, spec2) => {
	const type = getInputSpecType(spec1);
	const options1 = spec1[1] ?? {};
	const options2 = spec2[1] ?? {};
	return union(keys(options1), keys(options2)).filter((key) => !IGNORE_KEYS.has(key)).every((key) => {
		const value1 = options1[key];
		const value2 = options2[key];
		return value1 === value2 || isNil(value1) && isNil(value2);
	}) ? [type, {
		...options1,
		...options2
	}] : null;
};
/**
* Merges two input specs.
*
* @param spec1 - The first input spec.
* @param spec2 - The second input spec.
* @returns The merged input spec, or null if the specs are not mergeable.
*/
var mergeInputSpec = (spec1, spec2) => {
	if (getInputSpecType(spec1) !== getInputSpecType(spec2)) return null;
	if (isIntInputSpec(spec1) || isFloatInputSpec(spec1)) return mergeNumericInputSpec(spec1, spec2);
	if (isComboInputSpec(spec1)) return mergeComboInputSpec(spec1, spec2);
	return mergeCommonInputSpec(spec1, spec2);
};
//#endregion
//#region src/extensions/core/widgetInputs.ts
var replacePropertyName = "Run widget replace on values";
var isPrimitiveNode = (node) => node.type === "PrimitiveNode";
var PrimitiveNode = class extends LGraphNode {
	controlValues;
	lastType;
	static category;
	constructor(title) {
		super(title);
		this.addOutput("connect to widget input", "*");
		this.serialize_widgets = true;
		this.isVirtualNode = true;
		if (!(replacePropertyName in this.properties)) this.addProperty(replacePropertyName, false, "boolean");
	}
	applyToGraph(extraLinks = []) {
		const sourceWidget = this.widgets?.[0];
		const graph = this.graph;
		if (!sourceWidget || !graph) return;
		let v = sourceWidget.value;
		if (v && this.properties[replacePropertyName]) v = applyTextReplacements(graph, v);
		applyFirstWidgetValueToGraph(this, extraLinks, () => v);
	}
	refreshComboInNode(defs) {
		const widget = this.widgets?.[0];
		if (widget?.type !== "combo") return;
		const newValues = this._resolveComboValues(defs);
		if (newValues === void 0) return;
		widget.options.values = newValues;
		const value = widget.value;
		if (typeof value !== "string" && typeof value !== "number" || !newValues.includes(value)) {
			widget.value = newValues[0];
			widget.callback?.(widget.value);
		}
	}
	_resolveComboValues(defs) {
		const fromDefs = defs ? this._comboValuesFromDefs(defs) : void 0;
		if (fromDefs !== void 0) return fromDefs;
		const config = this.outputs[0].widget?.[GET_CONFIG]?.();
		if (!config || !isComboInputSpec(config)) return void 0;
		return getComboSpecComboOptions(config);
	}
	_comboValuesFromDefs(defs) {
		const graph = this.graph;
		const links = graph ? outputLinks(graph, this.id, 0) : [];
		if (!graph || !links.length) return void 0;
		let values;
		for (const link of links) {
			const targetNode = graph.getNodeById(link.target_id);
			const targetType = targetNode?.type;
			const targetInput = targetNode?.inputs.at(link.target_slot);
			const inputName = targetInput?.widget?.name ?? targetInput?.name;
			if (!targetType || !inputName) return void 0;
			const def = defs[targetType];
			const inputSpec = def?.input?.required?.[inputName] ?? def?.input?.optional?.[inputName];
			if (!inputSpec || !isComboInputSpec(inputSpec)) return void 0;
			const options = getComboSpecComboOptions(inputSpec);
			values = values === void 0 ? options : intersection(values, options);
		}
		return values;
	}
	configure(serialisedNode) {
		const type = serialisedNode.outputs?.[0]?.type;
		super.configure(serialisedNode);
		if (!this.graph || this.widgets?.length || typeof type !== "string" || !outputHasLinks(this.graph, this.id, 0)) return;
		useWidgetValueStore().setNodeWidgetRestoration(this.graph.rootGraph.id, this.id, createWidgetRestorationState(serialisedNode));
	}
	onAfterGraphConfigured() {
		if (this.graph && outputHasLinks(this.graph, this.id, 0) && !this.widgets?.length) {
			this._onFirstConnection();
			this._mergeWidgetConfig();
		}
	}
	_clearWidgetRestoration() {
		if (this.graph) useWidgetValueStore().clearNodeWidgetRestoration(this.graph.rootGraph.id, this.id);
	}
	onConnectionsChange(_type, _index, connected) {
		if (app.configuringGraph) return;
		const hasLinks = this.graph ? outputHasLinks(this.graph, this.id, 0) : false;
		if (connected) {
			if (hasLinks && !this.widgets?.length) this._onFirstConnection();
		} else {
			this._mergeWidgetConfig();
			if (!hasLinks) this.onLastDisconnect();
		}
	}
	onConnectOutput(slot, _type, input, target_node, target_slot) {
		if (!input.widget && (typeof input.type !== "string" || !(input.type in ComfyWidgets))) return false;
		if (this.graph && outputHasLinks(this.graph, this.id, slot)) {
			const valid = this._isValidConnection(input);
			if (valid) this.applyToGraph([{
				target_id: target_node.id,
				target_slot
			}]);
			return valid;
		}
		return true;
	}
	_onFirstConnection(recreating = false) {
		if (!this.graph) {
			this.onLastDisconnect();
			return;
		}
		const link = outputLinks(this.graph, this.id, 0).at(0);
		if (!link) {
			if (outputHasLinks(this.graph, this.id, 0)) console.warn(`PrimitiveNode ${this.id}: link store reports output 0 connected but no link resolves in the graph; resetting the widget.`);
			this.onLastDisconnect();
			return;
		}
		const theirNode = this.graph.getNodeById(link.target_id);
		if (!theirNode) return;
		const input = theirNode.inputs.at(link.target_slot);
		if (!input) return;
		let widget;
		if (!input.widget) {
			const inputType = input.type;
			if (typeof inputType !== "string" || !(inputType in ComfyWidgets)) return;
			widget = {
				name: input.name,
				[GET_CONFIG]: () => [inputType, {}]
			};
		} else widget = input.widget;
		const config = widget[GET_CONFIG]?.();
		if (!config) return;
		const { type } = getWidgetType(config);
		if (recreating || this.outputs[0].type !== type) this._clearWidgetRestoration();
		this.outputs[0].type = type;
		this.outputs[0].name = type;
		this.outputs[0].widget = widget;
		this._createWidget(widget[CONFIG] ?? config, theirNode, widget.name, recreating);
	}
	_createWidget(inputData, node, widgetName, recreating) {
		let type = inputData[0];
		if (type instanceof Array) type = "COMBO";
		const [oldWidth, oldHeight] = this.size;
		let widget;
		try {
			if (type === "COMBO" && assetService.shouldUseWidgetAssetPicker(node.comfyClass, widgetName)) {
				widget = this._createAssetWidget(node, widgetName, inputData);
				const theirWidget = node.widgets?.find((w) => w.name === widgetName);
				if (theirWidget) widget.value = theirWidget.value;
				this._restoreSavedValue(widget);
				this._finalizeWidget(widget, oldWidth, oldHeight, recreating);
				return;
			}
			if (isValidWidgetType(type)) widget = ComfyWidgets[type](this, "value", inputData, app).widget;
			else widget = this.addCustomWidget({
				type: type.toLowerCase(),
				name: "value",
				value: null,
				callback: () => {},
				options: {},
				y: 0
			});
			if (node.widgets) {
				const theirWidget = node.widgets.find((w) => w.name === widgetName);
				if (theirWidget) widget.value = theirWidget.value;
			}
			this._restoreSavedValue(widget);
			if (!inputData[1]?.control_after_generate && (widget.type === "number" || widget.type === "combo")) {
				addValueControlWidgets(this, widget, "fixed", void 0, inputData);
				if (this.widgets?.[1]) widget.linkedWidgets = [this.widgets[1]];
			}
			const controlValues = this.controlValues;
			if (this.widgets && this.lastType === this.widgets[0]?.type && controlValues?.length === this.widgets.length - 1) for (let i = 0; i < controlValues.length; i++) this.widgets[i + 1].value = controlValues[i];
			this._finalizeWidget(widget, oldWidth, oldHeight, recreating);
		} finally {
			this._clearWidgetRestoration();
		}
	}
	_restoreSavedValue(widget) {
		if (!this.graph) return;
		const restored = useWidgetValueStore().getRestoredWidgetValue(this.graph.rootGraph.id, this.id, widget, 0);
		if (restored) widget.value = restored.value;
	}
	_createAssetWidget(targetNode, targetInputName, inputData) {
		const defaultValue = inputData[1]?.default;
		return createAssetWidget({
			node: this,
			widgetName: "value",
			nodeTypeForBrowser: targetNode.comfyClass ?? "",
			inputNameForBrowser: targetInputName,
			defaultValue
		});
	}
	_finalizeWidget(widget, oldWidth, oldHeight, recreating) {
		widget.callback = useChainCallback(widget.callback, () => {
			this.applyToGraph();
		});
		this.setSize([Math.max(this.size[0], oldWidth), Math.max(this.size[1], oldHeight)]);
		if (!recreating) {
			const sz = this.computeSize();
			this.size = [Math.max(this.size[0], sz[0]), Math.max(this.size[1], sz[1])];
			requestAnimationFrame(() => {
				this.onResize?.(this.size);
			});
		}
	}
	recreateWidget() {
		const values = this.widgets?.map((w) => w.value);
		this._removeWidgets();
		this._onFirstConnection(!!values?.length);
		if (values?.length && this.widgets) for (let i = 0; i < this.widgets.length; i++) this.widgets[i].value = values[i];
		return this.widgets?.[0];
	}
	_mergeWidgetConfig() {
		const output = this.outputs[0];
		const links = this.graph ? outputLinks(this.graph, this.id, 0) : [];
		const hasConfig = !!output.widget?.[CONFIG];
		if (hasConfig) delete output.widget?.[CONFIG];
		if (links.length < 2 && hasConfig) {
			if (links.length) this.recreateWidget();
			return;
		}
		const config1 = output.widget?.[GET_CONFIG]?.();
		if (!config1) return;
		if (!(config1[0] === "INT" || config1[0] === "FLOAT") || !this.graph) return;
		for (const link of links) {
			const theirNode = this.graph.getNodeById(link.target_id);
			if (!theirNode) continue;
			const theirInput = theirNode.inputs[link.target_slot];
			this._isValidConnection(theirInput, hasConfig);
		}
	}
	_isValidConnection(input, forceUpdate) {
		const output = this.outputs[0];
		const config2 = input.widget?.[GET_CONFIG]?.();
		if (!config2) return false;
		return !!mergeIfValid(output, config2, forceUpdate, () => this.recreateWidget());
	}
	_removeWidgets() {
		if (this.widgets) {
			for (const w of this.widgets) if (w.onRemove) w.onRemove();
			this.controlValues = [];
			this.lastType = this.widgets[0]?.type;
			for (let i = 1; i < this.widgets.length; i++) this.controlValues.push(this.widgets[i].value);
			setTimeout(() => {
				delete this.lastType;
				delete this.controlValues;
			}, 15);
			this.widgets.length = 0;
		}
	}
	onLastDisconnect() {
		this._clearWidgetRestoration();
		this.outputs[0].type = "*";
		this.outputs[0].name = "connect to widget input";
		delete this.outputs[0].widget;
		this._removeWidgets();
	}
};
function getWidgetConfig(slot) {
	return slot.widget?.[CONFIG] ?? slot.widget?.[GET_CONFIG]?.() ?? ["*", {}];
}
function getConfig(widgetName) {
	const { nodeData } = this.constructor;
	return nodeData?.input?.required?.[widgetName] ?? nodeData?.input?.optional?.[widgetName];
}
/**
* Convert a widget to an input slot.
* @deprecated Widget to socket conversion is no longer necessary, as they co-exist now.
* @param node The node to convert the widget to an input slot for.
* @param widget The widget to convert to an input slot.
* @returns The input slot that was converted from the widget or undefined if the widget is not found.
*/
function convertToInput(node, widget) {
	console.warn("Please remove call to convertToInput. Widget to socket conversion is no longer necessary, as they co-exist now.");
	return node.inputs.find((slot) => slot.widget?.name === widget.name);
}
function getWidgetType(config) {
	let type = config[0];
	if (type instanceof Array) type = "COMBO";
	return { type };
}
function setWidgetConfig(slot, config) {
	if (!slot.widget) return;
	if (config) slot.widget[GET_CONFIG] = () => config;
	else delete slot.widget;
	if (!(slot instanceof NodeSlot)) return;
	const { node } = slot;
	if (!node.graph) return;
	const link = node.getInputLink(node.inputs.indexOf(slot));
	if (!link) return;
	const originNode = node.graph.getNodeById(link.origin_id);
	if (!originNode || !isPrimitiveNode(originNode)) return;
	if (config) originNode.recreateWidget();
	else if (!app.configuringGraph) {
		originNode.disconnectOutput(0);
		originNode.onLastDisconnect();
	}
}
function mergeIfValid(output, config2, forceUpdate, recreateWidget, config1) {
	if (!config1) config1 = getWidgetConfig(output);
	const customSpec = mergeInputSpec(config1, config2);
	if (customSpec || forceUpdate) {
		if (customSpec) {
			if (output.widget) output.widget[CONFIG] = customSpec;
		}
		const widget = recreateWidget?.();
		if (widget) {
			const { min, max } = widget.options;
			if (typeof widget.value === "number") {
				if (min != null && widget.value < min) widget.value = min;
				if (max != null && widget.value > max) widget.value = max;
			}
			widget.callback?.(widget.value);
		}
	}
	return { customConfig: customSpec?.[1] ?? {} };
}
var widgetInputsExtension = {
	name: "Comfy.WidgetInputs",
	async beforeRegisterNodeDef(nodeType, _nodeData) {
		nodeType.prototype.convertWidgetToInput = function() {
			console.warn("Please remove call to convertWidgetToInput. Widget to socket conversion is no longer necessary, as they co-exist now.");
			return false;
		};
		nodeType.prototype.onGraphConfigured = useChainCallback(nodeType.prototype.onGraphConfigured, function() {
			this.widgets ??= [];
			for (const input of this.inputs) if (input.widget) {
				const name = input.widget.name;
				if (!input.widget[GET_CONFIG]) input.widget[GET_CONFIG] = () => getConfig.call(this, name);
				if (!this.widgets.find((w) => w.name === name)) this.removeInput(this.inputs.findIndex((i) => i === input));
			}
		});
		nodeType.prototype.onConfigure = useChainCallback(nodeType.prototype.onConfigure, function() {
			if (!app.configuringGraph) {
				for (const input of this.inputs) if (input.widget && !input.widget[GET_CONFIG]) {
					const name = input.widget.name;
					input.widget[GET_CONFIG] = () => getConfig.call(this, name);
				}
			}
		});
		const origOnInputDblClick = nodeType.prototype.onInputDblClick;
		nodeType.prototype.onInputDblClick = function(...[slot, ...args]) {
			const r = origOnInputDblClick?.apply(this, [slot, ...args]);
			const input = this.inputs[slot];
			if (!input.widget) {
				if (typeof input.type !== "string" || !(input.type in ComfyWidgets)) return r;
			}
			const node = LiteGraph.createNode("PrimitiveNode");
			const graph = app.canvas.graph;
			if (!node || !graph) return r;
			graph.add(node);
			const pos = [this.pos[0] - node.size[0] - 30, this.pos[1]];
			while (graph.getNodeOnPos(pos[0], pos[1], graph.nodes)) pos[1] += LiteGraph.NODE_TITLE_HEIGHT;
			node.pos = pos;
			node.connect(0, this, slot);
			node.title = input.name;
			return r;
		};
	},
	registerCustomNodes() {
		LiteGraph.registerNodeType("PrimitiveNode", Object.assign(PrimitiveNode, { title: "Primitive" }));
		PrimitiveNode.category = "utilities/primitive";
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.widgetInputs = window.comfyAPI.widgetInputs || {};
window.comfyAPI.widgetInputs.PrimitiveNode = PrimitiveNode;
window.comfyAPI.widgetInputs.getWidgetConfig = getWidgetConfig;
window.comfyAPI.widgetInputs.convertToInput = convertToInput;
window.comfyAPI.widgetInputs.setWidgetConfig = setWidgetConfig;
window.comfyAPI.widgetInputs.mergeIfValid = mergeIfValid;
window.comfyAPI.widgetInputs.widgetInputsExtension = widgetInputsExtension;
//#endregion
//#region src/extensions/core/groupNode.ts
/**
* Marker symbol stamped on a synthesized group-node type's `nodeData` (via
* {@link markGroupNodeType}) so loaded group-node instances can be detected and
* migrated to subgraphs.
*/
var GROUP = Symbol();
/**
* Stamp the group-node marker onto the registered node type so instances created
* during load can be detected by {@link GroupNodeHandler.isGroupNode}. This is
* stamped directly on the constructor rather than copied through
* {@link ComfyNodeDefImpl} construction, keeping the migration self-contained.
*/
function markGroupNodeType(typeName, config) {
	const ctor = LiteGraph.registered_node_types[typeName];
	if (ctor?.nodeData) ctor.nodeData[GROUP] = config;
}
function isSlotType(value) {
	return typeof value === "number" || typeof value === "string" || Array.isArray(value) && value.every((item) => typeof item === "string");
}
function isOutputTypeSpec(value) {
	return typeof value === "string" || Array.isArray(value) && value.every((option) => typeof option === "string" || typeof option === "number");
}
var GroupNodeConfig = class GroupNodeConfig {
	name;
	nodeData;
	inputCount;
	oldToNewOutputMap;
	newToOldOutputMap;
	oldToNewInputMap;
	oldToNewWidgetMap;
	newToOldWidgetMap;
	primitiveDefs;
	widgetToPrimitive;
	primitiveToWidget;
	nodeInputs;
	outputVisibility;
	nodeDef;
	inputs;
	linksFrom;
	linksTo;
	externalFrom;
	constructor(name, nodeData) {
		this.name = name;
		this.nodeData = nodeData;
		this.getLinks();
		this.inputCount = 0;
		this.oldToNewOutputMap = {};
		this.newToOldOutputMap = {};
		this.oldToNewInputMap = {};
		this.oldToNewWidgetMap = {};
		this.newToOldWidgetMap = {};
		this.primitiveDefs = {};
		this.widgetToPrimitive = {};
		this.primitiveToWidget = {};
		this.nodeInputs = {};
		this.outputVisibility = [];
	}
	async registerType(source = PREFIX) {
		this.nodeDef = {
			output: [],
			output_name: [],
			output_is_list: [],
			output_node: false,
			name: source + ">" + this.name,
			display_name: this.name,
			category: "group nodes" + (">" + source),
			input: { required: {} },
			description: `Group node combining ${this.nodeData.nodes.map((n) => n.type).join(", ")}`,
			python_module: "custom_nodes." + this.name
		};
		this.inputs = [];
		const seenInputs = {};
		const seenOutputs = {};
		for (let i = 0; i < this.nodeData.nodes.length; i++) {
			const node = this.nodeData.nodes[i];
			node.index = i;
			this.processNode(node, seenInputs, seenOutputs);
		}
		for (const p of this._convertedToProcess) p();
		this._convertedToProcess = [];
		const typeName = `${PREFIX}>${this.name}`;
		await app.registerNodeDef(typeName, this.nodeDef);
		markGroupNodeType(typeName, this);
		useNodeDefStore().addNodeDef(this.nodeDef);
	}
	getLinks() {
		this.linksFrom = {};
		this.linksTo = {};
		this.externalFrom = {};
		for (const link of this.nodeData.links) {
			const [sourceNodeIndex, sourceSlot, targetNodeIndex, targetSlot] = link;
			if (sourceNodeIndex == null) continue;
			const fromSlots = this.linksFrom[sourceNodeIndex] ??= {};
			(fromSlots[sourceSlot] ??= []).push(link);
			(this.linksTo[targetNodeIndex] ??= {})[targetSlot] = link;
		}
		for (const ext of this.nodeData.external ?? []) {
			const nodeIdx = Number(ext[0]);
			const slotIdx = Number(ext[1]);
			const typeVal = ext.at(2);
			if (typeVal == null) continue;
			(this.externalFrom[nodeIdx] ??= {})[slotIdx] = typeVal;
		}
	}
	processNode(node, seenInputs, seenOutputs) {
		const def = this.getNodeDef(node);
		if (!def) return;
		const inputs = {
			...def.input?.required,
			...def.input?.optional
		};
		this.inputs.push(this.processNodeInputs(node, seenInputs, inputs));
		if (def.output?.length) this.processNodeOutputs(node, seenOutputs, def);
	}
	getNodeDef(node) {
		if (node.type) {
			const def = globalDefs[node.type];
			if (def) return def;
		}
		const nodeIndex = node.index;
		if (nodeIndex == null) return void 0;
		const linksFrom = this.linksFrom[nodeIndex];
		if (node.type === "PrimitiveNode") {
			if (!linksFrom) return;
			const firstLink = linksFrom[0]?.at(0);
			const linkedType = firstLink?.at(5);
			let type = firstLink ? linkedType == null ? null : isSlotType(linkedType) ? slotTypeKey(linkedType) : null : null;
			if (type === "COMBO") {
				const source = (node.outputs?.[0])?.widget?.name;
				const nodeIdx = firstLink?.[2];
				if (source && nodeIdx != null) {
					const fromTypeName = this.nodeData.nodes.at(nodeIdx)?.type;
					if (fromTypeName) {
						const fromType = globalDefs[fromTypeName];
						const inputType = (fromType?.input?.required?.[source] ?? fromType?.input?.optional?.[source])?.[0];
						type = typeof inputType === "string" || typeof inputType === "number" ? inputType : null;
					}
				}
			}
			return this.primitiveDefs[nodeIndex] = {
				input: { required: { value: [type, {}] } },
				output: [type],
				output_name: [],
				output_is_list: []
			};
		} else if (node.type === "Reroute") {
			const linksTo = this.linksTo[nodeIndex];
			if (linksTo && linksFrom && !this.externalFrom[nodeIndex]?.[0]) return null;
			let config = {};
			let rerouteType = "*";
			if (linksFrom) {
				const links = linksFrom[0] ?? [];
				for (const [, , targetNodeIndex, targetSlot] of links) {
					const targetNode = this.nodeData.nodes.at(targetNodeIndex);
					const input = targetNode?.inputs?.[targetSlot];
					if (input?.type && rerouteType === "*") rerouteType = input.type;
					if (input?.widget && targetNode?.type) {
						const targetDef = globalDefs[targetNode.type];
						const targetWidget = targetDef?.input?.required?.[input.widget.name] ?? targetDef?.input?.optional?.[input.widget.name];
						if (targetWidget) {
							const widgetSpec = [targetWidget[0], config];
							config = mergeIfValid({ widget: widgetSpec }, targetWidget, false, void 0, widgetSpec).customConfig ?? config;
						}
					}
				}
			} else if (linksTo) {
				const link = linksTo[0];
				if (link?.[0] != null) {
					const output = this.nodeData.nodes.at(link[0])?.outputs?.[link[1]];
					if (output) rerouteType = output.type;
				}
			} else {
				for (const l of this.nodeData.links) if (l[2] === node.index && isSlotType(l[5])) {
					rerouteType = l[5];
					break;
				}
				if (rerouteType === "*") {
					const t = this.externalFrom[nodeIndex]?.[0];
					if (t) rerouteType = t;
				}
			}
			config.forceInput = true;
			const rerouteTypeKey = slotTypeKey(rerouteType);
			return {
				input: { required: { [rerouteTypeKey]: [rerouteTypeKey, config] } },
				output: [rerouteTypeKey],
				output_name: [],
				output_is_list: []
			};
		}
		console.warn("Skipping virtual node " + node.type + " when building group node " + this.name);
	}
	getInputConfig(node, inputName, seenInputs, config, extra) {
		const customConfig = (this.nodeData.config?.[node.index ?? -1])?.input?.[inputName];
		let name = customConfig?.name ?? node.inputs?.find((inp) => inp.name === inputName)?.label ?? inputName;
		let key = name;
		let prefix = "";
		if (node.type === "PrimitiveNode" && node.title || name in seenInputs) {
			prefix = `${node.title ?? node.type} `;
			key = name = `${prefix}${inputName}`;
			if (name in seenInputs) name = `${prefix}${seenInputs[name]} ${inputName}`;
		}
		seenInputs[key] = (seenInputs[key] ?? 1) + 1;
		if (inputName === "seed" || inputName === "noise_seed") {
			if (!extra) extra = {};
			extra.control_after_generate = `${prefix}control_after_generate`;
		}
		if (config[0] === "IMAGEUPLOAD") {
			if (!extra) extra = {};
			const nodeIndex = node.index ?? -1;
			const configOptions = config[1] ?? {};
			const widgetKey = "widget" in configOptions && typeof configOptions.widget === "string" ? configOptions.widget : "image";
			extra.widget = this.oldToNewWidgetMap[nodeIndex]?.[widgetKey] ?? "image";
		}
		if (extra) config = [config[0], {
			...config[1],
			...extra
		}];
		return {
			name,
			config,
			customConfig
		};
	}
	processWidgetInputs(inputs, node, inputNames, seenInputs) {
		const slots = [];
		const converted = /* @__PURE__ */ new Map();
		const nodeIndex = node.index ?? -1;
		const widgetMap = this.oldToNewWidgetMap[nodeIndex] = {};
		for (const inputName of inputNames) {
			const inputSpec = inputs[inputName];
			const isValidSpec = Array.isArray(inputSpec) && inputSpec.length >= 1 && (typeof inputSpec[0] === "string" || Array.isArray(inputSpec[0]));
			const specOptions = Array.isArray(inputSpec) && typeof inputSpec[1] === "object" && inputSpec[1] !== null ? inputSpec[1] : {};
			const isForcedInput = "forceInput" in specOptions && specOptions.forceInput === true;
			if (isValidSpec && !isForcedInput && useWidgetStore().inputIsWidget(inputSpec)) {
				const convertedIndex = node.inputs?.findIndex((inp) => inp.name === inputName && inp.widget?.name === inputName) ?? -1;
				if (convertedIndex > -1) {
					converted.set(convertedIndex, inputName);
					widgetMap[inputName] = null;
				} else {
					const { name, config } = this.getInputConfig(node, inputName, seenInputs, inputSpec);
					if (this.nodeDef?.input?.required) this.nodeDef.input.required[name] = config;
					widgetMap[inputName] = name;
					this.newToOldWidgetMap[name] = {
						node,
						inputName
					};
				}
			} else slots.push(inputName);
		}
		return {
			converted,
			slots
		};
	}
	checkPrimitiveConnection(link, inputName, inputs) {
		const [sourceNodeIndex, , targetNodeIndex] = link;
		if (sourceNodeIndex == null) return;
		if (this.nodeData.nodes.at(sourceNodeIndex)?.type === "PrimitiveNode") {
			const primitiveDef = this.primitiveDefs[sourceNodeIndex];
			if (!primitiveDef) return;
			const targetWidget = inputs[inputName];
			const primitiveConfig = primitiveDef.input.required.value;
			const config = mergeIfValid({}, targetWidget, false, void 0, primitiveConfig);
			const inputConfig = inputs[inputName]?.[1];
			primitiveConfig[1] = config.customConfig ?? inputConfig ? { ...typeof inputConfig === "object" ? inputConfig : {} } : {};
			const widgetName = this.oldToNewWidgetMap[sourceNodeIndex]?.["value"];
			if (widgetName) {
				const name = widgetName.substring(0, widgetName.length - 6);
				primitiveConfig[1].control_after_generate = true;
				primitiveConfig[1].control_prefix = name;
			}
			const toPrimitive = this.widgetToPrimitive[targetNodeIndex] ??= {};
			const existing = toPrimitive[inputName];
			if (Array.isArray(existing)) existing.push(sourceNodeIndex);
			else if (typeof existing === "number") toPrimitive[inputName] = [existing, sourceNodeIndex];
			else toPrimitive[inputName] = sourceNodeIndex;
			(this.primitiveToWidget[sourceNodeIndex] ??= []).push({
				nodeId: targetNodeIndex,
				inputName
			});
		}
	}
	processInputSlots(inputs, node, slots, linksTo, inputMap, seenInputs) {
		const nodeIdx = node.index ?? -1;
		const nodeInputs = this.nodeInputs[nodeIdx] = {};
		for (let i = 0; i < slots.length; i++) {
			const inputName = slots[i];
			const namedSlotIndex = node.inputs?.findIndex((inp) => inp.name === inputName);
			const link = linksTo[namedSlotIndex != null && namedSlotIndex >= 0 ? namedSlotIndex : i];
			if (link) {
				this.checkPrimitiveConnection(link, inputName, inputs);
				continue;
			}
			const { name, config, customConfig } = this.getInputConfig(node, inputName, seenInputs, inputs[inputName]);
			nodeInputs[inputName] = name;
			if (customConfig?.visible === false) continue;
			if (this.nodeDef?.input?.required) this.nodeDef.input.required[name] = config;
			inputMap[inputName] = this.inputCount++;
		}
	}
	processConvertedWidgets(inputs, node, converted, linksTo, inputMap, seenInputs) {
		const convertedEntries = [...converted.entries()].sort(([a], [b]) => a - b);
		for (const [slotIndex, inputName] of convertedEntries) {
			if (!inputName) continue;
			const link = linksTo[slotIndex];
			if (link) {
				this.checkPrimitiveConnection(link, inputName, inputs);
				continue;
			}
			const { name, config } = this.getInputConfig(node, inputName, seenInputs, inputs[inputName], { defaultInput: true });
			if (this.nodeDef?.input?.required) this.nodeDef.input.required[name] = config;
			this.newToOldWidgetMap[name] = {
				node,
				inputName
			};
			const nodeIndex = node.index ?? -1;
			(this.oldToNewWidgetMap[nodeIndex] ??= {})[inputName] = name;
			inputMap[inputName] = this.inputCount++;
		}
	}
	_convertedToProcess = [];
	processNodeInputs(node, seenInputs, inputs) {
		const inputMapping = [];
		const inputNames = Object.keys(inputs);
		if (!inputNames.length) return;
		const { converted, slots } = this.processWidgetInputs(inputs, node, inputNames, seenInputs);
		const nodeIndex = node.index ?? -1;
		const linksTo = this.linksTo[nodeIndex] ?? {};
		const inputMap = this.oldToNewInputMap[nodeIndex] = {};
		this.processInputSlots(inputs, node, slots, linksTo, inputMap, seenInputs);
		this._convertedToProcess.push(() => this.processConvertedWidgets(inputs, node, converted, linksTo, inputMap, seenInputs));
		return inputMapping;
	}
	processNodeOutputs(node, seenOutputs, def) {
		const nodeIndex = node.index ?? -1;
		const oldToNew = this.oldToNewOutputMap[nodeIndex] = {};
		const defOutput = def.output ?? [];
		for (let outputId = 0; outputId < defOutput.length; outputId++) {
			const hasLink = this.linksFrom[nodeIndex]?.[outputId] && !this.externalFrom[nodeIndex]?.[outputId];
			const customConfig = (this.nodeData.config?.[node.index ?? -1])?.output?.[outputId];
			const visible = customConfig?.visible ?? !hasLink;
			this.outputVisibility.push(visible);
			if (!visible) continue;
			const output = defOutput[outputId];
			if (!isOutputTypeSpec(output)) continue;
			if (this.nodeDef?.output) {
				oldToNew[outputId] = this.nodeDef.output.length;
				this.newToOldOutputMap[this.nodeDef.output.length] = {
					node,
					slot: outputId
				};
				this.nodeDef.output.push(output);
				this.nodeDef.output_is_list?.push(def.output_is_list?.[outputId] ?? false);
			}
			let label = customConfig?.name;
			if (!label) {
				const outputVal = defOutput[outputId];
				label = def.output_name?.[outputId] ?? (typeof outputVal === "string" ? outputVal : void 0);
				const output = node.outputs?.find((o) => o.name === label);
				if (output?.label) label = output.label;
			}
			let name = label ?? `output_${outputId}`;
			if (name in seenOutputs) {
				const prefix = `${node.title ?? node.type} `;
				name = `${prefix}${label ?? outputId}`;
				if (name in seenOutputs) name = `${prefix}${node.index} ${label ?? outputId}`;
			}
			seenOutputs[name] = 1;
			this.nodeDef?.output_name?.push(name);
		}
	}
	static async registerFromWorkflow(groupNodes, missingNodeTypes, instanceIdsByGroup) {
		for (const g in groupNodes) {
			const groupData = groupNodes[g];
			const missingInnerTypes = [...new Set(groupData.nodes.filter((n) => !n.type || !(n.type in LiteGraph.registered_node_types)).map((n) => n.type ?? "unknown"))];
			if (missingInnerTypes.length) {
				const groupType = `${PREFIX}>${g}`;
				if (LiteGraph.registered_node_types[groupType]?.nodeData?.[GROUP]) {
					LiteGraph.unregisterNodeType(groupType);
					useNodeDefStore().removeNodeDef(groupType);
				}
				const removeAction = {
					text: "Remove from workflow",
					callback: (e) => {
						delete groupNodes[g];
						const target = e?.target;
						if (!target) return;
						target.textContent = "Removed";
						target.style.pointerEvents = "none";
						target.style.opacity = "0.7";
					}
				};
				if (instanceIdsByGroup) for (const id of instanceIdsByGroup.get(g) ?? []) missingNodeTypes.push({
					type: groupType,
					nodeId: String(id),
					hint: t("g.missingNodeTypesInGroup", { types: missingInnerTypes.join(", ") }),
					action: removeAction
				});
				else {
					for (const missingType of missingInnerTypes) missingNodeTypes.push({
						type: missingType,
						hint: ` (In group node '${groupType}')`
					});
					missingNodeTypes.push({
						type: groupType,
						action: removeAction
					});
				}
				continue;
			}
			await new GroupNodeConfig(g, groupData).registerType();
		}
	}
};
/**
* Finds the outer widget matching `name`, skipping any index already in
* `consumed`.
*
* Widget names inside a synthesized group-node type are meant to be unique
* (see {@link GroupNodeConfig.getInputConfig}'s de-duplication), so pairing
* by name alone is normally safe. But it is not *guaranteed* unique across
* every inner node/widget combination, and a plain `Array.findIndex` always
* resolves a shared name to the *first* matching widget — silently copying
* that node's value into every other inner node exposing a widget with the
* same final name. Consuming each match exactly once, in the same
* node-by-node order the inner nodes are unpacked, keeps every widget paired
* with the widget belonging to its own originating node even when two
* inner nodes end up sharing an outer widget name (e.g. two `CLIPTextEncode`
* nodes both exposing `text`).
*/
function findUnconsumedWidgetIndex(widgets, name, consumed) {
	if (!widgets) return -1;
	for (let i = 0; i < widgets.length; i++) {
		if (consumed.has(i)) continue;
		if (widgets[i]?.name === name) return i;
	}
	return -1;
}
/**
* Migration-only adapter for deprecated group nodes.
*
* Group nodes are no longer a supported feature. When a legacy workflow that
* contains group nodes is loaded, {@link GroupNodeConfig.registerFromWorkflow}
* synthesizes temporary node types so the instances can be created during
* `configure`. The load-time migration unpacks each instance via
* {@link convertToNodes} and {@link LGraph.convertToSubgraph} repackages the
* result as a subgraph.
*
*/
var GroupNodeHandler = class GroupNodeHandler {
	node;
	groupData;
	constructor(node, groupData) {
		this.node = node;
		this.groupData = groupData;
	}
	/**
	* Unpacks this group node into its constituent nodes within the root graph,
	* copying current widget values and reconnecting external links, then removes
	* the group node. Returns the newly created nodes.
	*
	* Lossiness is accepted: group nodes nested inside subgraphs are unpacked into
	* the root graph rather than their original container.
	*/
	convertToNodes() {
		const node = this.node;
		const { nodeData, oldToNewWidgetMap, oldToNewInputMap, newToOldOutputMap } = this.groupData;
		const addInnerNodes = () => {
			const c = { ...nodeData };
			c.nodes = c.nodes.map((n) => ({
				...n,
				id: void 0
			}));
			deserialiseAndCreate(JSON.stringify(c), app.canvas);
			const [x, y] = node.pos;
			let top;
			let left;
			const selectedIds = selectedCanvasNodes(app.canvas).map((n) => n.id);
			const newNodes = [];
			const consumedOuterWidgetIndices = /* @__PURE__ */ new Set();
			for (let i = 0; i < selectedIds.length; i++) {
				const selectedId = parseNodeId(selectedIds[i]);
				const newNode = selectedId ? app.rootGraph.getNodeById(selectedId) : null;
				const innerNodeData = nodeData.nodes.at(i);
				if (!newNode) continue;
				newNodes.push(newNode);
				if (left == null || newNode.pos[0] < left) left = newNode.pos[0];
				if (top == null || newNode.pos[1] < top) top = newNode.pos[1];
				if (!newNode.widgets || !innerNodeData) continue;
				const map = oldToNewWidgetMap[i];
				if (!map) continue;
				for (const oldName of Object.keys(map)) {
					const newName = map[oldName];
					if (!newName) continue;
					const widgetIndex = findUnconsumedWidgetIndex(node.widgets, newName, consumedOuterWidgetIndices);
					if (widgetIndex === -1) continue;
					if (innerNodeData.type === "PrimitiveNode") for (let j = 0; j < newNode.widgets.length; j++) {
						const srcWidget = node.widgets?.[widgetIndex + j];
						if (!srcWidget) continue;
						consumedOuterWidgetIndices.add(widgetIndex + j);
						newNode.widgets[j].value = srcWidget.value;
					}
					else {
						const outerWidget = node.widgets?.[widgetIndex];
						const newWidget = newNode.widgets.find((w) => w.name === oldName);
						if (!newWidget || !outerWidget) continue;
						consumedOuterWidgetIndices.add(widgetIndex);
						newWidget.value = outerWidget.value;
						const linkedWidgets = outerWidget.linkedWidgets ?? [];
						for (let w = 0; w < linkedWidgets.length; w++) {
							const newLinked = newWidget.linkedWidgets?.[w];
							if (newLinked && linkedWidgets[w]) newLinked.value = linkedWidgets[w].value;
						}
					}
				}
			}
			for (const newNode of newNodes) newNode.pos = [newNode.pos[0] - ((left ?? 0) - x), newNode.pos[1] - ((top ?? 0) - y)];
			return {
				newNodes,
				selectedIds
			};
		};
		const reconnectInputs = (selectedIds) => {
			for (const [innerNodeIndex, map] of Object.entries(oldToNewInputMap)) {
				const selectedId = parseNodeId(selectedIds[Number(innerNodeIndex)]);
				const newNode = selectedId ? app.rootGraph.getNodeById(selectedId) : null;
				if (!newNode || !map) continue;
				for (const [innerInputName, groupSlotId] of Object.entries(map)) {
					const link = node.getInputLink(groupSlotId);
					if (!link) continue;
					const originNode = app.rootGraph.getNodeById(link.origin_id);
					const innerInputId = newNode.findInputSlot(innerInputName);
					if (innerInputId !== -1) originNode?.connect(link.origin_slot, newNode, innerInputId);
				}
			}
		};
		const reconnectOutputs = (selectedIds) => {
			for (let groupOutputId = 0; groupOutputId < node.outputs.length; groupOutputId++) {
				const links = outputLinks(app.rootGraph, node.id, groupOutputId);
				for (const link of links) {
					const slot = newToOldOutputMap[groupOutputId];
					if (!slot) continue;
					const targetNode = app.rootGraph.getNodeById(link.target_id);
					const selectedId = parseNodeId(selectedIds[slot.node.index ?? 0]);
					const newNode = selectedId ? app.rootGraph.getNodeById(selectedId) : null;
					if (targetNode) newNode?.connect(slot.slot, targetNode, link.target_slot);
				}
			}
		};
		app.canvas.emitBeforeChange();
		try {
			const { newNodes, selectedIds } = addInnerNodes();
			reconnectInputs(selectedIds);
			reconnectOutputs(selectedIds);
			app.rootGraph.remove(this.node);
			return newNodes;
		} finally {
			app.canvas.emitAfterChange();
		}
	}
	static getHandler(node) {
		const cached = node[GROUP];
		if (cached) return cached;
		const groupData = groupConfigOf(node);
		if (!groupData) return void 0;
		const handler = new GroupNodeHandler(node, groupData);
		node[GROUP] = handler;
		return handler;
	}
	static isGroupNode(node) {
		return groupConfigOf(node) !== void 0;
	}
};
function groupConfigOf(node) {
	const config = node.constructor.nodeData?.[GROUP];
	return config instanceof GroupNodeConfig ? config : void 0;
}
var replaceLegacySeparators = (nodes) => {
	for (const node of nodes) if (typeof node.type === "string" && node.type.startsWith("workflow/")) node.type = node.type.replace(/^workflow\//, `${PREFIX}>`);
};
/**
* Converts every group node in the root graph to a subgraph. Re-scans until none
* remain so group nodes revealed by a previous conversion are also migrated. A
* failed conversion removes the offending node so loading can continue (accepted
* lossiness) and the scan cannot loop forever.
* @returns the number of group nodes converted
*/
function convertLoadedGroupNodes() {
	let converted = 0;
	const failed = /* @__PURE__ */ new Set();
	for (;;) {
		const node = app.rootGraph.nodes.find((n) => GroupNodeHandler.isGroupNode(n) && !failed.has(n));
		if (!node) return converted;
		try {
			const handler = GroupNodeHandler.getHandler(node);
			if (!handler) {
				console.error("Missing handler for group node");
				failed.add(node);
				app.rootGraph.remove(node);
				continue;
			}
			const innerNodes = handler.convertToNodes();
			for (const inner of innerNodes) inner.updateArea();
			app.rootGraph.convertToSubgraph(new Set(innerNodes));
			converted++;
		} catch (error) {
			console.error("Failed to convert group node to subgraph", error);
			failed.add(node);
			try {
				app.rootGraph.remove(node);
			} catch (removeError) {
				console.error("Failed to remove group node after conversion failure", removeError);
			}
		}
	}
}
var groupNodeReportIndices = /* @__PURE__ */ new WeakMap();
var id = "Comfy.GroupNode";
/**
* Global node definitions cache. Populated by `addCustomNodeDefs` during
* extension initialization and read by {@link GroupNodeConfig.getNodeDef} when
* synthesizing temporary group-node definitions during load.
*/
var globalDefs = {};
var groupNodeExtension = {
	name: id,
	addCustomNodeDefs(defs) {
		globalDefs = defs;
	},
	async beforeConfigureGraph(graphData, missingNodeTypes) {
		const nodes = graphData.extra?.groupNodes;
		if (nodes) {
			replaceLegacySeparators(graphData.nodes);
			const instanceIndicesByGroup = /* @__PURE__ */ new Map();
			const groupTypePrefix = `${PREFIX}>`;
			for (const [nodeIndex, n] of graphData.nodes.entries()) {
				if (!n.type.startsWith(groupTypePrefix)) continue;
				const groupName = n.type.slice(groupTypePrefix.length);
				const indices = instanceIndicesByGroup.get(groupName) ?? [];
				indices.push(nodeIndex);
				instanceIndicesByGroup.set(groupName, indices);
			}
			const groupNodeReports = [];
			await GroupNodeConfig.registerFromWorkflow(nodes, groupNodeReports, instanceIndicesByGroup);
			for (const report of groupNodeReports) {
				if (typeof report === "string" || report.nodeId == null) continue;
				const nodeIndex = Number(report.nodeId);
				if (Number.isInteger(nodeIndex)) groupNodeReportIndices.set(report, nodeIndex);
			}
			missingNodeTypes.push(...groupNodeReports);
		}
	},
	afterConfigureGraph(missingNodeTypes) {
		for (let index = missingNodeTypes.length - 1; index >= 0; index--) {
			const report = missingNodeTypes[index];
			if (typeof report === "string") continue;
			const nodeIndex = groupNodeReportIndices.get(report);
			if (nodeIndex === void 0) continue;
			groupNodeReportIndices.delete(report);
			const node = app.rootGraph.nodes.at(nodeIndex);
			if (node) report.nodeId = String(node.id);
			else missingNodeTypes.splice(index, 1);
		}
		if (convertLoadedGroupNodes() > 0) delete app.rootGraph.extra.groupNodes;
	},
	nodeCreated(node) {
		if (!GroupNodeHandler.isGroupNode(node)) return;
		const handler = GroupNodeHandler.getHandler(node);
		if (!app.configuringGraph) queueMicrotask(() => {
			const graph = node.graph;
			if (graph && handler && GroupNodeHandler.isGroupNode(node)) try {
				const innerNodes = handler.convertToNodes();
				for (const inner of innerNodes) inner.updateArea();
				graph.convertToSubgraph(new Set(innerNodes));
			} catch (error) {
				console.error("Failed to convert stray group node to subgraph", error);
			}
		});
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.groupNode = window.comfyAPI.groupNode || {};
window.comfyAPI.groupNode.GroupNodeConfig = GroupNodeConfig;
window.comfyAPI.groupNode.findUnconsumedWidgetIndex = findUnconsumedWidgetIndex;
window.comfyAPI.groupNode.GroupNodeHandler = GroupNodeHandler;
window.comfyAPI.groupNode.replaceLegacySeparators = replaceLegacySeparators;
window.comfyAPI.groupNode.groupNodeExtension = groupNodeExtension;
//#endregion
//#region src/extensions/core/groupOptions.ts
function setNodeMode(node, mode) {
	node.mode = mode;
	node.graph?.change();
}
var MODE_MENU_ITEMS = [
	{
		content: "Set Group Nodes to Always",
		mode: LGraphEventMode.ALWAYS
	},
	{
		content: "Set Group Nodes to Never",
		mode: LGraphEventMode.NEVER
	},
	{
		content: "Bypass Group Nodes",
		mode: LGraphEventMode.BYPASS
	}
];
function addNodesToGroup(group, items) {
	const padding = useSettingStore().get("Comfy.GroupSelectedNodes.Padding");
	group.resizeTo([...group.children, ...items], padding);
}
var groupOptionsExtension = {
	name: "Comfy.GroupOptions",
	getCanvasMenuItems(canvas) {
		const items = [];
		const graph = canvas.graph;
		if (!graph) return items;
		const group = graph.getGroupOnPos(canvas.graph_mouse[0], canvas.graph_mouse[1]);
		if (!group) {
			if (canvas.selectedItems.size > 0) items.push({
				content: "Add Group For Selected Nodes",
				callback: () => {
					const group = new LGraphGroup();
					addNodesToGroup(group, canvas.selectedItems);
					graph.add(group);
					graph.change();
					group.recomputeInsideNodes();
				}
			});
			return items;
		}
		group.recomputeInsideNodes();
		const nodesInGroup = group.nodes;
		items.push({
			content: "Add Selected Nodes To Group",
			disabled: !canvas.selectedItems.size,
			callback: () => {
				addNodesToGroup(group, canvas.selectedItems);
				graph.change();
			}
		});
		if (nodesInGroup.length === 0) return items;
		else items.push(null);
		const firstMode = nodesInGroup[0].mode;
		const sharedMode = nodesInGroup.every((node) => node.mode === firstMode) ? firstMode : void 0;
		items.push({
			content: "Fit Group To Nodes",
			callback: () => {
				group.recomputeInsideNodes();
				const padding = useSettingStore().get("Comfy.GroupSelectedNodes.Padding");
				group.resizeTo(group.children, padding);
				graph.change();
			}
		});
		items.push({
			content: "Select Nodes",
			callback: () => {
				canvas.selectNodes(nodesInGroup);
				graph.change();
				canvas.canvas.focus();
			}
		});
		for (const { content, mode } of MODE_MENU_ITEMS) {
			if (mode === sharedMode) continue;
			items.push({
				content,
				callback: () => {
					for (const node of nodesInGroup) setNodeMode(node, mode);
				}
			});
		}
		return items;
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.groupOptions = window.comfyAPI.groupOptions || {};
window.comfyAPI.groupOptions.groupOptionsExtension = groupOptionsExtension;
//#endregion
//#region src/extensions/core/imageCompare.ts
var imageCompareExtension = {
	name: "Comfy.ImageCompare",
	async nodeCreated(node) {
		if (node.constructor.comfyClass !== "ImageCompare") return;
		const [oldWidth, oldHeight] = node.size;
		node.setSize([Math.max(oldWidth, 400), Math.max(oldHeight, 350)]);
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.imageCompare = window.comfyAPI.imageCompare || {};
window.comfyAPI.imageCompare.imageCompareExtension = imageCompareExtension;
//#endregion
//#region src/extensions/core/imageCompositor.ts
var imageCompositorExtension = {
	name: "Comfy.ImageCompositor",
	nodeCreated(node) {
		if (node.constructor.comfyClass !== "ImageCompositor") return;
		const [oldWidth, oldHeight] = node.size;
		node.setSize([Math.max(oldWidth, 300), Math.max(oldHeight, 400)]);
		node.hideOutputImages = true;
		const onExecuted = node.onExecuted;
		node.onExecuted = function(output) {
			onExecuted?.call(this, output);
			const kept = (output.compositor_layers ?? []).flatMap(({ filename, subfolder = "", type = "temp" }, index) => filename ? [{
				layer: {
					filename,
					subfolder,
					type
				},
				index
			}] : []);
			const layers = kept.map(({ layer }) => layer);
			const rawBboxes = output.compositor_bboxes;
			const bboxes = rawBboxes ? kept.map(({ index }) => rawBboxes[index] ?? null) : void 0;
			if (layers.length) setCompositorLayers(node, layers, output.compositor_inputs, bboxes, output.compositor_canvas?.[0]);
			clearCompositorPreviewOverride(node);
			if (output.compositor_state_stale?.[0]) {
				resetCompositorStateWidgets(node);
				node.graph?.setDirtyCanvas(true);
			}
		};
		const onRemoved = node.onRemoved;
		node.onRemoved = function() {
			onRemoved?.call(this);
			clearCompositorLayers(node);
		};
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.imageCompositor = window.comfyAPI.imageCompositor || {};
window.comfyAPI.imageCompositor.imageCompositorExtension = imageCompositorExtension;
//#endregion
//#region src/extensions/core/imageCrop.ts
var imageCropExtension = {
	name: "Comfy.ImageCrop",
	async nodeCreated(node) {
		if (node.constructor.comfyClass !== "ImageCropV2") return;
		node.hideOutputImages = true;
		const [oldWidth, oldHeight] = node.size;
		node.setSize([Math.max(oldWidth, 300), Math.max(oldHeight, 450)]);
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.imageCrop = window.comfyAPI.imageCrop || {};
window.comfyAPI.imageCrop.imageCropExtension = imageCropExtension;
//#endregion
//#region src/extensions/core/layerEditor.ts
var layerEditorExtension = {
	name: "Comfy.LayerEditor",
	commands: [{
		id: "Comfy.LayerEditor.OpenLayerEditor",
		icon: "pi pi-images",
		label: "Open Layer Editor for Selected Node",
		function: async () => {
			const selectedNodes = selectedCanvasNodes(app.canvas);
			if (selectedNodes.length !== 1) return;
			const [selectedNode] = selectedNodes;
			const { useLayerEditor } = await __vitePreload(async () => {
				const { useLayerEditor } = await import("./useLayerEditor-CNrN-oWG.js");
				return { useLayerEditor };
			}, __vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66]), import.meta.url);
			useLayerEditor().openLayerEditor(selectedNode);
		}
	}]
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.layerEditor = window.comfyAPI.layerEditor || {};
window.comfyAPI.layerEditor.layerEditorExtension = layerEditorExtension;
//#endregion
//#region src/extensions/core/load3d/load3dSettings.ts
var load3dSettings = [
	{
		id: "Comfy.Load3D.ShowGrid",
		category: [
			"3D",
			"Scene",
			"Initial Grid Visibility"
		],
		name: "Initial Grid Visibility",
		tooltip: "Controls whether the grid is visible by default when a new 3D widget is created. This default can still be toggled individually for each widget after creation.",
		type: "boolean",
		defaultValue: true,
		experimental: true
	},
	{
		id: "Comfy.Load3D.BackgroundColor",
		category: [
			"3D",
			"Scene",
			"Initial Background Color"
		],
		name: "Initial Background Color",
		tooltip: "Controls the default background color of the 3D scene. This setting determines the background appearance when a new 3D widget is created, but can be adjusted individually for each widget after creation.",
		type: "color",
		defaultValue: "282828",
		experimental: true
	},
	{
		id: "Comfy.Load3D.CameraType",
		category: [
			"3D",
			"Camera",
			"Initial Camera Type"
		],
		name: "Initial Camera Type",
		tooltip: "Controls whether the camera is perspective or orthographic by default when a new 3D widget is created. This default can still be toggled individually for each widget after creation.",
		type: "combo",
		options: ["perspective", "orthographic"],
		defaultValue: "perspective",
		experimental: true
	},
	{
		id: "Comfy.Load3D.LightIntensity",
		category: [
			"3D",
			"Light",
			"Initial Light Intensity"
		],
		name: "Initial Light Intensity",
		tooltip: "Sets the default brightness level of lighting in the 3D scene. This value determines how intensely lights illuminate objects when a new 3D widget is created, but can be adjusted individually for each widget after creation.",
		type: "number",
		defaultValue: 3,
		experimental: true
	},
	{
		id: "Comfy.Load3D.LightIntensityMaximum",
		category: [
			"3D",
			"Light",
			"Light Intensity Maximum"
		],
		name: "Light Intensity Maximum",
		tooltip: "Sets the maximum allowable light intensity value for 3D scenes. This defines the upper brightness limit that can be set when adjusting lighting in any 3D widget.",
		type: "number",
		defaultValue: 10,
		experimental: true
	},
	{
		id: "Comfy.Load3D.LightIntensityMinimum",
		category: [
			"3D",
			"Light",
			"Light Intensity Minimum"
		],
		name: "Light Intensity Minimum",
		tooltip: "Sets the minimum allowable light intensity value for 3D scenes. This defines the lower brightness limit that can be set when adjusting lighting in any 3D widget.",
		type: "number",
		defaultValue: 1,
		experimental: true
	},
	{
		id: "Comfy.Load3D.LightAdjustmentIncrement",
		category: [
			"3D",
			"Light",
			"Light Adjustment Increment"
		],
		name: "Light Adjustment Increment",
		tooltip: "Controls the increment size when adjusting light intensity in 3D scenes. A smaller step value allows for finer control over lighting adjustments, while a larger value results in more noticeable changes per adjustment.",
		type: "slider",
		attrs: {
			min: .1,
			max: 1,
			step: .1
		},
		defaultValue: .5,
		experimental: true
	},
	{
		id: "Comfy.Load3D.3DViewerEnable",
		category: [
			"3D",
			"3DViewer",
			"Enable"
		],
		name: "Enable 3D Viewer (Beta)",
		tooltip: "Enables the 3D Viewer (Beta) for selected nodes. This feature allows you to visualize and interact with 3D models directly within the full size 3d viewer.",
		type: "boolean",
		defaultValue: true,
		experimental: true
	},
	{
		id: "Comfy.Load3D.PLYEngine",
		category: [
			"3D",
			"PointCloud",
			"Point Cloud Engine"
		],
		name: "Point Cloud Engine",
		tooltip: "Select the engine for loading point cloud PLY files. \"threejs\" uses the native Three.js PLYLoader (handles binary + ASCII, mesh-capable). \"fastply\" uses an optimized parser for ASCII PLY files. 3D Gaussian Splat PLYs are detected automatically and always rendered via sparkjs regardless of this setting.",
		type: "combo",
		options: ["threejs", "fastply"],
		defaultValue: "threejs",
		migrateDeprecatedValue: (value) => value === "sparkjs" ? "threejs" : value,
		experimental: true
	}
];
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.load3dSettings = window.comfyAPI.load3dSettings || {};
window.comfyAPI.load3dSettings.load3dSettings = load3dSettings;
//#endregion
//#region src/extensions/core/load3d/load3dWidgets.ts
var Load3D = defineAsyncComponent(() => __vitePreload(() => import("./Load3D-p6d5xKyZ.js"), __vite__mapDeps([67,68,1,69,35,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,36,37,38,39,49,50,40,41,42,43,44,45,46,54,55,70,56,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,2,47,48,51,52,53,57,58,59,60,61,62,63,64,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,65,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167]), import.meta.url));
var Load3DAdvanced = defineAsyncComponent(() => __vitePreload(() => import("./Load3DAdvanced-q6EyCc4w.js"), __vite__mapDeps([168,1,10,68,69,35,3,4,5,6,7,8,9,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,36,37,38,39,49,50,40,41,42,43,44,45,46,54,55,70,56,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,2,47,48,51,52,53,57,58,59,60,61,62,63,64,92,93,94,95,96,97,98,99,100,101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,119,120,121,122,65,123,124,125,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,162,163,164,165,166,167]), import.meta.url));
var CameraInfo = defineAsyncComponent(() => __vitePreload(() => import("./CameraInfo-CCEAiKWG.js"), __vite__mapDeps([169,1,82,35,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,36,37,38,39,100,54,55,46,170,74,70,171,172,83,84,50,161,173]), import.meta.url));
var CameraAngle = defineAsyncComponent(() => __vitePreload(() => import("./CameraAngle-s9nvoAN6.js"), __vite__mapDeps([174,1,82,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,106,99,100,90,73,116,69,117,118,105,119,102,120,121,103,122,65,123,104,85,124,125,92,93,94,95,96,97,98,101,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,91,107,108,109,110,161,162,163,164,165,166,167,86,175,170,74,70,171,172,83,84]), import.meta.url));
var VIEWPORT_STATE_NODES = /* @__PURE__ */ new Set([
	"Preview3DAdvanced",
	"Save3DAdvanced",
	"PreviewGaussianSplat",
	"PreviewPointCloud",
	"SaveGaussianSplat",
	"SavePointCloud"
]);
function resourceSubfolder(node) {
	const resourceFolder = String(node.properties["Resource Folder"] ?? "").trim();
	return resourceFolder ? `3d/${resourceFolder}` : "3d";
}
async function handleModelUpload(files, node) {
	if (!files.length) return;
	const modelWidget = node.widgets?.find((w) => w.name === "model_file");
	try {
		const uploadPath = await Load3dUtils.uploadFile(files[0], resourceSubfolder(node));
		if (!uploadPath) {
			useToast().warning(t("toastMessages.fileUploadFailed"));
			return;
		}
		const modelUrl = api.apiURL(Load3dUtils.getResourceURL(...Load3dUtils.splitFilePath(uploadPath), "input"));
		const { useLoad3d, markLoad3dSceneDirty } = await __vitePreload(async () => {
			const { useLoad3d, markLoad3dSceneDirty } = await import("./useLoad3d-btsY_FBU.js");
			return {
				useLoad3d,
				markLoad3dSceneDirty
			};
		}, __vite__mapDeps([176,115,1,81,82,83,84,50,6,69,3,4,5,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,49,40,41,42,43,44,45,46,106,35,36,37,38,39,47,48,51,52,53,54,55,56,57,58,59,60,61,62,99,100,90,116,117,118,105,119,2,63,64,102,120,121,103,122,65,123,104,85,124,125,92,93,94,95,96,97,98,101,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,91,107,108,109,110,161,162,163,164,165,166,167,86,87,88,89,111]), import.meta.url);
		useLoad3d(node).waitForLoad3d(async (load3d) => {
			try {
				reportLoadModelOutcome(await load3d.loadModel(modelUrl));
			} catch {
				useToast().warning(t("toastMessages.failedToLoadModel"));
			}
		});
		if (modelWidget) {
			if (!modelWidget.options.values?.includes(uploadPath)) modelWidget.options.values?.push(uploadPath);
			modelWidget.value = uploadPath;
		}
		markLoad3dSceneDirty(node);
	} catch (error) {
		console.error("Model upload failed:", error);
		useToast().warning(t("toastMessages.fileUploadFailed"));
	}
}
async function handleResourcesUpload(files, node) {
	if (!files.length) return;
	try {
		await Load3dUtils.uploadMultipleFiles(files, resourceSubfolder(node));
		const { markLoad3dSceneDirty } = await __vitePreload(async () => {
			const { markLoad3dSceneDirty } = await import("./useLoad3d-btsY_FBU.js");
			return { markLoad3dSceneDirty };
		}, __vite__mapDeps([176,115,1,81,82,83,84,50,6,69,3,4,5,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,49,40,41,42,43,44,45,46,106,35,36,37,38,39,47,48,51,52,53,54,55,56,57,58,59,60,61,62,99,100,90,116,117,118,105,119,2,63,64,102,120,121,103,122,65,123,104,85,124,125,92,93,94,95,96,97,98,101,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,91,107,108,109,110,161,162,163,164,165,166,167,86,87,88,89,111]), import.meta.url);
		markLoad3dSceneDirty(node);
	} catch (error) {
		console.error("Extra resources upload failed:", error);
		useToast().warning(t("toastMessages.extraResourcesUploadFailed"));
	}
}
async function clearModel(node) {
	try {
		const { markLoad3dSceneDirty } = await __vitePreload(async () => {
			const { markLoad3dSceneDirty } = await import("./useLoad3d-btsY_FBU.js");
			return { markLoad3dSceneDirty };
		}, __vite__mapDeps([176,115,1,81,82,83,84,50,6,69,3,4,5,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,49,40,41,42,43,44,45,46,106,35,36,37,38,39,47,48,51,52,53,54,55,56,57,58,59,60,61,62,99,100,90,116,117,118,105,119,2,63,64,102,120,121,103,122,65,123,104,85,124,125,92,93,94,95,96,97,98,101,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,91,107,108,109,110,161,162,163,164,165,166,167,86,87,88,89,111]), import.meta.url);
		const modelWidget = node.widgets?.find((w) => w.name === "model_file");
		if (modelWidget) modelWidget.value = LOAD3D_NONE_MODEL;
		markLoad3dSceneDirty(node);
	} catch (error) {
		reportError(error, {
			errorType: "error_loading_3d_extensions",
			surface: "graph"
		});
	}
}
function createFileInput(accept, multiple) {
	const input = document.createElement("input");
	input.type = "file";
	input.accept = accept;
	input.multiple = multiple;
	input.style.display = "none";
	return input;
}
function addModelFileButtons(node) {
	const fileInput = createFileInput(SUPPORTED_EXTENSIONS_ACCEPT, false);
	node.properties["Resource Folder"] = "";
	fileInput.onchange = async () => {
		await handleModelUpload(fileInput.files, node);
	};
	node.addWidget("button", "upload 3d model", "upload3dmodel", () => {
		fileInput.click();
	});
	const resourcesInput = createFileInput("*", true);
	resourcesInput.onchange = async () => {
		await handleResourcesUpload(resourcesInput.files, node);
		resourcesInput.value = "";
	};
	node.addWidget("button", "upload extra resources", "uploadExtraResources", () => {
		resourcesInput.click();
	});
	node.addWidget("button", "clear", "clear", () => {
		clearModel(node);
	});
}
function addViewportWidget(node, component, inputSpec, type) {
	const widget = new ComponentWidgetImpl({
		node,
		name: inputSpec.name,
		component,
		inputSpec,
		options: { hideInPanel: true }
	});
	widget.type = type;
	addWidget(node, widget);
	return { widget };
}
/** Widget constructors for the 3D node types, available before the 3D extensions load. */
var load3dWidgets = {
	LOAD_3D(node) {
		const { comfyClass } = node.constructor;
		const name = comfyClass && VIEWPORT_STATE_NODES.has(comfyClass) ? "viewport_state" : "image";
		if (node.widgets?.some((w) => w.name === "model_file")) addModelFileButtons(node);
		return addViewportWidget(node, Load3D, {
			name,
			type: "Load3D",
			isPreview: false
		}, "load3D");
	},
	PREVIEW_3D(node) {
		return addViewportWidget(node, Load3D, {
			name: "image",
			type: "Preview3D",
			isPreview: true
		}, "load3D");
	},
	LOAD_3D_ADVANCED(node) {
		return addViewportWidget(node, Load3DAdvanced, {
			name: "viewport_state",
			type: "LOAD_3D_ADVANCED",
			isPreview: false
		}, "load3DAdvanced");
	},
	CAMERA_INFO_STATE(node) {
		const widget = new ComponentWidgetImpl({
			node,
			name: "camera_info_state",
			component: CameraInfo,
			inputSpec: {
				name: "camera_info_state",
				type: "CAMERA_INFO_STATE",
				isPreview: false
			},
			options: {
				serialize: false,
				hideInPanel: true
			}
		});
		widget.type = "cameraInfo";
		widget.serialize = false;
		addWidget(node, widget);
		return { widget };
	},
	CAMERA_ANGLE_VIEW(node) {
		let viewMode = "camera";
		const widget = new ComponentWidgetImpl({
			node,
			name: CAMERA_ANGLE_VIEW_WIDGET_NAME,
			component: CameraAngle,
			inputSpec: {
				name: CAMERA_ANGLE_VIEW_WIDGET_NAME,
				type: "CAMERA_ANGLE_VIEW",
				isPreview: false
			},
			options: {
				serialize: false,
				hideInPanel: true,
				getValue: () => viewMode,
				setValue: (value) => {
					if (isViewMode(value)) viewMode = value;
				}
			}
		});
		widget.type = "cameraAngle";
		addWidget(node, widget);
		return { widget };
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.load3dWidgets = window.comfyAPI.load3dWidgets || {};
window.comfyAPI.load3dWidgets.load3dWidgets = load3dWidgets;
//#endregion
//#region src/extensions/core/load3d/load3dLazy.ts
var load3dExtensionsLoaded = false;
var load3dExtensionsLoading = null;
function loadLoad3dExtensions() {
	if (load3dExtensionsLoaded) return Promise.resolve([]);
	load3dExtensionsLoading ??= importLoad3dExtensions();
	return load3dExtensionsLoading;
}
async function importLoad3dExtensions() {
	const disposers = [];
	let extensions;
	try {
		const [load3d, load3dAdvanced, load3dPreview, saveMesh, cameraInfo, cameraAngle, lightInfo] = await Promise.all([
			__vitePreload(() => import("./load3d-Bztforeb.js"), __vite__mapDeps([177,1,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,46,56,116,69,117,52,53,118,48,105,49,50,40,41,42,43,44,45,51,54,55,57,58,59,60,47,61,62,106,99,100,90,119,2,63,64,102,120,121,103,122,65,123,104,85,124,125,92,93,94,95,96,97,98,101,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,91,107,108,109,110,161,162,163,164,165,166,167,86,77,73,71,72,78,79,80,81,82,83,84,87,88,89,111,112,113,115,178,179,180]), import.meta.url),
			__vitePreload(() => import("./load3dAdvanced-ChN-U8po.js"), __vite__mapDeps([181,1,10,112,16,111,81,82,83,84,50,6,69,87,46,15,17,18,19,20,21,22,115,3,4,5,7,8,9,11,12,13,14,23,24,25,26,27,28,29,30,31,32,33,34,49,40,41,42,43,44,45,106,35,36,37,38,39,47,48,51,52,53,54,55,56,57,58,59,60,61,62,99,100,90,116,117,118,105,119,2,63,64,102,120,121,103,122,65,123,104,85,124,125,92,93,94,95,96,97,98,101,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,91,107,108,109,110,161,162,163,164,165,166,167,86,88,89,178,179]), import.meta.url),
			__vitePreload(() => import("./load3dPreviewExtensions-BTywk1br.js"), __vite__mapDeps([182,1,10,46,15,16,17,18,19,20,21,22,29,30,116,69,117,3,4,5,6,7,8,9,11,12,13,14,23,24,25,26,27,28,31,32,33,34,52,36,53,35,37,38,39,118,48,105,49,50,40,41,42,43,44,45,51,54,55,56,57,58,59,60,47,61,62,106,99,100,90,119,2,63,64,102,120,121,103,122,65,123,104,85,124,125,92,93,94,95,96,97,98,101,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,91,107,108,109,110,161,162,163,164,165,166,167,86,112,111,81,82,83,84,87,115,88,89,178,180]), import.meta.url),
			__vitePreload(() => import("./saveMesh-G-hOAdLc.js"), __vite__mapDeps([183,1,10,29,30,116,16,69,117,3,4,5,6,7,8,9,11,12,13,14,15,17,18,19,20,21,22,23,24,25,26,27,28,31,32,33,34,52,36,53,46,35,37,38,39,118,48,105,49,50,40,41,42,43,44,45,51,54,55,56,57,58,59,60,47,61,62,106,99,100,90,119,2,63,64,102,120,121,103,122,65,123,104,85,124,125,92,93,94,95,96,97,98,101,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,91,107,108,109,110,161,162,163,164,165,166,167,86,112,111,81,82,83,84,87,115,88,89,178]), import.meta.url),
			__vitePreload(() => import("./cameraInfo-T4fIPsW0.js"), __vite__mapDeps([184,1,10]), import.meta.url),
			__vitePreload(() => import("./cameraAngle-q-D9oiPv.js"), __vite__mapDeps([185,1]), import.meta.url),
			__vitePreload(() => import("./lightInfo-Dzw5_wU6.js"), __vite__mapDeps([186,1]), import.meta.url)
		]);
		extensions = [
			load3d.load3dExtension,
			load3d.preview3DExtension,
			load3d.preview3DAdvancedExtension,
			load3d.save3DAdvancedExtension,
			load3dAdvanced.load3dAdvancedExtension,
			load3dPreview.previewGaussianSplatExtension,
			load3dPreview.previewPointCloudExtension,
			load3dPreview.saveGaussianSplatExtension,
			load3dPreview.savePointCloudExtension,
			saveMesh.saveMeshExtension,
			cameraInfo.cameraInfoExtension,
			cameraAngle.cameraAngleExtension,
			lightInfo.lightInfoExtension
		];
		const { registerExtension } = useExtensionService();
		for (const extension of extensions) disposers.push(registerExtension(extension));
	} catch (cause) {
		disposers.forEach((dispose) => dispose());
		load3dExtensionsLoading = null;
		reportError(cause, {
			errorType: "error_loading_3d_extensions",
			surface: "graph"
		});
		return;
	}
	load3dExtensionsLoaded = true;
	const { isExtensionEnabled } = useExtensionStore();
	return extensions.filter((extension) => isExtensionEnabled(extension.name));
}
function enableMeshUpload(nodeData) {
	const modelFile = nodeData.input?.required?.model_file;
	if (!modelFile?.[1]) return;
	modelFile[1].mesh_upload = true;
	modelFile[1].upload_subfolder = "3d";
}
function addPreview3dInput(nodeData) {
	const input = nodeData.input ??= {};
	(input.required ??= {}).image = ["PREVIEW_3D"];
}
function addLoad3dAdvancedViewport(nodeData) {
	enableMeshUpload(nodeData);
	const required = nodeData.input?.required;
	if (required) required.viewport_state = ["LOAD_3D_ADVANCED", {}];
}
var nodeDefPatches = {
	Load3D: enableMeshUpload,
	Load3DAdvanced: addLoad3dAdvancedViewport,
	Preview3D: addPreview3dInput,
	SaveGLB: addPreview3dInput
};
function containsThreeJsNode(graph) {
	return (graph.nodes ?? []).some(({ type }) => typeof type === "string" && isThreeJsNode(type)) || (graph.definitions?.subgraphs ?? []).some(containsThreeJsNode);
}
async function replayNodeCreated(extension, node) {
	try {
		await extension.nodeCreated?.(node, app);
	} catch (cause) {
		reportError(cause, {
			errorType: "error_replaying_3d_node_created",
			surface: "graph",
			context: { extension: extension.name }
		});
	}
}
var load3dLazyExtension = {
	name: "Comfy.Load3DLazy",
	settings: load3dSettings,
	getCustomWidgets: () => load3dWidgets,
	beforeRegisterNodeDef(_nodeType, nodeData) {
		nodeDefPatches[nodeData.name]?.(nodeData);
	},
	async beforeConfigureGraph(graphData) {
		if (containsThreeJsNode(graphData)) await loadLoad3dExtensions();
	},
	async nodeCreated(node) {
		const { comfyClass } = node.constructor;
		if (!comfyClass || !isThreeJsNode(comfyClass)) return;
		const newExtensions = await loadLoad3dExtensions();
		await Promise.all((newExtensions ?? []).map((extension) => replayNodeCreated(extension, node)));
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.load3dLazy = window.comfyAPI.load3dLazy || {};
window.comfyAPI.load3dLazy.load3dLazyExtension = load3dLazyExtension;
//#endregion
//#region src/extensions/core/maskeditor.ts
function openMaskEditor(node) {
	if (!node.imgs?.length && node.previewMediaType !== "image") {
		console.error("[MaskEditor] Node has no images");
		return;
	}
	useMaskEditor().openMaskEditor(node);
}
function openMaskEditorFromClipspace() {
	const node = ComfyApp.clipspace_return_node;
	if (!node) {
		console.error("[MaskEditor] No clipspace_return_node found");
		return;
	}
	openMaskEditor(node);
}
var warnOpenMaskEditorDeprecated = once(() => console.warn("[MaskEditor] ComfyApp.open_maskeditor is deprecated. Plugins should migrate to using the command system or direct node context menu integration."));
function isOpened() {
	return useDialogStore().isDialogOpen("global-mask-editor");
}
var changeBrushSize = async (sizeChanger) => {
	if (!isOpened()) return;
	const store = useMaskEditorStore();
	const oldBrushSize = store.brushSettings.size;
	const newBrushSize = sizeChanger(oldBrushSize);
	store.setBrushSize(newBrushSize);
};
var maskEditorExtension = {
	name: "Comfy.MaskEditor",
	settings: [{
		id: "Comfy.MaskEditor.BrushAdjustmentSpeed",
		category: [
			"Mask Editor",
			"BrushAdjustment",
			"Sensitivity"
		],
		name: "Brush adjustment speed multiplier",
		tooltip: "Controls how quickly the brush size and hardness change when adjusting. Higher values mean faster changes.",
		type: "slider",
		attrs: {
			min: .1,
			max: 2,
			step: .1
		},
		defaultValue: 1,
		versionAdded: "1.0.0"
	}, {
		id: "Comfy.MaskEditor.UseDominantAxis",
		category: [
			"Mask Editor",
			"BrushAdjustment",
			"UseDominantAxis"
		],
		name: "Lock brush adjustment to dominant axis",
		tooltip: "When enabled, brush adjustments will only affect size OR hardness based on which direction you move more",
		type: "boolean",
		defaultValue: true
	}],
	commands: [
		{
			id: "Comfy.MaskEditor.OpenMaskEditor",
			icon: "pi pi-pencil",
			label: "Open Mask Editor for Selected Node",
			function: () => {
				const selectedNodes = selectedCanvasNodes(app.canvas);
				if (selectedNodes.length !== 1) return;
				const [selectedNode] = selectedNodes;
				openMaskEditor(selectedNode);
			}
		},
		{
			id: "Comfy.MaskEditor.BrushSize.Increase",
			icon: "pi pi-plus-circle",
			label: "Increase Brush Size in MaskEditor",
			function: () => changeBrushSize((old) => toolkit.clamp(old + 2, 1, 250))
		},
		{
			id: "Comfy.MaskEditor.BrushSize.Decrease",
			icon: "pi pi-minus-circle",
			label: "Decrease Brush Size in MaskEditor",
			function: () => changeBrushSize((old) => toolkit.clamp(old - 2, 1, 250))
		},
		{
			id: "Comfy.MaskEditor.ColorPicker",
			icon: "pi pi-palette",
			label: "Open Color Picker in MaskEditor",
			function: () => {
				if (!isOpened()) return;
				useMaskEditorStore().colorInput?.click();
			}
		},
		{
			id: "Comfy.MaskEditor.Rotate.Right",
			icon: "pi pi-refresh",
			label: "Rotate Right in MaskEditor",
			function: async () => {
				if (!isOpened()) return;
				await useCanvasTransform().rotateClockwise();
			}
		},
		{
			id: "Comfy.MaskEditor.Rotate.Left",
			icon: "pi pi-undo",
			label: "Rotate Left in MaskEditor",
			function: async () => {
				if (!isOpened()) return;
				await useCanvasTransform().rotateCounterclockwise();
			}
		},
		{
			id: "Comfy.MaskEditor.Mirror.Horizontal",
			icon: "pi pi-arrows-h",
			label: "Mirror Horizontal in MaskEditor",
			function: async () => {
				if (!isOpened()) return;
				await useCanvasTransform().mirrorHorizontal();
			}
		},
		{
			id: "Comfy.MaskEditor.Mirror.Vertical",
			icon: "pi pi-arrows-v",
			label: "Mirror Vertical in MaskEditor",
			function: async () => {
				if (!isOpened()) return;
				await useCanvasTransform().mirrorVertical();
			}
		}
	],
	beforeRegisterNodeDef(nodeType) {
		const original = nodeType.prototype.getExtraMenuOptions;
		nodeType.prototype.getExtraMenuOptions = function(canvas, options) {
			const extra = original?.call(this, canvas, options) ?? [];
			if (ComfyApp.clipspace_return_node || !isImageNode(this)) return extra;
			options.push({
				content: "Open in MaskEditor | Image Canvas",
				callback: markCoreMediaMenuCallback(() => {
					useMaskEditor().openMaskEditor(this);
				}, "preview")
			});
			return extra;
		};
	},
	init() {
		ComfyApp.open_maskeditor = () => {
			warnOpenMaskEditorDeprecated();
			openMaskEditorFromClipspace();
		};
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.maskeditor = window.comfyAPI.maskeditor || {};
window.comfyAPI.maskeditor.maskEditorExtension = maskEditorExtension;
//#endregion
//#region src/extensions/core/noteNode.ts
var noteNodeExtension = {
	name: "Comfy.NoteNode",
	registerCustomNodes() {
		class NoteNode extends LGraphNode {
			static category;
			static collapsable;
			static title_mode;
			groupcolor = LGraphCanvas.node_colors.yellow.groupcolor;
			isVirtualNode;
			constructor(title) {
				super(title);
				this.color = LGraphCanvas.node_colors.yellow.color;
				this.bgcolor = LGraphCanvas.node_colors.yellow.bgcolor;
				ComfyWidgets.STRING(this, "text", ["STRING", {
					default: this.properties.text,
					multiline: true
				}], app);
				this.serialize_widgets = true;
				this.isVirtualNode = true;
			}
		}
		LiteGraph.registerNodeType("Note", Object.assign(NoteNode, {
			title_mode: LiteGraph.NORMAL_TITLE,
			title: "Note",
			collapsable: true
		}));
		NoteNode.category = "utilities";
		/** Markdown variant of NoteNode */
		class MarkdownNoteNode extends LGraphNode {
			static title = "Markdown Note";
			groupcolor = LGraphCanvas.node_colors.yellow.groupcolor;
			constructor(title) {
				super(title);
				this.color = LGraphCanvas.node_colors.yellow.color;
				this.bgcolor = LGraphCanvas.node_colors.yellow.bgcolor;
				ComfyWidgets.MARKDOWN(this, "text", ["STRING", { default: this.properties.text }], app);
				this.serialize_widgets = true;
				this.isVirtualNode = true;
			}
		}
		LiteGraph.registerNodeType("MarkdownNote", MarkdownNoteNode);
		MarkdownNoteNode.category = "utilities";
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.noteNode = window.comfyAPI.noteNode || {};
window.comfyAPI.noteNode.noteNodeExtension = noteNodeExtension;
//#endregion
//#region src/extensions/core/painter.ts
var HIDDEN_WIDGETS = /* @__PURE__ */ new Set([
	"width",
	"height",
	"bg_color"
]);
var painterExtension = {
	name: "Comfy.Painter",
	nodeCreated(node) {
		if (node.constructor.comfyClass !== "Painter") return;
		const [oldWidth, oldHeight] = node.size;
		node.setSize([Math.max(oldWidth, 450), Math.max(oldHeight, 550)]);
		node.hideOutputImages = true;
		for (const widget of node.widgets ?? []) if (HIDDEN_WIDGETS.has(widget.name)) widget.hidden = true;
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.painter = window.comfyAPI.painter || {};
window.comfyAPI.painter.painterExtension = painterExtension;
//#endregion
//#region src/extensions/core/textPreviewWidgets.ts
var PREVIEW_WIDGET_NAME = "preview_text";
var MODE_WIDGET_NAME = "preview_mode";
var inputSpecTextPreview = {
	name: PREVIEW_WIDGET_NAME,
	type: "TEXT_PREVIEW",
	isPreview: true
};
function addTextPreviewWidgets(node) {
	const widgetStore = useWidgetValueStore();
	let fallbackValue = "";
	const previewWidgetId = () => widgetId(resolveNodeRootGraphId(node, app.rootGraph.id), node.id, PREVIEW_WIDGET_NAME);
	const preview = new ComponentWidgetImpl({
		node,
		name: PREVIEW_WIDGET_NAME,
		component: WidgetTextPreview_default,
		inputSpec: inputSpecTextPreview,
		type: "textPreview",
		options: {
			serialize: false,
			hideInPanel: true,
			getMinHeight: () => 60,
			getValue: () => {
				const stored = widgetStore.getWidget(previewWidgetId())?.value;
				return typeof stored === "string" ? stored : fallbackValue;
			},
			setValue: (value) => {
				fallbackValue = typeof value === "string" ? value : "";
				const state = widgetStore.getWidget(previewWidgetId());
				if (state) state.value = fallbackValue;
			}
		}
	});
	preview.serialize = false;
	addWidget(node, preview);
	const modeWidget = ComfyWidgets["BOOLEAN"](node, MODE_WIDGET_NAME, ["BOOLEAN", {
		label_on: "Markdown",
		label_off: "Plain text",
		default: false
	}], app).widget;
	modeWidget.options.serialize = false;
	modeWidget.serialize = false;
}
function toPreviewText(text) {
	if (text == null) return "";
	if (Array.isArray(text)) return text.filter((part) => part != null).join("\n\n");
	return String(text);
}
function updateTextPreviewWidgets(node, message) {
	const preview = node.widgets?.find((w) => w.name === PREVIEW_WIDGET_NAME);
	if (!preview) return;
	preview.value = toPreviewText(message?.text);
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.textPreviewWidgets = window.comfyAPI.textPreviewWidgets || {};
window.comfyAPI.textPreviewWidgets.addTextPreviewWidgets = addTextPreviewWidgets;
window.comfyAPI.textPreviewWidgets.updateTextPreviewWidgets = updateTextPreviewWidgets;
//#endregion
//#region src/extensions/core/previewAny.ts
var previewAnyExtension = {
	name: "Comfy.PreviewAny",
	async beforeRegisterNodeDef(nodeType, nodeData) {
		if (nodeData.name !== "PreviewAny") return;
		const onNodeCreated = nodeType.prototype.onNodeCreated;
		nodeType.prototype.onNodeCreated = function() {
			onNodeCreated?.apply(this, []);
			addTextPreviewWidgets(this);
		};
		const onExecuted = nodeType.prototype.onExecuted;
		nodeType.prototype.onExecuted = function(message) {
			onExecuted?.apply(this, [message]);
			updateTextPreviewWidgets(this, message);
		};
	},
	onNodeOutputsUpdated(nodeOutputs) {
		for (const [nodeLocatorId, output] of Object.entries(nodeOutputs)) {
			const node = getNodeByLocatorId(app.rootGraph, nodeLocatorId);
			if (node?.type === "PreviewAny") updateTextPreviewWidgets(node, output);
		}
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.previewAny = window.comfyAPI.previewAny || {};
window.comfyAPI.previewAny.previewAnyExtension = previewAnyExtension;
//#endregion
//#region src/extensions/core/rerouteNode.ts
var rerouteNodeExtension = {
	name: "Comfy.RerouteNode",
	registerCustomNodes() {
		class RerouteNode extends LGraphNode {
			static category;
			static defaultVisibility = false;
			constructor(title) {
				super(title ?? "");
				this.properties.showOutputText = RerouteNode.defaultVisibility;
				this.properties.horizontal = false;
				this.addInput("", "*");
				this.addOutput(this.properties.showOutputText ? "*" : "", "*");
				this.setSize(this.computeSize());
				this.isVirtualNode = true;
			}
			onAfterGraphConfigured() {
				requestAnimationFrame(() => {
					this.onConnectionsChange(LiteGraph.INPUT, void 0, true);
				});
			}
			clone() {
				const cloned = super.clone();
				if (!cloned) return cloned;
				cloned.removeOutput(0);
				cloned.addOutput(this.properties.showOutputText ? "*" : "", "*");
				cloned.setSize(cloned.computeSize());
				return cloned;
			}
			onConnectionsChange(type, _index, connected) {
				const { graph } = this;
				if (!graph) return;
				if (app.configuringGraph) return;
				if (connected && type === LiteGraph.OUTPUT) {
					const links = outputLinks(graph, this.id, 0);
					if (new Set(links.map((l) => l.type).filter((t) => t && t !== "*")).size > 1) {
						const linksToDisconnect = links.slice(0, -1);
						for (const link of linksToDisconnect) graph.getNodeById(link.target_id)?.disconnectInput(link.target_slot);
					}
				}
				const rootInput = findRootInput(this, graph);
				if (!rootInput) return;
				const { updateNodes, inputNode, inputType } = rootInput;
				const nodes = [this];
				let outputType = null;
				while (nodes.length) {
					const currentNode = nodes.pop();
					for (const link of outputLinks(graph, currentNode.id, 0)) {
						const node = graph.getNodeById(link.target_id);
						if (!node) continue;
						if (node instanceof RerouteNode) {
							nodes.push(node);
							updateNodes.push(node);
						} else {
							const nodeInput = node.inputs[link.target_slot];
							const nodeOutType = nodeInput.type;
							const keep = !inputType || !nodeOutType || LiteGraph.isValidConnection(inputType, nodeOutType);
							if (!keep) {
								node.disconnectInput(link.target_slot);
								continue;
							}
							node.onConnectionsChange?.(LiteGraph.INPUT, link.target_slot, keep, link, nodeInput);
							outputType = node.inputs[link.target_slot].type;
						}
					}
				}
				const displayType = slotTypeKey(inputType || outputType || "*");
				const color = LGraphCanvas.link_type_colors[displayType];
				let widgetConfig;
				let widgetType;
				for (const node of updateNodes) {
					node.outputs[0].type = inputType || "*";
					node.__outputType = displayType;
					node.outputs[0].name = node.properties.showOutputText ? `${displayType}` : "";
					node.setSize(node.computeSize());
					for (const link of outputLinks(graph, node.id, 0)) {
						link.color = color;
						const targetNode = graph.getNodeById(link.target_id);
						if (!targetNode) continue;
						const targetInput = targetNode.inputs.at(link.target_slot);
						if (targetInput?.widget) {
							const config = getWidgetConfig(targetInput);
							if (!widgetConfig) {
								widgetConfig = config[1] ?? {};
								widgetType = config[0];
							}
							const merged = mergeIfValid(targetInput, [config[0], widgetConfig]);
							if (merged.customConfig) widgetConfig = merged.customConfig;
						}
					}
				}
				for (const node of updateNodes) if (widgetConfig && outputType) {
					node.inputs[0].widget = { name: "value" };
					setWidgetConfig(node.inputs[0], [widgetType ?? `${displayType}`, widgetConfig]);
				} else setWidgetConfig(node.inputs[0], void 0);
				const inputNodeLink = inputNode?.getInputLink(0);
				if (inputNodeLink) inputNodeLink.color = color;
			}
			getExtraMenuOptions(_, options) {
				options.unshift({
					content: (this.properties.showOutputText ? "Hide" : "Show") + " Type",
					callback: () => {
						this.properties.showOutputText = !this.properties.showOutputText;
						if (this.properties.showOutputText) this.outputs[0].name = `${this.__outputType || this.outputs[0].type}`;
						else this.outputs[0].name = "";
						this.setSize(this.computeSize());
						app.canvas.setDirty(true, true);
					}
				}, {
					content: (RerouteNode.defaultVisibility ? "Hide" : "Show") + " Type By Default",
					callback: () => {
						RerouteNode.setDefaultTextVisibility(!RerouteNode.defaultVisibility);
					}
				});
				return [];
			}
			computeSize() {
				return [this.properties.showOutputText && this.outputs.length ? Math.max(75, LiteGraph.NODE_TEXT_SIZE * this.outputs[0].name.length * .6 + 40) : 75, 26];
			}
			static setDefaultTextVisibility(visible) {
				RerouteNode.defaultVisibility = visible;
				if (visible) localStorage["Comfy.RerouteNode.DefaultVisibility"] = "true";
				else delete localStorage["Comfy.RerouteNode.DefaultVisibility"];
			}
		}
		RerouteNode.setDefaultTextVisibility(!!localStorage["Comfy.RerouteNode.DefaultVisibility"]);
		function findRootInput(start, graph) {
			const updateNodes = [start];
			let currentNode = start;
			let inputType = null;
			let inputNode = null;
			while (currentNode.isInputConnected(0)) {
				const link = currentNode.getInputLink(0);
				if (!link) return null;
				const node = graph.getNodeById(link.origin_id);
				if (!node) return null;
				if (!(node instanceof RerouteNode)) {
					inputNode = currentNode;
					inputType = node.outputs[link.origin_slot]?.type ?? null;
					break;
				}
				if (node === start) {
					currentNode.disconnectInput(link.target_slot);
					break;
				}
				updateNodes.unshift(node);
				currentNode = node;
			}
			return {
				updateNodes,
				inputNode,
				inputType
			};
		}
		LiteGraph.registerNodeType("Reroute", Object.assign(RerouteNode, {
			title_mode: LiteGraph.NO_TITLE,
			title: "Reroute",
			collapsable: false
		}));
		RerouteNode.category = "utilities";
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.rerouteNode = window.comfyAPI.rerouteNode || {};
window.comfyAPI.rerouteNode.rerouteNodeExtension = rerouteNodeExtension;
//#endregion
//#region src/extensions/core/saveImageExtraOutput.ts
var saveNodeTypes = /* @__PURE__ */ new Set([
	"SaveImage",
	"SaveImageAdvanced",
	"SaveSVGNode",
	"SaveVideo",
	"SaveAnimatedWEBP",
	"SaveWEBM",
	"SaveAudio",
	"SaveAudioMP3",
	"SaveAudioOpus",
	"SaveAudioAdvanced",
	"SaveGLB",
	"Save3DAdvanced",
	"SaveGaussianSplat",
	"SavePointCloud",
	"SaveAnimatedPNG",
	"CLIPSave",
	"VAESave",
	"ModelSave",
	"LoraSave",
	"SaveLatent"
]);
var saveImageExtraOutputExtension = {
	name: "Comfy.SaveImageExtraOutput",
	async beforeRegisterNodeDef(nodeType, nodeData) {
		if (saveNodeTypes.has(nodeData.name)) {
			const onNodeCreated = nodeType.prototype.onNodeCreated;
			nodeType.prototype.onNodeCreated = function() {
				const r = onNodeCreated?.call(this);
				const widget = this.widgets?.find((w) => w.name === "filename_prefix");
				if (!widget) return r;
				widget.serializeValue = () => typeof widget.value === "string" ? applyTextReplacements(app.graph, widget.value) : widget.value;
				return r;
			};
		} else {
			const onNodeCreated = nodeType.prototype.onNodeCreated;
			nodeType.prototype.onNodeCreated = function() {
				const r = onNodeCreated?.call(this);
				if (!("Node name for S&R" in this.properties)) this.addProperty("Node name for S&R", this.constructor.type, "string");
				return r;
			};
		}
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.saveImageExtraOutput = window.comfyAPI.saveImageExtraOutput || {};
window.comfyAPI.saveImageExtraOutput.saveImageExtraOutputExtension = saveImageExtraOutputExtension;
//#endregion
//#region src/extensions/core/saveText.ts
var saveTextExtension = {
	name: "Comfy.saveText",
	async beforeRegisterNodeDef(nodeType, nodeData) {
		if (nodeData.name !== "SaveText") return;
		const onNodeCreated = nodeType.prototype.onNodeCreated;
		nodeType.prototype.onNodeCreated = function() {
			onNodeCreated?.apply(this, []);
			addTextPreviewWidgets(this);
		};
		const onExecuted = nodeType.prototype.onExecuted;
		nodeType.prototype.onExecuted = function(message) {
			onExecuted?.apply(this, [message]);
			updateTextPreviewWidgets(this, message);
		};
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.saveText = window.comfyAPI.saveText || {};
window.comfyAPI.saveText.saveTextExtension = saveTextExtension;
//#endregion
//#region src/extensions/core/selectionBorder.ts
/**
* Draws a dashed border around selected items that maintains constant pixel size
* regardless of zoom level, similar to the DOM selection overlay.
*/
function drawSelectionBorder(ctx, canvas) {
	const selectedItems = canvas.selectedItems;
	if (selectedItems.size <= 1) return;
	const bounds = createBounds(selectedItems, 10);
	if (!bounds) return;
	const [x, y, width, height] = bounds;
	ctx.save();
	ctx.lineWidth = 2 / canvas.ds.scale;
	ctx.strokeStyle = getComputedStyle(document.documentElement).getPropertyValue("--border").trim() || "#ffffff66";
	const dashSize = 5 / canvas.ds.scale;
	ctx.setLineDash([dashSize, dashSize]);
	ctx.beginPath();
	ctx.roundRect(x, y, width, height, 8 / canvas.ds.scale);
	ctx.stroke();
	ctx.restore();
}
/**
* Extension that adds a dashed selection border for multiple selected nodes
*/
var selectionBorderExtension = {
	name: "Comfy.SelectionBorder",
	async init() {
		const originalDrawForeground = app.canvas.onDrawForeground;
		app.canvas.onDrawForeground = function(ctx, visibleArea) {
			originalDrawForeground?.call(this, ctx, visibleArea);
			drawSelectionBorder(ctx, app.canvas);
		};
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.selectionBorder = window.comfyAPI.selectionBorder || {};
window.comfyAPI.selectionBorder.selectionBorderExtension = selectionBorderExtension;
//#endregion
//#region src/extensions/core/simpleTouchSupport.ts
function zoomCanvasAroundPinch(canvas, requestedScale, center, lastTouch) {
	let scale = requestedScale;
	const newX = (center.clientX - lastTouch.clientX) / requestedScale;
	const newY = (center.clientY - lastTouch.clientY) / requestedScale;
	if (scale < canvas.ds.min_scale) scale = canvas.ds.min_scale;
	else if (scale > canvas.ds.max_scale) scale = canvas.ds.max_scale;
	const oldScale = canvas.ds.scale;
	canvas.ds.scale = scale;
	if (Math.abs(canvas.ds.scale - 1) < .01) canvas.ds.scale = 1;
	const newScale = canvas.ds.scale;
	const convertScaleToOffset = (scale) => [center.clientX / scale - canvas.ds.offset[0], center.clientY / scale - canvas.ds.offset[1]];
	const oldCenter = convertScaleToOffset(oldScale);
	const newCenter = convertScaleToOffset(newScale);
	canvas.ds.offset[0] += newX + newCenter[0] - oldCenter[0];
	canvas.ds.offset[1] += newY + newCenter[1] - oldCenter[1];
	lastTouch.clientX = center.clientX;
	lastTouch.clientY = center.clientY;
	canvas.setDirty(true, true);
}
var simpleTouchSupportExtension = {
	name: "Comfy.SimpleTouchSupport",
	setup() {
		let touchDist = null;
		let touchTime = null;
		let lastTouch = null;
		let lastScale = null;
		function getMultiTouchPos(e) {
			return Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
		}
		function getMultiTouchCenter(e) {
			return {
				clientX: (e.touches[0].clientX + e.touches[1].clientX) / 2,
				clientY: (e.touches[0].clientY + e.touches[1].clientY) / 2
			};
		}
		app.canvasEl.parentElement?.addEventListener("touchstart", (e) => {
			touchGesture.count += e.changedTouches.length;
			lastTouch = null;
			lastScale = null;
			if (e.touches.length === 1) {
				touchTime = /* @__PURE__ */ new Date();
				lastTouch = e.touches[0];
			} else {
				touchTime = null;
				if (e.touches.length === 2) {
					const canvas = canvasOrReport("touchstart", e);
					if (!canvas) return;
					lastScale = canvas.ds.scale;
					lastTouch = getMultiTouchCenter(e);
					touchDist = getMultiTouchPos(e);
					canvas.pointer.isDown = false;
				}
			}
		}, true);
		app.canvasEl.parentElement?.addEventListener("touchend", (e) => {
			touchGesture.count -= e.changedTouches.length;
			if (e.touches.length !== 1) touchGesture.zooming = false;
			if (touchTime && !e.touches.length) {
				if ((/* @__PURE__ */ new Date()).getTime() - touchTime.getTime() > 600) {
					if (e.target === app.canvasEl) {
						const touch = {
							button: 2,
							clientX: e.changedTouches[0].clientX,
							clientY: e.changedTouches[0].clientY,
							pointerId: 1,
							isPrimary: true
						};
						app.canvasEl.dispatchEvent(new PointerEvent("pointerdown", touch));
						setTimeout(() => {
							app.canvasEl.dispatchEvent(new PointerEvent("pointerup", touch));
						});
						e.preventDefault();
					}
				}
				touchTime = null;
			}
		});
		const resetTouchState = () => {
			touchGesture.count = 0;
			touchGesture.zooming = false;
			touchTime = null;
			lastTouch = null;
			lastScale = null;
			touchDist = null;
		};
		document.addEventListener("visibilitychange", () => {
			if (document.hidden) resetTouchState();
		});
		app.canvasEl.parentElement?.addEventListener("touchcancel", resetTouchState);
		app.canvasEl.parentElement?.addEventListener("touchmove", (e) => {
			if (touchTime && lastTouch && e.touches.length === 1) {
				const onlyTouch = e.touches[0];
				const deltaX = onlyTouch.clientX - lastTouch.clientX;
				const deltaY = onlyTouch.clientY - lastTouch.clientY;
				if (deltaX * deltaX + deltaY * deltaY > 30) touchTime = null;
			}
			if (e.touches.length === 2 && lastTouch && !e.ctrlKey && !e.shiftKey) {
				const canvas = canvasOrReport("touchmove", e);
				if (!canvas) return;
				e.preventDefault();
				canvas.pointer.isDown = false;
				touchGesture.zooming = true;
				LiteGraph.closeAllContextMenus(window);
				canvas.search_box?.close();
				const newTouchDist = getMultiTouchPos(e);
				const center = getMultiTouchCenter(e);
				if (lastScale === null || touchDist === null) return;
				zoomCanvasAroundPinch(canvas, lastScale * newTouchDist / touchDist, center, lastTouch);
			}
		}, true);
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.simpleTouchSupport = window.comfyAPI.simpleTouchSupport || {};
window.comfyAPI.simpleTouchSupport.simpleTouchSupportExtension = simpleTouchSupportExtension;
//#endregion
//#region src/extensions/core/slotDefaultTypes.ts
/**
* The socket types a node def should be registered under for link-release
* suggestions.
*
* Only required inputs are offered, to keep the menu small, and widget-backed
* types are skipped unless forced to a socket. Dynamic controls are descended
* so a type nested in a DynamicCombo option or an Autogrow template is still
* reachable, matching what node search reports.
*/
function collectRegistrableSlotTypes(nodeData) {
	const defV2 = transformNodeDefV1ToV2(nodeData);
	const inputTypes = /* @__PURE__ */ new Set();
	for (const rootSpec of Object.values(defV2.inputs)) collectInputTypes(rootSpec, inputTypes);
	return {
		inputTypes,
		outputTypes: collectSearchableOutputTypes(defV2.outputs, defV2.inputs, nodeData.output_matchtypes)
	};
}
function collectInputTypes(rootSpec, inputTypes) {
	if (rootSpec.isOptional) return;
	for (const spec of inputSpecTree(rootSpec)) if (!spec.isOptional) addSocketTypes(spec, inputTypes);
}
function addSocketTypes(spec, inputTypes) {
	for (const type of ownSlotTypes(spec)) if (!(type in ComfyWidgets) || spec.forceInput) inputTypes.add(type);
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.slotDefaultTypes = window.comfyAPI.slotDefaultTypes || {};
window.comfyAPI.slotDefaultTypes.collectRegistrableSlotTypes = collectRegistrableSlotTypes;
//#endregion
//#region src/extensions/core/slotDefaults.ts
var slotDefaultsExtension = {
	name: "Comfy.SlotDefaults",
	suggestionsNumber: null,
	init() {
		LiteGraph.search_filter_enabled = true;
		this.suggestionsNumber = app.ui.settings.addSetting({
			id: "Comfy.NodeSuggestions.number",
			category: [
				"Comfy",
				"Node Search Box",
				"NodeSuggestions"
			],
			name: "Number of nodes suggestions",
			tooltip: "Only for litegraph searchbox/context menu",
			type: "slider",
			attrs: {
				min: 1,
				max: 100,
				step: 1
			},
			defaultValue: 5,
			onChange: (newVal) => {
				this.setDefaults(newVal);
			}
		});
	},
	slot_types_default_out: {},
	slot_types_default_in: {},
	async beforeRegisterNodeDef(_nodeType, nodeData) {
		const nodeId = nodeData.name;
		const { inputTypes, outputTypes } = collectRegistrableSlotTypes(nodeData);
		for (const type of inputTypes) {
			if (!(type in this.slot_types_default_out)) this.slot_types_default_out[type] = ["Reroute"];
			if (this.slot_types_default_out[type].includes(nodeId)) continue;
			this.slot_types_default_out[type].push(nodeId);
			const lowerType = type.toLocaleLowerCase();
			if (!(lowerType in LiteGraph.registered_slot_in_types)) LiteGraph.registered_slot_in_types[lowerType] = { nodes: [] };
			LiteGraph.registered_slot_in_types[lowerType].nodes.push(nodeId);
		}
		for (const type of outputTypes) {
			if (!(type in this.slot_types_default_in)) this.slot_types_default_in[type] = ["Reroute"];
			if (this.slot_types_default_in[type].includes(nodeId)) continue;
			this.slot_types_default_in[type].push(nodeId);
			if (!(type in LiteGraph.registered_slot_out_types)) LiteGraph.registered_slot_out_types[type] = { nodes: [] };
			LiteGraph.registered_slot_out_types[type].nodes.push(nodeId);
			if (!LiteGraph.slot_types_out.includes(type)) LiteGraph.slot_types_out.push(type);
		}
		const maxNum = this.suggestionsNumber?.value;
		this.setDefaults(maxNum);
	},
	setDefaults(maxNum) {
		LiteGraph.slot_types_default_out = {};
		LiteGraph.slot_types_default_in = {};
		const max = maxNum ?? void 0;
		for (const type in this.slot_types_default_out) LiteGraph.slot_types_default_out[type] = this.slot_types_default_out[type].slice(0, max);
		for (const type in this.slot_types_default_in) LiteGraph.slot_types_default_in[type] = this.slot_types_default_in[type].slice(0, max);
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.slotDefaults = window.comfyAPI.slotDefaults || {};
window.comfyAPI.slotDefaults.slotDefaultsExtension = slotDefaultsExtension;
//#endregion
//#region src/renderer/extensions/vueNodes/widgets/utils/audioUtils.ts
function getResourceURL(subfolder, filename, type = "input") {
	return `/view?${[
		"filename=" + encodeURIComponent(filename),
		"type=" + type,
		"subfolder=" + subfolder,
		app.getRandParam().substring(1)
	].join("&")}`;
}
function splitFilePath(path) {
	const folder_separator = path.lastIndexOf("/");
	if (folder_separator === -1) return ["", path];
	return [path.substring(0, folder_separator), path.substring(folder_separator + 1)];
}
//#endregion
//#region src/extensions/core/uploadAudio.ts
function updateUIWidget(audioUIWidget, url = "") {
	audioUIWidget.element.src = url;
	audioUIWidget.value = url;
	audioUIWidget.callback?.(url);
	if (url) audioUIWidget.element.classList.remove("empty-audio-widget");
	else audioUIWidget.element.classList.add("empty-audio-widget");
}
function appendWidgetValue(widget, path) {
	const values = widget.options.values;
	if (values && !values.includes(path)) values.push(path);
}
async function uploadFile(node, audioWidget, audioUIWidget, file, updateNode, pasted = false) {
	try {
		const body = new FormData();
		body.append("image", file);
		if (pasted) body.append("subfolder", "pasted");
		const resp = await api.fetchApi("/upload/image", {
			method: "POST",
			body
		});
		if (resp.status === 200) {
			const data = await resp.json();
			const path = data.subfolder ? `${data.subfolder}/${data.name}` : data.name;
			appendWidgetValue(audioWidget, path);
			if (updateNode) {
				const oldValue = audioWidget.value;
				updateUIWidget(audioUIWidget, api.apiURL(getResourceURL(...splitFilePath(path))));
				audioWidget.value = path;
				audioWidget.callback?.(path);
				node.onWidgetChanged?.(audioWidget.name, path, oldValue, audioWidget);
			}
			return true;
		} else {
			useToast().warning(t("g.uploadFailed", { reason: `${resp.status} - ${resp.statusText}` }));
			return false;
		}
	} catch (error) {
		useToast().warning(t("g.uploadFailed", { reason: getErrorMessage(error) ?? t("g.unknownError") }));
		return false;
	}
}
var audioWidgetExtension = {
	name: "Comfy.AudioWidget",
	async beforeRegisterNodeDef(nodeType, nodeData) {
		const comfyClass = nodeType.prototype.comfyClass;
		if (comfyClass && [
			"LoadAudio",
			"SaveAudio",
			"PreviewAudio",
			"SaveAudioMP3",
			"SaveAudioOpus",
			"SaveAudioAdvanced"
		].includes(comfyClass)) {
			const input = nodeData.input ??= {};
			const required = input.required ??= {};
			required.audioUI = ["AUDIO_UI", {}];
		}
	},
	getCustomWidgets() {
		return { AUDIO_UI(node, inputName) {
			const audio = document.createElement("audio");
			audio.controls = true;
			audio.classList.add("comfy-audio");
			audio.setAttribute("name", "media");
			const audioUIWidget = node.addDOMWidget(inputName, "audioUI", audio);
			audioUIWidget.serialize = false;
			audioUIWidget.options.serialize = false;
			const { nodeData } = node.constructor;
			if (nodeData == null) throw new TypeError("nodeData is null");
			if (nodeData.output_node) {
				audioUIWidget.element.classList.add("empty-audio-widget");
				const onExecuted = node.onExecuted;
				node.onExecuted = function(output) {
					onExecuted?.call(this, output);
					const audios = output.audio;
					if (!audios?.length) return;
					const audio = audios[0];
					const resourceUrl = getResourceURL(audio.subfolder ?? "", audio.filename ?? "", audio.type);
					updateUIWidget(audioUIWidget, api.apiURL(resourceUrl));
				};
			}
			audioUIWidget.options.getValue = () => {
				const value = useWidgetValueStore().getWidget(widgetId(resolveNodeRootGraphId(node, app.rootGraph.id), node.id, inputName))?.value;
				return typeof value === "string" ? value : "";
			};
			audioUIWidget.options.setValue = (v) => {
				const graphId = resolveNodeRootGraphId(node, app.rootGraph.id);
				const widgetState = useWidgetValueStore().getWidget(widgetId(graphId, node.id, inputName));
				if (widgetState) widgetState.value = v;
			};
			return { widget: audioUIWidget };
		} };
	},
	onNodeOutputsUpdated(nodeOutputs) {
		for (const [nodeLocatorId, output] of Object.entries(nodeOutputs)) {
			if (!output.audio?.length) continue;
			const node = getNodeByLocatorId(app.rootGraph, nodeLocatorId);
			if (!node) continue;
			const audioUIWidget = node.widgets?.find((w) => w.name === "audioUI");
			const audio = output.audio[0];
			const resourceUrl = getResourceURL(audio.subfolder ?? "", audio.filename ?? "", audio.type);
			updateUIWidget(audioUIWidget, api.apiURL(resourceUrl));
		}
	}
};
var uploadAudioExtension = {
	name: "Comfy.UploadAudio",
	async beforeRegisterNodeDef(_nodeType, nodeData) {
		const required = nodeData.input?.required;
		if (required?.audio?.[1]?.audio_upload === true) required.upload = ["AUDIOUPLOAD", {}];
	},
	getCustomWidgets() {
		return { AUDIOUPLOAD(node, inputName) {
			const audioWidget = node.widgets?.find((w) => w.name === "audio");
			const audioUIWidget = node.widgets?.find((w) => w.name === "audioUI");
			const onAudioWidgetUpdate = () => {
				const value = audioWidget.value;
				const values = audioWidget.options.values;
				const isEmptySentinel = value === "none" && values?.length === 1 && values[0] === value;
				updateUIWidget(audioUIWidget, value && !isEmptySentinel ? api.apiURL(getResourceURL(...splitFilePath(value))) : "");
			};
			onAudioWidgetUpdate();
			audioWidget.callback = onAudioWidgetUpdate;
			const onGraphConfigured = node.onGraphConfigured;
			node.onGraphConfigured = function() {
				onGraphConfigured?.call(this);
				onAudioWidgetUpdate();
			};
			const handleUpload = async (files) => {
				if (!files.length) return files;
				if (node.isUploading) {
					useToast().warning(t("g.uploadAlreadyInProgress"));
					return [];
				}
				node.isUploading = true;
				const previousValue = audioWidget.value;
				audioWidget.value = files[0].name;
				try {
					if (!await uploadFile(node, audioWidget, audioUIWidget, files[0], true)) audioWidget.value = previousValue;
				} finally {
					node.isUploading = false;
					node.graph?.setDirtyCanvas(true);
				}
				return files;
			};
			const isAudioFile = (file) => file.type.startsWith("audio/");
			const { openFileSelection } = useNodeFileInput(node, {
				accept: "audio/*",
				onSelect: handleUpload
			});
			const uploadWidget = node.addWidget("button", inputName, "", openFileSelection, {
				serialize: false,
				surfaces: {
					canvas: "shown",
					vueNode: "never",
					panel: "never"
				}
			});
			uploadWidget.label = t("g.choose_file_to_upload");
			useNodeDragAndDrop(node, {
				fileFilter: isAudioFile,
				onDrop: handleUpload
			});
			useNodePaste(node, {
				fileFilter: isAudioFile,
				onPaste: handleUpload
			});
			node.previewMediaType = "audio";
			return { widget: uploadWidget };
		} };
	}
};
var recordAudioExtension = {
	name: "Comfy.RecordAudio",
	getCustomWidgets() {
		return { AUDIO_RECORD(node, inputName) {
			const audio = document.createElement("audio");
			audio.controls = true;
			audio.classList.add("comfy-audio");
			audio.setAttribute("name", "media");
			const audioUIWidget = node.addDOMWidget(inputName, "audioUI", audio);
			let mediaRecorder = null;
			let isRecording = false;
			let audioChunks = [];
			let currentStream = null;
			let recordWidget = null;
			let stopPromise = null;
			let stopResolve = null;
			const handleRecordingStartFailure = (error) => {
				reportError(error, {
					surface: "assets",
					errorType: "failure_starting_audio_recorder",
					tags: {
						failure_kind: "caught_unexpected",
						feature_area: "assets",
						operation: "execute",
						outcome: "recovered"
					},
					level: "error"
				});
				useToast().warning(t("g.recordingFailedToStart"));
				if (mediaRecorder) try {
					mediaRecorder.stop();
				} catch {}
				mediaRecorder = null;
				useAudioService().stopAllTracks(currentStream);
				currentStream = null;
				isRecording = false;
				if (recordWidget) recordWidget.label = t("g.startRecording");
			};
			audioUIWidget.serializeValue = async () => {
				if (isRecording && mediaRecorder) {
					stopPromise = new Promise((resolve) => {
						stopResolve = resolve;
					});
					mediaRecorder.stop();
					await stopPromise;
				}
				const audioSrc = audioUIWidget.element.src;
				if (!audioSrc) {
					useToast().warning(t("g.noAudioRecorded"));
					return "";
				}
				const blob = await fetch(audioSrc).then((r) => r.blob());
				return await useAudioService().convertBlobToFileAndSubmit(blob);
			};
			recordWidget = node.addWidget("button", inputName, "", async () => {
				if (isRecording) {
					mediaRecorder?.stop();
					return;
				}
				try {
					currentStream = await navigator.mediaDevices.getUserMedia({ audio: true });
				} catch (err) {
					if (err instanceof DOMException && err.name === "NotAllowedError") {
						console.error("Error accessing microphone:", err);
						useToast().warning(t("g.micPermissionDenied"));
						useAudioService().stopAllTracks(currentStream);
						currentStream = null;
					} else handleRecordingStartFailure(err);
					return;
				}
				try {
					mediaRecorder = new mediaRecorderConstructor(currentStream, { mimeType: "audio/wav" });
					audioChunks = [];
					mediaRecorder.ondataavailable = (event) => {
						audioChunks.push(event.data);
					};
					mediaRecorder.onstop = async () => {
						const audioBlob = new Blob(audioChunks, { type: "audio/wav" });
						useAudioService().stopAllTracks(currentStream);
						if (audioUIWidget.element.src && audioUIWidget.element.src.startsWith("blob:")) URL.revokeObjectURL(audioUIWidget.element.src);
						updateUIWidget(audioUIWidget, URL.createObjectURL(audioBlob));
						isRecording = false;
						if (recordWidget) recordWidget.label = t("g.startRecording");
						if (stopResolve) {
							stopResolve();
							stopResolve = null;
							stopPromise = null;
						}
					};
					mediaRecorder.onerror = (event) => {
						console.error("MediaRecorder error:", event);
						useAudioService().stopAllTracks(currentStream);
						isRecording = false;
						if (recordWidget) recordWidget.label = t("g.startRecording");
						if (stopResolve) {
							stopResolve();
							stopResolve = null;
							stopPromise = null;
						}
					};
					mediaRecorder.start();
					isRecording = true;
					if (recordWidget) recordWidget.label = t("g.stopRecording");
				} catch (err) {
					handleRecordingStartFailure(err);
				}
			}, { serialize: false });
			recordWidget.label = t("g.startRecording");
			recordWidget.type = "audiorecord";
			const originalOnRemoved = node.onRemoved;
			node.onRemoved = function() {
				if (isRecording && mediaRecorder) mediaRecorder.stop();
				useAudioService().stopAllTracks(currentStream);
				if (audioUIWidget.element.src.startsWith("blob:")) URL.revokeObjectURL(audioUIWidget.element.src);
				originalOnRemoved?.call(this);
			};
			return { widget: recordWidget };
		} };
	},
	async nodeCreated(node) {
		if (node.constructor.comfyClass !== "RecordAudio") return;
		await useAudioService().registerWavEncoder();
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.uploadAudio = window.comfyAPI.uploadAudio || {};
window.comfyAPI.uploadAudio.audioWidgetExtension = audioWidgetExtension;
window.comfyAPI.uploadAudio.uploadAudioExtension = uploadAudioExtension;
window.comfyAPI.uploadAudio.recordAudioExtension = recordAudioExtension;
//#endregion
//#region src/extensions/core/uploadImage.ts
var createUploadInput = (imageInputName, imageInputOptions) => ["IMAGEUPLOAD", {
	...imageInputOptions[1],
	imageInputName
}];
var uploadImageExtension = {
	name: "Comfy.UploadImage",
	beforeRegisterNodeDef(_nodeType, nodeData) {
		const { input } = nodeData;
		const { required } = input ?? {};
		if (!required) return;
		const found = Object.entries(required).find(([_, input]) => isMediaUploadComboInput(input));
		if (found) {
			const [inputName, inputSpec] = found;
			required.upload = createUploadInput(inputName, inputSpec);
		}
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.uploadImage = window.comfyAPI.uploadImage || {};
window.comfyAPI.uploadImage.uploadImageExtension = uploadImageExtension;
//#endregion
//#region src/extensions/core/webcamCapture.ts
var webcamReady = /* @__PURE__ */ new WeakMap();
var webcamCaptureExtension = {
	name: "Comfy.WebcamCapture",
	getCustomWidgets() {
		return { WEBCAM(node, inputName) {
			let resolveVideo = () => void 0;
			webcamReady.set(node, new Promise((resolve) => resolveVideo = resolve));
			const container = document.createElement("div");
			container.style.background = "rgba(0,0,0,0.25)";
			container.style.textAlign = "center";
			const video = document.createElement("video");
			video.style.height = video.style.width = "100%";
			const loadVideo = async () => {
				try {
					const stream = await navigator.mediaDevices.getUserMedia({
						video: true,
						audio: false
					});
					container.replaceChildren(video);
					setTimeout(() => resolveVideo(video), 500);
					video.addEventListener("loadedmetadata", () => resolveVideo(video), false);
					video.srcObject = stream;
					await video.play();
				} catch (error) {
					const label = document.createElement("div");
					label.style.color = "red";
					label.style.overflow = "auto";
					label.style.maxHeight = "100%";
					label.style.whiteSpace = "pre-wrap";
					const message = error instanceof Error ? error.message : String(error);
					if (window.isSecureContext) label.textContent = "Unable to load webcam, please ensure access is granted:\n" + message;
					else label.textContent = "Unable to load webcam. A secure context is required, if you are not accessing ComfyUI on localhost (127.0.0.1) you will have to enable TLS (https)\n\n" + message;
					container.replaceChildren(label);
				}
			};
			loadVideo();
			return { widget: node.addDOMWidget(inputName, "WEBCAM", container) };
		} };
	},
	nodeCreated(node) {
		if (node.type, node.constructor.comfyClass !== "WebcamCapture") return;
		let video;
		const camera = node.widgets?.find((w) => w.name === "image");
		const w = node.widgets?.find((w) => w.name === "width");
		const h = node.widgets?.find((w) => w.name === "height");
		const captureOnQueue = node.widgets?.find((w) => w.name === "capture_on_queue");
		if (!camera || !w || !h || !captureOnQueue) return;
		const canvas = document.createElement("canvas");
		const nodeOutputStore = useNodeOutputStore();
		const capture = () => {
			if (!video || typeof w.value !== "number" || typeof h.value !== "number") return;
			canvas.width = w.value;
			canvas.height = h.value;
			const ctx = canvas.getContext("2d");
			if (!ctx) return;
			ctx.drawImage(video, 0, 0, w.value, h.value);
			const data = canvas.toDataURL("image/png");
			const img = new Image();
			img.onload = () => {
				node.imgs = [img];
				nodeOutputStore.setNodePreviewsByNodeId(node.id, [data]);
				app.canvas.setDirty(true);
			};
			img.src = data;
		};
		const btn = node.addWidget("button", "waiting for camera...", "capture", capture, {});
		btn.disabled = true;
		btn.serializeValue = () => void 0;
		camera.serializeValue = async () => {
			if (captureOnQueue.value) capture();
			else if (!node.imgs?.length) {
				useToast().warning(t("toastMessages.noWebcamImageCaptured"));
				throw new Error("No webcam image captured");
			}
			const blob = await new Promise((resolve, reject) => canvas.toBlob((blob) => blob ? resolve(blob) : reject(/* @__PURE__ */ new Error("Failed to capture webcam"))));
			const name = `${+/* @__PURE__ */ new Date()}.png`;
			const file = new File([blob], name);
			const upload = await uploadTempFile(file, "webcam");
			if (!upload.ok) throw new Error(`Error uploading camera image: ${upload.reason}`);
			const data = upload.file;
			const serverName = data.name || name;
			return `${data.subfolder || "webcam"}/${serverName} [${data.type || "temp"}]`;
		};
		const ready = webcamReady.get(node);
		if (!ready) return;
		ready.then((v) => {
			video = v;
			if (typeof w.value !== "number" || !w.value) {
				w.value = video.videoWidth || 640;
				h.value = video.videoHeight || 480;
			}
			btn.disabled = false;
			btn.label = t("g.capture");
		});
	}
};
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.webcamCapture = window.comfyAPI.webcamCapture || {};
window.comfyAPI.webcamCapture.webcamCaptureExtension = webcamCaptureExtension;
//#endregion
//#region src/extensions/core/index.ts
var baseCoreExtensions = [
	clipspaceExtension,
	contextMenuFilterExtension,
	createBoundingBoxesExtension,
	customWidgetsExtension,
	dynamicPromptsExtension,
	editAttentionExtension,
	widgetInputsExtension,
	groupNodeExtension,
	groupOptionsExtension,
	imageCompareExtension,
	imageCompositorExtension,
	imageCropExtension,
	layerEditorExtension,
	load3dLazyExtension,
	maskEditorExtension,
	noteNodeExtension,
	painterExtension,
	previewAnyExtension,
	saveTextExtension,
	rerouteNodeExtension,
	saveImageExtraOutputExtension,
	selectionBorderExtension,
	simpleTouchSupportExtension,
	slotDefaultsExtension,
	audioWidgetExtension,
	uploadAudioExtension,
	recordAudioExtension,
	uploadImageExtension,
	webcamCaptureExtension
];
var disposers = [];
var registration;
function register(extension) {
	disposers.push(useExtensionService().registerExtension(extension));
}
async function registerInOrder() {
	baseCoreExtensions.forEach(register);
	register((await __vitePreload(async () => {
		const { nodeTemplatesExtension } = await import("./nodeTemplates-gKVQFylq.js");
		return { nodeTemplatesExtension };
	}, __vite__mapDeps([187,1,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,51,52,36,53,46,49,50,40,41,42,43,44,45,54,55,38,56,57,58,59,60,64,63,116,69,117,35,37,39,118,48,105,47,61,62,106,99,100,90,119,2,102,120,121,103,122,65,123,104,85,124,125,92,93,94,95,96,97,98,101,126,127,128,129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,91,107,108,109,110,161,162,163,164,165,166,167,86,188]), import.meta.url)).nodeTemplatesExtension);
	await registerElectronAdapterExtension();
	const { registerAgentPanelExtension } = await __vitePreload(async () => {
		const { registerAgentPanelExtension } = await import("./agentPanel-_EpIazfo.js");
		return { registerAgentPanelExtension };
	}, __vite__mapDeps([189,1,49,50,6,5,40,41,8,10,13,14,42,43,44,24,25,11,45,46,15,16,17,18,19,20,21,22,26,23,27,28,92,31,61,56,90,93,94,95,96,97,98,7,47,3,4,9,12,29,30,32,33,34,48,36,51,52,53,54,55,38,57,58,59,60,37,62,106,35,39,99,100,136,126,127,128,129,116,69,117,118,105,119,2,63,64,102,120,121,103,122,65,123,104,85,124,125,101,130,131,132,133,134,135,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,91,107,108,109,110,161,162,163,164,165,166,167,86,190,191,192,193,194,195,196,197]), import.meta.url);
	registerAgentPanelExtension();
}
/**
* Registers the core extensions in their fixed order. Later calls return the
* first call's promise.
*/
function registerCoreExtensions() {
	registration ??= registerInOrder();
	return registration;
}
window.comfyAPI = window.comfyAPI || {};
window.comfyAPI.index = window.comfyAPI.index || {};
window.comfyAPI.index.registerCoreExtensions = registerCoreExtensions;
//#endregion
export { registerCoreExtensions };
