import "./rolldown-runtime-xtsTai4I.js";
import { $ as mergeModels, F as createBaseVNode, G as defineComponent, I as createBlock, Kt as normalizeClass, L as createCommentVNode, R as createElementBlock, Wt as unref, _t as useModel, ct as openBlock, dt as renderSlot, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { i as cva, t as Button_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
//#region src/components/ui/message/message.variants.ts
var messageVariants = cva({
	base: "flex w-full items-start gap-2 rounded-lg border px-3 py-2.75 text-sm",
	variants: { severity: {
		error: "border-destructive/40 bg-destructive/10 text-foreground",
		warning: "border-warning/50 bg-warning/15 text-foreground",
		info: "border-primary/40 bg-primary/10 text-foreground",
		success: "border-success/50 bg-success/15 text-foreground",
		secondary: "border-border/50 bg-secondary text-foreground"
	} },
	defaultVariants: { severity: "info" }
});
//#endregion
//#region src/components/ui/message/Message.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = {
	key: 0,
	class: "shrink-0",
	"aria-hidden": "true"
};
var _hoisted_2 = { class: "min-w-0 flex-1" };
//#endregion
//#region src/components/ui/message/Message.vue
var Message_default = /* @__PURE__ */ defineComponent({
	__name: "Message",
	props: /*@__PURE__*/ mergeModels({
		severity: {},
		class: {
			type: [
				Boolean,
				null,
				String,
				Object,
				Array
			],
			default: ""
		},
		closable: { type: Boolean },
		closeLabel: {}
	}, {
		"visible": {
			type: Boolean,
			default: true
		},
		"visibleModifiers": {}
	}),
	emits: /*@__PURE__*/ mergeModels(["close"], ["update:visible"]),
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const visible = useModel(__props, "visible");
		function close(event) {
			visible.value = false;
			emit("close", event);
		}
		return (_ctx, _cache) => {
			return visible.value ? (openBlock(), createElementBlock("div", {
				key: 0,
				role: "alert",
				"aria-live": "assertive",
				"aria-atomic": "true",
				class: normalizeClass(unref(cn)(unref(messageVariants)({ severity: __props.severity }), __props.class))
			}, [
				_ctx.$slots.icon ? (openBlock(), createElementBlock("span", _hoisted_1, [renderSlot(_ctx.$slots, "icon")])) : createCommentVNode("", true),
				createBaseVNode("div", _hoisted_2, [renderSlot(_ctx.$slots, "default")]),
				__props.closable ? (openBlock(), createBlock(Button_default, {
					key: 1,
					type: "button",
					variant: "textonly",
					size: "unset",
					class: "size-6 shrink-0 p-0 text-current",
					"aria-label": __props.closeLabel,
					onClick: close
				}, {
					default: withCtx(() => [..._cache[0] || (_cache[0] = [createBaseVNode("i", {
						class: "icon-[lucide--x] size-4",
						"aria-hidden": "true"
					}, null, -1)])]),
					_: 1
				}, 8, ["aria-label"])) : createCommentVNode("", true)
			], 2)) : createCommentVNode("", true);
		};
	}
});
//#endregion
export { Message_default as t };
