import { r as __name, t as __commonJSMin } from "./rolldown-runtime-xtsTai4I.js";
import { n as uploadTempFile } from "./Load3dUtils-CF3OvEZx.js";
//#endregion
//#region node_modules/.pnpm/broker-factory@3.1.15/node_modules/broker-factory/build/es2019/factories/create-broker.js
var import_bundle$2 = (/* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(global, factory) {
		typeof exports === "object" && typeof module !== "undefined" ? factory(exports) : typeof define === "function" && define.amd ? define(["exports"], factory) : (global = typeof globalThis !== "undefined" ? globalThis : global || self, factory(global.fastUniqueNumbers = {}));
	})(exports, (function(exports$3) {
		"use strict";
		var createAddUniqueNumber = function createAddUniqueNumber(generateUniqueNumber) {
			return function(set) {
				var number = generateUniqueNumber(set);
				set.add(number);
				return number;
			};
		};
		var createCache = function createCache(lastNumberWeakMap) {
			return function(collection, nextNumber) {
				lastNumberWeakMap.set(collection, nextNumber);
				return nextNumber;
			};
		};
		var MAX_SAFE_INTEGER = Number.MAX_SAFE_INTEGER === void 0 ? 9007199254740991 : Number.MAX_SAFE_INTEGER;
		var TWO_TO_THE_POWER_OF_TWENTY_NINE = 536870912;
		var TWO_TO_THE_POWER_OF_THIRTY = TWO_TO_THE_POWER_OF_TWENTY_NINE * 2;
		var createGenerateUniqueNumber = function createGenerateUniqueNumber(cache, lastNumberWeakMap) {
			return function(collection) {
				var lastNumber = lastNumberWeakMap.get(collection);
				var nextNumber = lastNumber === void 0 ? collection.size : lastNumber < TWO_TO_THE_POWER_OF_THIRTY ? lastNumber + 1 : 0;
				if (!collection.has(nextNumber)) return cache(collection, nextNumber);
				if (collection.size < TWO_TO_THE_POWER_OF_TWENTY_NINE) {
					while (collection.has(nextNumber)) nextNumber = Math.floor(Math.random() * TWO_TO_THE_POWER_OF_THIRTY);
					return cache(collection, nextNumber);
				}
				if (collection.size > MAX_SAFE_INTEGER) throw new Error("Congratulations, you created a collection of unique numbers which uses all available integers!");
				while (collection.has(nextNumber)) nextNumber = Math.floor(Math.random() * MAX_SAFE_INTEGER);
				return cache(collection, nextNumber);
			};
		};
		var LAST_NUMBER_WEAK_MAP = /* @__PURE__ */ new WeakMap();
		var generateUniqueNumber = createGenerateUniqueNumber(createCache(LAST_NUMBER_WEAK_MAP), LAST_NUMBER_WEAK_MAP);
		exports$3.addUniqueNumber = createAddUniqueNumber(generateUniqueNumber);
		exports$3.generateUniqueNumber = generateUniqueNumber;
	}));
})))();
var createBrokerFactory = (createOrGetOngoingRequests, extendBrokerImplementation, generateUniqueNumber, isMessagePort) => (brokerImplementation) => {
	const fullBrokerImplementation = extendBrokerImplementation(brokerImplementation);
	return (sender) => {
		const ongoingRequests = createOrGetOngoingRequests(sender);
		sender.addEventListener("message", (({ data: message }) => {
			const { id } = message;
			if (id !== null && ongoingRequests.has(id)) {
				const { reject, resolve } = ongoingRequests.get(id);
				ongoingRequests.delete(id);
				if (message.error === void 0) resolve(message.result);
				else reject(new Error(message.error.message));
			}
		}));
		if (isMessagePort(sender)) sender.start();
		const call = (method, params = null, transferables = []) => {
			return new Promise((resolve, reject) => {
				const id = generateUniqueNumber(ongoingRequests);
				ongoingRequests.set(id, {
					reject,
					resolve
				});
				if (params === null) sender.postMessage({
					id,
					method
				}, transferables);
				else sender.postMessage({
					id,
					method,
					params
				}, transferables);
			});
		};
		const notify = (method, params, transferables = []) => {
			sender.postMessage({
				id: null,
				method,
				params
			}, transferables);
		};
		let functions = {};
		for (const [key, handler] of Object.entries(fullBrokerImplementation)) functions = {
			...functions,
			[key]: handler({
				call,
				notify
			})
		};
		return { ...functions };
	};
};
//#endregion
//#region node_modules/.pnpm/broker-factory@3.1.15/node_modules/broker-factory/build/es2019/factories/create-or-get-ongoing-requests.js
var createCreateOrGetOngoingRequests = (ongoingRequestsMap) => (sender) => {
	if (ongoingRequestsMap.has(sender)) return ongoingRequestsMap.get(sender);
	const ongoingRequests = /* @__PURE__ */ new Map();
	ongoingRequestsMap.set(sender, ongoingRequests);
	return ongoingRequests;
};
//#endregion
//#region node_modules/.pnpm/broker-factory@3.1.15/node_modules/broker-factory/build/es2019/factories/extend-broker-implementation.js
var createExtendBrokerImplementation = (portMap) => (partialBrokerImplementation) => ({
	...partialBrokerImplementation,
	connect: ({ call }) => {
		return async () => {
			const { port1, port2 } = new MessageChannel();
			const portId = await call("connect", { port: port1 }, [port1]);
			portMap.set(port2, portId);
			return port2;
		};
	},
	disconnect: ({ call }) => {
		return async (port) => {
			const portId = portMap.get(port);
			if (portId === void 0) throw new Error("The given port is not connected.");
			await call("disconnect", { portId });
		};
	},
	isSupported: ({ call }) => {
		return () => call("isSupported");
	}
});
//#endregion
//#region node_modules/.pnpm/broker-factory@3.1.15/node_modules/broker-factory/build/es2019/guards/message-port.js
var isMessagePort = (sender) => {
	return typeof sender.start === "function";
};
//#endregion
//#region node_modules/.pnpm/broker-factory@3.1.15/node_modules/broker-factory/build/es2019/module.js
var createBroker = createBrokerFactory(createCreateOrGetOngoingRequests(/* @__PURE__ */ new WeakMap()), createExtendBrokerImplementation(/* @__PURE__ */ new WeakMap()), import_bundle$2.generateUniqueNumber, isMessagePort);
//#endregion
//#region node_modules/.pnpm/media-encoder-host-broker@8.0.29/node_modules/media-encoder-host-broker/build/es2019/module.js
var encoderIds = /* @__PURE__ */ new Set();
var encoderInstanceIds = /* @__PURE__ */ new Set();
var messagePorts = /* @__PURE__ */ new WeakMap();
var wrap$1 = createBroker({
	deregister: ({ call }) => {
		return async (port) => {
			const encoderId = messagePorts.get(port);
			if (encoderId === void 0) throw new Error("There is no encoder registered with the given port.");
			const result = await call("deregister", { encoderId });
			encoderIds.delete(encoderId);
			messagePorts.delete(port);
			return result;
		};
	},
	encode: ({ call }) => {
		return async (encoderInstanceId, timeslice) => {
			const arrayBuffers = await call("encode", {
				encoderInstanceId,
				timeslice
			});
			encoderInstanceIds.delete(encoderInstanceId);
			return arrayBuffers;
		};
	},
	instantiate: ({ call }) => {
		return async (mimeType, sampleRate) => {
			const encoderInstanceId = (0, import_bundle$2.addUniqueNumber)(encoderInstanceIds);
			return {
				encoderInstanceId,
				port: await call("instantiate", {
					encoderInstanceId,
					mimeType,
					sampleRate
				})
			};
		};
	},
	register: ({ call }) => {
		return async (port) => {
			if (messagePorts.has(port)) throw new Error("");
			const encoderId = (0, import_bundle$2.addUniqueNumber)(encoderIds);
			messagePorts.set(port, encoderId);
			try {
				return await call("register", {
					encoderId,
					port
				}, [port]);
			} catch (err) {
				encoderIds.delete(encoderId);
				messagePorts.delete(port);
				throw err;
			}
		};
	}
});
var load$1 = /* @__PURE__ */ __name((url) => {
	return wrap$1(new Worker(url));
}, "load");
//#endregion
//#region node_modules/.pnpm/media-encoder-host@9.0.30/node_modules/media-encoder-host/build/es2019/module.js
var blob$1 = new Blob([`(()=>{var e={455(e,t){!function(e){"use strict";var t=function(e){return function(t){var r=e(t);return t.add(r),r}},r=function(e){return function(t,r){return e.set(t,r),r}},n=void 0===Number.MAX_SAFE_INTEGER?9007199254740991:Number.MAX_SAFE_INTEGER,o=536870912,s=2*o,a=function(e,t){return function(r){var a=t.get(r),c=void 0===a?r.size:a<s?a+1:0;if(!r.has(c))return e(r,c);if(r.size<o){for(;r.has(c);)c=Math.floor(Math.random()*s);return e(r,c)}if(r.size>n)throw new Error("Congratulations, you created a collection of unique numbers which uses all available integers!");for(;r.has(c);)c=Math.floor(Math.random()*n);return e(r,c)}},c=new WeakMap,i=r(c),d=a(i,c),l=t(d);e.addUniqueNumber=l,e.generateUniqueNumber=d}(t)}},t={};function r(n){var o=t[n];if(void 0!==o)return o.exports;var s=t[n]={exports:{}};return e[n].call(s.exports,s,s.exports,r),s.exports}(()=>{"use strict";var e=r(455);const t=((e,t,r,n)=>o=>{const s=t(o);return t=>{const o=e(t);t.addEventListener("message",({data:e})=>{const{id:t}=e;if(null!==t&&o.has(t)){const{reject:r,resolve:n}=o.get(t);o.delete(t),void 0===e.error?n(e.result):r(new Error(e.error.message))}}),n(t)&&t.start();const a=(e,n=null,s=[])=>new Promise((a,c)=>{const i=r(o);o.set(i,{reject:c,resolve:a}),null===n?t.postMessage({id:i,method:e},s):t.postMessage({id:i,method:e,params:n},s)}),c=(e,r,n=[])=>{t.postMessage({id:null,method:e,params:r},n)};let i={};for(const[e,t]of Object.entries(s))i={...i,[e]:t({call:a,notify:c})};return{...i}}})((o=new WeakMap,e=>{if(o.has(e))return o.get(e);const t=new Map;return o.set(e,t),t}),(n=new WeakMap,e=>({...e,connect:({call:e})=>async()=>{const{port1:t,port2:r}=new MessageChannel,o=await e("connect",{port:t},[t]);return n.set(r,o),r},disconnect:({call:e})=>async t=>{const r=n.get(t);if(void 0===r)throw new Error("The given port is not connected.");await e("disconnect",{portId:r})},isSupported:({call:e})=>()=>e("isSupported")})),e.generateUniqueNumber,e=>"function"==typeof e.start);var n,o;const s=t({characterize:({call:e})=>()=>e("characterize"),encode:({call:e})=>(t,r)=>e("encode",{recordingId:t,timeslice:r}),record:({call:e})=>async(t,r,n)=>{await e("record",{recordingId:t,sampleRate:r,typedArrays:n},n.map(({buffer:e})=>e).filter(e=>e instanceof ArrayBuffer))}}),a=-32603,c=-32602,i=-32601,d=(e,t)=>Object.assign(new Error(e),{status:t}),l=e=>d('The handler of the method called "'.concat(e,'" returned an unexpected result.'),a),u=(e,t)=>async({data:{id:r,method:n,params:o}})=>{const s=t[n];try{if(void 0===s)throw(e=>d('The requested method called "'.concat(e,'" is not supported.'),i))(n);const t=void 0===o?s():s(o);if(void 0===t)throw(e=>d('The handler of the method called "'.concat(e,'" returned no required result.'),a))(n);const c=t instanceof Promise?await t:t;if(null===r){if(void 0!==c.result)throw l(n)}else{if(void 0===c.result)throw l(n);const{result:t,transferables:o=[]}=c;e.postMessage({id:r,result:t},o)}}catch(t){const{message:n,status:o=-32603}=t;e.postMessage({error:{code:o,message:n},id:r})}},h=new Map,f=(t,r,n)=>({...r,connect:({port:n})=>{n.start();const o=t(n,r),s=(0,e.generateUniqueNumber)(h);return h.set(s,()=>{o(),n.close(),h.delete(s)}),{result:s}},disconnect:({portId:e})=>{const t=h.get(e);if(void 0===t)throw(e=>d('The specified parameter called "portId" with the given value "'.concat(e,'" does not identify a port connected to this worker.'),c))(e);return t(),{result:null}},isSupported:async()=>{if(await new Promise(e=>{const t=new ArrayBuffer(0),{port1:r,port2:n}=new MessageChannel;r.onmessage=({data:t})=>e(null!==t),n.postMessage(t,[t])})){const e=n();return{result:e instanceof Promise?await e:e}}return{result:!1}}}),w=(e,t,r=()=>!0)=>{const n=f(w,t,r),o=u(e,n);return e.addEventListener("message",o),()=>e.removeEventListener("message",o)},p=e=>{e.onmessage=null,e.close()},m=new Map,g=new Map,v=((e,t)=>r=>{const n=t.get(r);if(void 0===n)throw new Error("There was no encoder stored with the given id.");e.delete(n),t.delete(r)})(m,g),y=new Map,M=(e=>t=>{const r=e.get(t);if(void 0===r)throw new Error("There was no instance of an encoder stored with the given id.");return r})(y),E=((e,t)=>r=>{const n=t(r);return e.delete(r),n})(y,M),b=((e,t)=>r=>{const[n,o,s,a]=t(r);return s?new Promise(t=>{o.onmessage=({data:s})=>{0===s.length?(e(o),t(n.encode(r,null))):n.record(r,a,s)}}):n.encode(r,null)})(p,E),T=(e=>t=>{for(const[r,n]of Array.from(e.values()))if(r.test(t))return n;throw new Error("There is no encoder registered which could handle the given mimeType.")})(m),I=((e,t,r)=>(n,o,s)=>{if(t.has(n))throw new Error('There is already an encoder instance registered with an id called "'.concat(n,'".'));const a=r(o),{port1:c,port2:i}=new MessageChannel,d=[a,c,!0,s];return t.set(n,d),c.onmessage=({data:t})=>{0===t.length?(e(c),d[2]=!1):a.record(n,s,t.map(e=>"number"==typeof e?new Float32Array(e):e))},i})(p,y,T),A=((e,t,r)=>async(n,o)=>{const s=r(o),a=await s.characterize(),c=a.toString();if(e.has(c))throw new Error("There is already an encoder stored which handles exactly the same mime types.");if(t.has(n))throw new Error('There is already an encoder registered with an id called "'.concat(n,'".'));return e.set(c,[a,s]),t.set(n,c),a})(m,g,s),N=(e=>(t,r)=>{const[n]=e(t);return n.encode(t,r)})(M);w(self,{deregister:async({encoderId:e})=>(v(e),{result:null}),encode:async({encoderInstanceId:e,timeslice:t})=>{const r=null===t?await b(e):await N(e,t);return{result:r,transferables:r}},instantiate:({encoderInstanceId:e,mimeType:t,sampleRate:r})=>{const n=I(e,t,r);return{result:n,transferables:[n]}},register:async({encoderId:e,port:t})=>({result:await A(e,t)})})})()})();`], { type: "application/javascript; charset=utf-8" });
var url$1 = URL.createObjectURL(blob$1);
var mediaEncoderHost = load$1(url$1);
mediaEncoderHost.connect;
mediaEncoderHost.deregister;
mediaEncoderHost.disconnect;
var encode$1 = mediaEncoderHost.encode;
var instantiate = mediaEncoderHost.instantiate;
mediaEncoderHost.isSupported;
var register$1 = mediaEncoderHost.register;
URL.revokeObjectURL(url$1);
//#endregion
//#region node_modules/.pnpm/extendable-media-recorder@9.2.38/node_modules/extendable-media-recorder/build/es2019/factories/blob-event-factory.js
var createBlobEventFactory = (nativeBlobEventConstructor) => {
	return (type, blobEventInit) => {
		if (nativeBlobEventConstructor === null) throw new Error("A native BlobEvent could not be created.");
		return new nativeBlobEventConstructor(type, blobEventInit);
	};
};
//#endregion
//#region node_modules/.pnpm/extendable-media-recorder@9.2.38/node_modules/extendable-media-recorder/build/es2019/factories/decode-web-m-chunk.js
var createDecodeWebMChunk = (readElementContent, readElementType) => {
	return (dataView, elementType, channelCount) => {
		const contents = [];
		let currentElementType = elementType;
		let offset = 0;
		while (offset < dataView.byteLength) if (currentElementType === null) {
			const lengthAndType = readElementType(dataView, offset);
			if (lengthAndType === null) break;
			const { length, type } = lengthAndType;
			currentElementType = type;
			offset += length;
		} else {
			const contentAndLength = readElementContent(dataView, offset, currentElementType, channelCount);
			if (contentAndLength === null) break;
			const { content, length } = contentAndLength;
			currentElementType = null;
			offset += length;
			if (content !== null) contents.push(content);
		}
		return {
			contents,
			currentElementType,
			offset
		};
	};
};
//#endregion
//#region node_modules/.pnpm/extendable-media-recorder@9.2.38/node_modules/extendable-media-recorder/build/es2019/factories/event-target-constructor.js
var createEventTargetConstructor$1 = /* @__PURE__ */ __name((createEventTarget, wrapEventListener) => {
	return class EventTarget {
		constructor(nativeEventTarget = null) {
			this._listeners = /* @__PURE__ */ new WeakMap();
			this._nativeEventTarget = nativeEventTarget === null ? createEventTarget() : nativeEventTarget;
		}
		addEventListener(type, listener, options) {
			if (listener !== null) {
				let wrappedEventListener = this._listeners.get(listener);
				if (wrappedEventListener === void 0) {
					wrappedEventListener = wrapEventListener(this, listener);
					if (typeof listener === "function") this._listeners.set(listener, wrappedEventListener);
				}
				this._nativeEventTarget.addEventListener(type, wrappedEventListener, options);
			}
		}
		dispatchEvent(event) {
			return this._nativeEventTarget.dispatchEvent(event);
		}
		removeEventListener(type, listener, options) {
			const wrappedEventListener = listener === null ? void 0 : this._listeners.get(listener);
			this._nativeEventTarget.removeEventListener(type, wrappedEventListener === void 0 ? null : wrappedEventListener, options);
		}
	};
}, "createEventTargetConstructor");
//#endregion
//#region node_modules/.pnpm/extendable-media-recorder@9.2.38/node_modules/extendable-media-recorder/build/es2019/factories/event-target-factory.js
var createEventTargetFactory = (window) => {
	return () => {
		if (window === null) throw new Error("A native EventTarget could not be created.");
		return window.document.createElement("p");
	};
};
//#endregion
//#region node_modules/.pnpm/extendable-media-recorder@9.2.38/node_modules/extendable-media-recorder/build/es2019/factories/invalid-modification-error.js
var createInvalidModificationError = (message = "") => {
	try {
		return new DOMException(message, "InvalidModificationError");
	} catch (err) {
		err.code = 13;
		err.message = message;
		err.name = "InvalidModificationError";
		return err;
	}
};
//#endregion
//#region node_modules/.pnpm/extendable-media-recorder@9.2.38/node_modules/extendable-media-recorder/build/es2019/factories/invalid-state-error.js
var createInvalidStateError$1 = /* @__PURE__ */ __name(() => {
	try {
		return new DOMException("", "InvalidStateError");
	} catch (err) {
		err.code = 11;
		err.name = "InvalidStateError";
		return err;
	}
}, "createInvalidStateError");
//#endregion
//#region node_modules/.pnpm/extendable-media-recorder@9.2.38/node_modules/extendable-media-recorder/build/es2019/factories/media-recorder-constructor.js
var createMediaRecorderConstructor = (createNativeMediaRecorder, createNotSupportedError, createWebAudioMediaRecorder, createWebmPcmMediaRecorder, encoderRegexes, eventTargetConstructor, nativeMediaRecorderConstructor) => {
	return class MediaRecorder extends eventTargetConstructor {
		constructor(stream, options = {}) {
			const { mimeType } = options;
			if (nativeMediaRecorderConstructor !== null && (mimeType === void 0 || nativeMediaRecorderConstructor.isTypeSupported !== void 0 && nativeMediaRecorderConstructor.isTypeSupported(mimeType))) {
				const internalMediaRecorder = createNativeMediaRecorder(nativeMediaRecorderConstructor, stream, options);
				super(internalMediaRecorder);
				this._internalMediaRecorder = internalMediaRecorder;
			} else if (mimeType !== void 0 && encoderRegexes.some((regex) => regex.test(mimeType))) {
				super();
				if (nativeMediaRecorderConstructor !== null && nativeMediaRecorderConstructor.isTypeSupported !== void 0 && nativeMediaRecorderConstructor.isTypeSupported("audio/webm; codecs=pcm")) this._internalMediaRecorder = createWebmPcmMediaRecorder(this, nativeMediaRecorderConstructor, stream, mimeType);
				else this._internalMediaRecorder = createWebAudioMediaRecorder(this, stream, mimeType);
			} else {
				if (nativeMediaRecorderConstructor !== null) createNativeMediaRecorder(nativeMediaRecorderConstructor, stream, options);
				throw createNotSupportedError();
			}
			this._ondataavailable = null;
			this._onerror = null;
			this._onpause = null;
			this._onresume = null;
			this._onstart = null;
			this._onstop = null;
		}
		get mimeType() {
			return this._internalMediaRecorder.mimeType;
		}
		get ondataavailable() {
			return this._ondataavailable === null ? this._ondataavailable : this._ondataavailable[0];
		}
		set ondataavailable(value) {
			if (this._ondataavailable !== null) this.removeEventListener("dataavailable", this._ondataavailable[1]);
			if (typeof value === "function") {
				const boundListener = value.bind(this);
				this.addEventListener("dataavailable", boundListener);
				this._ondataavailable = [value, boundListener];
			} else this._ondataavailable = null;
		}
		get onerror() {
			return this._onerror === null ? this._onerror : this._onerror[0];
		}
		set onerror(value) {
			if (this._onerror !== null) this.removeEventListener("error", this._onerror[1]);
			if (typeof value === "function") {
				const boundListener = value.bind(this);
				this.addEventListener("error", boundListener);
				this._onerror = [value, boundListener];
			} else this._onerror = null;
		}
		get onpause() {
			return this._onpause === null ? this._onpause : this._onpause[0];
		}
		set onpause(value) {
			if (this._onpause !== null) this.removeEventListener("pause", this._onpause[1]);
			if (typeof value === "function") {
				const boundListener = value.bind(this);
				this.addEventListener("pause", boundListener);
				this._onpause = [value, boundListener];
			} else this._onpause = null;
		}
		get onresume() {
			return this._onresume === null ? this._onresume : this._onresume[0];
		}
		set onresume(value) {
			if (this._onresume !== null) this.removeEventListener("resume", this._onresume[1]);
			if (typeof value === "function") {
				const boundListener = value.bind(this);
				this.addEventListener("resume", boundListener);
				this._onresume = [value, boundListener];
			} else this._onresume = null;
		}
		get onstart() {
			return this._onstart === null ? this._onstart : this._onstart[0];
		}
		set onstart(value) {
			if (this._onstart !== null) this.removeEventListener("start", this._onstart[1]);
			if (typeof value === "function") {
				const boundListener = value.bind(this);
				this.addEventListener("start", boundListener);
				this._onstart = [value, boundListener];
			} else this._onstart = null;
		}
		get onstop() {
			return this._onstop === null ? this._onstop : this._onstop[0];
		}
		set onstop(value) {
			if (this._onstop !== null) this.removeEventListener("stop", this._onstop[1]);
			if (typeof value === "function") {
				const boundListener = value.bind(this);
				this.addEventListener("stop", boundListener);
				this._onstop = [value, boundListener];
			} else this._onstop = null;
		}
		get state() {
			return this._internalMediaRecorder.state;
		}
		pause() {
			return this._internalMediaRecorder.pause();
		}
		resume() {
			return this._internalMediaRecorder.resume();
		}
		start(timeslice) {
			return this._internalMediaRecorder.start(timeslice);
		}
		stop() {
			return this._internalMediaRecorder.stop();
		}
		static isTypeSupported(mimeType) {
			return nativeMediaRecorderConstructor !== null && nativeMediaRecorderConstructor.isTypeSupported !== void 0 && nativeMediaRecorderConstructor.isTypeSupported(mimeType) || encoderRegexes.some((regex) => regex.test(mimeType));
		}
	};
};
//#endregion
//#region node_modules/.pnpm/extendable-media-recorder@9.2.38/node_modules/extendable-media-recorder/build/es2019/factories/native-blob-event-constructor.js
var createNativeBlobEventConstructor = (window) => {
	if (window !== null && window.BlobEvent !== void 0) return window.BlobEvent;
	return null;
};
//#endregion
//#region node_modules/.pnpm/extendable-media-recorder@9.2.38/node_modules/extendable-media-recorder/build/es2019/factories/native-media-recorder-constructor.js
var createNativeMediaRecorderConstructor = (window) => {
	if (window === null) return null;
	return window.MediaRecorder === void 0 ? null : window.MediaRecorder;
};
//#endregion
//#region node_modules/.pnpm/extendable-media-recorder@9.2.38/node_modules/extendable-media-recorder/build/es2019/factories/native-media-recorder-factory.js
var createNativeMediaRecorderFactory = (createNotSupportedError) => (nativeMediaRecorderConstructor, stream, mediaRecorderOptions) => {
	const bufferedBlobEventListeners = /* @__PURE__ */ new Map();
	const dataAvailableListeners = /* @__PURE__ */ new WeakMap();
	const errorListeners = /* @__PURE__ */ new WeakMap();
	const flags = [];
	const nativeMediaRecorder = new nativeMediaRecorderConstructor(stream, mediaRecorderOptions);
	const stopListeners = /* @__PURE__ */ new WeakMap();
	nativeMediaRecorder.addEventListener("stop", ({ isTrusted }) => {
		if (isTrusted) setTimeout(() => flags.shift());
	});
	nativeMediaRecorder.addEventListener = ((addEventListener) => {
		return (type, listener, options) => {
			let patchedEventListener = listener;
			if (typeof listener === "function") {
				if (type === "dataavailable") {
					const bufferedBlobEvents = [];
					patchedEventListener = (event) => {
						const [[isSliced, isActive] = [false, false]] = flags;
						if (isSliced && !isActive) bufferedBlobEvents.push(event);
						else listener.call(nativeMediaRecorder, event);
					};
					bufferedBlobEventListeners.set(listener, bufferedBlobEvents);
					dataAvailableListeners.set(listener, patchedEventListener);
				} else if (type === "error") {
					patchedEventListener = (event) => {
						if (event instanceof ErrorEvent) listener.call(nativeMediaRecorder, event);
						else listener.call(nativeMediaRecorder, new ErrorEvent("error", { error: event.error }));
					};
					errorListeners.set(listener, patchedEventListener);
				} else if (type === "stop") {
					patchedEventListener = (event) => {
						for (const [dataAvailableListener, bufferedBlobEvents] of bufferedBlobEventListeners.entries()) if (bufferedBlobEvents.length > 0) {
							const [blobEvent] = bufferedBlobEvents;
							if (bufferedBlobEvents.length > 1) Object.defineProperty(blobEvent, "data", { value: new Blob(bufferedBlobEvents.map(({ data }) => data), { type: blobEvent.data.type }) });
							bufferedBlobEvents.length = 0;
							dataAvailableListener.call(nativeMediaRecorder, blobEvent);
						}
						listener.call(nativeMediaRecorder, event);
					};
					stopListeners.set(listener, patchedEventListener);
				}
			}
			return addEventListener.call(nativeMediaRecorder, type, patchedEventListener, options);
		};
	})(nativeMediaRecorder.addEventListener);
	nativeMediaRecorder.removeEventListener = ((removeEventListener) => {
		return (type, listener, options) => {
			let patchedEventListener = listener;
			if (typeof listener === "function") {
				if (type === "dataavailable") {
					bufferedBlobEventListeners.delete(listener);
					const dataAvailableListener = dataAvailableListeners.get(listener);
					if (dataAvailableListener !== void 0) patchedEventListener = dataAvailableListener;
				} else if (type === "error") {
					const errorListener = errorListeners.get(listener);
					if (errorListener !== void 0) patchedEventListener = errorListener;
				} else if (type === "stop") {
					const stopListener = stopListeners.get(listener);
					if (stopListener !== void 0) patchedEventListener = stopListener;
				}
			}
			return removeEventListener.call(nativeMediaRecorder, type, patchedEventListener, options);
		};
	})(nativeMediaRecorder.removeEventListener);
	nativeMediaRecorder.start = ((start) => {
		return (timeslice) => {
			if (mediaRecorderOptions.mimeType !== void 0 && mediaRecorderOptions.mimeType.startsWith("audio/") && stream.getVideoTracks().length > 0) throw createNotSupportedError();
			if (nativeMediaRecorder.state === "inactive") flags.push([timeslice !== void 0, true]);
			return timeslice === void 0 ? start.call(nativeMediaRecorder) : start.call(nativeMediaRecorder, timeslice);
		};
	})(nativeMediaRecorder.start);
	nativeMediaRecorder.stop = ((stop) => {
		return () => {
			if (nativeMediaRecorder.state !== "inactive") flags[0][1] = false;
			stop.call(nativeMediaRecorder);
		};
	})(nativeMediaRecorder.stop);
	return nativeMediaRecorder;
};
//#endregion
//#region node_modules/.pnpm/extendable-media-recorder@9.2.38/node_modules/extendable-media-recorder/build/es2019/factories/not-supported-error.js
var createNotSupportedError$1 = /* @__PURE__ */ __name(() => {
	try {
		return new DOMException("", "NotSupportedError");
	} catch (err) {
		err.code = 9;
		err.name = "NotSupportedError";
		return err;
	}
}, "createNotSupportedError");
//#endregion
//#region node_modules/.pnpm/extendable-media-recorder@9.2.38/node_modules/extendable-media-recorder/build/es2019/factories/read-element-content.js
var createReadElementContent = (readVariableSizeInteger) => {
	return (dataView, offset, type, channelCount = 2) => {
		const lengthAndValue = readVariableSizeInteger(dataView, offset);
		if (lengthAndValue === null) return lengthAndValue;
		const { length, value } = lengthAndValue;
		if (type === "master") return {
			content: null,
			length
		};
		if (offset + length + value > dataView.byteLength) return null;
		if (type === "binary") {
			const numberOfSamples = (value / Float32Array.BYTES_PER_ELEMENT - 1) / channelCount;
			const content = Array.from({ length: channelCount }, () => new Float32Array(numberOfSamples));
			for (let i = 0; i < numberOfSamples; i += 1) {
				const elementOffset = i * channelCount + 1;
				for (let j = 0; j < channelCount; j += 1) content[j][i] = dataView.getFloat32(offset + length + (elementOffset + j) * Float32Array.BYTES_PER_ELEMENT, true);
			}
			return {
				content,
				length: length + value
			};
		}
		return {
			content: null,
			length: length + value
		};
	};
};
//#endregion
//#region node_modules/.pnpm/extendable-media-recorder@9.2.38/node_modules/extendable-media-recorder/build/es2019/factories/read-element-type.js
var createReadElementType = (readVariableSizeInteger) => {
	return (dataView, offset) => {
		const lengthAndValue = readVariableSizeInteger(dataView, offset);
		if (lengthAndValue === null) return lengthAndValue;
		const { length, value } = lengthAndValue;
		if (value === 35) return {
			length,
			type: "binary"
		};
		if (value === 46 || value === 97 || value === 88713574 || value === 106212971 || value === 139690087 || value === 172351395 || value === 256095861) return {
			length,
			type: "master"
		};
		return {
			length,
			type: "unknown"
		};
	};
};
//#endregion
//#region node_modules/.pnpm/extendable-media-recorder@9.2.38/node_modules/extendable-media-recorder/build/es2019/factories/read-variable-size-integer.js
var createReadVariableSizeInteger = (readVariableSizeIntegerLength) => {
	return (dataView, offset) => {
		const length = readVariableSizeIntegerLength(dataView, offset);
		if (length === null) return length;
		const firstDataByteOffset = offset + Math.floor((length - 1) / 8);
		if (firstDataByteOffset + length > dataView.byteLength) return null;
		let value = dataView.getUint8(firstDataByteOffset) & (1 << 8 - length % 8) - 1;
		for (let i = 1; i < length; i += 1) value = (value << 8) + dataView.getUint8(firstDataByteOffset + i);
		return {
			length,
			value
		};
	};
};
//#endregion
//#region node_modules/.pnpm/rxjs-interop@2.0.0/node_modules/rxjs-interop/dist/esm/symbols.js
var observable = Symbol.observable || "@@observable";
//#endregion
//#region node_modules/.pnpm/rxjs-interop@2.0.0/node_modules/rxjs-interop/dist/esm/patch.js
function patch(arg) {
	if (!Symbol.observable) {
		if (typeof arg === "function" && arg.prototype && arg.prototype[Symbol.observable]) {
			arg.prototype[observable] = arg.prototype[Symbol.observable];
			delete arg.prototype[Symbol.observable];
		} else {
			arg[observable] = arg[Symbol.observable];
			delete arg[Symbol.observable];
		}
	}
	return arg;
}
//#endregion
//#region node_modules/.pnpm/rxjs-interop@2.0.0/node_modules/rxjs-interop/dist/esm/to-observer.js
var noop = () => {};
var rethrow = (error) => {
	throw error;
};
function toObserver(observer) {
	if (observer) {
		if (observer.next && observer.error && observer.complete) return observer;
		return {
			complete: (observer.complete ?? noop).bind(observer),
			error: (observer.error ?? rethrow).bind(observer),
			next: (observer.next ?? noop).bind(observer)
		};
	}
	return {
		complete: noop,
		error: rethrow,
		next: noop
	};
}
//#endregion
//#region node_modules/.pnpm/subscribable-things@2.1.60/node_modules/subscribable-things/build/es2019/factories/on.js
var createOn = (wrapSubscribeFunction) => {
	return (target, type, options) => wrapSubscribeFunction((observer) => {
		const listener = (event) => observer.next(event);
		target.addEventListener(type, listener, options);
		return () => target.removeEventListener(type, listener, options);
	});
};
//#endregion
//#region node_modules/.pnpm/subscribable-things@2.1.60/node_modules/subscribable-things/build/es2019/factories/window.js
var createWindow$2 = /* @__PURE__ */ __name(() => typeof window === "undefined" ? null : window, "createWindow");
//#endregion
//#region node_modules/.pnpm/subscribable-things@2.1.60/node_modules/subscribable-things/build/es2019/factories/wrap-subscribe-function.js
var createWrapSubscribeFunction = (patch, toObserver) => {
	const emptyFunction = () => {};
	const isNextFunction = (args) => typeof args[0] === "function";
	return (innerSubscribe) => {
		const subscribe = ((...args) => {
			const unsubscribe = innerSubscribe(isNextFunction(args) ? toObserver({ next: args[0] }) : toObserver(...args));
			if (unsubscribe !== void 0) return unsubscribe;
			return emptyFunction;
		});
		subscribe[Symbol.observable] = () => ({ subscribe: (...args) => ({ unsubscribe: subscribe(...args) }) });
		return patch(subscribe);
	};
};
createWindow$2();
var on = createOn(createWrapSubscribeFunction(patch, toObserver));
//#endregion
//#region node_modules/.pnpm/recorder-audio-worklet@6.0.59/node_modules/recorder-audio-worklet/build/es2019/factories/add-recorder-audio-worklet-module.js
var createAddRecorderAudioWorkletModule = (blobConstructor, urlConstructor, worklet) => {
	return async (addAudioWorkletModule) => {
		const blob = new blobConstructor([worklet], { type: "application/javascript; charset=utf-8" });
		const url = urlConstructor.createObjectURL(blob);
		try {
			await addAudioWorkletModule(url);
		} finally {
			urlConstructor.revokeObjectURL(url);
		}
	};
};
//#endregion
//#region node_modules/.pnpm/recorder-audio-worklet@6.0.59/node_modules/recorder-audio-worklet/build/es2019/factories/listener.js
var createListener = (ongoingRequests) => {
	return ({ data: message }) => {
		const { id } = message;
		if (id !== null) {
			const ongoingRequest = ongoingRequests.get(id);
			if (ongoingRequest !== void 0) {
				const { reject, resolve } = ongoingRequest;
				ongoingRequests.delete(id);
				if (message.error === void 0) resolve(message.result);
				else reject(new Error(message.error.message));
			}
		}
	};
};
//#endregion
//#region node_modules/.pnpm/recorder-audio-worklet@6.0.59/node_modules/recorder-audio-worklet/build/es2019/factories/post-message-factory.js
var createPostMessageFactory = (generateUniqueNumber) => {
	return (ongoingRequests, port) => {
		return (message, transferables = []) => {
			return new Promise((resolve, reject) => {
				const id = generateUniqueNumber(ongoingRequests);
				ongoingRequests.set(id, {
					reject,
					resolve
				});
				port.postMessage({
					id,
					...message
				}, transferables);
			});
		};
	};
};
//#endregion
//#region node_modules/.pnpm/recorder-audio-worklet@6.0.59/node_modules/recorder-audio-worklet/build/es2019/factories/recorder-audio-worklet-node-factory.js
var createRecorderAudioWorkletNodeFactory = (createListener, createPostMessage, on, validateState) => {
	return (audioWorkletNodeConstructor, context, options = {}) => {
		const fixedOptions = {
			channelCountMode: "explicit",
			numberOfInputs: 1,
			numberOfOutputs: 0
		};
		const audioWorkletNode = new audioWorkletNodeConstructor(context, "recorder-audio-worklet-processor", {
			...options,
			...fixedOptions
		});
		const ongoingRequests = /* @__PURE__ */ new Map();
		const postMessage = createPostMessage(ongoingRequests, audioWorkletNode.port);
		const unsubscribe = on(audioWorkletNode.port, "message")(createListener(ongoingRequests));
		audioWorkletNode.port.start();
		let state = "inactive";
		Object.defineProperties(audioWorkletNode, {
			pause: { get() {
				return async () => {
					validateState(["recording"], state);
					state = "paused";
					return postMessage({ method: "pause" });
				};
			} },
			port: { get() {
				throw new Error("The port of a RecorderAudioWorkletNode can't be accessed.");
			} },
			record: { get() {
				return async (encoderPort) => {
					validateState(["inactive"], state);
					state = "recording";
					return postMessage({
						method: "record",
						params: { encoderPort }
					}, [encoderPort]);
				};
			} },
			resume: { get() {
				return async () => {
					validateState(["paused"], state);
					state = "recording";
					return postMessage({ method: "resume" });
				};
			} },
			stop: { get() {
				return async () => {
					validateState(["paused", "recording"], state);
					state = "stopped";
					try {
						await postMessage({ method: "stop" });
					} finally {
						unsubscribe();
					}
				};
			} }
		});
		return audioWorkletNode;
	};
};
//#endregion
//#region node_modules/.pnpm/recorder-audio-worklet@6.0.59/node_modules/recorder-audio-worklet/build/es2019/functions/validate-state.js
var validateState = (expectedStates, currentState) => {
	if (!expectedStates.includes(currentState)) throw new Error(`Expected the state to be ${expectedStates.map((expectedState) => `"${expectedState}"`).join(" or ")} but it was "${currentState}".`);
};
//#endregion
//#region node_modules/.pnpm/recorder-audio-worklet@6.0.59/node_modules/recorder-audio-worklet/build/es2019/module.js
var addRecorderAudioWorkletModule = createAddRecorderAudioWorkletModule(Blob, URL, `(()=>{"use strict";class e extends AudioWorkletProcessor{constructor(){super(),this._encoderPort=null,this._numberOfChannels=0,this._state="inactive",this.port.onmessage=({data:e})=>{"pause"===e.method?"active"===this._state||"recording"===this._state?(this._state="paused",this._sendAcknowledgement(e.id)):this._sendUnexpectedStateError(e.id):"record"===e.method?"inactive"===this._state?(this._encoderPort=e.params.encoderPort,this._state="active",this._sendAcknowledgement(e.id)):this._sendUnexpectedStateError(e.id):"resume"===e.method?"paused"===this._state?(this._state="active",this._sendAcknowledgement(e.id)):this._sendUnexpectedStateError(e.id):"stop"===e.method?"active"!==this._state&&"paused"!==this._state&&"recording"!==this._state||null===this._encoderPort?this._sendUnexpectedStateError(e.id):(this._stop(this._encoderPort),this._sendAcknowledgement(e.id)):"number"==typeof e.id&&this.port.postMessage({error:{code:-32601,message:"The requested method is not supported."},id:e.id})}}process([e]){if("inactive"===this._state||"paused"===this._state)return!0;if("active"===this._state){if(void 0===e)throw new Error("No channelData was received for the first input.");if(0===e.length)return!0;this._state="recording"}if("recording"===this._state&&null!==this._encoderPort){if(void 0===e)throw new Error("No channelData was received for the first input.");return 0===e.length?this._encoderPort.postMessage(Array.from({length:this._numberOfChannels},()=>128)):(this._encoderPort.postMessage(e,e.map(({buffer:e})=>e)),this._numberOfChannels=e.length),!0}return!1}_sendAcknowledgement(e){this.port.postMessage({id:e,result:null})}_sendUnexpectedStateError(e){this.port.postMessage({error:{code:-32603,message:"The internal state does not allow to process the given message."},id:e})}_stop(e){e.postMessage([]),e.close(),this._encoderPort=null,this._state="stopped"}}e.parameterDescriptors=[],registerProcessor("recorder-audio-worklet-processor",e)})();`);
var createRecorderAudioWorkletNode = createRecorderAudioWorkletNodeFactory(createListener, createPostMessageFactory(import_bundle$2.generateUniqueNumber), on, validateState);
//#endregion
//#region node_modules/.pnpm/@babel+runtime@7.29.7/node_modules/@babel/runtime/helpers/arrayWithHoles.js
var require_arrayWithHoles = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function _arrayWithHoles(r) {
		if (Array.isArray(r)) return r;
	}
	module.exports = _arrayWithHoles, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
//#endregion
//#region node_modules/.pnpm/@babel+runtime@7.29.7/node_modules/@babel/runtime/helpers/iterableToArrayLimit.js
var require_iterableToArrayLimit = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function _iterableToArrayLimit(r, l) {
		var t = null == r ? null : "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
		if (null != t) {
			var e;
			var n;
			var i;
			var u;
			var a = [];
			var f = !0;
			var o = !1;
			try {
				if (i = (t = t.call(r)).next, 0 === l) {
					if (Object(t) !== t) return;
					f = !1;
				} else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
			} catch (r) {
				o = !0, n = r;
			} finally {
				try {
					if (!f && null != t["return"] && (u = t["return"](), Object(u) !== u)) return;
				} finally {
					if (o) throw n;
				}
			}
			return a;
		}
	}
	module.exports = _iterableToArrayLimit, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
//#endregion
//#region node_modules/.pnpm/@babel+runtime@7.29.7/node_modules/@babel/runtime/helpers/arrayLikeToArray.js
var require_arrayLikeToArray = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function _arrayLikeToArray(r, a) {
		(null == a || a > r.length) && (a = r.length);
		for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
		return n;
	}
	module.exports = _arrayLikeToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
//#endregion
//#region node_modules/.pnpm/@babel+runtime@7.29.7/node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js
var require_unsupportedIterableToArray = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var arrayLikeToArray = require_arrayLikeToArray();
	function _unsupportedIterableToArray(r, a) {
		if (r) {
			if ("string" == typeof r) return arrayLikeToArray(r, a);
			var t = {}.toString.call(r).slice(8, -1);
			return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? arrayLikeToArray(r, a) : void 0;
		}
	}
	module.exports = _unsupportedIterableToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
//#endregion
//#region node_modules/.pnpm/@babel+runtime@7.29.7/node_modules/@babel/runtime/helpers/nonIterableRest.js
var require_nonIterableRest = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function _nonIterableRest() {
		throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
	}
	module.exports = _nonIterableRest, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
//#endregion
//#region node_modules/.pnpm/@babel+runtime@7.29.7/node_modules/@babel/runtime/helpers/slicedToArray.js
var require_slicedToArray = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var arrayWithHoles = require_arrayWithHoles();
	var iterableToArrayLimit = require_iterableToArrayLimit();
	var unsupportedIterableToArray = require_unsupportedIterableToArray();
	var nonIterableRest = require_nonIterableRest();
	function _slicedToArray(r, e) {
		return arrayWithHoles(r) || iterableToArrayLimit(r, e) || unsupportedIterableToArray(r, e) || nonIterableRest();
	}
	module.exports = _slicedToArray, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
//#endregion
//#region node_modules/.pnpm/@babel+runtime@7.29.7/node_modules/@babel/runtime/helpers/classCallCheck.js
var require_classCallCheck = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function _classCallCheck(a, n) {
		if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
	}
	module.exports = _classCallCheck, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
//#endregion
//#region node_modules/.pnpm/@babel+runtime@7.29.7/node_modules/@babel/runtime/helpers/typeof.js
var require_typeof = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function _typeof(o) {
		"@babel/helpers - typeof";
		return module.exports = _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
			return typeof o;
		} : function(o) {
			return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
		}, module.exports.__esModule = true, module.exports["default"] = module.exports, _typeof(o);
	}
	module.exports = _typeof, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
//#endregion
//#region node_modules/.pnpm/@babel+runtime@7.29.7/node_modules/@babel/runtime/helpers/toPrimitive.js
var require_toPrimitive = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _typeof = require_typeof()["default"];
	function toPrimitive(t, r) {
		if ("object" != _typeof(t) || !t) return t;
		var e = t[Symbol.toPrimitive];
		if (void 0 !== e) {
			var i = e.call(t, r || "default");
			if ("object" != _typeof(i)) return i;
			throw new TypeError("@@toPrimitive must return a primitive value.");
		}
		return ("string" === r ? String : Number)(t);
	}
	module.exports = toPrimitive, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
//#endregion
//#region node_modules/.pnpm/@babel+runtime@7.29.7/node_modules/@babel/runtime/helpers/toPropertyKey.js
var require_toPropertyKey = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var _typeof = require_typeof()["default"];
	var toPrimitive = require_toPrimitive();
	function toPropertyKey(t) {
		var i = toPrimitive(t, "string");
		return "symbol" == _typeof(i) ? i : i + "";
	}
	module.exports = toPropertyKey, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
//#endregion
//#region node_modules/.pnpm/@babel+runtime@7.29.7/node_modules/@babel/runtime/helpers/createClass.js
var require_createClass = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var toPropertyKey = require_toPropertyKey();
	function _defineProperties(e, r) {
		for (var t = 0; t < r.length; t++) {
			var o = r[t];
			o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, toPropertyKey(o.key), o);
		}
	}
	function _createClass(e, r, t) {
		return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", { writable: !1 }), e;
	}
	module.exports = _createClass, module.exports.__esModule = true, module.exports["default"] = module.exports;
}));
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/abort-error.js
var import_bundle$1 = (/* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(global, factory) {
		typeof exports === "object" && typeof module !== "undefined" ? factory(exports, require_slicedToArray(), require_classCallCheck(), require_createClass()) : typeof define === "function" && define.amd ? define([
			"exports",
			"@babel/runtime/helpers/slicedToArray",
			"@babel/runtime/helpers/classCallCheck",
			"@babel/runtime/helpers/createClass"
		], factory) : (global = typeof globalThis !== "undefined" ? globalThis : global || self, factory(global.automationEvents = {}, global._slicedToArray, global._classCallCheck, global._createClass));
	})(exports, (function(exports$2, _slicedToArray, _classCallCheck, _createClass) {
		"use strict";
		var createExtendedExponentialRampToValueAutomationEvent = function createExtendedExponentialRampToValueAutomationEvent(value, endTime, insertTime) {
			return {
				endTime,
				insertTime,
				type: "exponentialRampToValue",
				value
			};
		};
		var createExtendedLinearRampToValueAutomationEvent = function createExtendedLinearRampToValueAutomationEvent(value, endTime, insertTime) {
			return {
				endTime,
				insertTime,
				type: "linearRampToValue",
				value
			};
		};
		var createSetValueAutomationEvent = function createSetValueAutomationEvent(value, startTime) {
			return {
				startTime,
				type: "setValue",
				value
			};
		};
		var createSetValueCurveAutomationEvent = function createSetValueCurveAutomationEvent(values, startTime, duration) {
			return {
				duration,
				startTime,
				type: "setValueCurve",
				values
			};
		};
		var getTargetValueAtTime = function getTargetValueAtTime(time, valueAtStartTime, _ref) {
			var startTime = _ref.startTime;
			var target = _ref.target;
			var timeConstant = _ref.timeConstant;
			return target + (valueAtStartTime - target) * Math.exp((startTime - time) / timeConstant);
		};
		var isExponentialRampToValueAutomationEvent = function isExponentialRampToValueAutomationEvent(automationEvent) {
			return automationEvent.type === "exponentialRampToValue";
		};
		var isLinearRampToValueAutomationEvent = function isLinearRampToValueAutomationEvent(automationEvent) {
			return automationEvent.type === "linearRampToValue";
		};
		var isAnyRampToValueAutomationEvent = function isAnyRampToValueAutomationEvent(automationEvent) {
			return isExponentialRampToValueAutomationEvent(automationEvent) || isLinearRampToValueAutomationEvent(automationEvent);
		};
		var isSetValueAutomationEvent = function isSetValueAutomationEvent(automationEvent) {
			return automationEvent.type === "setValue";
		};
		var isSetValueCurveAutomationEvent = function isSetValueCurveAutomationEvent(automationEvent) {
			return automationEvent.type === "setValueCurve";
		};
		var _getValueOfAutomationEventAtIndexAtTime = function getValueOfAutomationEventAtIndexAtTime(automationEvents, index, time, defaultValue) {
			var automationEvent = automationEvents[index];
			return automationEvent === void 0 ? defaultValue : isAnyRampToValueAutomationEvent(automationEvent) || isSetValueAutomationEvent(automationEvent) ? automationEvent.value : isSetValueCurveAutomationEvent(automationEvent) ? automationEvent.values[automationEvent.values.length - 1] : getTargetValueAtTime(time, _getValueOfAutomationEventAtIndexAtTime(automationEvents, index - 1, automationEvent.startTime, defaultValue), automationEvent);
		};
		var getEndTimeAndValueOfPreviousAutomationEvent = function getEndTimeAndValueOfPreviousAutomationEvent(automationEvents, index, currentAutomationEvent, nextAutomationEvent, defaultValue) {
			return currentAutomationEvent === void 0 ? [nextAutomationEvent.insertTime, defaultValue] : isAnyRampToValueAutomationEvent(currentAutomationEvent) ? [currentAutomationEvent.endTime, currentAutomationEvent.value] : isSetValueAutomationEvent(currentAutomationEvent) ? [currentAutomationEvent.startTime, currentAutomationEvent.value] : isSetValueCurveAutomationEvent(currentAutomationEvent) ? [currentAutomationEvent.startTime + currentAutomationEvent.duration, currentAutomationEvent.values[currentAutomationEvent.values.length - 1]] : [currentAutomationEvent.startTime, _getValueOfAutomationEventAtIndexAtTime(automationEvents, index - 1, currentAutomationEvent.startTime, defaultValue)];
		};
		var isCancelAndHoldAutomationEvent = function isCancelAndHoldAutomationEvent(automationEvent) {
			return automationEvent.type === "cancelAndHold";
		};
		var isCancelScheduledValuesAutomationEvent = function isCancelScheduledValuesAutomationEvent(automationEvent) {
			return automationEvent.type === "cancelScheduledValues";
		};
		var getEventTime = function getEventTime(automationEvent) {
			if (isCancelAndHoldAutomationEvent(automationEvent) || isCancelScheduledValuesAutomationEvent(automationEvent)) return automationEvent.cancelTime;
			if (isExponentialRampToValueAutomationEvent(automationEvent) || isLinearRampToValueAutomationEvent(automationEvent)) return automationEvent.endTime;
			return automationEvent.startTime;
		};
		var getExponentialRampValueAtTime = function getExponentialRampValueAtTime(time, startTime, valueAtStartTime, _ref) {
			var endTime = _ref.endTime;
			var value = _ref.value;
			if (valueAtStartTime === value) return value;
			if (0 < valueAtStartTime && 0 < value || valueAtStartTime < 0 && value < 0) return valueAtStartTime * Math.pow(value / valueAtStartTime, (time - startTime) / (endTime - startTime));
			return time < endTime ? valueAtStartTime : value;
		};
		var getLinearRampValueAtTime = function getLinearRampValueAtTime(time, startTime, valueAtStartTime, _ref) {
			var endTime = _ref.endTime;
			var value = _ref.value;
			return valueAtStartTime + (time - startTime) / (endTime - startTime) * (value - valueAtStartTime);
		};
		var interpolateValue = function interpolateValue(values, theoreticIndex) {
			var lowerIndex = Math.floor(theoreticIndex);
			if (lowerIndex === theoreticIndex) return values[lowerIndex];
			var upperIndex = Math.ceil(theoreticIndex);
			return (1 - (theoreticIndex - lowerIndex)) * values[lowerIndex] + (1 - (upperIndex - theoreticIndex)) * values[upperIndex];
		};
		var getValueCurveValueAtTime = function getValueCurveValueAtTime(time, _ref) {
			var duration = _ref.duration;
			var startTime = _ref.startTime;
			var values = _ref.values;
			return interpolateValue(values, (time - startTime) / duration * (values.length - 1));
		};
		var truncateValueCurve = function truncateValueCurve(values, originalDuration, targetDuration) {
			var length = values.length;
			var truncatedLength = Math.max(1, Math.floor(targetDuration / originalDuration * length)) + 1;
			var truncatedValues = values instanceof Float32Array ? new Float32Array(truncatedLength) : values.slice(0, truncatedLength);
			for (var i = 0; i < truncatedLength; i += 1) {
				var theoreticIndex = i / (truncatedLength - 1) * targetDuration / originalDuration * (length - 1);
				truncatedValues[i] = interpolateValue(values, theoreticIndex);
			}
			return truncatedValues;
		};
		var isSetTargetAutomationEvent = function isSetTargetAutomationEvent(automationEvent) {
			return automationEvent.type === "setTarget";
		};
		var AutomationEventList = /*#__PURE__*/ function() {
			function AutomationEventList(defaultValue) {
				_classCallCheck(this, AutomationEventList);
				this._automationEvents = [];
				this._currenTime = 0;
				this._defaultValue = defaultValue;
			}
			return _createClass(AutomationEventList, [
				{
					key: Symbol.iterator,
					value: function value() {
						return this._automationEvents[Symbol.iterator]();
					}
				},
				{
					key: "add",
					value: function add(automationEvent) {
						var eventTime = getEventTime(automationEvent);
						if (isCancelAndHoldAutomationEvent(automationEvent) || isCancelScheduledValuesAutomationEvent(automationEvent)) {
							var index = this._automationEvents.findIndex(function(currentAutomationEvent) {
								if (isCancelScheduledValuesAutomationEvent(automationEvent) && isSetValueCurveAutomationEvent(currentAutomationEvent)) return currentAutomationEvent.startTime + currentAutomationEvent.duration >= eventTime;
								return getEventTime(currentAutomationEvent) >= eventTime;
							});
							var removedAutomationEvent = this._automationEvents[index];
							if (index !== -1) this._automationEvents = this._automationEvents.slice(0, index);
							if (isCancelAndHoldAutomationEvent(automationEvent)) {
								var lastAutomationEvent = this._automationEvents[this._automationEvents.length - 1];
								if (removedAutomationEvent !== void 0 && isAnyRampToValueAutomationEvent(removedAutomationEvent)) {
									if (lastAutomationEvent !== void 0 && isSetTargetAutomationEvent(lastAutomationEvent)) throw new Error("The internal list is malformed.");
									var startTime = lastAutomationEvent === void 0 ? removedAutomationEvent.insertTime : isSetValueCurveAutomationEvent(lastAutomationEvent) ? lastAutomationEvent.startTime + lastAutomationEvent.duration : getEventTime(lastAutomationEvent);
									var startValue = lastAutomationEvent === void 0 ? this._defaultValue : isSetValueCurveAutomationEvent(lastAutomationEvent) ? lastAutomationEvent.values[lastAutomationEvent.values.length - 1] : lastAutomationEvent.value;
									var value = isExponentialRampToValueAutomationEvent(removedAutomationEvent) ? getExponentialRampValueAtTime(eventTime, startTime, startValue, removedAutomationEvent) : getLinearRampValueAtTime(eventTime, startTime, startValue, removedAutomationEvent);
									var truncatedAutomationEvent = isExponentialRampToValueAutomationEvent(removedAutomationEvent) ? createExtendedExponentialRampToValueAutomationEvent(value, eventTime, this._currenTime) : createExtendedLinearRampToValueAutomationEvent(value, eventTime, this._currenTime);
									this._automationEvents.push(truncatedAutomationEvent);
								}
								if (lastAutomationEvent !== void 0 && isSetTargetAutomationEvent(lastAutomationEvent)) this._automationEvents.push(createSetValueAutomationEvent(this.getValue(eventTime), eventTime));
								if (lastAutomationEvent !== void 0 && isSetValueCurveAutomationEvent(lastAutomationEvent) && lastAutomationEvent.startTime + lastAutomationEvent.duration > eventTime) {
									var duration = eventTime - lastAutomationEvent.startTime;
									this._automationEvents[this._automationEvents.length - 1] = createSetValueCurveAutomationEvent(truncateValueCurve(lastAutomationEvent.values, lastAutomationEvent.duration, duration), lastAutomationEvent.startTime, duration);
								}
							}
						} else {
							var _index = this._automationEvents.findIndex(function(currentAutomationEvent) {
								return getEventTime(currentAutomationEvent) > eventTime;
							});
							var previousAutomationEvent = _index === -1 ? this._automationEvents[this._automationEvents.length - 1] : this._automationEvents[_index - 1];
							if (previousAutomationEvent !== void 0 && isSetValueCurveAutomationEvent(previousAutomationEvent) && getEventTime(previousAutomationEvent) + previousAutomationEvent.duration > eventTime) return false;
							var persistentAutomationEvent = isExponentialRampToValueAutomationEvent(automationEvent) ? createExtendedExponentialRampToValueAutomationEvent(automationEvent.value, automationEvent.endTime, this._currenTime) : isLinearRampToValueAutomationEvent(automationEvent) ? createExtendedLinearRampToValueAutomationEvent(automationEvent.value, eventTime, this._currenTime) : automationEvent;
							if (_index === -1) this._automationEvents.push(persistentAutomationEvent);
							else {
								if (isSetValueCurveAutomationEvent(automationEvent) && eventTime + automationEvent.duration > getEventTime(this._automationEvents[_index])) return false;
								this._automationEvents.splice(_index, 0, persistentAutomationEvent);
							}
						}
						return true;
					}
				},
				{
					key: "flush",
					value: function flush(time) {
						var index = this._automationEvents.findIndex(function(currentAutomationEvent) {
							return getEventTime(currentAutomationEvent) > time;
						});
						if (index > 1) {
							var remainingAutomationEvents = this._automationEvents.slice(index - 1);
							var firstRemainingAutomationEvent = remainingAutomationEvents[0];
							if (isSetTargetAutomationEvent(firstRemainingAutomationEvent)) remainingAutomationEvents.unshift(createSetValueAutomationEvent(_getValueOfAutomationEventAtIndexAtTime(this._automationEvents, index - 2, firstRemainingAutomationEvent.startTime, this._defaultValue), firstRemainingAutomationEvent.startTime));
							this._automationEvents = remainingAutomationEvents;
						}
					}
				},
				{
					key: "getValue",
					value: function getValue(time) {
						if (this._automationEvents.length === 0) return this._defaultValue;
						var indexOfNextEvent = this._automationEvents.findIndex(function(automationEvent) {
							return getEventTime(automationEvent) > time;
						});
						var nextAutomationEvent = this._automationEvents[indexOfNextEvent];
						var indexOfCurrentEvent = (indexOfNextEvent === -1 ? this._automationEvents.length : indexOfNextEvent) - 1;
						var currentAutomationEvent = this._automationEvents[indexOfCurrentEvent];
						if (currentAutomationEvent !== void 0 && isSetTargetAutomationEvent(currentAutomationEvent) && (nextAutomationEvent === void 0 || !isAnyRampToValueAutomationEvent(nextAutomationEvent) || nextAutomationEvent.insertTime > time)) return getTargetValueAtTime(time, _getValueOfAutomationEventAtIndexAtTime(this._automationEvents, indexOfCurrentEvent - 1, currentAutomationEvent.startTime, this._defaultValue), currentAutomationEvent);
						if (currentAutomationEvent !== void 0 && isSetValueAutomationEvent(currentAutomationEvent) && (nextAutomationEvent === void 0 || !isAnyRampToValueAutomationEvent(nextAutomationEvent))) return currentAutomationEvent.value;
						if (currentAutomationEvent !== void 0 && isSetValueCurveAutomationEvent(currentAutomationEvent) && (nextAutomationEvent === void 0 || !isAnyRampToValueAutomationEvent(nextAutomationEvent) || currentAutomationEvent.startTime + currentAutomationEvent.duration > time)) {
							if (time < currentAutomationEvent.startTime + currentAutomationEvent.duration) return getValueCurveValueAtTime(time, currentAutomationEvent);
							return currentAutomationEvent.values[currentAutomationEvent.values.length - 1];
						}
						if (currentAutomationEvent !== void 0 && isAnyRampToValueAutomationEvent(currentAutomationEvent) && (nextAutomationEvent === void 0 || !isAnyRampToValueAutomationEvent(nextAutomationEvent))) return currentAutomationEvent.value;
						if (nextAutomationEvent !== void 0 && isExponentialRampToValueAutomationEvent(nextAutomationEvent)) {
							var _getEndTimeAndValueOf2 = _slicedToArray(getEndTimeAndValueOfPreviousAutomationEvent(this._automationEvents, indexOfCurrentEvent, currentAutomationEvent, nextAutomationEvent, this._defaultValue), 2);
							var startTime = _getEndTimeAndValueOf2[0];
							var value = _getEndTimeAndValueOf2[1];
							return getExponentialRampValueAtTime(time, startTime, value, nextAutomationEvent);
						}
						if (nextAutomationEvent !== void 0 && isLinearRampToValueAutomationEvent(nextAutomationEvent)) {
							var _getEndTimeAndValueOf4 = _slicedToArray(getEndTimeAndValueOfPreviousAutomationEvent(this._automationEvents, indexOfCurrentEvent, currentAutomationEvent, nextAutomationEvent, this._defaultValue), 2);
							var _startTime = _getEndTimeAndValueOf4[0];
							var _value = _getEndTimeAndValueOf4[1];
							return getLinearRampValueAtTime(time, _startTime, _value, nextAutomationEvent);
						}
						return this._defaultValue;
					}
				}
			]);
		}();
		var createCancelAndHoldAutomationEvent = function createCancelAndHoldAutomationEvent(cancelTime) {
			return {
				cancelTime,
				type: "cancelAndHold"
			};
		};
		var createCancelScheduledValuesAutomationEvent = function createCancelScheduledValuesAutomationEvent(cancelTime) {
			return {
				cancelTime,
				type: "cancelScheduledValues"
			};
		};
		var createExponentialRampToValueAutomationEvent = function createExponentialRampToValueAutomationEvent(value, endTime) {
			return {
				endTime,
				type: "exponentialRampToValue",
				value
			};
		};
		var createLinearRampToValueAutomationEvent = function createLinearRampToValueAutomationEvent(value, endTime) {
			return {
				endTime,
				type: "linearRampToValue",
				value
			};
		};
		var createSetTargetAutomationEvent = function createSetTargetAutomationEvent(target, startTime, timeConstant) {
			return {
				startTime,
				target,
				timeConstant,
				type: "setTarget"
			};
		};
		exports$2.AutomationEventList = AutomationEventList;
		exports$2.createCancelAndHoldAutomationEvent = createCancelAndHoldAutomationEvent;
		exports$2.createCancelScheduledValuesAutomationEvent = createCancelScheduledValuesAutomationEvent;
		exports$2.createExponentialRampToValueAutomationEvent = createExponentialRampToValueAutomationEvent;
		exports$2.createLinearRampToValueAutomationEvent = createLinearRampToValueAutomationEvent;
		exports$2.createSetTargetAutomationEvent = createSetTargetAutomationEvent;
		exports$2.createSetValueAutomationEvent = createSetValueAutomationEvent;
		exports$2.createSetValueCurveAutomationEvent = createSetValueCurveAutomationEvent;
	}));
})))();
var createAbortError = () => new DOMException("", "AbortError");
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/add-active-input-connection-to-audio-node.js
var createAddActiveInputConnectionToAudioNode = (insertElementInSet) => {
	return (activeInputs, source, [output, input, eventListener], ignoreDuplicates) => {
		insertElementInSet(activeInputs[input], [
			source,
			output,
			eventListener
		], (activeInputConnection) => activeInputConnection[0] === source && activeInputConnection[1] === output, ignoreDuplicates);
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/add-audio-node-connections.js
var createAddAudioNodeConnections = (audioNodeConnectionsStore) => {
	return (audioNode, audioNodeRenderer, nativeAudioNode) => {
		const activeInputs = [];
		for (let i = 0; i < nativeAudioNode.numberOfInputs; i += 1) activeInputs.push(/* @__PURE__ */ new Set());
		audioNodeConnectionsStore.set(audioNode, {
			activeInputs,
			outputs: /* @__PURE__ */ new Set(),
			passiveInputs: /* @__PURE__ */ new WeakMap(),
			renderer: audioNodeRenderer
		});
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/add-audio-param-connections.js
var createAddAudioParamConnections = (audioParamConnectionsStore) => {
	return (audioParam, audioParamRenderer) => {
		audioParamConnectionsStore.set(audioParam, {
			activeInputs: /* @__PURE__ */ new Set(),
			passiveInputs: /* @__PURE__ */ new WeakMap(),
			renderer: audioParamRenderer
		});
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/globals.js
var ACTIVE_AUDIO_NODE_STORE = /* @__PURE__ */ new WeakSet();
var AUDIO_NODE_CONNECTIONS_STORE = /* @__PURE__ */ new WeakMap();
var AUDIO_NODE_STORE = /* @__PURE__ */ new WeakMap();
var AUDIO_PARAM_CONNECTIONS_STORE = /* @__PURE__ */ new WeakMap();
var AUDIO_PARAM_STORE = /* @__PURE__ */ new WeakMap();
var CONTEXT_STORE = /* @__PURE__ */ new WeakMap();
var EVENT_LISTENERS = /* @__PURE__ */ new WeakMap();
var CYCLE_COUNTERS = /* @__PURE__ */ new WeakMap();
var NODE_NAME_TO_PROCESSOR_CONSTRUCTOR_MAPS = /* @__PURE__ */ new WeakMap();
var NODE_TO_PROCESSOR_MAPS = /* @__PURE__ */ new WeakMap();
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/is-constructible.js
var handler = { construct() {
	return handler;
} };
var isConstructible = (constructible) => {
	try {
		new new Proxy(constructible, handler)();
	} catch {
		return false;
	}
	return true;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/split-import-statements.js
var IMPORT_STATEMENT_REGEX = /^import(?:(?:[\s]+[\w]+|(?:[\s]+[\w]+[\s]*,)?[\s]*\{[\s]*[\w]+(?:[\s]+as[\s]+[\w]+)?(?:[\s]*,[\s]*[\w]+(?:[\s]+as[\s]+[\w]+)?)*[\s]*}|(?:[\s]+[\w]+[\s]*,)?[\s]*\*[\s]+as[\s]+[\w]+)[\s]+from)?(?:[\s]*)("([^"\\]|\\.)+"|'([^'\\]|\\.)+')(?:[\s]*);?/;
var splitImportStatements = (source, url) => {
	const importStatements = [];
	let sourceWithoutImportStatements = source.replace(/^[\s]+/, "");
	let result = sourceWithoutImportStatements.match(IMPORT_STATEMENT_REGEX);
	while (result !== null) {
		const unresolvedUrl = result[1].slice(1, -1);
		const importStatementWithResolvedUrl = result[0].replace(/([\s]+)?;?$/, "").replace(unresolvedUrl, new URL(unresolvedUrl, url).toString());
		importStatements.push(importStatementWithResolvedUrl);
		sourceWithoutImportStatements = sourceWithoutImportStatements.slice(result[0].length).replace(/^[\s]+/, "");
		result = sourceWithoutImportStatements.match(IMPORT_STATEMENT_REGEX);
	}
	return [importStatements.join(";"), sourceWithoutImportStatements];
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/add-audio-worklet-module.js
var verifyParameterDescriptors = (parameterDescriptors) => {
	if (parameterDescriptors !== void 0 && !Array.isArray(parameterDescriptors)) throw new TypeError("The parameterDescriptors property of given value for processorCtor is not an array.");
};
var verifyProcessorCtor = (processorCtor) => {
	if (!isConstructible(processorCtor)) throw new TypeError("The given value for processorCtor should be a constructor.");
	if (processorCtor.prototype === null || typeof processorCtor.prototype !== "object") throw new TypeError("The given value for processorCtor should have a prototype.");
};
var createAddAudioWorkletModule = (cacheTestResult, createNotSupportedError, evaluateSource, exposeCurrentFrameAndCurrentTime, fetchSource, getNativeContext, getOrCreateBackupOfflineAudioContext, isNativeOfflineAudioContext, nativeAudioWorkletNodeConstructor, ongoingRequests, resolvedRequests, testAudioWorkletProcessorPostMessageSupport, window) => {
	let index = 0;
	return (context, moduleURL, options = { credentials: "omit" }) => {
		const resolvedRequestsOfContext = resolvedRequests.get(context);
		if (resolvedRequestsOfContext !== void 0 && resolvedRequestsOfContext.has(moduleURL)) return Promise.resolve();
		const ongoingRequestsOfContext = ongoingRequests.get(context);
		if (ongoingRequestsOfContext !== void 0) {
			const promiseOfOngoingRequest = ongoingRequestsOfContext.get(moduleURL);
			if (promiseOfOngoingRequest !== void 0) return promiseOfOngoingRequest;
		}
		const nativeContext = getNativeContext(context);
		const promise = nativeContext.audioWorklet === void 0 ? fetchSource(moduleURL).then(([source, absoluteUrl]) => {
			const [importStatements, sourceWithoutImportStatements] = splitImportStatements(source, absoluteUrl);
			return evaluateSource(`${importStatements};((a,b)=>{(a[b]=a[b]||[]).push((AudioWorkletProcessor,global,registerProcessor,sampleRate,self,window)=>{${sourceWithoutImportStatements}
})})(window,'_AWGS')`);
		}).then(() => {
			const evaluateAudioWorkletGlobalScope = window._AWGS.pop();
			if (evaluateAudioWorkletGlobalScope === void 0) throw new SyntaxError();
			exposeCurrentFrameAndCurrentTime(nativeContext.currentTime, nativeContext.sampleRate, () => evaluateAudioWorkletGlobalScope(class AudioWorkletProcessor {}, void 0, (name, processorCtor) => {
				if (name.trim() === "") throw createNotSupportedError();
				const nodeNameToProcessorConstructorMap = NODE_NAME_TO_PROCESSOR_CONSTRUCTOR_MAPS.get(nativeContext);
				if (nodeNameToProcessorConstructorMap !== void 0) {
					if (nodeNameToProcessorConstructorMap.has(name)) throw createNotSupportedError();
					verifyProcessorCtor(processorCtor);
					verifyParameterDescriptors(processorCtor.parameterDescriptors);
					nodeNameToProcessorConstructorMap.set(name, processorCtor);
				} else {
					verifyProcessorCtor(processorCtor);
					verifyParameterDescriptors(processorCtor.parameterDescriptors);
					NODE_NAME_TO_PROCESSOR_CONSTRUCTOR_MAPS.set(nativeContext, /* @__PURE__ */ new Map([[name, processorCtor]]));
				}
			}, nativeContext.sampleRate, void 0, void 0));
		}) : Promise.all([fetchSource(moduleURL), Promise.resolve(cacheTestResult(testAudioWorkletProcessorPostMessageSupport, testAudioWorkletProcessorPostMessageSupport))]).then(([[source, absoluteUrl], isSupportingPostMessage]) => {
			const currentIndex = index + 1;
			index = currentIndex;
			const [importStatements, sourceWithoutImportStatements] = splitImportStatements(source, absoluteUrl);
			const wrappedSource = `${importStatements};((AudioWorkletProcessor,registerProcessor)=>{${sourceWithoutImportStatements}
})(${isSupportingPostMessage ? "AudioWorkletProcessor" : "class extends AudioWorkletProcessor {__b=new WeakSet();constructor(){super();(p=>p.postMessage=(q=>(m,t)=>q.call(p,m,t?t.filter(u=>!this.__b.has(u)):t))(p.postMessage))(this.port)}}"},(n,p)=>registerProcessor(n,class extends p{${isSupportingPostMessage ? "" : "__c = (a) => a.forEach(e=>this.__b.add(e.buffer));"}process(i,o,p){${isSupportingPostMessage ? "" : "i.forEach(this.__c);o.forEach(this.__c);this.__c(Object.values(p));"}return super.process(i.map(j=>j.some(k=>k.length===0)?[]:j),o,p)}}));registerProcessor('__sac${currentIndex}',class extends AudioWorkletProcessor{process(){return !1}})`;
			const blob = new Blob([wrappedSource], { type: "application/javascript; charset=utf-8" });
			const url = URL.createObjectURL(blob);
			return nativeContext.audioWorklet.addModule(url, options).then(() => {
				if (isNativeOfflineAudioContext(nativeContext)) return nativeContext;
				const backupOfflineAudioContext = getOrCreateBackupOfflineAudioContext(nativeContext);
				return backupOfflineAudioContext.audioWorklet.addModule(url, options).then(() => backupOfflineAudioContext);
			}).then((nativeContextOrBackupOfflineAudioContext) => {
				if (nativeAudioWorkletNodeConstructor === null) throw new SyntaxError();
				try {
					new nativeAudioWorkletNodeConstructor(nativeContextOrBackupOfflineAudioContext, `__sac${currentIndex}`);
				} catch {
					throw new SyntaxError();
				}
			}).finally(() => URL.revokeObjectURL(url));
		});
		if (ongoingRequestsOfContext === void 0) ongoingRequests.set(context, /* @__PURE__ */ new Map([[moduleURL, promise]]));
		else ongoingRequestsOfContext.set(moduleURL, promise);
		promise.then(() => {
			const updatedResolvedRequestsOfContext = resolvedRequests.get(context);
			if (updatedResolvedRequestsOfContext === void 0) resolvedRequests.set(context, /* @__PURE__ */ new Set([moduleURL]));
			else updatedResolvedRequestsOfContext.add(moduleURL);
		}).finally(() => {
			const updatedOngoingRequestsOfContext = ongoingRequests.get(context);
			if (updatedOngoingRequestsOfContext !== void 0) updatedOngoingRequestsOfContext.delete(moduleURL);
		});
		return promise;
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/get-value-for-key.js
var getValueForKey = (map, key) => {
	const value = map.get(key);
	if (value === void 0) throw new Error("A value with the given key could not be found.");
	return value;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/pick-element-from-set.js
var pickElementFromSet = (set, predicate) => {
	const matchingElements = Array.from(set).filter(predicate);
	if (matchingElements.length > 1) throw Error("More than one element was found.");
	if (matchingElements.length === 0) throw Error("No element was found.");
	const [matchingElement] = matchingElements;
	set.delete(matchingElement);
	return matchingElement;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/delete-passive-input-connection-to-audio-node.js
var deletePassiveInputConnectionToAudioNode = (passiveInputs, source, output, input) => {
	const passiveInputConnections = getValueForKey(passiveInputs, source);
	const matchingConnection = pickElementFromSet(passiveInputConnections, (passiveInputConnection) => passiveInputConnection[0] === output && passiveInputConnection[1] === input);
	if (passiveInputConnections.size === 0) passiveInputs.delete(source);
	return matchingConnection;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/get-event-listeners-of-audio-node.js
var getEventListenersOfAudioNode = (audioNode) => {
	return getValueForKey(EVENT_LISTENERS, audioNode);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/set-internal-state-to-active.js
var setInternalStateToActive = (audioNode) => {
	if (ACTIVE_AUDIO_NODE_STORE.has(audioNode)) throw new Error("The AudioNode is already stored.");
	ACTIVE_AUDIO_NODE_STORE.add(audioNode);
	getEventListenersOfAudioNode(audioNode).forEach((eventListener) => eventListener(true));
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/guards/audio-worklet-node.js
var isAudioWorkletNode = (audioNode) => {
	return "port" in audioNode;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/set-internal-state-to-passive.js
var setInternalStateToPassive = (audioNode) => {
	if (!ACTIVE_AUDIO_NODE_STORE.has(audioNode)) throw new Error("The AudioNode is not stored.");
	ACTIVE_AUDIO_NODE_STORE.delete(audioNode);
	getEventListenersOfAudioNode(audioNode).forEach((eventListener) => eventListener(false));
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/set-internal-state-to-passive-when-necessary.js
var setInternalStateToPassiveWhenNecessary = (audioNode, activeInputs) => {
	if (!isAudioWorkletNode(audioNode) && activeInputs.every((connections) => connections.size === 0)) setInternalStateToPassive(audioNode);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/add-connection-to-audio-node.js
var createAddConnectionToAudioNode = (addActiveInputConnectionToAudioNode, addPassiveInputConnectionToAudioNode, connectNativeAudioNodeToNativeAudioNode, deleteActiveInputConnectionToAudioNode, disconnectNativeAudioNodeFromNativeAudioNode, getAudioNodeConnections, getAudioNodeTailTime, getEventListenersOfAudioNode, getNativeAudioNode, insertElementInSet, isActiveAudioNode, isPartOfACycle, isPassiveAudioNode) => {
	const tailTimeTimeoutIds = /* @__PURE__ */ new WeakMap();
	return (source, destination, output, input, isOffline) => {
		const { activeInputs, passiveInputs } = getAudioNodeConnections(destination);
		const { outputs } = getAudioNodeConnections(source);
		const eventListeners = getEventListenersOfAudioNode(source);
		const eventListener = (isActive) => {
			const nativeDestinationAudioNode = getNativeAudioNode(destination);
			const nativeSourceAudioNode = getNativeAudioNode(source);
			if (isActive) {
				const partialConnection = deletePassiveInputConnectionToAudioNode(passiveInputs, source, output, input);
				addActiveInputConnectionToAudioNode(activeInputs, source, partialConnection, false);
				if (!isOffline && !isPartOfACycle(source)) connectNativeAudioNodeToNativeAudioNode(nativeSourceAudioNode, nativeDestinationAudioNode, output, input);
				if (isPassiveAudioNode(destination)) setInternalStateToActive(destination);
			} else {
				const partialConnection = deleteActiveInputConnectionToAudioNode(activeInputs, source, output, input);
				addPassiveInputConnectionToAudioNode(passiveInputs, input, partialConnection, false);
				if (!isOffline && !isPartOfACycle(source)) disconnectNativeAudioNodeFromNativeAudioNode(nativeSourceAudioNode, nativeDestinationAudioNode, output, input);
				const tailTime = getAudioNodeTailTime(destination);
				if (tailTime === 0) {
					if (isActiveAudioNode(destination)) setInternalStateToPassiveWhenNecessary(destination, activeInputs);
				} else {
					const tailTimeTimeoutId = tailTimeTimeoutIds.get(destination);
					if (tailTimeTimeoutId !== void 0) clearTimeout(tailTimeTimeoutId);
					tailTimeTimeoutIds.set(destination, setTimeout(() => {
						if (isActiveAudioNode(destination)) setInternalStateToPassiveWhenNecessary(destination, activeInputs);
					}, tailTime * 1e3));
				}
			}
		};
		if (insertElementInSet(outputs, [
			destination,
			output,
			input
		], (outputConnection) => outputConnection[0] === destination && outputConnection[1] === output && outputConnection[2] === input, true)) {
			eventListeners.add(eventListener);
			if (isActiveAudioNode(source)) addActiveInputConnectionToAudioNode(activeInputs, source, [
				output,
				input,
				eventListener
			], true);
			else addPassiveInputConnectionToAudioNode(passiveInputs, input, [
				source,
				output,
				eventListener
			], true);
			return true;
		}
		return false;
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/add-passive-input-connection-to-audio-node.js
var createAddPassiveInputConnectionToAudioNode = (insertElementInSet) => {
	return (passiveInputs, input, [source, output, eventListener], ignoreDuplicates) => {
		const passiveInputConnections = passiveInputs.get(source);
		if (passiveInputConnections === void 0) passiveInputs.set(source, /* @__PURE__ */ new Set([[
			output,
			input,
			eventListener
		]]));
		else insertElementInSet(passiveInputConnections, [
			output,
			input,
			eventListener
		], (passiveInputConnection) => passiveInputConnection[0] === output && passiveInputConnection[1] === input, ignoreDuplicates);
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/add-silent-connection.js
var createAddSilentConnection = (createNativeGainNode) => {
	return (nativeContext, nativeAudioScheduledSourceNode) => {
		const nativeGainNode = createNativeGainNode(nativeContext, {
			channelCount: 1,
			channelCountMode: "explicit",
			channelInterpretation: "discrete",
			gain: 0
		});
		nativeAudioScheduledSourceNode.connect(nativeGainNode).connect(nativeContext.destination);
		const disconnect = () => {
			nativeAudioScheduledSourceNode.removeEventListener("ended", disconnect);
			nativeAudioScheduledSourceNode.disconnect(nativeGainNode);
			nativeGainNode.disconnect();
		};
		nativeAudioScheduledSourceNode.addEventListener("ended", disconnect);
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/add-unrendered-audio-worklet-node.js
var createAddUnrenderedAudioWorkletNode = (getUnrenderedAudioWorkletNodes) => {
	return (nativeContext, audioWorkletNode) => {
		getUnrenderedAudioWorkletNodes(nativeContext).add(audioWorkletNode);
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/is-owned-by-context.js
var isOwnedByContext = (nativeAudioNode, nativeContext) => {
	return nativeAudioNode.context === nativeContext;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/test-audio-buffer-copy-channel-methods-out-of-bounds-support.js
var testAudioBufferCopyChannelMethodsOutOfBoundsSupport = (nativeAudioBuffer) => {
	try {
		nativeAudioBuffer.copyToChannel(/* @__PURE__ */ new Float32Array(1), 0, -1);
	} catch {
		return false;
	}
	return true;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/index-size-error.js
var createIndexSizeError = () => new DOMException("", "IndexSizeError");
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/wrap-audio-buffer-get-channel-data-method.js
var wrapAudioBufferGetChannelDataMethod = (audioBuffer) => {
	audioBuffer.getChannelData = ((getChannelData) => {
		return (channel) => {
			try {
				return getChannelData.call(audioBuffer, channel);
			} catch (err) {
				if (err.code === 12) throw createIndexSizeError();
				throw err;
			}
		};
	})(audioBuffer.getChannelData);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/audio-buffer-constructor.js
var DEFAULT_OPTIONS$19 = { numberOfChannels: 1 };
var createAudioBufferConstructor = (audioBufferStore, cacheTestResult, createNotSupportedError, nativeAudioBufferConstructor, nativeOfflineAudioContextConstructor, testNativeAudioBufferConstructorSupport, wrapAudioBufferCopyChannelMethods, wrapAudioBufferCopyChannelMethodsOutOfBounds) => {
	let nativeOfflineAudioContext = null;
	return class AudioBuffer {
		constructor(options) {
			if (nativeOfflineAudioContextConstructor === null) throw new Error("Missing the native OfflineAudioContext constructor.");
			const { length, numberOfChannels, sampleRate } = {
				...DEFAULT_OPTIONS$19,
				...options
			};
			if (nativeOfflineAudioContext === null) nativeOfflineAudioContext = new nativeOfflineAudioContextConstructor(1, 1, 44100);
			const audioBuffer = nativeAudioBufferConstructor !== null && cacheTestResult(testNativeAudioBufferConstructorSupport, testNativeAudioBufferConstructorSupport) ? new nativeAudioBufferConstructor({
				length,
				numberOfChannels,
				sampleRate
			}) : nativeOfflineAudioContext.createBuffer(numberOfChannels, length, sampleRate);
			if (audioBuffer.numberOfChannels === 0) throw createNotSupportedError();
			if (typeof audioBuffer.copyFromChannel !== "function") {
				wrapAudioBufferCopyChannelMethods(audioBuffer);
				wrapAudioBufferGetChannelDataMethod(audioBuffer);
			} else if (!cacheTestResult(testAudioBufferCopyChannelMethodsOutOfBoundsSupport, () => testAudioBufferCopyChannelMethodsOutOfBoundsSupport(audioBuffer))) wrapAudioBufferCopyChannelMethodsOutOfBounds(audioBuffer);
			audioBufferStore.add(audioBuffer);
			return audioBuffer;
		}
		static [Symbol.hasInstance](instance) {
			return instance !== null && typeof instance === "object" && Object.getPrototypeOf(instance) === AudioBuffer.prototype || audioBufferStore.has(instance);
		}
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/constants.js
var MOST_NEGATIVE_SINGLE_FLOAT = -34028234663852886e22;
var MOST_POSITIVE_SINGLE_FLOAT = 34028234663852886e22;
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/is-active-audio-node.js
var isActiveAudioNode = (audioNode) => ACTIVE_AUDIO_NODE_STORE.has(audioNode);
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/audio-buffer-source-node-constructor.js
var DEFAULT_OPTIONS$18 = {
	buffer: null,
	channelCount: 2,
	channelCountMode: "max",
	channelInterpretation: "speakers",
	loop: false,
	loopEnd: 0,
	loopStart: 0,
	playbackRate: 1
};
var createAudioBufferSourceNodeConstructor = (audioNodeConstructor, createAudioBufferSourceNodeRenderer, createAudioParam, createInvalidStateError, createNativeAudioBufferSourceNode, getNativeContext, isNativeOfflineAudioContext, wrapEventListener) => {
	return class AudioBufferSourceNode extends audioNodeConstructor {
		constructor(context, options) {
			const nativeContext = getNativeContext(context);
			const mergedOptions = {
				...DEFAULT_OPTIONS$18,
				...options
			};
			const nativeAudioBufferSourceNode = createNativeAudioBufferSourceNode(nativeContext, mergedOptions);
			const isOffline = isNativeOfflineAudioContext(nativeContext);
			const audioBufferSourceNodeRenderer = isOffline ? createAudioBufferSourceNodeRenderer() : null;
			super(context, false, nativeAudioBufferSourceNode, audioBufferSourceNodeRenderer);
			this._audioBufferSourceNodeRenderer = audioBufferSourceNodeRenderer;
			this._isBufferNullified = false;
			this._isBufferSet = mergedOptions.buffer !== null;
			this._nativeAudioBufferSourceNode = nativeAudioBufferSourceNode;
			this._onended = null;
			this._playbackRate = createAudioParam(this, isOffline, nativeAudioBufferSourceNode.playbackRate, MOST_POSITIVE_SINGLE_FLOAT, MOST_NEGATIVE_SINGLE_FLOAT);
		}
		get buffer() {
			if (this._isBufferNullified) return null;
			return this._nativeAudioBufferSourceNode.buffer;
		}
		set buffer(value) {
			this._nativeAudioBufferSourceNode.buffer = value;
			if (value !== null) {
				if (this._isBufferSet) throw createInvalidStateError();
				this._isBufferSet = true;
			}
		}
		get loop() {
			return this._nativeAudioBufferSourceNode.loop;
		}
		set loop(value) {
			this._nativeAudioBufferSourceNode.loop = value;
		}
		get loopEnd() {
			return this._nativeAudioBufferSourceNode.loopEnd;
		}
		set loopEnd(value) {
			this._nativeAudioBufferSourceNode.loopEnd = value;
		}
		get loopStart() {
			return this._nativeAudioBufferSourceNode.loopStart;
		}
		set loopStart(value) {
			this._nativeAudioBufferSourceNode.loopStart = value;
		}
		get onended() {
			return this._onended;
		}
		set onended(value) {
			const wrappedListener = typeof value === "function" ? wrapEventListener(this, value) : null;
			this._nativeAudioBufferSourceNode.onended = wrappedListener;
			const nativeOnEnded = this._nativeAudioBufferSourceNode.onended;
			this._onended = nativeOnEnded !== null && nativeOnEnded === wrappedListener ? value : nativeOnEnded;
		}
		get playbackRate() {
			return this._playbackRate;
		}
		start(when = 0, offset = 0, duration) {
			this._nativeAudioBufferSourceNode.start(when, offset, duration);
			if (this._audioBufferSourceNodeRenderer !== null) this._audioBufferSourceNodeRenderer.start = duration === void 0 ? [when, offset] : [
				when,
				offset,
				duration
			];
			if (this.context.state !== "closed") {
				setInternalStateToActive(this);
				const resetInternalStateToPassive = () => {
					this._nativeAudioBufferSourceNode.removeEventListener("ended", resetInternalStateToPassive);
					if (isActiveAudioNode(this)) setInternalStateToPassive(this);
				};
				this._nativeAudioBufferSourceNode.addEventListener("ended", resetInternalStateToPassive);
			}
		}
		stop(when = 0) {
			this._nativeAudioBufferSourceNode.stop(when);
			if (this._audioBufferSourceNodeRenderer !== null) this._audioBufferSourceNodeRenderer.stop = when;
		}
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/audio-buffer-source-node-renderer-factory.js
var createAudioBufferSourceNodeRendererFactory = (connectAudioParam, createNativeAudioBufferSourceNode, getNativeAudioNode, renderAutomation, renderInputsOfAudioNode) => {
	return () => {
		const renderedNativeAudioBufferSourceNodes = /* @__PURE__ */ new WeakMap();
		let start = null;
		let stop = null;
		const createAudioBufferSourceNode = async (proxy, nativeOfflineAudioContext) => {
			let nativeAudioBufferSourceNode = getNativeAudioNode(proxy);
			const nativeAudioBufferSourceNodeIsOwnedByContext = isOwnedByContext(nativeAudioBufferSourceNode, nativeOfflineAudioContext);
			if (!nativeAudioBufferSourceNodeIsOwnedByContext) {
				nativeAudioBufferSourceNode = createNativeAudioBufferSourceNode(nativeOfflineAudioContext, {
					buffer: nativeAudioBufferSourceNode.buffer,
					channelCount: nativeAudioBufferSourceNode.channelCount,
					channelCountMode: nativeAudioBufferSourceNode.channelCountMode,
					channelInterpretation: nativeAudioBufferSourceNode.channelInterpretation,
					loop: nativeAudioBufferSourceNode.loop,
					loopEnd: nativeAudioBufferSourceNode.loopEnd,
					loopStart: nativeAudioBufferSourceNode.loopStart,
					playbackRate: nativeAudioBufferSourceNode.playbackRate.value
				});
				if (start !== null) nativeAudioBufferSourceNode.start(...start);
				if (stop !== null) nativeAudioBufferSourceNode.stop(stop);
			}
			renderedNativeAudioBufferSourceNodes.set(nativeOfflineAudioContext, nativeAudioBufferSourceNode);
			if (!nativeAudioBufferSourceNodeIsOwnedByContext) await renderAutomation(nativeOfflineAudioContext, proxy.playbackRate, nativeAudioBufferSourceNode.playbackRate);
			else await connectAudioParam(nativeOfflineAudioContext, proxy.playbackRate, nativeAudioBufferSourceNode.playbackRate);
			await renderInputsOfAudioNode(proxy, nativeOfflineAudioContext, nativeAudioBufferSourceNode);
			return nativeAudioBufferSourceNode;
		};
		return {
			set start(value) {
				start = value;
			},
			set stop(value) {
				stop = value;
			},
			render(proxy, nativeOfflineAudioContext) {
				const renderedNativeAudioBufferSourceNode = renderedNativeAudioBufferSourceNodes.get(nativeOfflineAudioContext);
				if (renderedNativeAudioBufferSourceNode !== void 0) return Promise.resolve(renderedNativeAudioBufferSourceNode);
				return createAudioBufferSourceNode(proxy, nativeOfflineAudioContext);
			}
		};
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/guards/audio-buffer-source-node.js
var isAudioBufferSourceNode = (audioNode) => {
	return "playbackRate" in audioNode;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/guards/biquad-filter-node.js
var isBiquadFilterNode = (audioNode) => {
	return "frequency" in audioNode && "gain" in audioNode;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/guards/constant-source-node.js
var isConstantSourceNode = (audioNode) => {
	return "offset" in audioNode;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/guards/gain-node.js
var isGainNode = (audioNode) => {
	return !("frequency" in audioNode) && "gain" in audioNode;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/guards/oscillator-node.js
var isOscillatorNode = (audioNode) => {
	return "detune" in audioNode && "frequency" in audioNode && !("gain" in audioNode);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/guards/stereo-panner-node.js
var isStereoPannerNode = (audioNode) => {
	return "pan" in audioNode;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/get-audio-node-connections.js
var getAudioNodeConnections = (audioNode) => {
	return getValueForKey(AUDIO_NODE_CONNECTIONS_STORE, audioNode);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/get-audio-param-connections.js
var getAudioParamConnections = (audioParam) => {
	return getValueForKey(AUDIO_PARAM_CONNECTIONS_STORE, audioParam);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/deactivate-active-audio-node-input-connections.js
var deactivateActiveAudioNodeInputConnections = (audioNode, trace) => {
	const { activeInputs } = getAudioNodeConnections(audioNode);
	activeInputs.forEach((connections) => connections.forEach(([source]) => {
		if (!trace.includes(audioNode)) deactivateActiveAudioNodeInputConnections(source, [...trace, audioNode]);
	}));
	const audioParams = isAudioBufferSourceNode(audioNode) ? [audioNode.playbackRate] : isAudioWorkletNode(audioNode) ? Array.from(audioNode.parameters.values()) : isBiquadFilterNode(audioNode) ? [
		audioNode.Q,
		audioNode.detune,
		audioNode.frequency,
		audioNode.gain
	] : isConstantSourceNode(audioNode) ? [audioNode.offset] : isGainNode(audioNode) ? [audioNode.gain] : isOscillatorNode(audioNode) ? [audioNode.detune, audioNode.frequency] : isStereoPannerNode(audioNode) ? [audioNode.pan] : [];
	for (const audioParam of audioParams) {
		const audioParamConnections = getAudioParamConnections(audioParam);
		if (audioParamConnections !== void 0) audioParamConnections.activeInputs.forEach(([source]) => deactivateActiveAudioNodeInputConnections(source, trace));
	}
	if (isActiveAudioNode(audioNode)) setInternalStateToPassive(audioNode);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/deactivate-audio-graph.js
var deactivateAudioGraph = (context) => {
	deactivateActiveAudioNodeInputConnections(context.destination, []);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/is-valid-latency-hint.js
var isValidLatencyHint = (latencyHint) => {
	return latencyHint === void 0 || typeof latencyHint === "number" || typeof latencyHint === "string" && (latencyHint === "balanced" || latencyHint === "interactive" || latencyHint === "playback");
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/audio-destination-node-constructor.js
var createAudioDestinationNodeConstructor = (audioNodeConstructor, createAudioDestinationNodeRenderer, createIndexSizeError, createInvalidStateError, createNativeAudioDestinationNode, getNativeContext, isNativeOfflineAudioContext, renderInputsOfAudioNode) => {
	return class AudioDestinationNode extends audioNodeConstructor {
		constructor(context, channelCount) {
			const nativeContext = getNativeContext(context);
			const isOffline = isNativeOfflineAudioContext(nativeContext);
			const nativeAudioDestinationNode = createNativeAudioDestinationNode(nativeContext, channelCount, isOffline);
			const audioDestinationNodeRenderer = isOffline ? createAudioDestinationNodeRenderer(renderInputsOfAudioNode) : null;
			super(context, false, nativeAudioDestinationNode, audioDestinationNodeRenderer);
			this._isNodeOfNativeOfflineAudioContext = isOffline;
			this._nativeAudioDestinationNode = nativeAudioDestinationNode;
		}
		get channelCount() {
			return this._nativeAudioDestinationNode.channelCount;
		}
		set channelCount(value) {
			if (this._isNodeOfNativeOfflineAudioContext) throw createInvalidStateError();
			if (value > this._nativeAudioDestinationNode.maxChannelCount) throw createIndexSizeError();
			this._nativeAudioDestinationNode.channelCount = value;
		}
		get channelCountMode() {
			return this._nativeAudioDestinationNode.channelCountMode;
		}
		set channelCountMode(value) {
			if (this._isNodeOfNativeOfflineAudioContext) throw createInvalidStateError();
			this._nativeAudioDestinationNode.channelCountMode = value;
		}
		get maxChannelCount() {
			return this._nativeAudioDestinationNode.maxChannelCount;
		}
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/audio-destination-node-renderer-factory.js
var createAudioDestinationNodeRenderer = (renderInputsOfAudioNode) => {
	const renderedNativeAudioDestinationNodes = /* @__PURE__ */ new WeakMap();
	const createAudioDestinationNode = async (proxy, nativeOfflineAudioContext) => {
		const nativeAudioDestinationNode = nativeOfflineAudioContext.destination;
		renderedNativeAudioDestinationNodes.set(nativeOfflineAudioContext, nativeAudioDestinationNode);
		await renderInputsOfAudioNode(proxy, nativeOfflineAudioContext, nativeAudioDestinationNode);
		return nativeAudioDestinationNode;
	};
	return { render(proxy, nativeOfflineAudioContext) {
		const renderedNativeAudioDestinationNode = renderedNativeAudioDestinationNodes.get(nativeOfflineAudioContext);
		if (renderedNativeAudioDestinationNode !== void 0) return Promise.resolve(renderedNativeAudioDestinationNode);
		return createAudioDestinationNode(proxy, nativeOfflineAudioContext);
	} };
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/audio-listener-factory.js
var createAudioListenerFactory = (createAudioParam, createNativeChannelMergerNode, createNativeConstantSourceNode, createNativeScriptProcessorNode, createNotSupportedError, getFirstSample, isNativeOfflineAudioContext, overwriteAccessors) => {
	return (context, nativeContext) => {
		const nativeListener = nativeContext.listener;
		const createFakeAudioParams = () => {
			const buffer = /* @__PURE__ */ new Float32Array(1);
			const channelMergerNode = createNativeChannelMergerNode(nativeContext, {
				channelCount: 1,
				channelCountMode: "explicit",
				channelInterpretation: "speakers",
				numberOfInputs: 9
			});
			const isOffline = isNativeOfflineAudioContext(nativeContext);
			let isScriptProcessorNodeCreated = false;
			let lastOrientation = [
				0,
				0,
				-1,
				0,
				1,
				0
			];
			let lastPosition = [
				0,
				0,
				0
			];
			const createScriptProcessorNode = () => {
				if (isScriptProcessorNodeCreated) return;
				isScriptProcessorNodeCreated = true;
				const scriptProcessorNode = createNativeScriptProcessorNode(nativeContext, 256, 9, 0);
				scriptProcessorNode.onaudioprocess = ({ inputBuffer }) => {
					const orientation = [
						getFirstSample(inputBuffer, buffer, 0),
						getFirstSample(inputBuffer, buffer, 1),
						getFirstSample(inputBuffer, buffer, 2),
						getFirstSample(inputBuffer, buffer, 3),
						getFirstSample(inputBuffer, buffer, 4),
						getFirstSample(inputBuffer, buffer, 5)
					];
					if (orientation.some((value, index) => value !== lastOrientation[index])) {
						nativeListener.setOrientation(...orientation);
						lastOrientation = orientation;
					}
					const positon = [
						getFirstSample(inputBuffer, buffer, 6),
						getFirstSample(inputBuffer, buffer, 7),
						getFirstSample(inputBuffer, buffer, 8)
					];
					if (positon.some((value, index) => value !== lastPosition[index])) {
						nativeListener.setPosition(...positon);
						lastPosition = positon;
					}
				};
				channelMergerNode.connect(scriptProcessorNode);
			};
			const createSetOrientation = (index) => (value) => {
				if (value !== lastOrientation[index]) {
					lastOrientation[index] = value;
					nativeListener.setOrientation(...lastOrientation);
				}
			};
			const createSetPosition = (index) => (value) => {
				if (value !== lastPosition[index]) {
					lastPosition[index] = value;
					nativeListener.setPosition(...lastPosition);
				}
			};
			const createFakeAudioParam = (input, initialValue, setValue) => {
				const constantSourceNode = createNativeConstantSourceNode(nativeContext, {
					channelCount: 1,
					channelCountMode: "explicit",
					channelInterpretation: "discrete",
					offset: initialValue
				});
				constantSourceNode.connect(channelMergerNode, 0, input);
				constantSourceNode.start();
				Object.defineProperty(constantSourceNode.offset, "defaultValue", { get() {
					return initialValue;
				} });
				const audioParam = createAudioParam({ context }, isOffline, constantSourceNode.offset, MOST_POSITIVE_SINGLE_FLOAT, MOST_NEGATIVE_SINGLE_FLOAT);
				overwriteAccessors(audioParam, "value", (get) => () => get.call(audioParam), (set) => (value) => {
					try {
						set.call(audioParam, value);
					} catch (err) {
						if (err.code !== 9) throw err;
					}
					createScriptProcessorNode();
					if (isOffline) setValue(value);
				});
				audioParam.cancelAndHoldAtTime = ((cancelAndHoldAtTime) => {
					if (isOffline) return () => {
						throw createNotSupportedError();
					};
					return (...args) => {
						const value = cancelAndHoldAtTime.apply(audioParam, args);
						createScriptProcessorNode();
						return value;
					};
				})(audioParam.cancelAndHoldAtTime);
				audioParam.cancelScheduledValues = ((cancelScheduledValues) => {
					if (isOffline) return () => {
						throw createNotSupportedError();
					};
					return (...args) => {
						const value = cancelScheduledValues.apply(audioParam, args);
						createScriptProcessorNode();
						return value;
					};
				})(audioParam.cancelScheduledValues);
				audioParam.exponentialRampToValueAtTime = ((exponentialRampToValueAtTime) => {
					if (isOffline) return () => {
						throw createNotSupportedError();
					};
					return (...args) => {
						const value = exponentialRampToValueAtTime.apply(audioParam, args);
						createScriptProcessorNode();
						return value;
					};
				})(audioParam.exponentialRampToValueAtTime);
				audioParam.linearRampToValueAtTime = ((linearRampToValueAtTime) => {
					if (isOffline) return () => {
						throw createNotSupportedError();
					};
					return (...args) => {
						const value = linearRampToValueAtTime.apply(audioParam, args);
						createScriptProcessorNode();
						return value;
					};
				})(audioParam.linearRampToValueAtTime);
				audioParam.setTargetAtTime = ((setTargetAtTime) => {
					if (isOffline) return () => {
						throw createNotSupportedError();
					};
					return (...args) => {
						const value = setTargetAtTime.apply(audioParam, args);
						createScriptProcessorNode();
						return value;
					};
				})(audioParam.setTargetAtTime);
				audioParam.setValueAtTime = ((setValueAtTime) => {
					if (isOffline) return () => {
						throw createNotSupportedError();
					};
					return (...args) => {
						const value = setValueAtTime.apply(audioParam, args);
						createScriptProcessorNode();
						return value;
					};
				})(audioParam.setValueAtTime);
				audioParam.setValueCurveAtTime = ((setValueCurveAtTime) => {
					if (isOffline) return () => {
						throw createNotSupportedError();
					};
					return (...args) => {
						const value = setValueCurveAtTime.apply(audioParam, args);
						createScriptProcessorNode();
						return value;
					};
				})(audioParam.setValueCurveAtTime);
				return audioParam;
			};
			return {
				forwardX: createFakeAudioParam(0, 0, createSetOrientation(0)),
				forwardY: createFakeAudioParam(1, 0, createSetOrientation(1)),
				forwardZ: createFakeAudioParam(2, -1, createSetOrientation(2)),
				positionX: createFakeAudioParam(6, 0, createSetPosition(0)),
				positionY: createFakeAudioParam(7, 0, createSetPosition(1)),
				positionZ: createFakeAudioParam(8, 0, createSetPosition(2)),
				upX: createFakeAudioParam(3, 0, createSetOrientation(3)),
				upY: createFakeAudioParam(4, 1, createSetOrientation(4)),
				upZ: createFakeAudioParam(5, 0, createSetOrientation(5))
			};
		};
		const { forwardX, forwardY, forwardZ, positionX, positionY, positionZ, upX, upY, upZ } = nativeListener.forwardX === void 0 ? createFakeAudioParams() : nativeListener;
		return {
			get forwardX() {
				return forwardX;
			},
			get forwardY() {
				return forwardY;
			},
			get forwardZ() {
				return forwardZ;
			},
			get positionX() {
				return positionX;
			},
			get positionY() {
				return positionY;
			},
			get positionZ() {
				return positionZ;
			},
			get upX() {
				return upX;
			},
			get upY() {
				return upY;
			},
			get upZ() {
				return upZ;
			}
		};
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/guards/audio-node.js
var isAudioNode = (audioNodeOrAudioParam) => {
	return "context" in audioNodeOrAudioParam;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/guards/audio-node-output-connection.js
var isAudioNodeOutputConnection = (outputConnection) => {
	return isAudioNode(outputConnection[0]);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/insert-element-in-set.js
var insertElementInSet = (set, element, predicate, ignoreDuplicates) => {
	for (const lmnt of set) if (predicate(lmnt)) {
		if (ignoreDuplicates) return false;
		throw Error("The set contains at least one similar element.");
	}
	set.add(element);
	return true;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/add-active-input-connection-to-audio-param.js
var addActiveInputConnectionToAudioParam = (activeInputs, source, [output, eventListener], ignoreDuplicates) => {
	insertElementInSet(activeInputs, [
		source,
		output,
		eventListener
	], (activeInputConnection) => activeInputConnection[0] === source && activeInputConnection[1] === output, ignoreDuplicates);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/add-passive-input-connection-to-audio-param.js
var addPassiveInputConnectionToAudioParam = (passiveInputs, [source, output, eventListener], ignoreDuplicates) => {
	const passiveInputConnections = passiveInputs.get(source);
	if (passiveInputConnections === void 0) passiveInputs.set(source, /* @__PURE__ */ new Set([[output, eventListener]]));
	else insertElementInSet(passiveInputConnections, [output, eventListener], (passiveInputConnection) => passiveInputConnection[0] === output, ignoreDuplicates);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/guards/native-audio-node-faker.js
var isNativeAudioNodeFaker = (nativeAudioNodeOrNativeAudioNodeFaker) => {
	return "inputs" in nativeAudioNodeOrNativeAudioNodeFaker;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/connect-native-audio-node-to-native-audio-node.js
var connectNativeAudioNodeToNativeAudioNode = (nativeSourceAudioNode, nativeDestinationAudioNode, output, input) => {
	if (isNativeAudioNodeFaker(nativeDestinationAudioNode)) {
		const fakeNativeDestinationAudioNode = nativeDestinationAudioNode.inputs[input];
		nativeSourceAudioNode.connect(fakeNativeDestinationAudioNode, output, 0);
		return [
			fakeNativeDestinationAudioNode,
			output,
			0
		];
	}
	nativeSourceAudioNode.connect(nativeDestinationAudioNode, output, input);
	return [
		nativeDestinationAudioNode,
		output,
		input
	];
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/delete-active-input-connection.js
var deleteActiveInputConnection = (activeInputConnections, source, output) => {
	for (const activeInputConnection of activeInputConnections) if (activeInputConnection[0] === source && activeInputConnection[1] === output) {
		activeInputConnections.delete(activeInputConnection);
		return activeInputConnection;
	}
	return null;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/delete-active-input-connection-to-audio-param.js
var deleteActiveInputConnectionToAudioParam = (activeInputs, source, output) => {
	return pickElementFromSet(activeInputs, (activeInputConnection) => activeInputConnection[0] === source && activeInputConnection[1] === output);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/delete-event-listeners-of-audio-node.js
var deleteEventListenerOfAudioNode = (audioNode, eventListener) => {
	if (!getEventListenersOfAudioNode(audioNode).delete(eventListener)) throw new Error("Missing the expected event listener.");
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/delete-passive-input-connection-to-audio-param.js
var deletePassiveInputConnectionToAudioParam = (passiveInputs, source, output) => {
	const passiveInputConnections = getValueForKey(passiveInputs, source);
	const matchingConnection = pickElementFromSet(passiveInputConnections, (passiveInputConnection) => passiveInputConnection[0] === output);
	if (passiveInputConnections.size === 0) passiveInputs.delete(source);
	return matchingConnection;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/disconnect-native-audio-node-from-native-audio-node.js
var disconnectNativeAudioNodeFromNativeAudioNode = (nativeSourceAudioNode, nativeDestinationAudioNode, output, input) => {
	if (isNativeAudioNodeFaker(nativeDestinationAudioNode)) nativeSourceAudioNode.disconnect(nativeDestinationAudioNode.inputs[input], output, 0);
	else nativeSourceAudioNode.disconnect(nativeDestinationAudioNode, output, input);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/get-native-audio-node.js
var getNativeAudioNode = (audioNode) => {
	return getValueForKey(AUDIO_NODE_STORE, audioNode);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/get-native-audio-param.js
var getNativeAudioParam = (audioParam) => {
	return getValueForKey(AUDIO_PARAM_STORE, audioParam);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/is-part-of-a-cycle.js
var isPartOfACycle = (audioNode) => {
	return CYCLE_COUNTERS.has(audioNode);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/is-passive-audio-node.js
var isPassiveAudioNode = (audioNode) => {
	return !ACTIVE_AUDIO_NODE_STORE.has(audioNode);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/test-audio-node-disconnect-method-support.js
var testAudioNodeDisconnectMethodSupport = (nativeAudioContext, nativeAudioWorkletNodeConstructor) => {
	return new Promise((resolve) => {
		if (nativeAudioWorkletNodeConstructor !== null) resolve(true);
		else {
			const analyzer = nativeAudioContext.createScriptProcessor(256, 1, 1);
			const dummy = nativeAudioContext.createGain();
			const ones = nativeAudioContext.createBuffer(1, 2, 44100);
			const channelData = ones.getChannelData(0);
			channelData[0] = 1;
			channelData[1] = 1;
			const source = nativeAudioContext.createBufferSource();
			source.buffer = ones;
			source.loop = true;
			source.connect(analyzer).connect(nativeAudioContext.destination);
			source.connect(dummy);
			source.disconnect(dummy);
			analyzer.onaudioprocess = (event) => {
				const chnnlDt = event.inputBuffer.getChannelData(0);
				if (Array.prototype.some.call(chnnlDt, (sample) => sample === 1)) resolve(true);
				else resolve(false);
				source.stop();
				analyzer.onaudioprocess = null;
				source.disconnect(analyzer);
				analyzer.disconnect(nativeAudioContext.destination);
			};
			source.start();
		}
	});
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/visit-each-audio-node-once.js
var visitEachAudioNodeOnce = (cycles, visitor) => {
	const counts = /* @__PURE__ */ new Map();
	for (const cycle of cycles) for (const audioNode of cycle) {
		const count = counts.get(audioNode);
		counts.set(audioNode, count === void 0 ? 1 : count + 1);
	}
	counts.forEach((count, audioNode) => visitor(audioNode, count));
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/guards/native-audio-node.js
var isNativeAudioNode$1 = /* @__PURE__ */ __name((nativeAudioNodeOrAudioParam) => {
	return "context" in nativeAudioNodeOrAudioParam;
}, "isNativeAudioNode");
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/wrap-audio-node-disconnect-method.js
var wrapAudioNodeDisconnectMethod = (nativeAudioNode) => {
	const connections = /* @__PURE__ */ new Map();
	nativeAudioNode.connect = ((connect) => {
		return (destination, output = 0, input = 0) => {
			const returnValue = isNativeAudioNode$1(destination) ? connect(destination, output, input) : connect(destination, output);
			const connectionsToDestination = connections.get(destination);
			if (connectionsToDestination === void 0) connections.set(destination, [{
				input,
				output
			}]);
			else if (connectionsToDestination.every((connection) => connection.input !== input || connection.output !== output)) connectionsToDestination.push({
				input,
				output
			});
			return returnValue;
		};
	})(nativeAudioNode.connect.bind(nativeAudioNode));
	nativeAudioNode.disconnect = ((disconnect) => {
		return (destinationOrOutput, output, input) => {
			disconnect.apply(nativeAudioNode);
			if (destinationOrOutput === void 0) connections.clear();
			else if (typeof destinationOrOutput === "number") for (const [destination, connectionsToDestination] of connections) {
				const filteredConnections = connectionsToDestination.filter((connection) => connection.output !== destinationOrOutput);
				if (filteredConnections.length === 0) connections.delete(destination);
				else connections.set(destination, filteredConnections);
			}
			else if (connections.has(destinationOrOutput)) {
				if (output === void 0) connections.delete(destinationOrOutput);
				else {
					const connectionsToDestination = connections.get(destinationOrOutput);
					if (connectionsToDestination !== void 0) {
						const filteredConnections = connectionsToDestination.filter((connection) => connection.output !== output && (connection.input !== input || input === void 0));
						if (filteredConnections.length === 0) connections.delete(destinationOrOutput);
						else connections.set(destinationOrOutput, filteredConnections);
					}
				}
			}
			for (const [destination, connectionsToDestination] of connections) connectionsToDestination.forEach((connection) => {
				if (isNativeAudioNode$1(destination)) nativeAudioNode.connect(destination, connection.output, connection.input);
				else nativeAudioNode.connect(destination, connection.output);
			});
		};
	})(nativeAudioNode.disconnect);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/audio-node-constructor.js
var addConnectionToAudioParamOfAudioContext = (source, destination, output, isOffline) => {
	const { activeInputs, passiveInputs } = getAudioParamConnections(destination);
	const { outputs } = getAudioNodeConnections(source);
	const eventListeners = getEventListenersOfAudioNode(source);
	const eventListener = (isActive) => {
		const nativeAudioNode = getNativeAudioNode(source);
		const nativeAudioParam = getNativeAudioParam(destination);
		if (isActive) {
			const partialConnection = deletePassiveInputConnectionToAudioParam(passiveInputs, source, output);
			addActiveInputConnectionToAudioParam(activeInputs, source, partialConnection, false);
			if (!isOffline && !isPartOfACycle(source)) nativeAudioNode.connect(nativeAudioParam, output);
		} else {
			const partialConnection = deleteActiveInputConnectionToAudioParam(activeInputs, source, output);
			addPassiveInputConnectionToAudioParam(passiveInputs, partialConnection, false);
			if (!isOffline && !isPartOfACycle(source)) nativeAudioNode.disconnect(nativeAudioParam, output);
		}
	};
	if (insertElementInSet(outputs, [destination, output], (outputConnection) => outputConnection[0] === destination && outputConnection[1] === output, true)) {
		eventListeners.add(eventListener);
		if (isActiveAudioNode(source)) addActiveInputConnectionToAudioParam(activeInputs, source, [output, eventListener], true);
		else addPassiveInputConnectionToAudioParam(passiveInputs, [
			source,
			output,
			eventListener
		], true);
		return true;
	}
	return false;
};
var deleteInputConnectionOfAudioNode = (source, destination, output, input) => {
	const { activeInputs, passiveInputs } = getAudioNodeConnections(destination);
	const activeInputConnection = deleteActiveInputConnection(activeInputs[input], source, output);
	if (activeInputConnection === null) return [deletePassiveInputConnectionToAudioNode(passiveInputs, source, output, input)[2], false];
	return [activeInputConnection[2], true];
};
var deleteInputConnectionOfAudioParam = (source, destination, output) => {
	const { activeInputs, passiveInputs } = getAudioParamConnections(destination);
	const activeInputConnection = deleteActiveInputConnection(activeInputs, source, output);
	if (activeInputConnection === null) return [deletePassiveInputConnectionToAudioParam(passiveInputs, source, output)[1], false];
	return [activeInputConnection[2], true];
};
var deleteInputsOfAudioNode = (source, isOffline, destination, output, input) => {
	const [listener, isActive] = deleteInputConnectionOfAudioNode(source, destination, output, input);
	if (listener !== null) {
		deleteEventListenerOfAudioNode(source, listener);
		if (isActive && !isOffline && !isPartOfACycle(source)) disconnectNativeAudioNodeFromNativeAudioNode(getNativeAudioNode(source), getNativeAudioNode(destination), output, input);
	}
	if (isActiveAudioNode(destination)) {
		const { activeInputs } = getAudioNodeConnections(destination);
		setInternalStateToPassiveWhenNecessary(destination, activeInputs);
	}
};
var deleteInputsOfAudioParam = (source, isOffline, destination, output) => {
	const [listener, isActive] = deleteInputConnectionOfAudioParam(source, destination, output);
	if (listener !== null) {
		deleteEventListenerOfAudioNode(source, listener);
		if (isActive && !isOffline && !isPartOfACycle(source)) getNativeAudioNode(source).disconnect(getNativeAudioParam(destination), output);
	}
};
var deleteAnyConnection = (source, isOffline) => {
	const audioNodeConnectionsOfSource = getAudioNodeConnections(source);
	const destinations = [];
	for (const outputConnection of audioNodeConnectionsOfSource.outputs) {
		if (isAudioNodeOutputConnection(outputConnection)) deleteInputsOfAudioNode(source, isOffline, ...outputConnection);
		else deleteInputsOfAudioParam(source, isOffline, ...outputConnection);
		destinations.push(outputConnection[0]);
	}
	audioNodeConnectionsOfSource.outputs.clear();
	return destinations;
};
var deleteConnectionAtOutput = (source, isOffline, output) => {
	const audioNodeConnectionsOfSource = getAudioNodeConnections(source);
	const destinations = [];
	for (const outputConnection of audioNodeConnectionsOfSource.outputs) if (outputConnection[1] === output) {
		if (isAudioNodeOutputConnection(outputConnection)) deleteInputsOfAudioNode(source, isOffline, ...outputConnection);
		else deleteInputsOfAudioParam(source, isOffline, ...outputConnection);
		destinations.push(outputConnection[0]);
		audioNodeConnectionsOfSource.outputs.delete(outputConnection);
	}
	return destinations;
};
var deleteConnectionToDestination = (source, isOffline, destination, output, input) => {
	const audioNodeConnectionsOfSource = getAudioNodeConnections(source);
	return Array.from(audioNodeConnectionsOfSource.outputs).filter((outputConnection) => outputConnection[0] === destination && (output === void 0 || outputConnection[1] === output) && (input === void 0 || outputConnection[2] === input)).map((outputConnection) => {
		if (isAudioNodeOutputConnection(outputConnection)) deleteInputsOfAudioNode(source, isOffline, ...outputConnection);
		else deleteInputsOfAudioParam(source, isOffline, ...outputConnection);
		audioNodeConnectionsOfSource.outputs.delete(outputConnection);
		return outputConnection[0];
	});
};
var createAudioNodeConstructor = (addAudioNodeConnections, addConnectionToAudioNode, cacheTestResult, createIncrementCycleCounter, createIndexSizeError, createInvalidAccessError, createNotSupportedError, decrementCycleCounter, detectCycles, eventTargetConstructor, getNativeContext, isNativeAudioContext, isNativeAudioNode, isNativeAudioParam, isNativeOfflineAudioContext, nativeAudioWorkletNodeConstructor) => {
	return class AudioNode extends eventTargetConstructor {
		constructor(context, isActive, nativeAudioNode, audioNodeRenderer) {
			super(nativeAudioNode);
			this._context = context;
			this._nativeAudioNode = nativeAudioNode;
			const nativeContext = getNativeContext(context);
			if (isNativeAudioContext(nativeContext) && true !== cacheTestResult(testAudioNodeDisconnectMethodSupport, () => {
				return testAudioNodeDisconnectMethodSupport(nativeContext, nativeAudioWorkletNodeConstructor);
			})) wrapAudioNodeDisconnectMethod(nativeAudioNode);
			AUDIO_NODE_STORE.set(this, nativeAudioNode);
			EVENT_LISTENERS.set(this, /* @__PURE__ */ new Set());
			if (context.state !== "closed" && isActive) setInternalStateToActive(this);
			addAudioNodeConnections(this, audioNodeRenderer, nativeAudioNode);
		}
		get channelCount() {
			return this._nativeAudioNode.channelCount;
		}
		set channelCount(value) {
			this._nativeAudioNode.channelCount = value;
		}
		get channelCountMode() {
			return this._nativeAudioNode.channelCountMode;
		}
		set channelCountMode(value) {
			this._nativeAudioNode.channelCountMode = value;
		}
		get channelInterpretation() {
			return this._nativeAudioNode.channelInterpretation;
		}
		set channelInterpretation(value) {
			this._nativeAudioNode.channelInterpretation = value;
		}
		get context() {
			return this._context;
		}
		get numberOfInputs() {
			return this._nativeAudioNode.numberOfInputs;
		}
		get numberOfOutputs() {
			return this._nativeAudioNode.numberOfOutputs;
		}
		connect(destination, output = 0, input = 0) {
			if (output < 0 || output >= this._nativeAudioNode.numberOfOutputs) throw createIndexSizeError();
			const isOffline = isNativeOfflineAudioContext(getNativeContext(this._context));
			if (isNativeAudioNode(destination) || isNativeAudioParam(destination)) throw createInvalidAccessError();
			if (isAudioNode(destination)) {
				const nativeDestinationAudioNode = getNativeAudioNode(destination);
				try {
					const connection = connectNativeAudioNodeToNativeAudioNode(this._nativeAudioNode, nativeDestinationAudioNode, output, input);
					const isPassive = isPassiveAudioNode(this);
					if (isOffline || isPassive) this._nativeAudioNode.disconnect(...connection);
					if (this.context.state !== "closed" && !isPassive && isPassiveAudioNode(destination)) setInternalStateToActive(destination);
				} catch (err) {
					if (err.code === 12) throw createInvalidAccessError();
					throw err;
				}
				if (addConnectionToAudioNode(this, destination, output, input, isOffline)) visitEachAudioNodeOnce(detectCycles([this], destination), createIncrementCycleCounter(isOffline));
				return destination;
			}
			const nativeAudioParam = getNativeAudioParam(destination);
			if (nativeAudioParam.name === "playbackRate" && nativeAudioParam.maxValue === 1024) throw createNotSupportedError();
			try {
				this._nativeAudioNode.connect(nativeAudioParam, output);
				if (isOffline || isPassiveAudioNode(this)) this._nativeAudioNode.disconnect(nativeAudioParam, output);
			} catch (err) {
				if (err.code === 12) throw createInvalidAccessError();
				throw err;
			}
			if (addConnectionToAudioParamOfAudioContext(this, destination, output, isOffline)) visitEachAudioNodeOnce(detectCycles([this], destination), createIncrementCycleCounter(isOffline));
		}
		disconnect(destinationOrOutput, output, input) {
			let destinations;
			const isOffline = isNativeOfflineAudioContext(getNativeContext(this._context));
			if (destinationOrOutput === void 0) destinations = deleteAnyConnection(this, isOffline);
			else if (typeof destinationOrOutput === "number") {
				if (destinationOrOutput < 0 || destinationOrOutput >= this.numberOfOutputs) throw createIndexSizeError();
				destinations = deleteConnectionAtOutput(this, isOffline, destinationOrOutput);
			} else {
				if (output !== void 0 && (output < 0 || output >= this.numberOfOutputs)) throw createIndexSizeError();
				if (isAudioNode(destinationOrOutput) && input !== void 0 && (input < 0 || input >= destinationOrOutput.numberOfInputs)) throw createIndexSizeError();
				destinations = deleteConnectionToDestination(this, isOffline, destinationOrOutput, output, input);
				if (destinations.length === 0) throw createInvalidAccessError();
			}
			for (const destination of destinations) visitEachAudioNodeOnce(detectCycles([this], destination), decrementCycleCounter);
		}
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/audio-param-factory.js
var createAudioParamFactory = (addAudioParamConnections, audioParamAudioNodeStore, audioParamStore, createAudioParamRenderer, createCancelAndHoldAutomationEvent, createCancelScheduledValuesAutomationEvent, createExponentialRampToValueAutomationEvent, createLinearRampToValueAutomationEvent, createSetTargetAutomationEvent, createSetValueAutomationEvent, createSetValueCurveAutomationEvent, nativeAudioContextConstructor, setValueAtTimeUntilPossible) => {
	return (audioNode, isAudioParamOfOfflineAudioContext, nativeAudioParam, maxValue = null, minValue = null) => {
		const defaultValue = nativeAudioParam.value;
		const automationEventList = new import_bundle$1.AutomationEventList(defaultValue);
		const audioParamRenderer = isAudioParamOfOfflineAudioContext ? createAudioParamRenderer(automationEventList) : null;
		const audioParam = {
			get defaultValue() {
				return defaultValue;
			},
			get maxValue() {
				return maxValue === null ? nativeAudioParam.maxValue : maxValue;
			},
			get minValue() {
				return minValue === null ? nativeAudioParam.minValue : minValue;
			},
			get value() {
				return nativeAudioParam.value;
			},
			set value(value) {
				nativeAudioParam.value = value;
				audioParam.setValueAtTime(value, audioNode.context.currentTime);
			},
			cancelAndHoldAtTime(cancelTime) {
				if (typeof nativeAudioParam.cancelAndHoldAtTime === "function") {
					if (audioParamRenderer === null) automationEventList.flush(audioNode.context.currentTime);
					automationEventList.add(createCancelAndHoldAutomationEvent(cancelTime));
					nativeAudioParam.cancelAndHoldAtTime(cancelTime);
				} else {
					const previousLastEvent = Array.from(automationEventList).pop();
					if (audioParamRenderer === null) automationEventList.flush(audioNode.context.currentTime);
					automationEventList.add(createCancelAndHoldAutomationEvent(cancelTime));
					const currentLastEvent = Array.from(automationEventList).pop();
					nativeAudioParam.cancelScheduledValues(cancelTime);
					if (previousLastEvent !== currentLastEvent && currentLastEvent !== void 0) {
						if (currentLastEvent.type === "exponentialRampToValue") nativeAudioParam.exponentialRampToValueAtTime(currentLastEvent.value, currentLastEvent.endTime);
						else if (currentLastEvent.type === "linearRampToValue") nativeAudioParam.linearRampToValueAtTime(currentLastEvent.value, currentLastEvent.endTime);
						else if (currentLastEvent.type === "setValue") nativeAudioParam.setValueAtTime(currentLastEvent.value, currentLastEvent.startTime);
						else if (currentLastEvent.type === "setValueCurve") nativeAudioParam.setValueCurveAtTime(currentLastEvent.values, currentLastEvent.startTime, currentLastEvent.duration);
					}
				}
				return audioParam;
			},
			cancelScheduledValues(cancelTime) {
				if (audioParamRenderer === null) automationEventList.flush(audioNode.context.currentTime);
				automationEventList.add(createCancelScheduledValuesAutomationEvent(cancelTime));
				nativeAudioParam.cancelScheduledValues(cancelTime);
				return audioParam;
			},
			exponentialRampToValueAtTime(value, endTime) {
				if (value === 0) throw new RangeError();
				if (!Number.isFinite(endTime) || endTime < 0) throw new RangeError();
				const currentTime = audioNode.context.currentTime;
				if (audioParamRenderer === null) automationEventList.flush(currentTime);
				if (Array.from(automationEventList).length === 0) {
					automationEventList.add(createSetValueAutomationEvent(defaultValue, currentTime));
					nativeAudioParam.setValueAtTime(defaultValue, currentTime);
				}
				automationEventList.add(createExponentialRampToValueAutomationEvent(value, endTime));
				nativeAudioParam.exponentialRampToValueAtTime(value, endTime);
				return audioParam;
			},
			linearRampToValueAtTime(value, endTime) {
				const currentTime = audioNode.context.currentTime;
				if (audioParamRenderer === null) automationEventList.flush(currentTime);
				if (Array.from(automationEventList).length === 0) {
					automationEventList.add(createSetValueAutomationEvent(defaultValue, currentTime));
					nativeAudioParam.setValueAtTime(defaultValue, currentTime);
				}
				automationEventList.add(createLinearRampToValueAutomationEvent(value, endTime));
				nativeAudioParam.linearRampToValueAtTime(value, endTime);
				return audioParam;
			},
			setTargetAtTime(target, startTime, timeConstant) {
				if (audioParamRenderer === null) automationEventList.flush(audioNode.context.currentTime);
				automationEventList.add(createSetTargetAutomationEvent(target, startTime, timeConstant));
				nativeAudioParam.setTargetAtTime(target, startTime, timeConstant);
				return audioParam;
			},
			setValueAtTime(value, startTime) {
				if (audioParamRenderer === null) automationEventList.flush(audioNode.context.currentTime);
				automationEventList.add(createSetValueAutomationEvent(value, startTime));
				nativeAudioParam.setValueAtTime(value, startTime);
				return audioParam;
			},
			setValueCurveAtTime(values, startTime, duration) {
				const convertedValues = values instanceof Float32Array ? values : new Float32Array(values);
				if (nativeAudioContextConstructor !== null && nativeAudioContextConstructor.name === "webkitAudioContext") {
					const endTime = startTime + duration;
					const sampleRate = audioNode.context.sampleRate;
					const firstSample = Math.ceil(startTime * sampleRate);
					const lastSample = Math.floor(endTime * sampleRate);
					const numberOfInterpolatedValues = lastSample - firstSample;
					const interpolatedValues = new Float32Array(numberOfInterpolatedValues);
					for (let i = 0; i < numberOfInterpolatedValues; i += 1) {
						const theoreticIndex = (convertedValues.length - 1) / duration * ((firstSample + i) / sampleRate - startTime);
						const lowerIndex = Math.floor(theoreticIndex);
						const upperIndex = Math.ceil(theoreticIndex);
						interpolatedValues[i] = lowerIndex === upperIndex ? convertedValues[lowerIndex] : (1 - (theoreticIndex - lowerIndex)) * convertedValues[lowerIndex] + (1 - (upperIndex - theoreticIndex)) * convertedValues[upperIndex];
					}
					if (audioParamRenderer === null) automationEventList.flush(audioNode.context.currentTime);
					automationEventList.add(createSetValueCurveAutomationEvent(interpolatedValues, startTime, duration));
					nativeAudioParam.setValueCurveAtTime(interpolatedValues, startTime, duration);
					const timeOfLastSample = lastSample / sampleRate;
					if (timeOfLastSample < endTime) setValueAtTimeUntilPossible(audioParam, interpolatedValues[interpolatedValues.length - 1], timeOfLastSample);
					setValueAtTimeUntilPossible(audioParam, convertedValues[convertedValues.length - 1], endTime);
				} else {
					if (audioParamRenderer === null) automationEventList.flush(audioNode.context.currentTime);
					automationEventList.add(createSetValueCurveAutomationEvent(convertedValues, startTime, duration));
					nativeAudioParam.setValueCurveAtTime(convertedValues, startTime, duration);
				}
				return audioParam;
			}
		};
		audioParamStore.set(audioParam, nativeAudioParam);
		audioParamAudioNodeStore.set(audioParam, audioNode);
		addAudioParamConnections(audioParam, audioParamRenderer);
		return audioParam;
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/audio-param-renderer.js
var createAudioParamRenderer = (automationEventList) => {
	return { replay(audioParam) {
		for (const automationEvent of automationEventList) if (automationEvent.type === "exponentialRampToValue") {
			const { endTime, value } = automationEvent;
			audioParam.exponentialRampToValueAtTime(value, endTime);
		} else if (automationEvent.type === "linearRampToValue") {
			const { endTime, value } = automationEvent;
			audioParam.linearRampToValueAtTime(value, endTime);
		} else if (automationEvent.type === "setTarget") {
			const { startTime, target, timeConstant } = automationEvent;
			audioParam.setTargetAtTime(target, startTime, timeConstant);
		} else if (automationEvent.type === "setValue") {
			const { startTime, value } = automationEvent;
			audioParam.setValueAtTime(value, startTime);
		} else if (automationEvent.type === "setValueCurve") {
			const { duration, startTime, values } = automationEvent;
			audioParam.setValueCurveAtTime(values, startTime, duration);
		} else throw new Error("Can't apply an unknown automation.");
	} };
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/read-only-map.js
var ReadOnlyMap = class {
	constructor(parameters) {
		this._map = new Map(parameters);
	}
	get size() {
		return this._map.size;
	}
	entries() {
		return this._map.entries();
	}
	forEach(callback, thisArg = null) {
		return this._map.forEach((value, key) => callback.call(thisArg, value, key, this));
	}
	get(name) {
		return this._map.get(name);
	}
	has(name) {
		return this._map.has(name);
	}
	keys() {
		return this._map.keys();
	}
	values() {
		return this._map.values();
	}
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/audio-worklet-node-constructor.js
var DEFAULT_OPTIONS$17 = {
	channelCount: 2,
	channelCountMode: "explicit",
	channelInterpretation: "speakers",
	numberOfInputs: 1,
	numberOfOutputs: 1,
	parameterData: {},
	processorOptions: {}
};
var createAudioWorkletNodeConstructor = (addUnrenderedAudioWorkletNode, audioNodeConstructor, createAudioParam, createAudioWorkletNodeRenderer, createNativeAudioWorkletNode, getAudioNodeConnections, getBackupOfflineAudioContext, getNativeContext, isNativeOfflineAudioContext, nativeAudioWorkletNodeConstructor, sanitizeAudioWorkletNodeOptions, setActiveAudioWorkletNodeInputs, testAudioWorkletNodeOptionsClonability, wrapEventListener) => {
	return class AudioWorkletNode extends audioNodeConstructor {
		constructor(context, name, options) {
			var _a;
			const nativeContext = getNativeContext(context);
			const isOffline = isNativeOfflineAudioContext(nativeContext);
			const mergedOptions = sanitizeAudioWorkletNodeOptions({
				...DEFAULT_OPTIONS$17,
				...options
			});
			testAudioWorkletNodeOptionsClonability(mergedOptions);
			const nodeNameToProcessorConstructorMap = NODE_NAME_TO_PROCESSOR_CONSTRUCTOR_MAPS.get(nativeContext);
			const processorConstructor = nodeNameToProcessorConstructorMap === null || nodeNameToProcessorConstructorMap === void 0 ? void 0 : nodeNameToProcessorConstructorMap.get(name);
			const nativeAudioWorkletNode = createNativeAudioWorkletNode(isOffline || nativeContext.state !== "closed" ? nativeContext : (_a = getBackupOfflineAudioContext(nativeContext)) !== null && _a !== void 0 ? _a : nativeContext, isOffline ? null : context.baseLatency, nativeAudioWorkletNodeConstructor, name, processorConstructor, mergedOptions);
			const audioWorkletNodeRenderer = isOffline ? createAudioWorkletNodeRenderer(name, mergedOptions, processorConstructor) : null;
			super(context, true, nativeAudioWorkletNode, audioWorkletNodeRenderer);
			const parameters = [];
			nativeAudioWorkletNode.parameters.forEach((nativeAudioParam, nm) => {
				const audioParam = createAudioParam(this, isOffline, nativeAudioParam);
				parameters.push([nm, audioParam]);
			});
			this._nativeAudioWorkletNode = nativeAudioWorkletNode;
			this._onprocessorerror = null;
			this._parameters = new ReadOnlyMap(parameters);
			if (isOffline) addUnrenderedAudioWorkletNode(nativeContext, this);
			const { activeInputs } = getAudioNodeConnections(this);
			setActiveAudioWorkletNodeInputs(nativeAudioWorkletNode, activeInputs);
		}
		get onprocessorerror() {
			return this._onprocessorerror;
		}
		set onprocessorerror(value) {
			const wrappedListener = typeof value === "function" ? wrapEventListener(this, value) : null;
			this._nativeAudioWorkletNode.onprocessorerror = wrappedListener;
			const nativeOnProcessorError = this._nativeAudioWorkletNode.onprocessorerror;
			this._onprocessorerror = nativeOnProcessorError !== null && nativeOnProcessorError === wrappedListener ? value : nativeOnProcessorError;
		}
		get parameters() {
			if (this._parameters === null) return this._nativeAudioWorkletNode.parameters;
			return this._parameters;
		}
		get port() {
			return this._nativeAudioWorkletNode.port;
		}
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/copy-from-channel.js
function copyFromChannel(audioBuffer, parent, key, channelNumber, bufferOffset) {
	if (typeof audioBuffer.copyFromChannel === "function") {
		if (parent[key].byteLength === 0) parent[key] = /* @__PURE__ */ new Float32Array(128);
		audioBuffer.copyFromChannel(parent[key], channelNumber, bufferOffset);
	} else {
		const channelData = audioBuffer.getChannelData(channelNumber);
		if (parent[key].byteLength === 0) parent[key] = channelData.slice(bufferOffset, bufferOffset + 128);
		else {
			const slicedInput = new Float32Array(channelData.buffer, bufferOffset * Float32Array.BYTES_PER_ELEMENT, 128);
			parent[key].set(slicedInput);
		}
	}
}
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/copy-to-channel.js
var copyToChannel = (audioBuffer, parent, key, channelNumber, bufferOffset) => {
	if (typeof audioBuffer.copyToChannel === "function") {
		if (parent[key].byteLength !== 0) audioBuffer.copyToChannel(parent[key], channelNumber, bufferOffset);
	} else if (parent[key].byteLength !== 0) audioBuffer.getChannelData(channelNumber).set(parent[key], bufferOffset);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/create-nested-arrays.js
var createNestedArrays = (x, y) => {
	const arrays = [];
	for (let i = 0; i < x; i += 1) {
		const array = [];
		const length = typeof y === "number" ? y : y[i];
		for (let j = 0; j < length; j += 1) array.push(/* @__PURE__ */ new Float32Array(128));
		arrays.push(array);
	}
	return arrays;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/get-audio-worklet-processor.js
var getAudioWorkletProcessor = (nativeOfflineAudioContext, proxy) => {
	return getValueForKey(getValueForKey(NODE_TO_PROCESSOR_MAPS, nativeOfflineAudioContext), getNativeAudioNode(proxy));
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/audio-worklet-node-renderer-factory.js
var processBuffer = async (proxy, renderedBuffer, nativeOfflineAudioContext, options, outputChannelCount, processorConstructor, exposeCurrentFrameAndCurrentTime) => {
	const length = renderedBuffer === null ? Math.ceil(proxy.context.length / 128) * 128 : renderedBuffer.length;
	const numberOfInputChannels = options.channelCount * options.numberOfInputs;
	const numberOfOutputChannels = outputChannelCount.reduce((sum, value) => sum + value, 0);
	const processedBuffer = numberOfOutputChannels === 0 ? null : nativeOfflineAudioContext.createBuffer(numberOfOutputChannels, length, nativeOfflineAudioContext.sampleRate);
	if (processorConstructor === void 0) throw new Error("Missing the processor constructor.");
	const audioNodeConnections = getAudioNodeConnections(proxy);
	const audioWorkletProcessor = await getAudioWorkletProcessor(nativeOfflineAudioContext, proxy);
	const inputs = createNestedArrays(options.numberOfInputs, options.channelCount);
	const outputs = createNestedArrays(options.numberOfOutputs, outputChannelCount);
	const parameters = Array.from(proxy.parameters.keys()).reduce((prmtrs, name) => ({
		...prmtrs,
		[name]: /* @__PURE__ */ new Float32Array(128)
	}), {});
	for (let i = 0; i < length; i += 128) {
		if (options.numberOfInputs > 0 && renderedBuffer !== null) for (let j = 0; j < options.numberOfInputs; j += 1) for (let k = 0; k < options.channelCount; k += 1) copyFromChannel(renderedBuffer, inputs[j], k, k, i);
		if (processorConstructor.parameterDescriptors !== void 0 && renderedBuffer !== null) processorConstructor.parameterDescriptors.forEach(({ name }, index) => {
			copyFromChannel(renderedBuffer, parameters, name, numberOfInputChannels + index, i);
		});
		for (let j = 0; j < options.numberOfInputs; j += 1) for (let k = 0; k < outputChannelCount[j]; k += 1) if (outputs[j][k].byteLength === 0) outputs[j][k] = /* @__PURE__ */ new Float32Array(128);
		try {
			const potentiallyEmptyInputs = inputs.map((input, index) => {
				if (audioNodeConnections.activeInputs[index].size === 0) return [];
				return input;
			});
			const activeSourceFlag = exposeCurrentFrameAndCurrentTime(i / nativeOfflineAudioContext.sampleRate, nativeOfflineAudioContext.sampleRate, () => audioWorkletProcessor.process(potentiallyEmptyInputs, outputs, parameters));
			if (processedBuffer !== null) for (let j = 0, outputChannelSplitterNodeOutput = 0; j < options.numberOfOutputs; j += 1) {
				for (let k = 0; k < outputChannelCount[j]; k += 1) copyToChannel(processedBuffer, outputs[j], k, outputChannelSplitterNodeOutput + k, i);
				outputChannelSplitterNodeOutput += outputChannelCount[j];
			}
			if (!activeSourceFlag) break;
		} catch (error) {
			proxy.dispatchEvent(new ErrorEvent("processorerror", {
				colno: error.colno,
				filename: error.filename,
				lineno: error.lineno,
				message: error.message
			}));
			break;
		}
	}
	return processedBuffer;
};
var createAudioWorkletNodeRendererFactory = (connectAudioParam, connectMultipleOutputs, createNativeAudioBufferSourceNode, createNativeChannelMergerNode, createNativeChannelSplitterNode, createNativeConstantSourceNode, createNativeGainNode, deleteUnrenderedAudioWorkletNode, disconnectMultipleOutputs, exposeCurrentFrameAndCurrentTime, getNativeAudioNode, nativeAudioWorkletNodeConstructor, nativeOfflineAudioContextConstructor, renderAutomation, renderInputsOfAudioNode, renderNativeOfflineAudioContext) => {
	return (name, options, processorConstructor) => {
		const renderedNativeAudioNodes = /* @__PURE__ */ new WeakMap();
		let processedBufferPromise = null;
		const createAudioNode = async (proxy, nativeOfflineAudioContext) => {
			let nativeAudioWorkletNode = getNativeAudioNode(proxy);
			let nativeOutputNodes = null;
			const nativeAudioWorkletNodeIsOwnedByContext = isOwnedByContext(nativeAudioWorkletNode, nativeOfflineAudioContext);
			const outputChannelCount = Array.isArray(options.outputChannelCount) ? options.outputChannelCount : Array.from(options.outputChannelCount);
			if (nativeAudioWorkletNodeConstructor === null) {
				const numberOfOutputChannels = outputChannelCount.reduce((sum, value) => sum + value, 0);
				const outputChannelSplitterNode = createNativeChannelSplitterNode(nativeOfflineAudioContext, {
					channelCount: Math.max(1, numberOfOutputChannels),
					channelCountMode: "explicit",
					channelInterpretation: "discrete",
					numberOfOutputs: Math.max(1, numberOfOutputChannels)
				});
				const outputChannelMergerNodes = [];
				for (let i = 0; i < proxy.numberOfOutputs; i += 1) outputChannelMergerNodes.push(createNativeChannelMergerNode(nativeOfflineAudioContext, {
					channelCount: 1,
					channelCountMode: "explicit",
					channelInterpretation: "speakers",
					numberOfInputs: outputChannelCount[i]
				}));
				const outputGainNode = createNativeGainNode(nativeOfflineAudioContext, {
					channelCount: options.channelCount,
					channelCountMode: options.channelCountMode,
					channelInterpretation: options.channelInterpretation,
					gain: 1
				});
				outputGainNode.connect = connectMultipleOutputs.bind(null, outputChannelMergerNodes);
				outputGainNode.disconnect = disconnectMultipleOutputs.bind(null, outputChannelMergerNodes);
				nativeOutputNodes = [
					outputChannelSplitterNode,
					outputChannelMergerNodes,
					outputGainNode
				];
			} else if (!nativeAudioWorkletNodeIsOwnedByContext) nativeAudioWorkletNode = new nativeAudioWorkletNodeConstructor(nativeOfflineAudioContext, name);
			renderedNativeAudioNodes.set(nativeOfflineAudioContext, nativeOutputNodes === null ? nativeAudioWorkletNode : nativeOutputNodes[2]);
			if (nativeOutputNodes !== null) {
				if (processedBufferPromise === null) {
					if (processorConstructor === void 0) throw new Error("Missing the processor constructor.");
					if (nativeOfflineAudioContextConstructor === null) throw new Error("Missing the native OfflineAudioContext constructor.");
					const numberOfInputChannels = proxy.channelCount * proxy.numberOfInputs;
					const numberOfParameters = processorConstructor.parameterDescriptors === void 0 ? 0 : processorConstructor.parameterDescriptors.length;
					const numberOfChannels = numberOfInputChannels + numberOfParameters;
					const renderBuffer = async () => {
						const partialOfflineAudioContext = new nativeOfflineAudioContextConstructor(numberOfChannels, Math.ceil(proxy.context.length / 128) * 128, nativeOfflineAudioContext.sampleRate);
						const gainNodes = [];
						const inputChannelSplitterNodes = [];
						for (let i = 0; i < options.numberOfInputs; i += 1) {
							gainNodes.push(createNativeGainNode(partialOfflineAudioContext, {
								channelCount: options.channelCount,
								channelCountMode: options.channelCountMode,
								channelInterpretation: options.channelInterpretation,
								gain: 1
							}));
							inputChannelSplitterNodes.push(createNativeChannelSplitterNode(partialOfflineAudioContext, {
								channelCount: options.channelCount,
								channelCountMode: "explicit",
								channelInterpretation: "discrete",
								numberOfOutputs: options.channelCount
							}));
						}
						const constantSourceNodes = await Promise.all(Array.from(proxy.parameters.values()).map(async (audioParam) => {
							const constantSourceNode = createNativeConstantSourceNode(partialOfflineAudioContext, {
								channelCount: 1,
								channelCountMode: "explicit",
								channelInterpretation: "discrete",
								offset: audioParam.value
							});
							await renderAutomation(partialOfflineAudioContext, audioParam, constantSourceNode.offset);
							return constantSourceNode;
						}));
						const inputChannelMergerNode = createNativeChannelMergerNode(partialOfflineAudioContext, {
							channelCount: 1,
							channelCountMode: "explicit",
							channelInterpretation: "speakers",
							numberOfInputs: Math.max(1, numberOfInputChannels + numberOfParameters)
						});
						for (let i = 0; i < options.numberOfInputs; i += 1) {
							gainNodes[i].connect(inputChannelSplitterNodes[i]);
							for (let j = 0; j < options.channelCount; j += 1) inputChannelSplitterNodes[i].connect(inputChannelMergerNode, j, i * options.channelCount + j);
						}
						for (const [index, constantSourceNode] of constantSourceNodes.entries()) {
							constantSourceNode.connect(inputChannelMergerNode, 0, numberOfInputChannels + index);
							constantSourceNode.start(0);
						}
						inputChannelMergerNode.connect(partialOfflineAudioContext.destination);
						await Promise.all(gainNodes.map((gainNode) => renderInputsOfAudioNode(proxy, partialOfflineAudioContext, gainNode)));
						return renderNativeOfflineAudioContext(partialOfflineAudioContext);
					};
					processedBufferPromise = processBuffer(proxy, numberOfChannels === 0 ? null : await renderBuffer(), nativeOfflineAudioContext, options, outputChannelCount, processorConstructor, exposeCurrentFrameAndCurrentTime);
				}
				const processedBuffer = await processedBufferPromise;
				const audioBufferSourceNode = createNativeAudioBufferSourceNode(nativeOfflineAudioContext, {
					buffer: null,
					channelCount: 2,
					channelCountMode: "max",
					channelInterpretation: "speakers",
					loop: false,
					loopEnd: 0,
					loopStart: 0,
					playbackRate: 1
				});
				const [outputChannelSplitterNode, outputChannelMergerNodes, outputGainNode] = nativeOutputNodes;
				if (processedBuffer !== null) {
					audioBufferSourceNode.buffer = processedBuffer;
					audioBufferSourceNode.start(0);
				}
				audioBufferSourceNode.connect(outputChannelSplitterNode);
				for (let i = 0, outputChannelSplitterNodeOutput = 0; i < proxy.numberOfOutputs; i += 1) {
					const outputChannelMergerNode = outputChannelMergerNodes[i];
					for (let j = 0; j < outputChannelCount[i]; j += 1) outputChannelSplitterNode.connect(outputChannelMergerNode, outputChannelSplitterNodeOutput + j, j);
					outputChannelSplitterNodeOutput += outputChannelCount[i];
				}
				return outputGainNode;
			}
			if (!nativeAudioWorkletNodeIsOwnedByContext) for (const [nm, audioParam] of proxy.parameters.entries()) await renderAutomation(nativeOfflineAudioContext, audioParam, nativeAudioWorkletNode.parameters.get(nm));
			else for (const [nm, audioParam] of proxy.parameters.entries()) await connectAudioParam(nativeOfflineAudioContext, audioParam, nativeAudioWorkletNode.parameters.get(nm));
			await renderInputsOfAudioNode(proxy, nativeOfflineAudioContext, nativeAudioWorkletNode);
			return nativeAudioWorkletNode;
		};
		return { render(proxy, nativeOfflineAudioContext) {
			deleteUnrenderedAudioWorkletNode(nativeOfflineAudioContext, proxy);
			const renderedNativeAudioWorkletNodeOrGainNode = renderedNativeAudioNodes.get(nativeOfflineAudioContext);
			if (renderedNativeAudioWorkletNodeOrGainNode !== void 0) return Promise.resolve(renderedNativeAudioWorkletNodeOrGainNode);
			return createAudioNode(proxy, nativeOfflineAudioContext);
		} };
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/cache-test-result.js
var createCacheTestResult = (ongoingTests, testResults) => {
	return (tester, test) => {
		const cachedTestResult = testResults.get(tester);
		if (cachedTestResult !== void 0) return cachedTestResult;
		const ongoingTest = ongoingTests.get(tester);
		if (ongoingTest !== void 0) return ongoingTest;
		try {
			const synchronousTestResult = test();
			if (synchronousTestResult instanceof Promise) {
				ongoingTests.set(tester, synchronousTestResult);
				return synchronousTestResult.catch(() => false).then((finalTestResult) => {
					ongoingTests.delete(tester);
					testResults.set(tester, finalTestResult);
					return finalTestResult;
				});
			}
			testResults.set(tester, synchronousTestResult);
			return synchronousTestResult;
		} catch {
			testResults.set(tester, false);
			return false;
		}
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/connect-audio-param.js
var createConnectAudioParam = (renderInputsOfAudioParam) => {
	return (nativeOfflineAudioContext, audioParam, nativeAudioParam) => {
		return renderInputsOfAudioParam(audioParam, nativeOfflineAudioContext, nativeAudioParam);
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/connect-multiple-outputs.js
var createConnectMultipleOutputs = (createIndexSizeError) => {
	return (outputAudioNodes, destination, output = 0, input = 0) => {
		const outputAudioNode = outputAudioNodes[output];
		if (outputAudioNode === void 0) throw createIndexSizeError();
		if (isNativeAudioNode$1(destination)) return outputAudioNode.connect(destination, 0, input);
		return outputAudioNode.connect(destination, 0);
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/connected-native-audio-buffer-source-node-factory.js
var createConnectedNativeAudioBufferSourceNodeFactory = (createNativeAudioBufferSourceNode) => {
	return (nativeContext, nativeAudioNode) => {
		const nativeAudioBufferSourceNode = createNativeAudioBufferSourceNode(nativeContext, {
			buffer: null,
			channelCount: 2,
			channelCountMode: "max",
			channelInterpretation: "speakers",
			loop: false,
			loopEnd: 0,
			loopStart: 0,
			playbackRate: 1
		});
		nativeAudioBufferSourceNode.buffer = nativeContext.createBuffer(1, 2, 44100);
		nativeAudioBufferSourceNode.loop = true;
		nativeAudioBufferSourceNode.connect(nativeAudioNode);
		nativeAudioBufferSourceNode.start();
		return () => {
			nativeAudioBufferSourceNode.stop();
			nativeAudioBufferSourceNode.disconnect(nativeAudioNode);
		};
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/convert-number-to-unsigned-long.js
var createConvertNumberToUnsignedLong = (unit32Array) => {
	return (value) => {
		unit32Array[0] = value;
		return unit32Array[0];
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/decrement-cycle-counter.js
var createDecrementCycleCounter = (connectNativeAudioNodeToNativeAudioNode, cycleCounters, getAudioNodeConnections, getNativeAudioNode, getNativeAudioParam, getNativeContext, isActiveAudioNode, isNativeOfflineAudioContext) => {
	return (audioNode, count) => {
		const cycleCounter = cycleCounters.get(audioNode);
		if (cycleCounter === void 0) throw new Error("Missing the expected cycle count.");
		const isOffline = isNativeOfflineAudioContext(getNativeContext(audioNode.context));
		if (cycleCounter === count) {
			cycleCounters.delete(audioNode);
			if (!isOffline && isActiveAudioNode(audioNode)) {
				const nativeSourceAudioNode = getNativeAudioNode(audioNode);
				const { outputs } = getAudioNodeConnections(audioNode);
				for (const output of outputs) if (isAudioNodeOutputConnection(output)) connectNativeAudioNodeToNativeAudioNode(nativeSourceAudioNode, getNativeAudioNode(output[0]), output[1], output[2]);
				else {
					const nativeDestinationAudioParam = getNativeAudioParam(output[0]);
					nativeSourceAudioNode.connect(nativeDestinationAudioParam, output[1]);
				}
			}
		} else cycleCounters.set(audioNode, cycleCounter - count);
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/delete-active-input-connection-to-audio-node.js
var createDeleteActiveInputConnectionToAudioNode = (pickElementFromSet) => {
	return (activeInputs, source, output, input) => {
		return pickElementFromSet(activeInputs[input], (activeInputConnection) => activeInputConnection[0] === source && activeInputConnection[1] === output);
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/delete-unrendered-audio-worklet-node.js
var createDeleteUnrenderedAudioWorkletNode = (getUnrenderedAudioWorkletNodes) => {
	return (nativeContext, audioWorkletNode) => {
		getUnrenderedAudioWorkletNodes(nativeContext).delete(audioWorkletNode);
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/guards/delay-node.js
var isDelayNode = (audioNode) => {
	return "delayTime" in audioNode;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/detect-cycles.js
var createDetectCycles = (audioParamAudioNodeStore, getAudioNodeConnections, getValueForKey) => {
	return function detectCycles(chain, nextLink) {
		const audioNode = isAudioNode(nextLink) ? nextLink : getValueForKey(audioParamAudioNodeStore, nextLink);
		if (isDelayNode(audioNode)) return [];
		if (chain[0] === audioNode) return [chain];
		if (chain.includes(audioNode)) return [];
		const { outputs } = getAudioNodeConnections(audioNode);
		return Array.from(outputs).map((outputConnection) => detectCycles([...chain, audioNode], outputConnection[0])).reduce((mergedCycles, nestedCycles) => mergedCycles.concat(nestedCycles), []);
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/disconnect-multiple-outputs.js
var getOutputAudioNodeAtIndex = (createIndexSizeError, outputAudioNodes, output) => {
	const outputAudioNode = outputAudioNodes[output];
	if (outputAudioNode === void 0) throw createIndexSizeError();
	return outputAudioNode;
};
var createDisconnectMultipleOutputs = (createIndexSizeError) => {
	return (outputAudioNodes, destinationOrOutput = void 0, output = void 0, input = 0) => {
		if (destinationOrOutput === void 0) return outputAudioNodes.forEach((outputAudioNode) => outputAudioNode.disconnect());
		if (typeof destinationOrOutput === "number") return getOutputAudioNodeAtIndex(createIndexSizeError, outputAudioNodes, destinationOrOutput).disconnect();
		if (isNativeAudioNode$1(destinationOrOutput)) {
			if (output === void 0) return outputAudioNodes.forEach((outputAudioNode) => outputAudioNode.disconnect(destinationOrOutput));
			if (input === void 0) return getOutputAudioNodeAtIndex(createIndexSizeError, outputAudioNodes, output).disconnect(destinationOrOutput, 0);
			return getOutputAudioNodeAtIndex(createIndexSizeError, outputAudioNodes, output).disconnect(destinationOrOutput, 0, input);
		}
		if (output === void 0) return outputAudioNodes.forEach((outputAudioNode) => outputAudioNode.disconnect(destinationOrOutput));
		return getOutputAudioNodeAtIndex(createIndexSizeError, outputAudioNodes, output).disconnect(destinationOrOutput, 0);
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/evaluate-source.js
var createEvaluateSource = (window) => {
	return (source) => new Promise((resolve, reject) => {
		if (window === null) {
			reject(/* @__PURE__ */ new SyntaxError());
			return;
		}
		const head = window.document.head;
		if (head === null) reject(/* @__PURE__ */ new SyntaxError());
		else {
			const script = window.document.createElement("script");
			const blob = new Blob([source], { type: "application/javascript" });
			const url = URL.createObjectURL(blob);
			const originalOnErrorHandler = window.onerror;
			const removeErrorEventListenerAndRevokeUrl = () => {
				window.onerror = originalOnErrorHandler;
				URL.revokeObjectURL(url);
			};
			window.onerror = (message, src, lineno, colno, error) => {
				if (src === url || src === window.location.href && lineno === 1 && colno === 1) {
					removeErrorEventListenerAndRevokeUrl();
					reject(error);
					return false;
				}
				if (originalOnErrorHandler !== null) return originalOnErrorHandler(message, src, lineno, colno, error);
			};
			script.onerror = () => {
				removeErrorEventListenerAndRevokeUrl();
				reject(/* @__PURE__ */ new SyntaxError());
			};
			script.onload = () => {
				removeErrorEventListenerAndRevokeUrl();
				resolve();
			};
			script.src = url;
			script.type = "module";
			head.appendChild(script);
		}
	});
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/event-target-constructor.js
var createEventTargetConstructor = (wrapEventListener) => {
	return class EventTarget {
		constructor(_nativeEventTarget) {
			this._nativeEventTarget = _nativeEventTarget;
			this._listeners = /* @__PURE__ */ new WeakMap();
		}
		addEventListener(type, listener, options) {
			if (listener !== null) {
				let wrappedEventListener = this._listeners.get(listener);
				if (wrappedEventListener === void 0) {
					wrappedEventListener = wrapEventListener(this, listener);
					if (typeof listener === "function") this._listeners.set(listener, wrappedEventListener);
				}
				this._nativeEventTarget.addEventListener(type, wrappedEventListener, options);
			}
		}
		dispatchEvent(event) {
			return this._nativeEventTarget.dispatchEvent(event);
		}
		removeEventListener(type, listener, options) {
			const wrappedEventListener = listener === null ? void 0 : this._listeners.get(listener);
			this._nativeEventTarget.removeEventListener(type, wrappedEventListener === void 0 ? null : wrappedEventListener, options);
		}
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/expose-current-frame-and-current-time.js
var createExposeCurrentFrameAndCurrentTime = (window) => {
	return (currentTime, sampleRate, fn) => {
		Object.defineProperties(window, {
			currentFrame: {
				configurable: true,
				get() {
					return Math.round(currentTime * sampleRate);
				}
			},
			currentTime: {
				configurable: true,
				get() {
					return currentTime;
				}
			}
		});
		try {
			return fn();
		} finally {
			if (window !== null) {
				delete window.currentFrame;
				delete window.currentTime;
			}
		}
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/fetch-source.js
var createFetchSource = (createAbortError) => {
	return async (url) => {
		try {
			const response = await fetch(url);
			if (response.ok) return [await response.text(), response.url];
		} catch {}
		throw createAbortError();
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/get-active-audio-worklet-node-inputs.js
var createGetActiveAudioWorkletNodeInputs = (activeAudioWorkletNodeInputsStore, getValueForKey) => {
	return (nativeAudioWorkletNode) => getValueForKey(activeAudioWorkletNodeInputsStore, nativeAudioWorkletNode);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/get-audio-node-renderer.js
var createGetAudioNodeRenderer = (getAudioNodeConnections) => {
	return (audioNode) => {
		const audioNodeConnections = getAudioNodeConnections(audioNode);
		if (audioNodeConnections.renderer === null) throw new Error("Missing the renderer of the given AudioNode in the audio graph.");
		return audioNodeConnections.renderer;
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/get-audio-node-tail-time.js
var createGetAudioNodeTailTime = (audioNodeTailTimeStore) => {
	return (audioNode) => {
		var _a;
		return (_a = audioNodeTailTimeStore.get(audioNode)) !== null && _a !== void 0 ? _a : 0;
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/get-audio-param-renderer.js
var createGetAudioParamRenderer = (getAudioParamConnections) => {
	return (audioParam) => {
		const audioParamConnections = getAudioParamConnections(audioParam);
		if (audioParamConnections.renderer === null) throw new Error("Missing the renderer of the given AudioParam in the audio graph.");
		return audioParamConnections.renderer;
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/get-backup-offline-audio-context.js
var createGetBackupOfflineAudioContext = (backupOfflineAudioContextStore) => {
	return (nativeContext) => {
		return backupOfflineAudioContextStore.get(nativeContext);
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/invalid-state-error.js
var createInvalidStateError = () => new DOMException("", "InvalidStateError");
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/get-native-context.js
var createGetNativeContext = (contextStore) => {
	return (context) => {
		const nativeContext = contextStore.get(context);
		if (nativeContext === void 0) throw createInvalidStateError();
		return nativeContext;
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/get-or-create-backup-offline-audio-context.js
var createGetOrCreateBackupOfflineAudioContext = (backupOfflineAudioContextStore, nativeOfflineAudioContextConstructor) => {
	return (nativeContext) => {
		let backupOfflineAudioContext = backupOfflineAudioContextStore.get(nativeContext);
		if (backupOfflineAudioContext !== void 0) return backupOfflineAudioContext;
		if (nativeOfflineAudioContextConstructor === null) throw new Error("Missing the native OfflineAudioContext constructor.");
		backupOfflineAudioContext = new nativeOfflineAudioContextConstructor(1, 1, 44100);
		backupOfflineAudioContextStore.set(nativeContext, backupOfflineAudioContext);
		return backupOfflineAudioContext;
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/get-unrendered-audio-worklet-nodes.js
var createGetUnrenderedAudioWorkletNodes = (unrenderedAudioWorkletNodeStore) => {
	return (nativeContext) => {
		const unrenderedAudioWorkletNodes = unrenderedAudioWorkletNodeStore.get(nativeContext);
		if (unrenderedAudioWorkletNodes === void 0) throw new Error("The context has no set of AudioWorkletNodes.");
		return unrenderedAudioWorkletNodes;
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/invalid-access-error.js
var createInvalidAccessError = () => new DOMException("", "InvalidAccessError");
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/increment-cycle-counter-factory.js
var createIncrementCycleCounterFactory = (cycleCounters, disconnectNativeAudioNodeFromNativeAudioNode, getAudioNodeConnections, getNativeAudioNode, getNativeAudioParam, isActiveAudioNode) => {
	return (isOffline) => {
		return (audioNode, count) => {
			const cycleCounter = cycleCounters.get(audioNode);
			if (cycleCounter === void 0) {
				if (!isOffline && isActiveAudioNode(audioNode)) {
					const nativeSourceAudioNode = getNativeAudioNode(audioNode);
					const { outputs } = getAudioNodeConnections(audioNode);
					for (const output of outputs) if (isAudioNodeOutputConnection(output)) disconnectNativeAudioNodeFromNativeAudioNode(nativeSourceAudioNode, getNativeAudioNode(output[0]), output[1], output[2]);
					else {
						const nativeDestinationAudioParam = getNativeAudioParam(output[0]);
						nativeSourceAudioNode.disconnect(nativeDestinationAudioParam, output[1]);
					}
				}
				cycleCounters.set(audioNode, count);
			} else cycleCounters.set(audioNode, cycleCounter + count);
		};
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/is-native-audio-context.js
var createIsNativeAudioContext = (nativeAudioContextConstructor) => {
	return (anything) => {
		return nativeAudioContextConstructor !== null && anything instanceof nativeAudioContextConstructor;
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/is-native-audio-node.js
var createIsNativeAudioNode = (window) => {
	return (anything) => {
		return window !== null && typeof window.AudioNode === "function" && anything instanceof window.AudioNode;
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/is-native-audio-param.js
var createIsNativeAudioParam = (window) => {
	return (anything) => {
		return window !== null && typeof window.AudioParam === "function" && anything instanceof window.AudioParam;
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/is-native-offline-audio-context.js
var createIsNativeOfflineAudioContext = (nativeOfflineAudioContextConstructor) => {
	return (anything) => {
		return nativeOfflineAudioContextConstructor !== null && anything instanceof nativeOfflineAudioContextConstructor;
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/is-secure-context.js
var createIsSecureContext = (window) => window !== null && window.isSecureContext;
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/media-stream-audio-source-node-constructor.js
var createMediaStreamAudioSourceNodeConstructor = (audioNodeConstructor, createNativeMediaStreamAudioSourceNode, getNativeContext, isNativeOfflineAudioContext) => {
	return class MediaStreamAudioSourceNode extends audioNodeConstructor {
		constructor(context, options) {
			const nativeContext = getNativeContext(context);
			const nativeMediaStreamAudioSourceNode = createNativeMediaStreamAudioSourceNode(nativeContext, options);
			if (isNativeOfflineAudioContext(nativeContext)) throw new TypeError();
			super(context, true, nativeMediaStreamAudioSourceNode, null);
			this._nativeMediaStreamAudioSourceNode = nativeMediaStreamAudioSourceNode;
		}
		get mediaStream() {
			return this._nativeMediaStreamAudioSourceNode.mediaStream;
		}
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/minimal-audio-context-constructor.js
var createMinimalAudioContextConstructor = (createInvalidStateError, createNotSupportedError, createUnknownError, minimalBaseAudioContextConstructor, nativeAudioContextConstructor) => {
	return class MinimalAudioContext extends minimalBaseAudioContextConstructor {
		constructor(options = {}) {
			if (nativeAudioContextConstructor === null) throw new Error("Missing the native AudioContext constructor.");
			let nativeAudioContext;
			try {
				nativeAudioContext = new nativeAudioContextConstructor(options);
			} catch (err) {
				if (err.code === 12 && err.message === "sampleRate is not in range") throw createNotSupportedError();
				throw err;
			}
			if (nativeAudioContext === null) throw createUnknownError();
			if (!isValidLatencyHint(options.latencyHint)) throw new TypeError(`The provided value '${options.latencyHint}' is not a valid enum value of type AudioContextLatencyCategory.`);
			if (options.sampleRate !== void 0 && nativeAudioContext.sampleRate !== options.sampleRate) throw createNotSupportedError();
			super(nativeAudioContext, 2);
			const { latencyHint } = options;
			const { sampleRate } = nativeAudioContext;
			this._baseLatency = typeof nativeAudioContext.baseLatency === "number" ? nativeAudioContext.baseLatency : latencyHint === "balanced" ? 512 / sampleRate : latencyHint === "interactive" || latencyHint === void 0 ? 256 / sampleRate : latencyHint === "playback" ? 1024 / sampleRate : Math.max(2, Math.min(128, Math.round(latencyHint * sampleRate / 128))) * 128 / sampleRate;
			this._nativeAudioContext = nativeAudioContext;
			if (nativeAudioContextConstructor.name === "webkitAudioContext") {
				this._nativeGainNode = nativeAudioContext.createGain();
				this._nativeOscillatorNode = nativeAudioContext.createOscillator();
				this._nativeGainNode.gain.value = 1e-37;
				this._nativeOscillatorNode.connect(this._nativeGainNode).connect(nativeAudioContext.destination);
				this._nativeOscillatorNode.start();
			} else {
				this._nativeGainNode = null;
				this._nativeOscillatorNode = null;
			}
			this._state = null;
			if (nativeAudioContext.state === "running") {
				this._state = "suspended";
				const revokeState = () => {
					if (this._state === "suspended") this._state = null;
					nativeAudioContext.removeEventListener("statechange", revokeState);
				};
				nativeAudioContext.addEventListener("statechange", revokeState);
			}
		}
		get baseLatency() {
			return this._baseLatency;
		}
		get state() {
			return this._state !== null ? this._state : this._nativeAudioContext.state;
		}
		close() {
			if (this.state === "closed") return this._nativeAudioContext.close().then(() => {
				throw createInvalidStateError();
			});
			if (this._state === "suspended") this._state = null;
			return this._nativeAudioContext.close().then(() => {
				if (this._nativeGainNode !== null && this._nativeOscillatorNode !== null) {
					this._nativeOscillatorNode.stop();
					this._nativeGainNode.disconnect();
					this._nativeOscillatorNode.disconnect();
				}
				deactivateAudioGraph(this);
			});
		}
		resume() {
			if (this._state === "suspended") return new Promise((resolve, reject) => {
				const resolvePromise = () => {
					this._nativeAudioContext.removeEventListener("statechange", resolvePromise);
					if (this._nativeAudioContext.state === "running") resolve();
					else this.resume().then(resolve, reject);
				};
				this._nativeAudioContext.addEventListener("statechange", resolvePromise);
			});
			return this._nativeAudioContext.resume().catch((err) => {
				if (err === void 0 || err.code === 15) throw createInvalidStateError();
				throw err;
			});
		}
		suspend() {
			return this._nativeAudioContext.suspend().catch((err) => {
				if (err === void 0) throw createInvalidStateError();
				throw err;
			});
		}
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/minimal-base-audio-context-constructor.js
var createMinimalBaseAudioContextConstructor = (audioDestinationNodeConstructor, createAudioListener, eventTargetConstructor, isNativeOfflineAudioContext, unrenderedAudioWorkletNodeStore, wrapEventListener) => {
	return class MinimalBaseAudioContext extends eventTargetConstructor {
		constructor(_nativeContext, numberOfChannels) {
			super(_nativeContext);
			this._nativeContext = _nativeContext;
			CONTEXT_STORE.set(this, _nativeContext);
			if (isNativeOfflineAudioContext(_nativeContext)) unrenderedAudioWorkletNodeStore.set(_nativeContext, /* @__PURE__ */ new Set());
			this._destination = new audioDestinationNodeConstructor(this, numberOfChannels);
			this._listener = createAudioListener(this, _nativeContext);
			this._onstatechange = null;
		}
		get currentTime() {
			return this._nativeContext.currentTime;
		}
		get destination() {
			return this._destination;
		}
		get listener() {
			return this._listener;
		}
		get onstatechange() {
			return this._onstatechange;
		}
		set onstatechange(value) {
			const wrappedListener = typeof value === "function" ? wrapEventListener(this, value) : null;
			this._nativeContext.onstatechange = wrappedListener;
			const nativeOnStateChange = this._nativeContext.onstatechange;
			this._onstatechange = nativeOnStateChange !== null && nativeOnStateChange === wrappedListener ? value : nativeOnStateChange;
		}
		get sampleRate() {
			return this._nativeContext.sampleRate;
		}
		get state() {
			return this._nativeContext.state;
		}
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/test-promise-support.js
var testPromiseSupport = (nativeContext) => {
	const uint32Array = new Uint32Array([
		1179011410,
		40,
		1163280727,
		544501094,
		16,
		131073,
		44100,
		176400,
		1048580,
		1635017060,
		4,
		0
	]);
	try {
		const promise = nativeContext.decodeAudioData(uint32Array.buffer, () => {});
		if (promise === void 0) return false;
		promise.catch(() => {});
		return true;
	} catch {}
	return false;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/monitor-connections.js
var createMonitorConnections = (insertElementInSet, isNativeAudioNode) => {
	return (nativeAudioNode, whenConnected, whenDisconnected) => {
		const connections = /* @__PURE__ */ new Set();
		nativeAudioNode.connect = ((connect) => {
			return (destination, output = 0, input = 0) => {
				const wasDisconnected = connections.size === 0;
				if (isNativeAudioNode(destination)) {
					connect.call(nativeAudioNode, destination, output, input);
					insertElementInSet(connections, [
						destination,
						output,
						input
					], (connection) => connection[0] === destination && connection[1] === output && connection[2] === input, true);
					if (wasDisconnected) whenConnected();
					return destination;
				}
				connect.call(nativeAudioNode, destination, output);
				insertElementInSet(connections, [destination, output], (connection) => connection[0] === destination && connection[1] === output, true);
				if (wasDisconnected) whenConnected();
			};
		})(nativeAudioNode.connect);
		nativeAudioNode.disconnect = ((disconnect) => {
			return (destinationOrOutput, output, input) => {
				const wasConnected = connections.size > 0;
				if (destinationOrOutput === void 0) {
					disconnect.apply(nativeAudioNode);
					connections.clear();
				} else if (typeof destinationOrOutput === "number") {
					disconnect.call(nativeAudioNode, destinationOrOutput);
					for (const connection of connections) if (connection[1] === destinationOrOutput) connections.delete(connection);
				} else {
					if (isNativeAudioNode(destinationOrOutput)) disconnect.call(nativeAudioNode, destinationOrOutput, output, input);
					else disconnect.call(nativeAudioNode, destinationOrOutput, output);
					for (const connection of connections) if (connection[0] === destinationOrOutput && (output === void 0 || connection[1] === output) && (input === void 0 || connection[2] === input)) connections.delete(connection);
				}
				const isDisconnected = connections.size === 0;
				if (wasConnected && isDisconnected) whenDisconnected();
			};
		})(nativeAudioNode.disconnect);
		return nativeAudioNode;
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/assign-native-audio-node-option.js
var assignNativeAudioNodeOption = (nativeAudioNode, options, option) => {
	const value = options[option];
	if (value !== void 0 && value !== nativeAudioNode[option]) nativeAudioNode[option] = value;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/assign-native-audio-node-options.js
var assignNativeAudioNodeOptions = (nativeAudioNode, options) => {
	assignNativeAudioNodeOption(nativeAudioNode, options, "channelCount");
	assignNativeAudioNodeOption(nativeAudioNode, options, "channelCountMode");
	assignNativeAudioNodeOption(nativeAudioNode, options, "channelInterpretation");
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/native-audio-buffer-constructor.js
var createNativeAudioBufferConstructor = (window) => {
	if (window === null) return null;
	if (window.hasOwnProperty("AudioBuffer")) return window.AudioBuffer;
	return null;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/assign-native-audio-node-audio-param-value.js
var assignNativeAudioNodeAudioParamValue = (nativeAudioNode, options, audioParam) => {
	const value = options[audioParam];
	if (value !== void 0 && value !== nativeAudioNode[audioParam].value) nativeAudioNode[audioParam].value = value;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/wrap-audio-buffer-source-node-start-method-consecutive-calls.js
var wrapAudioBufferSourceNodeStartMethodConsecutiveCalls = (nativeAudioBufferSourceNode) => {
	nativeAudioBufferSourceNode.start = ((start) => {
		let isScheduled = false;
		return (when = 0, offset = 0, duration) => {
			if (isScheduled) throw createInvalidStateError();
			start.call(nativeAudioBufferSourceNode, when, offset, duration);
			isScheduled = true;
		};
	})(nativeAudioBufferSourceNode.start);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/wrap-audio-scheduled-source-node-start-method-negative-parameters.js
var wrapAudioScheduledSourceNodeStartMethodNegativeParameters = (nativeAudioScheduledSourceNode) => {
	nativeAudioScheduledSourceNode.start = ((start) => {
		return (when = 0, offset = 0, duration) => {
			if (typeof duration === "number" && duration < 0 || offset < 0 || when < 0) throw new RangeError("The parameters can't be negative.");
			start.call(nativeAudioScheduledSourceNode, when, offset, duration);
		};
	})(nativeAudioScheduledSourceNode.start);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/wrap-audio-scheduled-source-node-stop-method-negative-parameters.js
var wrapAudioScheduledSourceNodeStopMethodNegativeParameters = (nativeAudioScheduledSourceNode) => {
	nativeAudioScheduledSourceNode.stop = ((stop) => {
		return (when = 0) => {
			if (when < 0) throw new RangeError("The parameter can't be negative.");
			stop.call(nativeAudioScheduledSourceNode, when);
		};
	})(nativeAudioScheduledSourceNode.stop);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/native-audio-buffer-source-node-factory.js
var createNativeAudioBufferSourceNodeFactory = (addSilentConnection, cacheTestResult, testAudioBufferSourceNodeStartMethodConsecutiveCallsSupport, testAudioBufferSourceNodeStartMethodOffsetClampingSupport, testAudioBufferSourceNodeStopMethodNullifiedBufferSupport, testAudioScheduledSourceNodeStartMethodNegativeParametersSupport, testAudioScheduledSourceNodeStopMethodConsecutiveCallsSupport, testAudioScheduledSourceNodeStopMethodNegativeParametersSupport, wrapAudioBufferSourceNodeStartMethodOffsetClampling, wrapAudioBufferSourceNodeStopMethodNullifiedBuffer, wrapAudioScheduledSourceNodeStopMethodConsecutiveCalls) => {
	return (nativeContext, options) => {
		const nativeAudioBufferSourceNode = nativeContext.createBufferSource();
		assignNativeAudioNodeOptions(nativeAudioBufferSourceNode, options);
		assignNativeAudioNodeAudioParamValue(nativeAudioBufferSourceNode, options, "playbackRate");
		assignNativeAudioNodeOption(nativeAudioBufferSourceNode, options, "buffer");
		assignNativeAudioNodeOption(nativeAudioBufferSourceNode, options, "loop");
		assignNativeAudioNodeOption(nativeAudioBufferSourceNode, options, "loopEnd");
		assignNativeAudioNodeOption(nativeAudioBufferSourceNode, options, "loopStart");
		if (!cacheTestResult(testAudioBufferSourceNodeStartMethodConsecutiveCallsSupport, () => testAudioBufferSourceNodeStartMethodConsecutiveCallsSupport(nativeContext))) wrapAudioBufferSourceNodeStartMethodConsecutiveCalls(nativeAudioBufferSourceNode);
		if (!cacheTestResult(testAudioBufferSourceNodeStartMethodOffsetClampingSupport, () => testAudioBufferSourceNodeStartMethodOffsetClampingSupport(nativeContext))) wrapAudioBufferSourceNodeStartMethodOffsetClampling(nativeAudioBufferSourceNode);
		if (!cacheTestResult(testAudioBufferSourceNodeStopMethodNullifiedBufferSupport, () => testAudioBufferSourceNodeStopMethodNullifiedBufferSupport(nativeContext))) wrapAudioBufferSourceNodeStopMethodNullifiedBuffer(nativeAudioBufferSourceNode, nativeContext);
		if (!cacheTestResult(testAudioScheduledSourceNodeStartMethodNegativeParametersSupport, () => testAudioScheduledSourceNodeStartMethodNegativeParametersSupport(nativeContext))) wrapAudioScheduledSourceNodeStartMethodNegativeParameters(nativeAudioBufferSourceNode);
		if (!cacheTestResult(testAudioScheduledSourceNodeStopMethodConsecutiveCallsSupport, () => testAudioScheduledSourceNodeStopMethodConsecutiveCallsSupport(nativeContext))) wrapAudioScheduledSourceNodeStopMethodConsecutiveCalls(nativeAudioBufferSourceNode, nativeContext);
		if (!cacheTestResult(testAudioScheduledSourceNodeStopMethodNegativeParametersSupport, () => testAudioScheduledSourceNodeStopMethodNegativeParametersSupport(nativeContext))) wrapAudioScheduledSourceNodeStopMethodNegativeParameters(nativeAudioBufferSourceNode);
		addSilentConnection(nativeContext, nativeAudioBufferSourceNode);
		return nativeAudioBufferSourceNode;
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/native-audio-context-constructor.js
var createNativeAudioContextConstructor = (window) => {
	if (window === null) return null;
	if (window.hasOwnProperty("AudioContext")) return window.AudioContext;
	return window.hasOwnProperty("webkitAudioContext") ? window.webkitAudioContext : null;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/native-audio-destination-node.js
var createNativeAudioDestinationNodeFactory = (createNativeGainNode, overwriteAccessors) => {
	return (nativeContext, channelCount, isNodeOfNativeOfflineAudioContext) => {
		const nativeAudioDestinationNode = nativeContext.destination;
		if (nativeAudioDestinationNode.channelCount !== channelCount) try {
			nativeAudioDestinationNode.channelCount = channelCount;
		} catch {}
		if (isNodeOfNativeOfflineAudioContext && nativeAudioDestinationNode.channelCountMode !== "explicit") nativeAudioDestinationNode.channelCountMode = "explicit";
		if (nativeAudioDestinationNode.maxChannelCount === 0) Object.defineProperty(nativeAudioDestinationNode, "maxChannelCount", { value: channelCount });
		const gainNode = createNativeGainNode(nativeContext, {
			channelCount,
			channelCountMode: nativeAudioDestinationNode.channelCountMode,
			channelInterpretation: nativeAudioDestinationNode.channelInterpretation,
			gain: 1
		});
		overwriteAccessors(gainNode, "channelCount", (get) => () => get.call(gainNode), (set) => (value) => {
			set.call(gainNode, value);
			try {
				nativeAudioDestinationNode.channelCount = value;
			} catch (err) {
				if (value > nativeAudioDestinationNode.maxChannelCount) throw err;
			}
		});
		overwriteAccessors(gainNode, "channelCountMode", (get) => () => get.call(gainNode), (set) => (value) => {
			set.call(gainNode, value);
			nativeAudioDestinationNode.channelCountMode = value;
		});
		overwriteAccessors(gainNode, "channelInterpretation", (get) => () => get.call(gainNode), (set) => (value) => {
			set.call(gainNode, value);
			nativeAudioDestinationNode.channelInterpretation = value;
		});
		Object.defineProperty(gainNode, "maxChannelCount", { get: () => nativeAudioDestinationNode.maxChannelCount });
		gainNode.connect(nativeAudioDestinationNode);
		return gainNode;
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/native-audio-worklet-node-constructor.js
var createNativeAudioWorkletNodeConstructor = (window) => {
	if (window === null) return null;
	return window.hasOwnProperty("AudioWorkletNode") ? window.AudioWorkletNode : null;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/test-clonability-of-audio-worklet-node-options.js
var testClonabilityOfAudioWorkletNodeOptions = (audioWorkletNodeOptions) => {
	const { port1 } = new MessageChannel();
	try {
		port1.postMessage(audioWorkletNodeOptions);
	} finally {
		port1.close();
	}
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/native-audio-worklet-node-factory.js
var createNativeAudioWorkletNodeFactory = (createInvalidStateError, createNativeAudioWorkletNodeFaker, createNativeGainNode, createNotSupportedError, monitorConnections) => {
	return (nativeContext, baseLatency, nativeAudioWorkletNodeConstructor, name, processorConstructor, options) => {
		if (nativeAudioWorkletNodeConstructor !== null) try {
			const nativeAudioWorkletNode = new nativeAudioWorkletNodeConstructor(nativeContext, name, options);
			const patchedEventListeners = /* @__PURE__ */ new Map();
			let onprocessorerror = null;
			Object.defineProperties(nativeAudioWorkletNode, {
				channelCount: {
					get: () => options.channelCount,
					set: () => {
						throw createInvalidStateError();
					}
				},
				channelCountMode: {
					get: () => "explicit",
					set: () => {
						throw createInvalidStateError();
					}
				},
				onprocessorerror: {
					get: () => onprocessorerror,
					set: (value) => {
						if (typeof onprocessorerror === "function") nativeAudioWorkletNode.removeEventListener("processorerror", onprocessorerror);
						onprocessorerror = typeof value === "function" ? value : null;
						if (typeof onprocessorerror === "function") nativeAudioWorkletNode.addEventListener("processorerror", onprocessorerror);
					}
				}
			});
			nativeAudioWorkletNode.addEventListener = ((addEventListener) => {
				return (...args) => {
					if (args[0] === "processorerror") {
						const unpatchedEventListener = typeof args[1] === "function" ? args[1] : typeof args[1] === "object" && args[1] !== null && typeof args[1].handleEvent === "function" ? args[1].handleEvent : null;
						if (unpatchedEventListener !== null) {
							const patchedEventListener = patchedEventListeners.get(args[1]);
							if (patchedEventListener !== void 0) args[1] = patchedEventListener;
							else {
								args[1] = (event) => {
									if (event.type === "error") {
										Object.defineProperties(event, { type: { value: "processorerror" } });
										unpatchedEventListener(event);
									} else unpatchedEventListener(new ErrorEvent(args[0], { ...event }));
								};
								patchedEventListeners.set(unpatchedEventListener, args[1]);
							}
						}
					}
					addEventListener.call(nativeAudioWorkletNode, "error", args[1], args[2]);
					return addEventListener.call(nativeAudioWorkletNode, ...args);
				};
			})(nativeAudioWorkletNode.addEventListener);
			nativeAudioWorkletNode.removeEventListener = ((removeEventListener) => {
				return (...args) => {
					if (args[0] === "processorerror") {
						const patchedEventListener = patchedEventListeners.get(args[1]);
						if (patchedEventListener !== void 0) {
							patchedEventListeners.delete(args[1]);
							args[1] = patchedEventListener;
						}
					}
					removeEventListener.call(nativeAudioWorkletNode, "error", args[1], args[2]);
					return removeEventListener.call(nativeAudioWorkletNode, args[0], args[1], args[2]);
				};
			})(nativeAudioWorkletNode.removeEventListener);
			if (options.numberOfOutputs !== 0) {
				const nativeGainNode = createNativeGainNode(nativeContext, {
					channelCount: 1,
					channelCountMode: "explicit",
					channelInterpretation: "discrete",
					gain: 0
				});
				nativeAudioWorkletNode.connect(nativeGainNode).connect(nativeContext.destination);
				const whenConnected = () => nativeGainNode.disconnect();
				const whenDisconnected = () => nativeGainNode.connect(nativeContext.destination);
				return monitorConnections(nativeAudioWorkletNode, whenConnected, whenDisconnected);
			}
			return nativeAudioWorkletNode;
		} catch (err) {
			if (err.code === 11) throw createNotSupportedError();
			throw err;
		}
		if (processorConstructor === void 0) throw createNotSupportedError();
		testClonabilityOfAudioWorkletNodeOptions(options);
		return createNativeAudioWorkletNodeFaker(nativeContext, baseLatency, processorConstructor, options);
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/compute-buffer-size.js
var computeBufferSize = (baseLatency, sampleRate) => {
	if (baseLatency === null) return 512;
	return Math.max(512, Math.min(16384, Math.pow(2, Math.round(Math.log2(baseLatency * sampleRate)))));
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/clone-audio-worklet-node-options.js
var cloneAudioWorkletNodeOptions = (audioWorkletNodeOptions) => {
	return new Promise((resolve, reject) => {
		const { port1, port2 } = new MessageChannel();
		port1.onmessage = ({ data }) => {
			port1.close();
			port2.close();
			resolve(data);
		};
		port1.onmessageerror = ({ data }) => {
			port1.close();
			port2.close();
			reject(data);
		};
		port2.postMessage(audioWorkletNodeOptions);
	});
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/create-audio-worklet-processor-promise.js
var createAudioWorkletProcessorPromise = async (processorConstructor, audioWorkletNodeOptions) => {
	return new processorConstructor(await cloneAudioWorkletNodeOptions(audioWorkletNodeOptions));
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/create-audio-worklet-processor.js
var createAudioWorkletProcessor = (nativeContext, nativeAudioWorkletNode, processorConstructor, audioWorkletNodeOptions) => {
	let nodeToProcessorMap = NODE_TO_PROCESSOR_MAPS.get(nativeContext);
	if (nodeToProcessorMap === void 0) {
		nodeToProcessorMap = /* @__PURE__ */ new WeakMap();
		NODE_TO_PROCESSOR_MAPS.set(nativeContext, nodeToProcessorMap);
	}
	const audioWorkletProcessorPromise = createAudioWorkletProcessorPromise(processorConstructor, audioWorkletNodeOptions);
	nodeToProcessorMap.set(nativeAudioWorkletNode, audioWorkletProcessorPromise);
	return audioWorkletProcessorPromise;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/native-audio-worklet-node-faker-factory.js
var createNativeAudioWorkletNodeFakerFactory = (connectMultipleOutputs, createIndexSizeError, createInvalidStateError, createNativeChannelMergerNode, createNativeChannelSplitterNode, createNativeConstantSourceNode, createNativeGainNode, createNativeScriptProcessorNode, createNotSupportedError, disconnectMultipleOutputs, exposeCurrentFrameAndCurrentTime, getActiveAudioWorkletNodeInputs, monitorConnections) => {
	return (nativeContext, baseLatency, processorConstructor, options) => {
		if (options.numberOfInputs === 0 && options.numberOfOutputs === 0) throw createNotSupportedError();
		const outputChannelCount = Array.isArray(options.outputChannelCount) ? options.outputChannelCount : Array.from(options.outputChannelCount);
		if (outputChannelCount.some((channelCount) => channelCount < 1)) throw createNotSupportedError();
		if (outputChannelCount.length !== options.numberOfOutputs) throw createIndexSizeError();
		if (options.channelCountMode !== "explicit") throw createNotSupportedError();
		const numberOfInputChannels = options.channelCount * options.numberOfInputs;
		const numberOfOutputChannels = outputChannelCount.reduce((sum, value) => sum + value, 0);
		const numberOfParameters = processorConstructor.parameterDescriptors === void 0 ? 0 : processorConstructor.parameterDescriptors.length;
		if (numberOfInputChannels + numberOfParameters > 6 || numberOfOutputChannels > 6) throw createNotSupportedError();
		const messageChannel = new MessageChannel();
		const gainNodes = [];
		const inputChannelSplitterNodes = [];
		for (let i = 0; i < options.numberOfInputs; i += 1) {
			gainNodes.push(createNativeGainNode(nativeContext, {
				channelCount: options.channelCount,
				channelCountMode: options.channelCountMode,
				channelInterpretation: options.channelInterpretation,
				gain: 1
			}));
			inputChannelSplitterNodes.push(createNativeChannelSplitterNode(nativeContext, {
				channelCount: options.channelCount,
				channelCountMode: "explicit",
				channelInterpretation: "discrete",
				numberOfOutputs: options.channelCount
			}));
		}
		const constantSourceNodes = [];
		if (processorConstructor.parameterDescriptors !== void 0) for (const { defaultValue, maxValue, minValue, name } of processorConstructor.parameterDescriptors) {
			const constantSourceNode = createNativeConstantSourceNode(nativeContext, {
				channelCount: 1,
				channelCountMode: "explicit",
				channelInterpretation: "discrete",
				offset: options.parameterData[name] !== void 0 ? options.parameterData[name] : defaultValue === void 0 ? 0 : defaultValue
			});
			Object.defineProperties(constantSourceNode.offset, {
				defaultValue: { get: () => defaultValue === void 0 ? 0 : defaultValue },
				maxValue: { get: () => maxValue === void 0 ? MOST_POSITIVE_SINGLE_FLOAT : maxValue },
				minValue: { get: () => minValue === void 0 ? MOST_NEGATIVE_SINGLE_FLOAT : minValue }
			});
			constantSourceNodes.push(constantSourceNode);
		}
		const inputChannelMergerNode = createNativeChannelMergerNode(nativeContext, {
			channelCount: 1,
			channelCountMode: "explicit",
			channelInterpretation: "speakers",
			numberOfInputs: Math.max(1, numberOfInputChannels + numberOfParameters)
		});
		const bufferSize = computeBufferSize(baseLatency, nativeContext.sampleRate);
		const scriptProcessorNode = createNativeScriptProcessorNode(nativeContext, bufferSize, numberOfInputChannels + numberOfParameters, Math.max(1, numberOfOutputChannels));
		const outputChannelSplitterNode = createNativeChannelSplitterNode(nativeContext, {
			channelCount: Math.max(1, numberOfOutputChannels),
			channelCountMode: "explicit",
			channelInterpretation: "discrete",
			numberOfOutputs: Math.max(1, numberOfOutputChannels)
		});
		const outputChannelMergerNodes = [];
		for (let i = 0; i < options.numberOfOutputs; i += 1) outputChannelMergerNodes.push(createNativeChannelMergerNode(nativeContext, {
			channelCount: 1,
			channelCountMode: "explicit",
			channelInterpretation: "speakers",
			numberOfInputs: outputChannelCount[i]
		}));
		for (let i = 0; i < options.numberOfInputs; i += 1) {
			gainNodes[i].connect(inputChannelSplitterNodes[i]);
			for (let j = 0; j < options.channelCount; j += 1) inputChannelSplitterNodes[i].connect(inputChannelMergerNode, j, i * options.channelCount + j);
		}
		const parameterMap = new ReadOnlyMap(processorConstructor.parameterDescriptors === void 0 ? [] : processorConstructor.parameterDescriptors.map(({ name }, index) => {
			const constantSourceNode = constantSourceNodes[index];
			constantSourceNode.connect(inputChannelMergerNode, 0, numberOfInputChannels + index);
			constantSourceNode.start(0);
			return [name, constantSourceNode.offset];
		}));
		inputChannelMergerNode.connect(scriptProcessorNode);
		let channelInterpretation = options.channelInterpretation;
		let onprocessorerror = null;
		const outputAudioNodes = options.numberOfOutputs === 0 ? [scriptProcessorNode] : outputChannelMergerNodes;
		const nativeAudioWorkletNodeFaker = {
			get bufferSize() {
				return bufferSize;
			},
			get channelCount() {
				return options.channelCount;
			},
			set channelCount(_) {
				throw createInvalidStateError();
			},
			get channelCountMode() {
				return options.channelCountMode;
			},
			set channelCountMode(_) {
				throw createInvalidStateError();
			},
			get channelInterpretation() {
				return channelInterpretation;
			},
			set channelInterpretation(value) {
				for (const gainNode of gainNodes) gainNode.channelInterpretation = value;
				channelInterpretation = value;
			},
			get context() {
				return scriptProcessorNode.context;
			},
			get inputs() {
				return gainNodes;
			},
			get numberOfInputs() {
				return options.numberOfInputs;
			},
			get numberOfOutputs() {
				return options.numberOfOutputs;
			},
			get onprocessorerror() {
				return onprocessorerror;
			},
			set onprocessorerror(value) {
				if (typeof onprocessorerror === "function") nativeAudioWorkletNodeFaker.removeEventListener("processorerror", onprocessorerror);
				onprocessorerror = typeof value === "function" ? value : null;
				if (typeof onprocessorerror === "function") nativeAudioWorkletNodeFaker.addEventListener("processorerror", onprocessorerror);
			},
			get parameters() {
				return parameterMap;
			},
			get port() {
				return messageChannel.port2;
			},
			addEventListener(...args) {
				return scriptProcessorNode.addEventListener(args[0], args[1], args[2]);
			},
			connect: connectMultipleOutputs.bind(null, outputAudioNodes),
			disconnect: disconnectMultipleOutputs.bind(null, outputAudioNodes),
			dispatchEvent(...args) {
				return scriptProcessorNode.dispatchEvent(args[0]);
			},
			removeEventListener(...args) {
				return scriptProcessorNode.removeEventListener(args[0], args[1], args[2]);
			}
		};
		const patchedEventListeners = /* @__PURE__ */ new Map();
		messageChannel.port1.addEventListener = ((addEventListener) => {
			return (...args) => {
				if (args[0] === "message") {
					const unpatchedEventListener = typeof args[1] === "function" ? args[1] : typeof args[1] === "object" && args[1] !== null && typeof args[1].handleEvent === "function" ? args[1].handleEvent : null;
					if (unpatchedEventListener !== null) {
						const patchedEventListener = patchedEventListeners.get(args[1]);
						if (patchedEventListener !== void 0) args[1] = patchedEventListener;
						else {
							args[1] = (event) => {
								exposeCurrentFrameAndCurrentTime(nativeContext.currentTime, nativeContext.sampleRate, () => unpatchedEventListener(event));
							};
							patchedEventListeners.set(unpatchedEventListener, args[1]);
						}
					}
				}
				return addEventListener.call(messageChannel.port1, args[0], args[1], args[2]);
			};
		})(messageChannel.port1.addEventListener);
		messageChannel.port1.removeEventListener = ((removeEventListener) => {
			return (...args) => {
				if (args[0] === "message") {
					const patchedEventListener = patchedEventListeners.get(args[1]);
					if (patchedEventListener !== void 0) {
						patchedEventListeners.delete(args[1]);
						args[1] = patchedEventListener;
					}
				}
				return removeEventListener.call(messageChannel.port1, args[0], args[1], args[2]);
			};
		})(messageChannel.port1.removeEventListener);
		let onmessage = null;
		Object.defineProperty(messageChannel.port1, "onmessage", {
			get: () => onmessage,
			set: (value) => {
				if (typeof onmessage === "function") messageChannel.port1.removeEventListener("message", onmessage);
				onmessage = typeof value === "function" ? value : null;
				if (typeof onmessage === "function") {
					messageChannel.port1.addEventListener("message", onmessage);
					messageChannel.port1.start();
				}
			}
		});
		processorConstructor.prototype.port = messageChannel.port1;
		let audioWorkletProcessor = null;
		createAudioWorkletProcessor(nativeContext, nativeAudioWorkletNodeFaker, processorConstructor, options).then((dWrkltPrcssr) => audioWorkletProcessor = dWrkltPrcssr);
		const inputs = createNestedArrays(options.numberOfInputs, options.channelCount);
		const outputs = createNestedArrays(options.numberOfOutputs, outputChannelCount);
		const parameters = processorConstructor.parameterDescriptors === void 0 ? [] : processorConstructor.parameterDescriptors.reduce((prmtrs, { name }) => ({
			...prmtrs,
			[name]: /* @__PURE__ */ new Float32Array(128)
		}), {});
		let isActive = true;
		const disconnectOutputsGraph = () => {
			if (options.numberOfOutputs > 0) scriptProcessorNode.disconnect(outputChannelSplitterNode);
			for (let i = 0, outputChannelSplitterNodeOutput = 0; i < options.numberOfOutputs; i += 1) {
				const outputChannelMergerNode = outputChannelMergerNodes[i];
				for (let j = 0; j < outputChannelCount[i]; j += 1) outputChannelSplitterNode.disconnect(outputChannelMergerNode, outputChannelSplitterNodeOutput + j, j);
				outputChannelSplitterNodeOutput += outputChannelCount[i];
			}
		};
		const activeInputIndexes = /* @__PURE__ */ new Map();
		scriptProcessorNode.onaudioprocess = ({ inputBuffer, outputBuffer }) => {
			if (audioWorkletProcessor !== null) {
				const activeInputs = getActiveAudioWorkletNodeInputs(nativeAudioWorkletNodeFaker);
				for (let i = 0; i < bufferSize; i += 128) {
					for (let j = 0; j < options.numberOfInputs; j += 1) for (let k = 0; k < options.channelCount; k += 1) copyFromChannel(inputBuffer, inputs[j], k, k, i);
					if (processorConstructor.parameterDescriptors !== void 0) processorConstructor.parameterDescriptors.forEach(({ name }, index) => {
						copyFromChannel(inputBuffer, parameters, name, numberOfInputChannels + index, i);
					});
					for (let j = 0; j < options.numberOfInputs; j += 1) for (let k = 0; k < outputChannelCount[j]; k += 1) if (outputs[j][k].byteLength === 0) outputs[j][k] = /* @__PURE__ */ new Float32Array(128);
					try {
						const potentiallyEmptyInputs = inputs.map((input, index) => {
							if (activeInputs[index].size > 0) {
								activeInputIndexes.set(index, bufferSize / 128);
								return input;
							}
							const count = activeInputIndexes.get(index);
							if (count === void 0) return [];
							if (input.every((channelData) => channelData.every((sample) => sample === 0))) {
								if (count === 1) activeInputIndexes.delete(index);
								else activeInputIndexes.set(index, count - 1);
							}
							return input;
						});
						isActive = exposeCurrentFrameAndCurrentTime(nativeContext.currentTime + i / nativeContext.sampleRate, nativeContext.sampleRate, () => audioWorkletProcessor.process(potentiallyEmptyInputs, outputs, parameters));
						for (let j = 0, outputChannelSplitterNodeOutput = 0; j < options.numberOfOutputs; j += 1) {
							for (let k = 0; k < outputChannelCount[j]; k += 1) copyToChannel(outputBuffer, outputs[j], k, outputChannelSplitterNodeOutput + k, i);
							outputChannelSplitterNodeOutput += outputChannelCount[j];
						}
					} catch (error) {
						isActive = false;
						nativeAudioWorkletNodeFaker.dispatchEvent(new ErrorEvent("processorerror", {
							colno: error.colno,
							filename: error.filename,
							lineno: error.lineno,
							message: error.message
						}));
					}
					if (!isActive) {
						for (let j = 0; j < options.numberOfInputs; j += 1) {
							gainNodes[j].disconnect(inputChannelSplitterNodes[j]);
							for (let k = 0; k < options.channelCount; k += 1) inputChannelSplitterNodes[i].disconnect(inputChannelMergerNode, k, j * options.channelCount + k);
						}
						if (processorConstructor.parameterDescriptors !== void 0) {
							const length = processorConstructor.parameterDescriptors.length;
							for (let j = 0; j < length; j += 1) {
								const constantSourceNode = constantSourceNodes[j];
								constantSourceNode.disconnect(inputChannelMergerNode, 0, numberOfInputChannels + j);
								constantSourceNode.stop();
							}
						}
						inputChannelMergerNode.disconnect(scriptProcessorNode);
						scriptProcessorNode.onaudioprocess = null;
						if (isConnected) disconnectOutputsGraph();
						else disconnectFakeGraph();
						break;
					}
				}
			}
		};
		let isConnected = false;
		const nativeGainNode = createNativeGainNode(nativeContext, {
			channelCount: 1,
			channelCountMode: "explicit",
			channelInterpretation: "discrete",
			gain: 0
		});
		const connectFakeGraph = () => scriptProcessorNode.connect(nativeGainNode).connect(nativeContext.destination);
		const disconnectFakeGraph = () => {
			scriptProcessorNode.disconnect(nativeGainNode);
			nativeGainNode.disconnect();
		};
		const whenConnected = () => {
			if (isActive) {
				disconnectFakeGraph();
				if (options.numberOfOutputs > 0) scriptProcessorNode.connect(outputChannelSplitterNode);
				for (let i = 0, outputChannelSplitterNodeOutput = 0; i < options.numberOfOutputs; i += 1) {
					const outputChannelMergerNode = outputChannelMergerNodes[i];
					for (let j = 0; j < outputChannelCount[i]; j += 1) outputChannelSplitterNode.connect(outputChannelMergerNode, outputChannelSplitterNodeOutput + j, j);
					outputChannelSplitterNodeOutput += outputChannelCount[i];
				}
			}
			isConnected = true;
		};
		const whenDisconnected = () => {
			if (isActive) {
				connectFakeGraph();
				disconnectOutputsGraph();
			}
			isConnected = false;
		};
		connectFakeGraph();
		return monitorConnections(nativeAudioWorkletNodeFaker, whenConnected, whenDisconnected);
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/native-channel-merger-node-factory.js
var createNativeChannelMergerNodeFactory = (nativeAudioContextConstructor, wrapChannelMergerNode) => {
	return (nativeContext, options) => {
		const nativeChannelMergerNode = nativeContext.createChannelMerger(options.numberOfInputs);
		if (nativeAudioContextConstructor !== null && nativeAudioContextConstructor.name === "webkitAudioContext") wrapChannelMergerNode(nativeContext, nativeChannelMergerNode);
		assignNativeAudioNodeOptions(nativeChannelMergerNode, options);
		return nativeChannelMergerNode;
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/wrap-channel-splitter-node.js
var wrapChannelSplitterNode = (channelSplitterNode) => {
	const channelCount = channelSplitterNode.numberOfOutputs;
	Object.defineProperty(channelSplitterNode, "channelCount", {
		get: () => channelCount,
		set: (value) => {
			if (value !== channelCount) throw createInvalidStateError();
		}
	});
	Object.defineProperty(channelSplitterNode, "channelCountMode", {
		get: () => "explicit",
		set: (value) => {
			if (value !== "explicit") throw createInvalidStateError();
		}
	});
	Object.defineProperty(channelSplitterNode, "channelInterpretation", {
		get: () => "discrete",
		set: (value) => {
			if (value !== "discrete") throw createInvalidStateError();
		}
	});
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/native-channel-splitter-node.js
var createNativeChannelSplitterNode = (nativeContext, options) => {
	const nativeChannelSplitterNode = nativeContext.createChannelSplitter(options.numberOfOutputs);
	assignNativeAudioNodeOptions(nativeChannelSplitterNode, options);
	wrapChannelSplitterNode(nativeChannelSplitterNode);
	return nativeChannelSplitterNode;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/native-constant-source-node-factory.js
var createNativeConstantSourceNodeFactory = (addSilentConnection, cacheTestResult, createNativeConstantSourceNodeFaker, testAudioScheduledSourceNodeStartMethodNegativeParametersSupport, testAudioScheduledSourceNodeStopMethodNegativeParametersSupport) => {
	return (nativeContext, options) => {
		if (nativeContext.createConstantSource === void 0) return createNativeConstantSourceNodeFaker(nativeContext, options);
		const nativeConstantSourceNode = nativeContext.createConstantSource();
		assignNativeAudioNodeOptions(nativeConstantSourceNode, options);
		assignNativeAudioNodeAudioParamValue(nativeConstantSourceNode, options, "offset");
		if (!cacheTestResult(testAudioScheduledSourceNodeStartMethodNegativeParametersSupport, () => testAudioScheduledSourceNodeStartMethodNegativeParametersSupport(nativeContext))) wrapAudioScheduledSourceNodeStartMethodNegativeParameters(nativeConstantSourceNode);
		if (!cacheTestResult(testAudioScheduledSourceNodeStopMethodNegativeParametersSupport, () => testAudioScheduledSourceNodeStopMethodNegativeParametersSupport(nativeContext))) wrapAudioScheduledSourceNodeStopMethodNegativeParameters(nativeConstantSourceNode);
		addSilentConnection(nativeContext, nativeConstantSourceNode);
		return nativeConstantSourceNode;
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/intercept-connections.js
var interceptConnections = (original, interceptor) => {
	original.connect = interceptor.connect.bind(interceptor);
	original.disconnect = interceptor.disconnect.bind(interceptor);
	return original;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/native-constant-source-node-faker-factory.js
var createNativeConstantSourceNodeFakerFactory = (addSilentConnection, createNativeAudioBufferSourceNode, createNativeGainNode, monitorConnections) => {
	return (nativeContext, { offset, ...audioNodeOptions }) => {
		const audioBuffer = nativeContext.createBuffer(1, 2, 44100);
		const audioBufferSourceNode = createNativeAudioBufferSourceNode(nativeContext, {
			buffer: null,
			channelCount: 2,
			channelCountMode: "max",
			channelInterpretation: "speakers",
			loop: false,
			loopEnd: 0,
			loopStart: 0,
			playbackRate: 1
		});
		const gainNode = createNativeGainNode(nativeContext, {
			...audioNodeOptions,
			gain: offset
		});
		const channelData = audioBuffer.getChannelData(0);
		channelData[0] = 1;
		channelData[1] = 1;
		audioBufferSourceNode.buffer = audioBuffer;
		audioBufferSourceNode.loop = true;
		const nativeConstantSourceNodeFaker = {
			get bufferSize() {},
			get channelCount() {
				return gainNode.channelCount;
			},
			set channelCount(value) {
				gainNode.channelCount = value;
			},
			get channelCountMode() {
				return gainNode.channelCountMode;
			},
			set channelCountMode(value) {
				gainNode.channelCountMode = value;
			},
			get channelInterpretation() {
				return gainNode.channelInterpretation;
			},
			set channelInterpretation(value) {
				gainNode.channelInterpretation = value;
			},
			get context() {
				return gainNode.context;
			},
			get inputs() {
				return [];
			},
			get numberOfInputs() {
				return audioBufferSourceNode.numberOfInputs;
			},
			get numberOfOutputs() {
				return gainNode.numberOfOutputs;
			},
			get offset() {
				return gainNode.gain;
			},
			get onended() {
				return audioBufferSourceNode.onended;
			},
			set onended(value) {
				audioBufferSourceNode.onended = value;
			},
			addEventListener(...args) {
				return audioBufferSourceNode.addEventListener(args[0], args[1], args[2]);
			},
			dispatchEvent(...args) {
				return audioBufferSourceNode.dispatchEvent(args[0]);
			},
			removeEventListener(...args) {
				return audioBufferSourceNode.removeEventListener(args[0], args[1], args[2]);
			},
			start(when = 0) {
				audioBufferSourceNode.start.call(audioBufferSourceNode, when);
			},
			stop(when = 0) {
				audioBufferSourceNode.stop.call(audioBufferSourceNode, when);
			}
		};
		const whenConnected = () => audioBufferSourceNode.connect(gainNode);
		const whenDisconnected = () => audioBufferSourceNode.disconnect(gainNode);
		addSilentConnection(nativeContext, audioBufferSourceNode);
		return monitorConnections(interceptConnections(nativeConstantSourceNodeFaker, gainNode), whenConnected, whenDisconnected);
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/native-gain-node.js
var createNativeGainNode = (nativeContext, options) => {
	const nativeGainNode = nativeContext.createGain();
	assignNativeAudioNodeOptions(nativeGainNode, options);
	assignNativeAudioNodeAudioParamValue(nativeGainNode, options, "gain");
	return nativeGainNode;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/native-media-stream-audio-source-node.js
var createNativeMediaStreamAudioSourceNode = (nativeAudioContext, { mediaStream }) => {
	const audioStreamTracks = mediaStream.getAudioTracks();
	audioStreamTracks.sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
	const filteredAudioStreamTracks = audioStreamTracks.slice(0, 1);
	const nativeMediaStreamAudioSourceNode = nativeAudioContext.createMediaStreamSource(new MediaStream(filteredAudioStreamTracks));
	Object.defineProperty(nativeMediaStreamAudioSourceNode, "mediaStream", { value: mediaStream });
	return nativeMediaStreamAudioSourceNode;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/native-offline-audio-context-constructor.js
var createNativeOfflineAudioContextConstructor = (window) => {
	if (window === null) return null;
	if (window.hasOwnProperty("OfflineAudioContext")) return window.OfflineAudioContext;
	return window.hasOwnProperty("webkitOfflineAudioContext") ? window.webkitOfflineAudioContext : null;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/native-script-processor-node.js
var createNativeScriptProcessorNode = (nativeContext, bufferSize, numberOfInputChannels, numberOfOutputChannels) => {
	return nativeContext.createScriptProcessor(bufferSize, numberOfInputChannels, numberOfOutputChannels);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/native-stereo-panner-node-faker-factory.js
var createNativeStereoPannerNodeFakerFactory = (createNativeChannelMergerNode, createNativeChannelSplitterNode, createNativeGainNode, createNativeWaveShaperNode, createNotSupportedError, monitorConnections) => {
	const CURVE_SIZE = 16385;
	const DC_CURVE = new Float32Array([1, 1]);
	const HALF_PI = Math.PI / 2;
	const SINGLE_CHANNEL_OPTIONS = {
		channelCount: 1,
		channelCountMode: "explicit",
		channelInterpretation: "discrete"
	};
	const SINGLE_CHANNEL_WAVE_SHAPER_OPTIONS = {
		...SINGLE_CHANNEL_OPTIONS,
		oversample: "none"
	};
	const buildInternalGraphForMono = (nativeContext, inputGainNode, panGainNode, channelMergerNode) => {
		const leftWaveShaperCurve = new Float32Array(CURVE_SIZE);
		const rightWaveShaperCurve = new Float32Array(CURVE_SIZE);
		for (let i = 0; i < CURVE_SIZE; i += 1) {
			const x = i / 16384 * HALF_PI;
			leftWaveShaperCurve[i] = Math.cos(x);
			rightWaveShaperCurve[i] = Math.sin(x);
		}
		const leftGainNode = createNativeGainNode(nativeContext, {
			...SINGLE_CHANNEL_OPTIONS,
			gain: 0
		});
		const leftWaveShaperNode = createNativeWaveShaperNode(nativeContext, {
			...SINGLE_CHANNEL_WAVE_SHAPER_OPTIONS,
			curve: leftWaveShaperCurve
		});
		const panWaveShaperNode = createNativeWaveShaperNode(nativeContext, {
			...SINGLE_CHANNEL_WAVE_SHAPER_OPTIONS,
			curve: DC_CURVE
		});
		const rightGainNode = createNativeGainNode(nativeContext, {
			...SINGLE_CHANNEL_OPTIONS,
			gain: 0
		});
		const rightWaveShaperNode = createNativeWaveShaperNode(nativeContext, {
			...SINGLE_CHANNEL_WAVE_SHAPER_OPTIONS,
			curve: rightWaveShaperCurve
		});
		return {
			connectGraph() {
				inputGainNode.connect(leftGainNode);
				inputGainNode.connect(panWaveShaperNode.inputs === void 0 ? panWaveShaperNode : panWaveShaperNode.inputs[0]);
				inputGainNode.connect(rightGainNode);
				panWaveShaperNode.connect(panGainNode);
				panGainNode.connect(leftWaveShaperNode.inputs === void 0 ? leftWaveShaperNode : leftWaveShaperNode.inputs[0]);
				panGainNode.connect(rightWaveShaperNode.inputs === void 0 ? rightWaveShaperNode : rightWaveShaperNode.inputs[0]);
				leftWaveShaperNode.connect(leftGainNode.gain);
				rightWaveShaperNode.connect(rightGainNode.gain);
				leftGainNode.connect(channelMergerNode, 0, 0);
				rightGainNode.connect(channelMergerNode, 0, 1);
			},
			disconnectGraph() {
				inputGainNode.disconnect(leftGainNode);
				inputGainNode.disconnect(panWaveShaperNode.inputs === void 0 ? panWaveShaperNode : panWaveShaperNode.inputs[0]);
				inputGainNode.disconnect(rightGainNode);
				panWaveShaperNode.disconnect(panGainNode);
				panGainNode.disconnect(leftWaveShaperNode.inputs === void 0 ? leftWaveShaperNode : leftWaveShaperNode.inputs[0]);
				panGainNode.disconnect(rightWaveShaperNode.inputs === void 0 ? rightWaveShaperNode : rightWaveShaperNode.inputs[0]);
				leftWaveShaperNode.disconnect(leftGainNode.gain);
				rightWaveShaperNode.disconnect(rightGainNode.gain);
				leftGainNode.disconnect(channelMergerNode, 0, 0);
				rightGainNode.disconnect(channelMergerNode, 0, 1);
			}
		};
	};
	const buildInternalGraphForStereo = (nativeContext, inputGainNode, panGainNode, channelMergerNode) => {
		const leftInputForLeftOutputWaveShaperCurve = new Float32Array(CURVE_SIZE);
		const leftInputForRightOutputWaveShaperCurve = new Float32Array(CURVE_SIZE);
		const rightInputForLeftOutputWaveShaperCurve = new Float32Array(CURVE_SIZE);
		const rightInputForRightOutputWaveShaperCurve = new Float32Array(CURVE_SIZE);
		const centerIndex = Math.floor(CURVE_SIZE / 2);
		for (let i = 0; i < CURVE_SIZE; i += 1) if (i > centerIndex) {
			const x = (i - centerIndex) / 8192 * HALF_PI;
			leftInputForLeftOutputWaveShaperCurve[i] = Math.cos(x);
			leftInputForRightOutputWaveShaperCurve[i] = Math.sin(x);
			rightInputForLeftOutputWaveShaperCurve[i] = 0;
			rightInputForRightOutputWaveShaperCurve[i] = 1;
		} else {
			const x = i / 8192 * HALF_PI;
			leftInputForLeftOutputWaveShaperCurve[i] = 1;
			leftInputForRightOutputWaveShaperCurve[i] = 0;
			rightInputForLeftOutputWaveShaperCurve[i] = Math.cos(x);
			rightInputForRightOutputWaveShaperCurve[i] = Math.sin(x);
		}
		const channelSplitterNode = createNativeChannelSplitterNode(nativeContext, {
			channelCount: 2,
			channelCountMode: "explicit",
			channelInterpretation: "discrete",
			numberOfOutputs: 2
		});
		const leftInputForLeftOutputGainNode = createNativeGainNode(nativeContext, {
			...SINGLE_CHANNEL_OPTIONS,
			gain: 0
		});
		const leftInputForLeftOutputWaveShaperNode = createNativeWaveShaperNode(nativeContext, {
			...SINGLE_CHANNEL_WAVE_SHAPER_OPTIONS,
			curve: leftInputForLeftOutputWaveShaperCurve
		});
		const leftInputForRightOutputGainNode = createNativeGainNode(nativeContext, {
			...SINGLE_CHANNEL_OPTIONS,
			gain: 0
		});
		const leftInputForRightOutputWaveShaperNode = createNativeWaveShaperNode(nativeContext, {
			...SINGLE_CHANNEL_WAVE_SHAPER_OPTIONS,
			curve: leftInputForRightOutputWaveShaperCurve
		});
		const panWaveShaperNode = createNativeWaveShaperNode(nativeContext, {
			...SINGLE_CHANNEL_WAVE_SHAPER_OPTIONS,
			curve: DC_CURVE
		});
		const rightInputForLeftOutputGainNode = createNativeGainNode(nativeContext, {
			...SINGLE_CHANNEL_OPTIONS,
			gain: 0
		});
		const rightInputForLeftOutputWaveShaperNode = createNativeWaveShaperNode(nativeContext, {
			...SINGLE_CHANNEL_WAVE_SHAPER_OPTIONS,
			curve: rightInputForLeftOutputWaveShaperCurve
		});
		const rightInputForRightOutputGainNode = createNativeGainNode(nativeContext, {
			...SINGLE_CHANNEL_OPTIONS,
			gain: 0
		});
		const rightInputForRightOutputWaveShaperNode = createNativeWaveShaperNode(nativeContext, {
			...SINGLE_CHANNEL_WAVE_SHAPER_OPTIONS,
			curve: rightInputForRightOutputWaveShaperCurve
		});
		return {
			connectGraph() {
				inputGainNode.connect(channelSplitterNode);
				inputGainNode.connect(panWaveShaperNode.inputs === void 0 ? panWaveShaperNode : panWaveShaperNode.inputs[0]);
				channelSplitterNode.connect(leftInputForLeftOutputGainNode, 0);
				channelSplitterNode.connect(leftInputForRightOutputGainNode, 0);
				channelSplitterNode.connect(rightInputForLeftOutputGainNode, 1);
				channelSplitterNode.connect(rightInputForRightOutputGainNode, 1);
				panWaveShaperNode.connect(panGainNode);
				panGainNode.connect(leftInputForLeftOutputWaveShaperNode.inputs === void 0 ? leftInputForLeftOutputWaveShaperNode : leftInputForLeftOutputWaveShaperNode.inputs[0]);
				panGainNode.connect(leftInputForRightOutputWaveShaperNode.inputs === void 0 ? leftInputForRightOutputWaveShaperNode : leftInputForRightOutputWaveShaperNode.inputs[0]);
				panGainNode.connect(rightInputForLeftOutputWaveShaperNode.inputs === void 0 ? rightInputForLeftOutputWaveShaperNode : rightInputForLeftOutputWaveShaperNode.inputs[0]);
				panGainNode.connect(rightInputForRightOutputWaveShaperNode.inputs === void 0 ? rightInputForRightOutputWaveShaperNode : rightInputForRightOutputWaveShaperNode.inputs[0]);
				leftInputForLeftOutputWaveShaperNode.connect(leftInputForLeftOutputGainNode.gain);
				leftInputForRightOutputWaveShaperNode.connect(leftInputForRightOutputGainNode.gain);
				rightInputForLeftOutputWaveShaperNode.connect(rightInputForLeftOutputGainNode.gain);
				rightInputForRightOutputWaveShaperNode.connect(rightInputForRightOutputGainNode.gain);
				leftInputForLeftOutputGainNode.connect(channelMergerNode, 0, 0);
				rightInputForLeftOutputGainNode.connect(channelMergerNode, 0, 0);
				leftInputForRightOutputGainNode.connect(channelMergerNode, 0, 1);
				rightInputForRightOutputGainNode.connect(channelMergerNode, 0, 1);
			},
			disconnectGraph() {
				inputGainNode.disconnect(channelSplitterNode);
				inputGainNode.disconnect(panWaveShaperNode.inputs === void 0 ? panWaveShaperNode : panWaveShaperNode.inputs[0]);
				channelSplitterNode.disconnect(leftInputForLeftOutputGainNode, 0);
				channelSplitterNode.disconnect(leftInputForRightOutputGainNode, 0);
				channelSplitterNode.disconnect(rightInputForLeftOutputGainNode, 1);
				channelSplitterNode.disconnect(rightInputForRightOutputGainNode, 1);
				panWaveShaperNode.disconnect(panGainNode);
				panGainNode.disconnect(leftInputForLeftOutputWaveShaperNode.inputs === void 0 ? leftInputForLeftOutputWaveShaperNode : leftInputForLeftOutputWaveShaperNode.inputs[0]);
				panGainNode.disconnect(leftInputForRightOutputWaveShaperNode.inputs === void 0 ? leftInputForRightOutputWaveShaperNode : leftInputForRightOutputWaveShaperNode.inputs[0]);
				panGainNode.disconnect(rightInputForLeftOutputWaveShaperNode.inputs === void 0 ? rightInputForLeftOutputWaveShaperNode : rightInputForLeftOutputWaveShaperNode.inputs[0]);
				panGainNode.disconnect(rightInputForRightOutputWaveShaperNode.inputs === void 0 ? rightInputForRightOutputWaveShaperNode : rightInputForRightOutputWaveShaperNode.inputs[0]);
				leftInputForLeftOutputWaveShaperNode.disconnect(leftInputForLeftOutputGainNode.gain);
				leftInputForRightOutputWaveShaperNode.disconnect(leftInputForRightOutputGainNode.gain);
				rightInputForLeftOutputWaveShaperNode.disconnect(rightInputForLeftOutputGainNode.gain);
				rightInputForRightOutputWaveShaperNode.disconnect(rightInputForRightOutputGainNode.gain);
				leftInputForLeftOutputGainNode.disconnect(channelMergerNode, 0, 0);
				rightInputForLeftOutputGainNode.disconnect(channelMergerNode, 0, 0);
				leftInputForRightOutputGainNode.disconnect(channelMergerNode, 0, 1);
				rightInputForRightOutputGainNode.disconnect(channelMergerNode, 0, 1);
			}
		};
	};
	const buildInternalGraph = (nativeContext, channelCount, inputGainNode, panGainNode, channelMergerNode) => {
		if (channelCount === 1) return buildInternalGraphForMono(nativeContext, inputGainNode, panGainNode, channelMergerNode);
		if (channelCount === 2) return buildInternalGraphForStereo(nativeContext, inputGainNode, panGainNode, channelMergerNode);
		throw createNotSupportedError();
	};
	return (nativeContext, { channelCount, channelCountMode, pan, ...audioNodeOptions }) => {
		if (channelCountMode === "max") throw createNotSupportedError();
		const channelMergerNode = createNativeChannelMergerNode(nativeContext, {
			...audioNodeOptions,
			channelCount: 1,
			channelCountMode,
			numberOfInputs: 2
		});
		const inputGainNode = createNativeGainNode(nativeContext, {
			...audioNodeOptions,
			channelCount,
			channelCountMode,
			gain: 1
		});
		const panGainNode = createNativeGainNode(nativeContext, {
			channelCount: 1,
			channelCountMode: "explicit",
			channelInterpretation: "discrete",
			gain: pan
		});
		let { connectGraph, disconnectGraph } = buildInternalGraph(nativeContext, channelCount, inputGainNode, panGainNode, channelMergerNode);
		Object.defineProperty(panGainNode.gain, "defaultValue", { get: () => 0 });
		Object.defineProperty(panGainNode.gain, "maxValue", { get: () => 1 });
		Object.defineProperty(panGainNode.gain, "minValue", { get: () => -1 });
		const nativeStereoPannerNodeFakerFactory = {
			get bufferSize() {},
			get channelCount() {
				return inputGainNode.channelCount;
			},
			set channelCount(value) {
				if (inputGainNode.channelCount !== value) {
					if (isConnected) disconnectGraph();
					({connectGraph, disconnectGraph} = buildInternalGraph(nativeContext, value, inputGainNode, panGainNode, channelMergerNode));
					if (isConnected) connectGraph();
				}
				inputGainNode.channelCount = value;
			},
			get channelCountMode() {
				return inputGainNode.channelCountMode;
			},
			set channelCountMode(value) {
				if (value === "clamped-max" || value === "max") throw createNotSupportedError();
				inputGainNode.channelCountMode = value;
			},
			get channelInterpretation() {
				return inputGainNode.channelInterpretation;
			},
			set channelInterpretation(value) {
				inputGainNode.channelInterpretation = value;
			},
			get context() {
				return inputGainNode.context;
			},
			get inputs() {
				return [inputGainNode];
			},
			get numberOfInputs() {
				return inputGainNode.numberOfInputs;
			},
			get numberOfOutputs() {
				return inputGainNode.numberOfOutputs;
			},
			get pan() {
				return panGainNode.gain;
			},
			addEventListener(...args) {
				return inputGainNode.addEventListener(args[0], args[1], args[2]);
			},
			dispatchEvent(...args) {
				return inputGainNode.dispatchEvent(args[0]);
			},
			removeEventListener(...args) {
				return inputGainNode.removeEventListener(args[0], args[1], args[2]);
			}
		};
		let isConnected = false;
		const whenConnected = () => {
			connectGraph();
			isConnected = true;
		};
		const whenDisconnected = () => {
			disconnectGraph();
			isConnected = false;
		};
		return monitorConnections(interceptConnections(nativeStereoPannerNodeFakerFactory, channelMergerNode), whenConnected, whenDisconnected);
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/native-wave-shaper-node-factory.js
var createNativeWaveShaperNodeFactory = (createConnectedNativeAudioBufferSourceNode, createInvalidStateError, createNativeWaveShaperNodeFaker, isDCCurve, monitorConnections, nativeAudioContextConstructor, overwriteAccessors) => {
	return (nativeContext, options) => {
		const nativeWaveShaperNode = nativeContext.createWaveShaper();
		if (nativeAudioContextConstructor !== null && nativeAudioContextConstructor.name === "webkitAudioContext" && nativeContext.createGain().gain.automationRate === void 0) return createNativeWaveShaperNodeFaker(nativeContext, options);
		assignNativeAudioNodeOptions(nativeWaveShaperNode, options);
		const curve = options.curve === null || options.curve instanceof Float32Array ? options.curve : new Float32Array(options.curve);
		if (curve !== null && curve.length < 2) throw createInvalidStateError();
		assignNativeAudioNodeOption(nativeWaveShaperNode, { curve }, "curve");
		assignNativeAudioNodeOption(nativeWaveShaperNode, options, "oversample");
		let disconnectNativeAudioBufferSourceNode = null;
		let isConnected = false;
		overwriteAccessors(nativeWaveShaperNode, "curve", (get) => () => get.call(nativeWaveShaperNode), (set) => (value) => {
			set.call(nativeWaveShaperNode, value);
			if (isConnected) {
				if (isDCCurve(value) && disconnectNativeAudioBufferSourceNode === null) disconnectNativeAudioBufferSourceNode = createConnectedNativeAudioBufferSourceNode(nativeContext, nativeWaveShaperNode);
				else if (!isDCCurve(value) && disconnectNativeAudioBufferSourceNode !== null) {
					disconnectNativeAudioBufferSourceNode();
					disconnectNativeAudioBufferSourceNode = null;
				}
			}
			return value;
		});
		const whenConnected = () => {
			isConnected = true;
			if (isDCCurve(nativeWaveShaperNode.curve)) disconnectNativeAudioBufferSourceNode = createConnectedNativeAudioBufferSourceNode(nativeContext, nativeWaveShaperNode);
		};
		const whenDisconnected = () => {
			isConnected = false;
			if (disconnectNativeAudioBufferSourceNode !== null) {
				disconnectNativeAudioBufferSourceNode();
				disconnectNativeAudioBufferSourceNode = null;
			}
		};
		return monitorConnections(nativeWaveShaperNode, whenConnected, whenDisconnected);
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/native-wave-shaper-node-faker-factory.js
var createNativeWaveShaperNodeFakerFactory = (createConnectedNativeAudioBufferSourceNode, createInvalidStateError, createNativeGainNode, isDCCurve, monitorConnections) => {
	return (nativeContext, { curve, oversample, ...audioNodeOptions }) => {
		const negativeWaveShaperNode = nativeContext.createWaveShaper();
		const positiveWaveShaperNode = nativeContext.createWaveShaper();
		assignNativeAudioNodeOptions(negativeWaveShaperNode, audioNodeOptions);
		assignNativeAudioNodeOptions(positiveWaveShaperNode, audioNodeOptions);
		const inputGainNode = createNativeGainNode(nativeContext, {
			...audioNodeOptions,
			gain: 1
		});
		const invertGainNode = createNativeGainNode(nativeContext, {
			...audioNodeOptions,
			gain: -1
		});
		const outputGainNode = createNativeGainNode(nativeContext, {
			...audioNodeOptions,
			gain: 1
		});
		const revertGainNode = createNativeGainNode(nativeContext, {
			...audioNodeOptions,
			gain: -1
		});
		let disconnectNativeAudioBufferSourceNode = null;
		let isConnected = false;
		let unmodifiedCurve = null;
		const nativeWaveShaperNodeFaker = {
			get bufferSize() {},
			get channelCount() {
				return negativeWaveShaperNode.channelCount;
			},
			set channelCount(value) {
				inputGainNode.channelCount = value;
				invertGainNode.channelCount = value;
				negativeWaveShaperNode.channelCount = value;
				outputGainNode.channelCount = value;
				positiveWaveShaperNode.channelCount = value;
				revertGainNode.channelCount = value;
			},
			get channelCountMode() {
				return negativeWaveShaperNode.channelCountMode;
			},
			set channelCountMode(value) {
				inputGainNode.channelCountMode = value;
				invertGainNode.channelCountMode = value;
				negativeWaveShaperNode.channelCountMode = value;
				outputGainNode.channelCountMode = value;
				positiveWaveShaperNode.channelCountMode = value;
				revertGainNode.channelCountMode = value;
			},
			get channelInterpretation() {
				return negativeWaveShaperNode.channelInterpretation;
			},
			set channelInterpretation(value) {
				inputGainNode.channelInterpretation = value;
				invertGainNode.channelInterpretation = value;
				negativeWaveShaperNode.channelInterpretation = value;
				outputGainNode.channelInterpretation = value;
				positiveWaveShaperNode.channelInterpretation = value;
				revertGainNode.channelInterpretation = value;
			},
			get context() {
				return negativeWaveShaperNode.context;
			},
			get curve() {
				return unmodifiedCurve;
			},
			set curve(value) {
				if (value !== null && value.length < 2) throw createInvalidStateError();
				if (value === null) {
					negativeWaveShaperNode.curve = value;
					positiveWaveShaperNode.curve = value;
				} else {
					const curveLength = value.length;
					const negativeCurve = new Float32Array(curveLength + 2 - curveLength % 2);
					const positiveCurve = new Float32Array(curveLength + 2 - curveLength % 2);
					negativeCurve[0] = value[0];
					positiveCurve[0] = -value[curveLength - 1];
					const length = Math.ceil((curveLength + 1) / 2);
					const centerIndex = (curveLength + 1) / 2 - 1;
					for (let i = 1; i < length; i += 1) {
						const theoreticIndex = i / length * centerIndex;
						const lowerIndex = Math.floor(theoreticIndex);
						const upperIndex = Math.ceil(theoreticIndex);
						negativeCurve[i] = lowerIndex === upperIndex ? value[lowerIndex] : (1 - (theoreticIndex - lowerIndex)) * value[lowerIndex] + (1 - (upperIndex - theoreticIndex)) * value[upperIndex];
						positiveCurve[i] = lowerIndex === upperIndex ? -value[curveLength - 1 - lowerIndex] : -((1 - (theoreticIndex - lowerIndex)) * value[curveLength - 1 - lowerIndex]) - (1 - (upperIndex - theoreticIndex)) * value[curveLength - 1 - upperIndex];
					}
					negativeCurve[length] = curveLength % 2 === 1 ? value[length - 1] : (value[length - 2] + value[length - 1]) / 2;
					negativeWaveShaperNode.curve = negativeCurve;
					positiveWaveShaperNode.curve = positiveCurve;
				}
				unmodifiedCurve = value;
				if (isConnected) {
					if (isDCCurve(unmodifiedCurve) && disconnectNativeAudioBufferSourceNode === null) disconnectNativeAudioBufferSourceNode = createConnectedNativeAudioBufferSourceNode(nativeContext, inputGainNode);
					else if (disconnectNativeAudioBufferSourceNode !== null) {
						disconnectNativeAudioBufferSourceNode();
						disconnectNativeAudioBufferSourceNode = null;
					}
				}
			},
			get inputs() {
				return [inputGainNode];
			},
			get numberOfInputs() {
				return negativeWaveShaperNode.numberOfInputs;
			},
			get numberOfOutputs() {
				return negativeWaveShaperNode.numberOfOutputs;
			},
			get oversample() {
				return negativeWaveShaperNode.oversample;
			},
			set oversample(value) {
				negativeWaveShaperNode.oversample = value;
				positiveWaveShaperNode.oversample = value;
			},
			addEventListener(...args) {
				return inputGainNode.addEventListener(args[0], args[1], args[2]);
			},
			dispatchEvent(...args) {
				return inputGainNode.dispatchEvent(args[0]);
			},
			removeEventListener(...args) {
				return inputGainNode.removeEventListener(args[0], args[1], args[2]);
			}
		};
		if (curve !== null) nativeWaveShaperNodeFaker.curve = curve instanceof Float32Array ? curve : new Float32Array(curve);
		if (oversample !== nativeWaveShaperNodeFaker.oversample) nativeWaveShaperNodeFaker.oversample = oversample;
		const whenConnected = () => {
			inputGainNode.connect(negativeWaveShaperNode).connect(outputGainNode);
			inputGainNode.connect(invertGainNode).connect(positiveWaveShaperNode).connect(revertGainNode).connect(outputGainNode);
			isConnected = true;
			if (isDCCurve(unmodifiedCurve)) disconnectNativeAudioBufferSourceNode = createConnectedNativeAudioBufferSourceNode(nativeContext, inputGainNode);
		};
		const whenDisconnected = () => {
			inputGainNode.disconnect(negativeWaveShaperNode);
			negativeWaveShaperNode.disconnect(outputGainNode);
			inputGainNode.disconnect(invertGainNode);
			invertGainNode.disconnect(positiveWaveShaperNode);
			positiveWaveShaperNode.disconnect(revertGainNode);
			revertGainNode.disconnect(outputGainNode);
			isConnected = false;
			if (disconnectNativeAudioBufferSourceNode !== null) {
				disconnectNativeAudioBufferSourceNode();
				disconnectNativeAudioBufferSourceNode = null;
			}
		};
		return monitorConnections(interceptConnections(nativeWaveShaperNodeFaker, outputGainNode), whenConnected, whenDisconnected);
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/not-supported-error.js
var createNotSupportedError = () => new DOMException("", "NotSupportedError");
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/render-automation.js
var createRenderAutomation = (getAudioParamRenderer, renderInputsOfAudioParam) => {
	return (nativeOfflineAudioContext, audioParam, nativeAudioParam) => {
		getAudioParamRenderer(audioParam).replay(nativeAudioParam);
		return renderInputsOfAudioParam(audioParam, nativeOfflineAudioContext, nativeAudioParam);
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/render-inputs-of-audio-node.js
var createRenderInputsOfAudioNode = (getAudioNodeConnections, getAudioNodeRenderer, isPartOfACycle) => {
	return async (audioNode, nativeOfflineAudioContext, nativeAudioNode) => {
		const audioNodeConnections = getAudioNodeConnections(audioNode);
		await Promise.all(audioNodeConnections.activeInputs.map((connections, input) => Array.from(connections).map(async ([source, output]) => {
			const renderedNativeAudioNode = await getAudioNodeRenderer(source).render(source, nativeOfflineAudioContext);
			const destination = audioNode.context.destination;
			if (!isPartOfACycle(source) && (audioNode !== destination || !isPartOfACycle(audioNode))) renderedNativeAudioNode.connect(nativeAudioNode, output, input);
		})).reduce((allRenderingPromises, renderingPromises) => [...allRenderingPromises, ...renderingPromises], []));
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/render-inputs-of-audio-param.js
var createRenderInputsOfAudioParam = (getAudioNodeRenderer, getAudioParamConnections, isPartOfACycle) => {
	return async (audioParam, nativeOfflineAudioContext, nativeAudioParam) => {
		const audioParamConnections = getAudioParamConnections(audioParam);
		await Promise.all(Array.from(audioParamConnections.activeInputs).map(async ([source, output]) => {
			const renderedNativeAudioNode = await getAudioNodeRenderer(source).render(source, nativeOfflineAudioContext);
			if (!isPartOfACycle(source)) renderedNativeAudioNode.connect(nativeAudioParam, output);
		}));
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/render-native-offline-audio-context.js
var createRenderNativeOfflineAudioContext = (cacheTestResult, createNativeGainNode, createNativeScriptProcessorNode, testOfflineAudioContextCurrentTimeSupport) => {
	return (nativeOfflineAudioContext) => {
		if (cacheTestResult(testPromiseSupport, () => testPromiseSupport(nativeOfflineAudioContext))) return Promise.resolve(cacheTestResult(testOfflineAudioContextCurrentTimeSupport, testOfflineAudioContextCurrentTimeSupport)).then((isOfflineAudioContextCurrentTimeSupported) => {
			if (!isOfflineAudioContextCurrentTimeSupported) {
				const scriptProcessorNode = createNativeScriptProcessorNode(nativeOfflineAudioContext, 512, 0, 1);
				nativeOfflineAudioContext.oncomplete = () => {
					scriptProcessorNode.onaudioprocess = null;
					scriptProcessorNode.disconnect();
				};
				scriptProcessorNode.onaudioprocess = () => nativeOfflineAudioContext.currentTime;
				scriptProcessorNode.connect(nativeOfflineAudioContext.destination);
			}
			return nativeOfflineAudioContext.startRendering();
		});
		return new Promise((resolve) => {
			const gainNode = createNativeGainNode(nativeOfflineAudioContext, {
				channelCount: 1,
				channelCountMode: "explicit",
				channelInterpretation: "discrete",
				gain: 0
			});
			nativeOfflineAudioContext.oncomplete = (event) => {
				gainNode.disconnect();
				resolve(event.renderedBuffer);
			};
			gainNode.connect(nativeOfflineAudioContext.destination);
			nativeOfflineAudioContext.startRendering();
		});
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/set-active-audio-worklet-node-inputs.js
var createSetActiveAudioWorkletNodeInputs = (activeAudioWorkletNodeInputsStore) => {
	return (nativeAudioWorkletNode, activeInputs) => {
		activeAudioWorkletNodeInputsStore.set(nativeAudioWorkletNode, activeInputs);
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/test-audio-buffer-constructor-support.js
var createTestAudioBufferConstructorSupport = (nativeAudioBufferConstructor) => {
	return () => {
		if (nativeAudioBufferConstructor === null) return false;
		try {
			new nativeAudioBufferConstructor({
				length: 1,
				sampleRate: 44100
			});
		} catch {
			return false;
		}
		return true;
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/test-audio-worklet-processor-post-message-support.js
var createTestAudioWorkletProcessorPostMessageSupport = (nativeAudioWorkletNodeConstructor, nativeOfflineAudioContextConstructor) => {
	return async () => {
		if (nativeAudioWorkletNodeConstructor === null) return true;
		if (nativeOfflineAudioContextConstructor === null) return false;
		const blob = new Blob(["class A extends AudioWorkletProcessor{process(i){this.port.postMessage(i,[i[0][0].buffer])}}registerProcessor(\"a\",A)"], { type: "application/javascript; charset=utf-8" });
		const offlineAudioContext = new nativeOfflineAudioContextConstructor(1, 128, 44100);
		const url = URL.createObjectURL(blob);
		let isEmittingMessageEvents = false;
		let isEmittingProcessorErrorEvents = false;
		try {
			await offlineAudioContext.audioWorklet.addModule(url);
			const audioWorkletNode = new nativeAudioWorkletNodeConstructor(offlineAudioContext, "a", { numberOfOutputs: 0 });
			const oscillator = offlineAudioContext.createOscillator();
			audioWorkletNode.port.onmessage = () => isEmittingMessageEvents = true;
			audioWorkletNode.onprocessorerror = () => isEmittingProcessorErrorEvents = true;
			oscillator.connect(audioWorkletNode);
			oscillator.start(0);
			await offlineAudioContext.startRendering();
			await new Promise((resolve) => setTimeout(resolve));
		} catch {} finally {
			URL.revokeObjectURL(url);
		}
		return isEmittingMessageEvents && !isEmittingProcessorErrorEvents;
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/test-offline-audio-context-current-time-support.js
var createTestOfflineAudioContextCurrentTimeSupport = (createNativeGainNode, nativeOfflineAudioContextConstructor) => {
	return () => {
		if (nativeOfflineAudioContextConstructor === null) return Promise.resolve(false);
		const nativeOfflineAudioContext = new nativeOfflineAudioContextConstructor(1, 1, 44100);
		const gainNode = createNativeGainNode(nativeOfflineAudioContext, {
			channelCount: 1,
			channelCountMode: "explicit",
			channelInterpretation: "discrete",
			gain: 0
		});
		return new Promise((resolve) => {
			nativeOfflineAudioContext.oncomplete = () => {
				gainNode.disconnect();
				resolve(nativeOfflineAudioContext.currentTime !== 0);
			};
			nativeOfflineAudioContext.startRendering();
		});
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/unknown-error.js
var createUnknownError = () => new DOMException("", "UnknownError");
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/window.js
var createWindow$1 = /* @__PURE__ */ __name(() => typeof window === "undefined" ? null : window, "createWindow");
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/wrap-audio-buffer-copy-channel-methods.js
var createWrapAudioBufferCopyChannelMethods = (convertNumberToUnsignedLong, createIndexSizeError) => {
	return (audioBuffer) => {
		audioBuffer.copyFromChannel = (destination, channelNumberAsNumber, bufferOffsetAsNumber = 0) => {
			const bufferOffset = convertNumberToUnsignedLong(bufferOffsetAsNumber);
			const channelNumber = convertNumberToUnsignedLong(channelNumberAsNumber);
			if (channelNumber >= audioBuffer.numberOfChannels) throw createIndexSizeError();
			const audioBufferLength = audioBuffer.length;
			const channelData = audioBuffer.getChannelData(channelNumber);
			const destinationLength = destination.length;
			for (let i = bufferOffset < 0 ? -bufferOffset : 0; i + bufferOffset < audioBufferLength && i < destinationLength; i += 1) destination[i] = channelData[i + bufferOffset];
		};
		audioBuffer.copyToChannel = (source, channelNumberAsNumber, bufferOffsetAsNumber = 0) => {
			const bufferOffset = convertNumberToUnsignedLong(bufferOffsetAsNumber);
			const channelNumber = convertNumberToUnsignedLong(channelNumberAsNumber);
			if (channelNumber >= audioBuffer.numberOfChannels) throw createIndexSizeError();
			const audioBufferLength = audioBuffer.length;
			const channelData = audioBuffer.getChannelData(channelNumber);
			const sourceLength = source.length;
			for (let i = bufferOffset < 0 ? -bufferOffset : 0; i + bufferOffset < audioBufferLength && i < sourceLength; i += 1) channelData[i + bufferOffset] = source[i];
		};
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/wrap-audio-buffer-copy-channel-methods-out-of-bounds.js
var createWrapAudioBufferCopyChannelMethodsOutOfBounds = (convertNumberToUnsignedLong) => {
	return (audioBuffer) => {
		audioBuffer.copyFromChannel = ((copyFromChannel) => {
			return (destination, channelNumberAsNumber, bufferOffsetAsNumber = 0) => {
				const bufferOffset = convertNumberToUnsignedLong(bufferOffsetAsNumber);
				const channelNumber = convertNumberToUnsignedLong(channelNumberAsNumber);
				if (bufferOffset < audioBuffer.length) return copyFromChannel.call(audioBuffer, destination, channelNumber, bufferOffset);
			};
		})(audioBuffer.copyFromChannel);
		audioBuffer.copyToChannel = ((copyToChannel) => {
			return (source, channelNumberAsNumber, bufferOffsetAsNumber = 0) => {
				const bufferOffset = convertNumberToUnsignedLong(bufferOffsetAsNumber);
				const channelNumber = convertNumberToUnsignedLong(channelNumberAsNumber);
				if (bufferOffset < audioBuffer.length) return copyToChannel.call(audioBuffer, source, channelNumber, bufferOffset);
			};
		})(audioBuffer.copyToChannel);
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/wrap-audio-buffer-source-node-stop-method-nullified-buffer.js
var createWrapAudioBufferSourceNodeStopMethodNullifiedBuffer = (overwriteAccessors) => {
	return (nativeAudioBufferSourceNode, nativeContext) => {
		const nullifiedBuffer = nativeContext.createBuffer(1, 1, 44100);
		if (nativeAudioBufferSourceNode.buffer === null) nativeAudioBufferSourceNode.buffer = nullifiedBuffer;
		overwriteAccessors(nativeAudioBufferSourceNode, "buffer", (get) => () => {
			const value = get.call(nativeAudioBufferSourceNode);
			return value === nullifiedBuffer ? null : value;
		}, (set) => (value) => {
			return set.call(nativeAudioBufferSourceNode, value === null ? nullifiedBuffer : value);
		});
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/factories/wrap-channel-merger-node.js
var createWrapChannelMergerNode = (createInvalidStateError, monitorConnections) => {
	return (nativeContext, channelMergerNode) => {
		channelMergerNode.channelCount = 1;
		channelMergerNode.channelCountMode = "explicit";
		Object.defineProperty(channelMergerNode, "channelCount", {
			get: () => 1,
			set: () => {
				throw createInvalidStateError();
			}
		});
		Object.defineProperty(channelMergerNode, "channelCountMode", {
			get: () => "explicit",
			set: () => {
				throw createInvalidStateError();
			}
		});
		const audioBufferSourceNode = nativeContext.createBufferSource();
		const whenConnected = () => {
			const length = channelMergerNode.numberOfInputs;
			for (let i = 0; i < length; i += 1) audioBufferSourceNode.connect(channelMergerNode, 0, i);
		};
		const whenDisconnected = () => audioBufferSourceNode.disconnect(channelMergerNode);
		monitorConnections(channelMergerNode, whenConnected, whenDisconnected);
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/get-first-sample.js
var getFirstSample = (audioBuffer, buffer, channelNumber) => {
	if (audioBuffer.copyFromChannel === void 0) return audioBuffer.getChannelData(channelNumber)[0];
	audioBuffer.copyFromChannel(buffer, channelNumber);
	return buffer[0];
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/is-dc-curve.js
var isDCCurve = (curve) => {
	if (curve === null) return false;
	const length = curve.length;
	if (length % 2 !== 0) return curve[Math.floor(length / 2)] !== 0;
	return curve[length / 2 - 1] + curve[length / 2] !== 0;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/overwrite-accessors.js
var overwriteAccessors = (object, property, createGetter, createSetter) => {
	let prototype = object;
	while (!prototype.hasOwnProperty(property)) prototype = Object.getPrototypeOf(prototype);
	const { get, set } = Object.getOwnPropertyDescriptor(prototype, property);
	Object.defineProperty(object, property, {
		get: createGetter(get),
		set: createSetter(set)
	});
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/sanitize-audio-worklet-node-options.js
var sanitizeAudioWorkletNodeOptions = (options) => {
	return {
		...options,
		outputChannelCount: options.outputChannelCount !== void 0 ? options.outputChannelCount : options.numberOfInputs === 1 && options.numberOfOutputs === 1 ? [options.channelCount] : Array.from({ length: options.numberOfOutputs }, () => 1)
	};
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/set-value-at-time-until-possible.js
var setValueAtTimeUntilPossible = (audioParam, value, startTime) => {
	try {
		audioParam.setValueAtTime(value, startTime);
	} catch (err) {
		if (err.code !== 9) throw err;
		setValueAtTimeUntilPossible(audioParam, value, startTime + 1e-7);
	}
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/test-audio-buffer-source-node-start-method-consecutive-calls-support.js
var testAudioBufferSourceNodeStartMethodConsecutiveCallsSupport = (nativeContext) => {
	const nativeAudioBufferSourceNode = nativeContext.createBufferSource();
	nativeAudioBufferSourceNode.start();
	try {
		nativeAudioBufferSourceNode.start();
	} catch {
		return true;
	}
	return false;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/test-audio-buffer-source-node-start-method-offset-clamping-support.js
var testAudioBufferSourceNodeStartMethodOffsetClampingSupport = (nativeContext) => {
	const nativeAudioBufferSourceNode = nativeContext.createBufferSource();
	nativeAudioBufferSourceNode.buffer = nativeContext.createBuffer(1, 1, 44100);
	try {
		nativeAudioBufferSourceNode.start(0, 1);
	} catch {
		return false;
	}
	return true;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/test-audio-buffer-source-node-stop-method-nullified-buffer-support.js
var testAudioBufferSourceNodeStopMethodNullifiedBufferSupport = (nativeContext) => {
	const nativeAudioBufferSourceNode = nativeContext.createBufferSource();
	nativeAudioBufferSourceNode.start();
	try {
		nativeAudioBufferSourceNode.stop();
	} catch {
		return false;
	}
	return true;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/test-audio-scheduled-source-node-start-method-negative-parameters-support.js
var testAudioScheduledSourceNodeStartMethodNegativeParametersSupport = (nativeContext) => {
	const nativeAudioBufferSourceNode = nativeContext.createOscillator();
	try {
		nativeAudioBufferSourceNode.start(-1);
	} catch (err) {
		return err instanceof RangeError;
	}
	return false;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/test-audio-scheduled-source-node-stop-method-consecutive-calls-support.js
var testAudioScheduledSourceNodeStopMethodConsecutiveCallsSupport = (nativeContext) => {
	const nativeAudioBuffer = nativeContext.createBuffer(1, 1, 44100);
	const nativeAudioBufferSourceNode = nativeContext.createBufferSource();
	nativeAudioBufferSourceNode.buffer = nativeAudioBuffer;
	nativeAudioBufferSourceNode.start();
	nativeAudioBufferSourceNode.stop();
	try {
		nativeAudioBufferSourceNode.stop();
		return true;
	} catch {
		return false;
	}
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/test-audio-scheduled-source-node-stop-method-negative-parameters-support.js
var testAudioScheduledSourceNodeStopMethodNegativeParametersSupport = (nativeContext) => {
	const nativeAudioBufferSourceNode = nativeContext.createOscillator();
	try {
		nativeAudioBufferSourceNode.stop(-1);
	} catch (err) {
		return err instanceof RangeError;
	}
	return false;
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/test-audio-worklet-node-options-clonability.js
var testAudioWorkletNodeOptionsClonability = (audioWorkletNodeOptions) => {
	const { port1, port2 } = new MessageChannel();
	try {
		port1.postMessage(audioWorkletNodeOptions);
	} finally {
		port1.close();
		port2.close();
	}
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/wrap-audio-buffer-source-node-start-method-offset-clamping.js
var wrapAudioBufferSourceNodeStartMethodOffsetClamping = (nativeAudioBufferSourceNode) => {
	nativeAudioBufferSourceNode.start = ((start) => {
		return (when = 0, offset = 0, duration) => {
			const buffer = nativeAudioBufferSourceNode.buffer;
			const clampedOffset = buffer === null ? offset : Math.min(buffer.duration, offset);
			if (buffer !== null && clampedOffset > buffer.duration - .5 / nativeAudioBufferSourceNode.context.sampleRate) start.call(nativeAudioBufferSourceNode, when, 0, 0);
			else start.call(nativeAudioBufferSourceNode, when, clampedOffset, duration);
		};
	})(nativeAudioBufferSourceNode.start);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/wrap-audio-scheduled-source-node-stop-method-consecutive-calls.js
var wrapAudioScheduledSourceNodeStopMethodConsecutiveCalls = (nativeAudioScheduledSourceNode, nativeContext) => {
	const nativeGainNode = nativeContext.createGain();
	nativeAudioScheduledSourceNode.connect(nativeGainNode);
	const disconnectGainNode = ((disconnect) => {
		return () => {
			disconnect.call(nativeAudioScheduledSourceNode, nativeGainNode);
			nativeAudioScheduledSourceNode.removeEventListener("ended", disconnectGainNode);
		};
	})(nativeAudioScheduledSourceNode.disconnect);
	nativeAudioScheduledSourceNode.addEventListener("ended", disconnectGainNode);
	interceptConnections(nativeAudioScheduledSourceNode, nativeGainNode);
	nativeAudioScheduledSourceNode.stop = ((stop) => {
		let isStopped = false;
		return (when = 0) => {
			if (isStopped) try {
				stop.call(nativeAudioScheduledSourceNode, when);
			} catch {
				nativeGainNode.gain.setValueAtTime(0, when);
			}
			else {
				stop.call(nativeAudioScheduledSourceNode, when);
				isStopped = true;
			}
		};
	})(nativeAudioScheduledSourceNode.stop);
};
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/helpers/wrap-event-listener.js
var wrapEventListener$1 = /* @__PURE__ */ __name((target, eventListener) => {
	return (event) => {
		const descriptor = { value: target };
		Object.defineProperties(event, {
			currentTarget: descriptor,
			target: descriptor
		});
		if (typeof eventListener === "function") return eventListener.call(target, event);
		return eventListener.handleEvent.call(target, event);
	};
}, "wrapEventListener");
//#endregion
//#region node_modules/.pnpm/standardized-audio-context@25.3.77/node_modules/standardized-audio-context/build/es2019/module.js
var addActiveInputConnectionToAudioNode = createAddActiveInputConnectionToAudioNode(insertElementInSet);
var addPassiveInputConnectionToAudioNode = createAddPassiveInputConnectionToAudioNode(insertElementInSet);
var deleteActiveInputConnectionToAudioNode = createDeleteActiveInputConnectionToAudioNode(pickElementFromSet);
var getAudioNodeTailTime = createGetAudioNodeTailTime(/* @__PURE__ */ new WeakMap());
var cacheTestResult = createCacheTestResult(/* @__PURE__ */ new Map(), /* @__PURE__ */ new WeakMap());
var window$2 = createWindow$1();
var getAudioNodeRenderer = createGetAudioNodeRenderer(getAudioNodeConnections);
var renderInputsOfAudioNode = createRenderInputsOfAudioNode(getAudioNodeConnections, getAudioNodeRenderer, isPartOfACycle);
var getNativeContext = createGetNativeContext(CONTEXT_STORE);
var nativeOfflineAudioContextConstructor = createNativeOfflineAudioContextConstructor(window$2);
var isNativeOfflineAudioContext = createIsNativeOfflineAudioContext(nativeOfflineAudioContextConstructor);
var audioParamAudioNodeStore = /* @__PURE__ */ new WeakMap();
var eventTargetConstructor = createEventTargetConstructor(wrapEventListener$1);
var nativeAudioContextConstructor = createNativeAudioContextConstructor(window$2);
var isNativeAudioContext = createIsNativeAudioContext(nativeAudioContextConstructor);
var isNativeAudioNode = createIsNativeAudioNode(window$2);
var isNativeAudioParam = createIsNativeAudioParam(window$2);
var nativeAudioWorkletNodeConstructor = createNativeAudioWorkletNodeConstructor(window$2);
var audioNodeConstructor = createAudioNodeConstructor(createAddAudioNodeConnections(AUDIO_NODE_CONNECTIONS_STORE), createAddConnectionToAudioNode(addActiveInputConnectionToAudioNode, addPassiveInputConnectionToAudioNode, connectNativeAudioNodeToNativeAudioNode, deleteActiveInputConnectionToAudioNode, disconnectNativeAudioNodeFromNativeAudioNode, getAudioNodeConnections, getAudioNodeTailTime, getEventListenersOfAudioNode, getNativeAudioNode, insertElementInSet, isActiveAudioNode, isPartOfACycle, isPassiveAudioNode), cacheTestResult, createIncrementCycleCounterFactory(CYCLE_COUNTERS, disconnectNativeAudioNodeFromNativeAudioNode, getAudioNodeConnections, getNativeAudioNode, getNativeAudioParam, isActiveAudioNode), createIndexSizeError, createInvalidAccessError, createNotSupportedError, createDecrementCycleCounter(connectNativeAudioNodeToNativeAudioNode, CYCLE_COUNTERS, getAudioNodeConnections, getNativeAudioNode, getNativeAudioParam, getNativeContext, isActiveAudioNode, isNativeOfflineAudioContext), createDetectCycles(audioParamAudioNodeStore, getAudioNodeConnections, getValueForKey), eventTargetConstructor, getNativeContext, isNativeAudioContext, isNativeAudioNode, isNativeAudioParam, isNativeOfflineAudioContext, nativeAudioWorkletNodeConstructor);
var audioBufferStore = /* @__PURE__ */ new WeakSet();
var nativeAudioBufferConstructor = createNativeAudioBufferConstructor(window$2);
var convertNumberToUnsignedLong = createConvertNumberToUnsignedLong(/* @__PURE__ */ new Uint32Array(1));
var wrapAudioBufferCopyChannelMethods = createWrapAudioBufferCopyChannelMethods(convertNumberToUnsignedLong, createIndexSizeError);
var wrapAudioBufferCopyChannelMethodsOutOfBounds = createWrapAudioBufferCopyChannelMethodsOutOfBounds(convertNumberToUnsignedLong);
var audioBufferConstructor = createAudioBufferConstructor(audioBufferStore, cacheTestResult, createNotSupportedError, nativeAudioBufferConstructor, nativeOfflineAudioContextConstructor, createTestAudioBufferConstructorSupport(nativeAudioBufferConstructor), wrapAudioBufferCopyChannelMethods, wrapAudioBufferCopyChannelMethodsOutOfBounds);
var addSilentConnection = createAddSilentConnection(createNativeGainNode);
var renderInputsOfAudioParam = createRenderInputsOfAudioParam(getAudioNodeRenderer, getAudioParamConnections, isPartOfACycle);
var connectAudioParam = createConnectAudioParam(renderInputsOfAudioParam);
var createNativeAudioBufferSourceNode = createNativeAudioBufferSourceNodeFactory(addSilentConnection, cacheTestResult, testAudioBufferSourceNodeStartMethodConsecutiveCallsSupport, testAudioBufferSourceNodeStartMethodOffsetClampingSupport, testAudioBufferSourceNodeStopMethodNullifiedBufferSupport, testAudioScheduledSourceNodeStartMethodNegativeParametersSupport, testAudioScheduledSourceNodeStopMethodConsecutiveCallsSupport, testAudioScheduledSourceNodeStopMethodNegativeParametersSupport, wrapAudioBufferSourceNodeStartMethodOffsetClamping, createWrapAudioBufferSourceNodeStopMethodNullifiedBuffer(overwriteAccessors), wrapAudioScheduledSourceNodeStopMethodConsecutiveCalls);
var renderAutomation = createRenderAutomation(createGetAudioParamRenderer(getAudioParamConnections), renderInputsOfAudioParam);
var createAudioBufferSourceNodeRenderer = createAudioBufferSourceNodeRendererFactory(connectAudioParam, createNativeAudioBufferSourceNode, getNativeAudioNode, renderAutomation, renderInputsOfAudioNode);
var createAudioParam = createAudioParamFactory(createAddAudioParamConnections(AUDIO_PARAM_CONNECTIONS_STORE), audioParamAudioNodeStore, AUDIO_PARAM_STORE, createAudioParamRenderer, import_bundle$1.createCancelAndHoldAutomationEvent, import_bundle$1.createCancelScheduledValuesAutomationEvent, import_bundle$1.createExponentialRampToValueAutomationEvent, import_bundle$1.createLinearRampToValueAutomationEvent, import_bundle$1.createSetTargetAutomationEvent, import_bundle$1.createSetValueAutomationEvent, import_bundle$1.createSetValueCurveAutomationEvent, nativeAudioContextConstructor, setValueAtTimeUntilPossible);
var audioBufferSourceNodeConstructor = createAudioBufferSourceNodeConstructor(audioNodeConstructor, createAudioBufferSourceNodeRenderer, createAudioParam, createInvalidStateError, createNativeAudioBufferSourceNode, getNativeContext, isNativeOfflineAudioContext, wrapEventListener$1);
var audioDestinationNodeConstructor = createAudioDestinationNodeConstructor(audioNodeConstructor, createAudioDestinationNodeRenderer, createIndexSizeError, createInvalidStateError, createNativeAudioDestinationNodeFactory(createNativeGainNode, overwriteAccessors), getNativeContext, isNativeOfflineAudioContext, renderInputsOfAudioNode);
var monitorConnections = createMonitorConnections(insertElementInSet, isNativeAudioNode);
var createNativeChannelMergerNode = createNativeChannelMergerNodeFactory(nativeAudioContextConstructor, createWrapChannelMergerNode(createInvalidStateError, monitorConnections));
var createNativeConstantSourceNode = createNativeConstantSourceNodeFactory(addSilentConnection, cacheTestResult, createNativeConstantSourceNodeFakerFactory(addSilentConnection, createNativeAudioBufferSourceNode, createNativeGainNode, monitorConnections), testAudioScheduledSourceNodeStartMethodNegativeParametersSupport, testAudioScheduledSourceNodeStopMethodNegativeParametersSupport);
var renderNativeOfflineAudioContext = createRenderNativeOfflineAudioContext(cacheTestResult, createNativeGainNode, createNativeScriptProcessorNode, createTestOfflineAudioContextCurrentTimeSupport(createNativeGainNode, nativeOfflineAudioContextConstructor));
var createAudioListener = createAudioListenerFactory(createAudioParam, createNativeChannelMergerNode, createNativeConstantSourceNode, createNativeScriptProcessorNode, createNotSupportedError, getFirstSample, isNativeOfflineAudioContext, overwriteAccessors);
var unrenderedAudioWorkletNodeStore = /* @__PURE__ */ new WeakMap();
var minimalBaseAudioContextConstructor = createMinimalBaseAudioContextConstructor(audioDestinationNodeConstructor, createAudioListener, eventTargetConstructor, isNativeOfflineAudioContext, unrenderedAudioWorkletNodeStore, wrapEventListener$1);
var createConnectedNativeAudioBufferSourceNode = createConnectedNativeAudioBufferSourceNodeFactory(createNativeAudioBufferSourceNode);
createNativeStereoPannerNodeFakerFactory(createNativeChannelMergerNode, createNativeChannelSplitterNode, createNativeGainNode, createNativeWaveShaperNodeFactory(createConnectedNativeAudioBufferSourceNode, createInvalidStateError, createNativeWaveShaperNodeFakerFactory(createConnectedNativeAudioBufferSourceNode, createInvalidStateError, createNativeGainNode, isDCCurve, monitorConnections), isDCCurve, monitorConnections, nativeAudioContextConstructor, overwriteAccessors), createNotSupportedError, monitorConnections);
var isSecureContext = createIsSecureContext(window$2);
var exposeCurrentFrameAndCurrentTime = createExposeCurrentFrameAndCurrentTime(window$2);
var backupOfflineAudioContextStore = /* @__PURE__ */ new WeakMap();
var getOrCreateBackupOfflineAudioContext = createGetOrCreateBackupOfflineAudioContext(backupOfflineAudioContextStore, nativeOfflineAudioContextConstructor);
var addAudioWorkletModule = isSecureContext ? createAddAudioWorkletModule(cacheTestResult, createNotSupportedError, createEvaluateSource(window$2), exposeCurrentFrameAndCurrentTime, createFetchSource(createAbortError), getNativeContext, getOrCreateBackupOfflineAudioContext, isNativeOfflineAudioContext, nativeAudioWorkletNodeConstructor, /* @__PURE__ */ new WeakMap(), /* @__PURE__ */ new WeakMap(), createTestAudioWorkletProcessorPostMessageSupport(nativeAudioWorkletNodeConstructor, nativeOfflineAudioContextConstructor), window$2) : void 0;
var mediaStreamAudioSourceNodeConstructor = createMediaStreamAudioSourceNodeConstructor(audioNodeConstructor, createNativeMediaStreamAudioSourceNode, getNativeContext, isNativeOfflineAudioContext);
var getUnrenderedAudioWorkletNodes = createGetUnrenderedAudioWorkletNodes(unrenderedAudioWorkletNodeStore);
var addUnrenderedAudioWorkletNode = createAddUnrenderedAudioWorkletNode(getUnrenderedAudioWorkletNodes);
var connectMultipleOutputs = createConnectMultipleOutputs(createIndexSizeError);
var deleteUnrenderedAudioWorkletNode = createDeleteUnrenderedAudioWorkletNode(getUnrenderedAudioWorkletNodes);
var disconnectMultipleOutputs = createDisconnectMultipleOutputs(createIndexSizeError);
var activeAudioWorkletNodeInputsStore = /* @__PURE__ */ new WeakMap();
var createNativeAudioWorkletNode = createNativeAudioWorkletNodeFactory(createInvalidStateError, createNativeAudioWorkletNodeFakerFactory(connectMultipleOutputs, createIndexSizeError, createInvalidStateError, createNativeChannelMergerNode, createNativeChannelSplitterNode, createNativeConstantSourceNode, createNativeGainNode, createNativeScriptProcessorNode, createNotSupportedError, disconnectMultipleOutputs, exposeCurrentFrameAndCurrentTime, createGetActiveAudioWorkletNodeInputs(activeAudioWorkletNodeInputsStore, getValueForKey), monitorConnections), createNativeGainNode, createNotSupportedError, monitorConnections);
var createAudioWorkletNodeRenderer = createAudioWorkletNodeRendererFactory(connectAudioParam, connectMultipleOutputs, createNativeAudioBufferSourceNode, createNativeChannelMergerNode, createNativeChannelSplitterNode, createNativeConstantSourceNode, createNativeGainNode, deleteUnrenderedAudioWorkletNode, disconnectMultipleOutputs, exposeCurrentFrameAndCurrentTime, getNativeAudioNode, nativeAudioWorkletNodeConstructor, nativeOfflineAudioContextConstructor, renderAutomation, renderInputsOfAudioNode, renderNativeOfflineAudioContext);
var getBackupOfflineAudioContext = createGetBackupOfflineAudioContext(backupOfflineAudioContextStore);
var setActiveAudioWorkletNodeInputs = createSetActiveAudioWorkletNodeInputs(activeAudioWorkletNodeInputsStore);
var audioWorkletNodeConstructor = isSecureContext ? createAudioWorkletNodeConstructor(addUnrenderedAudioWorkletNode, audioNodeConstructor, createAudioParam, createAudioWorkletNodeRenderer, createNativeAudioWorkletNode, getAudioNodeConnections, getBackupOfflineAudioContext, getNativeContext, isNativeOfflineAudioContext, nativeAudioWorkletNodeConstructor, sanitizeAudioWorkletNodeOptions, setActiveAudioWorkletNodeInputs, testAudioWorkletNodeOptionsClonability, wrapEventListener$1) : void 0;
var minimalAudioContextConstructor = createMinimalAudioContextConstructor(createInvalidStateError, createNotSupportedError, createUnknownError, minimalBaseAudioContextConstructor, nativeAudioContextConstructor);
//#endregion
//#region node_modules/.pnpm/extendable-media-recorder@9.2.38/node_modules/extendable-media-recorder/build/es2019/factories/web-audio-media-recorder.js
var ERROR_MESSAGE = "Missing AudioWorklet support. Maybe this is not running in a secure context.";
var createPromisedAudioNodesEncoderInstanceIdAndPort = async (audioBuffer, audioContext, channelCount, mediaStream, mimeType) => {
	const { encoderInstanceId, port } = await instantiate(mimeType, audioContext.sampleRate);
	if (audioWorkletNodeConstructor === void 0) throw new Error(ERROR_MESSAGE);
	return {
		audioBufferSourceNode: audioBuffer === null ? null : new audioBufferSourceNodeConstructor(audioContext, { buffer: audioBuffer }),
		encoderInstanceId,
		mediaStreamAudioSourceNode: new mediaStreamAudioSourceNodeConstructor(audioContext, { mediaStream }),
		port,
		recorderAudioWorkletNode: createRecorderAudioWorkletNode(audioWorkletNodeConstructor, audioContext, { channelCount })
	};
};
var createWebAudioMediaRecorderFactory = (createBlobEvent, createInvalidModificationError, createInvalidStateError, createNotSupportedError) => {
	return (eventTarget, mediaStream, mimeType) => {
		var _a;
		const audioContext = new minimalAudioContextConstructor({
			latencyHint: "playback",
			sampleRate: (_a = mediaStream.getAudioTracks()[0]) === null || _a === void 0 ? void 0 : _a.getSettings().sampleRate
		});
		const audioBuffer = MediaRecorder.isTypeSupported("audio/mp4") ? new audioBufferConstructor({
			length: 2688,
			sampleRate: audioContext.sampleRate
		}) : null;
		const bufferedArrayBuffers = [];
		const promisedAudioWorkletModule = addRecorderAudioWorkletModule((url) => {
			if (addAudioWorkletModule === void 0) throw new Error(ERROR_MESSAGE);
			return addAudioWorkletModule(audioContext, url);
		});
		let abortRecording = null;
		let intervalId = null;
		let promisedAudioNodesAndEncoderInstanceId = null;
		let promisedPartialRecording = null;
		let isAudioContextRunning = true;
		const dispatchDataAvailableEvent = (arrayBuffers) => {
			eventTarget.dispatchEvent(createBlobEvent("dataavailable", { data: new Blob(arrayBuffers, { type: mimeType }) }));
		};
		const requestNextPartialRecording = async (encoderInstanceId, timeslice) => {
			const arrayBuffers = await encode$1(encoderInstanceId, timeslice);
			if (promisedAudioNodesAndEncoderInstanceId === null) bufferedArrayBuffers.push(...arrayBuffers);
			else {
				dispatchDataAvailableEvent(arrayBuffers);
				promisedPartialRecording = requestNextPartialRecording(encoderInstanceId, timeslice);
			}
		};
		const resume = () => {
			isAudioContextRunning = true;
			return audioContext.resume();
		};
		const stop = () => {
			if (promisedAudioNodesAndEncoderInstanceId === null) return;
			if (abortRecording !== null) {
				mediaStream.removeEventListener("addtrack", abortRecording);
				mediaStream.removeEventListener("removetrack", abortRecording);
			}
			if (intervalId !== null) clearTimeout(intervalId);
			promisedAudioNodesAndEncoderInstanceId.then(async ({ encoderInstanceId, mediaStreamAudioSourceNode, recorderAudioWorkletNode }) => {
				if (promisedPartialRecording !== null) {
					promisedPartialRecording.catch(() => {});
					promisedPartialRecording = null;
				}
				await recorderAudioWorkletNode.stop();
				mediaStreamAudioSourceNode.disconnect(recorderAudioWorkletNode);
				const arrayBuffers = await encode$1(encoderInstanceId, null);
				if (promisedAudioNodesAndEncoderInstanceId === null) await suspend();
				dispatchDataAvailableEvent([...bufferedArrayBuffers, ...arrayBuffers]);
				bufferedArrayBuffers.length = 0;
				eventTarget.dispatchEvent(new Event("stop"));
			});
			promisedAudioNodesAndEncoderInstanceId = null;
		};
		const suspend = () => {
			isAudioContextRunning = false;
			return audioContext.suspend();
		};
		suspend();
		return {
			get mimeType() {
				return mimeType;
			},
			get state() {
				return promisedAudioNodesAndEncoderInstanceId === null ? "inactive" : isAudioContextRunning ? "recording" : "paused";
			},
			pause() {
				if (promisedAudioNodesAndEncoderInstanceId === null) throw createInvalidStateError();
				if (isAudioContextRunning) {
					suspend();
					eventTarget.dispatchEvent(new Event("pause"));
				}
			},
			resume() {
				if (promisedAudioNodesAndEncoderInstanceId === null) throw createInvalidStateError();
				if (!isAudioContextRunning) {
					resume();
					eventTarget.dispatchEvent(new Event("resume"));
				}
			},
			start(timeslice) {
				var _a;
				if (promisedAudioNodesAndEncoderInstanceId !== null) throw createInvalidStateError();
				if (mediaStream.getVideoTracks().length > 0) throw createNotSupportedError();
				eventTarget.dispatchEvent(new Event("start"));
				const audioTracks = mediaStream.getAudioTracks();
				const channelCount = audioTracks.length === 0 ? 2 : (_a = audioTracks[0].getSettings().channelCount) !== null && _a !== void 0 ? _a : 2;
				promisedAudioNodesAndEncoderInstanceId = Promise.all([resume(), promisedAudioWorkletModule.then(() => createPromisedAudioNodesEncoderInstanceIdAndPort(audioBuffer, audioContext, channelCount, mediaStream, mimeType))]).then(async ([, { audioBufferSourceNode, encoderInstanceId, mediaStreamAudioSourceNode, port, recorderAudioWorkletNode }]) => {
					mediaStreamAudioSourceNode.connect(recorderAudioWorkletNode);
					if (audioBufferSourceNode !== null) {
						await new Promise((resolve) => {
							audioBufferSourceNode.onended = resolve;
							audioBufferSourceNode.connect(recorderAudioWorkletNode);
							audioBufferSourceNode.start();
						});
						audioBufferSourceNode.disconnect(recorderAudioWorkletNode);
					}
					await recorderAudioWorkletNode.record(port);
					if (timeslice !== void 0) promisedPartialRecording = requestNextPartialRecording(encoderInstanceId, timeslice);
					return {
						encoderInstanceId,
						mediaStreamAudioSourceNode,
						recorderAudioWorkletNode
					};
				});
				const tracks = mediaStream.getTracks();
				abortRecording = () => {
					stop();
					eventTarget.dispatchEvent(new ErrorEvent("error", { error: createInvalidModificationError() }));
				};
				mediaStream.addEventListener("addtrack", abortRecording);
				mediaStream.addEventListener("removetrack", abortRecording);
				intervalId = setInterval(() => {
					const currentTracks = mediaStream.getTracks();
					if ((currentTracks.length !== tracks.length || currentTracks.some((track, index) => track !== tracks[index])) && abortRecording !== null) abortRecording();
				}, 1e3);
			},
			stop
		};
	};
};
//#endregion
//#region node_modules/.pnpm/extendable-media-recorder@9.2.38/node_modules/extendable-media-recorder/build/es2019/factories/webm-pcm-media-recorder.js
var import_bundle = (/* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(global, factory) {
		typeof exports === "object" && typeof module !== "undefined" ? factory(exports, require_slicedToArray(), require_classCallCheck(), require_createClass()) : typeof define === "function" && define.amd ? define([
			"exports",
			"@babel/runtime/helpers/slicedToArray",
			"@babel/runtime/helpers/classCallCheck",
			"@babel/runtime/helpers/createClass"
		], factory) : (global = typeof globalThis !== "undefined" ? globalThis : global || self, factory(global.multiBufferDataView = {}, global._slicedToArray, global._classCallCheck, global._createClass));
	})(exports, (function(exports$1, _slicedToArray, _classCallCheck, _createClass) {
		"use strict";
		function _createForOfIteratorHelper(r, e) {
			var t = "undefined" != typeof Symbol && r[Symbol.iterator] || r["@@iterator"];
			if (!t) {
				if (Array.isArray(r) || (t = _unsupportedIterableToArray(r)) || e) {
					t && (r = t);
					var _n = 0;
					var F = function F() {};
					return {
						s: F,
						n: function n() {
							return _n >= r.length ? { done: true } : {
								done: false,
								value: r[_n++]
							};
						},
						e: function e(r) {
							throw r;
						},
						f: F
					};
				}
				throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
			}
			var o;
			var a = true;
			var u = false;
			return {
				s: function s() {
					t = t.call(r);
				},
				n: function n() {
					var r = t.next();
					return a = r.done, r;
				},
				e: function e(r) {
					u = true, o = r;
				},
				f: function f() {
					try {
						a || null == t["return"] || t["return"]();
					} finally {
						if (u) throw o;
					}
				}
			};
		}
		function _unsupportedIterableToArray(r, a) {
			if (r) {
				if ("string" == typeof r) return _arrayLikeToArray(r, a);
				var t = {}.toString.call(r).slice(8, -1);
				return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
			}
		}
		function _arrayLikeToArray(r, a) {
			(null == a || a > r.length) && (a = r.length);
			for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
			return n;
		}
		exports$1.MultiBufferDataView = /* @__PURE__ */ function() {
			function MultiBufferDataView(buffers) {
				var byteOffset = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0;
				var byteLength = arguments.length > 2 ? arguments[2] : void 0;
				_classCallCheck(this, MultiBufferDataView);
				if (byteOffset < 0 || byteLength !== void 0 && byteLength < 0) throw new RangeError();
				var availableBytes = buffers.reduce(function(length, buffer) {
					return length + buffer.byteLength;
				}, 0);
				if (byteOffset > availableBytes || byteLength !== void 0 && byteOffset + byteLength > availableBytes) throw new RangeError();
				var dataViews = [];
				var effectiveByteLength = byteLength === void 0 ? availableBytes - byteOffset : byteLength;
				var truncatedBuffers = [];
				var consumedByteLength = 0;
				var truncatedByteOffset = byteOffset;
				var _iterator = _createForOfIteratorHelper(buffers);
				var _step;
				try {
					for (_iterator.s(); !(_step = _iterator.n()).done;) {
						var buffer = _step.value;
						if (truncatedBuffers.length === 0) {
							if (buffer.byteLength > truncatedByteOffset) {
								consumedByteLength = buffer.byteLength - truncatedByteOffset;
								var byteLengthOfDataView = consumedByteLength > effectiveByteLength ? effectiveByteLength : consumedByteLength;
								dataViews.push(new DataView(buffer, truncatedByteOffset, byteLengthOfDataView));
								truncatedBuffers.push(buffer);
							} else truncatedByteOffset -= buffer.byteLength;
						} else if (consumedByteLength < effectiveByteLength) {
							consumedByteLength += buffer.byteLength;
							var _byteLengthOfDataView = consumedByteLength > effectiveByteLength ? buffer.byteLength - consumedByteLength + effectiveByteLength : buffer.byteLength;
							dataViews.push(new DataView(buffer, 0, _byteLengthOfDataView));
							truncatedBuffers.push(buffer);
						}
					}
				} catch (err) {
					_iterator.e(err);
				} finally {
					_iterator.f();
				}
				this._buffers = truncatedBuffers;
				this._byteLength = effectiveByteLength;
				this._byteOffset = truncatedByteOffset;
				this._dataViews = dataViews;
				this._internalBuffer = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(8));
			}
			return _createClass(MultiBufferDataView, [
				{
					key: "buffers",
					get: function get() {
						return this._buffers;
					}
				},
				{
					key: "byteLength",
					get: function get() {
						return this._byteLength;
					}
				},
				{
					key: "byteOffset",
					get: function get() {
						return this._byteOffset;
					}
				},
				{
					key: "getFloat32",
					value: function getFloat32(byteOffset, littleEndian) {
						this._internalBuffer.setUint8(0, this.getUint8(byteOffset + 0));
						this._internalBuffer.setUint8(1, this.getUint8(byteOffset + 1));
						this._internalBuffer.setUint8(2, this.getUint8(byteOffset + 2));
						this._internalBuffer.setUint8(3, this.getUint8(byteOffset + 3));
						return this._internalBuffer.getFloat32(0, littleEndian);
					}
				},
				{
					key: "getFloat64",
					value: function getFloat64(byteOffset, littleEndian) {
						this._internalBuffer.setUint8(0, this.getUint8(byteOffset + 0));
						this._internalBuffer.setUint8(1, this.getUint8(byteOffset + 1));
						this._internalBuffer.setUint8(2, this.getUint8(byteOffset + 2));
						this._internalBuffer.setUint8(3, this.getUint8(byteOffset + 3));
						this._internalBuffer.setUint8(4, this.getUint8(byteOffset + 4));
						this._internalBuffer.setUint8(5, this.getUint8(byteOffset + 5));
						this._internalBuffer.setUint8(6, this.getUint8(byteOffset + 6));
						this._internalBuffer.setUint8(7, this.getUint8(byteOffset + 7));
						return this._internalBuffer.getFloat64(0, littleEndian);
					}
				},
				{
					key: "getInt16",
					value: function getInt16(byteOffset, littleEndian) {
						this._internalBuffer.setUint8(0, this.getUint8(byteOffset + 0));
						this._internalBuffer.setUint8(1, this.getUint8(byteOffset + 1));
						return this._internalBuffer.getInt16(0, littleEndian);
					}
				},
				{
					key: "getInt32",
					value: function getInt32(byteOffset, littleEndian) {
						this._internalBuffer.setUint8(0, this.getUint8(byteOffset + 0));
						this._internalBuffer.setUint8(1, this.getUint8(byteOffset + 1));
						this._internalBuffer.setUint8(2, this.getUint8(byteOffset + 2));
						this._internalBuffer.setUint8(3, this.getUint8(byteOffset + 3));
						return this._internalBuffer.getInt32(0, littleEndian);
					}
				},
				{
					key: "getInt8",
					value: function getInt8(byteOffset) {
						var _this$_findDataViewWi2 = _slicedToArray(this._findDataViewWithOffset(byteOffset), 2);
						var dataView = _this$_findDataViewWi2[0];
						var byteOffsetOfDataView = _this$_findDataViewWi2[1];
						return dataView.getInt8(byteOffset - byteOffsetOfDataView);
					}
				},
				{
					key: "getUint16",
					value: function getUint16(byteOffset, littleEndian) {
						this._internalBuffer.setUint8(0, this.getUint8(byteOffset + 0));
						this._internalBuffer.setUint8(1, this.getUint8(byteOffset + 1));
						return this._internalBuffer.getUint16(0, littleEndian);
					}
				},
				{
					key: "getUint32",
					value: function getUint32(byteOffset, littleEndian) {
						this._internalBuffer.setUint8(0, this.getUint8(byteOffset + 0));
						this._internalBuffer.setUint8(1, this.getUint8(byteOffset + 1));
						this._internalBuffer.setUint8(2, this.getUint8(byteOffset + 2));
						this._internalBuffer.setUint8(3, this.getUint8(byteOffset + 3));
						return this._internalBuffer.getUint32(0, littleEndian);
					}
				},
				{
					key: "getUint8",
					value: function getUint8(byteOffset) {
						var _this$_findDataViewWi4 = _slicedToArray(this._findDataViewWithOffset(byteOffset), 2);
						var dataView = _this$_findDataViewWi4[0];
						var byteOffsetOfDataView = _this$_findDataViewWi4[1];
						return dataView.getUint8(byteOffset - byteOffsetOfDataView);
					}
				},
				{
					key: "setFloat32",
					value: function setFloat32(byteOffset, value, littleEndian) {
						this._internalBuffer.setFloat32(0, value, littleEndian);
						this.setUint8(byteOffset, this._internalBuffer.getUint8(0));
						this.setUint8(byteOffset + 1, this._internalBuffer.getUint8(1));
						this.setUint8(byteOffset + 2, this._internalBuffer.getUint8(2));
						this.setUint8(byteOffset + 3, this._internalBuffer.getUint8(3));
					}
				},
				{
					key: "setFloat64",
					value: function setFloat64(byteOffset, value, littleEndian) {
						this._internalBuffer.setFloat64(0, value, littleEndian);
						this.setUint8(byteOffset, this._internalBuffer.getUint8(0));
						this.setUint8(byteOffset + 1, this._internalBuffer.getUint8(1));
						this.setUint8(byteOffset + 2, this._internalBuffer.getUint8(2));
						this.setUint8(byteOffset + 3, this._internalBuffer.getUint8(3));
						this.setUint8(byteOffset + 4, this._internalBuffer.getUint8(4));
						this.setUint8(byteOffset + 5, this._internalBuffer.getUint8(5));
						this.setUint8(byteOffset + 6, this._internalBuffer.getUint8(6));
						this.setUint8(byteOffset + 7, this._internalBuffer.getUint8(7));
					}
				},
				{
					key: "setInt16",
					value: function setInt16(byteOffset, value, littleEndian) {
						this._internalBuffer.setInt16(0, value, littleEndian);
						this.setUint8(byteOffset, this._internalBuffer.getUint8(0));
						this.setUint8(byteOffset + 1, this._internalBuffer.getUint8(1));
					}
				},
				{
					key: "setInt32",
					value: function setInt32(byteOffset, value, littleEndian) {
						this._internalBuffer.setInt32(0, value, littleEndian);
						this.setUint8(byteOffset, this._internalBuffer.getUint8(0));
						this.setUint8(byteOffset + 1, this._internalBuffer.getUint8(1));
						this.setUint8(byteOffset + 2, this._internalBuffer.getUint8(2));
						this.setUint8(byteOffset + 3, this._internalBuffer.getUint8(3));
					}
				},
				{
					key: "setInt8",
					value: function setInt8(byteOffset, value) {
						var _this$_findDataViewWi6 = _slicedToArray(this._findDataViewWithOffset(byteOffset), 2);
						var dataView = _this$_findDataViewWi6[0];
						var byteOffsetOfDataView = _this$_findDataViewWi6[1];
						dataView.setInt8(byteOffset - byteOffsetOfDataView, value);
					}
				},
				{
					key: "setUint16",
					value: function setUint16(byteOffset, value, littleEndian) {
						this._internalBuffer.setUint16(0, value, littleEndian);
						this.setUint8(byteOffset, this._internalBuffer.getUint8(0));
						this.setUint8(byteOffset + 1, this._internalBuffer.getUint8(1));
					}
				},
				{
					key: "setUint32",
					value: function setUint32(byteOffset, value, littleEndian) {
						this._internalBuffer.setUint32(0, value, littleEndian);
						this.setUint8(byteOffset, this._internalBuffer.getUint8(0));
						this.setUint8(byteOffset + 1, this._internalBuffer.getUint8(1));
						this.setUint8(byteOffset + 2, this._internalBuffer.getUint8(2));
						this.setUint8(byteOffset + 3, this._internalBuffer.getUint8(3));
					}
				},
				{
					key: "setUint8",
					value: function setUint8(byteOffset, value) {
						var _this$_findDataViewWi8 = _slicedToArray(this._findDataViewWithOffset(byteOffset), 2);
						var dataView = _this$_findDataViewWi8[0];
						var byteOffsetOfDataView = _this$_findDataViewWi8[1];
						dataView.setUint8(byteOffset - byteOffsetOfDataView, value);
					}
				},
				{
					key: "_findDataViewWithOffset",
					value: function _findDataViewWithOffset(byteOffset) {
						var byteOffsetOfDataView = 0;
						var _iterator2 = _createForOfIteratorHelper(this._dataViews);
						var _step2;
						try {
							for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
								var dataView = _step2.value;
								var byteOffsetOfNextDataView = byteOffsetOfDataView + dataView.byteLength;
								if (byteOffset >= byteOffsetOfDataView && byteOffset < byteOffsetOfNextDataView) return [dataView, byteOffsetOfDataView];
								byteOffsetOfDataView = byteOffsetOfNextDataView;
							}
						} catch (err) {
							_iterator2.e(err);
						} finally {
							_iterator2.f();
						}
						throw new RangeError();
					}
				}
			]);
		}();
	}));
})))();
var createWebmPcmMediaRecorderFactory = (createBlobEvent, decodeWebMChunk, readVariableSizeInteger) => {
	return (eventTarget, nativeMediaRecorderConstructor, mediaStream, mimeType) => {
		const bufferedArrayBuffers = [];
		const nativeMediaRecorder = new nativeMediaRecorderConstructor(mediaStream, { mimeType: "audio/webm; codecs=pcm" });
		let promisedPartialRecording = null;
		let stopRecording = () => {};
		const dispatchDataAvailableEvent = (arrayBuffers) => {
			eventTarget.dispatchEvent(createBlobEvent("dataavailable", { data: new Blob(arrayBuffers, { type: mimeType }) }));
		};
		const requestNextPartialRecording = async (encoderInstanceId, timeslice) => {
			const arrayBuffers = await encode$1(encoderInstanceId, timeslice);
			if (nativeMediaRecorder.state === "inactive") bufferedArrayBuffers.push(...arrayBuffers);
			else {
				dispatchDataAvailableEvent(arrayBuffers);
				promisedPartialRecording = requestNextPartialRecording(encoderInstanceId, timeslice);
			}
		};
		const stop = () => {
			if (nativeMediaRecorder.state === "inactive") return;
			if (promisedPartialRecording !== null) {
				promisedPartialRecording.catch(() => {});
				promisedPartialRecording = null;
			}
			stopRecording();
			stopRecording = () => {};
			nativeMediaRecorder.stop();
		};
		nativeMediaRecorder.addEventListener("error", (event) => {
			stop();
			eventTarget.dispatchEvent(new ErrorEvent("error", { error: event.error }));
		});
		nativeMediaRecorder.addEventListener("pause", () => eventTarget.dispatchEvent(new Event("pause")));
		nativeMediaRecorder.addEventListener("resume", () => eventTarget.dispatchEvent(new Event("resume")));
		nativeMediaRecorder.addEventListener("start", () => eventTarget.dispatchEvent(new Event("start")));
		return {
			get mimeType() {
				return mimeType;
			},
			get state() {
				return nativeMediaRecorder.state;
			},
			pause() {
				return nativeMediaRecorder.pause();
			},
			resume() {
				return nativeMediaRecorder.resume();
			},
			start(timeslice) {
				const [audioTrack] = mediaStream.getAudioTracks();
				if (audioTrack !== void 0 && nativeMediaRecorder.state === "inactive") {
					const { channelCount, sampleRate } = audioTrack.getSettings();
					if (channelCount === void 0) throw new Error("The channelCount is not defined.");
					if (sampleRate === void 0) throw new Error("The sampleRate is not defined.");
					let isRecording = false;
					let isStopped = false;
					let pendingInvocations = 0;
					let promisedDataViewElementTypeEncoderInstanceIdAndPort = instantiate(mimeType, sampleRate);
					stopRecording = () => {
						isStopped = true;
					};
					const removeEventListener = on(nativeMediaRecorder, "dataavailable")(({ data }) => {
						pendingInvocations += 1;
						const promisedArrayBuffer = data.arrayBuffer();
						promisedDataViewElementTypeEncoderInstanceIdAndPort = promisedDataViewElementTypeEncoderInstanceIdAndPort.then(async ({ dataView = null, elementType = null, encoderInstanceId, port }) => {
							const arrayBuffer = await promisedArrayBuffer;
							pendingInvocations -= 1;
							const currentDataView = dataView === null ? new import_bundle.MultiBufferDataView([arrayBuffer]) : new import_bundle.MultiBufferDataView([...dataView.buffers, arrayBuffer], dataView.byteOffset);
							if (!isRecording && nativeMediaRecorder.state === "recording" && !isStopped) {
								const lengthAndValue = readVariableSizeInteger(currentDataView, 0);
								if (lengthAndValue === null) return {
									dataView: currentDataView,
									elementType,
									encoderInstanceId,
									port
								};
								const { value } = lengthAndValue;
								if (value !== 172351395) return {
									dataView,
									elementType,
									encoderInstanceId,
									port
								};
								isRecording = true;
							}
							const { currentElementType, offset, contents } = decodeWebMChunk(currentDataView, elementType, channelCount);
							const remainingDataView = offset < currentDataView.byteLength ? new import_bundle.MultiBufferDataView(currentDataView.buffers, currentDataView.byteOffset + offset) : null;
							contents.forEach((content) => port.postMessage(content, content.map(({ buffer }) => buffer)));
							if (pendingInvocations === 0 && (nativeMediaRecorder.state === "inactive" || isStopped)) {
								encode$1(encoderInstanceId, null).then((arrayBuffers) => {
									dispatchDataAvailableEvent([...bufferedArrayBuffers, ...arrayBuffers]);
									bufferedArrayBuffers.length = 0;
									eventTarget.dispatchEvent(new Event("stop"));
								});
								port.postMessage([]);
								port.close();
								removeEventListener();
							}
							return {
								dataView: remainingDataView,
								elementType: currentElementType,
								encoderInstanceId,
								port
							};
						});
					});
					if (timeslice !== void 0) promisedDataViewElementTypeEncoderInstanceIdAndPort.then(({ encoderInstanceId }) => {
						if (isStopped) return;
						promisedPartialRecording = requestNextPartialRecording(encoderInstanceId, timeslice);
					});
				}
				nativeMediaRecorder.start(100);
			},
			stop
		};
	};
};
//#endregion
//#region node_modules/.pnpm/extendable-media-recorder@9.2.38/node_modules/extendable-media-recorder/build/es2019/factories/window.js
var createWindow = () => typeof window === "undefined" ? null : window;
//#endregion
//#region node_modules/.pnpm/extendable-media-recorder@9.2.38/node_modules/extendable-media-recorder/build/es2019/functions/read-variable-size-integer-length.js
var readVariableSizeIntegerLength = (dataView, offset) => {
	if (offset >= dataView.byteLength) return null;
	const byte = dataView.getUint8(offset);
	if (byte > 127) return 1;
	if (byte > 63) return 2;
	if (byte > 31) return 3;
	if (byte > 15) return 4;
	if (byte > 7) return 5;
	if (byte > 3) return 6;
	if (byte > 1) return 7;
	if (byte > 0) return 8;
	const length = readVariableSizeIntegerLength(dataView, offset + 1);
	return length === null ? null : length + 8;
};
//#endregion
//#region node_modules/.pnpm/extendable-media-recorder@9.2.38/node_modules/extendable-media-recorder/build/es2019/functions/wrap-event-listener.js
var wrapEventListener = (target, eventListener) => {
	return (event) => {
		const descriptor = { value: target };
		Object.defineProperties(event, {
			currentTarget: descriptor,
			target: descriptor
		});
		if (typeof eventListener === "function") return eventListener.call(target, event);
		return eventListener.handleEvent.call(target, event);
	};
};
//#endregion
//#region node_modules/.pnpm/extendable-media-recorder@9.2.38/node_modules/extendable-media-recorder/build/es2019/module.js
var encoderRegexes = [];
var window$1 = createWindow();
var createBlobEvent = createBlobEventFactory(createNativeBlobEventConstructor(window$1));
var createWebAudioMediaRecorder = createWebAudioMediaRecorderFactory(createBlobEvent, createInvalidModificationError, createInvalidStateError$1, createNotSupportedError$1);
var readVariableSizeInteger = createReadVariableSizeInteger(readVariableSizeIntegerLength);
var createWebmPcmMediaRecorder = createWebmPcmMediaRecorderFactory(createBlobEvent, createDecodeWebMChunk(createReadElementContent(readVariableSizeInteger), createReadElementType(readVariableSizeInteger)), readVariableSizeInteger);
var createEventTarget = createEventTargetFactory(window$1);
var nativeMediaRecorderConstructor = createNativeMediaRecorderConstructor(window$1);
var mediaRecorderConstructor = createMediaRecorderConstructor(createNativeMediaRecorderFactory(createNotSupportedError$1), createNotSupportedError$1, createWebAudioMediaRecorder, createWebmPcmMediaRecorder, encoderRegexes, createEventTargetConstructor$1(createEventTarget, wrapEventListener), nativeMediaRecorderConstructor);
var ports = /* @__PURE__ */ new WeakMap();
var register = async (port) => {
	const encoderRegex = await register$1(port);
	encoderRegexes.push(encoderRegex);
	ports.set(port, encoderRegex);
};
//#endregion
//#region node_modules/.pnpm/extendable-media-recorder-wav-encoder-broker@7.0.128/node_modules/extendable-media-recorder-wav-encoder-broker/build/es2019/module.js
var wrap = createBroker({
	characterize: ({ call }) => {
		return () => call("characterize");
	},
	encode: ({ call }) => {
		return (recordingId, timeslice) => {
			return call("encode", {
				recordingId,
				timeslice
			});
		};
	},
	record: ({ call }) => {
		return async (recordingId, sampleRate, typedArrays) => {
			await call("record", {
				recordingId,
				sampleRate,
				typedArrays
			}, typedArrays.map(({ buffer }) => buffer).filter((buffer) => buffer instanceof ArrayBuffer));
		};
	}
});
var load = (url) => {
	return wrap(new Worker(url));
};
//#endregion
//#region node_modules/.pnpm/extendable-media-recorder-wav-encoder@7.0.139/node_modules/extendable-media-recorder-wav-encoder/build/es2019/module.js
var blob = new Blob([`(()=>{var e={455(e,t){!function(e){"use strict";var t=function(e){return function(t){var r=e(t);return t.add(r),r}},r=function(e){return function(t,r){return e.set(t,r),r}},n=void 0===Number.MAX_SAFE_INTEGER?9007199254740991:Number.MAX_SAFE_INTEGER,s=536870912,a=2*s,o=function(e,t){return function(r){var o=t.get(r),i=void 0===o?r.size:o<a?o+1:0;if(!r.has(i))return e(r,i);if(r.size<s){for(;r.has(i);)i=Math.floor(Math.random()*a);return e(r,i)}if(r.size>n)throw new Error("Congratulations, you created a collection of unique numbers which uses all available integers!");for(;r.has(i);)i=Math.floor(Math.random()*n);return e(r,i)}},i=new WeakMap,c=r(i),l=o(c,i),u=t(l);e.addUniqueNumber=u,e.generateUniqueNumber=l}(t)}},t={};function r(n){var s=t[n];if(void 0!==s)return s.exports;var a=t[n]={exports:{}};return e[n].call(a.exports,a,a.exports,r),a.exports}(()=>{"use strict";const e=-32603,t=-32602,n=-32601,s=(e,t)=>Object.assign(new Error(e),{status:t}),a=t=>s('The handler of the method called "'.concat(t,'" returned an unexpected result.'),e),o=(t,r)=>async({data:{id:o,method:i,params:c}})=>{const l=r[i];try{if(void 0===l)throw(e=>s('The requested method called "'.concat(e,'" is not supported.'),n))(i);const r=void 0===c?l():l(c);if(void 0===r)throw(t=>s('The handler of the method called "'.concat(t,'" returned no required result.'),e))(i);const u=r instanceof Promise?await r:r;if(null===o){if(void 0!==u.result)throw a(i)}else{if(void 0===u.result)throw a(i);const{result:e,transferables:r=[]}=u;t.postMessage({id:o,result:e},r)}}catch(e){const{message:r,status:n=-32603}=e;t.postMessage({error:{code:n,message:r},id:o})}};var i=r(455);const c=new Map,l=(e,r,n)=>({...r,connect:({port:t})=>{t.start();const n=e(t,r),s=(0,i.generateUniqueNumber)(c);return c.set(s,()=>{n(),t.close(),c.delete(s)}),{result:s}},disconnect:({portId:e})=>{const r=c.get(e);if(void 0===r)throw(e=>s('The specified parameter called "portId" with the given value "'.concat(e,'" does not identify a port connected to this worker.'),t))(e);return r(),{result:null}},isSupported:async()=>{if(await new Promise(e=>{const t=new ArrayBuffer(0),{port1:r,port2:n}=new MessageChannel;r.onmessage=({data:t})=>e(null!==t),n.postMessage(t,[t])})){const e=n();return{result:e instanceof Promise?await e:e}}return{result:!1}}}),u=(e,t,r=()=>!0)=>{const n=l(u,t,r),s=o(e,n);return e.addEventListener("message",s),()=>e.removeEventListener("message",s)},d=e=>e.reduce((e,t)=>e+t.length,0),h=(e,t)=>{const r=[];let n=0;e:for(;n<t;){const t=e.length;for(let s=0;s<t;s+=1){const t=e[s];void 0===r[s]&&(r[s]=[]);const a=t.shift();if(void 0===a)break e;r[s].push(a),0===s&&(n+=a.length)}}if(n>t){const s=n-t;r.forEach((t,r)=>{const n=t.pop(),a=n.length-s;t.push(n.subarray(0,a)),e[r].unshift(n.subarray(a))})}return r},f=new Map,m=(e=>(t,r,n)=>{const s=e.get(t);if(void 0===s){const s={channelDataArrays:n.map(e=>[e]),isComplete:!0,sampleRate:r};return e.set(t,s),s}return s.channelDataArrays.forEach((e,t)=>e.push(n[t])),s})(f),p=((e,t)=>(r,n,s,a)=>{const o=s>>3,i="subsequent"===n?0:44,c=r.length,l=e(r[0]),u=new ArrayBuffer(l*c*o+i),d=new DataView(u);return"subsequent"!==n&&t(d,s,c,"complete"===n?l:Number.POSITIVE_INFINITY,a),r.forEach((e,t)=>{let r=i+t*o;e.forEach(e=>{const t=e.length;for(let n=0;n<t;n+=1){const t=e[n];d.setInt16(r,t<0?32768*Math.max(-1,t):32767*Math.min(1,t),!0),r+=c*o}})}),[u]})(d,(e,t,r,n,s)=>{const a=t>>3,o=Math.min(n*r*a,4294967251);e.setUint32(0,1380533830),e.setUint32(4,o+36,!0),e.setUint32(8,1463899717),e.setUint32(12,1718449184),e.setUint32(16,16,!0),e.setUint16(20,1,!0),e.setUint16(22,r,!0),e.setUint32(24,s,!0),e.setUint32(28,s*r*a,!0),e.setUint16(32,r*a,!0),e.setUint16(34,t,!0),e.setUint32(36,1684108385),e.setUint32(40,o,!0)}),v=new Map;u(self,{characterize:()=>({result:/^audio\\/wav$/}),encode:({recordingId:e,timeslice:t})=>{const r=v.get(e);void 0!==r&&(v.delete(e),r.reject(new Error("Another request was made to initiate an encoding.")));const n=f.get(e);if(null!==t){if(void 0===n||d(n.channelDataArrays[0])*(1e3/n.sampleRate)<t)return new Promise((r,n)=>{v.set(e,{reject:n,resolve:r,timeslice:t})});const r=h(n.channelDataArrays,Math.ceil(t*(n.sampleRate/1e3))),s=p(r,n.isComplete?"initial":"subsequent",16,n.sampleRate);return n.isComplete=!1,{result:s,transferables:s}}if(void 0!==n){const t=p(n.channelDataArrays,n.isComplete?"complete":"subsequent",16,n.sampleRate);return f.delete(e),{result:t,transferables:t}}return{result:[],transferables:[]}},record:({recordingId:e,sampleRate:t,typedArrays:r})=>{const n=m(e,t,r),s=v.get(e);if(void 0!==s&&d(n.channelDataArrays[0])*(1e3/t)>=s.timeslice){const r=h(n.channelDataArrays,Math.ceil(s.timeslice*(t/1e3))),a=p(r,n.isComplete?"initial":"subsequent",16,t);n.isComplete=!1,v.delete(e),s.resolve({result:a,transferables:a})}return{result:null}}})})()})();`], { type: "application/javascript; charset=utf-8" });
var url = URL.createObjectURL(blob);
var extendableMediaRecorderWavEncoder = load(url);
extendableMediaRecorderWavEncoder.characterize;
var connect = extendableMediaRecorderWavEncoder.connect;
extendableMediaRecorderWavEncoder.disconnect;
extendableMediaRecorderWavEncoder.encode;
extendableMediaRecorderWavEncoder.isSupported;
extendableMediaRecorderWavEncoder.record;
URL.revokeObjectURL(url);
//#endregion
//#region src/services/audioService.ts
var isEncoderRegistered = false;
var useAudioService = () => {
	const handleError = (type, message, originalError) => {
		console.error(`Audio Service Error (${type}):`, message, originalError);
	};
	const stopAllTracks = (currentStream) => {
		if (currentStream) currentStream.getTracks().forEach((track) => {
			track.stop();
		});
	};
	const registerWavEncoder = async () => {
		if (isEncoderRegistered) return;
		try {
			await register(await connect());
			isEncoderRegistered = true;
		} catch (err) {
			if (err instanceof Error && err.message.includes("already an encoder stored")) isEncoderRegistered = true;
			else handleError("encoder", "Failed to register WAV encoder", err);
		}
	};
	const convertBlobToFileAndSubmit = async (blob) => {
		const name = `recording-${Date.now()}.wav`;
		const file = new File([blob], name, { type: blob.type || "audio/wav" });
		const upload = await uploadTempFile(file, "audio");
		if (!upload.ok) throw new Error(`Error uploading temp file: ${upload.reason}`);
		return `audio/${upload.file.name} [temp]`;
	};
	return {
		convertBlobToFileAndSubmit,
		registerWavEncoder,
		stopAllTracks
	};
};
//#endregion
export { mediaRecorderConstructor as n, useAudioService as t };
