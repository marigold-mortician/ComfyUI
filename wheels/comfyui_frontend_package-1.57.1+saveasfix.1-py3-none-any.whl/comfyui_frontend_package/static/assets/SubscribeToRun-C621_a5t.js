import "./rolldown-runtime-xtsTai4I.js";
import { F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, I as createBlock, P as computed, Wt as unref, Yt as toDisplayString, at as onMounted, ct as openBlock, ot as onUnmounted, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { Jn as useBreakpoints, zn as breakpointsTailwind } from "./vendor-reka-ui-NRTk7aIV.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as BILLING_ACTION_NAME } from "./billingActionNames-DwcV6mOp.js";
import { t as useSubscriptionPaywall } from "./useSubscriptionPaywall-DbqkouMv.js";
import { t as useRunButtonTelemetry } from "./useRunButtonTelemetry-DP8B1TcF.js";
import { t as useWorkspaceUI } from "./useWorkspaceUI-CALMkHxF.js";
//#region src/platform/billing/subscription/composables/useSubscribeCtaPresence.ts
var mountedPrompts = ref(0);
/**
* Registers a mounted Run-slot subscribe prompt for the caller's lifetime.
* The billing flag alone is not evidence a prompt is on screen — builder
* mode unmounts the actionbar, Linear mode needs outputs, and the wrapper
* withholds the prompt for sales-managed and payment-recovery states — so
* anything yielding to the prompt must key on real presence.
*/
function registerSubscribeToRunPrompt() {
	onMounted(() => {
		mountedPrompts.value += 1;
	});
	onUnmounted(() => {
		mountedPrompts.value = Math.max(0, mountedPrompts.value - 1);
	});
}
/** Whether any Run-slot subscribe prompt is currently on screen. */
function useSubscribeToRunPromptPresence() {
	return computed(() => mountedPrompts.value > 0);
}
//#endregion
//#region src/platform/billing/subscription/components/SubscribeToRun.vue
var SubscribeToRun_default = /* @__PURE__ */ defineComponent({
	__name: "SubscribeToRun",
	setup(__props) {
		const { t } = useI18n();
		registerSubscribeToRunPrompt();
		const isMdOrLarger = useBreakpoints(breakpointsTailwind).greaterOrEqual("md");
		const { permissions } = useWorkspaceUI();
		const { showSubscriptionDialog } = useSubscriptionPaywall();
		const { trackRunButton } = useRunButtonTelemetry();
		const canResubscribe = computed(() => permissions.value.canManageSubscription);
		const buttonLabel = computed(() => {
			if (!canResubscribe.value) return t("subscription.inactive.runLabel");
			return isMdOrLarger.value ? t("subscription.subscribeToRunFull") : t("subscription.subscribeToRun");
		});
		const buttonTooltip = computed(() => canResubscribe.value ? t("subscription.subscribeToRunFull") : t("subscription.inactive.memberRunTooltip"));
		function handleSubscribeToRun() {
			showSubscriptionDialog({ reason: "subscribe_to_run" });
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(Button_default, {
				tooltip: buttonTooltip.value,
				"tooltip-side": "bottom",
				class: "subscribe-to-run-button h-8 gap-1.5 rounded-lg px-4",
				variant: "subscribe",
				size: "unset",
				"data-testid": "subscribe-to-run-button",
				"data-dd-action-name": unref(BILLING_ACTION_NAME).subscribeToRun,
				onClick: handleSubscribeToRun
			}, {
				default: withCtx(() => [_cache[0] || (_cache[0] = createBaseVNode("i", { class: "pi pi-lock" }, null, -1)), createTextVNode(" " + toDisplayString(buttonLabel.value), 1)]),
				_: 1
			}, 8, ["tooltip", "data-dd-action-name"]);
		};
	}
});
//#endregion
export { useSubscribeToRunPromptPresence as n, SubscribeToRun_default as t };
