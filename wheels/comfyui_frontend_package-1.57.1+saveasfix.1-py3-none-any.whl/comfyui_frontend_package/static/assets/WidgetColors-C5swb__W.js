import "./rolldown-runtime-xtsTai4I.js";
import { $ as mergeModels, E as withModifiers, G as defineComponent, L as createCommentVNode, R as createElementBlock, U as createVNode, Wt as unref, Yt as toDisplayString, _t as useModel, ct as openBlock, tt as nextTick } from "./vendor-vue-core-CuN1excl.js";
import { t as PaletteSwatchRow_default } from "./PaletteSwatchRow-BDxyWNFq.js";
import { i as WidgetHistoryButtons_default, n as widgetHistoryScope, r as useWidgetValueHistory } from "./widgetHistoryScope-DLmWjnnJ.js";
//#region src/components/palette/WidgetColors.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = {
	key: 0,
	class: "shrink-0 truncate"
};
var MAX_COLORS = 16;
//#endregion
//#region src/components/palette/WidgetColors.vue
var WidgetColors_default = /* @__PURE__ */ defineComponent({
	__name: "WidgetColors",
	props: /*@__PURE__*/ mergeModels({
		widget: {},
		nodeId: {}
	}, {
		"modelValue": { default: () => [] },
		"modelModifiers": {}
	}),
	emits: ["update:modelValue"],
	setup(__props) {
		const modelValue = useModel(__props, "modelValue");
		function isColorList(value) {
			return Array.isArray(value) && value.every((color) => typeof color === "string");
		}
		const { canUndo, canRedo, undo, redo, commit } = useWidgetValueHistory({
			scope: () => __props.widget ? widgetHistoryScope(__props.widget, __props.nodeId) : null,
			read: () => modelValue.value,
			apply: (value) => {
				if (isColorList(value)) modelValue.value = value;
			}
		});
		function commitAfterUpdate(mergeKey) {
			nextTick(() => commit(mergeKey));
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				class: "flex size-full items-center gap-2",
				"data-testid": "colors",
				onPointerdown: _cache[1] || (_cache[1] = withModifiers(() => {}, ["stop"]))
			}, [
				__props.widget?.name ? (openBlock(), createElementBlock("span", _hoisted_1, toDisplayString(__props.widget.label || __props.widget.name), 1)) : createCommentVNode("", true),
				createVNode(PaletteSwatchRow_default, {
					modelValue: modelValue.value,
					"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => modelValue.value = $event),
					max: MAX_COLORS,
					onEditEnd: commitAfterUpdate
				}, null, 8, ["modelValue"]),
				createVNode(WidgetHistoryButtons_default, {
					class: "ml-auto",
					"can-undo": unref(canUndo),
					"can-redo": unref(canRedo),
					onUndo: unref(undo),
					onRedo: unref(redo)
				}, null, 8, [
					"can-undo",
					"can-redo",
					"onUndo",
					"onRedo"
				])
			], 32);
		};
	}
});
//#endregion
export { WidgetColors_default as default };
