const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./useSessionCookie-EVyvM0ta.js","./useSessionCookie-D8u4pwue.js","./rolldown-runtime-xtsTai4I.js","./teamWorkspaceStore-BNm5cZOK.js","./preload-helper-sJeoGctA.js","./delay-Cu8bS1zn.js","./globalThis-B6Vbq1EF.js","./api-BdJmXw98.js","./requestAuth-COoKVLz2.js","./get-Bk-Y8oEe.js","./vendor-vue-core-CuN1excl.js","./telemetry-IkzvF0TI.js","./vendor-zod-Del_rmdp.js","./zod.gen-DzuaBm8H.js","./vendor-axios-QnwcNXlY.js","./requestTimeout-DkmiEk-h.js","./hostTelemetryEnabled-DM7ML37c.js","./remoteConfig-VmmsGxJZ.js","./vendor-reka-ui-NRTk7aIV.js","./vendor-firebase-B37L--zT.js","./toastStore-Dg65fRgL.js","./i18n-BRluoVl-.js","./vendor-i18n-pA_PV1p-.js","./formatUtil-DsZFGVbT.js","./commands-C9zyhK6Q.js","./main-BtaRoPyL.js","./nodeDefs-BUEI64H3.js","./settings-B3DInspu.js","./vendor-sentry-zSXGkMPN.js","./reportError-BHgDVvfb.js","./errorUtil-DoQyAUQC.js","./rerouteId-1TDIYZkX.js","./assert--qJvwrYk.js","./storageIO-CAjGLygi.js","./dialogStore-Dm9z8_kv.js","./useFeatureFlags-B3zg5FdZ.js","./ssoTelemetry-DZUrpShr.js","./telemetry-CRUTYyCh.js","./comfyApi-CXw0-V35.js","./desktopHostSession-B3KqJnXo.js","./ssoRequiredDialogKey-DRv9w9ql.js","./errors-Bls3VadO.js","./isPlainObject-6prWdO5v.js","./cloudWebSessionStore-DQXLFlJm.js"])))=>i.map(i=>d[i]);
import { r as __name } from "./rolldown-runtime-xtsTai4I.js";
import { t as __vitePreload } from "./preload-helper-sJeoGctA.js";
import { n as useDialogService } from "./dialogService-CqZr0BhP.js";
import { S as provideEnsureSessionCookie, f as useWorkspaceAuthStore, g as PRESERVED_QUERY_NAMESPACES, j as workspaceApiUrl, m as fetchWithUnifiedRemint, t as useTeamWorkspaceStore, v as clearPreservedQuery, y as getPreservedQueryParam } from "./teamWorkspaceStore-BNm5cZOK.js";
import { G as isSsoRequiredRefusal, K as ssoRequiredOrganizationId, O as webSessionRequests, k as webSessionResourceHeader, v as firebaseIdentity } from "./api-BdJmXw98.js";
import { Ft as ref, P as computed, bt as watch, d as defineStore, tt as nextTick } from "./vendor-vue-core-CuN1excl.js";
import { _r as useMemoize, pr as useLocalStorage } from "./vendor-reka-ui-NRTk7aIV.js";
import { n as useTelemetry } from "./telemetry-IkzvF0TI.js";
import { $ as zExchangeTokenResponse, Q as zErrorResponse } from "./zod.gen-DzuaBm8H.js";
import { c as getAdditionalUserInfo, t as AUTH_ERROR_CODES_MAP_DO_NOT_USE_INTERNALLY, x as FirebaseError } from "./vendor-firebase-B37L--zT.js";
import { t as DISTRIBUTION } from "./types-t0xJOOCt.js";
import { t as useToast } from "./toastStore-Dg65fRgL.js";
import { d as t } from "./i18n-BRluoVl-.js";
import { r as reportError } from "./reportError-BHgDVvfb.js";
import { t as useErrorHandling } from "./useErrorHandling-WrECc0C0.js";
import { t as useFeatureFlags } from "./useFeatureFlags-B3zg5FdZ.js";
import { c as provideAuthStore, l as useAuthStoreAccess } from "./ssoTelemetry-DZUrpShr.js";
import { t as getComfyApiBaseUrl } from "./comfyApi-CXw0-V35.js";
import { a as isDesktopHostSignedIn, n as desktopHostUser, r as desktopHostWorkspaceToken, s as requestDesktopHostSignOut } from "./desktopHostSession-B3KqJnXo.js";
import { n as useCloudWebSessionStore } from "./cloudWebSessionStore-DQXLFlJm.js";
import { i as parseErrorResponse } from "./errors-Bls3VadO.js";
import { t as invalidateRemoteConfig } from "./refreshRemoteConfig-CEuxp20e.js";
//#region src/stores/apiKeyAuthStore.ts
var STORAGE_KEY = "comfy_api_key";
var useApiKeyAuthStore = defineStore("apiKeyAuth", () => {
	const authStore = useAuthStoreAccess();
	const apiKey = useLocalStorage(STORAGE_KEY, null);
	const toast = useToast();
	const { wrapWithErrorHandlingAsync, toastErrorHandler } = useErrorHandling();
	const currentUser = ref(null);
	const isAuthenticated = computed(() => !!currentUser.value);
	const initializeUserFromApiKey = async (watchedApiKey) => {
		const createCustomerResponse = await authStore.createCustomer().catch((err) => {
			console.error(err);
		});
		if (apiKey.value !== watchedApiKey) return;
		if (!createCustomerResponse) {
			apiKey.value = null;
			throw new Error(t("auth.login.noAssociatedUser"));
		}
		currentUser.value = createCustomerResponse;
	};
	watch(apiKey, async (watchedApiKey) => {
		currentUser.value = null;
		if (watchedApiKey) {
			await nextTick();
			if (apiKey.value !== watchedApiKey) return;
			initializeUserFromApiKey(watchedApiKey);
		}
	}, { immediate: true });
	const reportError = (error) => {
		if (error instanceof Error && error.message === "STORAGE_FAILED") toast.error(t("auth.apiKey.storageFailed"), { description: t("auth.apiKey.storageFailedDetail") });
		else toastErrorHandler(error);
	};
	const storeApiKey = wrapWithErrorHandlingAsync(async (newApiKey) => {
		apiKey.value = newApiKey;
		toast.success(t("auth.apiKey.stored"), {
			description: t("auth.apiKey.storedDetail"),
			duration: 5e3
		});
		return true;
	}, reportError);
	const clearStoredApiKey = wrapWithErrorHandlingAsync(async () => {
		apiKey.value = null;
		toast.success(t("auth.apiKey.cleared"), {
			description: t("auth.apiKey.clearedDetail"),
			duration: 5e3
		});
		return true;
	}, reportError);
	const getApiKey = () => apiKey.value;
	/**
	* Retrieves the appropriate authentication header for API requests if an
	* API key is available, otherwise returns null.
	*/
	const getAuthHeader = () => {
		const comfyOrgApiKey = getApiKey();
		if (comfyOrgApiKey) return { "X-API-KEY": comfyOrgApiKey };
		return null;
	};
	return {
		currentUser,
		isAuthenticated,
		storeApiKey,
		clearStoredApiKey,
		getAuthHeader,
		getApiKey
	};
});
async function isMissingCustomerResponse(response) {
	if (response.status !== 409) return false;
	try {
		const body = await response.clone().json();
		return typeof body === "object" && body !== null && "message" in body && body.message === "Failed to find customer";
	} catch {
		return false;
	}
}
function isCustomerEndpoint(input, base) {
	try {
		const { pathname } = new URL(input, base);
		return pathname === "/customers" || pathname.startsWith("/customers/");
	} catch {
		return false;
	}
}
/**
* On a missing-customer 409 this provisions the customer record and retries
* the original request a single time. If recovery fails, the original 409
* response is returned so callers surface their normal error handling.
*/
async function retryAfterCustomerRecovery(response, deps) {
	const { request, recoverMissingCustomer, identityUnchanged = () => true } = deps;
	if (!await isMissingCustomerResponse(response) || !identityUnchanged()) return response;
	try {
		await recoverMissingCustomer();
	} catch (error) {
		console.warn("Customer provisioning during 409 recovery failed; returning original response", error);
		return response;
	}
	if (!identityUnchanged()) return response;
	try {
		return await request();
	} catch (error) {
		console.warn("Retry after customer provisioning failed; returning original 409 response", error);
		return response;
	}
}
/**
* The recovery above, applied only to /customers/* endpoints: a 409 from
* anywhere else is never a missing customer.
*/
async function fetchWithCustomerRecovery(input, deps) {
	const response = await deps.request();
	if (!isCustomerEndpoint(input, deps.base)) return response;
	return retryAfterCustomerRecovery(response, deps);
}
//#endregion
//#region packages/account-core/src/provisioning.ts
/**
* Email sign-up: create the Firebase user, then provision the Comfy customer.
*
* Provisioning is where a Turnstile token gets validated server-side; if it
* fails (rejection, 5xx, network) the Firebase user is already created and,
* without rollback, the account is orphaned — every retry then fails
* "email already in use", permanently bricking signup. So a provisioning
* failure deletes the just-created user (best-effort with one retried
* delete, so a single transient blip cannot orphan the account; a cleanup
* failure never masks the original error) and rethrows.
*/
async function signUpWithProvisioning(deps) {
	const credential = await deps.createUser();
	try {
		await deps.provisionCustomer(credential);
	} catch (error) {
		try {
			try {
				await credential.user.delete();
			} catch {
				await credential.user.delete();
			}
		} catch (rollbackError) {
			try {
				deps.onRollbackFailure?.(rollbackError);
			} catch {}
		}
		throw error;
	}
	return credential;
}
/**
* Social sign-in: the popup, then find-or-create the Comfy customer — always,
* because a social user's first touch may be this host and skipping the
* customer record produces accounts where billing surfaces fail.
* `provisionCustomer` must tolerate an already-provisioned account. No
* rollback here: the signed-in user may be a long-standing account, and
* deleting it over a provisioning hiccup would destroy it — a provisioning
* failure propagates with the user still signed in.
*/
async function socialSignInWithProvisioning(deps) {
	const credential = await deps.signIn();
	await deps.provisionCustomer(credential);
	return credential;
}
//#endregion
//#region src/platform/auth/partnerNode/partnerNodeTokenSource.ts
var PARTNER_NODE_RESOURCE = "partner-node";
/**
* Ingest route that revokes partner-node sessions. A sign-in credential
* revokes every session of that login, including ones an earlier page load
* minted; a partner-node token (even expired) revokes only its own session.
*/
var PARTNER_NODE_REVOKE_ROUTE = "/auth/token/revoke";
/** An ingest that predates sign-in revoke refuses the sign-in with this code. */
var SIGN_IN_REVOKE_UNSUPPORTED = "auth_type_not_allowed";
var zPartnerNodeTokenResponse = zExchangeTokenResponse.pick({
	token: true,
	expires_at: true,
	workspace: true
});
function createPartnerNodeTokenSource({ apiUrl, now = () => Date.now() }) {
	const minted = /* @__PURE__ */ new Map();
	const inFlight = /* @__PURE__ */ new Map();
	let generation = 0;
	const keyOf = ({ ownerUid, workspaceId }) => `${ownerUid}:${workspaceId}`;
	async function mint(target) {
		const credential = await target.credential();
		if (!credential) return {
			ok: false,
			reason: "no_identity"
		};
		const body = {
			workspace_id: target.workspaceId,
			resource: PARTNER_NODE_RESOURCE
		};
		let response;
		try {
			response = await fetch(apiUrl("/auth/token"), {
				method: "POST",
				headers: {
					Authorization: `Bearer ${credential}`,
					"Content-Type": "application/json"
				},
				body: JSON.stringify(body)
			});
		} catch {
			return {
				ok: false,
				reason: "network"
			};
		}
		if (!response.ok) return {
			ok: false,
			reason: "http",
			status: response.status
		};
		let json;
		try {
			json = await response.json();
		} catch {
			return {
				ok: false,
				reason: "malformed"
			};
		}
		const parsed = zPartnerNodeTokenResponse.safeParse(json);
		if (!parsed.success) return {
			ok: false,
			reason: "malformed"
		};
		if (parsed.data.workspace.id !== target.workspaceId) return {
			ok: false,
			reason: "workspace_mismatch"
		};
		const expiresAt = Date.parse(parsed.data.expires_at);
		if (!(expiresAt > now())) return {
			ok: false,
			reason: "expired"
		};
		return {
			ok: true,
			token: parsed.data.token,
			expiresAt
		};
	}
	async function requestRevoke(bearer) {
		let response;
		try {
			response = await fetch(apiUrl(PARTNER_NODE_REVOKE_ROUTE), {
				method: "POST",
				headers: { Authorization: `Bearer ${bearer}` }
			});
		} catch {
			return {
				ok: false,
				reason: "network"
			};
		}
		if (response.ok) return { ok: true };
		const body = await response.json().catch(() => void 0);
		const code = zErrorResponse.safeParse(body).data?.code;
		return {
			ok: false,
			reason: "http",
			status: response.status,
			code
		};
	}
	function reportRevokeFailure(outcome) {
		reportError(/* @__PURE__ */ new Error("Partner-node session revoke failed"), {
			surface: "auth",
			errorType: "failure_revoking_partner_node_sessions",
			level: "warning",
			tags: outcome.reason === "http" ? {
				reason: outcome.reason,
				status: outcome.status
			} : { reason: outcome.reason }
		});
	}
	async function revokeWith(token) {
		const outcome = await requestRevoke(token);
		if (!outcome.ok) reportRevokeFailure(outcome);
	}
	/** Forgets every minted token, returning one held token per account. */
	function forgetAll() {
		generation += 1;
		inFlight.clear();
		const tokenPerOwner = /* @__PURE__ */ new Map();
		for (const { ownerUid, token } of minted.values()) tokenPerOwner.set(ownerUid, token);
		minted.clear();
		return [...tokenPerOwner.values()];
	}
	function reusableToken(key) {
		const entry = minted.get(key);
		if (!entry) return void 0;
		return entry.expiresAt - now() > 36e5 ? entry.token : void 0;
	}
	/**
	* A partner-node token for the target, reused while it has comfortable life
	* left, minted once for concurrent callers. Undefined when minting failed,
	* so the caller keeps the workspace token.
	*/
	function tokenFor(target) {
		const key = keyOf(target);
		const reusable = reusableToken(key);
		if (reusable) return Promise.resolve(reusable);
		const pending = inFlight.get(key);
		if (pending) return pending;
		const mintGeneration = generation;
		const request = mint(target).then((outcome) => {
			if (!outcome.ok) {
				reportError(/* @__PURE__ */ new Error("Partner-node token mint failed"), {
					surface: "auth",
					errorType: "failure_minting_partner_node_token",
					level: "warning",
					tags: {
						reason: outcome.reason,
						status: outcome.status
					}
				});
				return;
			}
			if (mintGeneration !== generation) {
				revokeWith(outcome.token);
				return;
			}
			minted.set(key, {
				ownerUid: target.ownerUid,
				token: outcome.token,
				expiresAt: outcome.expiresAt
			});
			return outcome.token;
		});
		inFlight.set(key, request);
		request.finally(() => {
			if (inFlight.get(key) === request) inFlight.delete(key);
		});
		return request;
	}
	/**
	* Forgets every minted token and revokes with the ones this page load still
	* holds. Used when the sign-in credential is already gone.
	*/
	async function revokeAll() {
		await Promise.all(forgetAll().map(revokeWith));
	}
	/**
	* Forgets every minted token and revokes every partner-node session of the
	* login `credential` signed in, whichever page load minted them. Falls back
	* to the held tokens when there is no credential or the ingest does not
	* take a sign-in on this route yet.
	*/
	async function revokeLogin(credential) {
		const held = forgetAll();
		if (credential) {
			const outcome = await requestRevoke(credential);
			if (outcome.ok) return;
			if (!(outcome.reason === "http" && outcome.code === SIGN_IN_REVOKE_UNSUPPORTED)) {
				reportRevokeFailure(outcome);
				return;
			}
		}
		await Promise.all(held.map(revokeWith));
	}
	return {
		tokenFor,
		revokeAll,
		revokeLogin
	};
}
//#endregion
//#region src/platform/auth/partnerNode/partnerNodeTokens.ts
var partnerNodeTokens = createPartnerNodeTokenSource({ apiUrl: workspaceApiUrl });
//#endregion
//#region src/platform/onboarding/onboardingReplay.ts
var REPLAY_KEY = "Comfy.OnboardingReplay";
function reportStorageError(error, operation) {
	reportError(error, {
		surface: "platform",
		errorType: `error_${operation}_onboarding_replay_request`
	});
}
function isReplayRequest(value) {
	if (typeof value !== "object" || value === null) return false;
	return "survey" in value && typeof value.survey === "boolean" && "firstRun" in value && typeof value.firstRun === "boolean" && "ownerId" in value && typeof value.ownerId === "string";
}
function writeReplayRequest(request) {
	try {
		sessionStorage.setItem(REPLAY_KEY, JSON.stringify(request));
		return true;
	} catch (error) {
		reportStorageError(error, "writing");
		return false;
	}
}
function readReplayRequest(ownerId) {
	if (ownerId === void 0) return;
	try {
		const stored = sessionStorage.getItem(REPLAY_KEY);
		if (stored === null) return;
		const request = JSON.parse(stored);
		if (!isReplayRequest(request) || request.ownerId !== ownerId) {
			sessionStorage.removeItem(REPLAY_KEY);
			return;
		}
		return request;
	} catch (error) {
		reportStorageError(error, "reading");
	}
}
function consumeReplayRequest(gate, ownerId) {
	const request = readReplayRequest(ownerId);
	if (!request) return;
	const next = {
		...request,
		[gate]: false
	};
	try {
		sessionStorage.setItem(REPLAY_KEY, JSON.stringify(next));
	} catch (error) {
		reportStorageError(error, "clearing");
	}
}
function isSurveyReplayRequested(ownerId) {
	return readReplayRequest(ownerId)?.survey === true;
}
function consumeSurveyReplayRequest(ownerId) {
	consumeReplayRequest("survey", ownerId);
}
function restoreSurveyReplayRequest(ownerId) {
	const current = readReplayRequest(ownerId);
	if (!current) return;
	writeReplayRequest({
		ownerId: current.ownerId,
		survey: true,
		firstRun: current.firstRun
	});
}
function isFirstRunReplayRequested(ownerId) {
	return readReplayRequest(ownerId)?.firstRun === true;
}
function consumeFirstRunReplayRequest(ownerId) {
	consumeReplayRequest("firstRun", ownerId);
}
function requestOnboardingReplay(ownerId) {
	return true;
}
function clearOnboardingReplay(ownerId) {
	try {
		sessionStorage.removeItem(REPLAY_KEY);
	} catch (error) {
		reportStorageError(error, "clearing");
		if (ownerId) writeReplayRequest({
			ownerId,
			survey: false,
			firstRun: false
		});
	}
}
//#endregion
//#region src/stores/authStore.ts
var BILLING_PORTAL_REQUEST_TIMEOUT_MS = 3e4;
/** `AuthStoreError.code` for a `/customers/*` call skipped because the account has no personal workspace. */
var NO_PERSONAL_WORKSPACE = "no_personal_workspace";
var AuthStoreError = class extends Error {
	status;
	code;
	constructor(message, status, code) {
		super(message);
		this.name = "AuthStoreError";
		this.status = status;
		this.code = code;
	}
};
/** The account belongs to an SSO organization, so it must sign in with SSO. */
var SsoRequiredAuthError = class extends AuthStoreError {
	organizationId;
	constructor(organizationId) {
		super(t("auth.sso.required.body"), 403, "sso_required");
		this.name = "SsoRequiredAuthError";
		this.organizationId = organizationId;
	}
};
var SSO_SIGN_IN_PROVIDERS = /* @__PURE__ */ new Set(["saml.workos", "oidc.workos"]);
async function webSessionRunToken(requests) {
	const scope = await requests.scope();
	if (!scope) return void 0;
	const result = await requests.workspaceToken(scope);
	if (result.status === "ok") return result.credential.token;
	if (result.httpStatus !== 401) reportError(/* @__PURE__ */ new Error(`Run token mint failed: ${result.code}`), {
		surface: "auth",
		errorType: "web_session_run_token_failure",
		level: "warning",
		tags: {
			failure_code: result.code,
			http_status: result.httpStatus ?? 0
		}
	});
}
var useAuthStore = defineStore("auth", () => {
	const { flags } = useFeatureFlags();
	const cloudWebSessionStore = useCloudWebSessionStore();
	const loading = ref(false);
	const currentUser = ref(null);
	const isInitialized = ref(false);
	const customerProvisionedIdentity = ref(null);
	/**
	* Memoizes the in-flight or successful customer provisioning attempt for
	* the current account (see recoverMissingCustomer). Declared here so the
	* auth-state listener below can reset it before its initializer would
	* otherwise run.
	*/
	let customerRecovery = null;
	let customerRecoveryIdentity = null;
	const isFetchingBalance = ref(false);
	const mintUnifiedToken = useMemoize((uid) => useWorkspaceAuthStore().mintAtLogin().then((success) => {
		if (!success) mintUnifiedToken.delete(uid);
		return success;
	}));
	const balance = ref(null);
	const lastBalanceUpdateTime = ref(null);
	const tokenRefreshTrigger = ref(0);
	/**
	* The user ID for which the initial ID token has been observed.
	* When a token changes for the same user, that is a refresh.
	*/
	const lastTokenUserId = ref(null);
	const buildApiUrl = (path) => `${getComfyApiBaseUrl()}${path}`;
	const sessionUser = computed(() => cloudWebSessionStore.signedInUser);
	const isAuthenticated = computed(() => isDesktopHostSignedIn() || !!currentUser.value || !!sessionUser.value);
	const userEmail = computed(() => isDesktopHostSignedIn() ? desktopHostUser.value?.email : sessionUser.value?.email ?? currentUser.value?.email);
	const userId = computed(() => isDesktopHostSignedIn() ? desktopHostUser.value?.id : sessionUser.value?.id ?? currentUser.value?.uid);
	/** False only when SSO is on and the session says there is no personal workspace. */
	const hasPersonalWorkspace = computed(() => !(flags.ssoEnabled && sessionUser.value?.hasPersonalWorkspace === false));
	const assertHasPersonalWorkspace = () => {
		if (!hasPersonalWorkspace.value) throw new AuthStoreError(t("toastMessages.noPersonalWorkspace"), void 0, NO_PERSONAL_WORKSPACE);
	};
	/** With SSO on, the session's user when no Firebase user signed this tab in. */
	const sessionOnlyUser = computed(() => flags.ssoEnabled && currentUser.value === null ? sessionUser.value : void 0);
	/** With SSO on, whether the server says the session signed in through SSO. */
	const signedInWithSso = computed(() => flags.ssoEnabled && SSO_SIGN_IN_PROVIDERS.has(sessionUser.value?.signInProvider ?? ""));
	const sessionOnlyRequests = () => sessionOnlyUser.value ? webSessionRequests() : void 0;
	function getShareAuthMetadata() {
		const shareId = getPreservedQueryParam(PRESERVED_QUERY_NAMESPACES.SHARE_AUTH, "share");
		if (shareId) clearPreservedQuery(PRESERVED_QUERY_NAMESPACES.SHARE_AUTH);
		return shareId ? { share_id: shareId } : {};
	}
	/**
	* Drops the previous account's state when the signed-in identity changes
	* or signs out, whichever source (Firebase or the Desktop host) changed it.
	*/
	const resetAccountState = (previousUserId, nextUserId) => {
		const identityChanged = previousUserId !== null && previousUserId !== nextUserId;
		if (nextUserId === null || identityChanged) {
			useWorkspaceAuthStore().clearWorkspaceContext();
			mintUnifiedToken.clear();
			partnerNodeTokens.revokeAll();
		}
		if (identityChanged) {
			clearOnboardingReplay(previousUserId);
			useTeamWorkspaceStore().resetForIdentityChange();
			invalidateRemoteConfig();
		}
		balance.value = null;
		lastBalanceUpdateTime.value = null;
		customerProvisionedIdentity.value = null;
		customerRecovery = null;
		customerRecoveryIdentity = null;
	};
	firebaseIdentity.onUserChanged((user) => {
		resetAccountState(currentUser.value?.uid ?? null, user?.uid ?? null);
		currentUser.value = user;
		isInitialized.value = true;
		if (user === null) lastTokenUserId.value = null;
	});
	watch(() => desktopHostUser.value?.id ?? null, (nextUserId, previousUserId) => resetAccountState(previousUserId, nextUserId));
	watch(() => desktopHostUser.value?.id ?? null, (userId, previousUserId) => {
		if (userId === null || false) return;
		const teamWorkspaceStore = useTeamWorkspaceStore();
		if (previousUserId == null && teamWorkspaceStore.initState !== "uninitialized") {
			useWorkspaceAuthStore().clearWorkspaceContext();
			teamWorkspaceStore.resetForIdentityChange();
		}
		teamWorkspaceStore.initialize().catch(() => void 0);
	}, { immediate: true });
	firebaseIdentity.onTokenChanged((user) => {});
	/**
	* Bumps the token-refresh trigger so downstream consumers (e.g. session
	* cookie rotation via useCurrentUser) react to a fresh Cloud JWT. Called by
	* the unified refresh lifecycle; under unified_cloud_auth it replaces the
	* Firebase onIdTokenChanged bump above as the sole rotation driver.
	*/
	const notifyTokenRefreshed = () => {
		tokenRefreshTrigger.value++;
	};
	/**
	* While Desktop shares its session, every credential comes from Desktop;
	* otherwise the existing Firebase / web-session / API-key paths answer.
	*/
	const preferDesktopHost = (fromHost, otherwise) => () => isDesktopHostSignedIn() ? fromHost() : otherwise();
	const desktopHostTabHeader = async () => headerFromToken(await desktopHostTabToken());
	const getFirebaseIdToken = async () => {
		const user = currentUser.value;
		if (!user) return;
		try {
			const token = await user.getIdToken();
			return currentUser.value?.uid === user.uid ? token : void 0;
		} catch (error) {
			if (currentUser.value?.uid !== user.uid) return;
			if (error instanceof FirebaseError && error.code === AUTH_ERROR_CODES_MAP_DO_NOT_USE_INTERNALLY.NETWORK_REQUEST_FAILED) {
				console.warn("Could not authenticate with Firebase. Features requiring authentication might not work.");
				return;
			}
			useDialogService().showErrorDialog(error, {
				title: t("errorDialog.defaultTitle"),
				reportType: "authenticationError"
			});
			console.error(error);
		}
	};
	/**
	* Awaits any in-flight unified-auth login mint for the current identity.
	* The wait can outlast an account switch, so callers must treat a `true`
	* result (identity changed while waiting) as stale and not read the new
	* identity's unified token or fall back to its Firebase token.
	*/
	const awaitUnifiedMint = async () => {
		const uid = currentUser.value?.uid;
		if (uid) await mintUnifiedToken(uid).catch(() => false);
		return currentUser.value?.uid !== uid;
	};
	/**
	* Unified Cloud JWT header, falling back to the Firebase token when minting
	* failed. See getAuthHeader for the full priority order.
	*/
	const getUnifiedAuthHeader = async () => {
		if (await awaitUnifiedMint()) return null;
		const token = useWorkspaceAuthStore().getUnifiedToken();
		if (token) return { Authorization: `Bearer ${token}` };
		return await getFirebaseAuthHeader();
	};
	/**
	* Retrieves the appropriate authentication header for API requests.
	*
	* When unified_cloud_auth is enabled, awaits any in-flight login mint and
	* returns the single Cloud JWT; if minting failed, falls back to the
	* Firebase token rather than reporting an authenticated user as logged out.
	* Otherwise checks for authentication in the following order:
	* 1. Workspace token on Cloud when the user has active workspace context
	* 2. Firebase authentication token (if user is logged in)
	* 3. API key (if stored in the browser's credential manager)
	*
	* @returns {Promise<AuthHeader | null>}
	*   - A LoggedInAuthHeader with Bearer token (unified Cloud JWT, workspace, or Firebase)
	*   - An ApiKeyAuthHeader with X-API-KEY if API key exists
	*   - null if no authentication method is available
	*/
	const getAccountAuthHeader = async () => {
		const sessionOnly = sessionOnlyRequests();
		if (sessionOnly) return headerFromToken(await webSessionRunToken(sessionOnly));
		if (flags.unifiedCloudAuthEnabled) return getUnifiedAuthHeader();
		if (webSessionRequests()) return getUserAuthHeader();
		useWorkspaceAuthStore();
		useTeamWorkspaceStore().activeWorkspaceId;
		const token = await getIdToken();
		if (token) return { Authorization: `Bearer ${token}` };
		return useApiKeyAuthStore().getAuthHeader();
	};
	/**
	* Returns Firebase auth header for user-scoped endpoints (e.g., /customers/*).
	* Use this for endpoints that need user identity, not workspace context.
	*/
	const headerFromToken = (token) => token ? { Authorization: `Bearer ${token}` } : null;
	const getFirebaseAuthHeader = async () => headerFromToken(await getIdToken());
	/**
	* Returns the user-identity auth header for user-scoped endpoints
	* (e.g., /customers/*): the Firebase token for signed-in sessions, the
	* stored API key for API-key sessions. Never a workspace-scoped token.
	*/
	const getUserAuthHeader = async () => currentUser.value === null && !isDesktopHostSignedIn() ? useApiKeyAuthStore().getAuthHeader() : await getFirebaseAuthHeader();
	const getCustomerAuthHeader = async () => await webSessionResourceHeader() ?? await getUserAuthHeader();
	const currentUserIdentity = () => isDesktopHostSignedIn() ? desktopHostUser.value?.id ?? null : sessionUser.value?.id ?? currentUser.value?.uid ?? useApiKeyAuthStore().getApiKey();
	const currentUserCredentialIdentity = () => currentUser.value?.uid ?? useApiKeyAuthStore().getApiKey();
	/**
	* Response data from a user-scoped endpoint belongs to the identity that
	* asked for it. A 200 bypasses the recovery guards in
	* fetchWithCustomerRecovery, which only fence the missing-customer retry, so
	* a credential swap while the request was in flight would hand the previous
	* account's data to the current session — a Stripe portal or checkout URL
	* minted for A opening inside B.
	*/
	const assertIdentityUnchanged = (requestOwner) => {
		if (currentUserIdentity() !== requestOwner) throw new AuthStoreError(t("toastMessages.userNotAuthenticated"));
	};
	/**
	* Desktop's credential, always requested for an explicit workspace: the
	* tab's active workspace, else the one Desktop's session reports. Desktop
	* releases nothing on a mismatch, and with neither there is no credential.
	*/
	const desktopHostTabToken = async () => {
		const tabWorkspaceId = () => useTeamWorkspaceStore().activeWorkspaceId ?? desktopHostUser.value?.workspaceId;
		const workspaceId = tabWorkspaceId();
		if (!workspaceId) return void 0;
		const token = await desktopHostWorkspaceToken(workspaceId);
		return tabWorkspaceId() === workspaceId ? token : void 0;
	};
	/**
	* Returns the workspace-scoped auth header. An API-key session has no
	* Firebase token to exchange for a workspace token; the key itself is the
	* workspace credential (the server resolves the key's bound workspace), so
	* it is sent directly instead of minting a token.
	*/
	const getAccountWorkspaceAuthHeader = async () => {
		const sessionOnly = sessionOnlyRequests();
		if (sessionOnly) return headerFromToken(await webSessionRunToken(sessionOnly));
		if (flags.unifiedCloudAuthEnabled) {
			if (await awaitUnifiedMint()) return null;
			const token = useWorkspaceAuthStore().getUnifiedToken();
			return token ? { Authorization: `Bearer ${token}` } : null;
		}
		if (currentUser.value === null) {
			const apiKeyHeader = useApiKeyAuthStore().getAuthHeader();
			if (apiKeyHeader) return apiKeyHeader;
		}
		const activeWorkspaceId = useTeamWorkspaceStore().activeWorkspaceId;
		if (!activeWorkspaceId) return getFirebaseAuthHeader();
		return useWorkspaceAuthStore().ensureWorkspaceAuthHeader(activeWorkspaceId);
	};
	/**
	* Unified Cloud JWT token. See getAuthToken for the full priority order.
	*/
	const getUnifiedAuthToken = async () => {
		if (await awaitUnifiedMint()) return void 0;
		return useWorkspaceAuthStore().getUnifiedToken();
	};
	/**
	* Returns the raw auth token (not wrapped in a header object).
	* When unified_cloud_auth is enabled, awaits any in-flight login mint and
	* returns the single Cloud JWT; otherwise Cloud priority is workspace token
	* > Firebase token.
	* Use this for WebSocket connections and backend node auth.
	*/
	const getAccountAuthToken = async () => {
		const sessionOnly = sessionOnlyRequests();
		if (sessionOnly) return webSessionRunToken(sessionOnly);
		if (flags.unifiedCloudAuthEnabled) return getUnifiedAuthToken();
		useWorkspaceAuthStore();
		useTeamWorkspaceStore().activeWorkspaceId;
		return await getIdToken();
	};
	/**
	* A local Firebase session resolves its workspace before its first run.
	* False when that resolution failed.
	*/
	const resolveLocalWorkspace = async () => {
		const teamWorkspaceStore = useTeamWorkspaceStore();
		if (!(currentUser.value !== null && !teamWorkspaceStore.activeWorkspaceId && teamWorkspaceStore.initState !== "ready")) return true;
		try {
			await teamWorkspaceStore.initialize();
			return true;
		} catch {
			return false;
		}
	};
	/** The run token for the tab's active workspace, per distribution. */
	const activeWorkspaceRunToken = async () => {
		const activeWorkspaceId = useTeamWorkspaceStore().activeWorkspaceId;
		if (currentUser.value && !activeWorkspaceId) return void 0;
		if (!activeWorkspaceId) return await getIdToken() ?? void 0;
		return await useWorkspaceAuthStore().ensureWorkspaceToken(activeWorkspaceId) ?? void 0;
	};
	const getAccountWorkspaceAuthToken = async () => {
		const requests = webSessionRequests();
		if (requests) return webSessionRunToken(requests);
		if (flags.unifiedCloudAuthEnabled) return useWorkspaceAuthStore().getUnifiedToken();
		if (currentUser.value === null && useApiKeyAuthStore().isAuthenticated) return;
		if (!await resolveLocalWorkspace()) return void 0;
		return activeWorkspaceRunToken();
	};
	const getIdToken = preferDesktopHost(() => desktopHostTabToken(), getFirebaseIdToken);
	const getAuthHeader = preferDesktopHost(desktopHostTabHeader, getAccountAuthHeader);
	const getWorkspaceAuthHeader = preferDesktopHost(desktopHostTabHeader, getAccountWorkspaceAuthHeader);
	const getAuthToken = preferDesktopHost(() => desktopHostTabToken(), getAccountAuthToken);
	const getWorkspaceAuthToken = preferDesktopHost(() => desktopHostTabToken(), getAccountWorkspaceAuthToken);
	const getAuthHeaderOrThrow = async () => {
		const authHeader = await getAuthHeader();
		if (!authHeader) throw new AuthStoreError(t("toastMessages.userNotAuthenticated"));
		return authHeader;
	};
	const getFirebaseAuthHeaderOrThrow = async () => {
		const authHeader = await getFirebaseAuthHeader();
		if (!authHeader) throw new AuthStoreError(t("toastMessages.userNotAuthenticated"));
		return authHeader;
	};
	const getWorkspaceAuthHeaderOrThrow = async () => {
		const authHeader = await getWorkspaceAuthHeader();
		if (!authHeader) throw new AuthStoreError(t("toastMessages.userNotAuthenticated"));
		return authHeader;
	};
	const getWorkspaceAuthTokenOrThrow = async () => {
		const token = await getWorkspaceAuthToken();
		if (!token) throw new AuthStoreError(t("toastMessages.userNotAuthenticated"));
		return token;
	};
	const fetchBalance = async () => {
		if (!hasPersonalWorkspace.value) return null;
		isFetchingBalance.value = true;
		const requestOwner = currentUserIdentity();
		const requestCredential = currentUserCredentialIdentity();
		const requestIsCurrent = () => currentUserIdentity() === requestOwner && currentUserCredentialIdentity() === requestCredential;
		try {
			const authHeader = await getCustomerAuthHeader();
			if (!authHeader) throw new AuthStoreError(t("toastMessages.userNotAuthenticated"));
			const response = await fetchWithCustomerRecovery$1(buildApiUrl("/customers/balance"), { headers: {
				...authHeader,
				"Content-Type": "application/json"
			} });
			if (!response.ok) {
				if (response.status === 404) return null;
				const { message } = await parseErrorResponse(response);
				if (!requestIsCurrent()) return null;
				throw new AuthStoreError(t("toastMessages.failedToFetchBalance", { error: message }));
			}
			const balanceData = await response.json();
			if (!requestIsCurrent()) return null;
			lastBalanceUpdateTime.value = /* @__PURE__ */ new Date();
			balance.value = balanceData;
			return balanceData;
		} finally {
			isFetchingBalance.value = false;
		}
	};
	const createCustomer = async (payload, completedCredential) => {
		const completedUser = completedCredential?.user;
		if (!completedUser) assertHasPersonalWorkspace();
		const sessionIdentity = completedUser?.uid ?? currentUserIdentity();
		const authHeader = completedUser ? headerFromToken(await completedUser.getIdToken()) : await getCustomerAuthHeader();
		if (!authHeader) throw new AuthStoreError(t("toastMessages.userNotAuthenticated"));
		const body = {
			...payload,
			signup_source: DISTRIBUTION
		};
		const createCustomerRes = await fetchWithUnifiedRemint(buildApiUrl("/customers"), {
			method: "POST",
			headers: {
				...authHeader,
				"Content-Type": "application/json"
			},
			body: JSON.stringify(body)
		}, false);
		if (!createCustomerRes.ok) {
			if (!completedUser) assertIdentityUnchanged(sessionIdentity);
			const refusal = await createCustomerRes.clone().json().catch(() => void 0);
			if (isSsoRequiredRefusal(createCustomerRes.status, refusal)) throw new SsoRequiredAuthError(ssoRequiredOrganizationId(refusal));
			throw new AuthStoreError(t("toastMessages.failedToCreateCustomer", { error: createCustomerRes.statusText }), createCustomerRes.status);
		}
		const createCustomerResJson = await createCustomerRes.json();
		if (!createCustomerResJson.id) throw new AuthStoreError(t("toastMessages.failedToCreateCustomer", { error: "No customer ID returned" }));
		if (!completedUser) assertIdentityUnchanged(sessionIdentity);
		if (sessionIdentity !== null) customerProvisionedIdentity.value = sessionIdentity;
		return createCustomerResJson;
	};
	/**
	* Memoizes the customer provisioning attempt so concurrent or repeated 409
	* responses from /customers/* endpoints trigger at most one successful
	* POST /customers per account. A failed attempt is cleared so a later
	* request can retry, e.g. after a transient network failure.
	*/
	const recoverMissingCustomer = () => {
		const sessionIdentity = currentUserIdentity();
		if (customerRecovery === null || customerRecoveryIdentity !== sessionIdentity) {
			const thisRecovery = createCustomer().then(() => void 0).catch((error) => {
				if (customerRecovery === thisRecovery) {
					customerRecovery = null;
					customerRecoveryIdentity = null;
				}
				throw error;
			});
			customerRecovery = thisRecovery;
			customerRecoveryIdentity = sessionIdentity;
		}
		return customerRecovery;
	};
	/** /customers/* fetch that self-heals a never-provisioned account (rule in @comfyorg/account-core). */
	const fetchWithCustomerRecovery$1 = /* @__PURE__ */ __name(async (input, init) => {
		assertHasPersonalWorkspace();
		const requestOwner = currentUserIdentity();
		return fetchWithCustomerRecovery(input, {
			request: () => fetchWithUnifiedRemint(input, init ?? {}, false),
			recoverMissingCustomer,
			identityUnchanged: () => currentUserIdentity() === requestOwner,
			base: window.location.href
		});
	}, "fetchWithCustomerRecovery");
	const executeAuthAction = async (action, options = {}) => {
		loading.value = true;
		try {
			const result = await action();
			if (options.createCustomer) await provisionCustomerForSignedInUser(options.customerPayload);
			return result;
		} finally {
			loading.value = false;
		}
	};
	const login = async (email, password) => {
		const result = await executeAuthAction(() => firebaseIdentity.signInWithEmail(email, password), { createCustomer: true });
		useCloudWebSessionStore().signedInInteractively(result.user);
		useTelemetry()?.trackAuth({
			method: "email",
			is_new_user: false,
			user_id: result.user.uid,
			email: result.user.email ?? void 0,
			...getShareAuthMetadata()
		});
		return result;
	};
	const register = async (email, password, turnstileToken) => {
		const result = await executeAuthAction(() => signUpWithProvisioning({
			createUser: () => firebaseIdentity.createUserWithEmail(email, password),
			provisionCustomer: (credential) => createCustomer(turnstileToken ? { turnstile_token: turnstileToken } : void 0, credential),
			onRollbackFailure: (error) => {
				reportError(error, {
					surface: "auth",
					errorType: "auth_signup_rollback_failed"
				});
				console.warn("Failed to roll back orphaned Firebase user after customer creation failed", error);
			}
		}));
		useCloudWebSessionStore().signedInInteractively(result.user);
		useTelemetry()?.trackAuth({
			method: "email",
			is_new_user: true,
			user_id: result.user.uid,
			email: result.user.email ?? void 0,
			...getShareAuthMetadata()
		});
		return result;
	};
	const provisionCustomerForSignedInUser = async (payload, completedCredential) => {
		if (!(completedCredential ? await completedCredential.user.getIdToken() : await getIdToken())) throw new AuthStoreError(t("toastMessages.userNotAuthenticated"));
		await createCustomer(payload, completedCredential);
	};
	const loginWithGoogle = async (options) => {
		const result = await executeAuthAction(() => socialSignInWithProvisioning({
			signIn: () => options?.resumed ?? firebaseIdentity.signInWithGoogle(options?.popup),
			provisionCustomer: (credential) => provisionCustomerForSignedInUser(void 0, credential)
		}));
		const additionalUserInfo = getAdditionalUserInfo(result);
		useCloudWebSessionStore().signedInInteractively(result.user);
		useTelemetry()?.trackAuth({
			method: "google",
			is_new_user: options?.isNewUser || additionalUserInfo?.isNewUser || false,
			user_id: result.user.uid,
			email: result.user.email ?? void 0,
			...getShareAuthMetadata()
		});
		return result;
	};
	const loginWithGithub = async (options) => {
		const result = await executeAuthAction(() => socialSignInWithProvisioning({
			signIn: () => options?.resumed ?? firebaseIdentity.signInWithGitHub(options?.popup),
			provisionCustomer: (credential) => provisionCustomerForSignedInUser(void 0, credential)
		}));
		const additionalUserInfo = getAdditionalUserInfo(result);
		useCloudWebSessionStore().signedInInteractively(result.user);
		useTelemetry()?.trackAuth({
			method: "github",
			is_new_user: options?.isNewUser || additionalUserInfo?.isNewUser || false,
			user_id: result.user.uid,
			email: result.user.email ?? void 0,
			...getShareAuthMetadata()
		});
		return result;
	};
	const revokePartnerNodeLogin = async () => {
		if (!flags.partnerNodeTokenEnabled) return;
		const credential = isDesktopHostSignedIn() ? await desktopHostTabToken() : await revokingFirebaseIdToken();
		partnerNodeTokens.revokeLogin(credential);
	};
	const revokingFirebaseIdToken = async () => {
		const user = currentUser.value;
		const token = await user?.getIdToken().catch(() => void 0);
		return currentUser.value?.uid === user?.uid ? token : void 0;
	};
	const logout = async () => executeAuthAction(async () => {
		await revokePartnerNodeLogin();
		const signsOutDesktopHost = isDesktopHostSignedIn();
		if (signsOutDesktopHost && !await requestDesktopHostSignOut()) throw new AuthStoreError(t("auth.desktopHost.signOutFailed"));
		const dropsStoredApiKey = signsOutDesktopHost || flags.ssoEnabled && flags.unifiedWebSessionEnabled;
		await useCloudWebSessionStore().signOut();
		if (currentUser.value) await firebaseIdentity.signOut();
		const apiKeyStore = useApiKeyAuthStore();
		if (dropsStoredApiKey && apiKeyStore.getApiKey() !== null) await apiKeyStore.clearStoredApiKey();
	});
	const sendPasswordReset = async (email) => executeAuthAction(() => firebaseIdentity.sendPasswordReset(email));
	/** Update password for current user */
	const _updatePassword = async (newPassword) => {
		if (!currentUser.value) throw new AuthStoreError(t("toastMessages.userNotAuthenticated"));
		await firebaseIdentity.updatePassword(newPassword);
	};
	const addCredits = async (requestBodyContent) => {
		const requestOwner = currentUserIdentity();
		const authHeader = await getCustomerAuthHeader();
		if (!authHeader) throw new AuthStoreError(t("toastMessages.userNotAuthenticated"));
		if (customerProvisionedIdentity.value !== requestOwner) {
			await recoverMissingCustomer();
			if (currentUserIdentity() !== requestOwner) throw new AuthStoreError(t("toastMessages.userNotAuthenticated"));
		}
		const response = await fetchWithCustomerRecovery$1(buildApiUrl("/customers/credit"), {
			method: "POST",
			headers: {
				...authHeader,
				"Content-Type": "application/json"
			},
			body: JSON.stringify(requestBodyContent)
		});
		if (!response.ok) {
			const { message, code } = await parseErrorResponse(response);
			assertIdentityUnchanged(requestOwner);
			throw new AuthStoreError(t("toastMessages.failedToInitiateCreditPurchase", { error: message }), response.status, code);
		}
		const creditPurchase = await response.json();
		assertIdentityUnchanged(requestOwner);
		return creditPurchase;
	};
	const initiateCreditPurchase = async (requestBodyContent) => executeAuthAction(() => addCredits(requestBodyContent));
	const accessBillingPortal = async (targetTier, options) => {
		if (targetTier && options?.cancelSubscription) throw new AuthStoreError("cancelSubscription cannot be combined with a target tier");
		const requestOwner = currentUserIdentity();
		const authHeader = await getCustomerAuthHeader();
		if (!authHeader) throw new AuthStoreError(t("toastMessages.userNotAuthenticated"));
		const response = await fetchWithCustomerRecovery$1(buildApiUrl("/customers/billing"), {
			method: "POST",
			signal: AbortSignal.timeout(BILLING_PORTAL_REQUEST_TIMEOUT_MS),
			headers: {
				...authHeader,
				"Content-Type": "application/json"
			},
			...targetTier && { body: JSON.stringify({ target_tier: targetTier }) },
			...options?.cancelSubscription === true && { body: JSON.stringify({ cancel_subscription: true }) }
		});
		if (!response.ok) {
			const { message, code } = await parseErrorResponse(response);
			assertIdentityUnchanged(requestOwner);
			throw new AuthStoreError(t("toastMessages.failedToAccessBillingPortal", { error: message }), response.status, code);
		}
		const billingPortal = await response.json();
		assertIdentityUnchanged(requestOwner);
		return billingPortal;
	};
	return {
		loading,
		currentUser,
		isInitialized,
		balance,
		lastBalanceUpdateTime,
		isFetchingBalance,
		tokenRefreshTrigger,
		isAuthenticated,
		sessionUser,
		hasPersonalWorkspace,
		sessionOnlyUser,
		signedInWithSso,
		userEmail,
		userId,
		login,
		register,
		logout,
		createCustomer,
		fetchWithCustomerRecovery: fetchWithCustomerRecovery$1,
		getIdToken,
		loginWithGoogle,
		loginWithGithub,
		initiateCreditPurchase,
		fetchBalance,
		accessBillingPortal,
		sendPasswordReset,
		updatePassword: _updatePassword,
		getAuthHeader,
		getAuthHeaderOrThrow,
		getFirebaseAuthHeader,
		getFirebaseAuthHeaderOrThrow,
		getUserAuthHeader,
		currentUserIdentity,
		getWorkspaceAuthHeader,
		getWorkspaceAuthHeaderOrThrow,
		getAuthToken,
		getWorkspaceAuthToken,
		getWorkspaceAuthTokenOrThrow,
		notifyTokenRefreshed
	};
});
provideAuthStore(useAuthStore);
provideEnsureSessionCookie(async () => {
	const { useSessionCookie } = await __vitePreload(async () => {
		const { useSessionCookie } = await import("./useSessionCookie-EVyvM0ta.js");
		return { useSessionCookie };
	}, __vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43]), import.meta.url);
	await useSessionCookie().ensureSessionCookie();
});
//#endregion
export { consumeFirstRunReplayRequest as a, isSurveyReplayRequested as c, partnerNodeTokens as d, useApiKeyAuthStore as f, clearOnboardingReplay as i, requestOnboardingReplay as l, SsoRequiredAuthError as n, consumeSurveyReplayRequest as o, useAuthStore as r, isFirstRunReplayRequested as s, AuthStoreError as t, restoreSurveyReplayRequest as u };
