import "./rolldown-runtime-xtsTai4I.js";
import { F as createBaseVNode, Ft as ref, G as defineComponent, I as createBlock, L as createCommentVNode, Nt as reactive, Wt as unref, bt as watch, ct as openBlock, dt as renderSlot, et as mergeProps, q as guardReactiveProps, qt as normalizeProps, wt as withCtx, yt as useTemplateRef, z as createPropsRestProxy } from "./vendor-vue-core-CuN1excl.js";
import { Cn as DialogContent_default$1, Dn as injectDialogRootContext, En as DialogRoot_default, Fn as ConfigProvider_default, In as injectConfigProviderContext, Mn as useForwardPropsEmits, bn as DialogPortal_default$1, xn as DialogOverlay_default$1 } from "./vendor-reka-ui-NRTk7aIV.js";
import { i as cva } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
//#endregion
//#region src/components/ui/dialog/Dialog.vue
var Dialog_default = /* @__PURE__ */ defineComponent({
	__name: "Dialog",
	props: {
		open: { type: Boolean },
		defaultOpen: { type: Boolean },
		modal: { type: Boolean },
		unmountOnHide: { type: Boolean }
	},
	emits: ["update:open"],
	setup(__props, { emit: __emit }) {
		const forwarded = useForwardPropsEmits(__props, __emit);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(DialogRoot_default), mergeProps({ "data-slot": "dialog" }, unref(forwarded)), {
				default: withCtx((slotProps) => [renderSlot(_ctx.$slots, "default", normalizeProps(guardReactiveProps(slotProps)))]),
				_: 3
			}, 16);
		};
	}
});
//#endregion
//#region src/components/ui/dialog/dialog.variants.ts
var dialogContentVariants = cva({
	base: "fixed z-overlay flex flex-col outline-none data-[state=closed]:pointer-events-none data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[state=open]:animate-in data-[state=open]:fade-in-0 data-[state=open]:zoom-in-95",
	variants: {
		surface: {
			card: "rounded-2xl border bg-background shadow-lg",
			none: ""
		},
		size: {
			sm: "sm:max-w-96",
			md: "sm:max-w-xl",
			lg: "sm:max-w-3xl",
			xl: "sm:max-w-5xl",
			full: "",
			fit: ""
		},
		maximized: {
			true: "inset-2 top-2 left-2 size-auto max-h-none max-w-none sm:max-w-none",
			false: "top-1/2 left-1/2 max-h-[85vh] w-[calc(100vw-1rem)] translate-x-[calc(-50%-min(var(--workspace-inset-right,0px)/2,max(0px,(50vw-50%-var(--workspace-inset-right,0px)/2-0.5rem+1px)*1000)))] -translate-y-1/2"
		}
	},
	compoundVariants: [{
		size: "full",
		maximized: false,
		class: "h-[90vh] max-h-[90vh] w-[90vw] max-w-[min(90vw,calc(100vw-var(--workspace-inset-right,0px)-1rem))]"
	}, {
		size: "fit",
		maximized: false,
		class: "w-fit max-w-[calc(100vw-1rem)]"
	}],
	defaultVariants: {
		surface: "card",
		size: "md",
		maximized: false
	}
});
//#endregion
//#region src/components/ui/dialog/DialogContent.vue
var DialogContent_default = /* @__PURE__ */ defineComponent({
	__name: "DialogContent",
	props: {
		forceMount: { type: Boolean },
		disableOutsidePointerEvents: { type: Boolean },
		asChild: { type: Boolean },
		as: {},
		class: {
			type: [
				Boolean,
				null,
				String,
				Object,
				Array
			],
			default: ""
		},
		maximized: {
			type: Boolean,
			default: false
		},
		size: {},
		surface: {}
	},
	emits: [
		"escapeKeyDown",
		"pointerDownOutside",
		"focusOutside",
		"interactOutside",
		"openAutoFocus",
		"closeAutoFocus"
	],
	setup(__props, { emit: __emit }) {
		const restProps = createPropsRestProxy(__props, [
			"class",
			"maximized",
			"size",
			"surface"
		]);
		const forwarded = useForwardPropsEmits(restProps, __emit);
		function focusAutofocusTarget(event) {
			if (event.defaultPrevented || !(event.target instanceof HTMLElement)) return;
			const target = event.target.querySelector("[autofocus]");
			if (!target) return;
			target.focus();
			if (document.activeElement === target) event.preventDefault();
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(DialogContent_default$1), mergeProps(unref(forwarded), {
				"data-reka-dialog-content": "",
				"data-maximized": __props.maximized || void 0,
				class: unref(cn)(unref(dialogContentVariants)({
					maximized: __props.maximized,
					size: __props.size,
					surface: __props.surface
				}), __props.class, __props.maximized && "top-2 left-2 size-auto max-h-none max-w-none sm:max-w-none"),
				onOpenAutoFocus: focusAutofocusTarget,
				onFocus: focusAutofocusTarget
			}), {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
				_: 3
			}, 16, ["data-maximized", "class"]);
		};
	}
});
//#endregion
//#region src/components/ui/dialog/DialogOverlay.vue
var DialogOverlay_default = /* @__PURE__ */ defineComponent({
	__name: "DialogOverlay",
	props: {
		forceMount: { type: Boolean },
		asChild: { type: Boolean },
		as: {},
		class: {
			type: [
				Boolean,
				null,
				String,
				Object,
				Array
			],
			default: ""
		}
	},
	setup(__props) {
		const delegated = createPropsRestProxy(__props, ["class"]);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(DialogOverlay_default$1), mergeProps(delegated, {
				"data-slot": "dialog-overlay",
				"data-testid": "dialog-overlay",
				class: unref(cn)("fixed inset-0 z-overlay bg-black/70 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:animate-in data-[state=open]:fade-in-0", __props.class)
			}), null, 16, ["class"]);
		};
	}
});
//#endregion
//#region src/components/ui/dialog/DialogPortal.vue
var DialogPortal_default = /* @__PURE__ */ defineComponent({
	__name: "DialogPortal",
	props: {
		to: {},
		disabled: { type: Boolean },
		defer: { type: Boolean },
		forceMount: { type: Boolean }
	},
	setup(__props) {
		const props = __props;
		const { open } = injectDialogRootContext();
		const config = reactive(injectConfigProviderContext(null) ?? {});
		const portalTarget = useTemplateRef("portalTarget");
		const openCount = ref(0);
		watch(open, (isOpen) => {
			if (isOpen) openCount.value++;
		});
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(DialogPortal_default$1), mergeProps({ key: openCount.value }, props), {
				default: withCtx(() => [createBaseVNode("div", {
					ref_key: "portalTarget",
					ref: portalTarget,
					class: "pointer-events-none fixed inset-0 z-overlay *:pointer-events-auto empty:hidden"
				}, [portalTarget.value ? (openBlock(), createBlock(unref(ConfigProvider_default), mergeProps({ key: 0 }, config, { "teleport-to": portalTarget.value }), {
					default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
					_: 3
				}, 16, ["teleport-to"])) : createCommentVNode("", true)], 512)]),
				_: 3
			}, 16);
		};
	}
});
//#endregion
export { Dialog_default as i, DialogOverlay_default as n, DialogContent_default as r, DialogPortal_default as t };
