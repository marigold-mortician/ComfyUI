import "./rolldown-runtime-xtsTai4I.js";
import { F as createBaseVNode, G as defineComponent, I as createBlock, Jt as normalizeStyle, Kt as normalizeClass, R as createElementBlock, V as createStaticVNode, Wt as unref, Yt as toDisplayString, ct as openBlock, et as mergeProps, pt as resolveDynamicComponent } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { t as _plugin_vue_export_helper_default } from "./_plugin-vue_export-helper-DEKQMRQ4.js";
//#endregion
//#region src/components/ui/spinner/Spinner.vue
var Spinner_default = /* @__PURE__ */ defineComponent({
	__name: "Spinner",
	props: { class: {
		type: [
			Boolean,
			null,
			String,
			Object,
			Array
		],
		default: ""
	} },
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("svg", {
				role: "progressbar",
				class: normalizeClass(unref(cn)("size-6 animate-spin text-muted-foreground", __props.class)),
				viewBox: "0 0 24 24",
				fill: "none",
				xmlns: "http://www.w3.org/2000/svg"
			}, [..._cache[0] || (_cache[0] = [createBaseVNode("circle", {
				class: "opacity-25",
				cx: "12",
				cy: "12",
				r: "10",
				stroke: "currentColor",
				"stroke-width": "4"
			}, null, -1), createBaseVNode("path", {
				class: "opacity-75",
				fill: "currentColor",
				d: "M4 12a8 8 0 0 1 8-8v4a4 4 0 0 0-4 4H4Z"
			}, null, -1)])], 2);
		};
	}
});
//#endregion
//#region src/components/common/DotSpinner.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$1 = ["width", "height"];
//#endregion
//#region src/components/common/DotSpinner.vue
var DotSpinner_default = /*#__PURE__*/ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "DotSpinner",
	props: {
		size: { default: 24 },
		duration: { default: "2s" }
	},
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				"data-testid": "dot-spinner",
				class: "inline-flex items-center justify-center",
				style: normalizeStyle({
					width: __props.size + "px",
					height: __props.size + "px"
				})
			}, [(openBlock(), createElementBlock("svg", {
				xmlns: "http://www.w3.org/2000/svg",
				width: __props.size,
				height: __props.size,
				viewBox: "0 0 14 14",
				class: "animate-spin fill-foreground",
				style: normalizeStyle({ animationDuration: __props.duration })
			}, [..._cache[0] || (_cache[0] = [createStaticVNode("<g clip-path=\"url(#clip0_776_9582)\" data-v-8e668792><path class=\"dot-animation\" style=\"animation-delay:0s;\" fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M7 2.21053C7.61042 2.21053 8.10526 1.71568 8.10526 1.10526C8.10526 0.494843 7.61042 0 7 0C6.38958 0 5.89474 0.494843 5.89474 1.10526C5.89474 1.71568 6.38958 2.21053 7 2.21053Z\" data-v-8e668792></path><path class=\"dot-animation\" style=\"animation-delay:0.25s;\" fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M2.21053 7C2.21053 7.61042 1.71568 8.10526 1.10526 8.10526C0.494843 8.10526 0 7.61042 0 7C0 6.38958 0.494843 5.89474 1.10526 5.89474C1.71568 5.89474 2.21053 6.38958 2.21053 7Z\" data-v-8e668792></path><path class=\"dot-animation\" style=\"animation-delay:0.5s;\" fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M14 7C14 7.61042 13.5052 8.10526 12.8947 8.10526C12.2843 8.10526 11.7895 7.61042 11.7895 7C11.7895 6.38958 12.2843 5.89474 12.8947 5.89474C13.5052 5.89474 14 6.38958 14 7Z\" data-v-8e668792></path><path class=\"dot-animation\" style=\"animation-delay:0.75s;\" fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M8.10526 12.8947C8.10526 13.5052 7.61041 14 6.99999 14C6.38957 14 5.89473 13.5052 5.89473 12.8947C5.89473 12.2843 6.38957 11.7895 6.99999 11.7895C7.61041 11.7895 8.10526 12.2843 8.10526 12.8947Z\" data-v-8e668792></path><path class=\"dot-animation\" style=\"animation-delay:0.125s;\" fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M2.05039 3.61349C2.48203 4.04513 3.18184 4.04513 3.61347 3.61349C4.0451 3.18186 4.0451 2.48205 3.61347 2.05042C3.18184 1.61878 2.48203 1.61878 2.05039 2.05042C1.61876 2.48205 1.61876 3.18186 2.05039 3.61349Z\" data-v-8e668792></path><path class=\"dot-animation\" style=\"animation-delay:0.625s;\" fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M11.9496 11.9496C11.518 12.3812 10.8182 12.3812 10.3865 11.9496C9.9549 11.5179 9.9549 10.8181 10.3865 10.3865C10.8182 9.95485 11.518 9.95485 11.9496 10.3865C12.3812 10.8181 12.3812 11.5179 11.9496 11.9496Z\" data-v-8e668792></path><path class=\"dot-animation\" style=\"animation-delay:0.875s;\" fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M2.05039 11.9496C2.48203 12.3812 3.18184 12.3812 3.61347 11.9496C4.0451 11.5179 4.0451 10.8181 3.61347 10.3865C3.18184 9.95485 2.48203 9.95485 2.05039 10.3865C1.61876 10.8181 1.61876 11.5179 2.05039 11.9496Z\" data-v-8e668792></path><path class=\"dot-animation\" style=\"animation-delay:0.375s;\" fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M11.9496 3.61349C11.518 4.04513 10.8182 4.04513 10.3865 3.61349C9.9549 3.18186 9.9549 2.48205 10.3865 2.05042C10.8182 1.61878 11.518 1.61878 11.9496 2.05042C12.3812 2.48205 12.3812 3.18186 11.9496 3.61349Z\" data-v-8e668792></path></g><defs data-v-8e668792><clipPath id=\"clip0_776_9582\" data-v-8e668792><rect width=\"14\" height=\"14\" fill=\"white\" data-v-8e668792></rect></clipPath></defs>", 2)])], 12, _hoisted_1$1))], 4);
		};
	}
}), [["__scopeId", "data-v-8e668792"]]);
//#endregion
//#region src/components/common/AppSpinner.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = {
	key: 0,
	class: "inline-flex items-center gap-2"
};
var _hoisted_2 = { "aria-hidden": "true" };
//#endregion
//#region src/components/common/AppSpinner.vue
var AppSpinner_default = /* @__PURE__ */ defineComponent({
	inheritAttrs: false,
	__name: "AppSpinner",
	props: {
		label: {
			type: Boolean,
			default: false
		},
		variant: { default: "ring" },
		class: {
			type: [
				Boolean,
				null,
				String,
				Object,
				Array
			],
			default: ""
		}
	},
	setup(__props) {
		const { t } = useI18n();
		return (_ctx, _cache) => {
			return __props.label ? (openBlock(), createElementBlock("span", _hoisted_1, [(openBlock(), createBlock(resolveDynamicComponent(__props.variant === "ring" ? Spinner_default : DotSpinner_default), mergeProps(_ctx.$attrs, {
				role: "progressbar",
				"aria-label": unref(t)("g.loading"),
				class: __props.class
			}), null, 16, ["aria-label", "class"])), createBaseVNode("span", _hoisted_2, toDisplayString(unref(t)("g.loading")), 1)])) : (openBlock(), createBlock(resolveDynamicComponent(__props.variant === "ring" ? Spinner_default : DotSpinner_default), mergeProps({ key: 1 }, _ctx.$attrs, {
				role: "progressbar",
				"aria-label": unref(t)("g.loading"),
				class: __props.class
			}), null, 16, ["aria-label", "class"]));
		};
	}
});
//#endregion
export { DotSpinner_default as n, AppSpinner_default as t };
