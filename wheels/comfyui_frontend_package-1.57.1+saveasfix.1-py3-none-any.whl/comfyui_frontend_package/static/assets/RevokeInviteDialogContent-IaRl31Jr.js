import "./rolldown-runtime-xtsTai4I.js";
import { t as useBillingContext } from "./useBillingContext-Cc-YANxo.js";
import { t as useTeamWorkspaceStore } from "./teamWorkspaceStore-BNm5cZOK.js";
import { F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, I as createBlock, U as createVNode, Yt as toDisplayString, ct as openBlock, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as useToast } from "./toastStore-Dg65fRgL.js";
import { t as getErrorMessage } from "./errorUtil-DoQyAUQC.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
import { t as AppDialogPanel_default } from "./AppDialogPanel-BklaJBTn.js";
//#region src/platform/workspace/components/dialogs/RevokeInviteDialogContent.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "m-0 text-sm text-muted-foreground" };
//#endregion
//#region src/platform/workspace/components/dialogs/RevokeInviteDialogContent.vue
var RevokeInviteDialogContent_default = /* @__PURE__ */ defineComponent({
	__name: "RevokeInviteDialogContent",
	props: { inviteId: {} },
	setup(__props) {
		const dialogStore = useDialogStore();
		const workspaceStore = useTeamWorkspaceStore();
		const { fetchStatus } = useBillingContext();
		const toast = useToast();
		const { t } = useI18n();
		const loading = ref(false);
		function onCancel() {
			dialogStore.closeDialog({ key: "revoke-invite" });
		}
		async function onRevoke() {
			loading.value = true;
			try {
				await workspaceStore.revokeInvite(__props.inviteId);
				fetchStatus().catch(console.error);
				dialogStore.closeDialog({ key: "revoke-invite" });
			} catch (error) {
				toast.error(t("g.error"), { description: getErrorMessage(error) });
			} finally {
				loading.value = false;
			}
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(AppDialogPanel_default, {
				size: "compact",
				onClose: onCancel
			}, {
				title: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.revokeInviteDialog.title")), 1)]),
				footer: withCtx(() => [createVNode(Button_default, {
					variant: "muted-textonly",
					onClick: onCancel
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("g.cancel")), 1)]),
					_: 1
				}), createVNode(Button_default, {
					variant: "destructive",
					size: "lg",
					loading: loading.value,
					onClick: onRevoke
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.revokeInviteDialog.revoke")), 1)]),
					_: 1
				}, 8, ["loading"])]),
				default: withCtx(() => [createBaseVNode("p", _hoisted_1, toDisplayString(_ctx.$t("workspacePanel.revokeInviteDialog.message")), 1)]),
				_: 1
			});
		};
	}
});
//#endregion
export { RevokeInviteDialogContent_default as default };
