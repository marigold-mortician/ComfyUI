import "./rolldown-runtime-xtsTai4I.js";
import { t as useTeamWorkspaceStore } from "./teamWorkspaceStore-BNm5cZOK.js";
import { C as vModelText, F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, I as createBlock, P as computed, T as withKeys, Tt as withDirectives, U as createVNode, Yt as toDisplayString, ct as openBlock, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { t as Button_default } from "./Button-CcqmlVQb.js";
import { t as useToast } from "./toastStore-Dg65fRgL.js";
import { t as getErrorMessage } from "./errorUtil-DoQyAUQC.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
import { t as AppDialogPanel_default } from "./AppDialogPanel-BklaJBTn.js";
//#region src/platform/workspace/components/dialogs/EditWorkspaceDialogContent.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "flex flex-col gap-2 text-sm" };
//#endregion
//#region src/platform/workspace/components/dialogs/EditWorkspaceDialogContent.vue
var EditWorkspaceDialogContent_default = /* @__PURE__ */ defineComponent({
	__name: "EditWorkspaceDialogContent",
	setup(__props) {
		const { t } = useI18n();
		const toast = useToast();
		const dialogStore = useDialogStore();
		const workspaceStore = useTeamWorkspaceStore();
		const loading = ref(false);
		const newWorkspaceName = ref(workspaceStore.workspaceName);
		const isValidName = computed(() => {
			const name = newWorkspaceName.value.trim();
			return name.length >= 1 && name.length <= 50 && /^[a-zA-Z0-9][a-zA-Z0-9\s\-_'.,()&+]*$/.test(name);
		});
		function onCancel() {
			dialogStore.closeDialog({ key: "edit-workspace" });
		}
		async function onSave() {
			if (!isValidName.value) return;
			loading.value = true;
			try {
				await workspaceStore.updateWorkspaceName(newWorkspaceName.value.trim());
				dialogStore.closeDialog({ key: "edit-workspace" });
				toast.success(t("workspacePanel.toast.workspaceUpdated.title"), {
					description: t("workspacePanel.toast.workspaceUpdated.message"),
					duration: 5e3
				});
			} catch (error) {
				console.error("[EditWorkspaceDialog] Failed to update workspace:", error);
				toast.error(t("workspacePanel.toast.failedToUpdateWorkspace"), { description: getErrorMessage(error) ?? t("g.unknownError") });
			} finally {
				loading.value = false;
			}
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(AppDialogPanel_default, {
				"body-class": "flex flex-col gap-4",
				class: "max-w-none min-w-100",
				onClose: onCancel
			}, {
				title: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.editWorkspaceDialog.title")), 1)]),
				footer: withCtx(() => [createVNode(Button_default, {
					variant: "muted-textonly",
					onClick: onCancel
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("g.cancel")), 1)]),
					_: 1
				}), createVNode(Button_default, {
					variant: "primary",
					size: "lg",
					loading: loading.value,
					disabled: !isValidName.value,
					onClick: onSave
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("workspacePanel.editWorkspaceDialog.save")), 1)]),
					_: 1
				}, 8, ["loading", "disabled"])]),
				default: withCtx(() => [createBaseVNode("div", _hoisted_1, [createBaseVNode("label", null, toDisplayString(_ctx.$t("workspacePanel.editWorkspaceDialog.nameLabel")), 1), withDirectives(createBaseVNode("input", {
					"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => newWorkspaceName.value = $event),
					type: "text",
					class: "w-full rounded-lg border bg-transparent px-3 py-2 placeholder:text-muted-foreground focus:ring-1 focus:ring-ring focus:outline-none",
					onKeydown: _cache[1] || (_cache[1] = withKeys(($event) => isValidName.value && onSave(), ["enter"]))
				}, null, 544), [[vModelText, newWorkspaceName.value]])])]),
				_: 1
			});
		};
	}
});
//#endregion
export { EditWorkspaceDialogContent_default as default };
