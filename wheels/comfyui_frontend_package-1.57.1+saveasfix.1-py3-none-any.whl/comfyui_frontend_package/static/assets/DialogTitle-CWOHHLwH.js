import "./rolldown-runtime-xtsTai4I.js";
import { G as defineComponent, I as createBlock, Kt as normalizeClass, Wt as unref, ct as openBlock, dt as renderSlot, wt as withCtx } from "./vendor-vue-core-CuN1excl.js";
import { Dn as injectDialogRootContext, jn as Primitive } from "./vendor-reka-ui-NRTk7aIV.js";
import { t as cn } from "./src-BHQtMnZc.js";
//#endregion
//#region src/components/ui/dialog/DialogTitle.vue
var DialogTitle_default = /* @__PURE__ */ defineComponent({
	__name: "DialogTitle",
	props: {
		asChild: { type: Boolean },
		as: { default: "h2" },
		class: {
			type: [
				Boolean,
				null,
				String,
				Object,
				Array
			],
			default: ""
		}
	},
	setup(__props) {
		const dialogRoot = injectDialogRootContext(null);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(Primitive), {
				id: unref(dialogRoot)?.titleId,
				as: __props.as,
				"as-child": __props.asChild,
				class: normalizeClass(unref(cn)("min-w-0 text-base font-semibold wrap-break-word text-foreground", __props.class))
			}, {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
				_: 3
			}, 8, [
				"id",
				"as",
				"as-child",
				"class"
			]);
		};
	}
});
//#endregion
export { DialogTitle_default as t };
