import { t as WidgetTextPreview_default } from "./WidgetTextPreview-CZWTA62G.js";
export { WidgetTextPreview_default as default };
