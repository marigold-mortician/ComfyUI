import "./rolldown-runtime-xtsTai4I.js";
import { Ln as partition, jt as zeroUuid } from "./litegraph-CgrqhFEE.js";
import { o as groupBy } from "./commandStore-XD_i1hej.js";
import { n as useSettingStore } from "./settingStore-DRRi2kOn.js";
import { A as isValueStillOutOfRange, D as isImageNotLoadedValidationError, E as hasErrorForSlot, O as isMissingNodePromptError, S as SIMPLE_ERROR_TYPES, T as getInputConfigBounds, k as isNodeLevelValidationError, n as useDialogService, w as errorsForSlot } from "./dialogService-CqZr0BhP.js";
import { Ft as ref, It as shallowReactive, P as computed, bt as watch, d as defineStore, zt as toRaw } from "./vendor-vue-core-CuN1excl.js";
import { Xr as whenever } from "./vendor-reka-ui-NRTk7aIV.js";
import { c as ChangeTrackerAccess, n as useWorkflowStore } from "./workflowStore-DP6mciq-.js";
import { n as useApp } from "./appInstance-CiT6CpGM.js";
import { t as useToast } from "./toastStore-Dg65fRgL.js";
import { d as t, l as st } from "./i18n-BRluoVl-.js";
import { J as tryNormalizeNodeExecutionId, L as isSubgraph, U as getAncestorExecutionIds, W as getParentExecutionIds, d as getActiveGraphNodeIds, g as getNodeByExecutionId, i as executionIdToNodeLocatorId, l as forEachNode, p as getExecutionIdByNode } from "./graphTraversalUtil-BUK1cr2m.js";
import { n as useCanvasStore } from "./canvasStore-Dnz7OWvY.js";
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/uniqBy.mjs
/**
* Returns a new array containing only the unique elements from the original array,
* based on the values returned by the mapper function.
*
* When duplicates are found, the first occurrence is kept and the rest are discarded.
*
* @template T - The type of elements in the array.
* @template U - The type of mapped elements.
* @param arr - The array to process.
* @param mapper - The function used to convert the array elements.
* @returns A new array containing only the unique elements from the original array, based on the values returned by the mapper function.
*
* @example
* ```ts
* uniqBy([1.2, 1.5, 2.1, 3.2, 5.7, 5.3, 7.19], Math.floor);
* // [1.2, 2.1, 3.2, 5.7, 7.19]
* ```
*
* @example
* const array = [
*   { category: 'fruit', name: 'apple' },
*   { category: 'fruit', name: 'banana' },
*   { category: 'vegetable', name: 'carrot' },
* ];
* uniqBy(array, item => item.category).length
* // 2
* ```
*/
function uniqBy(arr, mapper) {
	const map = /* @__PURE__ */ new Map();
	for (let i = 0; i < arr.length; i++) {
		const item = arr[i];
		const key = mapper(item, i, arr);
		if (!map.has(key)) map.set(key, item);
	}
	return Array.from(map.values());
}
//#endregion
//#region src/core/graph/subgraph/liftNodeErrorsToBoundary.ts
function getLiftedErrorSource(error) {
	const extraInfo = error.extra_info;
	if (!extraInfo) return null;
	const { input_name, source_execution_id, source_input_name } = extraInfo;
	if (typeof input_name !== "string" || typeof source_execution_id !== "string" || typeof source_input_name !== "string") return null;
	return {
		input_name,
		source_execution_id,
		source_input_name
	};
}
function getHostExecutionId(executionId) {
	const separatorIndex = executionId.lastIndexOf(":");
	if (separatorIndex <= 0) return null;
	return tryNormalizeNodeExecutionId(executionId.slice(0, separatorIndex));
}
/**
* Boundary surfaces that expose `(executionId, inputName)`, innermost first.
* Walks one host per level and stops at the last resolvable surface, so an
* unresolvable deeper host falls back to the shallower one (fail-open).
*/
function resolveLiftChain(rootGraph, executionId, inputName) {
	const chain = [];
	let currentExecId = executionId;
	let currentInputName = inputName;
	for (;;) {
		const node = getNodeByExecutionId(rootGraph, currentExecId);
		const graph = node?.graph;
		if (!node || !graph || !isSubgraph(graph)) break;
		const slot = node.inputs.find((input) => input.name === currentInputName);
		if (slot?.link == null) break;
		const subgraphInput = graph.getLink(slot.link)?.resolve(graph).subgraphInput;
		if (!subgraphInput) break;
		const hostExecId = getHostExecutionId(currentExecId);
		if (!hostExecId || !getNodeByExecutionId(rootGraph, hostExecId)) break;
		chain.push({
			hostExecId,
			hostInputName: subgraphInput.name
		});
		currentExecId = hostExecId;
		currentInputName = subgraphInput.name;
	}
	return chain;
}
function createEmptyNodeError(nodeError) {
	return {
		...nodeError,
		errors: []
	};
}
function createLiftedHostEntry(rootGraph, hostExecId) {
	return {
		class_type: getNodeByExecutionId(rootGraph, hostExecId)?.title ?? hostExecId,
		dependent_outputs: [],
		errors: []
	};
}
function toErrorPlacement(rootGraph, executionId, error) {
	const inputName = error.extra_info?.input_name;
	const surface = inputName && !isNodeLevelValidationError(error) ? resolveLiftChain(rootGraph, executionId, inputName).at(-1) : void 0;
	if (!inputName || !surface) return {
		kind: "own",
		targetExecId: executionId,
		error
	};
	const liftedExtraInfo = {
		input_name: surface.hostInputName,
		source_execution_id: executionId,
		source_input_name: inputName
	};
	return {
		kind: "lifted",
		targetExecId: surface.hostExecId,
		error: {
			...error,
			extra_info: {
				...error.extra_info,
				...liftedExtraInfo
			}
		}
	};
}
function liftNodeErrorsToBoundary(rootGraph, nodeErrors) {
	const output = {};
	const placements = Object.entries(nodeErrors).flatMap(([executionId, nodeError]) => nodeError.errors.map((error) => toErrorPlacement(rootGraph, executionId, error)));
	for (const [executionId, nodeError] of Object.entries(nodeErrors)) if (nodeError.errors.length === 0) output[executionId] = createEmptyNodeError(nodeError);
	const placementsByTarget = groupBy(placements, (placement) => placement.targetExecId);
	for (const [targetExecId, targetPlacements] of Object.entries(placementsByTarget)) {
		const existingEntry = Object.hasOwn(nodeErrors, targetExecId) ? nodeErrors[targetExecId] : void 0;
		const baseEntry = existingEntry ? createEmptyNodeError(existingEntry) : createLiftedHostEntry(rootGraph, targetExecId);
		const [ownErrors, liftedErrors] = partition(targetPlacements, (placement) => placement.kind === "own");
		output[targetExecId] = {
			...baseEntry,
			errors: [...ownErrors, ...liftedErrors].map((placement) => placement.error)
		};
	}
	return output;
}
//#endregion
//#region src/utils/missingResourceAbsorption.ts
function normalizePath(value) {
	return value.replace(/[\\/]+/g, "/").replace(/\/+$/, "");
}
function matchesReceivedValue(receivedValue, candidateName) {
	if (receivedValue == null) return false;
	return normalizePath(String(receivedValue)) === normalizePath(candidateName);
}
function isEligibleValidationError(error) {
	return error.type === "value_not_in_list" || isImageNotLoadedValidationError(error);
}
function matchesErrorNodeId(candidateNodeIds, liftedSource, nodeId) {
	const errorNodeIds = [nodeId, liftedSource?.source_execution_id].filter((id) => id != null).map(String);
	return candidateNodeIds.some((candidateId) => candidateId != null && errorNodeIds.includes(String(candidateId)));
}
function matchesErrorInputName(candidateNodeIds, candidateInputName, errorInputName, liftedSource) {
	if (candidateInputName === errorInputName) return true;
	if (!liftedSource) return false;
	return candidateInputName === liftedSource.source_input_name && candidateNodeIds.some((id) => id != null && String(id) === liftedSource.source_execution_id);
}
function matchesPromotedSource(source, error, nodeId) {
	if (String(source.executionId) !== String(nodeId)) return false;
	return source.widgetName === error.extra_info?.input_name;
}
function matchesCandidate(candidateNodeIds, candidateInputName, candidateName, isMissing, error, nodeId, promotedSources = []) {
	if (isMissing !== true) return false;
	if (promotedSources.some((source) => matchesPromotedSource(source, error, nodeId))) return true;
	const liftedSource = getLiftedErrorSource(error);
	if (!matchesErrorNodeId(candidateNodeIds, liftedSource, nodeId)) return false;
	if (matchesErrorInputName(candidateNodeIds, candidateInputName, error.extra_info?.input_name, liftedSource)) return true;
	if (error.extra_info?.input_name != null) return false;
	return matchesReceivedValue(error.extra_info?.received_value, candidateName);
}
function matchesMissingModel(candidate, error, nodeId) {
	return matchesCandidate([candidate.sourceExecutionId, candidate.nodeId], candidate.widgetName, candidate.name, candidate.isMissing, error, nodeId, candidate.promotedSources);
}
function matchesMissingMedia(candidate, error, nodeId) {
	return matchesCandidate([candidate.nodeId], candidate.widgetName, candidate.name, candidate.isMissing, error, nodeId, candidate.promotedSources);
}
function classifyValidationErrorAbsorption(missingModels, missingMedia, error, nodeId) {
	if (!isEligibleValidationError(error)) return null;
	if (missingModels?.some((candidate) => matchesMissingModel(candidate, error, nodeId))) return "missing_model";
	if (missingMedia?.some((candidate) => matchesMissingMedia(candidate, error, nodeId))) return "missing_media";
	return null;
}
function isMissingNodePromptErrorAbsorbed(promptError, hasMissingNodes) {
	return isMissingNodePromptError(promptError) && hasMissingNodes;
}
//#endregion
//#region src/utils/errorSeverityClassification.ts
function classifyPanelErrors(input) {
	const promptError = input.promptError ? {
		error: input.promptError,
		isAbsorbed: isMissingNodePromptErrorAbsorbed(input.promptError, input.hasMissingNodes)
	} : null;
	const executionNodeId = input.executionError?.node_id;
	const rawExecutionNodeId = executionNodeId == null ? void 0 : String(executionNodeId);
	const executionError = input.executionError ? {
		error: input.executionError,
		rawNodeId: rawExecutionNodeId,
		nodeId: rawExecutionNodeId === void 0 ? null : tryNormalizeNodeExecutionId(rawExecutionNodeId)
	} : null;
	const nodeErrors = Object.entries(input.nodeErrors ?? {}).map(([rawNodeId, nodeError]) => {
		const nodeId = tryNormalizeNodeExecutionId(rawNodeId);
		return {
			rawNodeId,
			nodeId,
			nodeError,
			errors: nodeError.errors.map((error) => ({
				error,
				absorption: nodeId ? classifyValidationErrorAbsorption(input.missingModels, input.missingMedia, error, nodeId) : null
			}))
		};
	});
	const hasBlockingNodeError = nodeErrors.some(({ errors }) => errors.some(({ absorption }) => !absorption));
	return {
		promptError,
		executionError,
		nodeErrors,
		hasBlockingError: promptError !== null && !promptError.isAbsorbed || executionError !== null || hasBlockingNodeError
	};
}
//#endregion
//#region src/composables/graph/useNodeErrorFlagSync.ts
function setNodeHasErrors(node, hasErrors) {
	if (node.has_errors === hasErrors) return;
	const oldValue = node.has_errors;
	node.has_errors = hasErrors;
	node.graph?.trigger("node:property:changed", {
		type: "node:property:changed",
		nodeId: node.id,
		property: "has_errors",
		oldValue,
		newValue: hasErrors
	});
}
/**
* Single-pass reconciliation of node error flags.
* Collects the set of nodes that should have errors, then walks all nodes
* once, setting each flag exactly once. This avoids the redundant
* true→false→true transition (and duplicate events) that a clear-then-apply
* approach would cause.
*/
function reconcileNodeErrorFlags(rootGraph, nodeErrors, missingModelExecIds, missingMediaExecIds = /* @__PURE__ */ new Set(), missingNodeExecIds = /* @__PURE__ */ new Set()) {
	const flaggedNodes = /* @__PURE__ */ new Set();
	const errorsByNode = /* @__PURE__ */ new Map();
	if (nodeErrors) for (const [executionId, nodeError] of Object.entries(nodeErrors)) {
		const node = getNodeByExecutionId(rootGraph, executionId);
		if (!node) continue;
		flaggedNodes.add(node);
		errorsByNode.set(node, [...errorsByNode.get(node) ?? [], ...nodeError.errors]);
		for (const parentId of getParentExecutionIds(executionId)) {
			const parentNode = getNodeByExecutionId(rootGraph, parentId);
			if (parentNode) flaggedNodes.add(parentNode);
		}
	}
	for (const execId of missingModelExecIds) {
		const node = getNodeByExecutionId(rootGraph, execId);
		if (node) flaggedNodes.add(node);
	}
	for (const execId of missingMediaExecIds) {
		const node = getNodeByExecutionId(rootGraph, execId);
		if (node) flaggedNodes.add(node);
	}
	for (const execId of missingNodeExecIds) {
		const node = getNodeByExecutionId(rootGraph, execId);
		if (node) flaggedNodes.add(node);
	}
	forEachNode(rootGraph, (node) => {
		setNodeHasErrors(node, flaggedNodes.has(node));
		const ownErrors = errorsByNode.get(node);
		for (const slot of node.inputs) slot.hasErrors = !!slot.name && !!ownErrors && hasErrorForSlot(ownErrors, slot.name);
	});
}
function useNodeErrorFlagSync(nodeErrors, missingModelStore, missingMediaStore, missingNodesStore) {
	const settingStore = useSettingStore();
	const showErrorsTab = computed(() => settingStore.get("Comfy.RightSidePanel.ShowErrorsTab"));
	return watch([
		nodeErrors,
		() => missingModelStore.missingModelNodeIds,
		() => missingMediaStore.missingMediaNodeIds,
		() => missingNodesStore.missingAncestorExecutionIds,
		showErrorsTab
	], () => {
		const rootGraph = useApp().rootGraphOrUndefined;
		if (!rootGraph) return;
		reconcileNodeErrorFlags(rootGraph, nodeErrors.value, showErrorsTab.value ? missingModelStore.missingModelAncestorExecutionIds : /* @__PURE__ */ new Set(), showErrorsTab.value ? missingMediaStore.missingMediaAncestorExecutionIds : /* @__PURE__ */ new Set(), missingNodesStore.missingAncestorExecutionIds);
	}, { flush: "post" });
}
//#endregion
//#region src/platform/settings/missingWarningVisibility.ts
var MISSING_WARNING_SETTING_IDS = {
	nodes: "Comfy.Workflow.ShowMissingNodesWarning",
	models: "Comfy.ErrorSystem.ShowMissingModels",
	media: "Comfy.Workflow.ShowMissingMediaWarning"
};
/** A setting that is not registered yet reads as enabled. */
function enabledByDefault(value) {
	return value ?? true;
}
function isEnabled(id) {
	return enabledByDefault(useSettingStore().get(id));
}
function isIssuesTabEnabled() {
	return isEnabled("Comfy.RightSidePanel.ShowErrorsTab");
}
function isMissingWarningVisible(kind) {
	return isEnabled(MISSING_WARNING_SETTING_IDS[kind]);
}
//#endregion
//#region src/platform/workflowErrors/missingModel/missingModelStore.ts
/**
* Missing model error state and interaction state.
* Separated from executionErrorStore to keep domain boundaries clean.
* The executionErrorStore composes from this store for aggregate error flags.
*/
var useMissingModelStore = defineStore("missingModel", () => {
	const canvasStore = useCanvasStore();
	const workflowStore = useWorkflowStore();
	const missingModelCandidates = ref(null);
	const isRefreshingMissingModels = ref(false);
	/** Candidates to display; `null` while the missing models warning is off. */
	const visibleMissingModelCandidates = computed(() => isMissingWarningVisible("models") ? missingModelCandidates.value : null);
	const hasMissingModels = computed(() => !!visibleMissingModelCandidates.value?.length);
	const missingModelCount = computed(() => visibleMissingModelCandidates.value?.length ?? 0);
	const missingModelNodeIds = computed(() => {
		const ids = /* @__PURE__ */ new Set();
		if (!visibleMissingModelCandidates.value) return ids;
		for (const m of visibleMissingModelCandidates.value) {
			if (m.nodeId != null) ids.add(String(m.nodeId));
			if (m.sourceExecutionId != null) ids.add(String(m.sourceExecutionId));
		}
		return ids;
	});
	const missingModelWidgetKeys = computed(() => {
		const keys = /* @__PURE__ */ new Set();
		if (!visibleMissingModelCandidates.value) return keys;
		for (const m of visibleMissingModelCandidates.value) keys.add(`${String(m.nodeId)}::${m.widgetName}`);
		return keys;
	});
	/**
	* Set of all execution ID prefixes derived from missing model node IDs,
	* including the missing model nodes themselves.
	*
	* Example: missing model on node "65:70:63" → Set { "65", "65:70", "65:70:63" }
	*/
	const missingModelAncestorExecutionIds = computed(() => {
		const ids = /* @__PURE__ */ new Set();
		for (const nodeId of missingModelNodeIds.value) for (const id of getAncestorExecutionIds(nodeId)) ids.add(id);
		return ids;
	});
	const activeMissingModelGraphIds = computed(() => {
		const rootGraph = useApp().rootGraphOrUndefined;
		if (!rootGraph) return /* @__PURE__ */ new Set();
		return getActiveGraphNodeIds(rootGraph, canvasStore.currentGraph ?? rootGraph, missingModelAncestorExecutionIds.value);
	});
	const modelExpandState = ref({});
	const selectedLibraryModel = ref({});
	const importTaskIds = ref({});
	const folderPaths = ref({});
	const fileSizes = ref({});
	const gatedRepoUrls = ref({});
	let _verificationAbortController = null;
	function createVerificationAbortController() {
		_verificationAbortController?.abort();
		_verificationAbortController = new AbortController();
		return _verificationAbortController;
	}
	function setMissingModels(models) {
		missingModelCandidates.value = models.length ? models : null;
	}
	function removeMissingModelByNameOnNodes(modelName, nodeIds) {
		if (!missingModelCandidates.value) return;
		missingModelCandidates.value = missingModelCandidates.value.filter((m) => m.name !== modelName || m.nodeId == null || !nodeIds.has(String(m.nodeId)));
		if (!missingModelCandidates.value.length) missingModelCandidates.value = null;
	}
	function removeMissingModelByWidget(nodeId, widgetName) {
		if (!missingModelCandidates.value) return;
		missingModelCandidates.value = missingModelCandidates.value.filter((m) => !(String(m.nodeId) === nodeId && m.widgetName === widgetName));
		if (!missingModelCandidates.value.length) missingModelCandidates.value = null;
	}
	function clearInteractionStateForName(name) {
		delete modelExpandState.value[name];
		delete selectedLibraryModel.value[name];
		delete importTaskIds.value[name];
	}
	function removeMissingModelsByNodeId(nodeId) {
		if (!missingModelCandidates.value) return;
		const removedNames = new Set(missingModelCandidates.value.filter((m) => String(m.nodeId) === nodeId).map((m) => m.name));
		missingModelCandidates.value = missingModelCandidates.value.filter((m) => String(m.nodeId) !== nodeId);
		for (const name of removedNames) if (!missingModelCandidates.value.some((m) => m.name === name)) clearInteractionStateForName(name);
		if (!missingModelCandidates.value.length) missingModelCandidates.value = null;
	}
	/**
	* Remove all candidates whose nodeId starts with `prefix`.
	*
	* Intended for clearing all interior errors when a subgraph container is
	* removed. Callers are expected to pass `${execId}:` (with trailing
	* colon) so that sibling IDs sharing a numeric prefix (e.g. `"705"` vs
	* `"70"`) are not matched.
	*/
	function removeMissingModelsByPrefix(prefix) {
		if (!missingModelCandidates.value) return;
		const removedNames = /* @__PURE__ */ new Set();
		const remaining = [];
		for (const m of missingModelCandidates.value) {
			if (m.nodeId == null) {
				remaining.push(m);
				continue;
			}
			if (String(m.nodeId).startsWith(prefix)) removedNames.add(m.name);
			else remaining.push(m);
		}
		if (removedNames.size === 0) return;
		missingModelCandidates.value = remaining.length ? remaining : null;
		for (const name of removedNames) if (!remaining.some((m) => m.name === name)) clearInteractionStateForName(name);
	}
	function removeMissingModelsBySourceScope(executionId) {
		if (!missingModelCandidates.value) return;
		const prefix = `${executionId}:`;
		const removedNames = /* @__PURE__ */ new Set();
		const remaining = [];
		for (const candidate of missingModelCandidates.value) {
			const sourceExecutionId = candidate.sourceExecutionId == null ? void 0 : String(candidate.sourceExecutionId);
			if (sourceExecutionId === executionId || sourceExecutionId?.startsWith(prefix)) removedNames.add(candidate.name);
			else remaining.push(candidate);
		}
		if (removedNames.size === 0) return;
		missingModelCandidates.value = remaining.length ? remaining : null;
		for (const name of removedNames) if (!remaining.some((candidate) => candidate.name === name)) clearInteractionStateForName(name);
	}
	function addMissingModels(models) {
		if (!models.length) return;
		const existing = missingModelCandidates.value ?? [];
		const existingKeys = new Set(existing.map((m) => `${String(m.nodeId)}::${m.widgetName}::${m.name}`));
		const newModels = models.filter((m) => !existingKeys.has(`${String(m.nodeId)}::${m.widgetName}::${m.name}`));
		if (!newModels.length) return;
		missingModelCandidates.value = [...existing, ...newModels];
	}
	function hasMissingModelOnNode(nodeLocatorId) {
		const executionId = workflowStore.nodeLocatorIdToNodeExecutionId(nodeLocatorId);
		return executionId ? missingModelNodeIds.value.has(executionId) : false;
	}
	function isWidgetMissingModel(nodeId, widgetName) {
		return missingModelWidgetKeys.value.has(`${nodeId}::${widgetName}`);
	}
	function isContainerWithMissingModel(node) {
		return activeMissingModelGraphIds.value.has(String(node.id));
	}
	function setFolderPaths(paths) {
		folderPaths.value = paths;
	}
	function setFileSize(url, size) {
		fileSizes.value[url] = size;
	}
	function setGatedRepoUrl(url, repoUrl) {
		gatedRepoUrls.value[url] = repoUrl;
	}
	function clearMissingModels() {
		_verificationAbortController?.abort();
		_verificationAbortController = null;
		missingModelCandidates.value = null;
		modelExpandState.value = {};
		selectedLibraryModel.value = {};
		importTaskIds.value = {};
		folderPaths.value = {};
		fileSizes.value = {};
		gatedRepoUrls.value = {};
	}
	function isAbortError(error) {
		return error instanceof Error && error.name === "AbortError";
	}
	async function refreshMissingModels(options = {}) {
		if (isRefreshingMissingModels.value) return;
		isRefreshingMissingModels.value = true;
		try {
			await useApp().refreshMissingModels({
				silent: true,
				reloadDefs: options.reloadDefs
			});
		} catch (error) {
			if (isAbortError(error)) return;
			console.error("Failed to refresh missing models:", error);
			useToast().error(t("g.error"), { description: t("rightSidePanel.missingModels.refreshFailed") });
		} finally {
			isRefreshingMissingModels.value = false;
		}
	}
	return {
		missingModelCandidates,
		visibleMissingModelCandidates,
		isRefreshingMissingModels,
		hasMissingModels,
		missingModelCount,
		missingModelNodeIds,
		activeMissingModelGraphIds,
		missingModelAncestorExecutionIds,
		setMissingModels,
		addMissingModels,
		removeMissingModelByNameOnNodes,
		removeMissingModelByWidget,
		removeMissingModelsByNodeId,
		removeMissingModelsByPrefix,
		removeMissingModelsBySourceScope,
		clearMissingModels,
		refreshMissingModels,
		createVerificationAbortController,
		hasMissingModelOnNode,
		isWidgetMissingModel,
		isContainerWithMissingModel,
		modelExpandState,
		selectedLibraryModel,
		importTaskIds,
		folderPaths,
		fileSizes,
		gatedRepoUrls,
		setFolderPaths,
		setFileSize,
		setGatedRepoUrl
	};
});
//#endregion
//#region src/platform/workflow/templates/stores/templateInputDownloadStore.ts
function normalizeProgress(progress) {
	return Number.isFinite(progress) && progress >= 0 && progress <= 1 ? progress : null;
}
var useTemplateInputDownloadStore = defineStore("templateInputDownload", () => {
	const downloadsById = shallowReactive(/* @__PURE__ */ new Map());
	const previewRevisions = shallowReactive(/* @__PURE__ */ new Map());
	const completedIds = /* @__PURE__ */ new Set();
	const downloads = computed(() => [...downloadsById.values()]);
	const blockingFilenames = computed(() => new Set(downloads.value.map(({ filename }) => filename)));
	function updateProgress(progress) {
		const { downloadId, filename, status } = progress;
		if (status === "error" || status === "cancelled") {
			downloadsById.delete(downloadId);
			return;
		}
		if (completedIds.has(downloadId)) return;
		if (status === "completed") {
			completedIds.add(downloadId);
			previewRevisions.set(filename, (previewRevisions.get(filename) ?? 0) + 1);
		}
		downloadsById.set(downloadId, {
			downloadId,
			filename,
			progress: normalizeProgress(progress.progress),
			status
		});
	}
	function completeGraphSync(filenames) {
		const completed = new Set(filenames);
		for (const [downloadId, download] of downloadsById) if (download.status === "completed" && completed.has(download.filename)) downloadsById.delete(downloadId);
	}
	function previewRevision(filename) {
		return previewRevisions.get(filename) ?? 0;
	}
	function clear() {
		downloadsById.clear();
		previewRevisions.clear();
		completedIds.clear();
	}
	return {
		downloads,
		blockingFilenames,
		updateProgress,
		completeGraphSync,
		previewRevision,
		clear
	};
});
//#endregion
//#region src/platform/workflowErrors/missingMedia/missingMediaStore.ts
/**
* Missing media error state.
* Separated from executionErrorStore to keep domain boundaries clean.
* The executionErrorStore composes from this store for aggregate error flags.
*/
var useMissingMediaStore = defineStore("missingMedia", () => {
	const canvasStore = useCanvasStore();
	const templateInputDownloadStore = useTemplateInputDownloadStore();
	const missingMediaCandidates = ref(null);
	/** Candidates to display; `null` while the missing media warning is off. */
	const visibleMissingMediaCandidates = computed(() => isMissingWarningVisible("media") ? missingMediaCandidates.value : null);
	/** Visible candidates the user can still act on, excluding in-flight template input downloads. */
	const actionableMissingMediaCandidates = computed(() => (visibleMissingMediaCandidates.value ?? []).filter(({ name }) => !templateInputDownloadStore.blockingFilenames.has(name)));
	const hasMissingMedia = computed(() => actionableMissingMediaCandidates.value.length > 0);
	const missingMediaCount = computed(() => actionableMissingMediaCandidates.value.length);
	const missingMediaNodeIds = computed(() => new Set(actionableMissingMediaCandidates.value.map((m) => String(m.nodeId))));
	/** `nodeId::widgetName` keys, so per-widget render lookups stay O(1). */
	const missingMediaWidgetKeys = computed(() => {
		const keys = /* @__PURE__ */ new Set();
		for (const candidate of actionableMissingMediaCandidates.value) keys.add(`${String(candidate.nodeId)}::${candidate.widgetName}`);
		return keys;
	});
	/**
	* Set of all execution ID prefixes derived from missing media node IDs,
	* including the missing media nodes themselves.
	*/
	const missingMediaAncestorExecutionIds = computed(() => {
		const ids = /* @__PURE__ */ new Set();
		for (const nodeId of missingMediaNodeIds.value) for (const id of getAncestorExecutionIds(nodeId)) ids.add(id);
		return ids;
	});
	const activeMissingMediaGraphIds = computed(() => {
		const rootGraph = useApp().rootGraphOrUndefined;
		if (!rootGraph) return /* @__PURE__ */ new Set();
		return getActiveGraphNodeIds(rootGraph, canvasStore.currentGraph ?? rootGraph, missingMediaAncestorExecutionIds.value);
	});
	let _verificationAbortController = null;
	function createVerificationAbortController() {
		_verificationAbortController?.abort();
		_verificationAbortController = new AbortController();
		return _verificationAbortController;
	}
	function setMissingMedia(media) {
		missingMediaCandidates.value = media.length ? media : null;
	}
	function hasMissingMediaOnNode(nodeLocatorId) {
		const executionId = useWorkflowStore().nodeLocatorIdToNodeExecutionId(nodeLocatorId);
		return executionId ? missingMediaNodeIds.value.has(executionId) : false;
	}
	function isContainerWithMissingMedia(node) {
		return activeMissingMediaGraphIds.value.has(String(node.id));
	}
	function isWidgetMissingMedia(nodeId, widgetName) {
		return missingMediaWidgetKeys.value.has(`${String(nodeId)}::${widgetName}`);
	}
	function removeMissingMediaByWidget(nodeId, widgetName) {
		if (!missingMediaCandidates.value) return;
		missingMediaCandidates.value = missingMediaCandidates.value.filter((m) => !(String(m.nodeId) === nodeId && m.widgetName === widgetName));
		if (!missingMediaCandidates.value.length) missingMediaCandidates.value = null;
	}
	function removeMissingMediaByNodeId(nodeId) {
		if (!missingMediaCandidates.value) return;
		missingMediaCandidates.value = missingMediaCandidates.value.filter((m) => String(m.nodeId) !== nodeId);
		if (!missingMediaCandidates.value.length) missingMediaCandidates.value = null;
	}
	/**
	* Remove all candidates whose nodeId starts with `prefix`.
	*
	* Intended for clearing all interior errors when a subgraph container is
	* removed. Callers are expected to pass `${execId}:` (with trailing
	* colon) so that sibling IDs sharing a numeric prefix (e.g. `"705"` vs
	* `"70"`) are not matched.
	*/
	function removeMissingMediaByPrefix(prefix) {
		if (!missingMediaCandidates.value) return;
		const remaining = [];
		for (const m of missingMediaCandidates.value) {
			const nodeId = m.nodeId;
			if (nodeId == null) {
				remaining.push(m);
				continue;
			}
			if (!String(nodeId).startsWith(prefix)) remaining.push(m);
		}
		if (remaining.length === missingMediaCandidates.value.length) return;
		missingMediaCandidates.value = remaining.length ? remaining : null;
	}
	function addMissingMedia(media) {
		if (!media.length) return;
		const existing = missingMediaCandidates.value ?? [];
		const existingKeys = new Set(existing.map((m) => `${String(m.nodeId)}::${m.widgetName}::${m.name}`));
		const newMedia = media.filter((m) => !existingKeys.has(`${String(m.nodeId)}::${m.widgetName}::${m.name}`));
		if (!newMedia.length) return;
		missingMediaCandidates.value = [...existing, ...newMedia];
	}
	function clearMissingMedia() {
		_verificationAbortController?.abort();
		_verificationAbortController = null;
		missingMediaCandidates.value = null;
	}
	return {
		missingMediaCandidates,
		visibleMissingMediaCandidates,
		hasMissingMedia,
		missingMediaCount,
		missingMediaNodeIds,
		missingMediaAncestorExecutionIds,
		activeMissingMediaGraphIds,
		hasMissingMediaOnNode,
		setMissingMedia,
		addMissingMedia,
		removeMissingMediaByWidget,
		removeMissingMediaByNodeId,
		removeMissingMediaByPrefix,
		clearMissingMedia,
		createVerificationAbortController,
		isContainerWithMissingMedia,
		isWidgetMissingMedia
	};
});
//#endregion
//#region src/platform/workflow/core/utils/pendingWarnings.ts
var emptyToUndefined = (arr) => arr?.length ? arr : void 0;
function getMissingNodeKey(node) {
	if (typeof node === "string") return `string:${node}`;
	if (node.nodeId != null) return `nodeId:${String(node.nodeId)}`;
	return `type:${node.type}`;
}
function dedupeMissingNodeTypes(types) {
	return uniqBy(types, getMissingNodeKey);
}
function removePendingMissingNodeTypesByType(currentTypes, typesToRemove) {
	const removeSet = new Set(typesToRemove);
	return dedupeMissingNodeTypes((currentTypes ?? []).filter((node) => {
		const nodeType = typeof node === "string" ? node : node.type;
		return !removeSet.has(nodeType);
	}));
}
function removePendingMissingNodeTypesByNodeId(currentTypes, nodeId) {
	return dedupeMissingNodeTypes((currentTypes ?? []).filter((node) => typeof node === "string" || node.nodeId == null || String(node.nodeId) !== nodeId));
}
function removePendingMissingNodeTypesByExecutionIdPrefix(currentTypes, prefix) {
	return dedupeMissingNodeTypes((currentTypes ?? []).filter((node) => {
		if (typeof node === "string" || node.nodeId == null) return true;
		return !String(node.nodeId).startsWith(prefix);
	}));
}
function normalizePendingWarnings(warnings) {
	if (!warnings) return null;
	const normalized = {
		missingNodeTypes: emptyToUndefined(warnings.missingNodeTypes),
		missingModelCandidates: emptyToUndefined(warnings.missingModelCandidates),
		missingMediaCandidates: emptyToUndefined(warnings.missingMediaCandidates)
	};
	return Object.values(normalized).some(Boolean) ? normalized : null;
}
function updatePendingWarnings(workflow, updates) {
	if (!workflow) return;
	workflow.pendingWarnings = normalizePendingWarnings({
		...workflow.pendingWarnings,
		...updates
	});
}
//#endregion
//#region src/platform/workflowErrors/nodeReplacement/missingNodesErrorStore.ts
var useMissingNodesErrorStore = defineStore("missingNodesError", () => {
	const missingNodesError = ref(null);
	/** Error to display; `null` while the missing nodes warning is off. */
	const visibleMissingNodesError = computed(() => isMissingWarningVisible("nodes") ? missingNodesError.value : null);
	function setMissingNodeTypes(types) {
		if (!types.length) {
			missingNodesError.value = null;
			return;
		}
		const uniqueTypes = dedupeMissingNodeTypes(types);
		missingNodesError.value = {
			message: st("rightSidePanel.missingNodePacks.title", "Missing Node Packs"),
			nodeTypes: uniqueTypes
		};
	}
	/** Set missing node types. Returns true if the Errors tab and the missing nodes warning are enabled and types were set. */
	function surfaceMissingNodes(types) {
		setMissingNodeTypes(types);
		return hasMissingNodes.value && useSettingStore().get("Comfy.RightSidePanel.ShowErrorsTab");
	}
	function removeMissingNodesByNodeId(nodeId) {
		if (!missingNodesError.value) return;
		setMissingNodeTypes(removePendingMissingNodeTypesByNodeId(missingNodesError.value.nodeTypes, nodeId));
	}
	/**
	* Remove all object-type entries whose nodeId starts with `prefix`.
	* String entries (group nodes) have no nodeId and are preserved.
	*
	* Intended for clearing all interior errors when a subgraph container
	* is removed. Callers are expected to pass `${execId}:` (with trailing
	* colon) so that sibling IDs sharing a numeric prefix are not matched.
	*/
	function removeMissingNodesByPrefix(prefix) {
		if (!missingNodesError.value) return;
		setMissingNodeTypes(removePendingMissingNodeTypesByExecutionIdPrefix(missingNodesError.value.nodeTypes, prefix));
	}
	/** Remove specific node types from the missing nodes list (e.g. after replacement). */
	function removeMissingNodesByType(typesToRemove) {
		if (!missingNodesError.value) return;
		setMissingNodeTypes(removePendingMissingNodeTypesByType(missingNodesError.value.nodeTypes, typesToRemove));
	}
	const hasMissingNodes = computed(() => !!visibleMissingNodesError.value);
	const missingNodeCount = computed(() => visibleMissingNodesError.value?.nodeTypes.length ?? 0);
	/**
	* Set of all execution ID prefixes derived from missing node execution IDs,
	* including the missing nodes themselves.
	*
	* Example: missing node at "65:70:63" → Set { "65", "65:70", "65:70:63" }
	*/
	const missingAncestorExecutionIds = computed(() => {
		const ids = /* @__PURE__ */ new Set();
		const error = visibleMissingNodesError.value;
		if (!error) return ids;
		for (const nodeType of error.nodeTypes) {
			if (typeof nodeType === "string") continue;
			if (nodeType.nodeId == null) continue;
			for (const id of getAncestorExecutionIds(String(nodeType.nodeId))) ids.add(id);
		}
		return ids;
	});
	/** True if the node has a missing node inside it at any nesting depth. */
	function isContainerWithMissingNode(node) {
		if (!useApp().isGraphReady) return false;
		const execId = getExecutionIdByNode(useApp().rootGraph, node);
		if (!execId) return false;
		return missingAncestorExecutionIds.value.has(execId);
	}
	return {
		missingNodesError,
		visibleMissingNodesError,
		setMissingNodeTypes,
		surfaceMissingNodes,
		removeMissingNodesByNodeId,
		removeMissingNodesByPrefix,
		removeMissingNodesByType,
		hasMissingNodes,
		missingNodeCount,
		missingAncestorExecutionIds,
		isContainerWithMissingNode
	};
});
//#endregion
//#region src/stores/executionErrorStore.ts
/** Execution error state: node errors, runtime errors, prompt errors, and missing assets. */
var useExecutionErrorStore = defineStore("executionError", () => {
	const workflowStore = useWorkflowStore();
	const canvasStore = useCanvasStore();
	const missingModelStore = useMissingModelStore();
	const missingNodesStore = useMissingNodesErrorStore();
	const missingMediaStore = useMissingMediaStore();
	/**
	* Run errors belong to the workflow that produced them, so they are parked
	* under its path and root graph id and follow that graph back into view
	* rather than being discarded when another workflow is loaded.
	*/
	const runErrorsByWorkflow = ref(/* @__PURE__ */ new Map());
	const activeRunErrorKey = ref(`:${zeroUuid}`);
	const isErrorOverlayOpen = ref(false);
	const activeRunErrors = computed(() => activeRunErrorKey.value === null ? void 0 : runErrorsByWorkflow.value.get(activeRunErrorKey.value));
	const lastNodeErrors = computed(() => activeRunErrors.value?.nodeErrors ?? null);
	const lastExecutionError = computed(() => activeRunErrors.value?.executionError ?? null);
	const lastPromptError = computed(() => activeRunErrors.value?.promptError ?? null);
	function updateRunErrors(patch, key) {
		if (key === null) return;
		const next = {
			absorbedValidationErrors: /* @__PURE__ */ new WeakMap(),
			nodeErrors: null,
			executionError: null,
			promptError: null,
			...runErrorsByWorkflow.value.get(key),
			...patch
		};
		if (!next.nodeErrors && !next.executionError && !next.promptError) runErrorsByWorkflow.value.delete(key);
		else runErrorsByWorkflow.value.set(key, next);
	}
	function runErrorKey(graphId, workflowPath) {
		return `${workflowPath ?? workflowStore.activeWorkflow?.path ?? ""}:${graphId}`;
	}
	function moveRunErrors(graphId, oldWorkflowPath, newWorkflowPath) {
		const oldKey = runErrorKey(graphId, oldWorkflowPath);
		const newKey = runErrorKey(graphId, newWorkflowPath);
		if (oldKey === newKey) return;
		const runErrors = runErrorsByWorkflow.value.get(oldKey);
		if (runErrors) runErrorsByWorkflow.value.set(newKey, runErrors);
		else runErrorsByWorkflow.value.delete(newKey);
		runErrorsByWorkflow.value.delete(oldKey);
		if (activeRunErrorKey.value === oldKey) activeRunErrorKey.value = newKey;
	}
	function captureRunErrorKey() {
		return activeRunErrorKey.value;
	}
	/**
	* Point the store at the run errors of `graphId`. `null` detaches it, so a
	* discarded graph shows nothing until the next one is loaded. The overlay is
	* dismissed on every move so it only ever reopens for the graph in front.
	*/
	function setActiveGraph(graphId, workflowPath) {
		const key = graphId === null ? null : runErrorKey(graphId, workflowPath);
		if (key === activeRunErrorKey.value) return;
		activeRunErrorKey.value = key;
		isErrorOverlayOpen.value = false;
	}
	const pendingAddedNodeScans = /* @__PURE__ */ new WeakMap();
	const pendingAddedNodeScanRevision = ref(0);
	const validationErrorSurfaces = /* @__PURE__ */ new WeakMap();
	function getValidationErrorSurfaces(rootGraph, rawNodeId, nodeError, error) {
		const rawErrorRecord = { [rawNodeId]: {
			...nodeError,
			errors: [error]
		} };
		const surfacedErrorRecord = rootGraph ? liftNodeErrorsToBoundary(rootGraph, rawErrorRecord) : rawErrorRecord;
		return Object.entries(surfacedErrorRecord).flatMap(([surfaceNodeId, surfaceNodeError]) => {
			const executionId = tryNormalizeNodeExecutionId(surfaceNodeId);
			if (!executionId) return [];
			return surfaceNodeError.errors.map((error) => ({
				executionId,
				error
			}));
		});
	}
	function captureValidationErrorSurfaces(nodeErrors) {
		const rootGraph = useApp().rootGraphOrUndefined;
		if (!rootGraph) return;
		for (const [rawNodeId, nodeError] of Object.entries(nodeErrors)) {
			const executionId = tryNormalizeNodeExecutionId(rawNodeId);
			if (!executionId) continue;
			for (const error of nodeError.errors) validationErrorSurfaces.set(toRaw(error), getValidationErrorSurfaces(rootGraph, executionId, nodeError, error));
		}
	}
	function resolveValidationErrorSurfaces(executionId, nodeError, error) {
		const rawError = toRaw(error);
		const cached = validationErrorSurfaces.get(rawError);
		if (cached) return cached;
		const rootGraph = useApp().rootGraphOrUndefined;
		const surfaces = getValidationErrorSurfaces(rootGraph, executionId, nodeError, error);
		if (rootGraph) validationErrorSurfaces.set(rawError, surfaces);
		return surfaces;
	}
	function beginAddedNodeErrorScan(rootGraph, executionId) {
		const scansForGraph = pendingAddedNodeScans.get(rootGraph) ?? /* @__PURE__ */ new Map();
		scansForGraph.set(executionId, (scansForGraph.get(executionId) ?? 0) + 1);
		pendingAddedNodeScans.set(rootGraph, scansForGraph);
		pendingAddedNodeScanRevision.value++;
		let finished = false;
		return () => {
			if (finished) return;
			finished = true;
			const remaining = (scansForGraph.get(executionId) ?? 1) - 1;
			if (remaining > 0) scansForGraph.set(executionId, remaining);
			else scansForGraph.delete(executionId);
			pendingAddedNodeScanRevision.value++;
		};
	}
	function hasPendingAddedNodeErrorScan(rootGraph, executionId) {
		pendingAddedNodeScanRevision.value;
		return (pendingAddedNodeScans.get(rootGraph)?.get(executionId) ?? 0) > 0;
	}
	/**
	* Also called after a graph load settles: the sync watcher below skips
	* transitions that happen while a load is in flight, and no later
	* transition reruns it.
	*/
	function retireResolvedMissingNodePromptError() {
		if (missingNodesStore.missingNodesError?.nodeTypes.length) return;
		if (!isMissingNodePromptError(lastPromptError.value)) return;
		updateRunErrors({ promptError: null }, activeRunErrorKey.value);
	}
	whenever(() => !missingNodesStore.missingNodesError?.nodeTypes.length, () => {
		if (ChangeTrackerAccess.isLoadingGraph) return;
		retireResolvedMissingNodePromptError();
	}, { flush: "sync" });
	function classifyMissingResource(surfaces, { models, media }) {
		for (const { executionId, error } of surfaces) {
			const kind = classifyValidationErrorAbsorption(models ?? null, media ?? null, error, executionId);
			if (kind) return kind;
		}
		return null;
	}
	/**
	* The model/media analog of the missing-node retirement above: when a
	* candidate leaves the store (installed + refreshed, node deleted or
	* bypassed), the validation errors it was absorbing must retire with it —
	* otherwise resolving the resource resurfaces them as blocking errors.
	* Matching is by content, so a rescan that rebuilds equivalent candidates
	* retires nothing.
	*/
	function reconcileAbsorbedErrors({ models, media }, key, previous) {
		if (ChangeTrackerAccess.isLoadingGraph || key === null || key !== activeRunErrorKey.value) return;
		const state = activeRunErrors.value;
		if (!state?.nodeErrors) return;
		const record = state.nodeErrors;
		const possiblyMissingModels = models?.map((candidate) => candidate.isMissing === void 0 ? {
			...candidate,
			isMissing: true
		} : candidate) ?? null;
		const possiblyMissingMedia = media?.map((candidate) => candidate.isMissing === void 0 ? {
			...candidate,
			isMissing: true
		} : candidate) ?? null;
		const current = {
			models,
			media
		};
		const possiblyMissing = {
			models: possiblyMissingModels,
			media: possiblyMissingMedia
		};
		const updated = filterNodeErrors(record, (surfaces, error) => {
			const rawError = toRaw(error);
			const kind = classifyMissingResource(surfaces, current);
			if (kind) {
				state.absorbedValidationErrors.set(rawError, kind);
				return true;
			}
			const wasAbsorbed = state.absorbedValidationErrors.get(rawError) ?? (previous ? classifyMissingResource(surfaces, previous) : null);
			if (!wasAbsorbed) return true;
			return !(wasAbsorbed === "missing_model" ? models !== void 0 : media !== void 0) || classifyMissingResource(surfaces, possiblyMissing) !== null;
		});
		if (updated !== record) updateRunErrors({ nodeErrors: updated }, key);
	}
	function filterNodeErrors(record, keepAndRecord) {
		let changed = false;
		const updated = {};
		for (const [rawNodeId, nodeError] of Object.entries(record)) {
			const executionId = tryNormalizeNodeExecutionId(rawNodeId);
			if (!executionId) {
				updated[rawNodeId] = nodeError;
				continue;
			}
			const remaining = nodeError.errors.filter((error) => keepAndRecord(resolveValidationErrorSurfaces(executionId, nodeError, error), error));
			if (remaining.length === nodeError.errors.length) updated[rawNodeId] = nodeError;
			else {
				changed = true;
				if (remaining.length > 0) updated[rawNodeId] = {
					...nodeError,
					errors: remaining
				};
			}
		}
		if (!changed) return record;
		return Object.keys(updated).length ? updated : null;
	}
	function retireResolvedMissingResourceErrors(candidates, key = activeRunErrorKey.value) {
		reconcileAbsorbedErrors(candidates, key);
	}
	watch(() => ({
		key: activeRunErrorKey.value,
		models: missingModelStore.missingModelCandidates,
		media: missingMediaStore.missingMediaCandidates
	}), (next, previous) => {
		if (next.key !== previous.key) return;
		reconcileAbsorbedErrors(next, next.key, previous);
	});
	/**
	* Replaces the full record; empty or null means the run produced no errors.
	*
	* `key` files the errors against the workflow that produced them, which is
	* not necessarily the one on screen. Build it with `runErrorKey`. It defaults
	* to the visible workflow for callers that record synchronously while
	* submitting it.
	*/
	function recordNodeErrors(nodeErrors, key = activeRunErrorKey.value) {
		const record = nodeErrors && Object.keys(nodeErrors).length > 0 ? nodeErrors : null;
		updateRunErrors({
			nodeErrors: record,
			absorbedValidationErrors: /* @__PURE__ */ new WeakMap()
		}, key);
		if (record && key !== null && key === activeRunErrorKey.value) {
			captureValidationErrorSurfaces(record);
			reconcileAbsorbedErrors({
				models: missingModelStore.missingModelCandidates,
				media: missingMediaStore.missingMediaCandidates
			}, key);
		}
	}
	function recordExecutionError(detail, key = activeRunErrorKey.value) {
		updateRunErrors({ executionError: detail }, key);
	}
	function showExecutionError(detail, key = activeRunErrorKey.value) {
		if (key === null || key !== activeRunErrorKey.value) return;
		if (useSettingStore().get("Comfy.RightSidePanel.ShowErrorsTab")) showErrorOverlay();
		else useDialogService().showExecutionErrorDialog(detail);
	}
	function recordPromptError(promptError, key = activeRunErrorKey.value) {
		updateRunErrors({ promptError }, key);
	}
	function showErrorOverlay() {
		isErrorOverlayOpen.value = true;
	}
	function dismissErrorOverlay() {
		isErrorOverlayOpen.value = false;
	}
	/** Clear error state produced by a run. Missing-resource state describes the
	*  loaded graph rather than the run, so only replacing or discarding the
	*  graph invalidates it. */
	function clearRunErrors() {
		if (activeRunErrorKey.value !== null) runErrorsByWorkflow.value.delete(activeRunErrorKey.value);
		isErrorOverlayOpen.value = false;
	}
	function clearExecutionStartErrors(key = activeRunErrorKey.value) {
		updateRunErrors({
			executionError: null,
			promptError: null
		}, key);
		if (key === activeRunErrorKey.value && !lastNodeErrors.value) isErrorOverlayOpen.value = false;
	}
	/** Clear only prompt-level errors. Called during resetExecutionState. */
	function clearPromptError(key = activeRunErrorKey.value) {
		updateRunErrors({ promptError: null }, key);
	}
	function clearSimpleNodeErrorsFromRecord(nodeErrors, executionId, slotName) {
		if (!(executionId in nodeErrors)) return null;
		const nodeError = nodeErrors[executionId];
		const isSlotScoped = slotName !== void 0;
		const relevantErrors = isSlotScoped ? errorsForSlot(nodeError.errors, slotName) : nodeError.errors;
		if (relevantErrors.length === 0) return null;
		if (!relevantErrors.every((e) => SIMPLE_ERROR_TYPES.has(e.type))) return null;
		const updated = { ...nodeErrors };
		if (isSlotScoped) {
			const remainingErrors = nodeError.errors.filter((error) => !relevantErrors.includes(error));
			if (remainingErrors.length === 0) delete updated[executionId];
			else updated[executionId] = {
				...nodeError,
				errors: remainingErrors
			};
		} else delete updated[executionId];
		return updated;
	}
	/**
	* Raw interior sources of lifted errors whose boundary chain passes through
	* `(executionId, slotName)`, so a fix at any host level — final surface or
	* intermediate — clears the error at its raw key.
	*/
	function getLiftedErrorSourceTargets(executionId, slotName) {
		const surfaced = surfacedNodeErrors.value;
		const rootGraph = useApp().rootGraphOrUndefined;
		if (!surfaced || !rootGraph) return [];
		return Object.values(surfaced).flatMap((surface) => surface.errors.flatMap((error) => {
			const source = getLiftedErrorSource(error);
			if (!source) return [];
			const sourceExecutionId = tryNormalizeNodeExecutionId(source.source_execution_id);
			if (!sourceExecutionId) return [];
			return resolveLiftChain(rootGraph, sourceExecutionId, source.source_input_name).some((level) => level.hostExecId === executionId && level.hostInputName === slotName) ? [{
				executionId: sourceExecutionId,
				slotName: source.source_input_name,
				useRecordedBounds: true
			}] : [];
		}));
	}
	/** Raw targets are keys into lastNodeErrors, not surfacedNodeErrors. */
	function getRawClearTargets(executionId, slotName) {
		return [{
			executionId,
			slotName
		}, ...getLiftedErrorSourceTargets(executionId, slotName)];
	}
	/**
	* Bounds recorded on the error win only for interior lifted targets, where
	* the caller's options describe the host widget rather than the interior
	* input. The base target keeps the caller's live widget bounds, which stay
	* authoritative when node definitions change after validation.
	*/
	function getTargetRangeOptions(errors, fallback) {
		for (const error of errors) {
			const { min, max } = getInputConfigBounds(error);
			if (min === void 0 && max === void 0) continue;
			return {
				min: typeof min === "number" ? min : fallback.min,
				max: typeof max === "number" ? max : fallback.max
			};
		}
		return fallback;
	}
	function isTargetStillOutOfRange(nodeErrors, target, value, callerOptions) {
		if (!(target.executionId in nodeErrors)) return false;
		const nodeError = nodeErrors[target.executionId];
		const errors = errorsForSlot(nodeError.errors, target.slotName);
		const options = target.useRecordedBounds ? getTargetRangeOptions(errors, callerOptions) : callerOptions;
		return isValueStillOutOfRange(value, errors, options);
	}
	function clearTargets(targets) {
		if (!lastNodeErrors.value) return;
		let updated = lastNodeErrors.value;
		for (const target of targets) updated = clearSimpleNodeErrorsFromRecord(updated, target.executionId, target.slotName) ?? updated;
		if (updated === lastNodeErrors.value) return;
		updateRunErrors({ nodeErrors: Object.keys(updated).length > 0 ? updated : null }, activeRunErrorKey.value);
	}
	/**
	* Removes a node's errors if they consist entirely of simple, auto-resolvable
	* types. When `slotName` is provided, only errors for that slot are checked
	* and boundary-lifted errors are also cleared through their raw interior
	* source. Node-scoped calls (no `slotName`) operate on the raw record key
	* only.
	*/
	function clearSimpleNodeErrors(executionId, slotName) {
		clearTargets(slotName === void 0 ? [{ executionId }] : getRawClearTargets(executionId, slotName));
	}
	/**
	* Attempts to clear an error for a given widget, but avoids clearing it if
	* the error is a range violation and the new value is still out of bounds.
	* The base target validates against the caller's live widget bounds; each
	* interior lifted target validates against its own recorded bounds, so a
	* boundary input fanning out to inputs with different constraints clears
	* only the targets the new value satisfies.
	*
	* Note: `value_not_in_list` errors are optimistically cleared without
	* list-membership validation because combo widgets constrain choices to
	* valid values at the UI level, and the valid-values source varies
	* (asset system vs objectInfo) making runtime validation non-trivial.
	*/
	function clearSlotErrorsWithRangeCheck(executionId, widgetName, newValue, options) {
		const nodeErrors = lastNodeErrors.value;
		if (!nodeErrors) return;
		const targets = getRawClearTargets(executionId, widgetName);
		clearTargets(typeof newValue === "number" ? targets.filter((target) => !isTargetStillOutOfRange(nodeErrors, target, newValue, options ?? {})) : targets);
	}
	/**
	* Clears both validation errors and missing model state for a widget.
	*
	* @param errorInputName Name matched against `error.extra_info.input_name`.
	* @param widgetName Widget name used for missing model/media lookup.
	*/
	function clearWidgetRelatedErrors(executionId, errorInputName, widgetName, newValue, options) {
		clearSlotErrorsWithRangeCheck(executionId, errorInputName, newValue, options);
		missingModelStore.removeMissingModelByWidget(executionId, widgetName);
		missingMediaStore.removeMissingMediaByWidget(executionId, widgetName);
	}
	/** Set missing models and optionally open the error overlay. */
	function surfaceMissingModels(models, options) {
		missingModelStore.setMissingModels(models);
		if (!options?.silent && missingModelStore.hasMissingModels && useSettingStore().get("Comfy.RightSidePanel.ShowErrorsTab")) showErrorOverlay();
	}
	/** Set missing media and optionally open the error overlay. */
	function surfaceMissingMedia(media, options) {
		missingMediaStore.setMissingMedia(media);
		if (!options?.silent && missingMediaStore.hasMissingMedia && useSettingStore().get("Comfy.RightSidePanel.ShowErrorsTab")) showErrorOverlay();
	}
	const lastExecutionErrorNodeLocatorId = computed(() => {
		const err = lastExecutionError.value;
		if (!err) return null;
		return executionIdToNodeLocatorId(useApp().rootGraphOrUndefined, String(err.node_id));
	});
	const lastExecutionErrorNodeId = computed(() => {
		const locator = lastExecutionErrorNodeLocatorId.value;
		if (!locator) return null;
		return workflowStore.nodeLocatorIdToNodeId(locator);
	});
	const hasExecutionError = computed(() => !!lastExecutionError.value);
	const hasPromptError = computed(() => !!lastPromptError.value);
	const hasNodeError = computed(() => lastNodeErrors.value !== null);
	const surfacedNodeErrors = computed(() => {
		const rootGraph = useApp().rootGraphOrUndefined;
		return lastNodeErrors.value && rootGraph ? liftNodeErrorsToBoundary(rootGraph, lastNodeErrors.value) : lastNodeErrors.value;
	});
	const errorClassification = computed(() => classifyPanelErrors({
		promptError: lastPromptError.value,
		executionError: lastExecutionError.value,
		nodeErrors: surfacedNodeErrors.value,
		missingModels: missingModelStore.visibleMissingModelCandidates,
		missingMedia: missingMediaStore.visibleMissingMediaCandidates,
		hasMissingNodes: missingNodesStore.hasMissingNodes
	}));
	const blockingErrorNodeLocatorIds = computed(() => {
		const classification = errorClassification.value;
		const executionIds = classification.nodeErrors.filter(({ errors }) => errors.some(({ absorption }) => !absorption)).map(({ rawNodeId }) => rawNodeId);
		if (classification.executionError?.rawNodeId != null) executionIds.push(classification.executionError.rawNodeId);
		const locators = /* @__PURE__ */ new Set();
		for (const executionId of executionIds) for (const ancestorId of getAncestorExecutionIds(executionId)) {
			const locator = executionIdToNodeLocatorId(useApp().rootGraphOrUndefined, ancestorId);
			if (locator) locators.add(locator);
		}
		return locators;
	});
	const hasMissingError = computed(() => missingNodesStore.hasMissingNodes || missingModelStore.hasMissingModels || missingMediaStore.hasMissingMedia);
	const hasAnyError = computed(() => hasExecutionError.value || hasPromptError.value || hasNodeError.value || hasMissingError.value);
	const allErrorExecutionIds = computed(() => {
		const ids = [];
		if (surfacedNodeErrors.value) ids.push(...Object.keys(surfacedNodeErrors.value));
		if (lastExecutionError.value) {
			const nodeId = lastExecutionError.value.node_id;
			if (nodeId != null) ids.push(String(nodeId));
		}
		return ids;
	});
	/** Graph node IDs (as strings) that have errors in the current graph scope. */
	const activeGraphErrorNodeIds = computed(() => {
		const ids = /* @__PURE__ */ new Set();
		const rootGraph = useApp().rootGraphOrUndefined;
		if (!rootGraph) return ids;
		const activeGraph = canvasStore.currentGraph ?? rootGraph;
		if (surfacedNodeErrors.value) for (const executionId of Object.keys(surfacedNodeErrors.value)) {
			const graphNode = getNodeByExecutionId(rootGraph, executionId);
			if (graphNode?.graph === activeGraph) ids.add(String(graphNode.id));
		}
		if (lastExecutionError.value) {
			const execNodeId = String(lastExecutionError.value.node_id);
			const graphNode = getNodeByExecutionId(rootGraph, execNodeId);
			if (graphNode?.graph === activeGraph) ids.add(String(graphNode.id));
		}
		return ids;
	});
	/** Map of node errors indexed by locator ID. */
	const nodeErrorsByLocatorId = computed(() => {
		if (!surfacedNodeErrors.value) return {};
		const map = {};
		for (const [executionId, nodeError] of Object.entries(surfacedNodeErrors.value)) {
			const locatorId = executionIdToNodeLocatorId(useApp().rootGraphOrUndefined, executionId);
			if (locatorId) map[locatorId] = nodeError;
		}
		return map;
	});
	/** Get node errors by locator ID. */
	const getNodeErrors = (nodeLocatorId) => {
		return nodeErrorsByLocatorId.value[nodeLocatorId];
	};
	/** Check if a specific slot has validation errors. */
	const slotHasError = (nodeLocatorId, slotName) => {
		const nodeError = getNodeErrors(nodeLocatorId);
		if (!nodeError) return false;
		return hasErrorForSlot(nodeError.errors, slotName);
	};
	/**
	* Set of all execution ID prefixes derived from active error nodes,
	* including the error nodes themselves.
	*
	* Example: error at "65:70:63" → Set { "65", "65:70", "65:70:63" }
	*/
	const errorAncestorExecutionIds = computed(() => {
		const ids = /* @__PURE__ */ new Set();
		for (const executionId of allErrorExecutionIds.value) for (const id of getAncestorExecutionIds(executionId)) ids.add(id);
		return ids;
	});
	/** True if the node has errors inside it at any nesting depth. */
	function isContainerWithInternalError(node) {
		const rootGraph = useApp().rootGraphOrUndefined;
		if (!rootGraph) return false;
		const execId = getExecutionIdByNode(rootGraph, node);
		if (!execId) return false;
		return errorAncestorExecutionIds.value.has(execId);
	}
	useNodeErrorFlagSync(surfacedNodeErrors, missingModelStore, missingMediaStore, missingNodesStore);
	return {
		lastNodeErrors,
		lastExecutionError,
		lastPromptError,
		recordNodeErrors,
		recordExecutionError,
		recordPromptError,
		captureRunErrorKey,
		runErrorKey,
		moveRunErrors,
		setActiveGraph,
		clearRunErrors,
		clearExecutionStartErrors,
		clearPromptError,
		retireResolvedMissingNodePromptError,
		retireResolvedMissingResourceErrors,
		isErrorOverlayOpen,
		showExecutionError,
		showErrorOverlay,
		dismissErrorOverlay,
		surfacedNodeErrors,
		hasExecutionError,
		hasPromptError,
		hasNodeError,
		errorClassification,
		blockingErrorNodeLocatorIds,
		hasMissingError,
		hasAnyError,
		allErrorExecutionIds,
		lastExecutionErrorNodeId,
		lastExecutionErrorNodeLocatorId,
		activeGraphErrorNodeIds,
		beginAddedNodeErrorScan,
		hasPendingAddedNodeErrorScan,
		clearSimpleNodeErrors,
		clearWidgetRelatedErrors,
		surfaceMissingModels,
		surfaceMissingMedia,
		getNodeErrors,
		slotHasError,
		isContainerWithInternalError
	};
});
//#endregion
export { updatePendingWarnings as a, useMissingModelStore as c, uniqBy as d, removePendingMissingNodeTypesByType as i, isIssuesTabEnabled as l, useMissingNodesErrorStore as n, useMissingMediaStore as o, normalizePendingWarnings as r, useTemplateInputDownloadStore as s, useExecutionErrorStore as t, isMissingWarningVisible as u };
