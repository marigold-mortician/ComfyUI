const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./dist-BQrSDUjE.js","./rolldown-runtime-xtsTai4I.js","./preload-helper-sJeoGctA.js","./modelThumbnail-DAA4IgcR.js","./TimeoutError-DBgma3uz.js","./delay-Cu8bS1zn.js","./globalThis-B6Vbq1EF.js","./reportError-BHgDVvfb.js","./hostTelemetryEnabled-DM7ML37c.js","./remoteConfig-VmmsGxJZ.js","./vendor-vue-core-CuN1excl.js","./vendor-reka-ui-NRTk7aIV.js","./vendor-sentry-zSXGkMPN.js","./errorUtil-DoQyAUQC.js","./load3dHost-B4KoEUu1.js","./settingStore-DRRi2kOn.js","./cloneDeep-BX7AjX4w.js","./api-BdJmXw98.js","./requestAuth-COoKVLz2.js","./get-Bk-Y8oEe.js","./telemetry-IkzvF0TI.js","./vendor-zod-Del_rmdp.js","./zod.gen-DzuaBm8H.js","./vendor-axios-QnwcNXlY.js","./requestTimeout-DkmiEk-h.js","./vendor-firebase-B37L--zT.js","./toastStore-Dg65fRgL.js","./i18n-BRluoVl-.js","./vendor-i18n-pA_PV1p-.js","./formatUtil-DsZFGVbT.js","./commands-C9zyhK6Q.js","./main-BtaRoPyL.js","./nodeDefs-BUEI64H3.js","./settings-B3DInspu.js","./rerouteId-1TDIYZkX.js","./Load3dUtils-CF3OvEZx.js","./appInstance-CiT6CpGM.js","./assert--qJvwrYk.js","./assetPreviewUtil-Dg8MDMb3.js","./graphTraversalUtil-BUK1cr2m.js","./globalEnums-BPoISudO.js","./useFeatureFlags-B3zg5FdZ.js","./assetsStore-CzSfkgjN.js","./litegraph-DsPnoImk.js","./noop-CsGmlYWz.js","./isPlainObject-6prWdO5v.js","./isObject-BDwzDI3k.js","./colorUtil--RFe1UD6.js","./vendor-markdown-CtxqRwKg.js","./widget-TCRFSGUe.js","./vendor-yjs-DzSvc5Ii.js","./nodeOutputStore-Dec5oA1b.js","./litegraphUtil-8EMdlR16.js","./iteratee-D-xtYlr8.js","./map--HGZfCRO.js","./inputSpecTree-B0INjagH.js","./workflowStore-ChkUx7Si.js","./treeUtil-4aExWhwq.js","./dialogService-CqZr0BhP.js","./commandStore-XD_i1hej.js","./useErrorHandling-WrECc0C0.js","./Button-CcqmlVQb.js","./src-BHQtMnZc.js","./dialogStore-Dm9z8_kv.js","./DialogTitle-CWOHHLwH.js","./useCopyToClipboard-DUbSOtYA.js","./systemStatsStore-DAY0RqGT.js","./Input-12QxL1XI.js","./storageIO-CAjGLygi.js","./colorPaletteTheme-BLTbQMIT.js","./utils-DPLBHlcF.js","./downloadUtil-PDRccee-.js","./teamWorkspaceStore-BNm5cZOK.js","./ssoTelemetry-DZUrpShr.js","./telemetry-CRUTYyCh.js","./comfyApi-CXw0-V35.js","./desktopHostSession-B3KqJnXo.js","./ssoRequiredDialogKey-DRv9w9ql.js","./errors-Bls3VadO.js","./agentPanelStore-CFwk6coW.js","./clamp-C6J77Y5a.js","./nodeDefStore-dfke_cvJ.js","./uniq-HSN5S90b.js","./vendor-vueuse-ehQVlHrl.js","./executionStore-DrU24oQb.js","./executionErrorStore-DzGUJU_L.js","./canvasStore-siYzI5aT.js","./quick-lru-CwZ_Nev1.js","./assetMetadataUtils-IzKjxxiA.js","./cloudPreviewUtil-QoYZLRNr.js","./resultItemUrl-BV9Vi8QF.js","./hdrFormatUtil-rFvza1J0.js","./Load3dViewerContent-DuG77Xh8.js","./Load3dViewerContent-DiX-pgUx.js","./constants-CcZ5JemZ.js","./SelectValue-Biyqru5w.js","./Slider-Ba9vS1t0.js","./AnimationControls-CuO05S2B.js","./ToggleGroupItem-B6sGt08k.js","./toggle-group-Cn40zTWz.js","./useLoad3dViewer-gzGwCj1t.js","./createLoad3d-DVjBd0bL.js","./vendor-three-B-UiePqj.js","./ViewHelperManager-BpbYuVKl.js","./sharedWebGLRenderer-BSlxZGp0.js","./reportLoadModelOutcome-DAkHX512.js","./load3dInstances-ykQ7kIrj.js","./load3dService-BJvHfXYO.js","./MediaLightbox-BxVt-Aqb.js","./MediaLightbox-3ctL3ALH.js","./extensionStore-CYnV6tYr.js","./useImageQuiet-Cn5yvS20.js","./WaveAudioPlayer-Dn6-iFHj.js","./useRetryableMediaSrc-Bj45a3to.js","./useWaveAudioPlayer-cIDEKkhR.js","./useTextFileContent-CQkdXCAG.js","./CrdtDevPanel-BxGaWlQM.js","./types-t0xJOOCt.js","./useCurrentUser-DjJaVYwd.js","./authStore-D2cL6XhN.js","./cloudWebSessionStore-DQXLFlJm.js","./refreshRemoteConfig-CEuxp20e.js","./app-C-5f0uvA.js","./appModeStore-C3kEWkI2.js","./shuffle-CnBsCH60.js","./debounce-CrddqoI1.js","./deburr-BNFMXPzm.js","./queueSettingsStore-BzKxsLQU.js","./sidebarTabStore-DSQyJJJG.js","./layerEditorDialogKey-j8nal3kA.js","./workflowFlattening-DY0Vs9rF.js","./modalUtil-Cmzr62_V.js","./useBillingContext-uo5ceiak.js","./tierPricing-Dm5JzLf8.js","./creditsUtil-DxLnYjvD.js","./useAuthActions-_rhVfmiU.js","./workspaceStore-CA_rc-fs.js","./markdownRendererUtil-BJj2U6Nd.js","./useBillingCapabilities-x1h7nBmq.js","./Badge-BUm0jxSy.js","./types-Co7511Rq.js","./useBillingDialogs-CYngXWQg.js","./billingActionNames-DwcV6mOp.js","./billingDialogsAccess-BbNj81q5.js","./Card-lRVBegiG.js","./AppDialogPanel-BklaJBTn.js","./usePaymentRecoveryDialog-CK1xdYr3.js","./FormNumberField-BP7-goH4.js","./NumberFieldInput-CUxTsNZT.js","./useExternalLink-Cd0Jpjd8.js","./envUtil-Cq1k2k7n.js","./useSubscriptionDialog-B-Gs4QHW.js","./subscriptionDialogAccess-Igw8sX_b.js","./useWorkspaceUI-rAENEr3F.js","./billingPlanTelemetry-CgeXQYDa.js","./pendingSubscriptionCheckout-CwZ4vFuG.js","./checkoutJourneyTelemetry-afzrfER1.js","./getExecutionContext-D9Siyc8N.js","./categoryUtil-DZVfz29_.js","./usePartnerNodesRunGate-Bl8OMNN4.js","./useAuthDialogs-C9YGTip0.js","./keybindingService-CtLOmFQk.js","./useChainCallback-Bm3zfHjO.js","./resolveWidgetValueAsset-CCylptbe.js","./usePopoverSizing-ux16dO36.js","./select.variants-BBeExFA3.js","./missingModelScan-zIBS2S8n.js","./imageUtil-B67VHiUy.js","./mathUtil-BWeg2vFD.js","./skillReferenceText-CIcnFnck.js","./types-CnYEnJ8O.js","./opEnvelope-eXHTW5mx.js","./agentApiSchema-BSP_VZP6.js"])))=>i.map(i=>d[i]);
import { r as __name } from "./rolldown-runtime-xtsTai4I.js";
import { t as __vitePreload } from "./preload-helper-sJeoGctA.js";
import { I as maxBy, L as intersection, N as omit, k as upperFirst } from "./appModeStore-C3kEWkI2.js";
import { Ft as toRootGraphId, Lt as layoutStore, M as topologicalSortSubgraphs, Mn as isEqual, On as truncate, Pn as once, Pt as toOwningGraphId, Rn as difference, Y as LGraphNode, dn as withGraphIntentSource, kt as createUuidv4, n as LGraphCanvas, st as detachSerialisedLinks, t as LiteGraph, yn as isUuidShapedSubgraphId } from "./litegraph-DsPnoImk.js";
import { t as useCommandStore } from "./commandStore-XD_i1hej.js";
import { d as isLGraphNode } from "./litegraphUtil-8EMdlR16.js";
import { s as uniq } from "./treeUtil-4aExWhwq.js";
import { t as useExecutionErrorStore } from "./executionErrorStore-DzGUJU_L.js";
import { t as delay } from "./delay-Cu8bS1zn.js";
import { t as TimeoutError } from "./TimeoutError-DBgma3uz.js";
import { n as debounce } from "./debounce-CrddqoI1.js";
import { t as useBillingContext } from "./useBillingContext-uo5ceiak.js";
import { n as useSettingStore } from "./settingStore-DRRi2kOn.js";
import { t as isPlainObject } from "./isPlainObject-6prWdO5v.js";
import { t as useTeamWorkspaceStore } from "./teamWorkspaceStore-BNm5cZOK.js";
import { a as useBillingIdentity, d as iconForMediaType, f as useOverflowObserver, h as withTimeout, i as useNodeEmphasisSource, m as MenuItem_default, o as useFocusNode, p as Tag_default, s as CanvasBanner_default, t as useFloating, u as registerMinimapDecorationLayer } from "./floating-ui.vue-B1rhRhA7.js";
import { d as zComfyNode, g as getSessionOverride, i as api, q as isMediaRoute } from "./api-BdJmXw98.js";
import { $ as mergeModels, B as createSlots, Bt as toRef, E as withModifiers, F as createBaseVNode, Ft as ref, G as defineComponent, H as createTextVNode, Ht as toValue, I as createBlock, J as h, Jt as normalizeStyle, K as getCurrentInstance, Kt as normalizeClass, L as createCommentVNode, Mt as onScopeDispose, O as Fragment, Ot as effectScope, P as computed, Pt as readonly, R as createElementBlock, Rt as shallowRef, T as withKeys, U as createVNode, W as defineAsyncComponent, Wt as unref, X as inject, Yt as toDisplayString, Z as isMemoSame, _t as useModel, at as onMounted, bt as watch, ct as openBlock, d as defineStore, dt as renderSlot, et as mergeProps, ft as resolveComponent, gt as useId, j as Teleport, jt as markRaw, kt as getCurrentScope, lt as provide, ot as onUnmounted, p as storeToRefs, q as guardReactiveProps, qt as normalizeProps, rt as onBeforeUnmount, tt as nextTick, ut as renderList, v as render$3, wt as withCtx, yt as useTemplateRef, z as createPropsRestProxy, zt as toRaw } from "./vendor-vue-core-CuN1excl.js";
import { An as CollapsibleRoot_default, At as PopoverAnchor_default, Cr as usePreferredReducedMotion, Ct as DropdownMenuRoot_default, Er as useScroll, Gr as useIntervalFn, Jr as useTimeoutFn, Mn as useForwardPropsEmits, Mr as useWindowSize, Nn as useForwardProps, On as CollapsibleTrigger_default, Or as useStorage, St as DropdownMenuContent_default, Tr as useResizeObserver, Xn as useClipboardItems, Yn as useClipboard, Yr as watchDebounced, _t as DropdownMenuRadioGroup_default, ar as useEventListener, bt as DropdownMenuItemIndicator_default, cn as shift, ct as HoverCardContent_default$1, dr as useIntersectionObserver, dt as DropdownMenuTrigger_default, gt as DropdownMenuRadioItem_default, in as autoUpdate, kn as CollapsibleContent_default, kr as useTimestamp, lt as HoverCardRoot_default, mt as DropdownMenuSub_default, nr as useElementHover, ot as HoverCardTrigger_default$1, pr as useLocalStorage, qr as useTimeout, sn as offset, sr as useFocusWithin, st as HoverCardPortal_default, tr as useElementBounding, ut as injectHoverCardRootContext, vt as DropdownMenuPortal_default, wn as FocusScope_default } from "./vendor-reka-ui-NRTk7aIV.js";
import { r as useI18n } from "./vendor-i18n-pA_PV1p-.js";
import { a as TooltipTrigger_default, o as TooltipContent_default, r as buttonVariants, s as Tooltip_default, t as Button_default } from "./Button-CcqmlVQb.js";
import { t as cn } from "./src-BHQtMnZc.js";
import { S as areWorkflowIdsEquivalent, _ as useColorPaletteStore, b as createPositionBounds, n as useWorkflowStore, o as blankGraph } from "./workflowStore-ChkUx7Si.js";
import { n as useTelemetry } from "./telemetry-IkzvF0TI.js";
import { D as union$1, O as unknown, S as object, T as string, j as ZodError, l as array, o as _null, u as boolean, w as record, x as number } from "./vendor-zod-Del_rmdp.js";
import { g as zAgentRetainedAttachmentExtension, h as zAgentReferenceAttachmentExtension, it as zGetFeaturesResponse, m as zAgentReadableAttachmentExtension, p as zAgentProbeableAttachmentExtension, r as zAgentAskConflict, t as zAgentAdmissionError, w as zAgentViewableAttachmentExtension } from "./zod.gen-DzuaBm8H.js";
import { n as getDevOverride } from "./hostTelemetryEnabled-DM7ML37c.js";
import { i as remoteConfig, r as isAuthenticatedConfigLoaded } from "./remoteConfig-VmmsGxJZ.js";
import { n as createToastId, t as useToast } from "./toastStore-Dg65fRgL.js";
import { n as i18n } from "./i18n-BRluoVl-.js";
import { h as getPathDetails, l as formatSize, m as getMediaTypeFromFilename, p as getFilenameDetails } from "./formatUtil-DsZFGVbT.js";
import { r as reportError } from "./reportError-BHgDVvfb.js";
import { n as parseLinkId, o as isWidgetValue, r as toLinkId } from "./rerouteId-1TDIYZkX.js";
import { i as MenuSubContent_default, l as MenuContent_default, o as MenuRadioItem_default, r as MenuSubTrigger_default, s as MenuSeparator_default, t as Menu_default } from "./Menu-iX8QWfwR.js";
import { t as Badge_default } from "./Badge-BUm0jxSy.js";
import { $ as toNodeId, G as isNodeLocatorId, H as createNodeLocatorId, Z as parseNodeId, _ as getNodeByLocatorId, q as parseNodeLocatorId } from "./graphTraversalUtil-BUK1cr2m.js";
import { t as assert } from "./assert--qJvwrYk.js";
import { C as StorageKeys, D as hashPath, r as clearLegacyAgentStorage, w as getWorkspaceId } from "./storageIO-CAjGLygi.js";
import { n as marked, r as purify } from "./vendor-markdown-CtxqRwKg.js";
import { a as YMap, c as decodeUpdate, i as YArrayEvent, n as Doc, o as YMapEvent, r as YArray, s as applyUpdate, t as AbstractType, u as encodeStateVector } from "./vendor-yjs-DzSvc5Ii.js";
import { t as useDialogStore } from "./dialogStore-Dm9z8_kv.js";
import { t as Input_default } from "./Input-12QxL1XI.js";
import { a as useAppMode, n as useCanvasStore } from "./canvasStore-siYzI5aT.js";
import { t as useFeatureFlags } from "./useFeatureFlags-B3zg5FdZ.js";
import { n as isCreditTransitionNoticeShown, t as useAgentPanelStore } from "./agentPanelStore-CFwk6coW.js";
import { r as inputSpecTree } from "./inputSpecTree-B0INjagH.js";
import { n as resolveMarkdownUrl, t as renderMarkdownToHtml } from "./markdownRendererUtil-BJj2U6Nd.js";
import { f as useApiKeyAuthStore, r as useAuthStore } from "./authStore-D2cL6XhN.js";
import { t as useSidebarTabStore } from "./sidebarTabStore-DSQyJJJG.js";
import { a as useWorkflowService } from "./useAuthActions-_rhVfmiU.js";
import { n as useExecutionStore } from "./executionStore-DrU24oQb.js";
import { t as useCurrentUser } from "./useCurrentUser-DjJaVYwd.js";
import { t as useBillingCapabilities } from "./useBillingCapabilities-x1h7nBmq.js";
import { t as AGENT_FREE_USE_PLACEMENTS } from "./types-Co7511Rq.js";
import { t as useWorkspaceUI } from "./useWorkspaceUI-rAENEr3F.js";
import { t as Card_default } from "./Card-lRVBegiG.js";
import { At as isDynamicGroupController, Dt as growAutogrowInput, Ft as useAccountPreconditionDialog, Mt as reportRemoteDynamicGroupRowMismatch, Ut as zMediaKindSchema, Vt as MIME_ASSET_INFO, at as hasImageType, it as hasAudioType, jt as reachesDynamicGroupRowCount, kt as applyRemoteDynamicGroupRowCount, n as app, nt as fetchDroppedAsset, ot as hasVideoType, rt as getDroppedAsset } from "./app-C-5f0uvA.js";
import { n as registerEscapeOverride } from "./keybindingService-CtLOmFQk.js";
import { t as useAssetsStore } from "./assetsStore-CzSfkgjN.js";
import { a as isHdrImageFilename } from "./hdrFormatUtil-rFvza1J0.js";
import { n as isLoopbackHost } from "./hostWhitelist-txsSSTbM.js";
import { t as Slider_default } from "./Slider-Ba9vS1t0.js";
import { t as useWaveAudioPlayer } from "./useWaveAudioPlayer-cIDEKkhR.js";
import { t as useOnboardingTourStore } from "./onboardingTourStore-DL-TBMHb.js";
import { a as useAgentConsentStore, o as AGENT_DOCS_URL, p as unionRect, r as useAgentConsent, s as clampSpotlight, t as useWorkflowTabActivityStore } from "./workflowTabActivityStore-BwZie-5b.js";
import { C as isLevelEnabled, E as startCrdtDebugGate, S as isCrdtDebugOptedOut, _ as sanitizeDevEventDetail, c as SERVER_DOC_FRAME_TYPES, d as isRetryableReseedCode, g as recordDevEvent, i as AgentCrdtDocLifecycle, r as promptReferenceParts, u as isPermanentSubscribeRefusalCode, w as resolveDebugPanelEnabled, x as isCrdtDebugEnabled } from "./skillReferenceText-CIcnFnck.js";
import { _ as reportLostEdit, a as agentMessageText, c as composerReferenceKey, d as useCanvasSelection, f as attachRestoreOpMinter, g as attachDocOpMinter, i as sameComposerReferenceOrder, l as composerReferenceName, n as composerPromptForSend, o as assetReferenceText, r as composerPromptForSubmission, s as nodeReferenceText, t as useAgentComposerStore, u as selectedNodeKey } from "./agentComposerStore-DTtkkFtu.js";
import { a as codePointLength, r as PACK_NAME_PATTERN } from "./types-CnYEnJ8O.js";
import { t as openFeedbackDialog$1 } from "./feedbackDialog-Ou8TLTOa.js";
import { t as SanitizedHtml_default } from "./SanitizedHtml-kTDIrh6X.js";
import { t as Popover_default } from "./Popover-Cjk42F0c.js";
import { t as PopoverContent_default } from "./PopoverContent-CJioRepA.js";
import { n as findServerPreviewUrl, r as isAssetPreviewSupported, t as findOutputAsset } from "./assetPreviewUtil-Dg8MDMb3.js";
import { t as LOAD3D_VIEWER_DIALOG_PROPS } from "./load3dViewerDialog-D35Ppx7u.js";
import { t as v4 } from "./v4-B6IY9qUv.js";
import { n as tagRemoveButtonVariants, r as tagVariants, t as TagRemoveButton_default } from "./TagRemoveButton-DmMMh2ek.js";
import { t as Checkbox_default } from "./Checkbox-CGtQ5Kkd.js";
import { n as RadioGroup_default, t as RadioGroupItem_default } from "./RadioGroupItem-DF4cXT8y.js";
import { t as useSkillPacksStore } from "./skillPacksStore-CvhjCUhU.js";
import { t as useOnboardingOverlayStore } from "./onboardingOverlayStore-bQGc_Pr0.js";
import { t as useAssetDownload } from "./useAssetDownload-RlJRQus_.js";
import { A as Slice, D as Fragment$1, E as DOMSerializer, T as DOMParser$1, _ as Decoration, a as undo, b as baseKeymap, g as keymap, i as redo, k as Schema, n as closeHistory, r as history, v as DecorationSet, w as TextSelection, x as EditorState, y as EditorView } from "./vendor-tiptap-MlR23Fl9.js";
import { t as useAgentPanelRenderStore } from "./agentPanelRenderStore-BeUEkE3X.js";
import { _ as zTurnInProgressError, f as zAttachmentRejection, i as toTurnId, m as zDisownedWorkflowError, n as isAgentEvent, r as parseAgentWsEvent } from "./agentApiSchema-BSP_VZP6.js";
import { A as isUnconfirmedCanvasWrite, C as serializeWorkflowReferences, D as askIdOf, E as toolCanMutateCanvas, O as choosableCount, S as normalizeAgentTranscript, T as toolCanClaimCanvasContent, b as useAgentConversationStore, c as readMeta, f as readSchemaVersion, h as nodesMap, i as appliedOpIds, j as toAskResolution, k as isOpenAskPart, l as readStamps, m as linksMap, n as measureWireOp, p as OPAQUE_WIDGETS_KEY, r as mintWireOps, s as readGraph, t as chunkWireOps, w as areAgentWorkflowIdsEquivalent, x as isAttachmentKind } from "./opEnvelope-eXHTW5mx.js";
import { a as createAgentRestClient, c as hasAgentCredential, i as AgentResponseUnreadableError, n as useAgentSendGateStore, o as agentSocketAuthParams, r as AgentApiError, s as ensureSignedIn, t as useAgentRunModeStore } from "./agentRunModeStore-Nsv7Xv1E.js";
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/union.mjs
/**
* Creates an array of unique values from all given arrays.
*
* This function takes two arrays, merges them into a single array, and returns a new array
* containing only the unique values from the merged array.
*
* @template T - The type of elements in the array.
* @param arr1 - The first array to merge and filter for unique values.
* @param arr2 - The second array to merge and filter for unique values.
* @returns A new array of unique values.
*
* @example
* const array1 = [1, 2, 3];
* const array2 = [3, 4, 5];
* const result = union(array1, array2);
* // result will be [1, 2, 3, 4, 5]
*/
function union(arr1, arr2) {
	return uniq(arr1.concat(arr2));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/array/xor.mjs
/**
* Computes the symmetric difference between two arrays. The symmetric difference is the set of elements
* which are in either of the arrays, but not in their intersection.
*
* @template T - The type of elements in the array.
* @param arr1 - The first array.
* @param arr2 - The second array.
* @returns An array containing the elements that are present in either `arr1` or `arr2` but not in both.
*
* @example
* // Returns [1, 2, 5, 6]
* xor([1, 2, 3, 4], [3, 4, 5, 6]);
*
* @example
* // Returns ['a', 'c']
* xor(['a', 'b'], ['b', 'c']);
*/
function xor(arr1, arr2) {
	return difference(union(arr1, arr2), intersection(arr1, arr2));
}
//#endregion
//#region node_modules/.pnpm/es-toolkit@1.49.0/node_modules/es-toolkit/dist/function/throttle.mjs
/**
* Creates a throttled function that only invokes the provided function at most once
* per every `throttleMs` milliseconds. Subsequent calls to the throttled function
* within the wait time will not trigger the execution of the original function.
*
* @template F - The type of function.
* @param func - The function to throttle.
* @param throttleMs - The number of milliseconds to throttle executions to.
* @returns A new throttled function that accepts the same parameters as the original function.
*
* @example
* const throttledFunction = throttle(() => {
*   console.log('Function executed');
* }, 1000);
*
* // Will log 'Function executed' immediately
* throttledFunction();
*
* // Will not log anything as it is within the throttle time
* throttledFunction();
*
* // After 1 second
* setTimeout(() => {
*   throttledFunction(); // Will log 'Function executed'
* }, 1000);
*/
function throttle(func, throttleMs, { signal, edges = ["leading", "trailing"] } = {}) {
	let pendingAt = null;
	const debounced = debounce(function(...args) {
		pendingAt = Date.now();
		func.apply(this, args);
	}, throttleMs, {
		signal,
		edges
	});
	const throttled = function(...args) {
		if (pendingAt == null) pendingAt = Date.now();
		if (Date.now() - pendingAt >= throttleMs) {
			pendingAt = Date.now();
			func.apply(this, args);
			debounced.cancel();
			debounced.schedule();
			return;
		}
		debounced.apply(this, args);
	};
	throttled.cancel = debounced.cancel;
	throttled.flush = debounced.flush;
	return throttled;
}
//#endregion
//#region src/workbench/extensions/agent/crdt/unsyncedHumanOps.ts
var STORAGE_KEY = "Comfy.Agent.UnsyncedHumanOps";
var unsyncedAtLoad = null;
var unsyncedByRecorder = /* @__PURE__ */ new Map();
function readStored() {
	try {
		const parsed = JSON.parse(sessionStorage.getItem(STORAGE_KEY) ?? "[]");
		return Array.isArray(parsed) ? parsed.filter((id) => typeof id === "string") : [];
	} catch {
		return [];
	}
}
function writeStored(ids) {
	try {
		if (ids.length === 0) sessionStorage.removeItem(STORAGE_KEY);
		else sessionStorage.setItem(STORAGE_KEY, JSON.stringify(ids));
	} catch {
		return;
	}
}
function loadOnce() {
	unsyncedAtLoad ??= new Set(readStored());
	return unsyncedAtLoad;
}
function unsyncedNow() {
	return /* @__PURE__ */ new Set([...loadOnce(), ...[...unsyncedByRecorder.values()].flatMap((ids) => [...ids])]);
}
/** Records this recorder's workflows whose canvas holds edits the doc may lack. */
function recordUnsyncedHumanOps(recorder, workflowIds) {
	const ids = new Set(workflowIds);
	if (ids.size === 0) unsyncedByRecorder.delete(recorder);
	else unsyncedByRecorder.set(recorder, ids);
	writeStored([...unsyncedNow()]);
}
/** Whether `workflowId`'s canvas holds edits the shared document may lack. */
function hasUnsyncedHumanOps(workflowId) {
	return unsyncedNow().has(workflowId);
}
/** Drops what a page before this one recorded for `workflowId`. */
function forgetUnsyncedAtLoad(workflowId) {
	if (workflowId === null) return;
	if (!loadOnce().delete(workflowId)) return;
	writeStored([...unsyncedNow()]);
}
//#endregion
//#region src/workbench/extensions/agent/crdt/workflowSyncErrorDetail.ts
/** Cap on the doc-host's raw refusal message appended to the localized detail
* below — the host's `message` is developer text of unbounded length, not
* meant to replace the reassurance the localized copy gives the person. */
var SYNC_ERROR_RAW_MESSAGE_MAX_LENGTH = 200;
/** Returns localized sync guidance with safe raw context when applicable. */
function formatWorkflowSyncErrorDetail(translate, message, code) {
	const detail = translate(detailKey(code));
	if (!message || code === "catalog_mismatch") return detail;
	return `${detail} (${truncate(message, { length: SYNC_ERROR_RAW_MESSAGE_MAX_LENGTH })})`;
}
function detailKey(code) {
	switch (code) {
		case "catalog_mismatch": return "agent.workflowSyncFailedDetailCatalogMismatch";
		case "stale_client_schema": return "agent.workflowSyncFailedDetailStaleClient";
		case "stale_host_schema": return "agent.workflowSyncFailedDetailStaleHost";
		default: return "agent.workflowSyncFailedDetail";
	}
}
//#endregion
//#region src/workbench/extensions/agent/utils/attachableFiles.ts
var CAPABILITY_BY_EXTENSION = new Map([
	...zAgentViewableAttachmentExtension.options.map((extension) => [extension, "view"]),
	...zAgentProbeableAttachmentExtension.options.map((extension) => [extension, "probe"]),
	...zAgentReferenceAttachmentExtension.options.map((extension) => [extension, "reference"]),
	...zAgentReadableAttachmentExtension.options.map((extension) => [extension, "read"]),
	...zAgentRetainedAttachmentExtension.options.map((extension) => [extension, "retain"])
]);
var AGENT_ATTACH_ACCEPT = [...CAPABILITY_BY_EXTENSION.keys()].join(",");
var EXTENSION_PATTERN = /\.[a-z0-9]{1,8}$/i;
var AUTHORITATIVE_EXTENSION_PATTERN = /\.[^./\\]+$/;
function extensionOf(filename) {
	const match = EXTENSION_PATTERN.exec(filename)?.[0].toLowerCase();
	return match && /[a-z]/.test(match) ? match : "";
}
function agentAttachCapability(filename) {
	return CAPABILITY_BY_EXTENSION.get(extensionOf(filename));
}
function isAgentAttachable(file) {
	return agentAttachCapability(file.name) !== void 0;
}
function agentAttachVerdict(filename) {
	if (agentAttachCapability(filename)) return "accepted";
	return extensionOf(filename) === "" ? "unknown" : "rejected";
}
function agentAttachRefVerdict(ref) {
	if (agentAttachCapability(ref)) return "accepted";
	return AUTHORITATIVE_EXTENSION_PATTERN.test(ref) ? "rejected" : "unknown";
}
function bytesMatch(bytes, offset, expected) {
	return expected.split("").every((char, index) => bytes[offset + index] === char.charCodeAt(0));
}
var ISO_BASE_MEDIA_BOXES = [
	"ftyp",
	"moov",
	"mdat",
	"wide",
	"free",
	"skip",
	"pnot"
];
var EBML_MAGIC = "Eß£";
function isIsoBaseMedia(bytes) {
	return ISO_BASE_MEDIA_BOXES.some((box) => bytesMatch(bytes, 4, box));
}
function isEbml(bytes) {
	return bytesMatch(bytes, 0, EBML_MAGIC);
}
var VIDEO_CONTAINER_CHECKS = {
	mp4: isIsoBaseMedia,
	m4v: isIsoBaseMedia,
	mov: isIsoBaseMedia,
	webm: isEbml,
	mkv: isEbml,
	avi: (bytes) => bytesMatch(bytes, 0, "RIFF") && bytesMatch(bytes, 8, "AVI ")
};
function isValidAgentAttachment(file) {
	const extension = extensionOf(file.name).slice(1);
	const check = Object.hasOwn(VIDEO_CONTAINER_CHECKS, extension) ? VIDEO_CONTAINER_CHECKS[extension] : void 0;
	if (!check) return true;
	return file.slice(0, 12).arrayBuffer().then((buffer) => check(new Uint8Array(buffer))).catch(() => false);
}
//#endregion
//#region src/workbench/extensions/agent/composables/agent/useOnboarding.ts
var SHARED_ONBOARDING_KEY = "Comfy.AgentPanel.onboarded";
function scopedOnboardingKey(userId, workspaceId) {
	if (!userId || !workspaceId) return null;
	return `${SHARED_ONBOARDING_KEY}.${userId}.${workspaceId}`;
}
/**
* The coach marks recorded one flag for the whole device, while consent is
* recorded per account and workspace. A user who had seen the marks anywhere
* therefore joined a new workspace, accepted consent again, and got no
* guidance. Carry the old flag onto the scope in front of the user, then drop
* the shared one so later scopes start clean.
*/
function adoptSharedOnboardingFlag(scopedKey) {
	try {
		if (localStorage.getItem(SHARED_ONBOARDING_KEY) !== "true") return;
		if (localStorage.getItem(scopedKey) === null) localStorage.setItem(scopedKey, "true");
		localStorage.removeItem(SHARED_ONBOARDING_KEY);
	} catch {}
}
var reportedMissingTargets = /* @__PURE__ */ new Set();
/** Once per target per session: every panel mount would otherwise repeat it. */
function reportMissingCoachTarget(target, step) {
	const key = `${target}:${step}`;
	if (reportedMissingTargets.has(key)) return;
	reportedMissingTargets.add(key);
	useTelemetry()?.trackAgentOnboardingNotShown({
		reason: "target_missing",
		step
	});
	reportError(/* @__PURE__ */ new Error("Agent coach target never mounted"), {
		surface: "agent",
		errorType: "failure_locating_agent_coach_target",
		level: "warning",
		context: {
			target,
			step
		}
	});
}
function hasSeenCoach(scopedKey) {
	try {
		return localStorage.getItem(scopedKey) === "true";
	} catch {
		return false;
	}
}
/**
* Clear the persisted flag with no live tour to notify. Only for the deferred
* case, where no `useOnboarding` instance is mounted to take `restart()`; a
* mounted tour must go through the transition so it reacts without a remount.
*/
function resetCoach(scopedKey) {
	try {
		localStorage.removeItem(scopedKey);
	} catch {}
}
var shownScopes = /* @__PURE__ */ new Set();
var reportedDeferrals = /* @__PURE__ */ new Set();
/** A coach paused mid-way by App Mode or a tour was already shown, so it stays quiet. */
function trackCoachDeferral(scope, reason) {
	if (reason === null) {
		shownScopes.add(scope);
		return;
	}
	const key = `${scope}:${reason}`;
	if (shownScopes.has(scope) || reportedDeferrals.has(key)) return;
	reportedDeferrals.add(key);
	useTelemetry()?.trackAgentOnboardingNotShown({ reason });
}
function useOnboarding(steps, storageKey = SHARED_ONBOARDING_KEY) {
	const seen = useStorage(storageKey, false);
	const index = ref(0);
	const step = computed(() => toValue(steps)[index.value]);
	const active = computed(() => !seen.value && !!step.value);
	const isLast = computed(() => index.value === toValue(steps).length - 1);
	function finish() {
		seen.value = true;
	}
	function next() {
		if (!active.value) return;
		if (isLast.value) finish();
		else index.value += 1;
	}
	function previous() {
		if (!active.value || index.value === 0) return;
		index.value -= 1;
	}
	/**
	* Replay from the first card. `seen` is the same reactive storage ref the
	* tour reads, so clearing it here reaches every consumer; the caller does not
	* have to poke localStorage and remount to be noticed.
	*/
	function restart() {
		index.value = 0;
		seen.value = false;
	}
	return {
		active,
		index,
		step,
		isLast,
		next,
		previous,
		finish,
		restart
	};
}
//#endregion
//#region src/workbench/extensions/agent/experiments/freeUsePlacement.ts
var FREE_USE_PLACEMENT_FLAG = "agent-free-use-message-placement";
var FREE_USE_VARIANTS = ["control", ...AGENT_FREE_USE_PLACEMENTS];
function isFreeUseVariant(value) {
	return FREE_USE_VARIANTS.some((variant) => variant === value);
}
function useFreeUsePlacement() {
	const panelStore = useAgentPanelStore();
	const assigned = ref("control");
	const sessionOverride = getSessionOverride(FREE_USE_PLACEMENT_FLAG);
	const override = sessionOverride !== void 0 ? sessionOverride : /* @__PURE__ */ getDevOverride(FREE_USE_PLACEMENT_FLAG);
	const hasQaOverride = override !== void 0;
	function assign() {
		const served = remoteConfig.value[FREE_USE_PLACEMENT_FLAG];
		if (!isFreeUseVariant(served)) {
			assigned.value = "control";
			return;
		}
		assigned.value = served;
		if (panelStore.reportedFreeUseExposure) return;
		const telemetry = useTelemetry();
		if (!telemetry) return;
		panelStore.reportedFreeUseExposure = true;
		telemetry.trackAgentFreeUseExposure({
			placement: served,
			[`$feature/${FREE_USE_PLACEMENT_FLAG}`]: served
		});
	}
	if (hasQaOverride) {
		if (isFreeUseVariant(override)) assigned.value = override;
	} else if (isAuthenticatedConfigLoaded.value) assign();
	else {
		const stop = watch(isAuthenticatedConfigLoaded, (authenticated) => {
			if (!authenticated) return;
			assign();
			stop();
		});
	}
	if (!hasQaOverride) {
		watch(() => remoteConfig.value[FREE_USE_PLACEMENT_FLAG], () => {
			if (isAuthenticatedConfigLoaded.value) assign();
		});
		watch(() => panelStore.isOpen, (isOpen) => {
			if (isOpen && isAuthenticatedConfigLoaded.value) assign();
		});
	}
	function reportNotice(metadata) {
		if (hasQaOverride) return;
		if (metadata.action === "shown" && panelStore.reportedFreeUseImpression) return;
		const telemetry = useTelemetry();
		if (!telemetry) return;
		if (metadata.action === "shown") panelStore.reportedFreeUseImpression = true;
		telemetry.trackAgentFreeUseNotice(metadata);
	}
	return {
		variant: readonly(assigned),
		reportNotice
	};
}
//#endregion
//#region src/workbench/extensions/agent/experiments/starterPromptSet.ts
var STARTER_PROMPT_SET_FLAG = "agent-starter-prompt-set";
var starterPromptAssignmentSchema = zGetFeaturesResponse.shape[STARTER_PROMPT_SET_FLAG].catch("control");
function resolveAssignment() {
	const sessionOverride = getSessionOverride(STARTER_PROMPT_SET_FLAG);
	const override = sessionOverride !== void 0 ? sessionOverride : /* @__PURE__ */ getDevOverride(STARTER_PROMPT_SET_FLAG);
	const candidate = override !== void 0 ? override : remoteConfig.value[STARTER_PROMPT_SET_FLAG];
	return {
		assignment: starterPromptAssignmentSchema.parse(candidate),
		hasQaOverride: override !== void 0
	};
}
function useStarterPromptSet() {
	const assignment = computed(() => {
		const resolved = resolveAssignment();
		return isAuthenticatedConfigLoaded.value || resolved.hasQaOverride ? resolved.assignment : "control";
	});
	const attributeExperiment = computed(() => {
		const resolved = resolveAssignment();
		return isAuthenticatedConfigLoaded.value && !resolved.hasQaOverride;
	});
	const expose = (renderedAssignment) => {
		if (!attributeExperiment.value || renderedAssignment !== assignment.value) return;
		useTelemetry()?.trackAgentStarterPromptExposure({ [`$feature/${STARTER_PROMPT_SET_FLAG}`]: assignment.value });
	};
	return {
		assignment,
		attributeExperiment,
		expose
	};
}
//#endregion
//#region src/workbench/extensions/agent/services/agent/agentPaywallPresentation.ts
var DEFAULT_AGENT_PAYWALL_PRESENTATION = { kind: "unavailable" };
var AGENT_PAYWALL_REASONS = {
	subscribed: "no_funds",
	local: "no_funds",
	subscriptionRequired: "subscription_inactive",
	member: "member_cannot_pay",
	salesManaged: "sales_managed",
	unavailable: "unknown"
};
function toAgentPaywallReason(presentation) {
	return AGENT_PAYWALL_REASONS[presentation.kind];
}
var AGENT_PAYWALL_CTAS = {
	addCredits: "add_credits",
	subscribe: "subscribe",
	upgrade: "upgrade"
};
function toAgentPaywallCta(action) {
	return AGENT_PAYWALL_CTAS[action];
}
function resolveAgentPaywallPresentation({ distribution, role, tier, canTopUp, canSubscribeSelfServe }) {
	if (distribution === "local") return { kind: "local" };
	if (role === void 0) return DEFAULT_AGENT_PAYWALL_PRESENTATION;
	if (role === "member" && !canTopUp) return { kind: "member" };
	if (!canTopUp) return canSubscribeSelfServe ? { kind: "subscriptionRequired" } : { kind: "salesManaged" };
	return {
		kind: "subscribed",
		showUpgrade: canSubscribeSelfServe && (tier === "STANDARD" || tier === "CREATOR")
	};
}
//#endregion
//#region src/workbench/extensions/agent/utils/sessionTitle.ts
var MAX_DERIVED_TITLE_LENGTH = 60;
var graphemeSegmenter = once(() => new Intl.Segmenter(void 0, { granularity: "grapheme" }));
/** First user message, trimmed and capped at 60 graphemes. */
function deriveSessionTitle(entries) {
	const text = entries.find((entry) => entry.role === "user")?.text.trim() ?? "";
	return Array.from(graphemeSegmenter().segment(text), ({ segment }) => segment).slice(0, MAX_DERIVED_TITLE_LENGTH).join("").trimEnd() || void 0;
}
function withCurrentSessionTitle(groups, title) {
	if (!title) return groups;
	return {
		...groups,
		current: groups.current.map((session) => session.titleSource === "fallback" ? {
			...session,
			title
		} : session)
	};
}
//#endregion
//#region src/workbench/extensions/agent/feedback.ts
function openFeedbackDialog(source) {
	if (!useAgentPanelStore().enabled) {
		openFeedbackDialog$1(source);
		return;
	}
	const { resolvedUserInfo } = useCurrentUser();
	openFeedbackDialog$1(source, {
		typeformId: "MZ6cjWIB",
		extraTags: {
			userid: resolvedUserInfo.value?.id,
			version: "1.59.1",
			os: navigator.platform,
			session: useAgentConversationStore().threadId
		}
	});
}
//#endregion
//#region src/workbench/extensions/agent/components/agent/AgentFeedbackCaption.vue
var AgentFeedbackCaption_default = /* @__PURE__ */ defineComponent({
	__name: "AgentFeedbackCaption",
	setup(__props) {
		const { t } = useI18n();
		return (_ctx, _cache) => {
			return openBlock(), createBlock(Button_default, {
				type: "button",
				variant: "muted-textonly",
				size: "sm",
				class: "-mt-1.5 mb-0 w-full",
				onClick: _cache[0] || (_cache[0] = ($event) => unref(openFeedbackDialog)("agent-panel"))
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(unref(t)("agent.feedbackCaption")), 1)]),
				_: 1
			});
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/AgentSyncRetryAlert.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$50 = {
	key: 0,
	role: "alert",
	class: "flex items-center gap-3 rounded-lg border border-destructive/40 bg-background p-3 text-sm"
};
var _hoisted_2$40 = { class: "m-0 min-w-0 flex-1" };
//#endregion
//#region src/workbench/extensions/agent/components/agent/AgentSyncRetryAlert.vue
var AgentSyncRetryAlert_default = /* @__PURE__ */ defineComponent({
	__name: "AgentSyncRetryAlert",
	props: { visible: { type: Boolean } },
	emits: ["retry"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const { t } = useI18n();
		return (_ctx, _cache) => {
			return __props.visible ? (openBlock(), createElementBlock("div", _hoisted_1$50, [
				_cache[1] || (_cache[1] = createBaseVNode("span", {
					"aria-hidden": "true",
					class: "icon-[lucide--circle-alert] size-5 shrink-0 text-destructive"
				}, null, -1)),
				createBaseVNode("p", _hoisted_2$40, toDisplayString(unref(t)("agent.workflowSyncFailedTitle")), 1),
				createVNode(Button_default, {
					type: "button",
					variant: "outline",
					size: "sm",
					class: "shrink-0",
					onClick: _cache[0] || (_cache[0] = ($event) => emit("retry"))
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(unref(t)("g.retry")), 1)]),
					_: 1
				})
			])) : createCommentVNode("", true);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/ChatHistorySelectButton.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$49 = { class: "flex min-w-0 flex-1 flex-col" };
var _hoisted_2$39 = {
	key: 0,
	"aria-hidden": "true",
	class: "icon-[lucide--loader-circle] size-4 shrink-0 animate-spin"
};
var _hoisted_3$30 = {
	key: 1,
	"aria-hidden": "true",
	class: "icon-[lucide--circle-check] size-4 shrink-0"
};
var _hoisted_4$23 = { class: "truncate" };
var _hoisted_5$18 = {
	key: 0,
	role: "status",
	class: "sr-only"
};
var _hoisted_6$13 = ["id"];
//#endregion
//#region src/workbench/extensions/agent/components/agent/ChatHistorySelectButton.vue
var ChatHistorySelectButton_default = /* @__PURE__ */ defineComponent({
	__name: "ChatHistorySelectButton",
	props: {
		title: {},
		loading: {
			type: Boolean,
			default: false
		},
		failed: {
			type: Boolean,
			default: false
		}
	},
	emits: ["select"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const { t } = useI18n();
		const displayTitle = computed(() => __props.title.trim() || t("agent.untitledChat"));
		const errorId = useId();
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$49, [
				createVNode(Button_default, {
					type: "button",
					variant: "muted-textonly",
					size: "unset",
					"aria-busy": __props.loading,
					"aria-label": displayTitle.value,
					"aria-describedby": __props.failed ? unref(errorId) : void 0,
					disabled: __props.loading,
					class: "min-w-0 justify-start text-left text-xs font-normal",
					onClick: _cache[0] || (_cache[0] = ($event) => emit("select"))
				}, {
					default: withCtx(() => [__props.loading ? (openBlock(), createElementBlock("span", _hoisted_2$39)) : (openBlock(), createElementBlock("span", _hoisted_3$30)), createBaseVNode("span", _hoisted_4$23, toDisplayString(displayTitle.value), 1)]),
					_: 1
				}, 8, [
					"aria-busy",
					"aria-label",
					"aria-describedby",
					"disabled"
				]),
				__props.loading ? (openBlock(), createElementBlock("span", _hoisted_5$18, toDisplayString(unref(t)("g.loading")), 1)) : createCommentVNode("", true),
				__props.failed ? (openBlock(), createElementBlock("span", {
					key: 1,
					id: unref(errorId),
					role: "alert",
					class: "pl-6 text-xs whitespace-normal text-destructive"
				}, toDisplayString(unref(t)("agent.historyOpenFailed")), 9, _hoisted_6$13)) : createCommentVNode("", true)
			]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/ChatHistoryScreen.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$48 = { class: "flex h-full flex-col overflow-hidden" };
var _hoisted_2$38 = { class: "flex h-10 shrink-0 items-center gap-1 px-2" };
var _hoisted_3$29 = { class: "m-0 text-xs font-normal text-muted-foreground" };
var _hoisted_4$22 = { class: "min-h-0 flex-1 overflow-y-auto p-2" };
var _hoisted_5$17 = {
	key: 0,
	class: "px-2 py-8 text-center text-sm text-muted-foreground"
};
var _hoisted_6$12 = { class: "my-0 px-2 py-1 text-xs text-muted-foreground" };
var _hoisted_7$9 = {
	key: 0,
	class: "flex min-w-0 flex-1 items-center"
};
var MAX_TITLE_LENGTH = 200;
//#endregion
//#region src/workbench/extensions/agent/components/agent/ChatHistoryScreen.vue
var ChatHistoryScreen_default = /* @__PURE__ */ defineComponent({
	__name: "ChatHistoryScreen",
	props: {
		groups: {},
		loadingId: { default: null },
		failedId: { default: null }
	},
	emits: [
		"back",
		"select",
		"delete",
		"copyMarkdown",
		"rename"
	],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const { t } = useI18n();
		const sections = computed(() => [
			[
				"current",
				t("agent.historyCurrent"),
				__props.groups.current
			],
			[
				"today",
				t("agent.historyToday"),
				__props.groups.today
			],
			[
				"yesterday",
				t("agent.historyYesterday"),
				__props.groups.yesterday
			],
			[
				"earlier",
				t("agent.historyEarlier"),
				__props.groups.earlier
			]
		].filter(([, , items]) => items.length > 0));
		const isEmpty = computed(() => sections.value.length === 0);
		function pick(session) {
			emit("select", session.id);
		}
		const renamingId = ref(null);
		const renameDraft = ref("");
		const selectOnFocus = ref(false);
		function startRename(session) {
			renamingId.value = session.id;
			renameDraft.value = session.title;
			selectOnFocus.value = true;
		}
		function focusInput(el) {
			const input = el instanceof Element ? el : el?.$el;
			if (!(input instanceof HTMLInputElement)) return;
			const shouldSelect = selectOnFocus.value;
			selectOnFocus.value = false;
			nextTick(() => {
				if (!input.isConnected) return;
				input.focus();
				if (shouldSelect) input.select();
			});
		}
		function cancelRename() {
			renamingId.value = null;
		}
		function commitRename(session) {
			if (renamingId.value !== session.id) return;
			renamingId.value = null;
			const title = renameDraft.value.trim();
			if (title !== "" && title !== session.title.trim()) emit("rename", session.id, title);
		}
		function onMenuCloseAutoFocus(event) {
			if (renamingId.value !== null) event.preventDefault();
		}
		function onRenameKeydown(session, event) {
			if (event.isComposing) return;
			if (event.key === "Enter") {
				event.preventDefault();
				commitRename(session);
			} else if (event.key === "Escape") {
				event.preventDefault();
				cancelRename();
			}
		}
		function getSessionMenuItems(session) {
			return [
				{
					label: t("g.rename"),
					icon: "icon-[lucide--pencil]",
					command: () => startRename(session)
				},
				{ separator: true },
				{
					label: t("g.delete"),
					icon: "icon-[lucide--trash-2]",
					variant: "destructive",
					command: () => emit("delete", session.id)
				}
			];
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$48, [createBaseVNode("div", _hoisted_2$38, [createVNode(Button_default, {
				tooltip: unref(t)("agent.backToPreviousChat"),
				"tooltip-side": "bottom",
				type: "button",
				variant: "muted-textonly",
				size: "icon-sm",
				"aria-label": unref(t)("agent.backToPreviousChat"),
				class: "size-6 shrink-0",
				onClick: _cache[0] || (_cache[0] = ($event) => emit("back"))
			}, {
				default: withCtx(() => [..._cache[2] || (_cache[2] = [createBaseVNode("span", { class: "icon-[lucide--chevron-left] size-4 shrink-0" }, null, -1)])]),
				_: 1
			}, 8, ["tooltip", "aria-label"]), createBaseVNode("h2", _hoisted_3$29, toDisplayString(unref(t)("agent.history")), 1)]), createBaseVNode("div", _hoisted_4$22, [isEmpty.value ? (openBlock(), createElementBlock("p", _hoisted_5$17, toDisplayString(unref(t)("agent.historyEmpty")), 1)) : createCommentVNode("", true), (openBlock(true), createElementBlock(Fragment, null, renderList(sections.value, ([key, label, items]) => {
				return openBlock(), createElementBlock("section", {
					key,
					class: "mb-3"
				}, [createBaseVNode("p", _hoisted_6$12, toDisplayString(label), 1), (openBlock(true), createElementBlock(Fragment, null, renderList(items, (session) => {
					return openBlock(), createElementBlock("div", {
						key: session.id,
						class: "group flex items-center gap-2 rounded-sm px-2 py-1 hover:bg-accent"
					}, [renamingId.value === session.id ? (openBlock(), createElementBlock("div", _hoisted_7$9, [_cache[3] || (_cache[3] = createBaseVNode("span", { class: "icon-[lucide--circle-check] size-4 shrink-0 text-muted-foreground" }, null, -1)), createVNode(Input_default, {
						ref_for: true,
						ref: focusInput,
						modelValue: renameDraft.value,
						"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => renameDraft.value = $event),
						type: "text",
						"aria-label": unref(t)("g.rename"),
						maxlength: MAX_TITLE_LENGTH,
						class: "h-6 flex-1 px-2 py-1 text-xs",
						onKeydown: ($event) => onRenameKeydown(session, $event),
						onBlur: ($event) => commitRename(session)
					}, null, 8, [
						"modelValue",
						"aria-label",
						"onKeydown",
						"onBlur"
					])])) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
						createVNode(ChatHistorySelectButton_default, {
							title: session.title,
							loading: __props.loadingId === session.id,
							failed: __props.failedId === session.id,
							onSelect: ($event) => pick(session)
						}, null, 8, [
							"title",
							"loading",
							"failed",
							"onSelect"
						]),
						createVNode(Button_default, {
							tooltip: unref(t)("agent.copyMarkdown"),
							type: "button",
							variant: "muted-textonly",
							size: "icon-sm",
							class: "shrink-0",
							"aria-label": unref(t)("agent.copyMarkdown"),
							disabled: __props.loadingId === session.id,
							onClick: ($event) => emit("copyMarkdown", session.id)
						}, {
							default: withCtx(() => [..._cache[4] || (_cache[4] = [createBaseVNode("span", { class: "icon-[lucide--copy] size-3.5" }, null, -1)])]),
							_: 1
						}, 8, [
							"tooltip",
							"aria-label",
							"disabled",
							"onClick"
						]),
						createVNode(Menu_default, {
							items: getSessionMenuItems(session),
							side: "bottom",
							align: "end",
							"side-offset": 4,
							class: "agent-scope",
							onCloseAutoFocus: onMenuCloseAutoFocus
						}, {
							trigger: withCtx(() => [createVNode(Button_default, {
								variant: "muted-textonly",
								size: "icon-sm",
								class: "size-6 shrink-0",
								"aria-label": unref(t)("agent.chatOptions"),
								disabled: __props.loadingId === session.id
							}, {
								default: withCtx(() => [..._cache[5] || (_cache[5] = [createBaseVNode("span", { class: "icon-[lucide--chevron-down] size-3" }, null, -1)])]),
								_: 1
							}, 8, ["aria-label", "disabled"])]),
							_: 2
						}, 1032, ["items"])
					], 64))]);
				}), 128))]);
			}), 128))])]);
		};
	}
});
//#endregion
//#region ~icons/lucide/arrow-up
var _hoisted_1$47 = {
	viewBox: "0 0 24 24",
	width: "1.2em",
	height: "1.2em"
};
function render$2(_ctx, _cache) {
	return openBlock(), createElementBlock("svg", _hoisted_1$47, [..._cache[0] || (_cache[0] = [createBaseVNode("path", {
		fill: "none",
		stroke: "currentColor",
		"stroke-linecap": "round",
		"stroke-linejoin": "round",
		"stroke-width": "2",
		d: "m5 12l7-7l7 7m-7 7V5"
	}, null, -1)])]);
}
__name(render$2, "render");
var arrow_up_default = markRaw({
	name: "lucide-arrow-up",
	render: render$2
});
//#endregion
//#region ~icons/lucide/square
var _hoisted_1$46 = {
	viewBox: "0 0 24 24",
	width: "1.2em",
	height: "1.2em"
};
function render$1(_ctx, _cache) {
	return openBlock(), createElementBlock("svg", _hoisted_1$46, [..._cache[0] || (_cache[0] = [createBaseVNode("rect", {
		width: "18",
		height: "18",
		x: "3",
		y: "3",
		fill: "none",
		stroke: "currentColor",
		"stroke-linecap": "round",
		"stroke-linejoin": "round",
		"stroke-width": "2",
		rx: "2"
	}, null, -1)])]);
}
__name(render$1, "render");
var square_default = markRaw({
	name: "lucide-square",
	render: render$1
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/AssetThumbnail.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$45 = { class: "flex items-center justify-center" };
var _hoisted_2$37 = [
	"src",
	"alt",
	"aria-hidden"
];
var _hoisted_3$28 = {
	key: 1,
	"aria-hidden": "true",
	class: "flex size-full items-center justify-center overflow-hidden p-1 text-center text-[10px] leading-tight break-all text-foreground"
};
var _hoisted_4$21 = { class: "line-clamp-3" };
var _hoisted_5$16 = [
	"role",
	"aria-label",
	"aria-hidden"
];
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/AssetThumbnail.vue
var AssetThumbnail_default = /* @__PURE__ */ defineComponent({
	__name: "AssetThumbnail",
	props: {
		name: {},
		previewUrl: {},
		mediaKind: {},
		variant: {}
	},
	setup(__props) {
		const kind = computed(() => __props.mediaKind ?? getMediaTypeFromFilename(__props.name));
		const failedUrl = ref();
		function onImageError(event) {
			if (event.target instanceof HTMLImageElement && event.target.getAttribute("src") === __props.previewUrl) failedUrl.value = event.target.getAttribute("src") ?? void 0;
		}
		const showNameTile = computed(() => __props.variant === "tray" && kind.value === "image");
		const isMediaIcon = computed(() => kind.value === "audio" || kind.value === "video");
		const mediaLabel = computed(() => kind.value === "audio" ? "sideToolbar.mediaAssets.filterAudio" : "sideToolbar.mediaAssets.filterVideo");
		const iconSize = computed(() => ({
			tray: "size-6 text-muted-foreground",
			menu: "size-3.5",
			inline: "size-3"
		})[__props.variant]);
		const icon = computed(() => {
			if (__props.variant !== "tray" && !isMediaIcon.value) return "icon-[lucide--paperclip]";
			return kind.value === "other" ? "icon-[lucide--file]" : iconForMediaType(kind.value);
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("span", _hoisted_1$45, [__props.previewUrl && __props.previewUrl !== failedUrl.value && (kind.value === "image" || kind.value === "video") ? (openBlock(), createElementBlock("img", {
				key: __props.previewUrl,
				src: __props.previewUrl,
				alt: __props.variant === "tray" ? __props.name : "",
				"aria-hidden": __props.variant !== "tray" || void 0,
				class: "size-full rounded-sm object-cover",
				onError: onImageError
			}, null, 40, _hoisted_2$37)) : showNameTile.value ? (openBlock(), createElementBlock("span", _hoisted_3$28, [createBaseVNode("span", _hoisted_4$21, toDisplayString(__props.name), 1)])) : (openBlock(), createElementBlock("span", {
				key: 2,
				role: isMediaIcon.value ? "img" : void 0,
				"aria-label": isMediaIcon.value ? _ctx.$t(mediaLabel.value) : void 0,
				"aria-hidden": !isMediaIcon.value || void 0,
				class: normalizeClass(unref(cn)(icon.value, "shrink-0", iconSize.value))
			}, null, 10, _hoisted_5$16))]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/inlineReferenceChipStyles.ts
var inlineReferenceChipClass = cn(tagVariants({
	interactive: true,
	removable: true
}), "group/inline-reference h-4 p-0 align-middle whitespace-nowrap");
var inlineReferenceRemoveAnchorClass = "relative inline-block h-4 w-0 align-middle";
var inlineReferenceRemoveButtonClass = cn(buttonVariants({
	variant: "textonly",
	size: "icon-sm"
}), tagRemoveButtonVariants(), "pointer-events-none absolute -top-2 -right-2 z-10 flex size-5 cursor-pointer items-center justify-center rounded-full p-0 text-foreground opacity-0 transition-opacity group-focus-within/inline-reference:pointer-events-auto group-focus-within/inline-reference:opacity-100 group-hover/inline-reference:pointer-events-auto group-hover/inline-reference:opacity-100 touch:pointer-events-auto touch:opacity-100");
var inlineReferenceRemoveBadgeClass = "flex size-3 items-center justify-center rounded-full bg-background ring-1 ring-border hover:bg-accent";
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/InlineAssetReference.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$44 = { class: "max-w-56 min-w-0 truncate" };
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/InlineAssetReference.vue
var InlineAssetReference_default = /* @__PURE__ */ defineComponent({
	__name: "InlineAssetReference",
	props: {
		name: {},
		previewUrl: {},
		mediaKind: {},
		removeLabel: {}
	},
	emits: ["remove", "highlight"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const chip = useTemplateRef("chip");
		const hovered = useElementHover(chip);
		const { focused } = useFocusWithin(chip);
		watch(() => hovered.value || focused.value, (active) => emit("highlight", active));
		onBeforeUnmount(() => emit("highlight", false));
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("span", {
				ref_key: "chip",
				ref: chip,
				"data-testid": "asset-reference-chip",
				tabindex: "0",
				class: normalizeClass(unref(inlineReferenceChipClass))
			}, [
				createVNode(AssetThumbnail_default, {
					name: __props.name,
					"preview-url": __props.previewUrl,
					"media-kind": __props.mediaKind,
					variant: "inline",
					class: "size-4 shrink-0"
				}, null, 8, [
					"name",
					"preview-url",
					"media-kind"
				]),
				createBaseVNode("span", _hoisted_1$44, toDisplayString(__props.name), 1),
				createBaseVNode("span", { class: normalizeClass(unref(inlineReferenceRemoveAnchorClass)) }, [createVNode(Button_default, {
					type: "button",
					variant: "textonly",
					size: "icon-sm",
					"aria-label": __props.removeLabel,
					class: normalizeClass(unref(inlineReferenceRemoveButtonClass)),
					onClick: _cache[0] || (_cache[0] = withModifiers(($event) => emit("remove"), ["stop"]))
				}, {
					default: withCtx(() => [createBaseVNode("span", { class: normalizeClass(unref(inlineReferenceRemoveBadgeClass)) }, [..._cache[1] || (_cache[1] = [createBaseVNode("span", {
						"aria-hidden": "true",
						class: "icon-[lucide--x] size-2"
					}, null, -1)])], 2)]),
					_: 1
				}, 8, ["aria-label", "class"])], 2)
			], 2);
		};
	}
});
//#endregion
//#region src/components/ui/hover-card/HoverCard.vue
var HoverCard_default = /* @__PURE__ */ defineComponent({
	__name: "HoverCard",
	props: {
		defaultOpen: { type: Boolean },
		open: { type: Boolean },
		openDelay: {},
		closeDelay: {},
		enableTouch: { type: Boolean }
	},
	emits: ["update:open"],
	setup(__props, { emit: __emit }) {
		const forwarded = useForwardPropsEmits(__props, __emit);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(HoverCardRoot_default), normalizeProps(guardReactiveProps(unref(forwarded))), {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
				_: 3
			}, 16);
		};
	}
});
//#endregion
//#region src/components/ui/hover-card/HoverCardContent.vue
var HoverCardContent_default = /* @__PURE__ */ defineComponent({
	__name: "HoverCardContent",
	props: {
		forceMount: { type: Boolean },
		memoDependencies: {},
		side: { default: "bottom" },
		sideOffset: { default: 8 },
		sideFlip: { type: Boolean },
		align: {},
		alignOffset: {},
		alignFlip: { type: Boolean },
		avoidCollisions: { type: Boolean },
		collisionBoundary: {},
		collisionPadding: {},
		arrowPadding: {},
		hideShiftedArrow: { type: Boolean },
		sticky: {},
		hideWhenDetached: { type: Boolean },
		positionStrategy: {},
		updatePositionStrategy: {},
		disableUpdateOnLayoutShift: { type: Boolean },
		prioritizePosition: { type: Boolean },
		reference: {},
		dir: {},
		asChild: { type: Boolean },
		as: {},
		class: { type: [
			Boolean,
			null,
			String,
			Object,
			Array
		] }
	},
	setup(__props) {
		const rest = createPropsRestProxy(__props, [
			"class",
			"side",
			"sideOffset"
		]);
		const forwarded = useForwardProps(computed(() => rest));
		const { open } = injectHoverCardRootContext();
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(HoverCardPortal_default), { key: Number(rest.forceMount || unref(open)) }, {
				default: withCtx(() => [createVNode(unref(HoverCardContent_default$1), mergeProps(unref(forwarded), {
					side: __props.side,
					"side-offset": __props.sideOffset,
					class: unref(cn)("z-overlay rounded-lg border border-border/50 bg-secondary p-2.5 shadow-md outline-none", __props.class)
				}), {
					default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
					_: 3
				}, 16, [
					"side",
					"side-offset",
					"class"
				])]),
				_: 3
			});
		};
	}
});
//#endregion
//#region src/components/ui/hover-card/HoverCardTrigger.vue
var HoverCardTrigger_default = /* @__PURE__ */ defineComponent({
	__name: "HoverCardTrigger",
	props: {
		reference: {},
		asChild: { type: Boolean },
		as: {}
	},
	setup(__props) {
		const forwarded = useForwardProps(__props);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(HoverCardTrigger_default$1), normalizeProps(guardReactiveProps(unref(forwarded))), {
				default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
				_: 3
			}, 16);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/SkillHoverPreview.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$43 = {
	role: "tooltip",
	class: "flex flex-col gap-2 text-xs/4 font-normal wrap-anywhere text-muted-foreground"
};
var _hoisted_2$36 = {
	key: 0,
	class: "flex items-start gap-1.5"
};
var _hoisted_3$27 = {
	key: 1,
	class: "whitespace-pre-wrap"
};
//#endregion
//#region src/workbench/extensions/agent/components/agent/SkillHoverPreview.vue
var SkillHoverPreview_default = /* @__PURE__ */ defineComponent({
	__name: "SkillHoverPreview",
	props: {
		description: {},
		unavailable: {
			type: Boolean,
			default: false
		}
	},
	setup(__props) {
		const { t } = useI18n();
		return (_ctx, _cache) => {
			return openBlock(), createBlock(HoverCard_default, {
				"open-delay": 250,
				"close-delay": 150
			}, {
				default: withCtx(() => [createVNode(HoverCardTrigger_default, { "as-child": "" }, {
					default: withCtx(() => [renderSlot(_ctx.$slots, "default")]),
					_: 3
				}), __props.description || __props.unavailable ? (openBlock(), createBlock(HoverCardContent_default, {
					key: 0,
					side: "top",
					align: "start",
					"collision-padding": 16,
					class: "w-62.5 max-w-[calc(100vw-2rem)] rounded-[10px] bg-background"
				}, {
					default: withCtx(() => [createBaseVNode("div", _hoisted_1$43, [__props.unavailable ? (openBlock(), createElementBlock("div", _hoisted_2$36, [_cache[0] || (_cache[0] = createBaseVNode("i", {
						class: "mt-0.5 icon-[lucide--circle-minus] size-3 shrink-0",
						"aria-hidden": "true"
					}, null, -1)), createBaseVNode("span", null, toDisplayString(unref(t)("agent.skillNotAvailable")), 1)])) : (openBlock(), createElementBlock("span", _hoisted_3$27, toDisplayString(__props.description), 1))])]),
					_: 1
				})) : createCommentVNode("", true)]),
				_: 3
			});
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/SkillReference.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$42 = [
	"data-skill-name",
	"data-skill-description",
	"aria-description"
];
//#endregion
//#region src/workbench/extensions/agent/components/agent/SkillReference.vue
var SkillReference_default = /* @__PURE__ */ defineComponent({
	__name: "SkillReference",
	props: {
		skill: {},
		unavailable: {
			type: Boolean,
			default: false
		}
	},
	setup(__props) {
		const { t } = useI18n();
		return (_ctx, _cache) => {
			return openBlock(), createBlock(SkillHoverPreview_default, {
				description: __props.skill.description,
				unavailable: __props.unavailable
			}, {
				default: withCtx(() => [createBaseVNode("span", {
					"data-testid": "skill-reference",
					"data-comfy-skill": "1",
					"data-skill-name": __props.skill.name,
					"data-skill-description": __props.skill.description,
					tabindex: "0",
					"aria-description": __props.unavailable ? unref(t)("agent.skillNotAvailable") : __props.skill.description || void 0,
					class: normalizeClass(unref(cn)("cursor-pointer underline underline-offset-2", __props.unavailable ? "text-muted-foreground" : "text-warning"))
				}, toDisplayString(`/${__props.skill.name}`), 11, _hoisted_1$42)]),
				_: 1
			}, 8, ["description", "unavailable"]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/CatalogSkillReference.vue
var CatalogSkillReference_default = /* @__PURE__ */ defineComponent({
	__name: "CatalogSkillReference",
	props: {
		skill: {},
		scope: {}
	},
	setup(__props) {
		const skills = useSkillPacksStore();
		const unavailable = computed(() => (__props.scope === void 0 || __props.scope === skills.scope) && skills.enabled && skills.catalogConfirmed && !skills.packs.some((pack) => pack.name === __props.skill.name));
		return (_ctx, _cache) => {
			return openBlock(), createBlock(SkillReference_default, {
				skill: __props.skill,
				unavailable: unavailable.value
			}, null, 8, ["skill", "unavailable"]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/ComposerSkillReference.vue
var ComposerSkillReference_default = /* @__PURE__ */ defineComponent({
	__name: "ComposerSkillReference",
	props: { skill: {} },
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createBlock(CatalogSkillReference_default, {
				skill: __props.skill,
				scope: __props.skill.scope
			}, null, 8, ["skill", "scope"]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/inlinePrompt.ts
function isSkillName(name) {
	return name.length <= 64 && PACK_NAME_PATTERN.test(name);
}
/** Typing opens the skill menu only at the text start or after whitespace. */
function pastedSkillCommand(doc, position, text) {
	if (!/(?:^|\s)$/.test(doc.textBetween(0, position, "", ""))) return;
	const match = /^\/(\S+)(?=\s|$)/.exec(text);
	if (!match || !isSkillName(match[1])) return;
	return {
		name: match[1],
		suffix: text.slice(match[0].length)
	};
}
var inlinePromptSchema = new Schema({ nodes: {
	doc: {
		content: "inline*",
		whitespace: "pre"
	},
	text: { group: "inline" },
	skill: {
		group: "inline",
		inline: true,
		atom: true,
		attrs: {
			name: {},
			description: {},
			scope: {},
			resolvePastedName: { default: false }
		},
		toDOM: (node) => [
			"span",
			{
				"data-comfy-skill": "1",
				"data-skill-name": node.attrs.name,
				"data-skill-description": node.attrs.description
			},
			`/${node.attrs.name}`
		],
		parseDOM: [{
			tag: "span[data-comfy-skill=\"1\"]",
			getAttrs(element) {
				const name = element.getAttribute("data-skill-name");
				const description = element.getAttribute("data-skill-description");
				return name && isSkillName(name) && description !== null && codePointLength(description) <= 1024 && element.textContent === `/${name}` ? {
					name,
					description,
					scope: ""
				} : false;
			}
		}]
	},
	workflow: {
		group: "inline",
		inline: true,
		atom: true,
		attrs: {
			id: {},
			name: {},
			unavailable: { default: false }
		},
		toDOM: (node) => [
			"span",
			{
				"data-comfy-workflow": "1",
				"data-workflow-id": node.attrs.id,
				"data-workflow-unavailable": String(node.attrs.unavailable)
			},
			node.attrs.name
		],
		parseDOM: [{
			tag: "span[data-comfy-workflow=\"1\"]",
			getAttrs(element) {
				const id = element.getAttribute("data-workflow-id")?.trim();
				const name = element.textContent;
				return id && name.trim() ? {
					id,
					name,
					unavailable: element.getAttribute("data-workflow-unavailable") === "true"
				} : false;
			}
		}]
	},
	node: {
		group: "inline",
		inline: true,
		atom: true,
		attrs: {
			id: {},
			name: {},
			scope: {},
			locatorId: { default: null }
		},
		toDOM: (node) => [
			"span",
			{ "data-node-id": node.attrs.id },
			nodeReferenceText(`${node.attrs.name} #${node.attrs.id}`)
		]
	},
	asset: {
		group: "inline",
		inline: true,
		atom: true,
		attrs: {
			id: {},
			name: {},
			ref: {},
			previewUrl: { default: null },
			mediaUrl: { default: null },
			mediaKind: { default: null },
			uploading: { default: false }
		},
		toDOM: (node) => [
			"span",
			{ "data-asset-id": node.attrs.id },
			assetReferenceText(node.attrs.name)
		]
	}
} });
function promptReferenceNode(reference) {
	switch (reference.kind) {
		case "skill": return inlinePromptSchema.nodes.skill.create({
			name: reference.name,
			description: reference.description,
			scope: reference.scope,
			resolvePastedName: reference.resolvePastedName === true
		});
		case "workflow": return inlinePromptSchema.nodes.workflow.create({
			id: reference.id,
			name: reference.name,
			unavailable: reference.unavailable === true
		});
		case "node": return inlinePromptSchema.nodes.node.create({
			id: reference.node.id,
			name: reference.node.title,
			locatorId: reference.node.locatorId,
			scope: reference.scope
		});
		case "asset": return inlinePromptSchema.nodes.asset.create({ ...reference.attachment });
	}
}
function promptDocument(prompt) {
	const content = [];
	let offset = 0;
	for (const reference of prompt.references) {
		const next = Math.max(offset, Math.min(prompt.text.length, reference.textOffset));
		if (next > offset) content.push(inlinePromptSchema.text(prompt.text.slice(offset, next)));
		content.push(promptReferenceNode(reference));
		offset = next;
	}
	if (offset < prompt.text.length) content.push(inlinePromptSchema.text(prompt.text.slice(offset)));
	return inlinePromptSchema.nodes.doc.create(null, content);
}
function assetNodeReference(node, id, name, textOffset) {
	const { ref, previewUrl, mediaUrl, uploading } = node.attrs;
	const mediaKind = zMediaKindSchema.safeParse(node.attrs.mediaKind).data;
	if (typeof ref !== "string") return;
	return {
		kind: "asset",
		textOffset,
		attachment: {
			id,
			name,
			ref,
			...typeof previewUrl === "string" ? { previewUrl } : {},
			...typeof mediaUrl === "string" ? { mediaUrl } : {},
			...mediaKind ? { mediaKind } : {},
			...uploading === true ? { uploading: true } : {}
		}
	};
}
function skillNodeReference(node, textOffset) {
	const { name, description, scope, resolvePastedName } = node.attrs;
	if (typeof name !== "string" || typeof description !== "string" || typeof scope !== "string") return;
	return {
		kind: "skill",
		name,
		description,
		scope,
		textOffset,
		...resolvePastedName === true ? { resolvePastedName: true } : {}
	};
}
function promptNodeReference(node, textOffset) {
	if (node.type === inlinePromptSchema.nodes.skill) return skillNodeReference(node, textOffset);
	const { id, name } = node.attrs;
	if (typeof id !== "string" || typeof name !== "string") return;
	if (node.type.name === "workflow") return {
		kind: "workflow",
		id,
		name,
		textOffset,
		...node.attrs.unavailable === true ? { unavailable: true } : {}
	};
	if (node.type.name === "node") {
		const { scope, locatorId } = node.attrs;
		if (typeof scope !== "string") return;
		return {
			kind: "node",
			scope,
			textOffset,
			node: {
				id,
				title: name,
				...isNodeLocatorId(locatorId) ? { locatorId } : {}
			}
		};
	}
	if (node.type.name === "asset") return assetNodeReference(node, id, name, textOffset);
}
function promptDraft(doc) {
	let text = "";
	const references = [];
	doc.forEach((node) => {
		if (node.isText) text += node.text;
		else {
			const reference = promptNodeReference(node, text.length);
			if (reference) references.push(reference);
		}
	});
	return {
		text,
		references
	};
}
function promptTextOffset(doc, position) {
	return doc.textBetween(0, position, "", "").length;
}
function promptInsertionPoint(doc, position) {
	let referenceIndex = 0;
	doc.forEach((node, offset) => {
		if (!node.isText && offset < position) referenceIndex++;
	});
	return {
		textOffset: promptTextOffset(doc, position),
		referenceIndex
	};
}
function promptDocumentPosition(doc, textOffset) {
	let text = 0;
	let position = 0;
	doc.forEach((node, offset) => {
		if (node.isText && textOffset >= text && textOffset <= text + node.nodeSize) position = offset + textOffset - text;
		else if (!node.isText && textOffset === text) position = offset + node.nodeSize;
		if (node.isText) text += node.nodeSize;
	});
	return position;
}
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/InlinePromptEditor.vue
var InlinePromptEditor_default = /* @__PURE__ */ defineComponent({
	inheritAttrs: false,
	__name: "InlinePromptEditor",
	props: /*@__PURE__*/ mergeModels({
		label: {},
		expanded: {
			type: Boolean,
			default: false
		},
		activeDescendant: {},
		historyEpoch: { default: 0 },
		editableWorkflowId: {},
		skillScope: { default: "" },
		searchHint: {}
	}, {
		"modelValue": { default: () => ({
			text: "",
			references: []
		}) },
		"modelModifiers": {}
	}),
	emits: /*@__PURE__*/ mergeModels([
		"input",
		"resolveSkillMetadata",
		"selectionChange",
		"keydown",
		"keyup",
		"click",
		"blur",
		"attachFiles",
		"openReferenceWorkflow",
		"removeWorkflowReference",
		"removeNodeReference",
		"highlightAssets"
	], ["update:modelValue"]),
	setup(__props, { expose: __expose, emit: __emit }) {
		const model = useModel(__props, "modelValue");
		const emit = __emit;
		const { t } = useI18n();
		const skillPacks = useSkillPacksStore();
		const appContext = getCurrentInstance()?.appContext;
		const host = useTemplateRef("host");
		let view;
		const activeAssetReferences = /* @__PURE__ */ new Map();
		const insertions = /* @__PURE__ */ new Set();
		const plugins = [
			history(),
			keymap({
				"Mod-z": undo,
				"Mod-Shift-z": redo,
				"Mod-y": redo,
				ArrowRight: (state, dispatch) => {
					if (state.selection.empty) return false;
					dispatch?.(state.tr.setSelection(TextSelection.create(state.doc, state.selection.to)));
					return true;
				},
				ArrowLeft: (state, dispatch) => {
					if (state.selection.empty) return false;
					dispatch?.(state.tr.setSelection(TextSelection.create(state.doc, state.selection.from)));
					return true;
				},
				"Shift-Enter": (state, dispatch) => {
					dispatch?.(state.tr.insertText("\n").scrollIntoView());
					return true;
				}
			}),
			keymap(baseKeymap)
		];
		function createState() {
			return EditorState.create({
				doc: promptDocument(model.value),
				plugins
			});
		}
		function deleteReference(state, position, node) {
			const end = position + node.nodeSize;
			const padding = state.doc.nodeAt(end)?.text?.startsWith(" ") ? 1 : 0;
			return state.tr.delete(position, end + padding);
		}
		function referenceClipboardText(node) {
			const reference = promptNodeReference(node, 0);
			if (!reference) return "";
			const name = composerReferenceName(reference);
			if (reference.kind === "skill") return `/${name}`;
			if (reference.kind === "workflow") return `@[Workflow: ${name}]`;
			return reference.kind === "node" ? nodeReferenceText(name) : assetReferenceText(name);
		}
		function resolvePastedSkillDescription() {
			if (!view || !skillPacks.enabled || !skillPacks.catalogConfirmed) return;
			const transaction = view.state.tr;
			view.state.doc.forEach((node, position) => {
				if (!node.attrs.resolvePastedName || node.attrs.scope !== skillPacks.scope) return;
				const pack = skillPacks.packs.find((pack) => pack.name === node.attrs.name);
				if (pack) transaction.setNodeMarkup(position, void 0, {
					...node.attrs,
					description: pack.description,
					resolvePastedName: false
				});
			});
			if (transaction.docChanged) view.dispatch(transaction.setMeta("addToHistory", false).setMeta("resolveSkillMetadata", true));
		}
		function insertPastedContent(editor, clipboard, slice, text) {
			const { state } = editor;
			const hasReferences = slice.content.content.some((node) => node.type === inlinePromptSchema.nodes.workflow || node.type === inlinePromptSchema.nodes.skill);
			let hasSkill = false;
			state.doc.forEach((node, position) => {
				if (node.type === inlinePromptSchema.nodes.skill && (position < state.selection.from || position >= state.selection.to)) hasSkill = true;
			});
			if (!hasReferences) {
				const leading = pastedSkillCommand(state.doc, state.selection.from, text);
				if (leading && !hasSkill && skillPacks.enabled) {
					const { name, suffix } = leading;
					const pack = skillPacks.catalogConfirmed ? skillPacks.packs.find((pack) => pack.name === name) : void 0;
					const description = pack?.description ?? "";
					const content = [inlinePromptSchema.nodes.skill.create({
						name,
						description,
						scope: __props.skillScope,
						resolvePastedName: !pack
					})];
					if (suffix) content.push(inlinePromptSchema.text(suffix));
					editor.dispatch(closeHistory(state.tr).replaceSelection(new Slice(Fragment$1.from(content), 0, 0)).setMeta("paste", true).setMeta("uiEvent", "paste").scrollIntoView());
				} else editor.dispatch(closeHistory(state.tr).insertText(text).setMeta("paste", true).setMeta("uiEvent", "paste").scrollIntoView());
				editor.dispatch(closeHistory(editor.state.tr));
				return;
			}
			const usedIds = /* @__PURE__ */ new Set([__props.editableWorkflowId]);
			state.doc.forEach((node, position) => {
				if (node.type === inlinePromptSchema.nodes.workflow && (position < state.selection.from || position >= state.selection.to)) usedIds.add(node.attrs.id);
			});
			const content = DOMParser$1.fromSchema(inlinePromptSchema).parseSlice(purify.sanitize(clipboard.getData("text/html"), { RETURN_DOM_FRAGMENT: true }), { preserveWhitespace: "full" }).content.content.map((node) => {
				if (node.type === inlinePromptSchema.nodes.skill) {
					if (hasSkill || !skillPacks.enabled) return inlinePromptSchema.text(referenceClipboardText(node));
					hasSkill = true;
					return inlinePromptSchema.nodes.skill.create({
						name: node.attrs.name,
						description: node.attrs.description,
						scope: __props.skillScope
					});
				}
				if (node.type !== inlinePromptSchema.nodes.workflow) return node;
				if (usedIds.has(node.attrs.id)) return inlinePromptSchema.text(referenceClipboardText(node));
				usedIds.add(node.attrs.id);
				return node;
			});
			editor.dispatch(closeHistory(state.tr).replaceSelection(new Slice(Fragment$1.from(content), 0, 0)).setMeta("paste", true).setMeta("uiEvent", "paste").scrollIntoView());
			editor.dispatch(closeHistory(editor.state.tr));
		}
		function searchHintDom() {
			const hint = document.createElement("span");
			hint.className = "pointer-events-none text-muted-foreground select-none";
			hint.setAttribute("aria-hidden", "true");
			hint.textContent = __props.searchHint ?? "";
			return hint;
		}
		function assetReferenceView(node, editor, getPos) {
			const dom = document.createElement("span");
			const reference = promptNodeReference(node, 0);
			if (reference?.kind !== "asset") return { dom };
			dom.contentEditable = "false";
			dom.className = "inline-flex rounded-sm align-middle ring-offset-background [&.ProseMirror-selectednode]:ring-2 [&.ProseMirror-selectednode]:ring-foreground [&.ProseMirror-selectednode]:ring-offset-1";
			const vnode = h(InlineAssetReference_default, {
				name: reference.attachment.name,
				previewUrl: reference.attachment.previewUrl,
				mediaKind: reference.attachment.mediaKind,
				removeLabel: t("agent.removeAssetReference", { name: reference.attachment.name }),
				onHighlight: (active) => {
					if (active) activeAssetReferences.set(dom, reference.attachment.id);
					else if (!activeAssetReferences.delete(dom)) return;
					emit("highlightAssets", [...new Set(activeAssetReferences.values())]);
				},
				onRemove: () => {
					const position = getPos();
					if (position === void 0) return;
					editor.dispatch(deleteReference(editor.state, position, node));
					editor.focus();
				}
			});
			vnode.appContext = appContext ?? null;
			render$3(vnode, dom);
			return {
				dom,
				stopEvent: () => true,
				ignoreMutation: () => true,
				destroy: () => render$3(null, dom)
			};
		}
		function nodeReferenceView(node, editor, getPos) {
			const dom = document.createElement("span");
			const reference = promptNodeReference(node, 0);
			if (reference?.kind !== "node") return { dom };
			dom.contentEditable = "false";
			dom.dataset.testid = `${reference.kind}-reference-chip`;
			dom.className = inlineReferenceChipClass;
			dom.tabIndex = 0;
			const icon = document.createElement("span");
			icon.className = "icon-[comfy--node] size-3 shrink-0";
			icon.setAttribute("aria-hidden", "true");
			const label = document.createElement("span");
			label.className = "min-w-0 max-w-56 truncate";
			label.textContent = reference.node.title;
			dom.append(icon, label);
			const id = document.createElement("span");
			id.className = "shrink-0 text-muted-foreground";
			id.textContent = ` #${reference.node.id}`;
			const remove = document.createElement("button");
			remove.type = "button";
			remove.setAttribute("aria-label", t("agent.removeNodeLabel", { node: composerReferenceName(reference) }));
			const removeAnchor = document.createElement("span");
			removeAnchor.className = inlineReferenceRemoveAnchorClass;
			remove.className = inlineReferenceRemoveButtonClass;
			const badge = document.createElement("span");
			badge.className = inlineReferenceRemoveBadgeClass;
			const cross = document.createElement("span");
			cross.className = "icon-[lucide--x] size-2";
			cross.setAttribute("aria-hidden", "true");
			badge.append(cross);
			remove.append(badge);
			remove.onclick = () => {
				const position = getPos();
				if (position === void 0) return;
				editor.dispatch(deleteReference(editor.state, position, node));
				editor.focus();
			};
			removeAnchor.append(remove);
			dom.append(id, removeAnchor);
			return {
				dom,
				stopEvent: () => true,
				ignoreMutation: () => true
			};
		}
		onMounted(() => {
			if (!host.value) return;
			view = new EditorView(host.value, {
				state: createState(),
				attributes: () => ({
					role: "textbox",
					"aria-label": __props.label,
					"aria-multiline": "true",
					"aria-expanded": String(__props.expanded),
					"aria-controls": "agent-reference-menu",
					...__props.activeDescendant ? { "aria-activedescendant": __props.activeDescendant } : {},
					class: "text-foreground w-full flex-1 cursor-text p-3 font-inter text-[14px]/5 font-normal wrap-anywhere whitespace-pre-wrap outline-none"
				}),
				decorations(state) {
					if (state.selection.empty) {
						if (!__props.searchHint) return null;
						return DecorationSet.create(state.doc, [Decoration.widget(state.selection.from, () => searchHintDom(), {
							side: 1,
							key: `search-hint:${__props.searchHint}`
						})]);
					}
					const decorations = [];
					state.doc.nodesBetween(state.selection.from, state.selection.to, (node, position) => {
						if (node.type === inlinePromptSchema.nodes.workflow) decorations.push(Decoration.node(position, position + node.nodeSize, { "data-selected": "true" }));
					});
					return DecorationSet.create(state.doc, decorations);
				},
				dispatchTransaction(transaction) {
					if (!view) return;
					const previousReferences = promptDraft(view.state.doc).references;
					const nextReferences = promptDraft(transaction.doc).references;
					if (!transaction.getMeta("resolveSkillMetadata") && (previousReferences.length !== nextReferences.length || previousReferences.some((reference, index) => composerReferenceKey(reference) !== composerReferenceKey(nextReferences[index])))) closeHistory(transaction);
					for (const insertion of insertions) {
						const collapsed = insertion.from === insertion.to;
						insertion.from = transaction.mapping.map(insertion.from, 1);
						insertion.to = Math.max(insertion.from, transaction.mapping.map(insertion.to, collapsed ? 1 : -1));
					}
					view.updateState(view.state.apply(transaction));
					if (transaction.docChanged) {
						const draft = promptDraft(view.state.doc);
						if (transaction.getMeta("resolveSkillMetadata")) emit("resolveSkillMetadata", draft);
						else model.value = draft;
						for (const previous of previousReferences) {
							if (draft.references.some((reference) => composerReferenceKey(reference) === composerReferenceKey(previous))) continue;
							if (previous.kind === "workflow") emit("removeWorkflowReference", previous.id);
							if (previous.kind === "node") emit("removeNodeReference", selectedNodeKey(previous.node));
						}
						if (!transaction.getMeta("resolveSkillMetadata")) emit("input");
					}
					if (transaction.selectionSet || transaction.docChanged) emit("selectionChange");
					resolvePastedSkillDescription();
				},
				handleKeyDown(editor, event) {
					emit("keydown", event);
					if (!event.defaultPrevented && !event.isComposing && editor.state.selection.empty) {
						const { $from, from } = editor.state.selection;
						const adjacent = event.key === "Backspace" ? $from.nodeBefore : event.key === "Delete" ? $from.nodeAfter : null;
						if (adjacent?.isAtom && !adjacent.isText) {
							const start = event.key === "Backspace" ? from - adjacent.nodeSize : from;
							editor.dispatch(deleteReference(editor.state, start, adjacent).scrollIntoView());
							event.preventDefault();
						}
					}
					return event.defaultPrevented;
				},
				handleDOMEvents: {
					dragenter: () => true,
					dragover: () => true,
					drop: () => true,
					keyup: (_view, event) => {
						emit("keyup", event);
						return false;
					},
					click: () => {
						emit("click");
						return false;
					},
					blur: (_view, event) => {
						emit("blur", event);
						return false;
					}
				},
				transformPastedHTML: (html) => purify.sanitize(html),
				handlePaste(editor, event, slice) {
					const clipboard = event.clipboardData;
					if (!clipboard) return false;
					const files = Array.from(clipboard.files);
					const text = clipboard.getData("text/plain");
					if (!(clipboard.files.length > 0 && text === "")) insertPastedContent(editor, clipboard, slice, text);
					if (files.length > 0) emit("attachFiles", files);
					return true;
				},
				clipboardTextSerializer: (slice) => slice.content.textBetween(0, slice.content.size, "", (node) => referenceClipboardText(node)),
				nodeViews: {
					skill(node) {
						const dom = document.createElement("span");
						const reference = promptNodeReference(node, 0);
						if (reference?.kind !== "skill") return { dom };
						dom.contentEditable = "false";
						dom.className = "rounded-sm [&.ProseMirror-selectednode]:ring-2 [&.ProseMirror-selectednode]:ring-foreground";
						const vnode = h(ComposerSkillReference_default, { skill: reference });
						vnode.appContext = appContext ?? null;
						render$3(vnode, dom);
						return {
							dom,
							stopEvent: () => true,
							ignoreMutation: () => true,
							destroy: () => render$3(null, dom)
						};
					},
					node: (node, editor, getPos) => nodeReferenceView(node, editor, getPos),
					asset: assetReferenceView,
					workflow(node, editor, getPos) {
						const id = node.attrs.id;
						const name = node.attrs.name;
						const dom = document.createElement("span");
						if (typeof id !== "string" || typeof name !== "string") return { dom };
						dom.contentEditable = "false";
						dom.dataset.testid = "workflow-reference-chip";
						dom.className = inlineReferenceChipClass;
						const open = document.createElement("button");
						open.type = "button";
						open.tabIndex = 0;
						const unavailable = node.attrs.unavailable === true;
						open.setAttribute("aria-label", t(unavailable ? "agent.unavailableWorkflowReference" : "agent.openWorkflowTab", { name }));
						if (unavailable) {
							const reason = t("agent.workflowReferenceUnavailableReason");
							open.setAttribute("aria-disabled", "true");
							open.setAttribute("aria-description", reason);
							open.title = reason;
						}
						open.className = "flex min-w-0 cursor-pointer items-center border-none bg-transparent p-0 text-inherit outline-none aria-disabled:cursor-not-allowed";
						const icon = document.createElement("span");
						icon.className = "icon-[comfy--workflow] mr-1 size-3 shrink-0";
						const title = document.createElement("span");
						title.className = "min-w-0 max-w-56 truncate";
						title.textContent = name;
						open.append(icon, title);
						open.onclick = () => {
							if (!unavailable) emit("openReferenceWorkflow", id, name);
						};
						const removeAnchor = document.createElement("span");
						removeAnchor.className = inlineReferenceRemoveAnchorClass;
						const remove = document.createElement("button");
						remove.type = "button";
						remove.setAttribute("aria-label", t("agent.removeWorkflowReference", { name }));
						remove.className = inlineReferenceRemoveButtonClass;
						const badge = document.createElement("span");
						badge.className = inlineReferenceRemoveBadgeClass;
						const cross = document.createElement("span");
						cross.className = "icon-[lucide--x] size-2";
						badge.append(cross);
						remove.append(badge);
						remove.onclick = () => {
							const position = getPos();
							if (position === void 0) return;
							editor.dispatch(deleteReference(editor.state, position, node));
							editor.focus();
						};
						removeAnchor.append(remove);
						dom.append(open, removeAnchor);
						return {
							dom,
							stopEvent: () => true,
							ignoreMutation: () => true
						};
					}
				}
			});
		});
		watch([model, () => __props.historyEpoch], ([next, epoch], [, previousEpoch]) => {
			if (!view) return;
			const doc = promptDocument(next);
			if (epoch !== previousEpoch) {
				insertions.clear();
				const state = createState();
				const position = Math.min(view.state.selection.head, doc.content.size);
				view.updateState(state.apply(state.tr.setSelection(TextSelection.create(state.doc, position))));
				emit("selectionChange");
				return;
			}
			const start = view.state.doc.content.findDiffStart(doc.content);
			if (start === null) return;
			const end = view.state.doc.content.findDiffEnd(doc.content);
			if (!end) return;
			const overlap = Math.max(0, start - Math.min(end.a, end.b));
			const before = promptDraft(view.state.doc);
			const metadataOnly = before.text === next.text && sameComposerReferenceOrder(before, next);
			const transaction = view.state.tr.replace(start, end.a + overlap, doc.slice(start, end.b + overlap));
			view.dispatch(closeHistory(transaction.setMeta("addToHistory", !metadataOnly)));
		}, {
			flush: "post",
			deep: true
		});
		watch(() => [
			__props.label,
			__props.expanded,
			__props.activeDescendant,
			__props.searchHint
		], () => view?.setProps({}));
		watch([() => skillPacks.catalogConfirmed, () => skillPacks.packs], resolvePastedSkillDescription);
		onBeforeUnmount(() => {
			insertions.clear();
			view?.destroy();
			view = void 0;
		});
		function selection() {
			if (!view) return {
				start: 0,
				end: 0
			};
			return {
				start: promptTextOffset(view.state.doc, view.state.selection.from),
				end: promptTextOffset(view.state.doc, view.state.selection.to)
			};
		}
		function insertText(text) {
			if (!view) return;
			view.dispatch(view.state.tr.insertText(text));
		}
		function replaceText(from, to, text) {
			if (!view) return;
			view.dispatch(view.state.tr.insertText(text, promptDocumentPosition(view.state.doc, from), promptDocumentPosition(view.state.doc, to)));
		}
		function captureInsertion(from, to) {
			const insertion = {
				from: view ? from === void 0 ? view.state.selection.from : promptDocumentPosition(view.state.doc, from) : 0,
				to: view ? to === void 0 ? view.state.selection.to : promptDocumentPosition(view.state.doc, to) : 0
			};
			insertions.add(insertion);
			return {
				insert(reference) {
					if (!view || !insertions.delete(insertion)) return;
					const node = inlinePromptSchema.nodes.workflow.create({
						id: reference.id,
						name: reference.name
					});
					const transaction = view.state.tr.replaceWith(insertion.from, insertion.to, node);
					const afterChip = insertion.from + node.nodeSize;
					if (!transaction.doc.nodeAt(afterChip)?.text?.startsWith(" ")) transaction.insertText(" ", afterChip);
					view.dispatch(transaction.setSelection(TextSelection.create(transaction.doc, afterChip + 1)).scrollIntoView());
					view.focus();
				},
				cancel: () => insertions.delete(insertion)
			};
		}
		function selectSkill(reference, from, to) {
			if (!view) return;
			const position = promptDocumentPosition(view.state.doc, from);
			const end = promptTextOffset(view.state.doc, view.state.selection.to) === to ? view.state.selection.to : promptDocumentPosition(view.state.doc, to);
			const node = inlinePromptSchema.nodes.skill.create({
				...reference,
				scope: __props.skillScope
			});
			const transaction = view.state.tr.replaceWith(position, end, node);
			const after = position + node.nodeSize;
			if (!transaction.doc.nodeAt(after)?.text?.startsWith(" ")) transaction.insertText(" ", after);
			transaction.setSelection(TextSelection.create(transaction.doc, after + 1));
			const previous = [];
			transaction.doc.forEach((item, offset) => {
				if (item.type === inlinePromptSchema.nodes.skill && offset !== position) previous.push(offset);
			});
			for (const offset of previous.reverse()) transaction.delete(offset, offset + 1);
			view.dispatch(transaction.scrollIntoView());
			view.focus();
		}
		__expose({
			insertionPoint: () => view ? promptInsertionPoint(view.state.doc, view.state.selection.head) : {
				textOffset: 0,
				referenceIndex: 0
			},
			focus: () => view?.focus(),
			selection,
			insertText,
			replaceText,
			selectSkill,
			captureInsertion
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				ref_key: "host",
				ref: host,
				class: "flex flex-1 flex-col"
			}, null, 512);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/composables/agent/mentionPickerState.ts
function sectionForQuery(state, trigger) {
	if (trigger === "/") return "skills";
	return state.status === "open" && state.section !== "skills" ? state.section : "root";
}
function initialActiveIndex(section, query, firstMatchIndex) {
	if (section === "skills") return query === "" ? -1 : firstMatchIndex;
	return query !== "" || section === "root" ? Math.max(0, firstMatchIndex) : 0;
}
function movedActiveIndex(activeIndex, direction, disabled) {
	const count = disabled.length;
	const from = activeIndex < 0 && direction < 0 ? 0 : activeIndex;
	for (let offset = 1; offset <= count; offset++) {
		const index = (from + direction * offset + count) % count;
		if (!disabled[index]) return index;
	}
	return activeIndex;
}
function openForQuery(state, event) {
	const section = sectionForQuery(state, event.trigger);
	return {
		status: "open",
		section,
		start: event.start,
		query: event.query,
		activeIndex: initialActiveIndex(section, event.query, event.firstMatchIndex)
	};
}
function transitionMentionPicker(state, event) {
	if (event.type === "closed") return { status: "closed" };
	if (event.type === "queryChanged") return openForQuery(state, event);
	if (state.status === "closed") return state;
	switch (event.type) {
		case "sectionSelected": return {
			...state,
			section: event.section,
			query: "",
			activeIndex: 0
		};
		case "back": return {
			...state,
			section: "root",
			activeIndex: 0
		};
		case "nodesUnavailable": return state.section === "nodes" ? {
			...state,
			section: "root",
			activeIndex: Math.max(0, event.firstMatchIndex)
		} : state;
		case "highlighted": return {
			...state,
			activeIndex: event.index
		};
		case "highlightMoved": return {
			...state,
			activeIndex: movedActiveIndex(state.activeIndex, event.direction, event.disabled)
		};
	}
}
//#endregion
//#region src/workbench/extensions/agent/composables/agent/useAgentMentionPicker.ts
var SKILL_QUERY = /^[A-Za-z0-9._-]*$/;
function triggerStart(text, caret, trigger) {
	const start = text.lastIndexOf(trigger, caret - 1);
	if (start < 0 || start >= caret) return -1;
	if (start > 0 && !/\s/.test(text[start - 1])) return -1;
	return text.slice(start + 1, caret).includes("\n") ? -1 : start;
}
function skillTriggerStart(text, caret) {
	const start = triggerStart(text, caret, "/");
	return start >= 0 && SKILL_QUERY.test(text.slice(start + 1, caret)) ? start : -1;
}
function useAgentMentionPicker(options) {
	const { t } = useI18n();
	const graphNodes = computed(() => options.nodeReferenceDisabledReason() ? [] : [...options.getMentionNodes()].sort((a, b) => a.title.localeCompare(b.title)));
	const mention = ref({ status: "closed" });
	const mentionSection = computed(() => mention.value.status === "open" ? mention.value.section : "root");
	const mentionQuery = computed(() => mention.value.status === "open" ? mention.value.query : null);
	const mentionActive = computed(() => mention.value.status === "open" ? mention.value.activeIndex : 0);
	const stagedKeys = computed(() => new Set(options.selectionTags().map((tag) => selectedNodeKey(tag))));
	function getMentionMatches(section, query) {
		const search = query.toLowerCase();
		if (section === "skills") return options.skills().filter(({ name }) => name.toLowerCase().includes(search)).map((skill) => ({
			kind: "skill",
			id: skill.name,
			label: skill.name,
			skill
		}));
		if (section === "root") {
			const sections = [{
				kind: "section",
				id: "nodes",
				label: t("agent.nodes")
			}, {
				kind: "section",
				id: "workflows",
				label: t("agent.workflows")
			}];
			return [...options.assets().filter((asset) => asset.name.toLowerCase().includes(search)).map((asset) => ({
				kind: "asset",
				id: asset.id,
				label: asset.name,
				asset
			})), ...sections.filter(({ label }) => label.toLowerCase().includes(search))];
		}
		const back = {
			kind: "back",
			id: "back",
			label: t("g.back")
		};
		if (section === "nodes") return [back, ...graphNodes.value.filter((node) => !stagedKeys.value.has(selectedNodeKey(node)) && (node.title.toLowerCase().includes(search) || node.id.includes(search))).map((node) => ({
			kind: "node",
			id: selectedNodeKey(node),
			label: node.title,
			node
		}))];
		return [back, ...options.workflows().filter(({ name }) => name.toLowerCase().includes(search)).map((workflow) => ({
			kind: "workflow",
			id: workflow.id ?? workflow.tabPath,
			label: workflow.name,
			workflow
		}))];
	}
	const mentionMatches = computed(() => {
		const query = mentionQuery.value;
		return query === null ? [] : getMentionMatches(mentionSection.value, query);
	});
	const mentionVisible = computed(() => mentionQuery.value !== null && (mentionSection.value === "skills" || mentionQuery.value === "" || mentionMatches.value.some((match) => match.kind !== "back" && !isNodeReferenceDisabled(match))));
	const mentionActiveNode = computed(() => {
		if (!mentionVisible.value) return void 0;
		const match = mentionMatches.value.at(mentionActive.value);
		return match?.kind === "node" ? match.node : void 0;
	});
	const skillQueryEmpty = computed(() => mentionSection.value === "skills" && mentionQuery.value === "");
	const mentionHasResults = computed(() => mentionSection.value === "skills" ? mentionMatches.value.length > 0 : mentionSection.value === "root" || mentionMatches.value.length > 1);
	function duplicatedTitles(nodes) {
		const seen = /* @__PURE__ */ new Set();
		const dupes = /* @__PURE__ */ new Set();
		for (const node of nodes) if (seen.has(node.title)) dupes.add(node.title);
		else seen.add(node.title);
		return dupes;
	}
	const graphDupes = computed(() => duplicatedTitles(graphNodes.value));
	function dispatchMention(event) {
		mention.value = transitionMentionPicker(mention.value, event);
	}
	function firstMentionMatchIndex(section, query) {
		return getMentionMatches(section, query).findIndex((match) => match.kind !== "back" && !isNodeReferenceDisabled(match));
	}
	function updateMentionQuery(trigger, start, query) {
		dispatchMention({
			type: "queryChanged",
			start,
			query,
			trigger,
			firstMatchIndex: firstMentionMatchIndex(trigger === "/" ? "skills" : mentionSection.value === "skills" ? "root" : mentionSection.value, query)
		});
	}
	function mentionTrigger(text, caret, collapsed) {
		const at = triggerStart(text, caret, "@");
		const slash = collapsed && options.skillsEnabled() ? skillTriggerStart(text, caret) : -1;
		const state = mention.value;
		const atOpen = state.status === "open" && state.section !== "skills";
		if (at >= 0 && (atOpen || at > slash)) return {
			trigger: "@",
			start: at
		};
		return slash >= 0 ? {
			trigger: "/",
			start: slash
		} : void 0;
	}
	function syncMention() {
		const selection = options.editor()?.selection();
		const caret = selection?.start ?? 0;
		const text = options.draft();
		const open = mentionTrigger(text, caret, selection?.end === caret);
		if (!open) {
			dispatchMention({ type: "closed" });
			return;
		}
		updateMentionQuery(open.trigger, open.start, text.slice(open.start + 1, caret));
	}
	watch(() => options.skills(), (_next, previous) => {
		const state = mention.value;
		if (state.status !== "open" || state.section !== "skills" || state.activeIndex < 0) return;
		const selected = previous.filter(({ name }) => name.toLowerCase().includes(state.query.toLowerCase())).at(state.activeIndex);
		const index = getMentionMatches("skills", state.query).findIndex((match) => match.id === selected?.name);
		dispatchMention({
			type: "highlighted",
			index: index >= 0 ? index : firstMentionMatchIndex("skills", state.query)
		});
	}, { flush: "sync" });
	function isNodeReferenceDisabled(match) {
		return !!options.nodeReferenceDisabledReason() && (match.kind === "node" || match.kind === "section" && match.id === "nodes");
	}
	watch(() => options.nodeReferenceDisabledReason(), (reason) => {
		if (!reason) return;
		if (mention.value.status === "open" && mention.value.section === "nodes") dispatchMention({
			type: "nodesUnavailable",
			firstMatchIndex: firstMentionMatchIndex("root", mention.value.query)
		});
	}, { flush: "sync" });
	watch(() => options.skillsEnabled(), (enabled) => {
		if (!enabled && mentionSection.value === "skills") dispatchMention({ type: "closed" });
		else if (enabled) syncMention();
	}, { flush: "sync" });
	function selectMentionSection(section, from, to) {
		options.editor()?.replaceText(from, to, "");
		dispatchMention({
			type: "sectionSelected",
			section
		});
		if (section === "workflows") options.requestWorkflows();
	}
	async function pickMention(match) {
		const state = mention.value;
		if (state.status === "closed" || isMentionDisabled(match)) return;
		if (match.kind === "section") {
			selectMentionSection(match.id, state.start + 1, state.start + 1 + state.query.length);
			return;
		}
		if (match.kind === "back") {
			dispatchMention({ type: "back" });
			return;
		}
		if (match.kind === "skill") {
			options.editor()?.selectSkill(match.skill, state.start, state.start + 1 + state.query.length);
			dispatchMention({ type: "closed" });
			return;
		}
		if (match.kind === "workflow") {
			if (await options.selectWorkflow(match.workflow, state.start, state.start + 1 + state.query.length)) dispatchMention({ type: "closed" });
			return;
		}
		options.editor()?.replaceText(state.start, state.start + 1 + state.query.length, "");
		if (match.kind === "asset") options.pickAsset(match.asset);
		else options.pickNode(match.node);
		dispatchMention({ type: "closed" });
		options.editor()?.focus();
	}
	function isMentionDisabled(match) {
		return isNodeReferenceDisabled(match) || match.kind === "workflow" && options.workflowSelecting();
	}
	function onComposerKeydown(event) {
		const state = mention.value;
		if (state.status === "open" && mentionVisible.value && !event.isComposing && !event.shiftKey) {
			const matches = mentionMatches.value;
			if (event.key === "ArrowDown" || event.key === "ArrowUp") {
				event.preventDefault();
				dispatchMention({
					type: "highlightMoved",
					direction: event.key === "ArrowDown" ? 1 : -1,
					disabled: matches.map(isMentionDisabled)
				});
				return true;
			}
			if (event.key === "Enter" || event.key === "Tab") {
				event.preventDefault();
				const match = state.activeIndex < 0 ? void 0 : matches.at(state.activeIndex);
				if (match) pickMention(match);
				return true;
			}
			if (event.key === "Escape") {
				event.stopPropagation();
				dispatchMention({ type: "closed" });
				return true;
			}
		}
		return false;
	}
	const CARET_KEYS = [
		"ArrowLeft",
		"ArrowRight",
		"Home",
		"End"
	];
	function onComposerKeyup(event) {
		if (mention.value.status === "open" && CARET_KEYS.includes(event.key)) syncMention();
	}
	return {
		mentionSection,
		mentionActive,
		mentionMatches,
		mentionVisible,
		mentionActiveNode,
		mentionHasResults,
		skillQueryEmpty,
		graphDupes,
		syncMention,
		pickMention,
		isNodeReferenceDisabled,
		isMentionDisabled,
		onComposerKeydown,
		onComposerKeyup,
		close: () => dispatchMention({ type: "closed" }),
		highlight: (index) => dispatchMention({
			type: "highlighted",
			index
		})
	};
}
//#endregion
//#region src/workbench/extensions/agent/composables/agent/useSkillMenuDescription.ts
var SHOW_DELAY_MS = 250;
var HOVER_CLOSE_DELAY_MS = 150;
function useSkillMenuDescription(activeSkill) {
	const trigger = ref();
	const ready = ref(false);
	let closeTimer;
	watch(() => trigger.value ? activeSkill()?.name : void 0, (name, _previous, onCleanup) => {
		ready.value = false;
		if (!name) return;
		const timer = setTimeout(() => {
			ready.value = true;
		}, SHOW_DELAY_MS);
		onCleanup(() => clearTimeout(timer));
	});
	function keepOpen() {
		clearTimeout(closeTimer);
	}
	onScopeDispose(keepOpen);
	return {
		describedSkill: computed(() => ready.value && trigger.value ? activeSkill() : void 0),
		requestDescription(source) {
			keepOpen();
			trigger.value = source;
		},
		dismissDescription() {
			keepOpen();
			trigger.value = void 0;
		},
		leaveDescription() {
			if (trigger.value !== "hover") return;
			keepOpen();
			closeTimer = setTimeout(() => {
				trigger.value = void 0;
			}, HOVER_CLOSE_DELAY_MS);
		},
		keepDescriptionOpen: keepOpen
	};
}
//#endregion
//#region src/workbench/extensions/agent/composables/agent/useWorkflowReferencePicker.ts
function useWorkflowReferencePicker(options) {
	const eligibleWorkflows = computed(() => {
		const selectedIds = new Set(options.references().map(({ id }) => id));
		return options.workflows().filter(({ id }) => id === void 0 || id !== options.editableWorkflowId() && !selectedIds.has(id));
	});
	async function selectWorkflow(workflow, from, to) {
		if (options.selecting()) return false;
		const insertion = options.editor()?.captureInsertion(from, to);
		if (!insertion) return false;
		try {
			const reference = await options.resolve(workflow);
			if (!reference) return false;
			insertion.insert(reference);
			return true;
		} finally {
			insertion.cancel();
		}
	}
	return {
		eligibleWorkflows,
		selectWorkflow
	};
}
//#endregion
//#region src/workbench/extensions/agent/composables/agent/useComposer.ts
function useComposer(options) {
	const store = useAgentComposerStore();
	const { draft, attachments, prompt, workflowReferences, promptEpoch } = storeToRefs(store);
	if (getCurrentScope()) onScopeDispose(store.releaseUnusedAssets);
	const canSend = computed(() => (draft.value.trim().length > 0 || prompt.value.references.length > 0 || attachments.value.length > 0) && !attachments.value.some((item) => item.uploading || item.validationError));
	function submit() {
		if (options.isRunning()) {
			options.onStop();
			return;
		}
		if (!canSend.value) return;
		options.onSend(composerPromptForSubmission(prompt.value).text.trim(), attachments.value);
	}
	/**
	* Puts an affordance's text in the composer. `starterPrompt` identifies the
	* empty-state chip it came from; it is what emits
	* `app:agent_starter_prompt_clicked` and what lets the resulting send be
	* attributed to that chip. New suggestion affordances need their own origin
	* contract instead of silently entering the starter-prompt population.
	*/
	function insert(text, starterPrompt) {
		const draftWasEmpty = !draft.value.trim() && prompt.value.references.length === 0 && attachments.value.length === 0;
		store.setText(draft.value ? `${draft.value} ${text}` : text);
		if (!starterPrompt) {
			store.markSuggestedPrompt();
			return;
		}
		const clickId = v4();
		store.markSuggestedPrompt({
			id: starterPrompt.promptId,
			clickId,
			...starterPrompt.assignment ? { assignment: starterPrompt.assignment } : {}
		});
		useTelemetry()?.trackAgentStarterPromptClicked({
			prompt_id: starterPrompt.promptId,
			prompt_index: starterPrompt.promptIndex,
			prompt_count: starterPrompt.promptCount,
			visible_prompt_count: starterPrompt.visiblePromptCount,
			prompt_text_hash: starterPrompt.promptTextHash,
			locale: starterPrompt.locale,
			click_id: clickId,
			draft_was_empty: draftWasEmpty,
			...starterPrompt.assignment ? { "$feature/agent-starter-prompt-set": starterPrompt.assignment } : {}
		});
	}
	return {
		draft,
		attachments,
		prompt,
		promptEpoch,
		applyEditorPrompt: store.applyEditorPrompt,
		resolveSkillMetadata: store.resolveSkillMetadata,
		setInsertionPoint: store.setInsertionPoint,
		setSkillScope: store.setSkillScope,
		removeReference: store.removeReference,
		workflowReferences,
		canSend,
		submit,
		insert,
		setText: store.setText,
		replacePrompt: store.replacePrompt,
		addAttachment: store.addAttachment,
		referenceAttachment: store.referenceAttachment,
		updateAttachment: store.updateAttachment,
		removeAttachment: store.removeAttachment
	};
}
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/AssetMediaPreview.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$41 = [
	"aria-label",
	"src",
	"poster"
];
var _hoisted_2$35 = {
	key: 1,
	class: "p-3"
};
var _hoisted_3$26 = ["aria-label", "src"];
var _hoisted_4$20 = {
	key: 2,
	role: "status",
	class: "px-3 py-2 text-sm text-muted-foreground"
};
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/AssetMediaPreview.vue
var AssetMediaPreview_default = /* @__PURE__ */ defineComponent({
	__name: "AssetMediaPreview",
	props: {
		name: {},
		mediaUrl: {},
		kind: {},
		posterUrl: {},
		active: { type: Boolean }
	},
	setup(__props, { expose: __expose }) {
		const player = useTemplateRef("player");
		const failed = ref(false);
		const colorPaletteStore = useColorPaletteStore();
		const colorScheme = computed(() => colorPaletteStore.colorScheme);
		onBeforeUnmount(() => player.value?.pause());
		watch(() => __props.active, (isActive) => {
			if (isActive || !player.value) return;
			player.value.pause();
			player.value.currentTime = 0;
		}, { flush: "post" });
		watch(() => __props.mediaUrl, () => {
			player.value?.pause();
			failed.value = false;
		});
		__expose({ focus: () => player.value?.focus() });
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", { style: normalizeStyle({ colorScheme: colorScheme.value }) }, [__props.kind === "video" ? (openBlock(), createElementBlock("video", {
				key: 0,
				ref_key: "player",
				ref: player,
				"aria-label": __props.name,
				src: __props.mediaUrl,
				poster: __props.posterUrl,
				controls: "",
				tabindex: "0",
				playsinline: "",
				preload: "metadata",
				class: "max-h-80 w-full object-contain",
				onError: _cache[0] || (_cache[0] = ($event) => failed.value = true)
			}, null, 40, _hoisted_1$41)) : (openBlock(), createElementBlock("div", _hoisted_2$35, [createBaseVNode("audio", {
				ref_key: "player",
				ref: player,
				"aria-label": __props.name,
				src: __props.mediaUrl,
				controls: "",
				tabindex: "0",
				preload: "metadata",
				class: "block w-full",
				onError: _cache[1] || (_cache[1] = ($event) => failed.value = true)
			}, null, 40, _hoisted_3$26)])), failed.value ? (openBlock(), createElementBlock("p", _hoisted_4$20, toDisplayString(_ctx.$t(__props.kind === "video" ? "g.videoFailedToLoad" : "g.audioFailedToLoad")), 1)) : createCommentVNode("", true)], 4);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/AssetHoverPreview.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$40 = [
	"aria-label",
	"aria-expanded",
	"aria-controls"
];
var _hoisted_2$34 = ["aria-label"];
var _hoisted_3$25 = ["src", "alt"];
var _hoisted_4$19 = { class: "px-3 py-2 text-sm wrap-anywhere text-foreground" };
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/AssetHoverPreview.vue
var AssetHoverPreview_default = /* @__PURE__ */ defineComponent({
	__name: "AssetHoverPreview",
	props: /*@__PURE__*/ mergeModels({
		name: {},
		previewUrl: {},
		mediaUrl: {},
		mediaKind: {}
	}, {
		"mode": { default: "closed" },
		"modeModifiers": {}
	}),
	emits: ["update:mode"],
	setup(__props) {
		const { t } = useI18n();
		const kind = computed(() => __props.mediaKind ?? getMediaTypeFromFilename(__props.name));
		const playableKind = computed(() => kind.value === "video" || kind.value === "audio" ? kind.value : void 0);
		const player = useTemplateRef("player");
		const mode = useModel(__props, "mode");
		const open = computed(() => mode.value === "hover" || mode.value === "interactive");
		const contentId = useId();
		const trigger = useTemplateRef("trigger");
		const content = useTemplateRef("content");
		const triggerPointerInside = useElementHover(trigger);
		const triggerHovered = useElementHover(trigger, {
			delayEnter: 250,
			delayLeave: 150
		});
		const contentHovered = useElementHover(content, {
			delayLeave: 150,
			triggerOnRemoval: true
		});
		watch([
			triggerHovered,
			contentHovered,
			triggerPointerInside
		], ([onTrigger, onContent, pointerInside]) => {
			const hovering = onTrigger || onContent;
			if ({
				closed: onTrigger && pointerInside,
				hover: true,
				interactive: false,
				dismissed: !hovering && !pointerInside
			}[mode.value]) mode.value = hovering ? "hover" : "closed";
		});
		onBeforeUnmount(() => {
			mode.value = "closed";
		});
		function focusPreview() {
			if (player.value) player.value.focus();
			else content.value?.focus();
		}
		function activate() {
			mode.value = "interactive";
			focusPreview();
		}
		function onOpenChange(next) {
			if (!next) mode.value = triggerPointerInside.value || contentHovered.value ? "dismissed" : "closed";
		}
		function onOpenAutoFocus(event) {
			event.preventDefault();
			if (mode.value === "interactive") focusPreview();
		}
		function onEscape() {
			if (mode.value === "interactive" || content.value?.contains(document.activeElement)) trigger.value?.focus();
		}
		function onInteractOutside(event) {
			if (event.target instanceof Node && trigger.value?.contains(event.target)) event.preventDefault();
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(Popover_default, {
				open: open.value,
				"onUpdate:open": onOpenChange
			}, {
				default: withCtx(() => [createVNode(unref(PopoverAnchor_default), { "as-child": "" }, {
					default: withCtx(() => [createBaseVNode("button", {
						ref_key: "trigger",
						ref: trigger,
						type: "button",
						"aria-label": unref(t)("agent.previewAsset", { name: __props.name }),
						"aria-haspopup": "dialog",
						"aria-expanded": open.value,
						"aria-controls": open.value ? unref(contentId) : void 0,
						class: "relative flex size-full cursor-pointer items-center justify-center overflow-hidden rounded-md hover:bg-accent focus-visible:ring-1 focus-visible:ring-ring focus-visible:outline-none",
						onClick: activate
					}, [renderSlot(_ctx.$slots, "default")], 8, _hoisted_1$40)]),
					_: 3
				}), createVNode(PopoverContent_default, {
					id: unref(contentId),
					"aria-label": __props.name,
					side: "top",
					align: "start",
					"side-offset": 8,
					"collision-padding": 16,
					class: normalizeClass(unref(cn)("z-overlay max-w-[calc(100vw-2rem)] overflow-hidden rounded-xl border-border/50 bg-secondary p-0", playableKind.value === "audio" ? "w-86" : "w-80")),
					onOpenAutoFocus,
					onCloseAutoFocus: _cache[0] || (_cache[0] = withModifiers(() => {}, ["prevent"])),
					onEscapeKeyDown: onEscape,
					onInteractOutside
				}, {
					default: withCtx(() => [createBaseVNode("div", {
						ref_key: "content",
						ref: content,
						tabindex: "-1",
						role: "region",
						"aria-label": __props.name
					}, [__props.mediaUrl && playableKind.value ? (openBlock(), createBlock(AssetMediaPreview_default, {
						key: playableKind.value,
						ref_key: "player",
						ref: player,
						name: __props.name,
						"media-url": __props.mediaUrl,
						kind: playableKind.value,
						"poster-url": __props.previewUrl,
						active: open.value
					}, null, 8, [
						"name",
						"media-url",
						"kind",
						"poster-url",
						"active"
					])) : __props.previewUrl && (kind.value === "image" || kind.value === "video") ? (openBlock(), createElementBlock("img", {
						key: 1,
						src: __props.previewUrl,
						alt: __props.name,
						class: "max-h-80 w-full object-contain"
					}, null, 8, _hoisted_3$25)) : createCommentVNode("", true), createBaseVNode("div", _hoisted_4$19, toDisplayString(__props.name), 1)], 8, _hoisted_2$34)]),
					_: 1
				}, 8, [
					"id",
					"aria-label",
					"class"
				])]),
				_: 3
			}, 8, ["open"]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/AttachmentChip.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$39 = [
	"data-attachment-name",
	"data-highlighted",
	"aria-label"
];
var _hoisted_2$33 = ["aria-label"];
var _hoisted_3$24 = {
	key: 0,
	"aria-hidden": "true",
	class: "pointer-events-none absolute right-1 bottom-1 flex size-5 items-center justify-center rounded-full bg-background/80"
};
var _hoisted_4$18 = ["aria-label"];
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/AttachmentChip.vue
var AttachmentChip_default = /* @__PURE__ */ defineComponent({
	__name: "AttachmentChip",
	props: /*@__PURE__*/ mergeModels({
		name: {},
		previewUrl: {},
		mediaUrl: {},
		mediaKind: {},
		uploading: {
			type: Boolean,
			default: false
		},
		validationError: {},
		highlighted: {
			type: Boolean,
			default: false
		}
	}, {
		"previewMode": { default: "closed" },
		"previewModeModifiers": {}
	}),
	emits: /*@__PURE__*/ mergeModels(["remove"], ["update:previewMode"]),
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const previewMode = useModel(__props, "previewMode");
		const { t } = useI18n();
		const kind = computed(() => __props.mediaKind ?? getMediaTypeFromFilename(__props.name));
		const VALIDATION_MESSAGES = {
			"invalid-video": "agent.attachmentInvalidVideo",
			"unsupported-type": "agent.attachmentUnsupportedType"
		};
		const outlined = computed(() => !!__props.validationError || kind.value === "image" && !__props.previewUrl);
		const invalidThumbnailKind = computed(() => __props.validationError === "unsupported-type" ? "other" : __props.mediaKind);
		const validationMessage = computed(() => __props.validationError && t(VALIDATION_MESSAGES[__props.validationError], { name: __props.name }));
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("span", {
				"data-testid": "agent-attachment-chip",
				"data-attachment-name": __props.name,
				"data-highlighted": __props.highlighted || void 0,
				role: "group",
				"aria-label": __props.name,
				class: normalizeClass(unref(cn)("group/attachment relative flex size-20 shrink-0 items-center justify-center rounded-lg p-1 data-highlighted:ring-2 data-highlighted:ring-foreground data-highlighted:ring-inset", outlined.value && "ring-1 ring-border ring-inset"))
			}, [__props.validationError ? (openBlock(), createBlock(Tooltip_default, { key: 0 }, {
				default: withCtx(() => [createVNode(TooltipTrigger_default, { "as-child": "" }, {
					default: withCtx(() => [createBaseVNode("span", {
						role: "status",
						tabindex: "0",
						"aria-label": validationMessage.value,
						class: "flex size-full items-center justify-center rounded-sm"
					}, [createVNode(AssetThumbnail_default, {
						name: __props.name,
						"media-kind": invalidThumbnailKind.value,
						variant: "tray",
						class: "size-full"
					}, null, 8, ["name", "media-kind"]), _cache[2] || (_cache[2] = createBaseVNode("span", {
						"aria-hidden": "true",
						class: "pointer-events-none absolute right-1 bottom-1 flex size-5 items-center justify-center rounded-full bg-background/80"
					}, [createBaseVNode("span", { class: "icon-[lucide--triangle-alert] size-3 text-destructive" })], -1))], 8, _hoisted_2$33)]),
					_: 1
				}), createVNode(TooltipContent_default, {
					side: "top",
					class: "max-w-56"
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(validationMessage.value), 1)]),
					_: 1
				})]),
				_: 1
			})) : (openBlock(), createBlock(AssetHoverPreview_default, {
				key: 1,
				mode: previewMode.value,
				"onUpdate:mode": _cache[0] || (_cache[0] = ($event) => previewMode.value = $event),
				name: __props.name,
				"preview-url": __props.previewUrl,
				"media-url": __props.mediaUrl,
				"media-kind": __props.mediaKind
			}, {
				default: withCtx(() => [
					createVNode(AssetThumbnail_default, {
						name: __props.name,
						"preview-url": __props.previewUrl,
						"media-kind": __props.mediaKind,
						variant: "tray",
						class: "size-full"
					}, null, 8, [
						"name",
						"preview-url",
						"media-kind"
					]),
					kind.value === "video" && __props.previewUrl ? (openBlock(), createElementBlock("span", _hoisted_3$24, [..._cache[3] || (_cache[3] = [createBaseVNode("span", { class: "icon-[lucide--play] size-3" }, null, -1)])])) : createCommentVNode("", true),
					__props.uploading ? (openBlock(), createElementBlock("span", {
						key: 1,
						role: "status",
						"aria-label": _ctx.$t("agent.uploading"),
						class: "absolute inset-0 flex items-center justify-center bg-background/60"
					}, [..._cache[4] || (_cache[4] = [createBaseVNode("span", { class: "icon-[lucide--loader-circle] size-5 animate-spin text-muted-foreground" }, null, -1)])], 8, _hoisted_4$18)) : createCommentVNode("", true)
				]),
				_: 1
			}, 8, [
				"mode",
				"name",
				"preview-url",
				"media-url",
				"media-kind"
			])), createVNode(TagRemoveButton_default, {
				"aria-label": _ctx.$t("agent.removeAsset", { name: __props.name }),
				class: "pointer-events-none absolute top-1 right-1 size-5 shrink-0 rounded-full bg-background text-foreground opacity-0 ring-1 ring-border/50 group-focus-within/attachment:pointer-events-auto group-focus-within/attachment:opacity-100 group-hover/attachment:pointer-events-auto group-hover/attachment:opacity-100 hover:bg-accent touch:pointer-events-auto touch:size-7 touch:opacity-100",
				onClick: _cache[1] || (_cache[1] = ($event) => emit("remove"))
			}, null, 8, ["aria-label"])], 10, _hoisted_1$39);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/AssetTray.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$38 = ["aria-label"];
var _hoisted_2$32 = ["aria-label"];
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/AssetTray.vue
var AssetTray_default = /* @__PURE__ */ defineComponent({
	__name: "AssetTray",
	props: {
		attachments: {},
		highlightedIds: { default: () => [] }
	},
	emits: ["remove"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const { t } = useI18n();
		const activePreview = ref();
		const scrollContainer = useTemplateRef("scrollContainer");
		const reducedMotion = usePreferredReducedMotion();
		const { x, arrivedState, measure } = useScroll(scrollContainer, { behavior: () => reducedMotion.value === "reduce" ? "auto" : "smooth" });
		const { isOverflowing, checkOverflow } = useOverflowObserver(scrollContainer, {
			debounceTime: 0,
			onCheck: measure
		});
		onMounted(checkOverflow);
		const hasMoreLeft = computed(() => isOverflowing.value && !arrivedState.left);
		const hasMoreRight = computed(() => isOverflowing.value && !arrivedState.right);
		function updatePreview(id, mode) {
			if ((mode === "closed" || mode === "dismissed") && activePreview.value?.id !== id) return;
			activePreview.value = mode === "closed" ? void 0 : {
				id,
				mode
			};
		}
		function scrollPage(direction) {
			const element = scrollContainer.value;
			if (!element) return;
			x.value = Math.max(0, Math.min(element.scrollWidth - element.clientWidth, x.value + direction * element.clientWidth));
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				role: "region",
				"aria-label": unref(t)("assetBrowser.assets"),
				class: "relative max-w-full min-w-0 shrink-0 overflow-hidden rounded-t-lg"
			}, [createBaseVNode("div", {
				ref_key: "scrollContainer",
				ref: scrollContainer,
				"data-testid": "composer-asset-section",
				role: "group",
				tabindex: "0",
				"aria-label": unref(t)("g.asset", { count: __props.attachments.length }, __props.attachments.length),
				class: "flex scrollbar-custom max-w-full min-w-0 flex-nowrap gap-2 overflow-x-auto overflow-y-hidden p-3 focus-visible:ring-1 focus-visible:ring-ring focus-visible:outline-none focus-visible:ring-inset"
			}, [(openBlock(true), createElementBlock(Fragment, null, renderList(__props.attachments, (item) => {
				return openBlock(), createBlock(AttachmentChip_default, {
					key: item.id,
					name: item.name,
					"preview-url": item.previewUrl,
					"media-url": item.mediaUrl,
					"media-kind": item.mediaKind,
					uploading: item.uploading,
					"validation-error": item.validationError,
					highlighted: __props.highlightedIds.includes(item.id),
					"preview-mode": activePreview.value?.id === item.id ? activePreview.value.mode : "closed",
					"onUpdate:previewMode": ($event) => updatePreview(item.id, $event),
					onRemove: ($event) => emit("remove", item.id)
				}, null, 8, [
					"name",
					"preview-url",
					"media-url",
					"media-kind",
					"uploading",
					"validation-error",
					"highlighted",
					"preview-mode",
					"onUpdate:previewMode",
					"onRemove"
				]);
			}), 128))], 8, _hoisted_2$32), unref(isOverflowing) ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [createBaseVNode("div", { class: normalizeClass(unref(cn)("pointer-events-none absolute inset-y-0 left-0 z-10 flex w-12 items-center pl-2", hasMoreLeft.value && "bg-linear-to-r from-secondary to-transparent")) }, [createVNode(Button_default, {
				variant: "base",
				size: "icon",
				"aria-label": unref(t)("g.scrollLeft"),
				disabled: !hasMoreLeft.value,
				class: "pointer-events-auto size-7 shrink-0 rounded-full shadow-sm ring-1 ring-border/50",
				onClick: _cache[0] || (_cache[0] = ($event) => scrollPage(-1))
			}, {
				default: withCtx(() => [..._cache[2] || (_cache[2] = [createBaseVNode("span", {
					"aria-hidden": "true",
					class: "icon-[lucide--chevron-left] size-4"
				}, null, -1)])]),
				_: 1
			}, 8, ["aria-label", "disabled"])], 2), createBaseVNode("div", { class: normalizeClass(unref(cn)("pointer-events-none absolute inset-y-0 right-0 z-10 flex w-12 items-center justify-end pr-2", hasMoreRight.value && "bg-linear-to-l from-secondary to-transparent")) }, [createVNode(Button_default, {
				variant: "base",
				size: "icon",
				"aria-label": unref(t)("g.scrollRight"),
				disabled: !hasMoreRight.value,
				class: "pointer-events-auto size-7 shrink-0 rounded-full shadow-sm ring-1 ring-border/50",
				onClick: _cache[1] || (_cache[1] = ($event) => scrollPage(1))
			}, {
				default: withCtx(() => [..._cache[3] || (_cache[3] = [createBaseVNode("span", {
					"aria-hidden": "true",
					class: "icon-[lucide--chevron-right] size-4"
				}, null, -1)])]),
				_: 1
			}, 8, ["aria-label", "disabled"])], 2)], 64)) : createCommentVNode("", true)], 8, _hoisted_1$38);
		};
	}
});
//#endregion
//#region ~icons/lucide/paperclip
var _hoisted_1$37 = {
	viewBox: "0 0 24 24",
	width: "1.2em",
	height: "1.2em"
};
function render(_ctx, _cache) {
	return openBlock(), createElementBlock("svg", _hoisted_1$37, [..._cache[0] || (_cache[0] = [createBaseVNode("path", {
		fill: "none",
		stroke: "currentColor",
		"stroke-linecap": "round",
		"stroke-linejoin": "round",
		"stroke-width": "2",
		d: "m16 6l-8.414 8.586a2 2 0 0 0 2.829 2.829l8.414-8.586a4 4 0 1 0-5.657-5.657l-8.379 8.551a6 6 0 1 0 8.485 8.485l8.379-8.551"
	}, null, -1)])]);
}
var paperclip_default = markRaw({
	name: "lucide-paperclip",
	render
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/ComposerAddMenu.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$36 = { class: "whitespace-nowrap" };
var _hoisted_2$31 = { class: "whitespace-nowrap" };
var _hoisted_3$23 = { class: "flex-1 text-left whitespace-nowrap" };
var _hoisted_4$17 = { class: "max-w-64 truncate" };
var _hoisted_5$15 = {
	key: 0,
	class: "text-xs text-muted-foreground"
};
var _hoisted_6$11 = {
	key: 0,
	class: "px-2 py-1 text-xs text-muted-foreground"
};
var _hoisted_7$8 = { class: "whitespace-nowrap" };
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/ComposerAddMenu.vue
var ComposerAddMenu_default = /* @__PURE__ */ defineComponent({
	__name: "ComposerAddMenu",
	props: {
		canAttach: { type: Boolean },
		canOpenAssets: { type: Boolean },
		nodeReferenceDisabledReason: {},
		workflows: {},
		workflowSelecting: { type: Boolean },
		selectWorkflow: { type: Function }
	},
	emits: [
		"selectNodes",
		"attach",
		"openAssets",
		"requestWorkflowReferences"
	],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const { t } = useI18n();
		const addMenuOpen = ref(false);
		const workflowSubmenuOpen = ref(false);
		function onWorkflowSubmenuOpenChange(open) {
			if (open && !__props.workflowSelecting) emit("requestWorkflowReferences");
		}
		async function pickWorkflow(workflow) {
			if (await __props.selectWorkflow(workflow)) addMenuOpen.value = false;
		}
		return (_ctx, _cache) => {
			const _component_i_lucide58paperclip = paperclip_default;
			return openBlock(), createBlock(unref(DropdownMenuRoot_default), {
				open: addMenuOpen.value,
				"onUpdate:open": _cache[5] || (_cache[5] = ($event) => addMenuOpen.value = $event)
			}, {
				default: withCtx(() => [createVNode(unref(DropdownMenuTrigger_default), { "as-child": "" }, {
					default: withCtx(() => [createVNode(Button_default, {
						tooltip: unref(t)("agent.addToPrompt"),
						variant: "muted-textonly",
						size: "icon",
						"aria-label": unref(t)("agent.addToPrompt")
					}, {
						default: withCtx(() => [..._cache[6] || (_cache[6] = [createBaseVNode("span", { class: "icon-[lucide--plus] size-4" }, null, -1)])]),
						_: 1
					}, 8, ["tooltip", "aria-label"])]),
					_: 1
				}), (openBlock(), createBlock(unref(DropdownMenuPortal_default), { key: Number(addMenuOpen.value) }, {
					default: withCtx(() => [createVNode(MenuContent_default, {
						side: "top",
						align: "start",
						"side-offset": 4,
						width: "compact",
						class: "agent-scope"
					}, {
						default: withCtx(() => [
							__props.canOpenAssets ? (openBlock(), createBlock(MenuItem_default, {
								key: 0,
								class: "mb-0.5",
								onSelect: _cache[0] || (_cache[0] = ($event) => emit("openAssets"))
							}, {
								default: withCtx(() => [_cache[7] || (_cache[7] = createBaseVNode("span", { class: "icon-[comfy--image-ai-edit] size-4 shrink-0" }, null, -1)), createBaseVNode("span", _hoisted_1$36, toDisplayString(unref(t)("agent.addFromAssets")), 1)]),
								_: 1
							})) : createCommentVNode("", true),
							createVNode(Tooltip_default, { disabled: !__props.nodeReferenceDisabledReason }, {
								default: withCtx(() => [createVNode(TooltipTrigger_default, { "as-child": "" }, {
									default: withCtx(() => [createVNode(MenuItem_default, {
										disabled: !!__props.nodeReferenceDisabledReason,
										"aria-description": __props.nodeReferenceDisabledReason,
										onSelect: _cache[1] || (_cache[1] = ($event) => emit("selectNodes", $event))
									}, {
										default: withCtx(() => [_cache[8] || (_cache[8] = createBaseVNode("span", { class: "icon-[comfy--node] size-4 shrink-0" }, null, -1)), createBaseVNode("span", _hoisted_2$31, toDisplayString(unref(t)("agent.nodes")), 1)]),
										_: 1
									}, 8, ["disabled", "aria-description"])]),
									_: 1
								}), createVNode(TooltipContent_default, null, {
									default: withCtx(() => [createTextVNode(toDisplayString(__props.nodeReferenceDisabledReason), 1)]),
									_: 1
								})]),
								_: 1
							}, 8, ["disabled"]),
							createVNode(unref(DropdownMenuSub_default), {
								open: workflowSubmenuOpen.value,
								"onUpdate:open": [_cache[3] || (_cache[3] = ($event) => workflowSubmenuOpen.value = $event), onWorkflowSubmenuOpenChange]
							}, {
								default: withCtx(() => [createVNode(MenuSubTrigger_default, null, {
									default: withCtx(() => [
										_cache[9] || (_cache[9] = createBaseVNode("span", { class: "icon-[comfy--workflow] size-4 shrink-0" }, null, -1)),
										createBaseVNode("span", _hoisted_3$23, toDisplayString(unref(t)("agent.workflows")), 1),
										_cache[10] || (_cache[10] = createBaseVNode("span", { class: "icon-[lucide--chevron-right] size-4 shrink-0" }, null, -1))
									]),
									_: 1
								}), (openBlock(), createBlock(unref(DropdownMenuPortal_default), { key: Number(workflowSubmenuOpen.value) }, {
									default: withCtx(() => [createVNode(MenuSubContent_default, {
										"side-offset": 4,
										width: "compact",
										"max-height": "compact",
										class: "agent-scope"
									}, {
										default: withCtx(() => [
											createVNode(MenuItem_default, { onSelect: _cache[2] || (_cache[2] = withModifiers(($event) => workflowSubmenuOpen.value = false, ["prevent"])) }, {
												default: withCtx(() => [_cache[11] || (_cache[11] = createBaseVNode("span", { class: "icon-[lucide--chevron-left] size-4 shrink-0" }, null, -1)), createBaseVNode("span", null, toDisplayString(unref(t)("g.back")), 1)]),
												_: 1
											}),
											(openBlock(true), createElementBlock(Fragment, null, renderList(__props.workflows, (workflow) => {
												return openBlock(), createBlock(MenuItem_default, {
													key: workflow.id ?? workflow.tabPath,
													disabled: __props.workflowSelecting,
													onSelect: withModifiers(($event) => pickWorkflow(workflow), ["prevent"])
												}, {
													default: withCtx(() => [
														_cache[12] || (_cache[12] = createBaseVNode("span", { class: "icon-[comfy--workflow] size-4 shrink-0" }, null, -1)),
														createBaseVNode("span", _hoisted_4$17, toDisplayString(workflow.name), 1),
														workflow.id === void 0 ? (openBlock(), createElementBlock("span", _hoisted_5$15, toDisplayString(unref(t)("agent.unsavedWorkflow")), 1)) : createCommentVNode("", true)
													]),
													_: 2
												}, 1032, ["disabled", "onSelect"]);
											}), 128)),
											__props.workflows.length === 0 ? (openBlock(), createElementBlock("div", _hoisted_6$11, toDisplayString(unref(t)("agent.noWorkflowsToReference")), 1)) : createCommentVNode("", true)
										]),
										_: 1
									})]),
									_: 1
								}))]),
								_: 1
							}, 8, ["open"]),
							__props.canAttach ? (openBlock(), createBlock(MenuSeparator_default, {
								key: 1,
								class: "mt-0 mb-px"
							})) : createCommentVNode("", true),
							__props.canAttach ? (openBlock(), createBlock(MenuItem_default, {
								key: 2,
								onSelect: _cache[4] || (_cache[4] = ($event) => emit("attach"))
							}, {
								default: withCtx(() => [createVNode(_component_i_lucide58paperclip, { class: "size-4 shrink-0" }), createBaseVNode("span", _hoisted_7$8, toDisplayString(unref(t)("agent.attachFiles")), 1)]),
								_: 1
							})) : createCommentVNode("", true)
						]),
						_: 1
					})]),
					_: 1
				}))]),
				_: 1
			}, 8, ["open"]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/ComposerPlaceholder.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$35 = ["aria-hidden", "inert"];
var _hoisted_2$30 = { class: "underline decoration-dashed underline-offset-2" };
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/ComposerPlaceholder.vue
var ComposerPlaceholder_default = /* @__PURE__ */ defineComponent({
	__name: "ComposerPlaceholder",
	props: {
		label: {},
		visible: { type: Boolean },
		nodeReferenceDisabledReason: {}
	},
	emits: ["selectNodes"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const placeholderHint = computed(() => {
			const [text = "", mentionNodes = ""] = __props.label.split("\n");
			return {
				text,
				mentionNodes
			};
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				"aria-hidden": !__props.visible || void 0,
				inert: !__props.visible,
				class: normalizeClass(unref(cn)("pointer-events-none z-10 col-start-1 row-start-1 self-start p-3 font-inter text-[14px]/5 font-normal text-muted-foreground", !__props.visible && "invisible"))
			}, [createBaseVNode("span", null, toDisplayString(placeholderHint.value.text), 1), placeholderHint.value.mentionNodes ? (openBlock(), createBlock(Button_default, {
				key: 0,
				tooltip: __props.nodeReferenceDisabledReason ?? "",
				type: "button",
				variant: "link",
				size: "unset",
				"aria-disabled": !!__props.nodeReferenceDisabledReason || void 0,
				"aria-description": __props.nodeReferenceDisabledReason,
				class: "pointer-events-auto h-5 shrink-0 gap-1 px-1 align-top text-sm/5 aria-disabled:cursor-not-allowed aria-disabled:opacity-50",
				onClick: _cache[0] || (_cache[0] = ($event) => emit("selectNodes", $event))
			}, {
				default: withCtx(() => [_cache[1] || (_cache[1] = createBaseVNode("span", { class: "icon-[lucide--mouse-pointer-click] size-3.5 shrink-0" }, null, -1)), createBaseVNode("span", _hoisted_2$30, toDisplayString(placeholderHint.value.mentionNodes), 1)]),
				_: 1
			}, 8, [
				"tooltip",
				"aria-disabled",
				"aria-description"
			])) : createCommentVNode("", true)], 10, _hoisted_1$35);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/SkillMenuDescription.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$34 = ["id"];
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/SkillMenuDescription.vue
var SkillMenuDescription_default = /* @__PURE__ */ defineComponent({
	__name: "SkillMenuDescription",
	props: {
		id: {},
		skill: {},
		anchor: {}
	},
	emits: [
		"enter",
		"leave",
		"focusout",
		"releaseFocus",
		"dismiss"
	],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const card = useTemplateRef("card");
		onBeforeUnmount(() => {
			if (card.value?.contains(document.activeElement)) emit("releaseFocus");
		});
		return (_ctx, _cache) => {
			return __props.skill && __props.anchor ? (openBlock(), createBlock(HoverCard_default, {
				key: 0,
				open: ""
			}, {
				default: withCtx(() => [createVNode(HoverCardContent_default, {
					reference: __props.anchor,
					side: "top",
					align: "end",
					"side-offset": 0,
					"collision-padding": 16,
					class: "border-0 bg-transparent p-0 shadow-none"
				}, {
					default: withCtx(() => [createBaseVNode("div", {
						class: "pb-1.5",
						onMouseenter: _cache[2] || (_cache[2] = ($event) => emit("enter")),
						onMouseleave: _cache[3] || (_cache[3] = ($event) => emit("leave"))
					}, [createBaseVNode("div", {
						id: __props.id,
						ref_key: "card",
						ref: card,
						tabindex: "-1",
						class: "w-62.5 max-w-[calc(100vw-2rem)] rounded-[10px] border border-border/50 bg-background p-2.5 text-xs/4 font-normal wrap-anywhere whitespace-pre-wrap text-muted-foreground shadow-md outline-none select-text",
						onFocusout: _cache[0] || (_cache[0] = ($event) => emit("focusout", $event)),
						onKeydown: _cache[1] || (_cache[1] = withKeys(withModifiers(($event) => emit("dismiss"), ["stop"]), ["esc"]))
					}, toDisplayString(__props.skill.description), 41, _hoisted_1$34)], 32)]),
					_: 1
				}, 8, ["reference"])]),
				_: 1
			})) : createCommentVNode("", true);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/MentionMenuItem.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$33 = [
	"id",
	"aria-disabled",
	"aria-description",
	"aria-describedby",
	"aria-label",
	"data-active"
];
var _hoisted_2$29 = { class: "min-w-0 flex-1 truncate" };
var _hoisted_3$22 = {
	key: 3,
	class: "text-muted-foreground"
};
var _hoisted_4$16 = {
	key: 4,
	class: "ml-auto shrink-0 rounded-full bg-muted px-1 py-0.5 font-mono text-xs/4"
};
var _hoisted_5$14 = {
	key: 5,
	class: "icon-[lucide--chevron-right] size-4 shrink-0"
};
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/MentionMenuItem.vue
var MentionMenuItem_default = /* @__PURE__ */ defineComponent({
	__name: "MentionMenuItem",
	props: {
		match: {},
		index: {},
		active: { type: Boolean },
		disabled: { type: Boolean },
		nodeReferenceDisabledReason: {},
		duplicateNodeTitles: {},
		describedSkill: {},
		descriptionId: {}
	},
	emits: [
		"highlight",
		"pick",
		"descriptionEnter",
		"descriptionLeave",
		"descriptionFocusout",
		"descriptionReleaseFocus",
		"descriptionDismiss"
	],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const row = useTemplateRef("row");
		const description = computed(() => __props.active && __props.descriptionId ? __props.describedSkill : void 0);
		const disabledReason = computed(() => __props.match.kind === "node" || __props.match.kind === "section" && __props.match.id === "nodes" ? __props.nodeReferenceDisabledReason : void 0);
		const asset = computed(() => __props.match.kind === "asset" ? __props.match.asset : void 0);
		const icon = computed(() => {
			if (__props.match.kind === "back") return "icon-[lucide--chevron-left] size-4";
			if (__props.match.kind !== "section") return void 0;
			return __props.match.id === "nodes" ? "icon-[comfy--node] size-3.5" : "icon-[comfy--workflow] size-3.5";
		});
		const unsavedWorkflow = computed(() => __props.match.kind === "workflow" && __props.match.workflow.id === void 0);
		const nodeId = computed(() => __props.match.kind === "node" && __props.duplicateNodeTitles.has(__props.match.node.title) ? __props.match.node.id : void 0);
		return (_ctx, _cache) => {
			return openBlock(), createBlock(Tooltip_default, { disabled: !disabledReason.value }, {
				default: withCtx(() => [createVNode(TooltipTrigger_default, { "as-child": "" }, {
					default: withCtx(() => [createBaseVNode("div", {
						id: `agent-reference-item-${__props.index}`,
						ref_key: "row",
						ref: row,
						"aria-disabled": __props.disabled || void 0,
						"aria-description": disabledReason.value,
						"aria-describedby": description.value ? __props.descriptionId : void 0,
						role: "menuitem",
						"aria-label": asset.value || __props.match.kind === "skill" ? __props.match.label : void 0,
						"data-active": __props.active,
						class: normalizeClass(unref(cn)("flex h-7 w-full cursor-pointer items-center gap-1.5 rounded-lg px-1.5 py-1 text-xs font-normal outline-none aria-disabled:cursor-not-allowed aria-disabled:opacity-50", __props.active && "bg-accent")),
						onMouseenter: _cache[5] || (_cache[5] = ($event) => emit("highlight")),
						onClick: _cache[6] || (_cache[6] = ($event) => emit("pick"))
					}, [
						icon.value ? (openBlock(), createElementBlock("span", {
							key: 0,
							class: normalizeClass(unref(cn)(icon.value, "shrink-0"))
						}, null, 2)) : createCommentVNode("", true),
						asset.value ? (openBlock(), createBlock(AssetThumbnail_default, {
							key: 1,
							name: asset.value.name,
							"preview-url": asset.value.previewUrl,
							"media-kind": asset.value.mediaKind,
							variant: "menu",
							class: "size-5 shrink-0"
						}, null, 8, [
							"name",
							"preview-url",
							"media-kind"
						])) : createCommentVNode("", true),
						createBaseVNode("span", _hoisted_2$29, toDisplayString(__props.match.label), 1),
						description.value && __props.descriptionId ? (openBlock(), createBlock(SkillMenuDescription_default, {
							key: 2,
							id: __props.descriptionId,
							skill: description.value,
							anchor: row.value,
							onEnter: _cache[0] || (_cache[0] = ($event) => emit("descriptionEnter")),
							onLeave: _cache[1] || (_cache[1] = ($event) => emit("descriptionLeave")),
							onFocusout: _cache[2] || (_cache[2] = ($event) => emit("descriptionFocusout", $event)),
							onReleaseFocus: _cache[3] || (_cache[3] = ($event) => emit("descriptionReleaseFocus")),
							onDismiss: _cache[4] || (_cache[4] = ($event) => emit("descriptionDismiss"))
						}, null, 8, [
							"id",
							"skill",
							"anchor"
						])) : createCommentVNode("", true),
						unsavedWorkflow.value ? (openBlock(), createElementBlock("span", _hoisted_3$22, toDisplayString(_ctx.$t("agent.unsavedWorkflow")), 1)) : createCommentVNode("", true),
						nodeId.value !== void 0 ? (openBlock(), createElementBlock("span", _hoisted_4$16, toDisplayString(" #" + nodeId.value), 1)) : createCommentVNode("", true),
						__props.match.kind === "section" ? (openBlock(), createElementBlock("span", _hoisted_5$14)) : createCommentVNode("", true)
					], 42, _hoisted_1$33)]),
					_: 1
				}), createVNode(TooltipContent_default, null, {
					default: withCtx(() => [createTextVNode(toDisplayString(disabledReason.value), 1)]),
					_: 1
				})]),
				_: 1
			}, 8, ["disabled"]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/MentionMenuStatus.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$32 = {
	role: "status",
	class: "px-2 py-1 text-xs text-muted-foreground"
};
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/MentionMenuStatus.vue
var MentionMenuStatus_default = /* @__PURE__ */ defineComponent({
	__name: "MentionMenuStatus",
	props: {
		label: {},
		retryable: {
			type: Boolean,
			default: false
		}
	},
	emits: ["retry"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$32, [createTextVNode(toDisplayString(__props.label) + " ", 1), __props.retryable ? (openBlock(), createBlock(Button_default, {
				key: 0,
				variant: "textonly",
				size: "sm",
				onClick: _cache[0] || (_cache[0] = ($event) => emit("retry"))
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("g.retry")), 1)]),
				_: 1
			})) : createCommentVNode("", true)]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/RunModePopover.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$31 = { class: "flex flex-col gap-0.5" };
var _hoisted_2$28 = {
	"aria-hidden": "true",
	class: "text-sm/5 text-foreground"
};
var _hoisted_3$21 = ["id"];
var _hoisted_4$15 = { class: "min-w-0 flex-1" };
var _hoisted_5$13 = { class: "block text-sm/5 text-foreground" };
var _hoisted_6$10 = { class: "mt-0.5 block text-xs/4 text-muted-foreground" };
var _hoisted_7$7 = {
	key: 0,
	role: "status",
	class: "sr-only"
};
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/RunModePopover.vue
var RunModePopover_default = /* @__PURE__ */ defineComponent({
	__name: "RunModePopover",
	setup(__props) {
		const { t } = useI18n();
		const store = useAgentRunModeStore();
		const toast = useToast();
		const open = ref(false);
		const savingMode = ref(null);
		const descriptionId = useId();
		let openCount = 0;
		function onOpenChange(next) {
			open.value = next;
			if (next) openCount += 1;
		}
		async function onSelectMode(value) {
			const match = options.find((option) => option.mode === value);
			if (!match || savingMode.value !== null) return;
			const openedAs = openCount;
			const previousMode = store.mode;
			savingMode.value = match.mode;
			try {
				await store.save(match.mode, null);
				if (previousMode !== match.mode) useTelemetry()?.trackAgentRunModeChanged({
					from: previousMode,
					to: match.mode
				});
				if (openedAs === openCount) open.value = false;
			} catch (error) {
				reportError(error, {
					surface: "agent",
					errorType: "agent_run_mode_save_failure"
				});
				toast.error(t("agent.runModeSaveFailed"));
			} finally {
				savingMode.value = null;
			}
		}
		const TRIGGER_LABEL_KEYS = {
			ask_approval: "agent.runModeTriggerAsk",
			auto: "agent.runModeTriggerAuto",
			auto_limited: "agent.runModeTriggerAutoLimit"
		};
		const triggerLabel = computed(() => t(TRIGGER_LABEL_KEYS[store.mode]));
		const TRIGGER_TOOLTIP_KEYS = {
			ask_approval: "agent.runModeTriggerAskTooltip",
			auto: "agent.runModeTriggerAutoTooltip",
			auto_limited: "agent.runModeTriggerAutoLimitTooltip"
		};
		const triggerTooltip = computed(() => t(TRIGGER_TOOLTIP_KEYS[store.mode]));
		const options = [{
			mode: "ask_approval",
			icon: "icon-[lucide--hand]",
			title: "agent.runModeAsk",
			description: "agent.runModeAskDescription"
		}, {
			mode: "auto",
			icon: "icon-[lucide--zap]",
			title: "agent.runModeAuto",
			description: "agent.runModeAutoDescription"
		}];
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(DropdownMenuRoot_default), {
				open: open.value,
				modal: false,
				"onUpdate:open": onOpenChange
			}, {
				default: withCtx(() => [createVNode(unref(DropdownMenuTrigger_default), { "as-child": "" }, {
					default: withCtx(() => [createVNode(Button_default, {
						tooltip: triggerTooltip.value,
						variant: "muted-textonly",
						size: "md",
						class: normalizeClass(unref(cn)("gap-1", open.value && "bg-accent"))
					}, {
						default: withCtx(() => [createBaseVNode("span", null, toDisplayString(triggerLabel.value), 1), _cache[2] || (_cache[2] = createBaseVNode("span", {
							"data-testid": "run-mode-chevron",
							class: "icon-[lucide--chevron-down] size-4"
						}, null, -1))]),
						_: 1
					}, 8, ["tooltip", "class"])]),
					_: 1
				}), (openBlock(), createBlock(unref(DropdownMenuPortal_default), { key: Number(open.value) }, {
					default: withCtx(() => [createVNode(unref(DropdownMenuContent_default), {
						side: "top",
						align: "end",
						"side-offset": 8,
						"aria-describedby": unref(descriptionId),
						class: "agent-scope z-overlay flex w-80 flex-col gap-2.5 rounded-lg border bg-secondary p-2.5 text-foreground shadow-lg outline-none data-[side=bottom]:slide-in-from-top-2 data-[side=top]:slide-in-from-bottom-2 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[state=open]:animate-in data-[state=open]:fade-in-0 data-[state=open]:zoom-in-95"
					}, {
						default: withCtx(() => [createBaseVNode("div", _hoisted_1$31, [createBaseVNode("div", _hoisted_2$28, toDisplayString(unref(t)("agent.runPermissions")), 1), createBaseVNode("div", {
							id: unref(descriptionId),
							"aria-hidden": "true",
							class: "text-xs/4 text-muted-foreground"
						}, toDisplayString(unref(t)("agent.runPermissionsDescription")), 9, _hoisted_3$21)]), createVNode(unref(DropdownMenuRadioGroup_default), {
							"model-value": unref(store).mode,
							"aria-label": unref(t)("agent.runPermissions"),
							class: "flex flex-col gap-1",
							"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => typeof $event === "string" && onSelectMode($event))
						}, {
							default: withCtx(() => [(openBlock(), createElementBlock(Fragment, null, renderList(options, (option) => {
								return createVNode(unref(DropdownMenuRadioItem_default), {
									key: option.mode,
									value: option.mode,
									disabled: savingMode.value !== null,
									"aria-busy": savingMode.value === option.mode || void 0,
									"as-child": "",
									onSelect: _cache[0] || (_cache[0] = withModifiers(() => {}, ["prevent"]))
								}, {
									default: withCtx(() => [createVNode(Button_default, {
										variant: unref(store).mode === option.mode ? "tertiary" : "muted-textonly",
										size: "unset",
										class: normalizeClass(unref(cn)("w-full items-start gap-3 px-2.5 py-2 text-left whitespace-normal data-disabled:pointer-events-none", savingMode.value !== null && savingMode.value !== option.mode && "opacity-50"))
									}, {
										default: withCtx(() => [
											createBaseVNode("span", { class: normalizeClass(unref(cn)("mt-0.5 size-4 shrink-0 text-muted-foreground", option.icon)) }, null, 2),
											createBaseVNode("span", _hoisted_4$15, [createBaseVNode("span", _hoisted_5$13, toDisplayString(unref(t)(option.title)), 1), createBaseVNode("span", _hoisted_6$10, toDisplayString(unref(t)(option.description)), 1)]),
											createBaseVNode("span", {
												"aria-hidden": "true",
												class: normalizeClass(unref(cn)("mt-0.5 size-4 shrink-0", savingMode.value === option.mode ? "icon-[lucide--loader-circle] text-muted-foreground motion-safe:animate-spin" : unref(store).mode === option.mode && "icon-[lucide--check] text-foreground"))
											}, null, 2)
										]),
										_: 2
									}, 1032, ["variant", "class"])]),
									_: 2
								}, 1032, [
									"value",
									"disabled",
									"aria-busy"
								]);
							}), 64))]),
							_: 1
						}, 8, ["model-value", "aria-label"])]),
						_: 1
					}, 8, ["aria-describedby"]), open.value ? (openBlock(), createElementBlock("span", _hoisted_7$7, toDisplayString(savingMode.value === null ? "" : unref(t)("g.saving")), 1)) : createCommentVNode("", true)]),
					_: 1
				}))]),
				_: 1
			}, 8, ["open"]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/Composer.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$30 = ["aria-label"];
var _hoisted_2$27 = {
	key: 0,
	class: "flex h-6 items-center px-1.5 py-1 text-xs/4 text-muted-foreground"
};
var _hoisted_3$20 = {
	key: 1,
	class: "flex h-11 shrink-0 items-center rounded-t-lg bg-background px-2"
};
var _hoisted_4$14 = {
	"data-testid": "composer-input-box",
	class: "relative -m-px flex max-h-[50dvh] min-h-28 min-w-0 flex-col rounded-lg border border-border/50 bg-secondary transition-colors focus-within:border-muted-foreground"
};
var _hoisted_5$12 = {
	"data-testid": "composer-inline-input",
	class: "flex max-h-100 min-h-16 flex-col overflow-x-hidden overflow-y-auto"
};
var _hoisted_6$9 = {
	key: 0,
	role: "status",
	class: "-mb-2 flex items-center gap-1 px-3 pt-3 text-xs text-muted-foreground"
};
var _hoisted_7$6 = { class: "grid flex-1" };
var _hoisted_8$4 = { class: "flex shrink-0 items-center justify-between px-3 py-2" };
var _hoisted_9$3 = { class: "flex items-center gap-1" };
var _hoisted_10$2 = { class: "flex items-center gap-1" };
var _hoisted_11$1 = {
	key: 0,
	class: "ml-1 opacity-50"
};
var SKILL_DESCRIPTION_ID = "agent-skill-description";
//#endregion
//#region src/workbench/extensions/agent/components/agent/Composer.vue
var Composer_default = /* @__PURE__ */ defineComponent({
	__name: "Composer",
	props: {
		streaming: {
			type: Boolean,
			default: false
		},
		submitting: {
			type: Boolean,
			default: false
		},
		canAttach: {
			type: Boolean,
			default: false
		},
		canOpenAssets: {
			type: Boolean,
			default: false
		},
		selectionTags: { default: () => [] },
		nodeReferenceDisabledReason: {},
		availableWorkflows: { default: () => [] },
		selectWorkflowReference: {
			type: Function,
			default: async () => void 0
		},
		editableWorkflowId: {},
		hasWorkflowTarget: {
			type: Boolean,
			default: false
		},
		workflowSelecting: {
			type: Boolean,
			default: false
		},
		openingChat: {
			type: Boolean,
			default: false
		},
		getMentionNodes: {
			type: Function,
			default: () => []
		}
	},
	emits: [
		"send",
		"stop",
		"attach",
		"attachFiles",
		"removeAttachment",
		"openAssets",
		"selectNodes",
		"removeTag",
		"mentionPick",
		"requestWorkflowReferences",
		"removeWorkflowReference",
		"openReferenceWorkflow",
		"workflowTargetRequired"
	],
	setup(__props, { expose: __expose, emit: __emit }) {
		const emit = __emit;
		const { t } = useI18n();
		const skills = useSkillPacksStore();
		const running = computed(() => __props.streaming || __props.submitting);
		const composer = useComposer({
			onSend: (_text, attachments) => {
				if (__props.workflowSelecting || __props.submitting) return;
				if (!__props.hasWorkflowTarget) {
					emit("workflowTargetRequired");
					return;
				}
				const prepared = composerPromptForSubmission(composer.prompt.value);
				if (workflowReferences.value.length > 0) {
					const { text: draft, workflowReferences: references } = prepared;
					const offsets = references.map((reference) => reference.textOffset);
					const start = Math.min(draft.length - draft.trimStart().length, ...offsets);
					const end = Math.max(draft.trimEnd().length, ...offsets);
					emit("send", draft.slice(start, end), attachments, references.map((reference) => ({
						...reference,
						textOffset: Math.min(end - start, Math.max(0, reference.textOffset - start))
					})));
				} else emit("send", prepared.text.trim(), attachments);
			},
			isRunning: () => running.value,
			onStop: () => emit("stop", "button")
		});
		const editorRef = useTemplateRef("editorRef");
		watch(() => skills.scope, (scope) => composer.setSkillScope(scope), {
			immediate: true,
			flush: "sync"
		});
		const { workflowReferences } = composer;
		const placeholderLabel = computed(() => t(__props.openingChat ? "agent.openingChat" : skills.enabled ? "agent.placeholder" : "agent.placeholderWithoutSkills"));
		const showPlaceholderHint = computed(() => !composer.draft.value && !composer.prompt.value.references.length);
		const highlightedAssetIds = ref([]);
		const uploadingAttachmentCount = computed(() => composer.attachments.value.filter((item) => item.uploading).length);
		const { eligibleWorkflows, selectWorkflow } = useWorkflowReferencePicker({
			editor: () => editorRef.value,
			references: () => workflowReferences.value,
			workflows: () => __props.availableWorkflows,
			editableWorkflowId: () => __props.editableWorkflowId,
			selecting: () => __props.workflowSelecting,
			resolve: (workflow) => __props.selectWorkflowReference(workflow)
		});
		const { mentionSection, mentionActive, mentionMatches, mentionVisible, mentionActiveNode, mentionHasResults, skillQueryEmpty, graphDupes, syncMention, pickMention, isMentionDisabled, onComposerKeydown: handleMentionKeydown, onComposerKeyup, close: closeMention, highlight: highlightMention } = useAgentMentionPicker({
			draft: () => composer.draft.value,
			editor: () => editorRef.value,
			selectionTags: () => __props.selectionTags,
			workflows: () => eligibleWorkflows.value,
			skills: () => skills.packs,
			skillsEnabled: () => skills.enabled,
			assets: () => composer.attachments.value.filter((item) => !item.validationError),
			nodeReferenceDisabledReason: () => __props.nodeReferenceDisabledReason,
			workflowSelecting: () => __props.workflowSelecting,
			getMentionNodes: () => __props.getMentionNodes(),
			selectWorkflow,
			pickNode: (node) => emit("mentionPick", node),
			pickAsset: (asset) => composer.referenceAttachment(asset.id),
			requestWorkflows: () => emit("requestWorkflowReferences")
		});
		useNodeEmphasisSource(() => {
			const node = mentionActiveNode.value;
			return node && toNodeId(node.id);
		});
		function onSelectNodes(event) {
			if (__props.nodeReferenceDisabledReason) {
				event.preventDefault();
				return;
			}
			emit("selectNodes");
		}
		watch(mentionSection, (section) => {
			if (section === "skills") skills.refreshPacks();
		});
		function draftSkillNeedsRefresh([name, epoch, enabled], [oldName, oldEpoch, oldEnabled, oldSection]) {
			if (!name || !enabled) return false;
			if (epoch !== oldEpoch || enabled !== oldEnabled) return true;
			return name !== oldName && oldSection !== "skills";
		}
		watch([
			() => composer.prompt.value.references.find((reference) => reference.kind === "skill")?.name,
			() => composer.promptEpoch.value,
			() => skills.enabled,
			mentionSection
		], (next, previous) => {
			if (draftSkillNeedsRefresh(next, previous)) skills.refreshPacksInBackground();
		}, { immediate: true });
		function onEditorSelectionChange() {
			const point = editorRef.value?.insertionPoint();
			if (point) composer.setInsertionPoint(point);
			syncMention();
		}
		const { describedSkill, requestDescription, dismissDescription, leaveDescription, keepDescriptionOpen } = useSkillMenuDescription(() => {
			const match = mentionMatches.value[mentionActive.value];
			return match?.kind === "skill" ? match.skill : void 0;
		});
		watch(mentionVisible, (visible) => {
			if (!visible) dismissDescription();
		});
		function onMentionHover(index) {
			highlightMention(index);
			requestDescription("hover");
		}
		function onEditorInput() {
			syncMention();
			if (mentionVisible.value) requestDescription("input");
		}
		function focusEditor() {
			editorRef.value?.focus();
		}
		function isSkillDescription(target) {
			return target instanceof Element && !!target.closest(`#${SKILL_DESCRIPTION_ID}`);
		}
		function onEditorBlur(event) {
			if (!isSkillDescription(event.relatedTarget)) closeMention();
		}
		const editorHostRef = useTemplateRef("editorHostRef");
		function onDescriptionFocusOut(event) {
			const next = event.relatedTarget;
			if (next instanceof Node && editorHostRef.value?.contains(next)) return;
			closeMention();
		}
		function onDescriptionDismiss() {
			closeMention();
			focusEditor();
		}
		const HIGHLIGHT_KEYS = ["ArrowDown", "ArrowUp"];
		function requestKeyboardDescription(event) {
			if (mentionVisible.value && HIGHLIGHT_KEYS.includes(event.key)) requestDescription("input");
		}
		function stopRunOnEscape(event) {
			if (event.key !== "Escape" || !running.value) return;
			if (event.isComposing || event.repeat) return;
			event.preventDefault();
			event.stopPropagation();
			emit("stop", "escape");
		}
		function onComposerKeydown(event) {
			if (__props.openingChat) {
				event.preventDefault();
				return;
			}
			requestKeyboardDescription(event);
			if (handleMentionKeydown(event)) return;
			if (event.key === "Enter") onEnter(event);
			stopRunOnEscape(event);
		}
		const mentionListRef = useTemplateRef("mentionListRef");
		watch(mentionActive, async () => {
			await nextTick();
			mentionListRef.value?.querySelector("[data-active=\"true\"]")?.scrollIntoView?.({ block: "nearest" });
		});
		const mentionMenuLabel = computed(() => t(mentionSection.value === "skills" ? "agent.skills" : "agent.addToPrompt"));
		const mentionMenuHeading = computed(() => {
			if (mentionSection.value === "skills") return t("agent.skills");
			return mentionSection.value === "root" ? t("agent.reference") : void 0;
		});
		const skillsRetryVisible = computed(() => mentionSection.value === "skills" && skills.loadFailed);
		const emptyMentionLabel = computed(() => mentionSection.value === "skills" ? t(skills.loading ? "agent.skillsLoading" : skills.loadFailed ? "agent.skillsLoadError" : "agent.noSkillsFound") : t(mentionSection.value === "workflows" ? "agent.noWorkflowsToReference" : "agent.noNodesToReference"));
		function openReferenceMenu() {
			const editor = editorRef.value;
			if (!editor) return;
			const { start } = editor.selection();
			const needsSeparator = start > 0 && !/\s/.test(composer.draft.value[start - 1] ?? "");
			editor.insertText(needsSeparator ? " @" : "@");
			editor.focus();
			syncMention();
		}
		function onEnter(event) {
			if (event.isComposing || event.shiftKey) return;
			event.preventDefault();
			if (running.value) return;
			composer.submit();
		}
		const primaryActionLabel = computed(() => running.value ? t("agent.stop") : t("agent.send"));
		const primaryActionVariant = computed(() => running.value ? "secondary" : "inverted");
		const SEND_BLOCKED_MESSAGES = {
			"invalid-video": "agent.sendBlockedByInvalidVideo",
			"unsupported-type": "agent.sendBlockedByUnsupportedType"
		};
		const sendBlockedReason = computed(() => {
			const invalid = composer.attachments.value.flatMap(({ name, validationError }) => validationError ? [{
				name,
				validationError
			}] : []);
			if (running.value || invalid.length === 0) return void 0;
			if (invalid.length > 1) return t("agent.sendBlockedByInvalidAttachments", { count: invalid.length });
			const [{ name, validationError }] = invalid;
			return t(SEND_BLOCKED_MESSAGES[validationError], { name });
		});
		const primaryActionTooltip = computed(() => sendBlockedReason.value ?? primaryActionLabel.value);
		const primaryActionAriaDisabled = computed(() => sendBlockedReason.value ? true : void 0);
		const primaryActionDisabled = computed(() => __props.openingChat || !running.value && !sendBlockedReason.value && (__props.workflowSelecting || !composer.canSend.value));
		const skillSearchHint = computed(() => skillQueryEmpty.value ? t("agent.typeToSearch") : void 0);
		const activeMentionDescendant = computed(() => mentionVisible.value && mentionActive.value >= 0 ? `agent-reference-item-${mentionActive.value}` : void 0);
		const primaryActionShortcut = computed(() => running.value ? t("agent.stopShortcut") : void 0);
		function onPrimaryAction() {
			if (__props.openingChat) return;
			if (running.value) emit("stop", "button");
			else composer.submit();
		}
		const composerContainerRef = useTemplateRef("composerContainerRef");
		function focusAllowsComposerStop() {
			const active = document.activeElement;
			return active === null || active === document.body || composerContainerRef.value?.contains(active) === true;
		}
		function handleEscapeOverride(event) {
			if (__props.openingChat || event.key !== "Escape" || !running.value || event.isComposing) return false;
			if (event.defaultPrevented) return false;
			if (!focusAllowsComposerStop()) return false;
			event.preventDefault();
			if (!event.repeat) emit("stop", "escape");
			return true;
		}
		let unregisterEscapeOverride;
		onMounted(() => {
			skills.startFlagGate({ fetch: false });
			unregisterEscapeOverride = registerEscapeOverride(handleEscapeOverride);
		});
		onUnmounted(() => {
			unregisterEscapeOverride?.();
		});
		function insert(text, starterPrompt) {
			composer.insert(text, starterPrompt);
			editorRef.value?.focus();
		}
		function replaceDraft(prompt) {
			composer.replacePrompt(prompt);
			editorRef.value?.focus();
		}
		function removeAttachment(id) {
			composer.removeAttachment(id);
			emit("removeAttachment", id);
		}
		__expose({
			insert,
			replaceDraft,
			addAttachment: composer.addAttachment,
			updateAttachment: composer.updateAttachment,
			removeAttachment: composer.removeAttachment
		});
		return (_ctx, _cache) => {
			const _component_i_lucide58square = square_default;
			const _component_i_lucide58arrow_up = arrow_up_default;
			return openBlock(), createElementBlock("div", {
				id: "agent-composer",
				ref_key: "composerContainerRef",
				ref: composerContainerRef,
				"data-testid": "agent-composer",
				class: "relative flex min-w-0 flex-col rounded-lg border border-border/50 bg-background"
			}, [
				unref(mentionVisible) ? (openBlock(), createElementBlock("div", {
					key: 0,
					id: "agent-reference-menu",
					ref_key: "mentionListRef",
					ref: mentionListRef,
					"data-testid": "agent-reference-menu",
					role: "menu",
					"aria-label": mentionMenuLabel.value,
					class: "absolute inset-x-0 bottom-full z-1100 -mb-8.75 max-h-64 overflow-y-auto rounded-lg border border-border/50 bg-secondary p-1 font-inter shadow-md",
					onMousedown: _cache[1] || (_cache[1] = withModifiers(() => {}, ["prevent"])),
					onMouseleave: _cache[2] || (_cache[2] = (...args) => unref(leaveDescription) && unref(leaveDescription)(...args))
				}, [
					mentionMenuHeading.value ? (openBlock(), createElementBlock("div", _hoisted_2$27, toDisplayString(mentionMenuHeading.value), 1)) : createCommentVNode("", true),
					(openBlock(true), createElementBlock(Fragment, null, renderList(unref(mentionMatches), (match, index) => {
						return openBlock(), createBlock(MentionMenuItem_default, {
							key: `${match.kind}:${match.id}`,
							match,
							index,
							active: index === unref(mentionActive),
							disabled: unref(isMentionDisabled)(match),
							"node-reference-disabled-reason": __props.nodeReferenceDisabledReason,
							"duplicate-node-titles": unref(graphDupes),
							"described-skill": unref(describedSkill),
							"description-id": SKILL_DESCRIPTION_ID,
							onHighlight: ($event) => onMentionHover(index),
							onPick: ($event) => unref(pickMention)(match),
							onDescriptionEnter: unref(keepDescriptionOpen),
							onDescriptionLeave: unref(leaveDescription),
							onDescriptionFocusout: onDescriptionFocusOut,
							onDescriptionReleaseFocus: focusEditor,
							onDescriptionDismiss
						}, null, 8, [
							"match",
							"index",
							"active",
							"disabled",
							"node-reference-disabled-reason",
							"duplicate-node-titles",
							"described-skill",
							"onHighlight",
							"onPick",
							"onDescriptionEnter",
							"onDescriptionLeave"
						]);
					}), 128)),
					!unref(mentionHasResults) ? (openBlock(), createBlock(MentionMenuStatus_default, {
						key: 1,
						label: emptyMentionLabel.value,
						retryable: skillsRetryVisible.value,
						onRetry: _cache[0] || (_cache[0] = ($event) => unref(skills).ensurePacks())
					}, null, 8, ["label", "retryable"])) : createCommentVNode("", true)
				], 40, _hoisted_1$30)) : createCommentVNode("", true),
				_ctx.$slots.header ? (openBlock(), createElementBlock("div", _hoisted_3$20, [renderSlot(_ctx.$slots, "header")])) : createCommentVNode("", true),
				renderSlot(_ctx.$slots, "aboveInput"),
				createBaseVNode("div", _hoisted_4$14, [
					renderSlot(_ctx.$slots, "insideInput"),
					unref(composer).attachments.value.length ? (openBlock(), createBlock(AssetTray_default, {
						key: 0,
						attachments: unref(composer).attachments.value,
						"highlighted-ids": highlightedAssetIds.value,
						onRemove: removeAttachment
					}, null, 8, ["attachments", "highlighted-ids"])) : createCommentVNode("", true),
					createBaseVNode("div", {
						"data-testid": "composer-upload-status",
						"aria-live": "polite",
						"aria-atomic": "true",
						class: normalizeClass(unref(cn)("flex shrink-0 items-center gap-1 text-xs text-muted-foreground", uploadingAttachmentCount.value > 0 && "px-3 pb-2"))
					}, [uploadingAttachmentCount.value > 0 ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [_cache[11] || (_cache[11] = createBaseVNode("span", {
						"aria-hidden": "true",
						class: "icon-[lucide--loader-circle] size-3 animate-spin"
					}, null, -1)), createTextVNode(" " + toDisplayString(unref(t)("agent.uploadingAttachments", uploadingAttachmentCount.value)), 1)], 64)) : createCommentVNode("", true)], 2),
					createBaseVNode("div", _hoisted_5$12, [__props.workflowSelecting ? (openBlock(), createElementBlock("div", _hoisted_6$9, [_cache[12] || (_cache[12] = createBaseVNode("span", { class: "icon-[lucide--loader-circle] size-3 animate-spin" }, null, -1)), createTextVNode(" " + toDisplayString(unref(t)("agent.savingWorkflow")), 1)])) : createCommentVNode("", true), createBaseVNode("div", _hoisted_7$6, [createBaseVNode("div", {
						ref_key: "editorHostRef",
						ref: editorHostRef,
						class: "col-start-1 row-start-1 flex flex-col"
					}, [createVNode(InlinePromptEditor_default, {
						ref_key: "editorRef",
						ref: editorRef,
						"model-value": unref(composer).prompt.value,
						label: placeholderLabel.value,
						expanded: unref(mentionVisible),
						"active-descendant": activeMentionDescendant.value,
						"search-hint": skillSearchHint.value,
						"history-epoch": unref(composer).promptEpoch.value,
						"editable-workflow-id": __props.editableWorkflowId,
						"skill-scope": unref(skills).scope,
						onKeydown: onComposerKeydown,
						"onUpdate:modelValue": unref(composer).applyEditorPrompt,
						onResolveSkillMetadata: unref(composer).resolveSkillMetadata,
						onKeyup: unref(onComposerKeyup),
						onInput: onEditorInput,
						onSelectionChange: onEditorSelectionChange,
						onClick: unref(syncMention),
						onBlur: onEditorBlur,
						onAttachFiles: _cache[3] || (_cache[3] = ($event) => emit("attachFiles", $event)),
						onOpenReferenceWorkflow: _cache[4] || (_cache[4] = (id, name) => emit("openReferenceWorkflow", id, name)),
						onRemoveNodeReference: _cache[5] || (_cache[5] = ($event) => emit("removeTag", $event)),
						onHighlightAssets: _cache[6] || (_cache[6] = ($event) => highlightedAssetIds.value = $event),
						onRemoveWorkflowReference: _cache[7] || (_cache[7] = ($event) => emit("removeWorkflowReference", $event))
					}, null, 8, [
						"model-value",
						"label",
						"expanded",
						"active-descendant",
						"search-hint",
						"history-epoch",
						"editable-workflow-id",
						"skill-scope",
						"onUpdate:modelValue",
						"onResolveSkillMetadata",
						"onKeyup",
						"onClick"
					])], 512), createVNode(ComposerPlaceholder_default, {
						label: placeholderLabel.value,
						visible: showPlaceholderHint.value,
						"node-reference-disabled-reason": __props.nodeReferenceDisabledReason,
						onSelectNodes
					}, null, 8, [
						"label",
						"visible",
						"node-reference-disabled-reason"
					])])]),
					createBaseVNode("div", _hoisted_8$4, [createBaseVNode("div", _hoisted_9$3, [createVNode(ComposerAddMenu_default, {
						"can-attach": __props.canAttach,
						"can-open-assets": __props.canOpenAssets,
						"node-reference-disabled-reason": __props.nodeReferenceDisabledReason,
						workflows: unref(eligibleWorkflows),
						"workflow-selecting": __props.workflowSelecting,
						"select-workflow": unref(selectWorkflow),
						onSelectNodes,
						onAttach: _cache[8] || (_cache[8] = ($event) => emit("attach")),
						onOpenAssets: _cache[9] || (_cache[9] = ($event) => emit("openAssets")),
						onRequestWorkflowReferences: _cache[10] || (_cache[10] = ($event) => emit("requestWorkflowReferences"))
					}, null, 8, [
						"can-attach",
						"can-open-assets",
						"node-reference-disabled-reason",
						"workflows",
						"workflow-selecting",
						"select-workflow"
					]), createVNode(Button_default, {
						tooltip: unref(t)("agent.reference"),
						type: "button",
						variant: "muted-textonly",
						size: "icon",
						"aria-label": unref(t)("agent.reference"),
						onClick: openReferenceMenu
					}, {
						default: withCtx(() => [..._cache[13] || (_cache[13] = [createBaseVNode("span", { class: "text-base/4 font-medium" }, "@", -1)])]),
						_: 1
					}, 8, ["tooltip", "aria-label"])]), createBaseVNode("div", _hoisted_10$2, [createVNode(RunModePopover_default), createVNode(Button_default, {
						tooltip: primaryActionTooltip.value,
						type: "button",
						variant: primaryActionVariant.value,
						size: "icon",
						"aria-label": primaryActionLabel.value,
						"aria-disabled": primaryActionAriaDisabled.value,
						"aria-description": sendBlockedReason.value,
						disabled: primaryActionDisabled.value,
						class: "aria-disabled:cursor-not-allowed aria-disabled:opacity-50 aria-disabled:hover:bg-foreground",
						onClick: onPrimaryAction
					}, {
						tooltip: withCtx(() => [createTextVNode(toDisplayString(primaryActionTooltip.value) + " ", 1), primaryActionShortcut.value ? (openBlock(), createElementBlock("span", _hoisted_11$1, toDisplayString(primaryActionShortcut.value), 1)) : createCommentVNode("", true)]),
						default: withCtx(() => [running.value ? (openBlock(), createBlock(_component_i_lucide58square, {
							key: 0,
							class: "size-4"
						})) : (openBlock(), createBlock(_component_i_lucide58arrow_up, {
							key: 1,
							class: "size-4"
						}))]),
						_: 1
					}, 8, [
						"tooltip",
						"variant",
						"aria-label",
						"aria-disabled",
						"aria-description",
						"disabled"
					])])])
				])
			], 512);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/utils/replyAssets.ts
function isReplyAssetKind(value) {
	return value === "image" || value === "video" || value === "audio" || value === "3D";
}
/**
* Moves a loopback ComfyUI media URL onto the page's API route and returns any
* other URL unchanged.
*/
function resolveAgentAssetUrl(href) {
	const url = URL.parse(href) ?? (href.startsWith("//") ? URL.parse(href, window.location.origin) : null);
	if (!url) return href;
	if (url.protocol !== "http:" && url.protocol !== "https:") return href;
	if (!isLoopbackHost(url.hostname)) return href;
	if (!isMediaRoute(`${url.pathname}${url.search}`)) return href;
	const rehomed = URL.parse(api.apiURL(`${url.pathname}${url.search}`), window.location.origin);
	if (!rehomed) return href;
	rehomed.hash = url.hash;
	return rehomed.href;
}
var SRCSET_SPACE = /[\t\n\f\r ]/;
function srcsetCandidates(value) {
	const candidates = [];
	let position = skipSrcsetSeparators(value, 0);
	while (position < value.length) {
		const [rawUrl, afterUrl] = readSrcsetUrl(value, position);
		const closesCandidate = rawUrl.endsWith(",");
		const [descriptor, next] = closesCandidate ? ["", afterUrl] : readSrcsetDescriptor(value, afterUrl);
		const url = closesCandidate ? rawUrl.replace(/,+$/, "") : rawUrl;
		if (url) candidates.push({
			url,
			descriptor
		});
		position = skipSrcsetSeparators(value, next);
	}
	return candidates;
}
function isSrcsetSpace(c) {
	return SRCSET_SPACE.test(c);
}
function skipSrcsetSeparators(value, position) {
	while (position < value.length && (isSrcsetSpace(value[position]) || value[position] === ",")) position++;
	return position;
}
function readSrcsetUrl(value, position) {
	const start = position;
	while (position < value.length && !isSrcsetSpace(value[position])) position++;
	return [value.slice(start, position), position];
}
function readSrcsetDescriptor(value, position) {
	const start = position;
	let inParens = false;
	for (; position < value.length; position++) {
		const c = value[position];
		if (c === "," && !inParens) break;
		if (c === "(") inParens = true;
		else if (c === ")") inParens = false;
	}
	return [value.slice(start, position).trim(), position + 1];
}
function resolveSrcset(value) {
	const candidates = srcsetCandidates(value).map((candidate) => ({
		...candidate,
		target: resolveAgentAssetUrl(candidate.url)
	}));
	if (candidates.every(({ url, target }) => target === url)) return value;
	return candidates.map(({ target, descriptor }) => descriptor ? `${target} ${descriptor}` : target).join(", ");
}
var REWRITABLE_ATTRS = [
	"src",
	"href",
	"poster",
	"srcset"
];
var MAYBE_MEDIA_ROUTE = /[/\\](?:view|vhs[/\\]|assets[/\\])/;
function rewriteAgentAssetHtml(html) {
	if (!MAYBE_MEDIA_ROUTE.test(html)) return html;
	const template = document.createElement("template");
	template.innerHTML = html;
	let rewritten = false;
	for (const element of template.content.querySelectorAll(REWRITABLE_ATTRS.map((name) => `[${name}]`).join(", "))) for (const name of REWRITABLE_ATTRS) {
		const value = element.getAttribute(name);
		if (value === null) continue;
		const resolved = name === "srcset" ? resolveSrcset(value) : resolveAgentAssetUrl(value);
		if (resolved === value) continue;
		element.setAttribute(name, resolved);
		rewritten = true;
	}
	return rewritten ? template.innerHTML : html;
}
function classifyAssetUrl(href, baseUrl = window.location.origin) {
	let url;
	try {
		url = new URL(href, baseUrl);
	} catch {
		return null;
	}
	let filename = url.searchParams.get("filename");
	try {
		filename ??= decodeURIComponent(url.pathname.split("/").at(-1) ?? "");
	} catch {
		return null;
	}
	if (!filename) return null;
	const kind = getMediaTypeFromFilename(filename);
	if (!isReplyAssetKind(kind)) return null;
	return {
		url: resolveAgentAssetUrl(href),
		filename,
		kind
	};
}
function scanInline(tokens) {
	const scan = {
		assets: [],
		sawImageSyntax: false
	};
	for (const token of tokens ?? []) if (token.type === "image" || token.type === "link") {
		const asset = token.href ? classifyAssetUrl(token.href) : null;
		if (!asset) return null;
		if (token.type === "image") {
			scan.sawImageSyntax = true;
			if (token.text) asset.label = token.text;
		}
		scan.assets.push(asset);
	} else if (token.type === "br" || token.type === "space") continue;
	else if (token.type === "text" && (token.text ?? "").trim() === "") continue;
	else return null;
	return scan.assets.length ? scan : null;
}
function selectAssets(scan) {
	const { assets, sawImageSyntax } = scan;
	if (assets.length > 1 || sawImageSyntax) return assets;
	return assets[0].kind === "image" ? null : assets;
}
function tokenReplyAssets(token) {
	if (token.type === "paragraph") {
		const scan = scanInline(token.tokens);
		return scan ? selectAssets(scan) : null;
	}
	if (token.type !== "list") return null;
	const combined = {
		assets: [],
		sawImageSyntax: false
	};
	for (const item of token.items) for (const block of item.tokens) {
		if (block.type !== "text" && block.type !== "paragraph") return null;
		const scan = scanInline(block.tokens);
		if (!scan) return null;
		combined.assets.push(...scan.assets);
		combined.sawImageSyntax ||= scan.sawImageSyntax;
	}
	return combined.assets.length ? selectAssets(combined) : null;
}
function htmlReplyAssets(html) {
	const doc = new DOMParser().parseFromString(html, "text/html");
	const seen = /* @__PURE__ */ new Set();
	const out = [];
	for (const element of doc.querySelectorAll("a[href], img[src]")) {
		const asset = classifyAssetUrl(element.getAttribute("href") ?? element.getAttribute("src") ?? "");
		if (asset && !seen.has(asset.url)) {
			seen.add(asset.url);
			out.push(asset);
		}
	}
	return out;
}
function replyAssetResultItem(asset) {
	return {
		filename: asset.filename,
		subfolder: "",
		type: "output",
		nodeId: "",
		mediaType: asset.kind === "image" ? "images" : asset.kind,
		mediaTypeIsResolved: true,
		url: asset.url
	};
}
//#endregion
//#region src/workbench/extensions/agent/services/agent/agentActivityRows.ts
function matchingToolStep(previous, part) {
	if (previous?.kind !== "tool" || previous.name !== part.name || part.name === "load_skill" && previous.skill !== part.skill) return void 0;
	return previous;
}
function foldCanvasConfirmed(previous, next) {
	if (previous === false || next === false) return false;
	return previous ?? next;
}
function foldActivity(parts) {
	const rows = [];
	for (const part of parts) {
		if (part.type === "thinking") {
			rows.push({
				kind: "thinking",
				text: part.text,
				state: part.state
			});
			continue;
		}
		const previous = matchingToolStep(rows.at(-1), part);
		if (previous) {
			previous.count += 1;
			if (part.state === "streaming") previous.state = "streaming";
			if (part.ok !== void 0) previous.ok = part.ok;
			previous.canvasConfirmed = foldCanvasConfirmed(previous.canvasConfirmed, part.canvasConfirmed);
		} else rows.push({
			kind: "tool",
			name: part.name,
			skill: part.skill,
			state: part.state,
			ok: part.ok,
			canvasConfirmed: part.canvasConfirmed,
			count: 1
		});
	}
	return rows;
}
//#endregion
//#region src/workbench/extensions/agent/services/agent/agentToolGlyph.ts
var KNOWN_TOOLS = {
	new_tab: {
		labelKey: "agent.toolOpenedNewTab",
		activeLabelKey: "agent.toolOpeningNewTab",
		icon: "icon-[lucide--plus]"
	},
	switch_tab: {
		labelKey: "agent.toolSwitchedTabs",
		activeLabelKey: "agent.toolSwitchingTabs",
		icon: "icon-[lucide--arrow-left-right]"
	},
	remember: {
		labelKey: "agent.toolSavedPreference",
		activeLabelKey: "agent.toolSavingPreference",
		icon: "icon-[lucide--save]"
	},
	forget: {
		labelKey: "agent.toolForgotPreference",
		activeLabelKey: "agent.toolForgettingPreference",
		icon: "icon-[lucide--circle-question-mark]"
	}
};
function knownTool(name) {
	return Object.hasOwn(KNOWN_TOOLS, name) ? KNOWN_TOOLS[name] : void 0;
}
function toolLabel(name, state, translate) {
	const known = knownTool(name);
	if (known) return translate(state === "streaming" ? known.activeLabelKey : known.labelKey);
	return upperFirst(name.replaceAll("_", " "));
}
function toolGlyph(name, state, outcome = {}) {
	if (state === "streaming") return "animate-spin icon-[lucide--loader-circle]";
	if (outcome.ok === false) return "icon-[lucide--circle-x]";
	if (isUnconfirmedCanvasWrite(outcome)) return "icon-[lucide--triangle-alert]";
	return knownTool(name)?.icon ?? "icon-[lucide--wrench]";
}
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/ActivityTrace.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$29 = {
	role: "list",
	"data-testid": "agent-activity-trace",
	class: "flex flex-col"
};
var _hoisted_2$26 = { class: "flex w-4 shrink-0 flex-col items-center" };
var _hoisted_3$19 = {
	key: 0,
	class: "mt-1 w-px flex-1 bg-border"
};
var _hoisted_4$13 = { class: "flex min-w-0 flex-1 items-start gap-2 pb-3" };
var _hoisted_5$11 = {
	key: 0,
	class: "mt-0.5 shrink-0 text-xs text-muted-foreground"
};
var LABEL = "text-muted-foreground min-w-0 text-sm/5";
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/ActivityTrace.vue
var ActivityTrace_default = /* @__PURE__ */ defineComponent({
	__name: "ActivityTrace",
	props: {
		parts: {},
		live: {
			type: Boolean,
			default: false
		}
	},
	setup(__props) {
		const { t } = useI18n();
		const rows = computed(() => foldActivity(__props.parts));
		const LABEL_STREAMING = `${LABEL} agent-shimmer-text`;
		function labelClass(state) {
			return state === "streaming" ? LABEL_STREAMING : LABEL;
		}
		function glyphOf(row) {
			return row.kind === "thinking" ? "icon-[lucide--brain]" : toolGlyph(row.name, row.state, row);
		}
		function labelOf(row) {
			if (isUnconfirmedCanvasWrite(row)) return t("agent.toolNotConfirmedOnCanvas", { tool: toolLabel(row.name, row.state, t) });
			if (row.name === "load_skill" && row.skill) {
				const label = row.state === "streaming" ? "agent.toolLoadingSkill" : row.ok === false ? "agent.toolFailedSkill" : "agent.toolLoadedSkill";
				return t(label, { skill: row.skill });
			}
			return toolLabel(row.name, row.state, t);
		}
		function rowSignature(row) {
			return row.kind === "tool" ? JSON.stringify([
				"tool",
				row.name,
				row.skill,
				row.state,
				row.ok,
				row.canvasConfirmed,
				row.count
			]) : `think:${row.state}:${row.text}`;
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$29, [(openBlock(true), createElementBlock(Fragment, null, renderList(rows.value, (row, index, ___, _cached) => {
				const _memo = [
					rowSignature(row),
					index === rows.value.length - 1,
					__props.live
				];
				if (_cached && _cached.el && _cached.key === index && isMemoSame(_cached, _memo)) return _cached;
				const _item = (openBlock(), createElementBlock("div", {
					key: index,
					role: "listitem",
					class: normalizeClass(unref(cn)("flex gap-2 px-2", __props.live && "agent-row-enter"))
				}, [createBaseVNode("div", _hoisted_2$26, [createBaseVNode("span", { class: normalizeClass(unref(cn)("mt-0.5 size-4 shrink-0 text-muted-foreground", glyphOf(row))) }, null, 2), index < rows.value.length - 1 ? (openBlock(), createElementBlock("span", _hoisted_3$19)) : createCommentVNode("", true)]), createBaseVNode("div", _hoisted_4$13, [row.kind === "thinking" ? (openBlock(), createElementBlock("span", {
					key: 0,
					class: normalizeClass(unref(cn)(labelClass(row.state), "wrap-break-word whitespace-pre-wrap"))
				}, toDisplayString(row.text || unref(t)("agent.thinking")), 3)) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [createBaseVNode("span", { class: normalizeClass(unref(cn)(labelClass(row.state), "truncate")) }, toDisplayString(labelOf(row)), 3), row.count > 1 ? (openBlock(), createElementBlock("span", _hoisted_5$11, "×" + toDisplayString(row.count), 1)) : createCommentVNode("", true)], 64))])], 2));
				_item.memo = _memo;
				return _item;
			}, _cache, 0), 128))]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/AgentNoticeCard.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$28 = ["role"];
var _hoisted_2$25 = { class: "flex flex-col gap-0.5" };
var _hoisted_3$18 = {
	key: 0,
	class: "text-xs text-muted-foreground"
};
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/AgentNoticeCard.vue
var AgentNoticeCard_default = /* @__PURE__ */ defineComponent({
	__name: "AgentNoticeCard",
	props: { part: {} },
	setup(__props) {
		const { t } = useI18n();
		const notice = computed(() => __props.part.type === "askUnavailable" ? {
			type: "notice",
			level: "warning",
			text: t("agent.askUnavailable")
		} : __props.part);
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				role: notice.value.level === "error" ? "alert" : "status",
				class: normalizeClass(unref(cn)("flex items-start gap-2 rounded-xl border px-3 py-2 text-sm", notice.value.level === "error" ? "border-destructive/40 text-destructive" : "border-border text-muted-foreground"))
			}, [_cache[0] || (_cache[0] = createBaseVNode("span", { class: "mt-0.5 icon-[lucide--triangle-alert] size-4 shrink-0" }, null, -1)), createBaseVNode("span", _hoisted_2$25, [createBaseVNode("span", null, toDisplayString(notice.value.text), 1), notice.value.retryAfterSeconds !== void 0 ? (openBlock(), createElementBlock("span", _hoisted_3$18, toDisplayString(unref(t)("agent.retryAfterSeconds", { seconds: notice.value.retryAfterSeconds })), 1)) : createCommentVNode("", true)])], 10, _hoisted_1$28);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/AgentPaywallCard.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$27 = { class: "flex w-full items-start gap-2" };
var _hoisted_2$24 = { class: "min-w-0 flex-1 text-sm/5" };
var _hoisted_3$17 = { class: "m-0" };
var _hoisted_4$12 = { class: "m-0 text-muted-foreground" };
var _hoisted_5$10 = {
	key: 0,
	class: "flex w-full justify-end gap-2"
};
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/AgentPaywallCard.vue
var AgentPaywallCard_default = /* @__PURE__ */ defineComponent({
	__name: "AgentPaywallCard",
	props: {
		presentation: { default: () => DEFAULT_AGENT_PAYWALL_PRESENTATION },
		message: {}
	},
	emits: ["paywallAction"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const bodyKeys = {
			subscribed: "agent.paywall.body.subscribed",
			subscriptionRequired: "agent.paywall.body.subscriptionRequired",
			member: "agent.paywall.body.member",
			salesManaged: "agent.paywall.body.salesManaged",
			local: "agent.paywall.body.local",
			unavailable: "agent.paywall.body.subscriptionRequired"
		};
		const bodyKey = computed(() => bodyKeys[__props.presentation.kind]);
		const showUpgrade = computed(() => __props.presentation.kind === "subscribed" && __props.presentation.showUpgrade);
		const showSubscribe = computed(() => __props.presentation.kind === "subscriptionRequired");
		const showAddCredits = computed(() => __props.presentation.kind === "subscribed" || __props.presentation.kind === "local");
		return (_ctx, _cache) => {
			return openBlock(), createBlock(Card_default, {
				surface: "secondary",
				role: "alert",
				class: "flex w-full flex-col justify-center gap-2 overflow-hidden p-4 shadow-sm"
			}, {
				default: withCtx(() => [createBaseVNode("div", _hoisted_1$27, [_cache[3] || (_cache[3] = createBaseVNode("span", {
					"aria-hidden": "true",
					class: "mt-0.5 icon-[lucide--gauge] size-5 shrink-0 text-destructive"
				}, null, -1)), createBaseVNode("div", _hoisted_2$24, [createBaseVNode("p", _hoisted_3$17, toDisplayString(_ctx.$t("agent.paywall.title")), 1), createBaseVNode("p", _hoisted_4$12, toDisplayString(__props.message || _ctx.$t(bodyKey.value)), 1)])]), showAddCredits.value || showSubscribe.value || showUpgrade.value ? (openBlock(), createElementBlock("div", _hoisted_5$10, [
					showUpgrade.value ? (openBlock(), createBlock(Button_default, {
						key: 0,
						variant: "secondary",
						size: "sm",
						onClick: _cache[0] || (_cache[0] = ($event) => emit("paywallAction", "upgrade"))
					}, {
						default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("agent.paywall.upgradePlan")), 1)]),
						_: 1
					})) : createCommentVNode("", true),
					showSubscribe.value ? (openBlock(), createBlock(Button_default, {
						key: 1,
						variant: "inverted",
						size: "sm",
						onClick: _cache[1] || (_cache[1] = ($event) => emit("paywallAction", "subscribe"))
					}, {
						default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("agent.paywall.subscribe")), 1)]),
						_: 1
					})) : createCommentVNode("", true),
					showAddCredits.value ? (openBlock(), createBlock(Button_default, {
						key: 2,
						variant: "inverted",
						size: "sm",
						onClick: _cache[2] || (_cache[2] = ($event) => emit("paywallAction", "addCredits"))
					}, {
						default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("agent.paywall.addCredits")), 1)]),
						_: 1
					})) : createCommentVNode("", true)
				])) : createCommentVNode("", true)]),
				_: 1
			});
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/AskUserAnswer.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$26 = {
	role: "status",
	class: "flex min-w-0 flex-col gap-1 text-sm/5"
};
var _hoisted_2$23 = {
	key: 0,
	class: "m-0 flex list-none flex-col gap-0.5 p-0"
};
var _hoisted_3$16 = { class: "min-w-0 wrap-break-word" };
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/AskUserAnswer.vue
var AskUserAnswer_default = /* @__PURE__ */ defineComponent({
	__name: "AskUserAnswer",
	props: {
		resolution: {},
		options: {}
	},
	setup(__props) {
		const { t } = useI18n();
		const answers = computed(() => {
			if (__props.resolution.status !== "answered") return [];
			const labels = new Map(__props.options.map(({ id, label }) => [id, label]));
			const chosen = __props.resolution.selected.map((id) => labels.get(id) ?? id);
			return __props.resolution.otherText ? [...chosen, t("agent.askUser.otherAnswer", { text: __props.resolution.otherText }, { escapeParameter: false })] : chosen;
		});
		const STATUS_TEXT = {
			answered: "agent.askUser.answered",
			closed: "agent.askUser.closed",
			retired: "agent.askUser.retired",
			unconfirmed: "agent.askUser.unconfirmed"
		};
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$26, [createBaseVNode("p", { class: normalizeClass(unref(cn)("m-0 text-muted-foreground", answers.value.length > 0 && "text-xs/5")) }, toDisplayString(unref(t)(STATUS_TEXT[__props.resolution.status])), 3), answers.value.length > 0 ? (openBlock(), createElementBlock("ul", _hoisted_2$23, [(openBlock(true), createElementBlock(Fragment, null, renderList(answers.value, (answer, index) => {
				return openBlock(), createElementBlock("li", {
					key: index,
					class: "flex items-start gap-2 text-foreground"
				}, [_cache[0] || (_cache[0] = createBaseVNode("i", { class: "mt-0.5 icon-[lucide--check] size-4 shrink-0 text-primary" }, null, -1)), createBaseVNode("span", _hoisted_3$16, toDisplayString(answer), 1)]);
			}), 128))])) : createCommentVNode("", true)]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/AskUserOptionLabel.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$25 = ["for"];
var _hoisted_2$22 = ["id"];
var _hoisted_3$15 = ["id"];
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/AskUserOptionLabel.vue
var AskUserOptionLabel_default = /* @__PURE__ */ defineComponent({
	__name: "AskUserOptionLabel",
	props: {
		optionId: {},
		option: {},
		disabled: {
			type: Boolean,
			default: false
		}
	},
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("label", {
				for: __props.optionId,
				class: normalizeClass(unref(cn)("flex min-w-0 flex-1 cursor-pointer flex-col", __props.disabled && "cursor-not-allowed opacity-50"))
			}, [createBaseVNode("span", {
				id: `${__props.optionId}-label`,
				class: "wrap-break-word text-foreground"
			}, toDisplayString(__props.option.label), 9, _hoisted_2$22), __props.option.description ? (openBlock(), createElementBlock("span", {
				key: 0,
				id: `${__props.optionId}-description`,
				class: "text-xs/5 wrap-break-word text-muted-foreground"
			}, toDisplayString(__props.option.description), 9, _hoisted_3$15)) : createCommentVNode("", true)], 10, _hoisted_1$25);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/askUserOptions.ts
var askUserOptionRowClass = "flex items-start gap-2 rounded-md px-2 py-1.5 transition-colors hover:bg-accent";
function askUserOptionId(idPrefix, index) {
	return `${idPrefix}-option-${index}`;
}
function askUserOptionDescribedBy(idPrefix, option, index) {
	return option.description ? `${askUserOptionId(idPrefix, index)}-description` : void 0;
}
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/AskUserCheckboxOptions.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$24 = ["aria-labelledby", "aria-describedby"];
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/AskUserCheckboxOptions.vue
var AskUserCheckboxOptions_default = /* @__PURE__ */ defineComponent({
	__name: "AskUserCheckboxOptions",
	props: /*@__PURE__*/ mergeModels({
		options: {},
		idPrefix: {},
		labelledBy: {},
		describedBy: {},
		disabled: {
			type: Boolean,
			default: false
		},
		full: {
			type: Boolean,
			default: false
		}
	}, {
		"modelValue": { required: true },
		"modelModifiers": {}
	}),
	emits: ["update:modelValue"],
	setup(__props) {
		const selected = useModel(__props, "modelValue");
		function optionDisabled(id) {
			return __props.disabled || __props.full && !selected.value.includes(id);
		}
		function toggle(id) {
			selected.value = xor(selected.value, [id]);
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				role: "group",
				"aria-labelledby": __props.labelledBy,
				"aria-describedby": __props.describedBy,
				class: "flex flex-col gap-0.5 text-sm/5"
			}, [(openBlock(true), createElementBlock(Fragment, null, renderList(__props.options, (option, index) => {
				return openBlock(), createElementBlock("div", {
					key: option.id,
					class: normalizeClass(unref(askUserOptionRowClass))
				}, [createVNode(Checkbox_default, {
					id: unref(askUserOptionId)(__props.idPrefix, index),
					"model-value": selected.value.includes(option.id),
					disabled: optionDisabled(option.id),
					"aria-labelledby": `${unref(askUserOptionId)(__props.idPrefix, index)}-label`,
					"aria-describedby": unref(askUserOptionDescribedBy)(__props.idPrefix, option, index),
					class: "mt-0.5 p-0",
					"onUpdate:modelValue": ($event) => toggle(option.id)
				}, null, 8, [
					"id",
					"model-value",
					"disabled",
					"aria-labelledby",
					"aria-describedby",
					"onUpdate:modelValue"
				]), createVNode(AskUserOptionLabel_default, {
					"option-id": unref(askUserOptionId)(__props.idPrefix, index),
					option,
					disabled: optionDisabled(option.id)
				}, null, 8, [
					"option-id",
					"option",
					"disabled"
				])], 2);
			}), 128))], 8, _hoisted_1$24);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/AskUserRadioOptions.vue
var AskUserRadioOptions_default = /* @__PURE__ */ defineComponent({
	__name: "AskUserRadioOptions",
	props: /*@__PURE__*/ mergeModels({
		options: {},
		idPrefix: {},
		labelledBy: {},
		disabled: {
			type: Boolean,
			default: false
		}
	}, {
		"modelValue": {},
		"modelModifiers": {}
	}),
	emits: ["update:modelValue"],
	setup(__props) {
		const modelValue = useModel(__props, "modelValue");
		function choose(value) {
			if (typeof value === "string") modelValue.value = value;
		}
		return (_ctx, _cache) => {
			return openBlock(), createBlock(RadioGroup_default, {
				"model-value": modelValue.value,
				disabled: __props.disabled,
				"aria-labelledby": __props.labelledBy,
				class: "flex-col gap-0.5 text-sm/5",
				"onUpdate:modelValue": choose
			}, {
				default: withCtx(() => [(openBlock(true), createElementBlock(Fragment, null, renderList(__props.options, (option, index) => {
					return openBlock(), createElementBlock("div", {
						key: option.id,
						class: normalizeClass(unref(askUserOptionRowClass))
					}, [createVNode(RadioGroupItem_default, {
						id: unref(askUserOptionId)(__props.idPrefix, index),
						value: option.id,
						"aria-labelledby": `${unref(askUserOptionId)(__props.idPrefix, index)}-label`,
						"aria-describedby": unref(askUserOptionDescribedBy)(__props.idPrefix, option, index),
						class: "mt-0.5 p-0"
					}, null, 8, [
						"id",
						"value",
						"aria-labelledby",
						"aria-describedby"
					]), createVNode(AskUserOptionLabel_default, {
						"option-id": unref(askUserOptionId)(__props.idPrefix, index),
						option,
						disabled: __props.disabled
					}, null, 8, [
						"option-id",
						"option",
						"disabled"
					])], 2);
				}), 128))]),
				_: 1
			}, 8, [
				"model-value",
				"disabled",
				"aria-labelledby"
			]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/AskUserCard.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$23 = ["aria-label"];
var _hoisted_2$21 = { class: "flex min-w-0 flex-col gap-0.5 text-sm/5" };
var _hoisted_3$14 = {
	key: 2,
	class: "flex flex-col gap-1 px-2 text-sm/5"
};
var _hoisted_4$11 = { class: "flex h-6 w-full justify-end gap-2" };
var IME_PROCESS_KEY_CODE = 229;
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/AskUserCard.vue
var AskUserCard_default = /* @__PURE__ */ defineComponent({
	__name: "AskUserCard",
	props: {
		part: {},
		answering: {
			type: Boolean,
			default: false
		}
	},
	emits: ["answer"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const { t } = useI18n();
		const baseId = useId();
		const selected = ref([]);
		const otherText = ref("");
		const replacesSelection = computed(() => __props.part.maxSelections === 1);
		const requiredSingleChoice = computed(() => replacesSelection.value && __props.part.minSelections > 0);
		const trimmedOther = computed(() => __props.part.allowOther ? otherText.value.trim() : "");
		const count = computed(() => selected.value.length + (trimmedOther.value ? 1 : 0));
		const atMax = computed(() => count.value >= __props.part.maxSelections);
		const canSubmit = computed(() => !__props.answering && count.value >= __props.part.minSelections && count.value <= __props.part.maxSelections);
		function boundsHint(min, max, choosable) {
			if (min > 0) {
				if (min === max) return t("agent.askUser.chooseExactly", { min });
				return max >= choosable ? t("agent.askUser.chooseAtLeast", { min }) : t("agent.askUser.chooseBetween", {
					min,
					max
				});
			}
			if (choosable === 1) return void 0;
			if (max >= choosable) return t("agent.askUser.chooseAny");
			return max === 1 ? t("agent.askUser.chooseOneOrNone") : t("agent.askUser.chooseUpTo", { max });
		}
		const hint = computed(() => requiredSingleChoice.value || __props.part.resolution ? void 0 : boundsHint(__props.part.minSelections, __props.part.maxSelections, choosableCount(__props.part)));
		const promptId = `${baseId}-prompt`;
		const hintId = `${baseId}-hint`;
		const otherId = `${baseId}-other`;
		const otherDescribedBy = computed(() => hint.value ? `${promptId} ${hintId}` : promptId);
		const singleValue = computed(() => selected.value[0]);
		function chooseSingle(value) {
			if (value === void 0) return;
			selected.value = [value];
			otherText.value = "";
		}
		function chooseMany(next) {
			if (!replacesSelection.value) {
				selected.value = next;
				return;
			}
			const added = next.filter((id) => !selected.value.includes(id));
			selected.value = added;
			if (added.length > 0) otherText.value = "";
		}
		const otherModel = computed({
			get: () => otherText.value,
			set: (value) => {
				otherText.value = String(value ?? "");
				if (replacesSelection.value && otherText.value.trim()) selected.value = [];
			}
		});
		const otherDisabled = computed(() => __props.answering || !replacesSelection.value && atMax.value && !trimmedOther.value);
		const composing = ref(false);
		function onCompositionEnd() {
			setTimeout(() => {
				composing.value = false;
			});
		}
		function onOtherEnter(event) {
			if (event.isComposing || composing.value || event.keyCode === IME_PROCESS_KEY_CODE) return;
			event.preventDefault();
			submit();
		}
		function submit() {
			if (!canSubmit.value) return;
			const chosen = __props.part.options.map(({ id }) => id).filter((id) => selected.value.includes(id));
			emit("answer", __props.part.askId, trimmedOther.value ? {
				selected: chosen,
				other_text: trimmedOther.value
			} : { selected: chosen });
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				role: "group",
				"aria-label": unref(t)("agent.askUser.card"),
				class: "flex w-full flex-col gap-2 overflow-hidden rounded-lg border bg-secondary p-4 shadow-md"
			}, [createBaseVNode("div", _hoisted_2$21, [createBaseVNode("p", {
				id: promptId,
				class: "m-0 font-medium wrap-break-word whitespace-pre-line text-foreground"
			}, toDisplayString(__props.part.prompt), 1), hint.value ? (openBlock(), createElementBlock("p", {
				key: 0,
				id: hintId,
				class: "m-0 text-xs/5 text-muted-foreground"
			}, toDisplayString(hint.value), 1)) : createCommentVNode("", true)]), __props.part.resolution ? (openBlock(), createBlock(AskUserAnswer_default, {
				key: 0,
				resolution: __props.part.resolution,
				options: __props.part.options
			}, null, 8, ["resolution", "options"])) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
				requiredSingleChoice.value ? (openBlock(), createBlock(AskUserRadioOptions_default, {
					key: 0,
					"model-value": singleValue.value,
					options: __props.part.options,
					"id-prefix": unref(baseId),
					"labelled-by": promptId,
					disabled: __props.answering,
					"onUpdate:modelValue": chooseSingle
				}, null, 8, [
					"model-value",
					"options",
					"id-prefix",
					"disabled"
				])) : (openBlock(), createBlock(AskUserCheckboxOptions_default, {
					key: 1,
					"model-value": selected.value,
					options: __props.part.options,
					"id-prefix": unref(baseId),
					"labelled-by": promptId,
					"described-by": hint.value ? hintId : void 0,
					disabled: __props.answering,
					full: !replacesSelection.value && atMax.value,
					"onUpdate:modelValue": chooseMany
				}, null, 8, [
					"model-value",
					"options",
					"id-prefix",
					"described-by",
					"disabled",
					"full"
				])),
				__props.part.allowOther ? (openBlock(), createElementBlock("div", _hoisted_3$14, [createBaseVNode("label", {
					for: otherId,
					class: "text-foreground"
				}, toDisplayString(unref(t)("agent.askUser.other")), 1), createVNode(Input_default, {
					id: otherId,
					modelValue: otherModel.value,
					"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => otherModel.value = $event),
					type: "text",
					placeholder: unref(t)("agent.askUser.otherPlaceholder"),
					disabled: otherDisabled.value,
					"aria-describedby": otherDescribedBy.value,
					class: "h-8 bg-card px-3",
					onKeydown: withKeys(onOtherEnter, ["enter"]),
					onCompositionstart: _cache[1] || (_cache[1] = ($event) => composing.value = true),
					onCompositionend: onCompositionEnd
				}, null, 8, [
					"modelValue",
					"placeholder",
					"disabled",
					"aria-describedby"
				])])) : createCommentVNode("", true),
				createBaseVNode("div", _hoisted_4$11, [createVNode(Button_default, {
					variant: "primary",
					size: "sm",
					disabled: !canSubmit.value,
					"aria-busy": __props.answering || void 0,
					onClick: submit
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(unref(t)("g.submit")), 1)]),
					_: 1
				}, 8, ["disabled", "aria-busy"])])
			], 64))], 8, _hoisted_1$23);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/DeleteApprovalCard.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$22 = ["aria-label"];
var _hoisted_2$20 = { class: "m-0 text-sm/5 wrap-break-word whitespace-pre-line text-foreground" };
var _hoisted_3$13 = { class: "flex flex-col gap-1 rounded-md bg-background p-2 text-xs/5" };
var _hoisted_4$10 = ["aria-label"];
var _hoisted_5$9 = {
	key: 0,
	class: "truncate text-foreground"
};
var _hoisted_6$8 = { class: "max-w-1/2 shrink-0 truncate text-muted-foreground" };
var _hoisted_7$5 = {
	key: 0,
	class: "m-0 text-muted-foreground"
};
var _hoisted_8$3 = {
	key: 0,
	role: "status",
	class: "m-0 text-sm/5 text-muted-foreground"
};
var _hoisted_9$2 = {
	key: 1,
	class: "flex h-6 w-full justify-end gap-2"
};
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/DeleteApprovalCard.vue
var DeleteApprovalCard_default = /* @__PURE__ */ defineComponent({
	__name: "DeleteApprovalCard",
	props: {
		part: {},
		answering: {
			type: Boolean,
			default: false
		}
	},
	emits: ["answer"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const { t } = useI18n();
		const STATUS_TEXT = {
			answered: "agent.deleteApproval.answered",
			closed: "agent.deleteApproval.closed",
			retired: "agent.deleteApproval.retired",
			unconfirmed: "agent.deleteApproval.unconfirmed"
		};
		const decision = computed(() => {
			const resolution = __props.part.resolution;
			if (!resolution) return void 0;
			if (resolution.status === "answered") {
				const count = __props.part.nodes.length + __props.part.hiddenNodeCount;
				if (resolution.selected.includes("delete")) return t("agent.deleteApproval.deleted", count);
				if (resolution.selected.includes("keep")) return t("agent.deleteApproval.kept", count);
			}
			return t(STATUS_TEXT[resolution.status]);
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				role: "group",
				"aria-label": unref(t)("agent.deleteApproval.card"),
				class: "flex w-full flex-col gap-2 overflow-hidden rounded-lg border bg-secondary p-4 shadow-md"
			}, [
				createBaseVNode("p", _hoisted_2$20, toDisplayString(__props.part.prompt), 1),
				createBaseVNode("div", _hoisted_3$13, [createBaseVNode("ul", {
					"aria-label": unref(t)("agent.deleteApproval.nodes"),
					class: "m-0 flex max-h-40 list-none flex-col gap-0.5 overflow-y-auto p-0"
				}, [(openBlock(true), createElementBlock(Fragment, null, renderList(__props.part.nodes, (node) => {
					return openBlock(), createElementBlock("li", {
						key: node.id,
						class: "flex min-w-0 items-baseline gap-2"
					}, [node.name ? (openBlock(), createElementBlock("span", _hoisted_5$9, toDisplayString(node.name), 1)) : createCommentVNode("", true), createBaseVNode("span", _hoisted_6$8, " #" + toDisplayString(node.id), 1)]);
				}), 128))], 8, _hoisted_4$10), __props.part.hiddenNodeCount > 0 ? (openBlock(), createElementBlock("p", _hoisted_7$5, toDisplayString(unref(t)("agent.deleteApproval.moreNodes", __props.part.hiddenNodeCount)), 1)) : createCommentVNode("", true)]),
				decision.value ? (openBlock(), createElementBlock("p", _hoisted_8$3, toDisplayString(decision.value), 1)) : (openBlock(), createElementBlock("div", _hoisted_9$2, [createVNode(Button_default, {
					variant: "secondary",
					size: "sm",
					disabled: __props.answering,
					"aria-busy": __props.answering || void 0,
					onClick: _cache[0] || (_cache[0] = ($event) => emit("answer", __props.part.askId, "keep"))
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(unref(t)("agent.deleteApproval.keep")), 1)]),
					_: 1
				}, 8, ["disabled", "aria-busy"]), createVNode(Button_default, {
					variant: "destructive",
					size: "sm",
					disabled: __props.answering,
					"aria-busy": __props.answering || void 0,
					onClick: _cache[1] || (_cache[1] = ($event) => emit("answer", __props.part.askId, "delete"))
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(unref(t)("agent.deleteApproval.delete")), 1)]),
					_: 1
				}, 8, ["disabled", "aria-busy"])]))
			], 8, _hoisted_1$22);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/CodeBlock.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$21 = { class: "group relative my-2 overflow-hidden rounded-md border" };
var _hoisted_2$19 = { class: "flex items-center justify-between border-b bg-accent px-3 py-1.5" };
var _hoisted_3$12 = { class: "flex items-center gap-1.5 font-mono text-xs text-muted-foreground" };
var _hoisted_4$9 = { class: "text-foreground" };
var _hoisted_5$8 = {
	key: 1,
	class: "overflow-x-auto p-4 font-mono text-sm"
};
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/CodeBlock.vue
var CodeBlock_default = /* @__PURE__ */ defineComponent({
	__name: "CodeBlock",
	props: {
		code: {},
		lang: { default: "text" }
	},
	setup(__props) {
		const { t } = useI18n();
		const { copy, copied } = useClipboard({
			copiedDuring: 2e3,
			legacy: true
		});
		const highlighted = ref(null);
		watchDebounced(() => [__props.code, __props.lang], async ([currentCode, currentLang], _prev, onCleanup) => {
			let cancelled = false;
			onCleanup(() => {
				cancelled = true;
			});
			try {
				const { codeToHtml } = await __vitePreload(async () => {
					const { codeToHtml } = await import("./dist-BQrSDUjE.js");
					return { codeToHtml };
				}, __vite__mapDeps([0,1,2]), import.meta.url);
				const html = await codeToHtml(currentCode, {
					lang: currentLang,
					theme: "github-dark",
					colorReplacements: { "#24292e": "transparent" }
				});
				if (!cancelled) highlighted.value = html;
			} catch {
				if (!cancelled) highlighted.value = null;
			}
		}, {
			immediate: true,
			debounce: 100
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$21, [createBaseVNode("div", _hoisted_2$19, [createBaseVNode("span", _hoisted_3$12, [_cache[1] || (_cache[1] = createBaseVNode("span", { class: "icon-[lucide--file-code] size-3.5" }, null, -1)), createBaseVNode("span", _hoisted_4$9, toDisplayString(__props.lang), 1)]), createVNode(Button_default, {
				type: "button",
				variant: "outline",
				size: "sm",
				class: "gap-1 font-mono",
				onClick: _cache[0] || (_cache[0] = ($event) => unref(copy)(__props.code))
			}, {
				default: withCtx(() => [createBaseVNode("span", { class: normalizeClass(unref(cn)("size-3.5", unref(copied) ? "icon-[lucide--check]" : "icon-[lucide--copy]")) }, null, 2), createTextVNode(" " + toDisplayString(unref(copied) ? unref(t)("agent.copied") : unref(t)("agent.copy")), 1)]),
				_: 1
			})]), highlighted.value ? (openBlock(), createBlock(SanitizedHtml_default, {
				key: 0,
				profile: "highlighted-code",
				class: "overflow-x-auto p-4 font-mono text-sm [&_pre]:bg-transparent",
				html: highlighted.value
			}, null, 8, ["html"])) : (openBlock(), createElementBlock("pre", _hoisted_5$8, [createBaseVNode("code", null, toDisplayString(__props.code), 1)]))]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/utils/resolveReplyAssetDownload.ts
function preserveExtension(name, filename) {
	const { suffix } = getFilenameDetails(filename);
	return name.includes(".") || suffix === null ? name : `${name}.${suffix}`;
}
async function displayFilename(asset) {
	const fallback = preserveExtension(asset.label ?? asset.filename, asset.filename);
	if (!isAssetPreviewSupported()) return fallback;
	const record = await findOutputAsset(asset.filename).catch(() => void 0);
	const name = record && getPathDetails(record.name).fullFilename;
	return name ? preserveExtension(name, asset.filename) : fallback;
}
/** Authenticates only the exact same-origin API view route; every other URL is fetched without credentials. */
async function resolveReplyAssetDownload(asset) {
	const candidate = new URL(asset.url, window.location.origin);
	const apiBase = new URL(api.apiURL(""), window.location.origin);
	const viewPath = `${apiBase.pathname.replace(/\/$/, "")}/view`;
	const trusted = candidate.origin === apiBase.origin && candidate.pathname === viewPath;
	return {
		url: trusted ? `${candidate.pathname.slice(apiBase.pathname.length)}${candidate.search}` : asset.url,
		filename: await displayFilename(asset),
		fetch: trusted ? (url) => api.fetchApi(url) : (url) => fetch(url, { credentials: "omit" }),
		mode: "fetch",
		preferResponseFilename: false
	};
}
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/ReplyAudioCard.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$20 = { class: "group/audio flex w-full items-center gap-2.5 rounded-lg border px-3 py-2.5" };
var _hoisted_2$18 = ["src"];
var _hoisted_3$11 = { class: "flex min-w-0 flex-1 flex-col" };
var _hoisted_4$8 = { class: "truncate text-sm/4" };
var _hoisted_5$7 = { class: "flex h-6 items-center gap-4" };
var _hoisted_6$7 = { class: "text-xs whitespace-nowrap text-muted-foreground tabular-nums" };
var _hoisted_7$4 = { class: "flex shrink-0 items-center gap-2" };
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/ReplyAudioCard.vue
var ReplyAudioCard_default = /* @__PURE__ */ defineComponent({
	__name: "ReplyAudioCard",
	props: {
		asset: {},
		title: {}
	},
	setup(__props) {
		const { t } = useI18n();
		const { downloadFiles } = useAssetDownload();
		const { audioRef, isPlaying, progressRatio, formattedCurrentTime, formattedDuration, togglePlayPause, muted, volumeIcon, toggleMute, seekToRatio } = useWaveAudioPlayer({
			src: toRef(() => __props.asset.url),
			waveform: false
		});
		function onScrub(value) {
			if (value?.length) seekToRatio(value[0] / 100);
		}
		async function download() {
			await downloadFiles([await resolveReplyAssetDownload(__props.asset)]);
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$20, [
				createBaseVNode("audio", {
					ref: (el) => audioRef.value = el,
					"data-testid": "reply-audio-element",
					class: "hidden",
					src: __props.asset.url,
					preload: "metadata"
				}, null, 8, _hoisted_2$18),
				createVNode(Button_default, {
					type: "button",
					variant: "secondary",
					size: "icon-lg",
					"aria-label": unref(isPlaying) ? unref(t)("g.pause") : unref(t)("g.play"),
					class: "shrink-0",
					onClick: unref(togglePlayPause)
				}, {
					default: withCtx(() => [createBaseVNode("span", { class: normalizeClass(unref(cn)("size-4", unref(isPlaying) ? "icon-[lucide--pause]" : "icon-[lucide--play]")) }, null, 2)]),
					_: 1
				}, 8, ["aria-label", "onClick"]),
				createBaseVNode("div", _hoisted_3$11, [createBaseVNode("span", _hoisted_4$8, toDisplayString(__props.title), 1), createBaseVNode("div", _hoisted_5$7, [
					createBaseVNode("span", _hoisted_6$7, toDisplayString(unref(formattedCurrentTime)) + " / " + toDisplayString(unref(formattedDuration)), 1),
					createVNode(Slider_default, {
						class: "min-w-0 flex-1",
						"thumb-class": "opacity-0 transition-opacity group-hover/audio:opacity-100 focus-visible:opacity-100",
						"model-value": [unref(progressRatio)],
						max: 100,
						step: .1,
						"onUpdate:modelValue": onScrub
					}, null, 8, ["model-value"]),
					createBaseVNode("div", _hoisted_7$4, [createVNode(Button_default, {
						type: "button",
						variant: "muted-textonly",
						size: "icon-sm",
						"aria-label": unref(muted) ? unref(t)("g.unmute") : unref(t)("g.mute"),
						class: "size-6 rounded-lg",
						onClick: unref(toggleMute)
					}, {
						default: withCtx(() => [createBaseVNode("span", { class: normalizeClass(unref(cn)("size-4", unref(volumeIcon))) }, null, 2)]),
						_: 1
					}, 8, ["aria-label", "onClick"]), createVNode(Button_default, {
						type: "button",
						variant: "muted-textonly",
						size: "icon-sm",
						"aria-label": unref(t)("g.download"),
						class: "size-6 rounded-lg",
						onClick: download
					}, {
						default: withCtx(() => [..._cache[0] || (_cache[0] = [createBaseVNode("span", { class: "icon-[lucide--download] size-4" }, null, -1)])]),
						_: 1
					}, 8, ["aria-label"])])
				])])
			]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/ReplyAssetGroup.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$19 = {
	"data-testid": "reply-asset-group",
	class: "my-4 flex flex-col gap-2"
};
var _hoisted_2$17 = ["aria-label", "onClick"];
var _hoisted_3$10 = ["src", "alt"];
var _hoisted_4$7 = ["src"];
var _hoisted_5$6 = ["src", "alt"];
var _hoisted_6$6 = {
	key: 4,
	"data-testid": "reply-video-affordance",
	"aria-hidden": "true",
	class: "pointer-events-none absolute inset-0 flex items-center justify-center"
};
var _hoisted_7$3 = {
	key: 2,
	class: "flex flex-col gap-1"
};
var COLLAPSED_COUNT = 12;
var AUDIO_COLLAPSED_COUNT = 5;
var THUMBNAIL_RETRY_DELAY_MS = 2e3;
var THUMBNAIL_MAX_ATTEMPTS = 30;
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/ReplyAssetGroup.vue
var ReplyAssetGroup_default = /* @__PURE__ */ defineComponent({
	__name: "ReplyAssetGroup",
	props: { assets: {} },
	setup(__props) {
		const { t } = useI18n();
		const visual = computed(() => __props.assets.filter((asset) => asset.kind !== "audio"));
		const audio = computed(() => __props.assets.filter((asset) => asset.kind === "audio"));
		const expanded = ref(false);
		const collapsible = computed(() => visual.value.length > COLLAPSED_COUNT);
		const visibleVisual = computed(() => expanded.value || !collapsible.value ? visual.value : visual.value.slice(0, COLLAPSED_COUNT));
		const multi = computed(() => visual.value.length > 1);
		const audioExpanded = ref(false);
		const audioCollapsible = computed(() => audio.value.length > AUDIO_COLLAPSED_COUNT);
		const visibleAudio = computed(() => audioExpanded.value || !audioCollapsible.value ? audio.value : audio.value.slice(0, AUDIO_COLLAPSED_COUNT));
		const gridColsClass = computed(() => {
			const count = visual.value.length;
			if (count <= 1) return "grid-cols-1";
			if (count === 2) return "grid-cols-2";
			if (count === 3) return "grid-cols-3";
			return "grid-cols-4";
		});
		const galleryAssets = computed(() => visual.value.filter((asset) => asset.kind !== "3D"));
		const galleryItems = computed(() => galleryAssets.value.map(replyAssetResultItem));
		const galleryIndex = ref(-1);
		const modelThumbnails = ref({});
		const assetNames = ref({});
		const thumbnailAbortController = new AbortController();
		const thumbnailRetryTimers = /* @__PURE__ */ new Set();
		onBeforeUnmount(() => {
			thumbnailAbortController.abort();
			for (const timer of thumbnailRetryTimers) clearTimeout(timer);
			thumbnailRetryTimers.clear();
		});
		async function generateOffscreenModelThumbnail(url, filename, attempt = 1) {
			const { generateModelThumbnail } = await __vitePreload(async () => {
				const { generateModelThumbnail } = await import("./modelThumbnail-DAA4IgcR.js");
				return { generateModelThumbnail };
			}, __vite__mapDeps([3,1,2,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91]), import.meta.url);
			const generated = await generateModelThumbnail(url, filename, thumbnailAbortController.signal);
			if (generated.status === "rendered") {
				modelThumbnails.value[url] = generated.dataUrl;
				return;
			}
			if (generated.status !== "busy" || thumbnailAbortController.signal.aborted || attempt >= THUMBNAIL_MAX_ATTEMPTS) return;
			const timer = setTimeout(() => {
				thumbnailRetryTimers.delete(timer);
				generateOffscreenModelThumbnail(url, filename, attempt + 1).catch(() => {});
			}, THUMBNAIL_RETRY_DELAY_MS);
			thumbnailRetryTimers.add(timer);
		}
		watch(() => __props.assets.filter((asset) => asset.kind === "3D" || asset.kind === "audio"), (lookups) => {
			if (!isAssetPreviewSupported()) return;
			for (const { url, filename, kind } of lookups) {
				if (kind === "3D" && !(url in modelThumbnails.value)) {
					modelThumbnails.value[url] = "";
					findServerPreviewUrl(filename).then(async (preview) => {
						if (preview) {
							modelThumbnails.value[url] = preview;
							return;
						}
						if (!new URL(url, window.location.origin).searchParams.has("filename")) return;
						await generateOffscreenModelThumbnail(url, filename);
					}).catch(() => {});
				}
				if (!(url in assetNames.value)) {
					assetNames.value[url] = "";
					findOutputAsset(filename).then((record) => {
						if (record?.name) assetNames.value[url] = record.name;
					}).catch(() => {});
				}
			}
		}, { immediate: true });
		const Load3dViewerContent = defineAsyncComponent(() => __vitePreload(() => import("./Load3dViewerContent-DuG77Xh8.js"), __vite__mapDeps([92,93,1,94,15,5,6,16,17,18,19,10,20,21,22,23,24,8,9,11,25,26,27,2,28,29,30,31,32,33,12,7,13,34,61,62,63,95,96,97,98,99,100,101,102,103,104,87,35,36,37,105,14,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,88,89,90,91,106,107]), import.meta.url));
		const MediaLightbox = defineAsyncComponent(() => __vitePreload(() => import("./MediaLightbox-BxVt-Aqb.js"), __vite__mapDeps([108,109,1,15,5,6,16,17,18,19,10,20,21,22,23,24,8,9,11,25,26,27,2,28,29,30,31,32,33,12,7,13,34,61,62,110,90,89,91,111,112,96,113,114,115]), import.meta.url));
		function refreshModelThumbnail(asset, retry = true) {
			if (!isAssetPreviewSupported() || modelThumbnails.value[asset.url]) return;
			findServerPreviewUrl(asset.filename).then((preview) => {
				if (preview) modelThumbnails.value[asset.url] = preview;
				else if (retry) setTimeout(() => refreshModelThumbnail(asset, false), 2e3);
			});
		}
		function inspect(asset) {
			if (asset.kind === "3D") {
				useDialogStore().showDialog({
					key: "asset-3d-viewer",
					title: assetNames.value[asset.url] || asset.label || asset.filename,
					component: Load3dViewerContent,
					props: { modelUrl: asset.url },
					dialogComponentProps: {
						...LOAD3D_VIEWER_DIALOG_PROPS,
						onClose: () => refreshModelThumbnail(asset)
					}
				});
				return;
			}
			galleryIndex.value = galleryAssets.value.indexOf(asset);
		}
		function playPreview(event) {
			const video = event.target;
			if (video instanceof HTMLVideoElement) video.play().catch(() => {});
		}
		function stopPreview(event) {
			const video = event.target;
			if (video instanceof HTMLVideoElement) video.pause();
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$19, [
				visibleVisual.value.length ? (openBlock(), createElementBlock("div", {
					key: 0,
					class: normalizeClass(unref(cn)("grid gap-1", gridColsClass.value))
				}, [(openBlock(true), createElementBlock(Fragment, null, renderList(visibleVisual.value, (asset) => {
					return openBlock(), createElementBlock("button", {
						key: asset.url,
						type: "button",
						"aria-label": asset.label ?? asset.filename,
						class: normalizeClass(unref(cn)("relative cursor-pointer overflow-hidden rounded-lg border-none p-0", multi.value && "aspect-square bg-accent", !multi.value && asset.kind === "3D" && "justify-self-end")),
						onClick: ($event) => inspect(asset)
					}, [asset.kind === "image" ? (openBlock(), createElementBlock("img", {
						key: 0,
						src: asset.url,
						alt: asset.label ?? asset.filename,
						"data-testid": "reply-image-preview",
						loading: "lazy",
						class: normalizeClass(multi.value ? "size-full object-cover" : "block h-auto max-w-full")
					}, null, 10, _hoisted_3$10)) : asset.kind === "video" ? (openBlock(), createElementBlock("video", {
						key: 1,
						src: asset.url,
						"data-testid": "reply-video-preview",
						muted: "",
						loop: "",
						playsinline: "",
						preload: "metadata",
						class: normalizeClass(multi.value ? "size-full object-cover" : "block h-auto max-w-full"),
						onMouseenter: playPreview,
						onMouseleave: stopPreview
					}, null, 42, _hoisted_4$7)) : modelThumbnails.value[asset.url] ? (openBlock(), createElementBlock("img", {
						key: 2,
						src: modelThumbnails.value[asset.url],
						alt: asset.label ?? asset.filename,
						loading: "lazy",
						class: normalizeClass(multi.value ? "size-full object-cover" : "block h-auto max-w-full")
					}, null, 10, _hoisted_5$6)) : (openBlock(), createElementBlock("span", {
						key: 3,
						class: normalizeClass(unref(cn)("flex items-center justify-center", multi.value ? "size-full" : "aspect-square w-40 bg-accent"))
					}, [..._cache[3] || (_cache[3] = [createBaseVNode("span", { class: "icon-[lucide--box] size-6 text-muted-foreground" }, null, -1)])], 2)), asset.kind === "video" ? (openBlock(), createElementBlock("span", _hoisted_6$6, [..._cache[4] || (_cache[4] = [createBaseVNode("span", { class: "flex size-9 items-center justify-center rounded-full bg-black/60 text-white shadow-sm backdrop-blur-sm" }, [createBaseVNode("span", { class: "icon-[lucide--play] size-4 fill-current" })], -1)])])) : createCommentVNode("", true)], 10, _hoisted_2$17);
				}), 128))], 2)) : createCommentVNode("", true),
				collapsible.value ? (openBlock(), createBlock(Button_default, {
					key: 1,
					type: "button",
					variant: "outline",
					size: "sm",
					class: "self-center rounded-full",
					onClick: _cache[0] || (_cache[0] = ($event) => expanded.value = !expanded.value)
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(expanded.value ? unref(t)("agent.showLess") : unref(t)("agent.showMore")) + " ", 1), createBaseVNode("span", { class: normalizeClass(unref(cn)("icon-[lucide--chevron-down] size-3", expanded.value && "rotate-180")) }, null, 2)]),
					_: 1
				})) : createCommentVNode("", true),
				audio.value.length ? (openBlock(), createElementBlock("div", _hoisted_7$3, [(openBlock(true), createElementBlock(Fragment, null, renderList(visibleAudio.value, (asset) => {
					return openBlock(), createBlock(ReplyAudioCard_default, {
						key: asset.url,
						asset,
						title: assetNames.value[asset.url] || asset.label || asset.filename
					}, null, 8, ["asset", "title"]);
				}), 128)), audioCollapsible.value ? (openBlock(), createBlock(Button_default, {
					key: 0,
					type: "button",
					variant: "outline",
					size: "sm",
					class: "self-center rounded-full",
					onClick: _cache[1] || (_cache[1] = ($event) => audioExpanded.value = !audioExpanded.value)
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(audioExpanded.value ? unref(t)("agent.showLess") : unref(t)("agent.showMore")) + " ", 1), createBaseVNode("span", { class: normalizeClass(unref(cn)("icon-[lucide--chevron-down] size-3", audioExpanded.value && "rotate-180")) }, null, 2)]),
					_: 1
				})) : createCommentVNode("", true)])) : createCommentVNode("", true),
				galleryIndex.value !== -1 ? (openBlock(), createBlock(unref(MediaLightbox), {
					key: 3,
					"all-gallery-items": galleryItems.value,
					"active-index": galleryIndex.value,
					"onUpdate:activeIndex": _cache[2] || (_cache[2] = ($event) => galleryIndex.value = $event)
				}, null, 8, ["all-gallery-items", "active-index"])) : createCommentVNode("", true)
			]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/MarkdownStream.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$18 = {
	"data-testid": "markdown-stream",
	class: "max-w-full min-w-0"
};
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/MarkdownStream.vue
var MarkdownStream_default = /* @__PURE__ */ defineComponent({
	__name: "MarkdownStream",
	props: { text: {} },
	setup(__props) {
		const apiBaseUrl = new URL(api.apiURL(""), window.location.origin).href;
		const normalizedBase = apiBaseUrl.replace(/\/+$/, "");
		function isFencedCode(token) {
			return token.type === "code" && token.codeBlockStyle !== "indented";
		}
		function pushAssets(out, assets) {
			const prev = out.at(-1);
			if (prev?.type === "assets") prev.assets.push(...assets);
			else out.push({
				type: "assets",
				assets
			});
		}
		const segments = computed(() => {
			const out = [];
			let prose = "";
			const flushProse = () => {
				if (!prose.trim()) {
					prose = "";
					return;
				}
				out.push({
					type: "prose",
					html: rewriteAgentAssetHtml(renderMarkdownToHtml(prose, apiBaseUrl))
				});
				prose = "";
			};
			for (const token of marked.lexer(__props.text)) {
				if (isFencedCode(token)) {
					flushProse();
					out.push({
						type: "code",
						code: token.text,
						lang: token.lang?.split(/\s+/)[0] || "text"
					});
					continue;
				}
				const assets = tokenReplyAssets(token);
				if (!assets) {
					prose += token.raw;
					continue;
				}
				const resolved = assets.map((asset) => ({
					...asset,
					url: resolveMarkdownUrl(asset.url, normalizedBase)
				}));
				flushProse();
				pushAssets(out, resolved);
			}
			flushProse();
			return out;
		});
		const MediaLightbox = defineAsyncComponent(() => __vitePreload(() => import("./MediaLightbox-BxVt-Aqb.js"), __vite__mapDeps([108,109,1,15,5,6,16,17,18,19,10,20,21,22,23,24,8,9,11,25,26,27,2,28,29,30,31,32,33,12,7,13,34,61,62,110,90,89,91,111,112,96,113,114,115]), import.meta.url));
		const proseItems = ref([]);
		const proseIndex = ref(-1);
		function onProseClick(event) {
			const image = event.target;
			if (!(image instanceof HTMLImageElement)) return;
			const asset = classifyAssetUrl(image.src) ?? {
				url: image.src,
				filename: image.alt || "image",
				kind: "image"
			};
			proseItems.value = [replyAssetResultItem({
				...asset,
				kind: "image"
			})];
			proseIndex.value = 0;
		}
		const proseClass = cn("text-sm wrap-break-word text-foreground", "[&_img]:mt-2 [&_img]:block [&_img]:h-auto [&_img]:max-w-full [&_img]:cursor-pointer [&_img]:object-contain", "[&_a]:cursor-pointer [&_a]:text-primary [&_a]:underline", "[&_p]:my-0 [&_p]:pt-4 [&_p:first-child]:pt-0 [&_strong]:font-semibold", "[&_h1]:mt-0 [&_h1]:pt-4 [&_h1]:pb-2 [&_h1]:text-2xl [&_h1]:font-semibold", "[&_h2]:pt-3.5 [&_h2]:pb-1.5 [&_h2]:text-base [&_h2]:font-semibold [&_h3]:pt-2 [&_h3]:font-semibold", "[&_ol]:my-0 [&_ol]:list-decimal [&_ol]:pt-1 [&_ol]:pb-2 [&_ol]:pl-5", "[&_ul]:my-0 [&_ul]:list-disc [&_ul]:pt-1 [&_ul]:pb-2 [&_ul]:pl-5", "[&_:not(pre)>code]:rounded-sm [&_:not(pre)>code]:border [&_:not(pre)>code]:border-border [&_:not(pre)>code]:bg-accent [&_:not(pre)>code]:px-1.5 [&_:not(pre)>code]:py-0.5 [&_:not(pre)>code]:text-[0.875em]", "[&_blockquote]:my-2 [&_blockquote]:border-l-[3px] [&_blockquote]:border-border [&_blockquote]:py-1.5 [&_blockquote]:pl-3.5 [&_blockquote]:text-muted-foreground", "[&_table]:my-2 [&_table]:w-full [&_table]:border-collapse [&_table]:overflow-hidden [&_table]:rounded-lg [&_table]:bg-secondary", "[&_th]:border-b [&_th]:border-border [&_th]:bg-accent [&_th]:px-4 [&_th]:py-2.5 [&_th]:text-left [&_th]:font-semibold", "[&_td]:border-b [&_td]:border-border [&_td]:px-4 [&_td]:py-2.5");
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$18, [(openBlock(true), createElementBlock(Fragment, null, renderList(segments.value, (segment, index) => {
				return openBlock(), createElementBlock(Fragment, { key: index }, [segment.type === "code" ? (openBlock(), createBlock(CodeBlock_default, {
					key: 0,
					code: segment.code,
					lang: segment.lang
				}, null, 8, ["code", "lang"])) : segment.type === "assets" ? (openBlock(), createBlock(ReplyAssetGroup_default, {
					key: 1,
					assets: segment.assets
				}, null, 8, ["assets"])) : (openBlock(), createBlock(SanitizedHtml_default, {
					key: 2,
					class: normalizeClass(unref(proseClass)),
					html: segment.html,
					onClick: onProseClick
				}, null, 8, ["class", "html"]))], 64);
			}), 128)), proseIndex.value !== -1 ? (openBlock(), createBlock(unref(MediaLightbox), {
				key: 0,
				"all-gallery-items": proseItems.value,
				"active-index": proseIndex.value,
				"onUpdate:activeIndex": _cache[0] || (_cache[0] = ($event) => proseIndex.value = $event)
			}, null, 8, ["all-gallery-items", "active-index"])) : createCommentVNode("", true)]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/agentBoundWorkflowId.ts
var agentBoundWorkflowIdKey = Symbol("agentBoundWorkflowId");
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/RunApprovalCard.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$17 = { class: "flex min-w-0 flex-col gap-0.5 text-sm/5" };
var _hoisted_2$16 = { class: "m-0" };
var _hoisted_3$9 = {
	key: 0,
	class: "m-0 min-w-0 list-disc pl-5 text-muted-foreground"
};
var _hoisted_4$6 = {
	key: 1,
	class: "wrap-break-word underline underline-offset-2"
};
var _hoisted_5$5 = { class: "m-0 text-muted-foreground" };
var _hoisted_6$5 = { class: "flex h-6 w-full justify-end gap-2" };
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/RunApprovalCard.vue
var RunApprovalCard_default = /* @__PURE__ */ defineComponent({
	__name: "RunApprovalCard",
	props: {
		part: {},
		answering: {
			type: Boolean,
			default: false
		}
	},
	emits: [
		"answer",
		"openWorkflow",
		"shown"
	],
	setup(__props, { emit: __emit }) {
		const boundWorkflowId = inject(agentBoundWorkflowIdKey, ref(void 0));
		const hideWorkflowName = computed(() => !!boundWorkflowId.value && __props.part.workflowId === boundWorkflowId.value);
		const emit = __emit;
		onMounted(() => emit("shown", __props.part.askId, __props.part.workflowId ?? null));
		const { t } = useI18n();
		const workflowLabel = computed(() => __props.part.workflowName?.trim() || __props.part.workflowId?.trim() || t("agent.runApproval.thisWorkflow"));
		return (_ctx, _cache) => {
			return openBlock(), createBlock(Card_default, {
				surface: "secondary",
				class: "flex w-full flex-col gap-2 overflow-hidden p-4 shadow-md"
			}, {
				default: withCtx(() => [createBaseVNode("div", _hoisted_1$17, [
					createBaseVNode("p", _hoisted_2$16, toDisplayString(unref(t)(hideWorkflowName.value ? "agent.runApproval.leadBound" : "agent.runApproval.lead")), 1),
					!hideWorkflowName.value ? (openBlock(), createElementBlock("ul", _hoisted_3$9, [createBaseVNode("li", null, [__props.part.workflowId ? (openBlock(), createBlock(Button_default, {
						key: 0,
						type: "button",
						variant: "link",
						size: "unset",
						class: "max-w-full justify-start text-left font-normal wrap-break-word whitespace-normal text-inherit underline underline-offset-2",
						onClick: _cache[0] || (_cache[0] = ($event) => emit("openWorkflow", __props.part.askId, __props.part.workflowId, __props.part.workflowName))
					}, {
						default: withCtx(() => [createTextVNode(toDisplayString(workflowLabel.value), 1)]),
						_: 1
					})) : (openBlock(), createElementBlock("span", _hoisted_4$6, toDisplayString(workflowLabel.value), 1))])])) : createCommentVNode("", true),
					createBaseVNode("p", _hoisted_5$5, toDisplayString(unref(t)("agent.runApproval.question")), 1)
				]), createBaseVNode("div", _hoisted_6$5, [createVNode(Button_default, {
					variant: "secondary",
					size: "sm",
					disabled: __props.answering,
					"aria-busy": __props.answering || void 0,
					onClick: _cache[1] || (_cache[1] = ($event) => emit("answer", __props.part.askId, "cancel"))
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(unref(t)("agent.runApproval.cancel")), 1)]),
					_: 1
				}, 8, ["disabled", "aria-busy"]), createVNode(Button_default, {
					variant: "primary",
					size: "sm",
					disabled: __props.answering,
					"aria-busy": __props.answering || void 0,
					onClick: _cache[2] || (_cache[2] = ($event) => emit("answer", __props.part.askId, "run"))
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(unref(t)("agent.runApproval.run")), 1)]),
					_: 1
				}, 8, ["disabled", "aria-busy"])])]),
				_: 1
			});
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/stores/agent/agentWorkflowTabBindingStore.ts
var BINDING_TTL_MS = 2592e6;
function isNonEmptyString(value) {
	return typeof value === "string" && value.length > 0;
}
function isPersistedBinding(value) {
	if (typeof value !== "object" || value === null) return false;
	const { tabPath, graphId, confirmedAt } = value;
	return typeof tabPath === "string" && (graphId === null || isNonEmptyString(graphId)) && typeof confirmedAt === "number";
}
function liveBindings(bindings, now) {
	return Object.fromEntries(Object.entries(bindings).filter((entry) => isPersistedBinding(entry[1]) && entry[1].confirmedAt + BINDING_TTL_MS >= now));
}
function graphIdOf(tab) {
	const activeId = tab.activeState?.id;
	if (activeId !== void 0) return activeId;
	if (typeof tab.originalContent !== "string") return void 0;
	try {
		const parsed = JSON.parse(tab.originalContent);
		return typeof parsed === "object" && parsed !== null && "id" in parsed && isNonEmptyString(parsed.id) ? parsed.id : void 0;
	} catch {
		return;
	}
}
var useAgentWorkflowTabBindingStore = defineStore("agentWorkflowTabBinding", () => {
	clearLegacyAgentStorage();
	const tabByWorkflow = useLocalStorage(StorageKeys.agentWorkflowTabBindings(getWorkspaceId()), {});
	tabByWorkflow.value = liveBindings(tabByWorkflow.value, Date.now());
	const workflows = useWorkflowStore();
	const boundInstances = /* @__PURE__ */ new Map();
	const refusedInstances = /* @__PURE__ */ new Map();
	function recordFor(workflowId) {
		return Object.hasOwn(tabByWorkflow.value, workflowId) ? tabByWorkflow.value[workflowId] : void 0;
	}
	function recordIdFor(tabPath) {
		for (const [workflowId, record] of Object.entries(tabByWorkflow.value)) if (record.tabPath === tabPath) return workflowId;
	}
	function isVerifiedOwner(workflowId, tab) {
		return boundInstances.get(workflowId) === toRaw(tab);
	}
	function claimable(workflowId, record, tab) {
		if (refusedInstances.get(workflowId) === toRaw(tab)) return false;
		const graphId = graphIdOf(tab);
		if (record.graphId === null || graphId === void 0) return !tab.isTemporary;
		return areWorkflowIdsEquivalent(graphId, record.graphId, tab.legacyId);
	}
	function blockedByOccupant(workflowId, record) {
		const occupant = workflows.openWorkflows.find((tab) => tab.path === record.tabPath);
		return occupant !== void 0 && !isVerifiedOwner(workflowId, occupant) && !claimable(workflowId, record, occupant);
	}
	function unbind(tabPath) {
		for (const [workflowId, record] of Object.entries(tabByWorkflow.value)) if (record.tabPath === tabPath) {
			delete tabByWorkflow.value[workflowId];
			boundInstances.delete(workflowId);
			refusedInstances.delete(workflowId);
		}
	}
	/**
	* Drops one workflow's record wherever it sits. Path-keyed `unbind` would
	* take whichever workflow occupies the path now, which is the wrong one
	* once the tab has been rebound.
	*/
	function unbindWorkflow(workflowId) {
		if (!Object.hasOwn(tabByWorkflow.value, workflowId)) return;
		delete tabByWorkflow.value[workflowId];
		boundInstances.delete(workflowId);
		refusedInstances.delete(workflowId);
	}
	function releaseClosedTab({ tab, path }) {
		const workflowId = recordIdFor(path);
		if (workflowId === void 0) return;
		if (refusedInstances.get(workflowId) === toRaw(tab)) refusedInstances.delete(workflowId);
		if (isVerifiedOwner(workflowId, tab)) unbind(path);
	}
	function adoptOpenTab({ tab, path }) {
		const workflowId = recordIdFor(path);
		if (workflowId === void 0 || boundInstances.has(workflowId)) return;
		const record = tabByWorkflow.value[workflowId];
		if (!claimable(workflowId, record, tab)) {
			refusedInstances.set(workflowId, toRaw(tab));
			return;
		}
		boundInstances.set(workflowId, toRaw(tab));
		tabByWorkflow.value[workflowId] = {
			...record,
			confirmedAt: Date.now()
		};
	}
	watch(() => workflows.openWorkflows.map((tab) => ({
		tab,
		path: tab.path
	})), (open, previous = []) => {
		previous.filter(({ tab }) => !open.some((entry) => entry.tab === tab)).forEach(releaseClosedTab);
		open.forEach(adoptOpenTab);
	}, { immediate: true });
	function matchesWorkflow(workflowId, workflow) {
		return !workflow.isTemporary || isVerifiedOwner(workflowId, workflow);
	}
	function bind(workflowId, tabPath) {
		unbind(tabPath);
		refusedInstances.delete(workflowId);
		const workflow = workflows.getWorkflowByPath(tabPath);
		if (workflow) boundInstances.set(workflowId, toRaw(workflow));
		else boundInstances.delete(workflowId);
		tabByWorkflow.value = {
			...tabByWorkflow.value,
			[workflowId]: {
				tabPath,
				graphId: workflow ? graphIdOf(workflow) ?? null : null,
				confirmedAt: Date.now()
			}
		};
	}
	function tabPathFor(workflowId) {
		const record = recordFor(workflowId);
		return record !== void 0 && !blockedByOccupant(workflowId, record) ? record.tabPath : void 0;
	}
	function workflowIdFor(tabPath) {
		const workflowId = recordIdFor(tabPath);
		return workflowId !== void 0 && !blockedByOccupant(workflowId, tabByWorkflow.value[workflowId]) ? workflowId : void 0;
	}
	return {
		bind,
		unbind,
		unbindWorkflow,
		matchesWorkflow,
		tabPathFor,
		workflowIdFor
	};
});
//#endregion
//#region src/workbench/extensions/agent/services/agent/targetAwareAgentNavigation.ts
var AgentTargetNavigationError = class extends Error {
	code;
	workflowId;
	locatorId;
	recoverable = true;
	constructor(code, workflowId, locatorId) {
		super(`Agent navigation failed: ${code}`);
		this.code = code;
		this.workflowId = workflowId;
		this.locatorId = locatorId;
		this.name = "AgentTargetNavigationError";
	}
};
function createTargetAwareAgentNavigation(dependencies) {
	function target(reference) {
		const tab = dependencies.tabForWorkflow(reference.workflowId);
		if (tab === void 0) throw new AgentTargetNavigationError("missing_target", reference.workflowId, reference.locatorId);
		if (!dependencies.isOpen(tab)) throw new AgentTargetNavigationError("closed_target", reference.workflowId, reference.locatorId);
		return tab;
	}
	async function navigate(reference) {
		const tab = target(reference);
		if (!await dependencies.activate(tab)) throw new AgentTargetNavigationError("activation_failed", reference.workflowId, reference.locatorId);
		if (dependencies.activeTab() !== tab) throw new AgentTargetNavigationError("activation_failed", reference.workflowId, reference.locatorId);
		const node = dependencies.resolveIn(tab, reference.locatorId);
		if (node === void 0) throw new AgentTargetNavigationError("missing_node", reference.workflowId, reference.locatorId);
		await dependencies.focus(node);
		if (dependencies.activeTab() !== tab) throw new AgentTargetNavigationError("activation_failed", reference.workflowId, reference.locatorId);
		return node;
	}
	return { navigate };
}
//#endregion
//#region src/workbench/extensions/agent/composables/agent/useAgentTargetNavigation.ts
function useAgentTargetNavigation() {
	const bindingStore = useAgentWorkflowTabBindingStore();
	const workflowStore = useWorkflowStore();
	const workflowService = useWorkflowService();
	const { focusNodeInstance } = useFocusNode();
	return createTargetAwareAgentNavigation({
		tabForWorkflow: (workflowId) => {
			const path = bindingStore.tabPathFor(workflowId);
			return path === void 0 ? void 0 : workflowStore.getWorkflowByPath(path) ?? void 0;
		},
		isOpen: (tab) => workflowStore.openWorkflows.includes(tab),
		activate: (tab) => workflowService.openWorkflow(tab),
		activeTab: () => workflowStore.activeWorkflow ?? void 0,
		resolveIn: (tab, locatorId) => workflowStore.activeWorkflow === tab ? getNodeByLocatorId(app.rootGraph, locatorId) ?? void 0 : void 0,
		focus: focusNodeInstance
	});
}
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/TabLinkCard.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$16 = {
	"data-testid": "workflow-link-content",
	class: "flex min-w-0 flex-1 flex-col gap-0.5"
};
var _hoisted_2$15 = { class: "truncate text-sm/4 text-foreground" };
var _hoisted_3$8 = ["id"];
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/TabLinkCard.vue
var TabLinkCard_default = /* @__PURE__ */ defineComponent({
	__name: "TabLinkCard",
	props: {
		workflowId: {},
		locatorId: {},
		name: {}
	},
	setup(__props) {
		const { t } = useI18n();
		const workflowStore = useWorkflowStore();
		const workflowService = useWorkflowService();
		const bindingStore = useAgentWorkflowTabBindingStore();
		const toast = useToast();
		const { enabled: agentEnabled } = storeToRefs(useAgentPanelStore());
		const targetNavigation = useAgentTargetNavigation();
		const tab = computed(() => {
			const path = bindingStore.tabPathFor(__props.workflowId);
			return path === void 0 ? void 0 : workflowStore.openWorkflows.find((open) => open.path === path);
		});
		const label = computed(() => __props.name || tab.value?.filename);
		const nodeCountId = useId();
		const nodeCount = ref();
		watch(tab, (activeTab) => {
			nodeCount.value = activeTab?.activeState?.nodes?.length;
		}, { immediate: true });
		useEventListener(api, "graphChanged", (event) => {
			if (tab.value === workflowStore.activeWorkflow) nodeCount.value = event.detail.nodes?.length;
		});
		async function open() {
			const target = tab.value;
			if (!target) return;
			if (__props.locatorId === void 0) await workflowService.openWorkflow(target);
			else try {
				await targetNavigation.navigate({
					workflowId: __props.workflowId,
					locatorId: __props.locatorId
				});
			} catch (error) {
				if (!(error instanceof AgentTargetNavigationError)) reportError(error, {
					surface: "agent",
					errorType: "agent_target_navigation_failure"
				});
				toast.warning(t("agent.targetNavigationUnavailable"), { duration: 5e3 });
			}
		}
		return (_ctx, _cache) => {
			return unref(agentEnabled) && tab.value ? (openBlock(), createBlock(Button_default, {
				key: 0,
				type: "button",
				variant: "outline",
				size: "unset",
				"aria-label": unref(t)("agent.openWorkflowTab", { name: label.value }),
				"aria-describedby": nodeCount.value === void 0 ? void 0 : unref(nodeCountId),
				class: "h-[53px] w-full justify-start gap-2.5 px-3 py-2.5 text-left whitespace-normal",
				onClick: open
			}, {
				default: withCtx(() => [
					_cache[0] || (_cache[0] = createBaseVNode("span", {
						"aria-hidden": "true",
						"data-testid": "workflow-link-media",
						class: "flex size-8 shrink-0 items-center justify-center rounded-md border bg-secondary text-muted-foreground"
					}, [createBaseVNode("span", { class: "icon-[comfy--workflow] size-4" })], -1)),
					createBaseVNode("span", _hoisted_1$16, [createBaseVNode("span", _hoisted_2$15, toDisplayString(label.value), 1), nodeCount.value !== void 0 ? (openBlock(), createElementBlock("span", {
						key: 0,
						id: unref(nodeCountId),
						class: "text-xs text-muted-foreground"
					}, toDisplayString(unref(t)("g.nodesCount", nodeCount.value)), 9, _hoisted_3$8)) : createCommentVNode("", true)]),
					_cache[1] || (_cache[1] = createBaseVNode("span", {
						"aria-hidden": "true",
						"data-testid": "workflow-link-navigation",
						class: "icon-[lucide--arrow-right] size-4 shrink-0 text-muted-foreground"
					}, null, -1))
				]),
				_: 1
			}, 8, ["aria-label", "aria-describedby"])) : createCommentVNode("", true);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/WorkSummary.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$15 = {
	key: 0,
	class: "icon-[lucide--triangle-alert] size-4 shrink-0",
	"data-testid": "agent-canvas-unconfirmed"
};
var _hoisted_2$14 = { class: "text-left" };
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/WorkSummary.vue
var WorkSummary_default = /* @__PURE__ */ defineComponent({
	__name: "WorkSummary",
	props: { parts: {} },
	setup(__props) {
		const { t } = useI18n();
		const unconfirmedCanvasWrite = computed(() => __props.parts.some((part) => part.type === "tool" && (isUnconfirmedCanvasWrite(part) || part.ok === true && part.state === "streaming" && toolCanMutateCanvas(part.name))));
		return (_ctx, _cache) => {
			return openBlock(), createBlock(unref(CollapsibleRoot_default), null, {
				default: withCtx(() => [createVNode(unref(CollapsibleTrigger_default), { class: "group flex h-8 w-full cursor-pointer items-center gap-2 rounded-lg px-2 text-sm leading-none font-normal text-muted-foreground transition-colors hover:bg-accent hover:text-foreground" }, {
					default: withCtx(() => [
						unconfirmedCanvasWrite.value ? (openBlock(), createElementBlock("span", _hoisted_1$15)) : createCommentVNode("", true),
						createBaseVNode("span", _hoisted_2$14, toDisplayString(unconfirmedCanvasWrite.value ? unref(t)("agent.workedNotConfirmedOnCanvas") : unref(t)("agent.worked")), 1),
						_cache[0] || (_cache[0] = createBaseVNode("span", { class: "icon-[lucide--chevron-down] size-4 shrink-0 transition-transform group-data-[state=open]:rotate-180" }, null, -1))
					]),
					_: 1
				}), createVNode(unref(CollapsibleContent_default), { class: "agent-work-summary overflow-hidden" }, {
					default: withCtx(() => [createVNode(ActivityTrace_default, { parts: __props.parts }, null, 8, ["parts"])]),
					_: 1
				})]),
				_: 1
			});
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/AgentMessageGroup.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$14 = {
	key: 2,
	role: "group",
	class: "flex flex-col gap-1"
};
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/AgentMessageGroup.vue
var AgentMessageGroup_default = /* @__PURE__ */ defineComponent({
	__name: "AgentMessageGroup",
	props: {
		group: {},
		streaming: { type: Boolean },
		activityParts: {},
		answeringAskIds: {},
		paywallPresentation: {}
	},
	emits: [
		"answer",
		"openWorkflow",
		"approvalShown",
		"paywallAction"
	],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		return (_ctx, _cache) => {
			return __props.group.kind === "text" ? (openBlock(), createBlock(MarkdownStream_default, {
				key: 0,
				text: __props.group.parts.map((part) => part.text).join("\n\n")
			}, null, 8, ["text"])) : __props.group.kind === "trace" ? (openBlock(), createElementBlock(Fragment, { key: 1 }, [__props.streaming ? (openBlock(), createBlock(ActivityTrace_default, {
				key: 0,
				parts: __props.activityParts,
				live: ""
			}, null, 8, ["parts"])) : (openBlock(), createBlock(WorkSummary_default, {
				key: 1,
				parts: __props.activityParts
			}, null, 8, ["parts"]))], 64)) : __props.group.kind === "tabLinks" ? (openBlock(), createElementBlock("div", _hoisted_1$14, [(openBlock(true), createElementBlock(Fragment, null, renderList(__props.group.parts, (link, linkIndex) => {
				return openBlock(), createBlock(TabLinkCard_default, {
					key: linkIndex,
					"workflow-id": link.workflowId,
					"locator-id": link.locatorId,
					name: link.name
				}, null, 8, [
					"workflow-id",
					"locator-id",
					"name"
				]);
			}), 128))])) : __props.group.kind === "runApproval" ? (openBlock(), createBlock(RunApprovalCard_default, {
				key: 3,
				part: __props.group.part,
				answering: __props.answeringAskIds.has(__props.group.part.askId),
				onAnswer: _cache[0] || (_cache[0] = (askId, selection) => emit("answer", askId, { selected: [selection] })),
				onShown: _cache[1] || (_cache[1] = (askId, workflowId) => emit("approvalShown", askId, workflowId)),
				onOpenWorkflow: _cache[2] || (_cache[2] = (askId, workflowId, workflowName) => emit("openWorkflow", askId, workflowId, workflowName))
			}, null, 8, ["part", "answering"])) : __props.group.kind === "askUser" ? (openBlock(), createBlock(AskUserCard_default, {
				key: 4,
				part: __props.group.part,
				answering: __props.answeringAskIds.has(__props.group.part.askId),
				onAnswer: _cache[3] || (_cache[3] = (askId, answer) => emit("answer", askId, answer))
			}, null, 8, ["part", "answering"])) : __props.group.kind === "deleteApproval" ? (openBlock(), createBlock(DeleteApprovalCard_default, {
				key: 5,
				part: __props.group.part,
				answering: __props.answeringAskIds.has(__props.group.part.askId),
				onAnswer: _cache[4] || (_cache[4] = (askId, selection) => emit("answer", askId, { selected: [selection] }))
			}, null, 8, ["part", "answering"])) : __props.group.kind === "paywall" ? (openBlock(), createBlock(AgentPaywallCard_default, {
				key: 6,
				presentation: __props.paywallPresentation,
				message: __props.group.part.message,
				onPaywallAction: _cache[5] || (_cache[5] = ($event) => emit("paywallAction", $event))
			}, null, 8, ["presentation", "message"])) : (openBlock(), createBlock(AgentNoticeCard_default, {
				key: 7,
				part: __props.group.part
			}, null, 8, ["part"]));
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/MessageFeedback.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$13 = { class: "flex w-full items-center gap-1 text-muted-foreground" };
var _hoisted_2$13 = { class: "flex h-6 w-14 rounded-lg transition-colors hover:bg-accent hover:text-foreground has-data-[state=open]:bg-accent has-data-[state=open]:text-foreground" };
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/MessageFeedback.vue
var MessageFeedback_default = /* @__PURE__ */ defineComponent({
	__name: "MessageFeedback",
	props: {
		markdown: {},
		assets: { default: () => [] }
	},
	emits: ["feedback"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const { t } = useI18n();
		const { copy, copied } = useClipboard({
			copiedDuring: 2e3,
			legacy: true
		});
		const { downloadFiles } = useAssetDownload();
		const vote = ref(null);
		function setVote(next) {
			vote.value = vote.value === next ? null : next;
			emit("feedback", vote.value);
		}
		function copyPlainText() {
			const doc = new DOMParser().parseFromString(renderMarkdownToHtml(__props.markdown), "text/html");
			copy(doc.body.textContent?.trim() ?? "");
		}
		const downloading = ref(false);
		const copyMenuItems = computed(() => [{
			label: t("agent.copyMarkdown"),
			command: () => copy(__props.markdown)
		}]);
		async function downloadAssets() {
			if (downloading.value) return;
			downloading.value = true;
			try {
				await downloadFiles(await Promise.all(__props.assets.map(resolveReplyAssetDownload)));
			} finally {
				downloading.value = false;
			}
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$13, [
				createVNode(Button_default, {
					tooltip: unref(t)("agent.helpful"),
					type: "button",
					variant: vote.value === "up" ? "textonly" : "muted-textonly",
					size: "icon-sm",
					"aria-label": unref(t)("agent.helpful"),
					"aria-pressed": vote.value === "up",
					class: "size-6",
					onClick: _cache[0] || (_cache[0] = ($event) => setVote("up"))
				}, {
					default: withCtx(() => [..._cache[3] || (_cache[3] = [createBaseVNode("span", { class: "icon-[lucide--thumbs-up] size-3" }, null, -1)])]),
					_: 1
				}, 8, [
					"tooltip",
					"variant",
					"aria-label",
					"aria-pressed"
				]),
				createVNode(Button_default, {
					tooltip: unref(t)("agent.notHelpful"),
					type: "button",
					variant: vote.value === "down" ? "textonly" : "muted-textonly",
					size: "icon-sm",
					"aria-label": unref(t)("agent.notHelpful"),
					"aria-pressed": vote.value === "down",
					class: "size-6",
					onClick: _cache[1] || (_cache[1] = ($event) => setVote("down"))
				}, {
					default: withCtx(() => [..._cache[4] || (_cache[4] = [createBaseVNode("span", { class: "icon-[lucide--thumbs-down] size-3" }, null, -1)])]),
					_: 1
				}, 8, [
					"tooltip",
					"variant",
					"aria-label",
					"aria-pressed"
				]),
				__props.assets.length ? (openBlock(), createBlock(Button_default, {
					key: 0,
					tooltip: unref(t)("agent.downloadAssets"),
					type: "button",
					variant: "muted-textonly",
					size: "icon-sm",
					"aria-label": unref(t)("agent.downloadAssets"),
					disabled: downloading.value,
					class: "size-6 rounded-lg",
					onClick: downloadAssets
				}, {
					default: withCtx(() => [..._cache[5] || (_cache[5] = [createBaseVNode("span", { class: "icon-[lucide--download] size-3" }, null, -1)])]),
					_: 1
				}, 8, [
					"tooltip",
					"aria-label",
					"disabled"
				])) : createCommentVNode("", true),
				createBaseVNode("div", _hoisted_2$13, [createVNode(Tooltip_default, { "disable-closing-trigger": "" }, {
					default: withCtx(() => [createVNode(TooltipTrigger_default, { "as-child": "" }, {
						default: withCtx(() => [createVNode(Button_default, {
							type: "button",
							variant: "muted-textonly",
							size: "unset",
							"aria-label": unref(copied) ? unref(t)("agent.copied") : unref(t)("agent.copy"),
							class: normalizeClass(unref(cn)("h-6 w-8 rounded-l-lg rounded-r-none focus-visible:z-10", unref(copied) ? "text-foreground" : "text-inherit")),
							onClick: _cache[2] || (_cache[2] = ($event) => copyPlainText())
						}, {
							default: withCtx(() => [createBaseVNode("span", { class: normalizeClass(unref(cn)("size-3", unref(copied) ? "icon-[lucide--check]" : "icon-[lucide--copy]")) }, null, 2)]),
							_: 1
						}, 8, ["aria-label", "class"])]),
						_: 1
					}), createVNode(TooltipContent_default, null, {
						default: withCtx(() => [createTextVNode(toDisplayString(unref(copied) ? unref(t)("agent.copied") : unref(t)("agent.copy")), 1)]),
						_: 1
					})]),
					_: 1
				}), createVNode(Menu_default, {
					items: copyMenuItems.value,
					align: "end",
					"side-offset": 4,
					class: "agent-scope"
				}, {
					trigger: withCtx(() => [createVNode(Button_default, {
						variant: "muted-textonly",
						size: "icon-sm",
						"aria-label": unref(t)("agent.copyMarkdown"),
						class: "size-6 rounded-l-none rounded-r-lg text-inherit focus-visible:z-10"
					}, {
						default: withCtx(() => [..._cache[6] || (_cache[6] = [createBaseVNode("span", { class: "icon-[lucide--chevron-down] size-3" }, null, -1)])]),
						_: 1
					}, 8, ["aria-label"])]),
					_: 1
				}, 8, ["items"])])
			]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/agentMessageGroup.ts
function groupMessageParts(parts) {
	const out = [];
	let tracePlaced = false;
	let openTextGroup = null;
	for (const part of parts) {
		if (part.type === "tool" || part.type === "thinking") {
			if (tracePlaced) continue;
			tracePlaced = true;
			out.push({ kind: "trace" });
			continue;
		}
		if (part.type === "text") {
			openTextGroup = appendText(out, openTextGroup, part);
			continue;
		}
		openTextGroup = null;
		pushInterruptingGroup(out, part);
	}
	return out;
}
function appendText(out, openTextGroup, part) {
	if (openTextGroup) {
		openTextGroup.parts.push(part);
		return openTextGroup;
	}
	const group = {
		kind: "text",
		parts: [part]
	};
	out.push(group);
	return group;
}
function pushInterruptingGroup(out, part) {
	if (part.type !== "tabLink") {
		out.push(cardGroup(part));
		return;
	}
	const prev = out.at(-1);
	if (prev?.kind === "tabLinks") prev.parts.push(part);
	else out.push({
		kind: "tabLinks",
		parts: [part]
	});
}
function cardGroup(part) {
	switch (part.type) {
		case "runApproval": return {
			kind: "runApproval",
			part
		};
		case "askUser": return {
			kind: "askUser",
			part
		};
		case "deleteApproval": return {
			kind: "deleteApproval",
			part
		};
		case "paywall": return {
			kind: "paywall",
			part
		};
		case "notice":
		case "askUnavailable": return {
			kind: "notice",
			part
		};
	}
}
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/AgentMessage.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$12 = { class: "space-y-2 pb-4" };
var _hoisted_2$12 = {
	key: 0,
	class: "flex h-8 items-center gap-2 rounded-lg px-2 text-sm/5 font-normal text-muted-foreground"
};
var _hoisted_3$7 = { class: "agent-shimmer-text min-w-0 truncate" };
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/AgentMessage.vue
var AgentMessage_default = /* @__PURE__ */ defineComponent({
	__name: "AgentMessage",
	props: {
		message: {},
		answeringAskIds: { default: () => /* @__PURE__ */ new Set() },
		paywallPresentation: { default: () => DEFAULT_AGENT_PAYWALL_PRESENTATION }
	},
	emits: [
		"feedback",
		"answerAsk",
		"openWorkflow",
		"approvalShown",
		"paywallAction"
	],
	setup(__props, { emit: __emit }) {
		const { t } = useI18n();
		const emit = __emit;
		const activityParts = computed(() => __props.message.parts.filter((part) => part.type === "tool" || part.type === "thinking"));
		const groups = computed(() => groupMessageParts(__props.message.parts));
		function groupKey(group, index) {
			const askId = "part" in group ? askIdOf(group.part) : void 0;
			return askId === void 0 ? `group:${index}` : `ask:${askId}`;
		}
		const markdown = computed(() => __props.message.parts.filter((part) => part.type === "text").map((part) => part.text).join("\n\n"));
		const showActions = computed(() => !__props.message.streaming && markdown.value.length > 0);
		const replyAssets = computed(() => showActions.value ? htmlReplyAssets(renderMarkdownToHtml(markdown.value)) : []);
		const composing = computed(() => __props.message.streaming && __props.message.parts.length > 0 && __props.message.parts.every((part) => !isOpenAskPart(part) && (!("state" in part) || part.state === "done")));
		const status = computed(() => {
			if (activityParts.value.length === 0 && (__props.message.thinking || __props.message.streaming && !__props.message.parts.length)) return {
				icon: "icon-[lucide--brain]",
				text: __props.message.thinkingText || t("agent.thinking")
			};
			if (composing.value) return {
				icon: "text-muted-foreground icon-[lucide--loader-circle] animate-spin",
				text: t("agent.working")
			};
			return null;
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$12, [
				(openBlock(true), createElementBlock(Fragment, null, renderList(groups.value, (group, index) => {
					return openBlock(), createBlock(AgentMessageGroup_default, {
						key: groupKey(group, index),
						group,
						streaming: __props.message.streaming,
						"activity-parts": activityParts.value,
						"answering-ask-ids": __props.answeringAskIds,
						"paywall-presentation": __props.paywallPresentation,
						onAnswer: _cache[0] || (_cache[0] = (askId, answer) => emit("answerAsk", askId, answer)),
						onApprovalShown: _cache[1] || (_cache[1] = (askId, workflowId) => emit("approvalShown", askId, __props.message.id, workflowId)),
						onOpenWorkflow: _cache[2] || (_cache[2] = (askId, workflowId, workflowName) => emit("openWorkflow", askId, workflowId, workflowName)),
						onPaywallAction: _cache[3] || (_cache[3] = ($event) => emit("paywallAction", $event))
					}, null, 8, [
						"group",
						"streaming",
						"activity-parts",
						"answering-ask-ids",
						"paywall-presentation"
					]);
				}), 128)),
				status.value ? (openBlock(), createElementBlock("div", _hoisted_2$12, [createBaseVNode("span", { class: normalizeClass(unref(cn)("size-4 shrink-0", status.value.icon)) }, null, 2), createBaseVNode("span", _hoisted_3$7, toDisplayString(status.value.text), 1)])) : createCommentVNode("", true),
				showActions.value ? (openBlock(), createBlock(MessageFeedback_default, {
					key: 1,
					markdown: markdown.value,
					assets: replyAssets.value,
					onFeedback: _cache[4] || (_cache[4] = ($event) => emit("feedback", $event))
				}, null, 8, ["markdown", "assets"])) : createCommentVNode("", true)
			]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/userMessageClipboard.ts
function userMessageClipboard(message) {
	const { text, workflowReferences = [], skillReference } = message;
	const plainText = agentMessageText(message);
	const prompt = promptDocument({
		text,
		references: promptReferenceParts(text, workflowReferences, skillReference).flatMap((part) => {
			if (part.type === "text") return [];
			return part.type === "workflow" ? [{
				...part.reference,
				kind: "workflow"
			}] : [{
				...part.reference,
				kind: "skill",
				scope: ""
			}];
		})
	});
	const container = document.createElement("span");
	container.style.whiteSpace = "pre-wrap";
	container.append(DOMSerializer.fromSchema(inlinePromptSchema).serializeFragment(prompt.content), plainText.slice(agentMessageText({
		text,
		workflowReferences,
		skillReference
	}).length));
	return {
		text: plainText,
		html: container.outerHTML
	};
}
function selectedUserMessageClipboard(bubble, selection) {
	if (!selection || selection.isCollapsed || selection.rangeCount !== 1) return;
	const range = selection.getRangeAt(0).cloneRange();
	if (!bubble.contains(range.startContainer) || !bubble.contains(range.endContainer)) return;
	for (const chip of bubble.querySelectorAll("[data-comfy-workflow=\"1\"], [data-comfy-skill=\"1\"]")) {
		if (chip.contains(range.startContainer)) range.setStartBefore(chip);
		if (chip.contains(range.endContainer)) range.setEndAfter(chip);
	}
	const selectedContent = range.cloneContents();
	for (const skill of selectedContent.querySelectorAll("[data-comfy-skill=\"1\"]")) {
		const name = skill.getAttribute("data-skill-name");
		if (name !== null) skill.textContent = `/${name}`;
	}
	const prompt = promptDraft(DOMParser$1.fromSchema(inlinePromptSchema).parse(selectedContent, { preserveWhitespace: "full" }));
	if (!prompt.references.length) return;
	return userMessageClipboard(composerPromptForSend(prompt));
}
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/UserMessage.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$11 = {
	key: 0,
	class: "flex flex-wrap justify-end gap-1"
};
var _hoisted_2$11 = {
	key: 1,
	class: "w-full"
};
var _hoisted_3$6 = {
	key: 2,
	class: "grid w-56 max-w-full grid-cols-2 gap-1.5"
};
var _hoisted_4$5 = { class: "flex aspect-square w-full items-center justify-center rounded-lg bg-secondary" };
var _hoisted_5$4 = { class: "mt-0.5 truncate text-xs text-muted-foreground" };
var _hoisted_6$4 = {
	key: 4,
	class: "pointer-events-none flex text-muted-foreground opacity-0 transition-opacity group-hover:pointer-events-auto group-hover:opacity-100 focus-within:pointer-events-auto focus-within:opacity-100 touch:pointer-events-auto touch:opacity-100"
};
//#endregion
//#region src/workbench/extensions/agent/components/agent/message/UserMessage.vue
var UserMessage_default = /* @__PURE__ */ defineComponent({
	__name: "UserMessage",
	props: {
		text: {},
		attachments: { default: () => [] },
		tags: { default: () => [] },
		workflowReferences: { default: () => [] },
		skillReference: {},
		editable: {
			type: Boolean,
			default: false
		}
	},
	emits: ["edit", "openReferenceWorkflow"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const { t } = useI18n();
		const promptParts = computed(() => promptReferenceParts(__props.text, __props.workflowReferences, __props.skillReference));
		const readableText = computed(() => agentMessageText({
			text: __props.text,
			workflowReferences: __props.workflowReferences,
			skillReference: __props.skillReference,
			tags: __props.tags,
			attachments: __props.attachments
		}));
		const bubble = useTemplateRef("bubble");
		const plainClipboard = useClipboard({
			copiedDuring: 2e3,
			legacy: true
		});
		const richClipboard = useClipboardItems({ copiedDuring: 2e3 });
		const copied = computed(() => plainClipboard.copied.value || richClipboard.copied.value);
		async function copyMessage() {
			if ((__props.workflowReferences.length || __props.skillReference) && richClipboard.isSupported.value && typeof ClipboardItem !== "undefined") {
				const content = userMessageClipboard({
					text: __props.text,
					workflowReferences: __props.workflowReferences,
					skillReference: __props.skillReference,
					tags: __props.tags,
					attachments: __props.attachments
				});
				try {
					await richClipboard.copy([new ClipboardItem({
						"text/plain": new Blob([content.text], { type: "text/plain" }),
						"text/html": new Blob([content.html], { type: "text/html" })
					})]);
					return;
				} catch {
					await plainClipboard.copy(content.text);
					return;
				}
			}
			await plainClipboard.copy(readableText.value);
		}
		function copySelection(event) {
			if (!bubble.value || !event.clipboardData) return;
			const content = selectedUserMessageClipboard(bubble.value, document.getSelection());
			if (!content) return;
			event.clipboardData.setData("text/plain", content.text);
			event.clipboardData.setData("text/html", content.html);
			event.preventDefault();
			event.stopPropagation();
		}
		function openReference(reference) {
			if (reference.unavailable) return;
			emit("openReferenceWorkflow", reference.id, reference.name);
		}
		function attachmentIconClass(name) {
			const kind = getMediaTypeFromFilename(name);
			return kind === "other" ? "icon-[lucide--file]" : iconForMediaType(kind);
		}
		const splitAttachments = computed(() => {
			const grid = [];
			const plain = [];
			for (const item of __props.attachments) {
				const asset = gridAsset(item);
				if (asset) grid.push(asset);
				else plain.push(item);
			}
			return {
				grid,
				plain
			};
		});
		function gridAsset(item) {
			const kind = item.kind ?? getMediaTypeFromFilename(item.name);
			if (!isReplyAssetKind(kind)) return void 0;
			const url = attachmentUrl(item, kind);
			if (!url) return void 0;
			const filename = item.ref ?? item.name;
			return {
				url,
				filename,
				kind,
				label: filename === item.name ? void 0 : item.name
			};
		}
		function attachmentUrl(item, kind) {
			const capturedUrl = kind === "video" || kind === "audio" ? item.mediaUrl : item.previewUrl;
			if (capturedUrl) return capturedUrl;
			if (!item.ref || isHdrImageFilename(item.name)) return;
			return api.apiURL(`/view?filename=${encodeURIComponent(item.ref)}&type=input`);
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				class: "group flex flex-col items-end gap-2 pl-16",
				onCopy: copySelection
			}, [
				__props.tags.length ? (openBlock(), createElementBlock("div", _hoisted_1$11, [(openBlock(true), createElementBlock(Fragment, null, renderList(__props.tags, (tag, index) => {
					return openBlock(), createBlock(Tag_default, {
						key: `${tag}:${index}`,
						label: tag,
						shape: "rounded",
						class: "max-w-48"
					}, {
						icon: withCtx(() => [..._cache[1] || (_cache[1] = [createBaseVNode("span", { class: "icon-[lucide--at-sign] size-3 shrink-0" }, null, -1)])]),
						_: 1
					}, 8, ["label"]);
				}), 128))])) : createCommentVNode("", true),
				splitAttachments.value.grid.length ? (openBlock(), createElementBlock("div", _hoisted_2$11, [createVNode(ReplyAssetGroup_default, { assets: splitAttachments.value.grid }, null, 8, ["assets"])])) : createCommentVNode("", true),
				splitAttachments.value.plain.length ? (openBlock(), createElementBlock("div", _hoisted_3$6, [(openBlock(true), createElementBlock(Fragment, null, renderList(splitAttachments.value.plain, (item, index) => {
					return openBlock(), createElementBlock("figure", {
						key: `${item.name}:${index}`,
						class: "m-0"
					}, [createBaseVNode("div", _hoisted_4$5, [createBaseVNode("span", { class: normalizeClass(unref(cn)(attachmentIconClass(item.name), "size-6 text-muted-foreground")) }, null, 2)]), createBaseVNode("figcaption", _hoisted_5$4, toDisplayString(item.name), 1)]);
				}), 128))])) : createCommentVNode("", true),
				__props.text || __props.workflowReferences.length || __props.skillReference ? (openBlock(), createElementBlock("div", {
					key: 3,
					ref_key: "bubble",
					ref: bubble,
					"data-testid": "user-message-bubble",
					class: "w-fit max-w-full rounded-lg bg-secondary px-2.5 py-1.5 text-sm/5 font-normal wrap-break-word whitespace-pre-wrap text-muted-foreground"
				}, [(openBlock(true), createElementBlock(Fragment, null, renderList(promptParts.value, (part, index) => {
					return openBlock(), createElementBlock(Fragment, { key: index }, [part.type === "workflow" ? (openBlock(), createBlock(Tag_default, {
						key: 0,
						interactive: "",
						label: part.reference.name,
						class: "-my-0.5 max-w-64 align-middle",
						"aria-label": part.reference.unavailable ? unref(t)("agent.unavailableWorkflowReference", { name: part.reference.name }) : unref(t)("agent.openWorkflowTab", { name: part.reference.name }),
						"data-testid": "workflow-reference-chip",
						"data-comfy-workflow": "1",
						"data-workflow-id": part.reference.id,
						"data-workflow-unavailable": part.reference.unavailable ? "true" : void 0,
						"aria-disabled": part.reference.unavailable,
						"aria-description": part.reference.unavailable ? unref(t)("agent.workflowReferenceUnavailableReason") : void 0,
						title: part.reference.unavailable ? unref(t)("agent.workflowReferenceUnavailableReason") : void 0,
						onClick: ($event) => openReference(part.reference)
					}, {
						icon: withCtx(() => [..._cache[2] || (_cache[2] = [createBaseVNode("span", { class: "icon-[comfy--workflow] size-3 shrink-0" }, null, -1)])]),
						_: 1
					}, 8, [
						"label",
						"aria-label",
						"data-workflow-id",
						"data-workflow-unavailable",
						"aria-disabled",
						"aria-description",
						"title",
						"onClick"
					])) : part.type === "skill" ? (openBlock(), createBlock(CatalogSkillReference_default, {
						key: 1,
						skill: part.reference
					}, null, 8, ["skill"])) : (openBlock(), createElementBlock(Fragment, { key: 2 }, [createTextVNode(toDisplayString(part.text), 1)], 64))], 64);
				}), 128))], 512)) : createCommentVNode("", true),
				readableText.value ? (openBlock(), createElementBlock("div", _hoisted_6$4, [__props.editable && (__props.text || __props.workflowReferences.length || __props.skillReference) ? (openBlock(), createBlock(Button_default, {
					key: 0,
					tooltip: unref(t)("g.edit"),
					type: "button",
					variant: "muted-textonly",
					size: "icon-sm",
					"aria-label": unref(t)("g.edit"),
					class: "size-6 rounded-lg",
					onClick: _cache[0] || (_cache[0] = ($event) => emit("edit", {
						text: __props.text,
						workflowReferences: __props.workflowReferences,
						...__props.skillReference ? { skillReference: __props.skillReference } : {}
					}))
				}, {
					default: withCtx(() => [..._cache[3] || (_cache[3] = [createBaseVNode("span", { class: "icon-[lucide--pencil] size-3" }, null, -1)])]),
					_: 1
				}, 8, ["tooltip", "aria-label"])) : createCommentVNode("", true), createVNode(Tooltip_default, { "disable-closing-trigger": "" }, {
					default: withCtx(() => [createVNode(TooltipTrigger_default, { "as-child": "" }, {
						default: withCtx(() => [createVNode(Button_default, {
							type: "button",
							variant: "muted-textonly",
							size: "icon-sm",
							"aria-label": copied.value ? unref(t)("agent.copied") : unref(t)("agent.copy"),
							class: "size-6 rounded-lg",
							onClick: copyMessage
						}, {
							default: withCtx(() => [createBaseVNode("span", { class: normalizeClass(unref(cn)("size-3", copied.value ? "icon-[lucide--check]" : "icon-[lucide--copy]")) }, null, 2)]),
							_: 1
						}, 8, ["aria-label"])]),
						_: 1
					}), createVNode(TooltipContent_default, null, {
						default: withCtx(() => [createTextVNode(toDisplayString(copied.value ? unref(t)("agent.copied") : unref(t)("agent.copy")), 1)]),
						_: 1
					})]),
					_: 1
				})])) : createCommentVNode("", true)
			], 32);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/ConversationView.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$10 = {
	"data-testid": "agent-conversation",
	class: "relative h-full"
};
var _hoisted_2$10 = { class: "flex flex-col gap-4" };
var bottomGracePx = 16;
var followIntentTolerancePx = 1;
//#endregion
//#region src/workbench/extensions/agent/components/agent/ConversationView.vue
var ConversationView_default = /* @__PURE__ */ defineComponent({
	__name: "ConversationView",
	props: {
		entries: {},
		conversationId: {},
		paywallPresentation: { default: () => DEFAULT_AGENT_PAYWALL_PRESENTATION },
		editableTurnId: { default: null },
		answeringAskIds: { default: () => /* @__PURE__ */ new Set() }
	},
	emits: [
		"feedback",
		"editPrompt",
		"answerAsk",
		"openWorkflow",
		"approvalShown",
		"openReferenceWorkflow",
		"paywallAction"
	],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const { t } = useI18n();
		const skills = useSkillPacksStore();
		const conversation = useAgentConversationStore();
		const hasSkills = computed(() => __props.entries.some((entry) => entry.role === "user" && entry.skillReference));
		function refreshSkills() {
			skills.startFlagGate({ fetch: false });
			if (skills.enabled) skills.refreshPacks();
		}
		watch(() => conversation.historySkillNames, (names) => {
			if (names.length) refreshSkills();
		}, { immediate: true });
		watch([() => skills.enabled, () => skills.scope], () => {
			if (hasSkills.value) refreshSkills();
		});
		const scrollContainer = ref();
		const content = ref();
		const shouldFollowLatest = ref(true);
		const atBottom = ref(true);
		let pendingProgrammaticScroll;
		let pendingConversationId;
		const top = ref();
		const atTop = ref(true);
		useIntersectionObserver(top, ([entry]) => {
			atTop.value = entry?.isIntersecting ?? true;
		});
		function clearPendingProgrammaticScroll() {
			if (pendingProgrammaticScroll) cancelAnimationFrame(pendingProgrammaticScroll.frame);
			pendingProgrammaticScroll = void 0;
		}
		useEventListener(scrollContainer, "pointerdown", clearPendingProgrammaticScroll);
		useEventListener(scrollContainer, "keydown", clearPendingProgrammaticScroll);
		useEventListener(scrollContainer, "wheel", clearPendingProgrammaticScroll, { passive: true });
		useEventListener(scrollContainer, "touchstart", clearPendingProgrammaticScroll, { passive: true });
		onBeforeUnmount(clearPendingProgrammaticScroll);
		function scrollToLatest() {
			const element = scrollContainer.value;
			if (!element) return;
			shouldFollowLatest.value = true;
			atBottom.value = true;
			const target = Math.max(0, element.scrollHeight - element.clientHeight);
			clearPendingProgrammaticScroll();
			if (element.scrollHeight > element.clientHeight && Math.abs(element.scrollTop - target) > bottomGracePx) pendingProgrammaticScroll = {
				target,
				frame: requestAnimationFrame(clearPendingProgrammaticScroll)
			};
			if (typeof element.scrollTo === "function") element.scrollTo({
				top: target,
				behavior: "instant"
			});
			else element.scrollTop = target;
		}
		useEventListener(scrollContainer, "scroll", () => {
			const element = scrollContainer.value;
			if (!element) return;
			atBottom.value = element.scrollHeight - element.scrollTop - element.clientHeight <= bottomGracePx;
			if (pendingProgrammaticScroll && Math.abs(element.scrollTop - pendingProgrammaticScroll.target) <= bottomGracePx) {
				clearPendingProgrammaticScroll();
				return;
			}
			shouldFollowLatest.value = element.scrollHeight - element.scrollTop - element.clientHeight <= followIntentTolerancePx;
			clearPendingProgrammaticScroll();
		});
		function followLatestAfterResize() {
			const element = scrollContainer.value;
			if (!element || element.clientHeight === 0) return;
			atBottom.value = element.scrollHeight - element.scrollTop - element.clientHeight <= bottomGracePx;
			if (shouldFollowLatest.value) scrollToLatest();
		}
		useResizeObserver(content, followLatestAfterResize);
		useResizeObserver(scrollContainer, followLatestAfterResize);
		const latestContentSignal = computed(() => {
			const last = __props.entries.at(-1);
			if (!last || !("parts" in last)) return `${__props.entries.length}`;
			const tail = last.parts.at(-1);
			const tailText = tail && "text" in tail ? tail.text.length : 0;
			const settled = last.parts.filter((part) => "state" in part && part.state === "done").length;
			return `${__props.entries.length}:${last.streaming}:${last.parts.length}:${settled}:${tailText}`;
		});
		watch(() => __props.conversationId, (current, previous) => {
			if (current == null || previous == null) return;
			pendingConversationId = current;
			shouldFollowLatest.value = true;
		});
		watch(() => __props.entries, async () => {
			if (__props.entries.length === 0) {
				pendingConversationId = void 0;
				shouldFollowLatest.value = true;
				return;
			}
			if (pendingConversationId === void 0 || pendingConversationId !== __props.conversationId) return;
			pendingConversationId = void 0;
			shouldFollowLatest.value = true;
			await nextTick();
			scrollToLatest();
		});
		watch(latestContentSignal, async () => {
			if (!shouldFollowLatest.value) return;
			await nextTick();
			if (!shouldFollowLatest.value) return;
			scrollToLatest();
		}, {
			flush: "post",
			immediate: true
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$10, [createBaseVNode("div", {
				ref_key: "scrollContainer",
				ref: scrollContainer,
				"data-testid": "agent-conversation-scroll",
				class: normalizeClass(unref(cn)("h-full overflow-y-auto", !atTop.value && "mask-t-from-[calc(100%-2rem)]", !atBottom.value && "mask-b-from-[calc(100%-2rem)]"))
			}, [createBaseVNode("div", {
				ref_key: "top",
				ref: top
			}, null, 512), createBaseVNode("div", {
				ref_key: "content",
				ref: content,
				class: "mx-auto max-w-[640px] p-4"
			}, [createBaseVNode("div", _hoisted_2$10, [(openBlock(true), createElementBlock(Fragment, null, renderList(__props.entries, (entry) => {
				return openBlock(), createElementBlock(Fragment, { key: `${entry.role}-${entry.id}` }, [entry.role === "user" ? (openBlock(), createBlock(UserMessage_default, {
					key: 0,
					text: entry.text,
					attachments: entry.attachments,
					tags: entry.tags,
					"workflow-references": entry.workflowReferences,
					"skill-reference": entry.skillReference,
					editable: entry.id === __props.editableTurnId,
					onEdit: _cache[0] || (_cache[0] = ($event) => emit("editPrompt", $event)),
					onOpenReferenceWorkflow: _cache[1] || (_cache[1] = (workflowId, workflowName) => emit("openReferenceWorkflow", workflowId, workflowName))
				}, null, 8, [
					"text",
					"attachments",
					"tags",
					"workflow-references",
					"skill-reference",
					"editable"
				])) : (openBlock(), createBlock(AgentMessage_default, {
					key: 1,
					message: entry,
					"answering-ask-ids": __props.answeringAskIds,
					"paywall-presentation": __props.paywallPresentation,
					onFeedback: ($event) => emit("feedback", entry.id, $event),
					onAnswerAsk: _cache[2] || (_cache[2] = (askId, answer) => emit("answerAsk", askId, answer)),
					onApprovalShown: _cache[3] || (_cache[3] = (askId, turnId, workflowId) => emit("approvalShown", askId, turnId, workflowId)),
					onOpenWorkflow: _cache[4] || (_cache[4] = (askId, workflowId, workflowName) => emit("openWorkflow", askId, workflowId, workflowName)),
					onPaywallAction: _cache[5] || (_cache[5] = ($event) => emit("paywallAction", $event))
				}, null, 8, [
					"message",
					"answering-ask-ids",
					"paywall-presentation",
					"onFeedback"
				]))], 64);
			}), 128))])], 512)], 2), !shouldFollowLatest.value ? (openBlock(), createBlock(Button_default, {
				key: 0,
				tooltip: unref(t)("agent.latest"),
				type: "button",
				variant: "secondary",
				size: "icon",
				"aria-label": unref(t)("agent.latest"),
				class: "absolute bottom-2 left-1/2 -translate-x-1/2 rounded-full shadow-md ring-1 ring-muted-foreground",
				onClick: scrollToLatest
			}, {
				default: withCtx(() => [..._cache[6] || (_cache[6] = [createBaseVNode("span", { class: "icon-[lucide--chevron-down] size-4" }, null, -1)])]),
				_: 1
			}, 8, ["tooltip", "aria-label"])) : createCommentVNode("", true)]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/utils/starterPrompts.ts
/**
* Stable ids for the empty state's starter prompts, index-aligned with
* `agent.suggestedPrompts.{cloud,local}` and the Cloud-only
* `agent.suggestedPrompts.treatment.cloud` list in the English locale, and with
* the icon list in `EmptyState.vue`. A Cloud slot shows different copy per arm.
*
* The copy is owned by product and is expected to change; these ids are not,
* which is the whole point of them — an event keyed on display text cannot
* survive a rewrite, and an event keyed on nothing cannot tell the five chips
* apart. An appended prompt needs its id added here; until then that extra chip
* reports `unregistered`.
*/
var STARTER_PROMPT_IDS = [
	"slot_1",
	"slot_2",
	"slot_3",
	"slot_4",
	"slot_5"
];
function starterPromptIdAt(index) {
	return STARTER_PROMPT_IDS[index] ?? "unregistered";
}
/**
* `count` is the size of the rendered set; `visibleCount` is how many of that
* set the viewer could actually see, which is smaller in a narrow panel. They
* are two separate facts and are reported as two separate fields on purpose —
* folding the width-dependent one into `promptCount` would make a set change
* and a panel resize indistinguishable to the starter-prompt set experiment.
* `visibleCount` defaults to `count` for callers with no layout to measure.
*/
function starterPromptAttribution(text, index, count, locale, assignment, visibleCount = count) {
	return {
		promptId: starterPromptIdAt(index),
		promptIndex: index,
		promptCount: count,
		visiblePromptCount: visibleCount,
		promptTextHash: hashPath(text),
		locale,
		...assignment ? { assignment } : {}
	};
}
//#endregion
//#region src/workbench/extensions/agent/components/agent/EmptyState.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$9 = { class: "flex h-full flex-col overflow-x-hidden overflow-y-auto px-4 py-8" };
var _hoisted_2$9 = { class: "my-auto flex shrink-0 flex-col items-center gap-8 text-center" };
var _hoisted_3$5 = { class: "flex max-w-sm flex-col items-center pt-12 text-base/snug font-semibold tracking-tight @min-[570px]:text-2xl/snug" };
var _hoisted_4$4 = { class: "my-0" };
var _hoisted_5$3 = { class: "my-0" };
var _hoisted_6$3 = { class: "truncate" };
var treatmentPromptKey = "agent.suggestedPrompts.treatment.cloud";
var COMPACT_PROMPT_COUNT = 3;
//#endregion
//#region src/workbench/extensions/agent/components/agent/EmptyState.vue
var EmptyState_default = /* @__PURE__ */ defineComponent({
	__name: "EmptyState",
	props: {
		userName: {},
		assignment: { default: "control" },
		attributeExperiment: {
			type: Boolean,
			default: false
		}
	},
	emits: ["insert", "rendered"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const { t, te, tm, locale } = useI18n();
		const promptKey = "agent.suggestedPrompts.local";
		const hasTreatmentCopy = computed(() => false);
		const renderedAssignment = __props.assignment === "test" && hasTreatmentCopy.value ? "test" : "control";
		const selectedPromptKey = computed(() => renderedAssignment === "test" && hasTreatmentCopy.value ? treatmentPromptKey : promptKey);
		const prompts = computed(() => {
			return tm(selectedPromptKey.value);
		});
		const effectiveAssignment = computed(() => selectedPromptKey.value === treatmentPromptKey ? "test" : "control");
		const promptLocale = computed(() => {
			return te(`${selectedPromptKey.value}.0`, locale.value) ? locale.value : "en";
		});
		const eligibleAtMount = __props.attributeExperiment && hasTreatmentCopy.value;
		const shouldAttributeExperiment = computed(() => eligibleAtMount && hasTreatmentCopy.value);
		onMounted(() => {
			if (shouldAttributeExperiment.value) emit("rendered", effectiveAssignment.value);
		});
		const promptList = useTemplateRef("promptList");
		/**
		* Suggestions the viewer could actually see. A narrow panel hides the overflow
		* with a container query, so the set's length overstates what was on screen.
		* Reported alongside the set size, never instead of it: the set experiment
		* reads the set size, and one field cannot carry both facts.
		*/
		function visiblePromptCount() {
			const buttons = promptList.value?.querySelectorAll("button");
			if (!buttons) return prompts.value.length;
			return Array.from(buttons).filter((button) => getComputedStyle(button).display !== "none").length;
		}
		/**
		* One emit per click, carrying the slot's stable id rather than its text. Fires
		* on click only — not on render or focus — so the count is a count of choices.
		*/
		function onPromptClick(prompt, index) {
			emit("insert", prompt, starterPromptAttribution(prompt, index, prompts.value.length, promptLocale.value, shouldAttributeExperiment.value ? effectiveAssignment.value : void 0, visiblePromptCount()));
		}
		const promptIcons = [
			"icon-[lucide--image]",
			"icon-[lucide--video]",
			"icon-[lucide--message-circle-question-mark]",
			"icon-[lucide--puzzle]",
			"icon-[lucide--message-circle-warning]"
		];
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$9, [createBaseVNode("div", _hoisted_2$9, [createBaseVNode("div", _hoisted_3$5, [createBaseVNode("p", _hoisted_4$4, toDisplayString(unref(t)("agent.greeting", { name: __props.userName ?? unref(t)("agent.friend") })), 1), createBaseVNode("p", _hoisted_5$3, toDisplayString(unref(t)("agent.greetingQuestion")), 1)]), createBaseVNode("div", {
				ref_key: "promptList",
				ref: promptList,
				"data-testid": "suggested-prompts",
				class: "mx-auto flex w-full max-w-[608px] shrink-0 flex-wrap gap-2 @min-[460px]:justify-center"
			}, [(openBlock(true), createElementBlock(Fragment, null, renderList(prompts.value, (prompt, index) => {
				return openBlock(), createBlock(Button_default, {
					key: index,
					type: "button",
					variant: "secondary",
					size: "md",
					class: normalizeClass(unref(cn)("w-full max-w-full min-w-0 justify-start rounded-full px-3 text-sm @min-[460px]:w-auto", index >= COMPACT_PROMPT_COUNT && "@max-[460px]:hidden")),
					onClick: ($event) => onPromptClick(prompt, index)
				}, {
					default: withCtx(() => [createBaseVNode("span", {
						class: normalizeClass(unref(cn)("size-3 shrink-0 text-muted-foreground", promptIcons[index] ?? "icon-[lucide--sparkles]")),
						"aria-hidden": "true"
					}, null, 2), createBaseVNode("span", _hoisted_6$3, toDisplayString(prompt), 1)]),
					_: 2
				}, 1032, ["class", "onClick"]);
			}), 128))], 512)])]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/freeUseNoticeDismissal.ts
var FREE_USE_NOTICE_DISMISSED_KEY = "Comfy.AgentPanel.freeUseNoticeDismissed";
/**
* Account-scoped, because a browser-wide dismissal carries across an account
* switch and a shared browser: the next viewer sees no notice while the panel
* still reports them exposed to their treatment arm, diluting the arm with a
* dismissal nobody in it made. Signed-out viewers share the unsuffixed key.
*/
function freeUseNoticeDismissedKey(userId) {
	return userId === void 0 ? FREE_USE_NOTICE_DISMISSED_KEY : `${FREE_USE_NOTICE_DISMISSED_KEY}.${userId}`;
}
//#endregion
//#region src/workbench/extensions/agent/components/agent/FreeUseNotice.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$8 = ["aria-label", "data-placement"];
var _hoisted_2$8 = { class: "my-0 min-w-0 flex-1 text-sm/5" };
//#endregion
//#region src/workbench/extensions/agent/components/agent/FreeUseNotice.vue
var FreeUseNotice_default = /* @__PURE__ */ defineComponent({
	__name: "FreeUseNotice",
	props: { placement: {} },
	emits: ["notice"],
	setup(__props, { emit: __emit }) {
		const PLACEMENT_CLASSES = {
			"top-banner": "px-4 py-3",
			"near-composer": "rounded-lg px-4 py-3",
			"above-input": "px-4 py-3",
			"inside-input": "m-3 rounded-lg px-4 py-3"
		};
		const emit = __emit;
		const { isAuthInitialized, resolvedUserInfo } = useCurrentUser();
		const dismissed = useLocalStorage(() => freeUseNoticeDismissedKey(resolvedUserInfo.value?.id), false, { writeDefaults: false });
		const visible = computed(() => isAuthInitialized.value && !dismissed.value);
		watch(visible, (onScreen) => {
			if (onScreen) emit("notice", {
				action: "shown",
				placement: __props.placement
			});
		}, { immediate: true });
		function onDismiss() {
			dismissed.value = true;
			emit("notice", {
				action: "dismissed",
				placement: __props.placement
			});
		}
		return (_ctx, _cache) => {
			return visible.value ? (openBlock(), createElementBlock("div", {
				key: 0,
				role: "note",
				"aria-label": _ctx.$t("agent.freeUseNoticeLabel"),
				"data-placement": __props.placement,
				class: normalizeClass(unref(cn)("flex items-start gap-3 bg-primary/30 text-foreground", PLACEMENT_CLASSES[__props.placement]))
			}, [createBaseVNode("p", _hoisted_2$8, [createTextVNode(toDisplayString(_ctx.$t("agent.freeUseNotice")) + " ", 1), createVNode(Button_default, {
				variant: "link",
				size: "unset",
				as: "a",
				href: unref(AGENT_DOCS_URL),
				target: "_blank",
				rel: "noopener noreferrer",
				class: "inline p-0 text-sm/5 font-normal text-foreground underline underline-offset-4",
				onClick: _cache[0] || (_cache[0] = ($event) => emit("notice", {
					action: "learn_more_clicked",
					placement: __props.placement
				}))
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("g.learnMore")), 1)]),
				_: 1
			}, 8, ["href"])]), createVNode(Button_default, {
				type: "button",
				variant: "muted-textonly",
				size: "icon-sm",
				"aria-label": _ctx.$t("agent.dismiss"),
				class: "shrink-0",
				onClick: onDismiss
			}, {
				default: withCtx(() => [..._cache[1] || (_cache[1] = [createBaseVNode("span", { class: "icon-[lucide--x] size-5" }, null, -1)])]),
				_: 1
			}, 8, ["aria-label"])], 10, _hoisted_1$8)) : createCommentVNode("", true);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/PanelHeader.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$7 = { class: "flex h-12 shrink-0 items-center gap-2 border-b px-4" };
var _hoisted_2$7 = { class: "flex items-center gap-1" };
var _hoisted_3$4 = {
	id: "agent-panel-title",
	"data-testid": "agent-panel-title",
	class: "my-0 text-sm font-normal whitespace-nowrap"
};
var _hoisted_4$3 = { class: "ml-auto flex items-center gap-2" };
//#endregion
//#region src/workbench/extensions/agent/components/agent/PanelHeader.vue
var PanelHeader_default = /* @__PURE__ */ defineComponent({
	__name: "PanelHeader",
	props: { isMaximized: {
		type: Boolean,
		default: false
	} },
	emits: [
		"newChat",
		"startTour",
		"toggleSize",
		"close"
	],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const { t } = useI18n();
		const sizeToggleIcon = computed(() => __props.isMaximized ? "icon-[lucide--minimize-2]" : "icon-[lucide--maximize-2]");
		const sizeToggleLabel = computed(() => __props.isMaximized ? t("agent.minimize") : t("agent.maximize"));
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("header", _hoisted_1$7, [
				createBaseVNode("div", _hoisted_2$7, [createBaseVNode("h1", _hoisted_3$4, toDisplayString(unref(t)("agent.title")), 1), createVNode(Button_default, {
					tooltip: unref(t)("agent.takeTour"),
					"tooltip-side": "bottom",
					variant: "muted-textonly",
					size: "icon-sm",
					"aria-label": unref(t)("agent.takeTour"),
					class: "size-6 shrink-0",
					onClick: _cache[0] || (_cache[0] = ($event) => emit("startTour"))
				}, {
					default: withCtx(() => [..._cache[4] || (_cache[4] = [createBaseVNode("span", { class: "icon-[lucide--info] size-4" }, null, -1)])]),
					_: 1
				}, 8, ["tooltip", "aria-label"])]),
				createVNode(Badge_default, {
					variant: "pill",
					class: "border bg-transparent text-xs text-muted-foreground"
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(unref(t)("agent.beta")), 1)]),
					_: 1
				}),
				createBaseVNode("div", _hoisted_4$3, [
					createVNode(Button_default, {
						tooltip: unref(t)("agent.newChat"),
						"tooltip-side": "bottom",
						variant: "muted-textonly",
						size: "icon",
						"aria-label": unref(t)("agent.newChat"),
						onClick: _cache[1] || (_cache[1] = ($event) => emit("newChat"))
					}, {
						default: withCtx(() => [..._cache[5] || (_cache[5] = [createBaseVNode("span", { class: "icon-[lucide--plus] size-4" }, null, -1)])]),
						_: 1
					}, 8, ["tooltip", "aria-label"]),
					createVNode(Button_default, {
						tooltip: sizeToggleLabel.value,
						"tooltip-side": "bottom",
						variant: "muted-textonly",
						size: "icon",
						"aria-label": sizeToggleLabel.value,
						onClick: _cache[2] || (_cache[2] = ($event) => emit("toggleSize"))
					}, {
						default: withCtx(() => [createBaseVNode("span", { class: normalizeClass(unref(cn)(sizeToggleIcon.value, "size-4")) }, null, 2)]),
						_: 1
					}, 8, ["tooltip", "aria-label"]),
					createVNode(Button_default, {
						tooltip: unref(t)("agent.close"),
						"tooltip-side": "bottom",
						variant: "muted-textonly",
						size: "icon",
						"aria-label": unref(t)("agent.close"),
						onClick: _cache[3] || (_cache[3] = ($event) => emit("close"))
					}, {
						default: withCtx(() => [..._cache[6] || (_cache[6] = [createBaseVNode("span", { class: "icon-[lucide--x] size-4" }, null, -1)])]),
						_: 1
					}, 8, ["tooltip", "aria-label"])
				])
			]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/RunNoticeAction.vue
var RunNoticeAction_default = /* @__PURE__ */ defineComponent({
	__name: "RunNoticeAction",
	props: {
		label: {},
		name: {},
		workflowName: {},
		icon: {}
	},
	emits: ["run"],
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createBlock(Button_default, {
				type: "button",
				variant: "muted-textonly",
				size: "sm",
				"aria-label": _ctx.$t(__props.name, { workflowName: __props.workflowName }),
				onClick: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("run"))
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t(__props.label)) + " ", 1), __props.icon ? (openBlock(), createElementBlock("span", {
					key: 0,
					class: normalizeClass(__props.icon)
				}, null, 2)) : createCommentVNode("", true)]),
				_: 1
			}, 8, ["aria-label"]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/RunNoticeBanner.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$6 = ["data-testid", "aria-live"];
var _hoisted_2$6 = { class: "my-0 min-w-0 flex-1 text-sm" };
var _hoisted_3$3 = { class: "underline decoration-solid" };
//#endregion
//#region src/workbench/extensions/agent/components/agent/RunNoticeBanner.vue
var RunNoticeBanner_default = /* @__PURE__ */ defineComponent({
	__name: "RunNoticeBanner",
	props: {
		expanded: {
			type: Boolean,
			default: false
		},
		workflowName: {},
		genericNoticeReady: {
			type: Boolean,
			default: false
		},
		context: {}
	},
	emits: ["showTarget", "retry"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		const dismissed = useStorage("Comfy.AgentPanel.runNoticeDismissed", false);
		const contextMessages = {
			following: "agent.targetFollowsVisibleWorkflow",
			mismatch: "agent.viewingDifferentWorkflow",
			unavailable: "agent.targetWorkflowUnavailable",
			emptyCanvas: "agent.canvasIsEmptyAfterTurn",
			followFailed: "agent.followedChatOpenFailed"
		};
		const defaultNotice = computed(() => __props.expanded ? "agent.runNoticeExpanded" : "agent.runNotice");
		const visible = computed(() => Boolean(__props.context) || !dismissed.value && Boolean(__props.workflowName || __props.genericNoticeReady));
		const liveness = computed(() => __props.context ? "polite" : void 0);
		const contextAction = computed(() => {
			switch (__props.context) {
				case "mismatch": return {
					label: "agent.showTarget",
					name: "agent.showTargetWorkflow",
					icon: "icon-[lucide--arrow-up-right] size-4",
					run: () => emit("showTarget")
				};
				case "followFailed": return {
					label: "g.retry",
					name: "agent.retryFollowedChat",
					run: () => emit("retry")
				};
				default: return;
			}
		});
		return (_ctx, _cache) => {
			const _component_i18n_t = resolveComponent("i18n-t");
			return visible.value ? (openBlock(), createElementBlock("div", {
				key: 0,
				role: "note",
				"data-testid": __props.context ? `agent-run-notice-${__props.context}` : void 0,
				"aria-live": liveness.value,
				class: "relative flex items-start gap-2 overflow-hidden rounded-lg bg-background p-4 ring-1 ring-border/50 before:absolute before:inset-y-0 before:left-0 before:w-1 before:bg-muted"
			}, [
				_cache[2] || (_cache[2] = createBaseVNode("span", { class: "icon-[heroicons--information-circle-20-solid] size-5 shrink-0 text-muted-foreground" }, null, -1)),
				createBaseVNode("p", _hoisted_2$6, [__props.context ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [createTextVNode(toDisplayString(_ctx.$t(contextMessages[__props.context], { workflowName: __props.workflowName })) + " ", 1), contextAction.value ? (openBlock(), createBlock(RunNoticeAction_default, mergeProps({ key: 0 }, contextAction.value, {
					"workflow-name": __props.workflowName,
					onRun: contextAction.value.run
				}), null, 16, ["workflow-name", "onRun"])) : createCommentVNode("", true)], 64)) : __props.workflowName ? (openBlock(), createBlock(_component_i18n_t, {
					key: 1,
					keypath: "agent.workflowEditNotice",
					tag: "span"
				}, {
					workflow: withCtx(() => [createBaseVNode("span", _hoisted_3$3, toDisplayString(__props.workflowName), 1)]),
					_: 1
				})) : (openBlock(), createElementBlock(Fragment, { key: 2 }, [createTextVNode(toDisplayString(_ctx.$t(defaultNotice.value)), 1)], 64))]),
				!__props.context ? (openBlock(), createBlock(Button_default, {
					key: 0,
					type: "button",
					variant: "muted-textonly",
					size: "icon-sm",
					"aria-label": _ctx.$t("agent.dismiss"),
					class: "shrink-0",
					onClick: _cache[0] || (_cache[0] = ($event) => dismissed.value = true)
				}, {
					default: withCtx(() => [..._cache[1] || (_cache[1] = [createBaseVNode("span", { class: "icon-[lucide--x] size-5" }, null, -1)])]),
					_: 1
				}, 8, ["aria-label"])) : createCommentVNode("", true)
			], 8, _hoisted_1$6)) : createCommentVNode("", true);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/WorkflowSelectorChip.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$5 = ["aria-label"];
var _hoisted_2$5 = {
	key: 1,
	"data-testid": "workflow-selector-icon",
	class: "icon-[comfy--workflow] size-4 shrink-0 text-muted-foreground group-hover:text-foreground"
};
var _hoisted_3$2 = { class: "min-w-0 truncate" };
var _hoisted_4$2 = {
	key: 2,
	"data-testid": "unsaved-dot",
	class: "flex size-3.5 shrink-0 items-center justify-center"
};
var _hoisted_5$2 = ["aria-label"];
var _hoisted_6$2 = {
	key: 0,
	"aria-hidden": "true",
	class: "px-1.5 py-1 text-[11px]/4 text-muted-foreground"
};
var _hoisted_7$2 = {
	key: 0,
	role: "status",
	class: "flex size-4 shrink-0 items-center justify-center"
};
var _hoisted_8$2 = { class: "sr-only" };
var _hoisted_9$1 = ["aria-label"];
var _hoisted_10$1 = {
	key: 2,
	class: "icon-[comfy--workflow] size-4 shrink-0 text-muted-foreground"
};
var _hoisted_11 = { class: "min-w-0 truncate" };
var _hoisted_12 = ["aria-label"];
var _hoisted_13 = {
	key: 4,
	"data-testid": "unsaved-dot",
	class: "flex size-4 shrink-0 items-center justify-center"
};
var _hoisted_14 = { class: "ml-auto flex size-4 shrink-0 items-center justify-center" };
//#endregion
//#region src/workbench/extensions/agent/components/agent/composer/WorkflowSelectorChip.vue
var WorkflowSelectorChip_default = /* @__PURE__ */ defineComponent({
	__name: "WorkflowSelectorChip",
	props: {
		activeTab: {},
		tabs: {},
		visibleTabPath: { default: null },
		selectingTabPath: { default: null },
		selectTab: {
			type: Function,
			default: async () => false
		},
		detached: {
			type: Boolean,
			default: false
		},
		disabled: {
			type: Boolean,
			default: false
		}
	},
	setup(__props, { expose: __expose }) {
		const { t } = useI18n();
		const tabActivity = useWorkflowTabActivityStore();
		const conversation = useAgentConversationStore();
		const current = computed(() => __props.detached ? null : __props.activeTab);
		const workflowTooltipText = computed(() => current.value ? t("agent.changeWorkflowForChat") : t("agent.chooseWorkflowForChat"));
		const open = ref(false);
		const query = ref("");
		const searchInput = ref();
		const selectorRoot = useTemplateRef("selectorRoot");
		const composerReference = computed(() => selectorRoot.value?.parentElement?.parentElement ?? void 0);
		watch(open, async (isOpen) => {
			if (!isOpen) return;
			query.value = "";
			await nextTick();
			searchInput.value?.focus();
		});
		function openPicker() {
			if (!__props.disabled) open.value = true;
		}
		__expose({ openPicker });
		function onOpenChange(value) {
			if (__props.selectingTabPath === null) open.value = value;
		}
		async function onSelectTab(path) {
			if (__props.disabled || __props.selectingTabPath !== null) return;
			if (await __props.selectTab(path)) open.value = false;
		}
		const tabSections = computed(() => {
			const normalizedQuery = query.value.trim().toLowerCase();
			const filteredTabs = __props.tabs.filter((tab) => tab.name.toLowerCase().includes(normalizedQuery));
			const visibleTab = filteredTabs.find((tab) => tab.path === __props.visibleTabPath);
			const otherTabs = filteredTabs.filter((tab) => tab.path !== __props.visibleTabPath);
			return [{
				key: "current",
				label: t("agent.currentTab"),
				tabs: visibleTab ? [visibleTab] : []
			}, {
				key: "other",
				label: visibleTab ? t("agent.otherOpenWorkflows") : void 0,
				tabs: otherTabs
			}].filter((section) => section.tabs.length > 0);
		});
		function onSearchKeydown(event) {
			if (event.key !== "Escape") event.stopPropagation();
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				ref_key: "selectorRoot",
				ref: selectorRoot,
				class: "flex w-full items-center justify-between gap-1.5"
			}, [createVNode(unref(DropdownMenuRoot_default), {
				open: open.value,
				"onUpdate:open": onOpenChange
			}, {
				default: withCtx(() => [createVNode(unref(DropdownMenuTrigger_default), { "as-child": "" }, {
					default: withCtx(() => [createVNode(Button_default, {
						tooltip: workflowTooltipText.value,
						type: "button",
						variant: current.value ? "textonly" : "outline",
						size: "unset",
						disabled: __props.disabled,
						"aria-label": unref(t)("agent.switchWorkflow"),
						class: normalizeClass(unref(cn)("group h-7 min-w-0 justify-start gap-2 px-2.5 text-left text-xs/4 font-normal", current.value && "flex-1"))
					}, {
						default: withCtx(() => [
							unref(conversation).activeTurnTabPath === current.value?.path ? (openBlock(), createElementBlock("span", {
								key: 0,
								role: "img",
								"aria-label": unref(t)("g.agentWorking"),
								class: "icon-[lucide--loader-circle] size-4 shrink-0 text-muted-foreground motion-safe:animate-spin"
							}, null, 8, _hoisted_1$5)) : (openBlock(), createElementBlock("span", _hoisted_2$5)),
							createBaseVNode("span", _hoisted_3$2, toDisplayString(current.value?.name ?? unref(t)("agent.selectWorkflowForAgent")), 1),
							current.value?.isPersisted === false || current.value?.modified ? (openBlock(), createElementBlock("span", _hoisted_4$2, [..._cache[3] || (_cache[3] = [createBaseVNode("span", { class: "size-[7px] rounded-full bg-foreground" }, null, -1)])])) : createCommentVNode("", true)
						]),
						_: 1
					}, 8, [
						"tooltip",
						"variant",
						"disabled",
						"aria-label",
						"class"
					])]),
					_: 1
				}), (openBlock(), createBlock(unref(DropdownMenuPortal_default), { key: Number(open.value) }, {
					default: withCtx(() => [createVNode(MenuContent_default, {
						side: "top",
						align: "start",
						"side-offset": 8,
						reference: composerReference.value,
						width: "trigger",
						class: "agent-scope"
					}, {
						default: withCtx(() => [createVNode(Input_default, {
							ref_key: "searchInput",
							ref: searchInput,
							modelValue: query.value,
							"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => query.value = $event),
							disabled: __props.selectingTabPath !== null,
							type: "text",
							placeholder: unref(t)("agent.searchWorkflows"),
							class: "mb-1 h-8 bg-background px-2.5 py-1",
							onKeydown: onSearchKeydown
						}, null, 8, [
							"modelValue",
							"disabled",
							"placeholder"
						]), createVNode(unref(DropdownMenuRadioGroup_default), {
							"model-value": current.value?.path ?? "",
							class: "max-h-52 overflow-y-auto",
							"onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => typeof $event === "string" && onSelectTab($event))
						}, {
							default: withCtx(() => [(openBlock(true), createElementBlock(Fragment, null, renderList(tabSections.value, (section) => {
								return openBlock(), createElementBlock("div", {
									key: section.key,
									role: "group",
									"aria-label": section.label
								}, [section.label ? (openBlock(), createElementBlock("div", _hoisted_6$2, toDisplayString(section.label), 1)) : createCommentVNode("", true), (openBlock(true), createElementBlock(Fragment, null, renderList(section.tabs, (tab) => {
									return openBlock(), createBlock(MenuRadioItem_default, {
										key: tab.path,
										value: tab.path,
										disabled: __props.disabled || __props.selectingTabPath !== null,
										"aria-busy": __props.selectingTabPath === tab.path || void 0,
										onSelect: _cache[1] || (_cache[1] = withModifiers(() => {}, ["prevent"]))
									}, {
										default: withCtx(() => [
											__props.selectingTabPath === tab.path ? (openBlock(), createElementBlock("span", _hoisted_7$2, [_cache[4] || (_cache[4] = createBaseVNode("span", {
												class: "icon-[lucide--loader-circle] size-4 text-muted-foreground motion-safe:animate-spin",
												"aria-hidden": "true"
											}, null, -1)), createBaseVNode("span", _hoisted_8$2, toDisplayString(unref(t)("agent.savingWorkflow")), 1)])) : unref(conversation).activeTurnTabPath === tab.path ? (openBlock(), createElementBlock("span", {
												key: 1,
												role: "img",
												"aria-label": unref(t)("g.agentWorking"),
												class: "icon-[lucide--loader-circle] size-4 shrink-0 text-muted-foreground motion-safe:animate-spin"
											}, null, 8, _hoisted_9$1)) : (openBlock(), createElementBlock("span", _hoisted_10$1)),
											createBaseVNode("span", _hoisted_11, toDisplayString(tab.name), 1),
											unref(tabActivity).unseenModifiedPaths.has(tab.path) ? (openBlock(), createElementBlock("span", {
												key: 3,
												role: "img",
												"aria-label": unref(t)("g.agentModified"),
												class: "flex size-4 shrink-0 items-center justify-center"
											}, [..._cache[5] || (_cache[5] = [createBaseVNode("span", { class: "size-2 rounded-full bg-primary" }, null, -1)])], 8, _hoisted_12)) : tab.isPersisted === false || tab.modified ? (openBlock(), createElementBlock("span", _hoisted_13, [..._cache[6] || (_cache[6] = [createBaseVNode("span", { class: "size-2 rounded-full bg-foreground" }, null, -1)])])) : createCommentVNode("", true),
											createBaseVNode("span", _hoisted_14, [createVNode(unref(DropdownMenuItemIndicator_default), { class: "flex size-4 items-center justify-center" }, {
												default: withCtx(() => [..._cache[7] || (_cache[7] = [createBaseVNode("span", {
													"aria-hidden": "true",
													class: "icon-[lucide--check] size-3.5"
												}, null, -1)])]),
												_: 1
											})])
										]),
										_: 2
									}, 1032, [
										"value",
										"disabled",
										"aria-busy"
									]);
								}), 128))], 8, _hoisted_5$2);
							}), 128))]),
							_: 1
						}, 8, ["model-value"])]),
						_: 1
					}, 8, ["reference"])]),
					_: 1
				}))]),
				_: 1
			}, 8, ["open"])], 512);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/AgentPanel.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$4 = { class: "@container flex h-full flex-col overflow-hidden bg-background text-foreground" };
var _hoisted_2$4 = { class: "flex h-10 shrink-0 items-center px-2" };
var _hoisted_3$1 = ["aria-label"];
var _hoisted_4$1 = { class: "min-w-0 truncate" };
var _hoisted_5$1 = { class: "relative min-h-0 flex-1" };
var _hoisted_6$1 = ["aria-label"];
var _hoisted_7$1 = ["inert"];
var _hoisted_8$1 = {
	"data-testid": "agent-composer-stack",
	class: "mx-auto flex w-full max-w-[640px] flex-col gap-4 px-4"
};
//#endregion
//#region src/workbench/extensions/agent/components/agent/AgentPanel.vue
var AgentPanel_default = /* @__PURE__ */ defineComponent({
	__name: "AgentPanel",
	props: {
		entries: {},
		userName: {},
		streaming: {
			type: Boolean,
			default: false
		},
		submitting: {
			type: Boolean,
			default: false
		},
		canAttach: {
			type: Boolean,
			default: false
		},
		canOpenAssets: {
			type: Boolean,
			default: false
		},
		isMaximized: {
			type: Boolean,
			default: false
		},
		selectionTags: { default: () => [] },
		nodeReferenceDisabledReason: {},
		availableWorkflows: { default: () => [] },
		selectWorkflowReference: { type: Function },
		savingReference: {
			type: Boolean,
			default: false
		},
		editableWorkflowId: {},
		activeTab: { default: null },
		workflowTabs: { default: () => [] },
		visibleTabPath: { default: null },
		followsVisibleWorkflow: {
			type: Boolean,
			default: false
		},
		selectingTabPath: { default: null },
		selectTab: {
			type: Function,
			default: async () => false
		},
		workflowDetached: {
			type: Boolean,
			default: false
		},
		targetUnavailable: {
			type: Boolean,
			default: false
		},
		canvasEmptyAfterTurn: {
			type: Boolean,
			default: false
		},
		getMentionNodes: {
			type: Function,
			default: () => []
		},
		paywallPresentation: { default: () => DEFAULT_AGENT_PAYWALL_PRESENTATION },
		creditsExhausted: {
			type: Boolean,
			default: false
		},
		sessionId: { default: null },
		currentChatReady: {
			type: Boolean,
			default: false
		},
		customTitle: {},
		openingWorkflowName: {},
		historyGroups: {},
		selectHistory: {
			type: Function,
			default: async () => false
		},
		editableTurnId: { default: null },
		answeringAskIds: { default: () => /* @__PURE__ */ new Set() },
		freeUsePlacement: { default: "control" },
		starterPromptAssignment: { default: "control" },
		attributeStarterPromptExperiment: {
			type: Boolean,
			default: false
		},
		syncRetryAvailable: {
			type: Boolean,
			default: false
		}
	},
	emits: [
		"send",
		"stop",
		"attach",
		"attachFiles",
		"removeAttachment",
		"openAssets",
		"selectNodes",
		"removeTag",
		"mentionPick",
		"requestWorkflowReferences",
		"removeWorkflowReference",
		"feedback",
		"paywallAction",
		"standingPaywallShown",
		"newChat",
		"startTour",
		"toggleSize",
		"close",
		"openHistory",
		"deleteHistory",
		"copyHistory",
		"renameHistory",
		"renameChat",
		"answerAsk",
		"openWorkflow",
		"approvalShown",
		"openReferenceWorkflow",
		"showTarget",
		"freeUseNotice",
		"starterPromptRendered",
		"retrySync"
	],
	setup(__props, { expose: __expose, emit: __emit }) {
		const emit = __emit;
		const openingChat = computed(() => __props.openingWorkflowName !== void 0);
		const { ready: loadingDelayReady, start: startLoadingDelay, stop: stopLoadingDelay } = useTimeout(120, {
			controls: true,
			immediate: false
		});
		watch(openingChat, (opening) => {
			if (opening) startLoadingDelay();
			else stopLoadingDelay();
		}, {
			immediate: true,
			flush: "sync"
		});
		const showChatLoading = computed(() => openingChat.value && loadingDelayReady.value);
		const targetNotice = computed(() => {
			if (openingChat.value) return void 0;
			if (__props.canvasEmptyAfterTurn) return "emptyCanvas";
			if (__props.targetUnavailable) return "unavailable";
			if (__props.workflowDetached || __props.activeTab === null) return void 0;
			if (__props.visibleTabPath !== null && __props.visibleTabPath !== __props.activeTab.path) return "mismatch";
			return __props.followsVisibleWorkflow ? "following" : void 0;
		});
		const panelStore = useAgentPanelStore();
		const { view } = storeToRefs(panelStore);
		const showHistory = computed(() => view.value.screen === "history");
		const loadingHistoryId = computed(() => view.value.screen === "history" && view.value.selection.status === "loading" ? view.value.selection.id : null);
		const failedHistoryId = computed(() => view.value.screen === "history" && view.value.selection.status === "failed" ? view.value.selection.id : null);
		onScopeDispose(panelStore.interruptHistorySelection);
		watch([showHistory, () => __props.creditsExhausted], ([historyVisible, exhausted]) => {
			if (!historyVisible && exhausted) emit("standingPaywallShown");
		}, { immediate: true });
		function onNewChat() {
			view.value = { screen: "chat" };
			emit("newChat");
		}
		function onOpenHistory() {
			view.value = {
				screen: "history",
				previousThreadId: __props.sessionId,
				selection: { status: "idle" }
			};
			emit("openHistory");
		}
		async function openHistoryChat(id, onFailure) {
			if (view.value.screen !== "history" || loadingHistoryId.value === id) return;
			const opening = {
				...view.value,
				selection: {
					status: "loading",
					id
				}
			};
			view.value = opening;
			const isCurrent = () => view.value === opening;
			let opened = false;
			try {
				opened = await __props.selectHistory(id, isCurrent);
			} finally {
				if (isCurrent()) view.value = opened || onFailure === "leave" ? { screen: "chat" } : {
					...opening,
					selection: {
						status: "failed",
						id
					}
				};
			}
		}
		function onSelectHistory(id) {
			return openHistoryChat(id, "stay");
		}
		function onBackFromHistory() {
			if (view.value.screen !== "history") return;
			if (__props.sessionId === view.value.previousThreadId && (view.value.selection.status === "idle" || __props.currentChatReady)) view.value = { screen: "chat" };
			else if (view.value.previousThreadId === null) onNewChat();
			else openHistoryChat(view.value.previousThreadId, "leave");
		}
		function onDeleteHistory(id) {
			if (view.value.screen === "history" && (view.value.previousThreadId === id || view.value.selection.status !== "idle" && view.value.selection.id === id)) view.value = {
				...view.value,
				previousThreadId: view.value.previousThreadId === id ? null : view.value.previousThreadId,
				selection: { status: "idle" }
			};
			emit("deleteHistory", id);
		}
		const chatMenuItems = computed(() => [
			{
				label: t("g.rename"),
				icon: "icon-[lucide--pencil]",
				command: startRename
			},
			{ separator: true },
			{
				label: t("g.delete"),
				icon: "icon-[lucide--trash-2]",
				variant: "destructive",
				command: onDeleteChat
			}
		]);
		function onClose() {
			panelStore.interruptHistorySelection();
			emit("close");
		}
		const composerRef = ref();
		const runNoticeReady = ref(false);
		const { isPending: runNoticeTimerPending, start: startRunNoticeTimer } = useTimeoutFn(() => {
			runNoticeReady.value = true;
		}, 500, { immediate: false });
		const workflowSelectorRef = ref();
		function onComposerFocus() {
			if (runNoticeTimerPending.value || runNoticeReady.value) return;
			startRunNoticeTimer();
		}
		function onWorkflowTargetRequired() {
			workflowSelectorRef.value?.openPicker();
		}
		const { t } = useI18n();
		const sessionTitle = computed(() => __props.customTitle || deriveSessionTitle(__props.entries));
		const displayTitle = computed(() => sessionTitle.value || t("agent.newChatTitle"));
		const renaming = ref(false);
		const renameDraft = ref("");
		const renameInput = ref();
		const titleButton = ref();
		async function startRename() {
			renameDraft.value = sessionTitle.value ?? "";
			renaming.value = true;
			await nextTick();
			renameInput.value?.focus();
			renameInput.value?.select();
		}
		async function exitRename() {
			renaming.value = false;
			await nextTick();
			const button = titleButton.value?.$el;
			if (button instanceof HTMLButtonElement) button.focus();
		}
		function onRenameKeydown(event) {
			if (event.isComposing) return;
			if (event.key === "Enter") {
				event.preventDefault();
				commitRename();
			} else if (event.key === "Escape") {
				event.preventDefault();
				exitRename();
			}
		}
		function commitRename() {
			if (!renaming.value) return;
			exitRename();
			const title = renameDraft.value.trim();
			if (title !== "" && title !== sessionTitle.value) emit("renameChat", title);
		}
		function onDeleteChat() {
			if (__props.sessionId !== null) emit("deleteHistory", __props.sessionId);
		}
		function addAttachment(attachment) {
			return composerRef.value?.addAttachment(attachment) ?? false;
		}
		function updateAttachment(id, patch) {
			composerRef.value?.updateAttachment(id, patch);
		}
		function removeAttachment(id) {
			composerRef.value?.removeAttachment(id);
		}
		function onComposerSend(text, attachments, references) {
			if (references !== void 0) emit("send", text, attachments, references);
			else emit("send", text, attachments);
		}
		__expose({
			addAttachment,
			updateAttachment,
			removeAttachment
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("section", _hoisted_1$4, [
				createVNode(PanelHeader_default, {
					"is-maximized": __props.isMaximized,
					onNewChat,
					onStartTour: _cache[0] || (_cache[0] = ($event) => emit("startTour")),
					onToggleSize: _cache[1] || (_cache[1] = ($event) => emit("toggleSize")),
					onClose
				}, null, 8, ["is-maximized"]),
				!showHistory.value && __props.freeUsePlacement === "top-banner" ? (openBlock(), createBlock(FreeUseNotice_default, {
					key: 0,
					placement: "top-banner",
					onNotice: _cache[2] || (_cache[2] = ($event) => emit("freeUseNotice", $event))
				})) : createCommentVNode("", true),
				showHistory.value ? (openBlock(), createBlock(ChatHistoryScreen_default, {
					key: 1,
					groups: __props.historyGroups,
					"loading-id": loadingHistoryId.value,
					"failed-id": failedHistoryId.value,
					class: "min-h-0 flex-1",
					onBack: onBackFromHistory,
					onSelect: onSelectHistory,
					onDelete: onDeleteHistory,
					onCopyMarkdown: _cache[3] || (_cache[3] = ($event) => emit("copyHistory", $event)),
					onRename: _cache[4] || (_cache[4] = (id, title) => emit("renameHistory", id, title))
				}, null, 8, [
					"groups",
					"loading-id",
					"failed-id"
				])) : (openBlock(), createElementBlock(Fragment, { key: 2 }, [
					createBaseVNode("div", _hoisted_2$4, [createVNode(Button_default, {
						id: "agent-chat-history",
						tooltip: unref(t)("agent.showChatHistory"),
						"tooltip-side": "right",
						type: "button",
						variant: "muted-textonly",
						size: "icon-sm",
						"aria-label": unref(t)("agent.showChatHistory"),
						class: "size-6 shrink-0 data-coach-hover:bg-accent",
						onClick: onOpenHistory
					}, {
						default: withCtx(() => [..._cache[32] || (_cache[32] = [createBaseVNode("span", { class: "icon-[lucide--history] size-4 shrink-0" }, null, -1)])]),
						_: 1
					}, 8, ["tooltip", "aria-label"]), renaming.value ? (openBlock(), createBlock(Input_default, {
						key: 0,
						ref_key: "renameInput",
						ref: renameInput,
						modelValue: renameDraft.value,
						"onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => renameDraft.value = $event),
						type: "text",
						"aria-label": unref(t)("g.rename"),
						class: "h-6 flex-1 px-2 py-1 text-xs",
						onKeydown: onRenameKeydown,
						onBlur: commitRename
					}, null, 8, ["modelValue", "aria-label"])) : (openBlock(), createElementBlock("div", {
						key: 1,
						role: "group",
						"aria-label": unref(t)("agent.chatOptions"),
						class: "flex w-fit max-w-full min-w-0 items-center"
					}, [createVNode(Button_default, {
						ref_key: "titleButton",
						ref: titleButton,
						type: "button",
						variant: "muted-textonly",
						size: "sm",
						class: "min-w-0 justify-start text-left",
						onClick: startRename
					}, {
						default: withCtx(() => [createBaseVNode("span", _hoisted_4$1, toDisplayString(displayTitle.value), 1)]),
						_: 1
					}, 512), __props.sessionId ? (openBlock(), createBlock(Menu_default, {
						key: 0,
						items: chatMenuItems.value,
						side: "bottom",
						align: "start",
						"side-offset": 4,
						class: "agent-scope"
					}, {
						trigger: withCtx(() => [createVNode(Button_default, {
							tooltip: unref(t)("agent.chatOptions"),
							"tooltip-side": "bottom",
							variant: "muted-textonly",
							size: "icon-sm",
							"aria-label": unref(t)("agent.chatOptions"),
							class: "size-6 shrink-0"
						}, {
							default: withCtx(() => [..._cache[33] || (_cache[33] = [createBaseVNode("span", { class: "icon-[lucide--chevron-down] size-3" }, null, -1)])]),
							_: 1
						}, 8, ["tooltip", "aria-label"])]),
						_: 1
					}, 8, ["items"])) : createCommentVNode("", true)], 8, _hoisted_3$1))]),
					createBaseVNode("div", _hoisted_5$1, [!__props.entries.length ? (openBlock(), createBlock(EmptyState_default, {
						key: 0,
						"aria-busy": openingChat.value,
						inert: openingChat.value,
						"user-name": __props.userName,
						assignment: __props.starterPromptAssignment,
						"attribute-experiment": __props.attributeStarterPromptExperiment,
						onRendered: _cache[6] || (_cache[6] = ($event) => emit("starterPromptRendered", $event)),
						onInsert: _cache[7] || (_cache[7] = (text, prompt) => {
							composerRef.value?.insert(text, prompt);
						})
					}, null, 8, [
						"aria-busy",
						"inert",
						"user-name",
						"assignment",
						"attribute-experiment"
					])) : (openBlock(), createBlock(ConversationView_default, {
						key: 1,
						"aria-busy": openingChat.value,
						inert: openingChat.value,
						entries: __props.entries,
						"conversation-id": __props.sessionId,
						"editable-turn-id": __props.editableTurnId,
						"answering-ask-ids": __props.answeringAskIds,
						"paywall-presentation": __props.paywallPresentation,
						onEditPrompt: _cache[8] || (_cache[8] = ($event) => composerRef.value?.replaceDraft($event)),
						onFeedback: _cache[9] || (_cache[9] = (id, vote) => emit("feedback", id, vote)),
						onAnswerAsk: _cache[10] || (_cache[10] = (askId, selection) => emit("answerAsk", askId, selection)),
						onApprovalShown: _cache[11] || (_cache[11] = (askId, turnId, workflowId) => emit("approvalShown", askId, turnId, workflowId)),
						onOpenWorkflow: _cache[12] || (_cache[12] = (askId, workflowId, workflowName) => emit("openWorkflow", askId, workflowId, workflowName)),
						onOpenReferenceWorkflow: _cache[13] || (_cache[13] = (workflowId, workflowName) => emit("openReferenceWorkflow", workflowId, workflowName)),
						onPaywallAction: _cache[14] || (_cache[14] = ($event) => emit("paywallAction", $event, "refused_send"))
					}, null, 8, [
						"aria-busy",
						"inert",
						"entries",
						"conversation-id",
						"editable-turn-id",
						"answering-ask-ids",
						"paywall-presentation"
					])), showChatLoading.value ? (openBlock(), createElementBlock("div", {
						key: 2,
						role: "status",
						"aria-live": "polite",
						"aria-atomic": "true",
						"aria-label": unref(t)("agent.openingWorkflowChat", { workflowName: __props.openingWorkflowName }),
						class: "absolute inset-0 z-10 flex items-center justify-center gap-2 bg-background/80 px-6 text-center text-sm"
					}, [_cache[34] || (_cache[34] = createBaseVNode("span", {
						"aria-hidden": "true",
						class: "icon-[lucide--loader-circle] size-4 shrink-0 motion-safe:animate-spin"
					}, null, -1)), createTextVNode(" " + toDisplayString(unref(t)("agent.openingWorkflowChat", { workflowName: __props.openingWorkflowName })), 1)], 8, _hoisted_6$1)) : createCommentVNode("", true)]),
					renderSlot(_ctx.$slots, "instrument"),
					createBaseVNode("footer", {
						"data-testid": "agent-panel-footer",
						inert: openingChat.value,
						class: "shrink-0 py-3 inert:opacity-50"
					}, [createBaseVNode("div", _hoisted_8$1, [
						createVNode(AgentSyncRetryAlert_default, {
							visible: __props.syncRetryAvailable,
							onRetry: _cache[15] || (_cache[15] = ($event) => emit("retrySync"))
						}, null, 8, ["visible"]),
						renderSlot(_ctx.$slots, "composerNotice"),
						__props.creditsExhausted ? (openBlock(), createBlock(AgentPaywallCard_default, {
							key: 0,
							"data-testid": "agent-credits-exhausted-paywall",
							presentation: __props.paywallPresentation,
							onPaywallAction: _cache[16] || (_cache[16] = ($event) => emit("paywallAction", $event, "credits_exhausted"))
						}, null, 8, ["presentation"])) : createCommentVNode("", true),
						createVNode(RunNoticeBanner_default, {
							expanded: __props.isMaximized,
							"workflow-name": __props.workflowDetached ? void 0 : __props.activeTab?.name,
							context: targetNotice.value,
							"generic-notice-ready": runNoticeReady.value,
							onShowTarget: _cache[17] || (_cache[17] = ($event) => emit("showTarget"))
						}, null, 8, [
							"expanded",
							"workflow-name",
							"context",
							"generic-notice-ready"
						]),
						__props.freeUsePlacement === "near-composer" ? (openBlock(), createBlock(FreeUseNotice_default, {
							key: 1,
							placement: "near-composer",
							onNotice: _cache[18] || (_cache[18] = ($event) => emit("freeUseNotice", $event))
						})) : createCommentVNode("", true),
						createVNode(Composer_default, {
							ref_key: "composerRef",
							ref: composerRef,
							streaming: __props.streaming,
							submitting: __props.submitting,
							"opening-chat": openingChat.value,
							"can-attach": __props.canAttach,
							"can-open-assets": __props.canOpenAssets,
							"selection-tags": __props.selectionTags,
							"node-reference-disabled-reason": __props.nodeReferenceDisabledReason,
							"select-workflow-reference": __props.selectWorkflowReference,
							"available-workflows": __props.availableWorkflows,
							"editable-workflow-id": __props.editableWorkflowId,
							"has-workflow-target": !__props.workflowDetached,
							"workflow-selecting": __props.selectingTabPath !== null || __props.savingReference,
							"get-mention-nodes": __props.getMentionNodes,
							onFocusin: onComposerFocus,
							onSend: onComposerSend,
							onStop: _cache[21] || (_cache[21] = ($event) => emit("stop", $event)),
							onAttach: _cache[22] || (_cache[22] = ($event) => emit("attach")),
							onAttachFiles: _cache[23] || (_cache[23] = ($event) => emit("attachFiles", $event)),
							onRemoveAttachment: _cache[24] || (_cache[24] = ($event) => emit("removeAttachment", $event)),
							onOpenAssets: _cache[25] || (_cache[25] = ($event) => emit("openAssets")),
							onSelectNodes: _cache[26] || (_cache[26] = ($event) => emit("selectNodes")),
							onRemoveTag: _cache[27] || (_cache[27] = ($event) => emit("removeTag", $event)),
							onMentionPick: _cache[28] || (_cache[28] = ($event) => emit("mentionPick", $event)),
							onRequestWorkflowReferences: _cache[29] || (_cache[29] = ($event) => emit("requestWorkflowReferences")),
							onRemoveWorkflowReference: _cache[30] || (_cache[30] = ($event) => emit("removeWorkflowReference", $event)),
							onOpenReferenceWorkflow: _cache[31] || (_cache[31] = (workflowId, workflowName) => emit("openReferenceWorkflow", workflowId, workflowName)),
							onWorkflowTargetRequired
						}, {
							header: withCtx(() => [createVNode(WorkflowSelectorChip_default, {
								ref_key: "workflowSelectorRef",
								ref: workflowSelectorRef,
								"active-tab": __props.activeTab,
								tabs: __props.workflowTabs,
								"visible-tab-path": __props.visibleTabPath,
								"selecting-tab-path": __props.selectingTabPath,
								"select-tab": __props.selectTab,
								detached: __props.workflowDetached,
								disabled: __props.streaming || __props.submitting || __props.savingReference
							}, null, 8, [
								"active-tab",
								"tabs",
								"visible-tab-path",
								"selecting-tab-path",
								"select-tab",
								"detached",
								"disabled"
							])]),
							aboveInput: withCtx(() => [__props.freeUsePlacement === "above-input" ? (openBlock(), createBlock(FreeUseNotice_default, {
								key: 0,
								placement: "above-input",
								onNotice: _cache[19] || (_cache[19] = ($event) => emit("freeUseNotice", $event))
							})) : createCommentVNode("", true)]),
							insideInput: withCtx(() => [__props.freeUsePlacement === "inside-input" ? (openBlock(), createBlock(FreeUseNotice_default, {
								key: 0,
								placement: "inside-input",
								onNotice: _cache[20] || (_cache[20] = ($event) => emit("freeUseNotice", $event))
							})) : createCommentVNode("", true)]),
							_: 1
						}, 8, [
							"streaming",
							"submitting",
							"opening-chat",
							"can-attach",
							"can-open-assets",
							"selection-tags",
							"node-reference-disabled-reason",
							"select-workflow-reference",
							"available-workflows",
							"editable-workflow-id",
							"has-workflow-target",
							"workflow-selecting",
							"get-mention-nodes"
						]),
						createVNode(AgentFeedbackCaption_default)
					])], 8, _hoisted_7$1)
				], 64))
			]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/AgentCreditTransitionNotice.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$3 = {
	role: "status",
	"aria-live": "polite",
	class: "relative flex items-start gap-2 overflow-hidden rounded-lg bg-background p-4 ring-1 ring-border/50 before:absolute before:inset-y-0 before:left-0 before:w-1 before:bg-warning"
};
var _hoisted_2$3 = { class: "my-0 min-w-0 flex-1 text-sm" };
//#endregion
//#region src/workbench/extensions/agent/components/agent/AgentCreditTransitionNotice.vue
var AgentCreditTransitionNotice_default = /* @__PURE__ */ defineComponent({
	__name: "AgentCreditTransitionNotice",
	emits: ["dismiss", "shown"],
	setup(__props, { emit: __emit }) {
		const emit = __emit;
		onMounted(() => emit("shown"));
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$3, [
				_cache[2] || (_cache[2] = createBaseVNode("span", { class: "icon-[heroicons--information-circle-20-solid] size-5 shrink-0 text-warning" }, null, -1)),
				createBaseVNode("p", _hoisted_2$3, toDisplayString(_ctx.$t("agent.creditTransitionNotice")), 1),
				createVNode(Button_default, {
					type: "button",
					variant: "muted-textonly",
					size: "icon-sm",
					"aria-label": _ctx.$t("agent.dismiss"),
					class: "shrink-0",
					onClick: _cache[0] || (_cache[0] = ($event) => emit("dismiss"))
				}, {
					default: withCtx(() => [..._cache[1] || (_cache[1] = [createBaseVNode("span", { class: "icon-[lucide--x] size-5" }, null, -1)])]),
					_: 1
				}, 8, ["aria-label"])
			]);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/stores/agent/agentGraphActivityStore.ts
var SETTLE_MS = 1e3;
var useAgentGraphActivityStore = defineStore("agentGraphActivity", () => {
	const state = ref({ phase: "idle" });
	const turnOpen = ref(false);
	const currentTurnId = ref(null);
	let settleTimer;
	function startTurn(turnId = null) {
		if (turnOpen.value && currentTurnId.value === turnId) return;
		const previous = state.value;
		const resumesCurrentTurn = currentTurnId.value === turnId && (previous.phase === "settling" || previous.phase === "complete");
		turnOpen.value = true;
		currentTurnId.value = turnId;
		if (settleTimer !== void 0) clearTimeout(settleTimer);
		settleTimer = void 0;
		if (resumesCurrentTurn) {
			state.value = {
				...previous,
				phase: "running"
			};
			return;
		}
		state.value = { phase: "idle" };
	}
	function recordMaterialized(target, nodeIds, turnId) {
		if (nodeIds.length === 0) return;
		if (turnId !== void 0 && (!turnOpen.value || turnId !== currentTurnId.value)) return;
		turnOpen.value = true;
		if (settleTimer !== void 0) clearTimeout(settleTimer);
		settleTimer = void 0;
		const current = state.value;
		const previous = current.phase !== "idle" && current.workflowId === target.workflowId && current.rootGraphId === target.rootGraphId ? current.nodeIds : [];
		state.value = {
			phase: "running",
			...target,
			nodeIds: [.../* @__PURE__ */ new Set([...previous, ...nodeIds])]
		};
	}
	function finishTurn() {
		turnOpen.value = false;
		if (state.value.phase !== "running") return;
		if (settleTimer !== void 0) clearTimeout(settleTimer);
		state.value = {
			...state.value,
			phase: "settling"
		};
		settleTimer = setTimeout(() => {
			settleTimer = void 0;
			if (state.value.phase !== "settling") return;
			state.value = {
				...state.value,
				phase: "complete"
			};
		}, SETTLE_MS);
	}
	function removeNodes(nodeIds) {
		if (state.value.phase === "idle" || nodeIds.length === 0) return;
		const removed = new Set(nodeIds);
		const remaining = state.value.nodeIds.filter((id) => !removed.has(id));
		state.value = remaining.length === 0 ? { phase: "idle" } : {
			...state.value,
			nodeIds: remaining
		};
	}
	function dismiss() {
		if (settleTimer !== void 0) clearTimeout(settleTimer);
		settleTimer = void 0;
		currentTurnId.value = null;
		state.value = { phase: "idle" };
	}
	function resetWorkflow(workflowId) {
		if (state.value.phase !== "idle" && state.value.workflowId === workflowId) dismiss();
	}
	return {
		state,
		startTurn,
		recordMaterialized,
		finishTurn,
		removeNodes,
		dismiss,
		resetWorkflow
	};
});
//#endregion
//#region src/workbench/extensions/agent/components/AgentGraphActivityBar.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$2 = {
	key: 0,
	class: "pointer-events-none absolute inset-x-2 bottom-8 z-1100 flex justify-center"
};
var _hoisted_2$2 = { class: "flex min-w-0 items-center gap-1" };
//#endregion
//#region src/workbench/extensions/agent/components/AgentGraphActivityBar.vue
var AgentGraphActivityBar_default = /* @__PURE__ */ defineComponent({
	__name: "AgentGraphActivityBar",
	props: { canvas: {} },
	setup(__props) {
		const { t } = useI18n();
		const activity = useAgentGraphActivityStore();
		const teleportTarget = ref(null);
		onMounted(() => {
			teleportTarget.value = document.querySelector(".graph-canvas-panel");
		});
		const visibleState = computed(() => {
			const state = activity.state;
			if (state.phase === "idle" || !__props.canvas?.graph || String(__props.canvas.graph.id) !== state.rootGraphId) return null;
			return state;
		});
		const isComplete = computed(() => visibleState.value?.phase === "complete");
		const presentation = computed(() => ({
			testId: isComplete.value ? "agent-graph-added-toast" : "agent-graph-activity-bar",
			accent: isComplete.value ? "border-l-success" : "border-l-foreground",
			iconClass: isComplete.value ? "icon-[lucide--check] text-success" : "icon-[lucide--loader-circle] text-muted-foreground motion-safe:animate-spin",
			title: isComplete.value ? t("agent.nodesAdded", visibleState.value?.nodeIds.length ?? 0) : t("agent.updatingGraph")
		}));
		const liveNodes = computed(() => {
			const state = visibleState.value;
			if (!state || !__props.canvas) return [];
			return state.nodeIds.flatMap((nodeId) => {
				const locator = createNodeLocatorId(null, nodeId);
				const node = getNodeByLocatorId(app.rootGraph, locator);
				return locator && node?.graph === __props.canvas.graph ? [node] : [];
			});
		});
		function viewNodes() {
			const panel = document.querySelector(".graph-canvas-panel");
			if (!__props.canvas || !panel) return;
			const bounds = createPositionBounds(liveNodes.value, 40);
			if (!bounds) return;
			const canvasRect = __props.canvas.canvas.getBoundingClientRect();
			const panelRect = panel.getBoundingClientRect();
			__props.canvas.animateToBounds(bounds, { viewport: [
				panelRect.left - canvasRect.left,
				panelRect.top - canvasRect.top,
				panelRect.width,
				panelRect.height
			] });
		}
		return (_ctx, _cache) => {
			return teleportTarget.value ? (openBlock(), createBlock(Teleport, {
				key: 0,
				to: teleportTarget.value
			}, [visibleState.value ? (openBlock(), createElementBlock("div", _hoisted_1$2, [createVNode(CanvasBanner_default, {
				"data-testid": presentation.value.testId,
				role: "status",
				accent: presentation.value.accent,
				class: "max-w-full flex-wrap gap-3"
			}, createSlots({
				icon: withCtx(() => [createBaseVNode("i", {
					class: normalizeClass([presentation.value.iconClass, "size-4 shrink-0"]),
					"aria-hidden": "true"
				}, null, 2)]),
				title: withCtx(() => [createTextVNode(toDisplayString(presentation.value.title), 1)]),
				actions: withCtx(() => [createBaseVNode("div", _hoisted_2$2, [liveNodes.value.length > 0 ? (openBlock(), createBlock(Button_default, {
					key: 0,
					variant: "secondary",
					size: "sm",
					onClick: viewNodes
				}, {
					default: withCtx(() => [createTextVNode(toDisplayString(unref(t)("agent.viewAddedNodes", liveNodes.value.length)), 1)]),
					_: 1
				})) : createCommentVNode("", true), isComplete.value ? (openBlock(), createBlock(Button_default, {
					key: 1,
					variant: "muted-textonly",
					size: "icon",
					class: "shrink-0",
					"aria-label": unref(t)("agent.close"),
					onClick: _cache[0] || (_cache[0] = ($event) => unref(activity).dismiss())
				}, {
					default: withCtx(() => [..._cache[1] || (_cache[1] = [createBaseVNode("i", {
						class: "icon-[lucide--x] size-4",
						"aria-hidden": "true"
					}, null, -1)])]),
					_: 1
				}, 8, ["aria-label"])) : createCommentVNode("", true)])]),
				_: 2
			}, [!isComplete.value ? {
				name: "description",
				fn: withCtx(() => [createTextVNode(toDisplayString(unref(t)("agent.editWhileWorking")), 1)]),
				key: "0"
			} : void 0]), 1032, ["data-testid", "accent"])])) : createCommentVNode("", true)], 8, ["to"])) : createCommentVNode("", true);
		};
	}
});
//#endregion
//#region src/workbench/extensions/agent/components/agent/OnboardingCoach.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$1 = {
	key: 0,
	class: "agent-scope fixed inset-0 z-tour"
};
var _hoisted_2$1 = { class: "rounded-md border bg-background px-3 py-2 text-xs/tight wrap-break-word whitespace-pre-line text-foreground shadow-md" };
var _hoisted_3 = ["aria-labelledby", "aria-describedby"];
var _hoisted_4 = { class: "flex flex-col gap-6" };
var _hoisted_5 = { class: "flex flex-col gap-2" };
var _hoisted_6 = { class: "m-0 text-xs/normal opacity-50" };
var _hoisted_7 = ["id"];
var _hoisted_8 = ["id"];
var _hoisted_9 = ["id"];
var _hoisted_10 = { class: "flex justify-end gap-3" };
/** Long enough for any panel layout to settle; a target still absent is a regression. */
var TARGET_MISSING_AFTER_MS = 8e3;
var COACH_HOVER_ATTRIBUTE = "data-coach-hover";
//#endregion
//#region src/workbench/extensions/agent/components/agent/OnboardingCoach.vue
var OnboardingCoach_default = /* @__PURE__ */ defineComponent({
	__name: "OnboardingCoach",
	props: {
		steps: {},
		storageKey: {},
		holdNotice: {}
	},
	emits: ["finished", "stalled"],
	setup(__props, { expose: __expose, emit: __emit }) {
		const emit = __emit;
		const { active, index, step, isLast, next, previous, finish, restart } = useOnboarding(() => __props.steps, __props.storageKey);
		let reportedShown = false;
		__expose({ restart: () => {
			reportedShown = false;
			restart();
		} });
		const titleId = useId();
		const bodyId = useId();
		const holdNoticeId = useId();
		const target = ref(null);
		const visible = computed(() => active.value && target.value !== null);
		useOnboardingOverlayStore().registerSource(() => visible.value);
		const toolbar = ref(null);
		const card = ref(null);
		const tooltip = ref(null);
		const bounds = useElementBounding(target);
		const toolbarBounds = useElementBounding(toolbar);
		const tooltipBounds = useElementBounding(tooltip);
		const { width, height } = useWindowSize();
		let targetRetryTimer;
		function scheduleTargetRetry() {
			clearTimeout(targetRetryTimer);
			if (!active.value || target.value) return;
			targetRetryTimer = setTimeout(() => {
				resolveTargets();
				scheduleTargetRetry();
			}, 50);
		}
		function resolveTargets() {
			const nextTarget = active.value ? document.querySelector(step.value.target) : null;
			const nextToolbar = active.value && step.value.toolbarTarget ? document.querySelector(step.value.toolbarTarget) : null;
			if (target.value !== nextTarget) target.value = nextTarget;
			if (toolbar.value !== nextToolbar) toolbar.value = nextToolbar;
			bounds.update();
			toolbarBounds.update();
			scheduleTargetRetry();
		}
		watch(visible, (isVisible) => {
			if (!isVisible || reportedShown) return;
			reportedShown = true;
			useTelemetry()?.trackAgentOnboardingShown();
		});
		function reportStep(action) {
			useTelemetry()?.trackAgentOnboardingStep({
				step: index.value + 1,
				action
			});
		}
		function onNext() {
			const finished = isLast.value;
			reportStep(isLast.value ? "finish" : "next");
			next();
			if (finished) emit("finished");
		}
		function onSkip() {
			reportStep("skip");
			finish();
			emit("finished");
		}
		const targetObserver = new MutationObserver(resolveTargets);
		targetObserver.observe(document.body, {
			childList: true,
			subtree: true
		});
		let reportedStalled = false;
		const missingTarget = computed(() => active.value && !target.value ? step.value.target : null);
		const { start: startMissingTargetTimer, stop: stopMissingTargetTimer } = useTimeoutFn((selector, step) => {
			reportMissingCoachTarget(selector, step);
			if (reportedStalled) return;
			reportedStalled = true;
			emit("stalled");
		}, TARGET_MISSING_AFTER_MS, { immediate: false });
		watch(missingTarget, (selector) => {
			stopMissingTargetTimer();
			if (selector) startMissingTargetTimer(selector, index.value + 1);
		}, { immediate: true });
		onBeforeUnmount(() => {
			targetObserver.disconnect();
			clearTimeout(targetRetryTimer);
		});
		watch([target, () => step.value?.tooltip], ([element, text], _, onCleanup) => {
			if (!element || !text) return;
			element.setAttribute(COACH_HOVER_ATTRIBUTE, "");
			onCleanup(() => element.removeAttribute(COACH_HOVER_ATTRIBUTE));
		});
		const tooltipStyle = computed(() => ({
			left: `${bounds.right.value}px`,
			top: `${bounds.top.value + bounds.height.value / 2}px`
		}));
		watch([active, step], async () => {
			await nextTick();
			resolveTargets();
		}, {
			immediate: true,
			flush: "post"
		});
		const middleware = computed(() => {
			const result = [offset({
				mainAxis: 16,
				crossAxis: step.value?.placement === "left-start" ? -16 : 0
			})];
			if (step.value?.placement === "graph-bottom") {
				const bottom = toolbar.value ? toolbarBounds.top.value : bounds.bottom.value;
				result.push({
					name: "graphBottom",
					fn: ({ rects }) => ({
						x: rects.reference.x + (rects.reference.width - rects.floating.width) / 2,
						y: Math.min(bottom, rects.reference.y + rects.reference.height) - 16 - rects.floating.height
					})
				});
			}
			return [...result, shift({
				padding: 8,
				crossAxis: true
			})];
		});
		const { floatingStyles, isPositioned } = useFloating(target, card, {
			strategy: "fixed",
			transform: false,
			placement: () => step.value?.placement === "left-center" ? "left" : step.value?.placement === "left-end" ? "left-end" : "left-start",
			middleware,
			whileElementsMounted: autoUpdate
		});
		const spotlightStyle = computed(() => {
			const targetRect = new DOMRect(bounds.left.value, bounds.top.value, bounds.width.value, bounds.height.value);
			const hasTooltip = tooltipBounds.width.value > 0;
			return clampSpotlight(hasTooltip ? unionRect(targetRect, new DOMRect(tooltipBounds.left.value, tooltipBounds.top.value, tooltipBounds.width.value, tooltipBounds.height.value)) : targetRect, hasTooltip ? 4 : 0, {
				width: width.value,
				height: height.value
			});
		});
		useEventListener(document, "keydown", (event) => {
			if (!active.value || !target.value || event.key !== "Escape") return;
			event.preventDefault();
			event.stopPropagation();
			onSkip();
		}, { capture: true });
		return (_ctx, _cache) => {
			return openBlock(), createBlock(Teleport, { to: "body" }, [visible.value ? (openBlock(), createElementBlock("div", _hoisted_1$1, [
				_cache[1] || (_cache[1] = createBaseVNode("div", { class: "absolute inset-0" }, null, -1)),
				createBaseVNode("div", {
					"aria-hidden": "true",
					"data-testid": "agent-coach-spotlight",
					style: normalizeStyle({ ...spotlightStyle.value }),
					class: "pointer-events-none absolute rounded-lg border-2 border-foreground shadow-[0_0_0_9999px_color-mix(in_srgb,var(--color-black)_60%,transparent)]"
				}, null, 4),
				unref(step).tooltip ? (openBlock(), createElementBlock("div", {
					key: 0,
					ref_key: "tooltip",
					ref: tooltip,
					role: "tooltip",
					style: normalizeStyle(tooltipStyle.value),
					class: "pointer-events-none absolute flex max-w-50 -translate-y-1/2 items-center"
				}, [_cache[0] || (_cache[0] = createBaseVNode("span", {
					"aria-hidden": "true",
					class: "size-0 border-y-4 border-r-4 border-y-transparent border-r-border"
				}, null, -1)), createBaseVNode("div", _hoisted_2$1, toDisplayString(unref(step).tooltip), 1)], 4)) : createCommentVNode("", true),
				createVNode(unref(FocusScope_default), {
					"as-child": "",
					trapped: "",
					loop: ""
				}, {
					default: withCtx(() => [createBaseVNode("div", {
						ref_key: "card",
						ref: card,
						role: "dialog",
						"aria-modal": "true",
						"aria-labelledby": unref(titleId),
						"aria-describedby": __props.holdNotice ? `${unref(bodyId)} ${unref(holdNoticeId)}` : unref(bodyId),
						tabindex: "-1",
						style: normalizeStyle({
							...unref(floatingStyles),
							opacity: unref(isPositioned) ? 1 : 0
						}),
						class: normalizeClass(unref(cn)("fixed box-border flex max-h-[calc(100vh-16px)] w-[307px] max-w-[calc(100vw-16px)] flex-col gap-3 overflow-y-auto rounded-2xl border bg-background p-4 text-foreground shadow-lg", unref(index) < 2 ? "border-secondary" : "border-smoke-500/20"))
					}, [createBaseVNode("div", _hoisted_4, [createBaseVNode("div", _hoisted_5, [
						createBaseVNode("p", _hoisted_6, toDisplayString(_ctx.$t("agent.coachProgress", {
							current: unref(index) + 1,
							total: __props.steps.length
						})), 1),
						createBaseVNode("h3", {
							id: unref(titleId),
							class: "m-0 text-base/normal font-semibold text-pretty"
						}, toDisplayString(unref(step).title), 9, _hoisted_7),
						createBaseVNode("p", {
							id: unref(bodyId),
							class: "m-0 text-sm/normal text-pretty text-muted-foreground"
						}, toDisplayString(unref(step).body), 9, _hoisted_8),
						__props.holdNotice ? (openBlock(), createElementBlock("p", {
							key: 0,
							id: unref(holdNoticeId),
							class: "m-0 text-xs/normal text-muted-foreground",
							"data-testid": "agent-coach-hold-notice"
						}, toDisplayString(__props.holdNotice), 9, _hoisted_9)) : createCommentVNode("", true)
					]), createBaseVNode("div", _hoisted_10, [
						unref(index) > 0 ? (openBlock(), createBlock(Button_default, {
							key: 0,
							variant: "textonly",
							size: "md",
							class: "mr-auto",
							onClick: unref(previous)
						}, {
							default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("onboardingCoachmarks.back")), 1)]),
							_: 1
						}, 8, ["onClick"])) : createCommentVNode("", true),
						createVNode(Button_default, {
							variant: "secondary",
							size: "md",
							onClick: onSkip
						}, {
							default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t("agent.skip")), 1)]),
							_: 1
						}),
						createVNode(Button_default, {
							variant: "inverted",
							size: "md",
							onClick: onNext
						}, {
							default: withCtx(() => [createTextVNode(toDisplayString(_ctx.$t(unref(isLast) ? "onboardingCoachmarks.done" : "g.next")), 1)]),
							_: 1
						})
					])])], 14, _hoisted_3)]),
					_: 1
				})
			])) : createCommentVNode("", true)]);
		};
	}
});
var UPLOAD_HANDSHAKE_TIMEOUT_MS = 3e4;
var UPLOAD_FLOOR_BYTES_PER_SECOND = 65536;
var DEFERRED_FETCH_TIMEOUT_MS = 6e4;
var MAX_CONCURRENT_UPLOADS = 3;
var MAX_TELEMETRY_FILE_TYPE_LENGTH = 128;
var MIME_TYPE_PATTERN = /^[!#$%&'*+\-.^_`|~0-9A-Za-z]+\/[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/;
function uploadDeadlineMs(file) {
	return UPLOAD_HANDSHAKE_TIMEOUT_MS + file.size / UPLOAD_FLOOR_BYTES_PER_SECOND * 1e3;
}
function telemetryFileType(type) {
	if (!type || type.length > MAX_TELEMETRY_FILE_TYPE_LENGTH) return "unknown";
	return MIME_TYPE_PATTERN.test(type) ? type : "unknown";
}
var stagedCount = 0;
function fileUploadKey(file) {
	return `${file.name}:${file.size}:${file.lastModified}`;
}
function fileSourceKey(file) {
	return `file:${JSON.stringify([
		file.name,
		file.size,
		file.lastModified,
		file.type
	])}`;
}
async function fileContentHash(file) {
	const digest = await crypto.subtle.digest("SHA-256", await file.arrayBuffer());
	return Array.from(new Uint8Array(digest)).map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
function attachmentMediaKind(file) {
	if (hasImageType(file) || isHdrImageFilename(file.name)) return "image";
	if (hasVideoType(file)) return "video";
	if (hasAudioType(file)) return "audio";
	return getMediaTypeFromFilename(file.name);
}
function localPreview(file, kind) {
	if (isHdrImageFilename(file.name)) return {};
	const playable = kind === "video" || kind === "audio";
	const url = kind === "image" || playable ? URL.createObjectURL(file) : void 0;
	return {
		previewUrl: kind === "image" ? url : void 0,
		mediaUrl: playable ? url : void 0
	};
}
function uploadedPreview(kind, url) {
	if (!url) return {};
	if (kind === "audio" || kind === "video") return { mediaUrl: url };
	if (kind === "image") return { previewUrl: url };
	return {};
}
function useAttachment(options) {
	const pending = /* @__PURE__ */ new Set();
	const inFlight = /* @__PURE__ */ new Map();
	const cancelled = /* @__PURE__ */ new Set();
	const waiting = [];
	const uploaded = /* @__PURE__ */ new Map();
	const contentHashes = /* @__PURE__ */ new WeakMap();
	let uploadGeneration = 0;
	let activeUploads = 0;
	function contentHashFor(file) {
		const cached = contentHashes.get(file);
		if (cached) return cached;
		const hash = fileContentHash(file);
		contentHashes.set(file, hash);
		return hash;
	}
	function stage(name, sourceKey) {
		const id = `upload-${++stagedCount}:${name}`;
		if (!options.stage({
			id,
			name,
			ref: "",
			uploading: true,
			sourceKey
		})) return void 0;
		pending.add(id);
		return id;
	}
	function stageUnsupported(name, sourceKey) {
		const id = `upload-${++stagedCount}:${name}`;
		return options.stage({
			id,
			name,
			ref: "",
			sourceKey,
			validationError: "unsupported-type"
		}) ? id : void 0;
	}
	function admit(sourceKey) {
		const staged = options.staged();
		if (staged.length < 25) return "admitted";
		return sourceKey && staged.some((item) => item.sourceKey === sourceKey) ? "duplicate" : "too_many";
	}
	function reportAdmission(name, admission) {
		if (admission === "duplicate") options.onDuplicate?.([name]);
		if (admission === "too_many") reportTurnLimit();
	}
	function settle(id) {
		pending.delete(id);
		inFlight.delete(id);
		cancelled.delete(id);
	}
	function isTooLarge(file) {
		const maxBytes = options.maxBytes?.(file) ?? 20971520;
		if (file.size <= maxBytes) return false;
		options.onError?.(i18n.global.t("agent.attachmentTooLarge", {
			name: file.name,
			limit: formatSize(maxBytes)
		}));
		return true;
	}
	function uploadFailureCause(cause) {
		if (cause instanceof AgentApiError) return `http_${cause.status}`;
		if (cause instanceof AgentResponseUnreadableError) return "unreadable_response";
		if (cause instanceof TimeoutError) return "timeout";
		if (cause instanceof DOMException && cause.name === "AbortError") return "aborted";
		return "unknown";
	}
	function reportTurnLimit() {
		options.onError?.(i18n.global.t("agent.attachmentCountExceeded", { count: 25 }));
	}
	function failAttachment(id, file, errorType, cause, notify = true) {
		return () => {
			reportError(/* @__PURE__ */ new Error("Agent attachment upload failed"), {
				surface: "agent",
				errorType,
				tags: {
					failure_kind: "caught_unexpected",
					feature_area: "agent",
					operation: "save",
					outcome: "failed",
					integration_target: "assets",
					feature_flag: "agent_panel",
					feature_flag_state: "enabled",
					project_context: "agent_composer",
					upload_failure_cause: uploadFailureCause(cause),
					file_type: telemetryFileType(file.type),
					file_size_bytes: file.size ?? -1
				}
			});
			if (notify) options.onError?.(i18n.global.t("agent.attachmentUploadFailed", { name: file.name }));
			options.remove(id);
		};
	}
	async function resolveUpload(id, file) {
		const key = fileUploadKey(file);
		const contentHash = contentHashFor(file);
		if (uploaded.has(key)) {
			const hash = await contentHash;
			const cachedResult = uploaded.get(key)?.get(hash);
			if (cancelled.has(id)) throw new DOMException("Aborted", "AbortError");
			if (cachedResult) return cachedResult;
		}
		const generation = uploadGeneration;
		const controller = new AbortController();
		const deadline = new AbortController();
		inFlight.set(id, controller);
		const result = await withTimeout(() => options.upload(file, controller.signal), options.uploadTimeoutMs ?? uploadDeadlineMs(file), { signal: deadline.signal }).catch((error) => {
			if (error instanceof TimeoutError) controller.abort();
			throw error;
		}).finally(() => deadline.abort());
		const hash = await contentHash;
		if (cancelled.has(id)) throw new DOMException("Aborted", "AbortError");
		if (generation === uploadGeneration) {
			const cachedResults = uploaded.get(key) ?? /* @__PURE__ */ new Map();
			cachedResults.set(hash, result);
			uploaded.set(key, cachedResults);
		}
		return result;
	}
	function forgetUploads() {
		uploaded.clear();
		uploadGeneration += 1;
	}
	async function uploadStagedFile(id, file) {
		if (activeUploads === MAX_CONCURRENT_UPLOADS) await new Promise((resolve) => waiting.push(resolve));
		else activeUploads += 1;
		try {
			if (cancelled.has(id)) return "cancelled";
			if (options.validate) {
				const valid = await options.validate(file);
				if (cancelled.has(id)) return "cancelled";
				if (!valid) {
					options.update(id, {
						name: file.name,
						uploading: false,
						validationError: "invalid-video"
					});
					return "failed";
				}
			}
			const mediaKind = attachmentMediaKind(file);
			options.update(id, {
				name: file.name,
				mediaKind,
				...localPreview(file, mediaKind)
			});
			const result = await resolveUpload(id, file);
			options.update(id, {
				ref: result.ref,
				...uploadedPreview(mediaKind, result.url),
				uploading: false
			});
			showStoredPreview(id, file, result.ref);
			return "uploaded";
		} catch (cause) {
			if (cancelled.has(id)) return "cancelled";
			failAttachment(id, file, "agent_attachment_upload_failed", cause)();
			return "failed";
		} finally {
			settle(id);
			const next = waiting.shift();
			if (next) next();
			else activeUploads -= 1;
		}
	}
	async function showStoredPreview(id, file, ref) {
		if (!options.resolveStoredPreview) return;
		const previewUrl = await options.resolveStoredPreview(file, ref).catch(() => void 0);
		if (previewUrl) options.update(id, { previewUrl });
	}
	function cancelUpload(id) {
		if (!pending.has(id)) return;
		cancelled.add(id);
		options.remove(id);
		inFlight.get(id)?.abort();
	}
	function cancelAllUploads() {
		for (const id of Array.from(pending)) cancelUpload(id);
	}
	async function uploadDeferredFile(id, name, resolve) {
		const controller = new AbortController();
		const deadline = new AbortController();
		inFlight.set(id, controller);
		try {
			const file = await withTimeout(() => resolve(controller.signal), DEFERRED_FETCH_TIMEOUT_MS, { signal: deadline.signal }).catch((error) => {
				if (error instanceof TimeoutError) controller.abort();
				throw error;
			}).finally(() => deadline.abort());
			if (cancelled.has(id)) return "cancelled";
			if (!file) {
				options.remove(id);
				return "fetch_failed";
			}
			if (!isAgentAttachable(file)) {
				options.update(id, {
					name: file.name,
					uploading: false,
					validationError: "unsupported-type"
				});
				return "unsupported";
			}
			if (isTooLarge(file)) {
				options.remove(id);
				return "failed";
			}
			const result = await uploadStagedFile(id, file);
			if (result === "uploaded") options.onUploaded?.();
			return result;
		} catch (cause) {
			if (cancelled.has(id)) return "cancelled";
			failAttachment(id, { name }, "agent_attachment_fetch_failed", cause, false)();
			return "fetch_failed";
		} finally {
			settle(id);
		}
	}
	async function addDeferredFile(name, resolve, sourceKey) {
		const admission = admit(sourceKey);
		if (admission !== "admitted") {
			reportAdmission(name, admission);
			return admission;
		}
		const id = stage(name, sourceKey);
		if (!id) {
			options.onDuplicate?.([name]);
			return "duplicate";
		}
		return uploadDeferredFile(id, name, resolve);
	}
	function addUnsupportedAsset(name, sourceKey) {
		const admission = admit(sourceKey);
		if (admission !== "admitted") {
			reportAdmission(name, admission);
			return admission;
		}
		if (stageUnsupported(name, sourceKey)) return "unsupported";
		options.onDuplicate?.([name]);
		return "duplicate";
	}
	function stageFile(file) {
		const supported = isAgentAttachable(file);
		if (supported && isTooLarge(file)) return {
			file,
			outcome: "skipped"
		};
		const sourceKey = fileSourceKey(file);
		const admission = admit(sourceKey);
		if (admission !== "admitted") return {
			file,
			outcome: admission
		};
		if (!supported) return {
			file,
			outcome: stageUnsupported(file.name, sourceKey) ? "staged" : "duplicate"
		};
		const id = stage(file.name, sourceKey);
		return id ? {
			file,
			outcome: "upload",
			id
		} : {
			file,
			outcome: "duplicate"
		};
	}
	async function addFiles(files) {
		const staged = Array.from(files, stageFile);
		const duplicates = staged.flatMap(({ file, outcome }) => outcome === "duplicate" ? [file.name] : []);
		if (duplicates.length) options.onDuplicate?.(duplicates);
		if (staged.some(({ outcome }) => outcome === "too_many")) reportTurnLimit();
		let uploaded = 0;
		await Promise.all(staged.map(async (item) => {
			if (item.outcome !== "upload") return;
			if (await uploadStagedFile(item.id, item.file) === "uploaded") uploaded += 1;
		}));
		if (uploaded > 0) options.onUploaded?.();
		return uploaded > 0;
	}
	return {
		addDeferredFile,
		addFiles,
		addUnsupportedAsset,
		cancelUpload,
		cancelAllUploads,
		forgetUploads
	};
}
//#endregion
//#region src/workbench/extensions/agent/composables/agent/useAgentWorkflowResolver.ts
function useAgentWorkflowResolver({ workflows, bindings, listCloudWorkflows, getCloudWorkflow }) {
	const cloudIndex = ref([]);
	const listedCloudIds = ref(/* @__PURE__ */ new Set());
	const listingComplete = ref(false);
	let refreshGeneration = 0;
	const cloudIdsByName = computed(() => {
		const counts = /* @__PURE__ */ new Map();
		for (const { name } of cloudIndex.value) counts.set(name, (counts.get(name) ?? 0) + 1);
		return new Map(cloudIndex.value.flatMap(({ id, name }) => counts.get(name) === 1 ? [[name, id]] : []));
	});
	async function refreshCloudWorkflowIds() {
		const generation = ++refreshGeneration;
		try {
			const { entries, complete } = await listCloudWorkflows();
			if (generation !== refreshGeneration) return false;
			listedCloudIds.value = new Set(entries.map(({ id }) => id));
			listingComplete.value = complete;
			cloudIndex.value = entries.flatMap(({ id, name }) => name === void 0 ? [] : [{
				id,
				name
			}]);
			return true;
		} catch (error) {
			if (generation !== refreshGeneration) return false;
			reportError(error, {
				surface: "agent",
				errorType: "agent_cloud_workflow_ids_refresh_failed"
			});
			return false;
		}
	}
	/**
	* Drops a workflow the server has refused. `cloudIdFor` reads this index
	* ahead of the binding store, and `refreshCloudWorkflowIds` both swallows
	* its errors and races a timeout, so a stale entry would keep handing the
	* refused id back to the next turn however often the binding is released.
	*/
	function forgetCloudWorkflowId(workflowId) {
		cloudIndex.value = cloudIndex.value.filter(({ id }) => id !== workflowId);
	}
	function cloudWorkflowName(workflow) {
		return workflow.suffix === "app.json" ? `${workflow.filename}.app` : workflow.filename;
	}
	function savedMatches(name, candidates) {
		return candidates.filter((workflow) => !workflow.isTemporary && cloudWorkflowName(workflow) === name);
	}
	function cloudIdFor(workflow) {
		const name = cloudWorkflowName(workflow);
		const saved = !workflow.isTemporary && savedMatches(name, workflows.openWorkflows).length === 1 ? cloudIdsByName.value.get(name) : void 0;
		if (saved !== void 0) return saved;
		const bound = bindings.workflowIdFor(workflow.path);
		return bound !== void 0 && bindings.matchesWorkflow(bound, workflow) ? bound : void 0;
	}
	function indexedNameFor(workflowId) {
		return cloudIndex.value.find(({ id }) => id === workflowId)?.name;
	}
	/**
	* A persisted binding is stale when the cloud index says `workflowId` is
	* a different saved workflow than the tab it points at, and the tab's own
	* name resolves to another cloud id. Applying mutations through such a
	* binding would write one workflow's edits into another workflow's graph.
	*/
	function bindingIsStale(workflowId, bound) {
		if (bound.isTemporary) return false;
		const indexedName = indexedNameFor(workflowId);
		const boundName = cloudWorkflowName(bound);
		if (indexedName === void 0 || indexedName === boundName) return false;
		const boundId = cloudIndex.value.find(({ name }) => name === boundName)?.id;
		return boundId !== void 0 && boundId !== workflowId;
	}
	function resolveWorkflow(workflowId, nameCandidates) {
		const path = bindings.tabPathFor(workflowId);
		const bound = path === void 0 ? null : workflows.getWorkflowByPath(path);
		if (bound && bindings.matchesWorkflow(workflowId, bound)) {
			if (!bindingIsStale(workflowId, bound)) return bound;
			bindings.unbind(bound.path);
		}
		for (const [name, id] of cloudIdsByName.value) {
			if (id !== workflowId) continue;
			const matches = savedMatches(name, nameCandidates);
			return matches.length === 1 ? matches[0] : null;
		}
		return null;
	}
	function boundOrOpenWorkflowFor(workflowId) {
		return resolveWorkflow(workflowId, workflows.openWorkflows);
	}
	function cachedOpenWorkflowFor(workflowId) {
		if (indexedNameFor(workflowId) === void 0) return null;
		const target = boundOrOpenWorkflowFor(workflowId);
		return target !== null && workflows.openWorkflows.includes(target) ? target : null;
	}
	function cloudListingOmits(workflowId) {
		return listingComplete.value && !listedCloudIds.value.has(workflowId);
	}
	/**
	* Only a 404 proves deletion. A 403 can come from auth middleware for reasons
	* unrelated to the workflow, so it stays `unknown` like every other failure.
	*/
	async function cloudWorkflowLifecycle(workflowId) {
		try {
			await getCloudWorkflow(workflowId);
			return "live";
		} catch (error) {
			if (error instanceof AgentApiError && error.status === 404) return "gone";
			reportError(error, {
				surface: "agent",
				errorType: "failure_reading_agent_cloud_workflow"
			});
			return "unknown";
		}
	}
	function storedWorkflowFor(workflowId) {
		return resolveWorkflow(workflowId, workflows.workflows);
	}
	function openWorkflowFor(workflowId) {
		return workflows.openWorkflows.find((workflow) => cloudIdFor(workflow) === workflowId) ?? null;
	}
	const availableWorkflowReferences = computed(() => {
		const seenIds = /* @__PURE__ */ new Set();
		const open = [];
		for (const workflow of workflows.openWorkflows) {
			const id = cloudIdFor(workflow);
			const name = cloudWorkflowName(workflow);
			if (id !== void 0) {
				if (seenIds.has(id)) continue;
				seenIds.add(id);
				open.push({
					id,
					name
				});
			} else if (workflow.isTemporary) open.push({
				tabPath: workflow.path,
				name
			});
		}
		const saved = cloudIndex.value.filter(({ id }) => {
			if (seenIds.has(id)) return false;
			seenIds.add(id);
			return true;
		});
		return [...[...open].sort((a, b) => a.name.localeCompare(b.name)), ...[...saved].sort((a, b) => a.name.localeCompare(b.name))];
	});
	function openTabsSnapshot() {
		const openTabs = workflows.openWorkflows.flatMap((workflow) => {
			const id = cloudIdFor(workflow);
			return id === void 0 ? [] : [{
				workflow_id: id,
				name: cloudWorkflowName(workflow)
			}];
		});
		return openTabs.length > 0 ? { open_tabs: openTabs } : void 0;
	}
	function nextSaveFilename(workflow) {
		const names = /* @__PURE__ */ new Set([...cloudIndex.value.map(({ name }) => name), ...workflows.workflows.filter((candidate) => candidate.path !== workflow.path).map(cloudWorkflowName)]);
		const appSuffix = workflow.initialMode === "app" ? ".app" : "";
		const stem = workflow.filename.replace(/ \(\d+\)$/, "");
		let filename = workflow.filename;
		let counter = 2;
		while (names.has(`${filename}${appSuffix}`)) filename = `${stem} (${counter++})`;
		return filename;
	}
	return {
		refreshCloudWorkflowIds,
		forgetCloudWorkflowId,
		cloudIdFor,
		cloudWorkflowName,
		boundOrOpenWorkflowFor,
		cachedOpenWorkflowFor,
		storedWorkflowFor,
		cloudListingOmits,
		cloudWorkflowLifecycle,
		openWorkflowFor,
		availableWorkflowReferences,
		openTabsSnapshot,
		nextSaveFilename
	};
}
//#endregion
//#region src/workbench/extensions/agent/composables/agent/useAgentWorkflowSelection.ts
var NOT_RESTORED = {
	ready: true,
	committedWorkflowId: null
};
var RESTORE_ABANDONED = {
	ready: false,
	committedWorkflowId: null
};
function restorationOutcomeFor(lifecycle, target) {
	switch (lifecycle) {
		case "gone": return { outcome: "deleted" };
		case "live":
		case "unknown": return {
			outcome: "open",
			target
		};
	}
}
function useAgentWorkflowSelection({ resolver, canSelectTarget, warnWorkflowUnavailable, warnRestoreFailed, onTargetBound }) {
	const workflowStore = useWorkflowStore();
	const workflowService = useWorkflowService();
	const bindingStore = useAgentWorkflowTabBindingStore();
	const panelStore = useAgentPanelStore();
	const { selectedWorkflow: selectedTarget, canRestoreWorkflow } = storeToRefs(panelStore);
	const composerStore = useAgentComposerStore();
	const { workflowReferences } = storeToRefs(composerStore);
	const { t } = useI18n();
	const toast = useToast();
	const { refreshCloudWorkflowIds, cloudIdFor, cloudWorkflowName, nextSaveFilename, boundOrOpenWorkflowFor, cachedOpenWorkflowFor, storedWorkflowFor, cloudListingOmits, cloudWorkflowLifecycle } = resolver;
	const editableWorkflowId = computed(() => selectedTarget.value ? cloudIdFor(selectedTarget.value) : void 0);
	let composerContextGeneration = 0;
	const workflowSelection = ref(null);
	const selectingTarget = computed(() => workflowSelection.value?.purpose === "target" ? workflowSelection.value.workflow : null);
	const savingReference = computed(() => workflowSelection.value?.purpose === "reference");
	let targetSelectionGeneration = 0;
	function onVisibleWorkflowChanged() {
		if (!panelStore.followsVisibleWorkflow) return;
		if (workflowSelection.value?.purpose === "target" && workflowSelection.value.workflow !== workflowStore.activeWorkflow) ++targetSelectionGeneration;
	}
	function commitWorkflowTarget(workflow, workflowId, source, previousWorkflowId = editableWorkflowId.value ?? null) {
		bindingStore.bind(workflowId, workflow.path);
		panelStore.setWorkflowTarget(workflow);
		composerStore.removeWorkflowReference(workflowId);
		if (workflowId !== previousWorkflowId) onTargetBound?.(workflowId, previousWorkflowId, source);
	}
	async function prepareWorkflowSelection(tab, isCurrent) {
		function fail(detail) {
			if (isCurrent()) warnWorkflowSelectionFailed(detail);
		}
		try {
			if (tab.isTemporary && cloudIdFor(tab) === void 0) {
				if (!await refreshCloudWorkflowIds()) return fail();
				if (!isCurrent()) return;
				const filename = nextSaveFilename(tab);
				if (!await workflowService.saveWorkflowAs(tab, { filename })) return fail();
			}
			if (!isCurrent()) return;
			let workflowId = cloudIdFor(tab);
			if (workflowId === void 0) {
				if (!await refreshCloudWorkflowIds()) return fail();
				if (!isCurrent()) return;
				workflowId = cloudIdFor(tab);
			}
			if (workflowId === void 0) warnWorkflowUnavailable();
			return workflowId;
		} catch (error) {
			return fail(error instanceof Error ? error.message : void 0);
		}
	}
	function warnWorkflowSelectionFailed(detail = t("shareWorkflow.saveFailedDescription")) {
		toast.warning(t("shareWorkflow.saveFailedTitle"), { description: detail });
	}
	async function onSelectWorkflowTarget(path) {
		const tab = workflowStore.getWorkflowByPath(path);
		if (!tab || workflowSelection.value || !canSelectTarget()) return false;
		workflowSelection.value = {
			purpose: "target",
			workflow: tab
		};
		const generation = ++targetSelectionGeneration;
		const isCurrent = () => generation === targetSelectionGeneration && workflowStore.openWorkflows.includes(tab);
		try {
			const workflowId = await prepareWorkflowSelection(tab, isCurrent);
			if (workflowId === void 0 || !isCurrent()) return false;
			const previousWorkflowId = editableWorkflowId.value ?? null;
			if (!await workflowService.openWorkflow(tab)) {
				if (isCurrent()) warnWorkflowSelectionFailed(t("agent.targetNavigationUnavailable"));
				return false;
			}
			if (!isCurrent()) return false;
			commitWorkflowTarget(tab, workflowId, "selector_chip", previousWorkflowId);
			return true;
		} catch (error) {
			if (isCurrent()) warnWorkflowSelectionFailed(error instanceof Error ? error.message : void 0);
			return false;
		} finally {
			workflowSelection.value = null;
		}
	}
	async function onSelectWorkflowReference(option) {
		if (workflowSelection.value) return void 0;
		if (option.id !== void 0) {
			if (option.id === editableWorkflowId.value || workflowReferences.value.some(({ id }) => id === option.id)) return void 0;
			return option;
		}
		const tab = workflowStore.getWorkflowByPath(option.tabPath);
		if (!tab || !workflowStore.openWorkflows.includes(tab)) return void 0;
		workflowSelection.value = {
			purpose: "reference",
			workflow: tab
		};
		const generation = composerContextGeneration;
		const isCurrent = () => generation === composerContextGeneration && workflowStore.openWorkflows.includes(tab);
		try {
			const workflowId = await prepareWorkflowSelection(tab, isCurrent);
			if (workflowId === void 0 || !isCurrent()) return void 0;
			if (workflowId === editableWorkflowId.value || workflowReferences.value.some(({ id }) => id === workflowId)) return void 0;
			bindingStore.bind(workflowId, tab.path);
			return {
				id: workflowId,
				name: cloudWorkflowName(tab)
			};
		} catch (error) {
			if (isCurrent()) warnWorkflowSelectionFailed(error instanceof Error ? error.message : void 0);
			return;
		} finally {
			workflowSelection.value = null;
		}
	}
	function onRequestWorkflowReferences() {
		if (!workflowSelection.value) refreshCloudWorkflowIds();
	}
	/**
	* A complete listing that omits the id is conclusive only when nothing local
	* owns it. With a local owner, `GET /api/workflows/{id}` decides, because the
	* listing hides version-less drafts.
	*/
	async function resolveRestorationTarget(workflowId, isCurrent) {
		const listed = await refreshCloudWorkflowIds();
		if (!isCurrent()) return { outcome: "superseded" };
		const target = boundOrOpenWorkflowFor(workflowId) ?? storedWorkflowFor(workflowId);
		if (!listed || !cloudListingOmits(workflowId)) return {
			outcome: "open",
			target
		};
		if (target === null) return { outcome: "deleted" };
		const lifecycle = await cloudWorkflowLifecycle(workflowId);
		if (!isCurrent()) return { outcome: "superseded" };
		return restorationOutcomeFor(lifecycle, boundOrOpenWorkflowFor(workflowId) ?? storedWorkflowFor(workflowId));
	}
	async function onWorkflowRestored(workflowId, isSessionCurrent) {
		if (!isSessionCurrent()) return RESTORE_ABANDONED;
		if (!canRestoreWorkflow.value) return NOT_RESTORED;
		const generation = ++targetSelectionGeneration;
		const isCurrent = () => generation === targetSelectionGeneration && isSessionCurrent() && canRestoreWorkflow.value;
		if (workflowId === void 0) return NOT_RESTORED;
		const cached = cachedOpenWorkflowFor(workflowId);
		if (cached !== null) return openRestoredWorkflow(cached, workflowId, isCurrent);
		const resolved = await resolveRestorationTarget(workflowId, isCurrent);
		if (resolved.outcome === "superseded") return RESTORE_ABANDONED;
		if (resolved.outcome === "deleted") {
			panelStore.markWorkflowTargetUnavailable();
			return NOT_RESTORED;
		}
		return openRestoredWorkflow(resolved.target, workflowId, isCurrent);
	}
	async function openRestoredWorkflow(target, workflowId, isCurrent) {
		try {
			if (target === null) {
				await workflowStore.syncWorkflows();
				if (!isCurrent()) return RESTORE_ABANDONED;
				target = storedWorkflowFor(workflowId);
			}
			if (target === null) {
				panelStore.setWorkflowTarget(null);
				warnRestoreFailed();
				return RESTORE_ABANDONED;
			}
			const opened = await workflowService.openWorkflow(target, { isCurrent });
			if (!isCurrent()) return RESTORE_ABANDONED;
			if (!opened) {
				panelStore.setWorkflowTarget(null);
				warnRestoreFailed();
				return RESTORE_ABANDONED;
			}
			commitWorkflowTarget(target, workflowId, "restored");
			return {
				ready: true,
				committedWorkflowId: workflowId
			};
		} catch {
			if (!isCurrent()) return RESTORE_ABANDONED;
			warnRestoreFailed();
			return RESTORE_ABANDONED;
		}
	}
	function adoptTarget(workflow, workflowId) {
		commitWorkflowTarget(workflow, workflowId, "restored");
	}
	function cancelSelection() {
		++composerContextGeneration;
		++targetSelectionGeneration;
	}
	onScopeDispose(cancelSelection);
	return {
		isSelecting: computed(() => workflowSelection.value !== null),
		selectingTarget,
		savingReference,
		onVisibleWorkflowChanged,
		selectTarget: onSelectWorkflowTarget,
		selectReference: onSelectWorkflowReference,
		restoreTarget: onWorkflowRestored,
		adoptTarget,
		requestReferences: onRequestWorkflowReferences,
		cancelSelection
	};
}
//#endregion
//#region src/workbench/extensions/agent/composables/agent/useAgentSession.ts
var PREPARE_TIMEOUT_MS = 3e3;
var RECONCILE_TIMEOUT_MS = 5e3;
var hydrationBuffers = /* @__PURE__ */ new Map();
var hydrationMailboxes = /* @__PURE__ */ new Map();
var HYDRATION_HANDOFF_MS = 3e4;
var HYDRATION_MAILBOX_MS = 3e5;
var MAX_HYDRATION_EVENTS = 256;
var MAX_HYDRATION_MAILBOXES = 32;
/**
* After a reconnect the server may still be finishing the turn, and its
* terminal event may or may not reach the new socket. Poll the persisted row
* with backoff; once the schedule is exhausted the socket alone is trusted.
*/
var TURN_RECOVERY_DELAYS_MS = [
	0,
	1e3,
	2e3,
	4e3,
	8e3,
	16e3
];
/** Upper bound on one recovery job, including any history fetch still in flight. */
var TURN_RECOVERY_DEADLINE_MS = 6e4;
function isTerminalTurnStatus(status) {
	switch (status) {
		case "complete":
		case "error":
		case "interrupted": return true;
		case "streaming": return false;
	}
}
function mergeAdjacentTextParts(parts) {
	const merged = [];
	for (const part of parts) {
		const previous = merged.at(-1);
		if (part.type === "text" && previous?.type === "text") {
			previous.text += part.text;
			continue;
		}
		merged.push(part);
	}
	return merged;
}
function terminalRecoveryParts(rows) {
	const parts = mergeAdjacentTextParts(normalizeAgentTranscript(rows).messages[0]?.parts ?? []);
	if (parts.length > 0) return parts;
	if (rows.every((row) => row.status !== "error")) return void 0;
	return [{
		type: "notice",
		level: "error",
		text: i18n.global.t("agent.recoveredTurnFailed")
	}];
}
function recoveryKey(turn) {
	return JSON.stringify([turn.threadId, turn.messageId]);
}
function turnOutcomeFromError(error) {
	if (error instanceof AgentApiError && error.status === 404) return { kind: "thread-missing" };
	return {
		kind: "error",
		message: error instanceof Error ? error.message : String(error)
	};
}
var NON_RETRYABLE_REQUEST_STATUSES = /* @__PURE__ */ new Set([
	400,
	401,
	403,
	404,
	405,
	409,
	410,
	422
]);
function isRetryableRequestFailure(error, accepted) {
	if (accepted) return false;
	if (error instanceof ZodError || error instanceof AgentResponseUnreadableError) return false;
	if (error instanceof AgentApiError) return !NON_RETRYABLE_REQUEST_STATUSES.has(error.status);
	return true;
}
function isUnreadableAckFailure(error) {
	return error instanceof ZodError || error instanceof AgentResponseUnreadableError;
}
function trackAgentError(errorClass, stage, uiTreatment, overrides = {}) {
	useTelemetry()?.trackAgentError({
		error_class: errorClass,
		failure_stage: stage,
		retryable: overrides.retryable ?? stage === "pre_acceptance",
		turn_accepted: overrides.turnAccepted ?? stage === "post_acceptance",
		ui_treatment: uiTreatment
	});
}
var REFUSED_ANSWER_STATUSES = /* @__PURE__ */ new Set([
	403,
	404,
	501
]);
var ANSWER_FAILURE_ERROR_TYPES = {
	rejected: "agent_ask_answer_rejected",
	refused: "agent_ask_answer_refused",
	unconfirmed: "agent_ask_answer_failed"
};
function classifyAnswerFailure(error) {
	if (!(error instanceof AgentApiError)) return "unconfirmed";
	if (error.status === 422) return "rejected";
	return REFUSED_ANSWER_STATUSES.has(error.status) ? "refused" : "unconfirmed";
}
/**
* PM-1658: backoff before re-driving an ask answer. The server documents
* 5xx here as retryable and re-drives the STORED selection, so resending the
* same answer is always safe and is the only recovery that cannot turn into a
* contradictory second choice. One retry only: the card is disabled for the
* whole sequence, which with ANSWER_ASK_TIMEOUT_MS keeps the worst case under
* the shared 60s request deadline it replaces.
*/
var ANSWER_RETRY_BACKOFF_MS = [300];
/**
* A rejected fetch never reached the server, and 5xx is the status the server
* documents as retryable. Everything else either answered (a schema failure
* means a 202 body we could not read — replaying it is a wasted request) or
* refuses permanently, as 501 does on deployments with no durable turn to
* wake.
*/
function isRetryableAnswerFailure(error) {
	if (error instanceof AgentApiError) return error.status >= 500 && error.status !== 501;
	return error instanceof TypeError || error instanceof DOMException;
}
function namesCommittedAnswer({ selected, other_text }) {
	return Array.isArray(selected) || Boolean(other_text);
}
function isSupersededAnswer(submitted, committed, selectionKnown) {
	return selectionKnown && xor(submitted.selected, committed.selected).length > 0 || (submitted.other_text || void 0) !== committed.otherText;
}
var sessionGeneration = 0;
/**
* Page-lifetime binding memory: the workflow a resumed turn belongs to must
* survive a panel remount. Module-level like `sessionGeneration`;
* newChat/loadThread clear it.
*/
var rememberedWorkflowId = null;
var turnStartedAt = /* @__PURE__ */ new Map();
/**
* Module-level like `turnStartedAt`: a POST outlives the panel that sent it,
* so a stop clicked from a remounted panel before the acknowledgement must
* reach the continuation that acks. One owner: armed while a send is in
* flight, consumed exactly once at ack.
*/
var sendInFlight = false;
var stopPendingAck = null;
function consumeStopPendingAck() {
	const pending = stopPendingAck;
	stopPendingAck = null;
	return pending;
}
var CREDENTIAL_REFRESH_INTERVAL_MS = 24e4;
function parseAdmissionError(error) {
	if (!(error instanceof AgentApiError)) return void 0;
	const parsed = zAgentAdmissionError.safeParse(error.body);
	if (!parsed.success) return void 0;
	const expectedStatus = parsed.data.error.type === "PAYMENT_REQUIRED" ? 402 : 503;
	if (error.status !== expectedStatus) return void 0;
	return {
		...parsed.data.error,
		retryAfterSeconds: error.retryAfterSeconds
	};
}
function isAttachmentTypeRejection(error) {
	return error instanceof AgentApiError && error.status === 422 && zAttachmentRejection.safeParse(error.body).success;
}
function reportSendFailure(error) {
	if (isAttachmentTypeRejection(error)) return;
	reportError(error, {
		surface: "agent",
		errorType: "agent_send_message_failed",
		tags: error instanceof AgentApiError ? {
			status: error.status,
			operation: error.operation,
			retryAfterSeconds: error.retryAfterSeconds
		} : void 0
	});
}
function disownsWorkflow(error) {
	return error instanceof AgentApiError && error.status === 403 && zDisownedWorkflowError.safeParse(error.body).success;
}
function parseTurnInProgress(error) {
	if (!(error instanceof AgentApiError) || error.status !== 409) return void 0;
	const parsed = zTurnInProgressError.safeParse(error.body);
	return parsed.success ? parsed.data : void 0;
}
function useAgentSession(deps) {
	const { rest, events, onThreadStarted, onAgentEvent, onThreadActivated, onAskResolved, refreshCredentialDuringTurns = false, workflow } = deps;
	const threadStorageKey = StorageKeys.agentThread(getWorkspaceId());
	clearLegacyAgentStorage();
	const conversationStore = useAgentConversationStore();
	const sendGateStore = useAgentSendGateStore();
	const skillPacks = useSkillPacksStore();
	const skillTurnUsage = /* @__PURE__ */ new Map();
	watch(() => skillPacks.scope, () => {
		for (const usage of skillTurnUsage.values()) {
			usage.used = false;
			usage.scope = "";
		}
	}, { flush: "sync" });
	function pruneSkillTurns() {
		const liveKeys = new Set(conversationStore.liveTurns().map(recoveryKey));
		for (const key of skillTurnUsage.keys()) if (!liveKeys.has(key)) skillTurnUsage.delete(key);
	}
	function observeSkillTurn(turn, scope = skillPacks.scope) {
		if (!conversationStore.liveTurns().some((live) => recoveryKey(live) === recoveryKey(turn))) return;
		const key = recoveryKey(turn);
		const usage = skillTurnUsage.get(key) ?? {
			scope,
			used: false
		};
		usage.used ||= conversationStore.turnUsesSkill(turn);
		skillTurnUsage.set(key, usage);
	}
	function finishSkillTurn(turn) {
		observeSkillTurn(turn);
		const key = recoveryKey(turn);
		const usage = skillTurnUsage.get(key);
		skillTurnUsage.delete(key);
		if (usage?.used && skillPacks.isCurrentScope(usage.scope)) skillPacks.refreshPacksInBackground();
	}
	const bindingStore = useAgentWorkflowTabBindingStore();
	/**
	* The workflow the session is bound to (set on turn ack or an active-tab
	* switch, cleared by newChat/loadThread) - the CRDT follower's subscribe
	* target.
	*/
	const boundWorkflowId = ref(rememberedWorkflowId);
	/**
	* H8 reporting state, kept beside the binding it describes: the workflow
	* last reported for the current thread (suppresses the ack's re-report of a
	* transition already committed by a selection), and a target selection
	* committed before its thread exists, consumed by the ack that binds it.
	*/
	let reportedWorkflowBind = null;
	let pendingWorkflowBind = null;
	function reportWorkflowBound(workflowId, previousWorkflowId, source) {
		const currentThreadId = conversationStore.threadId;
		if (currentThreadId === null) {
			if (source === "selector_chip" || source === "restored") pendingWorkflowBind = {
				workflowId,
				previousWorkflowId,
				source
			};
			return;
		}
		const pending = pendingWorkflowBind?.workflowId === workflowId ? pendingWorkflowBind : null;
		pendingWorkflowBind = null;
		const lastReported = reportedWorkflowBind?.threadId === currentThreadId ? reportedWorkflowBind.workflowId : pending?.previousWorkflowId ?? previousWorkflowId;
		if (workflowId === lastReported) return;
		reportedWorkflowBind = {
			threadId: currentThreadId,
			workflowId
		};
		useTelemetry()?.trackAgentWorkflowBound({
			thread_id: currentThreadId,
			workflow_id: workflowId,
			prev_workflow_id: lastReported,
			bind_source: pending?.source ?? source
		});
	}
	const notices = ref([]);
	const readyThreadId = ref(null);
	const promptEditState = ref({ phase: "idle" });
	const sending = ref(false);
	const answeringAskIds = computed(() => conversationStore.answeringAskIds);
	const pendingThreadSource = ref("first_open");
	useIntervalFn(() => {
		if (!refreshCredentialDuringTurns) return;
		if (conversationStore.liveTurns().length === 0) return;
		rest.refreshCredential().catch((error) => reportError(error, {
			surface: "agent",
			errorType: "failure_refreshing_agent_credential",
			level: "warning"
		}));
	}, CREDENTIAL_REFRESH_INTERVAL_MS);
	function nextLocalErrorId() {
		return toTurnId(`local-error-${createUuidv4()}`);
	}
	let unsubscribe = null;
	let unsubscribeStatus = null;
	let ownedGeneration = 0;
	let connection = "initial";
	const recoveringTurns = /* @__PURE__ */ new Map();
	function pushError(text) {
		notices.value.push({
			level: "error",
			text
		});
	}
	const malformedStreamReports = /* @__PURE__ */ new Map();
	function trackMalformedStreamEvent(cause, eventType, turnId, uiTreatment) {
		const visible = uiTreatment !== "none";
		const priorVisible = malformedStreamReports.get(turnId);
		if (priorVisible === true || priorVisible === false && !visible) return;
		malformedStreamReports.set(turnId, visible);
		reportError(/* @__PURE__ */ new Error("Malformed agent stream event"), {
			surface: "agent",
			errorType: "agent_malformed_stream_event",
			tags: {
				ui_treatment: uiTreatment,
				event_type: eventType
			},
			context: { issues: cause.issues }
		});
		trackAgentError("malformed_stream_event", turnId === null ? "pre_acceptance" : "post_acceptance", uiTreatment, { retryable: false });
	}
	function initializeWorkflowContext(hasThread) {
		workflow?.initialize?.(hasThread);
		if (conversationStore.threadId === null && localStorage.getItem(threadStorageKey) === null) {
			rememberedWorkflowId = null;
			boundWorkflowId.value = null;
		}
	}
	function start({ restore = true } = {}) {
		stopped = false;
		readyThreadId.value = null;
		ownedGeneration = ++sessionGeneration;
		connection = "initial";
		const surviving = conversationStore.threadId;
		const stored = conversationStore.messages.length === 0 ? localStorage.getItem(threadStorageKey) : null;
		const initialThreadId = surviving ?? stored;
		initializeWorkflowContext(initialThreadId !== null);
		unsubscribe = events.subscribe(onRaw);
		if (events.onStatus) unsubscribeStatus = events.onStatus(onStatus);
		if (!restore) return;
		if (initialThreadId === null) {
			onThreadActivated?.(null);
			return;
		}
		restoreInitialThread(initialThreadId, surviving);
	}
	async function restoreInitialThread(initialThreadId, surviving) {
		const generation = ++loadGeneration;
		const isCurrent = () => generation === loadGeneration && ownedGeneration === sessionGeneration;
		const ready = await hydrateFromServer(initialThreadId, isCurrent, { stashedTurn: beginInitialThread(initialThreadId, surviving) });
		if (isCurrent()) settleInitialThread(initialThreadId, surviving, ready);
	}
	/** Returns whether a surviving thread's active turn was stashed. */
	function beginInitialThread(initialThreadId, surviving) {
		if (surviving === null) {
			conversationStore.setThreadId(initialThreadId);
			return false;
		}
		const stashedTurn = conversationStore.activeTurnId !== null;
		conversationStore.stashActiveTurn();
		return stashedTurn;
	}
	function settleInitialThread(initialThreadId, surviving, ready) {
		if (ready) onThreadActivated?.(initialThreadId);
		else if (conversationStore.threadId === null) onThreadActivated?.(null);
		if (surviving !== null && conversationStore.threadId === surviving) conversationStore.resumeBackgroundTurn();
	}
	/**
	* The buffer holding for each thread whose hydrate is still fetching.
	* `subscribe()` runs before the GET resolves, and until the transcript
	* installs a transport there is nothing for `ingest` to route a frame to --
	* a panel reopened over a live turn has no background entry to fall back on
	* either, so they are dropped outright. Losing an `agent_message_done` that
	* way leaves the turn the transcript then restores running for good
	* (PM-1776); losing a delta silently truncates the reply.
	*
	* More than one thread at a time is ordinary: `start()`'s hydrate is often
	* still fetching when the user picks a thread out of history. Keying by
	* thread is what makes "one buffer per thread" unrepresentable rather than
	* merely maintained.
	*/
	let stopped = false;
	function bufferFor(threadId, terminal) {
		if (threadId === void 0) return void 0;
		return hydrationBuffers.get(threadId) ?? (terminal ? hydrationMailboxes.get(threadId) : void 0);
	}
	/**
	* Arms a buffer for the thread a hydrate is about to fetch, taking over the
	* frames of any in-flight hydrate of that thread.
	*
	* Claimed here rather than when that earlier hydrate finishes, because the
	* two GETs can resolve in either order and only this end of the overlap is
	* ordered. Replayed after ours, its older delta lands on a turn our
	* `agent_message_done` has already settled -- and both `ingest` and a
	* settled transport drop what they cannot place.
	*/
	function armHydration(threadId) {
		const superseded = hydrationBuffers.get(threadId) ?? hydrationMailboxes.get(threadId);
		if (superseded?.retirement !== void 0) clearTimeout(superseded.retirement);
		if (superseded?.mailboxRetirement !== void 0) clearTimeout(superseded.mailboxRetirement);
		hydrationMailboxes.delete(threadId);
		const buffer = {
			threadId,
			events: superseded?.events.splice(0) ?? [],
			pending: true
		};
		hydrationBuffers.set(threadId, buffer);
		buffer.retirement = setTimeout(() => retireHydrationCapture(buffer), HYDRATION_HANDOFF_MS);
		return buffer;
	}
	function retireHydrationCapture(buffer) {
		if (hydrationBuffers.get(buffer.threadId) !== buffer) return;
		hydrationBuffers.delete(buffer.threadId);
		mailboxHydration(buffer);
	}
	/**
	* Parks a buffer where a later hydrate of its thread can claim it, under a
	* fresh TTL and the cap. Re-armed rather than reused, because a buffer
	* reaching here a second time -- captured before its session stopped, and
	* only now settled -- skipped the first TTL while it was still pending.
	*/
	function mailboxHydration(buffer) {
		if (buffer.mailboxRetirement !== void 0) clearTimeout(buffer.mailboxRetirement);
		hydrationMailboxes.delete(buffer.threadId);
		hydrationMailboxes.set(buffer.threadId, buffer);
		buffer.mailboxRetirement = setTimeout(() => {
			if (buffer.pending) return;
			if (hydrationMailboxes.get(buffer.threadId) === buffer) hydrationMailboxes.delete(buffer.threadId);
			buffer.events.length = 0;
		}, HYDRATION_MAILBOX_MS);
		enforceMailboxCap();
	}
	function enforceMailboxCap() {
		while (hydrationMailboxes.size > MAX_HYDRATION_MAILBOXES) {
			const oldest = [...hydrationMailboxes].find(([, held]) => !held.pending);
			if (oldest === void 0) break;
			const [threadId, retired] = oldest;
			hydrationMailboxes.delete(threadId);
			if (retired.mailboxRetirement !== void 0) clearTimeout(retired.mailboxRetirement);
			retired.events.length = 0;
		}
	}
	/**
	* Replays a hydrate's frames and retires its buffer. Deferred rather than
	* immediate: `ingest` routes each one by thread and turn, so a frame whose
	* hydrate was superseded or failed still reaches the background turn it
	* belongs to -- and a background turn that never receives its own
	* `agent_message_done` is one `resumeBackgroundTurn` later restores as
	* permanently running. Idempotent, so the success path and the `finally`
	* can both call it.
	*
	* Delivery is best-effort, and of its bounds only the per-queue one always
	* holds. A thread captures for `HYDRATION_HANDOFF_MS` from the moment its
	* hydrate is armed; past that the queue becomes a mailbox a later hydrate
	* of the same thread can still claim. That mailbox expires after
	* `HYDRATION_MAILBOX_MS` and gives way once it is no longer among the
	* newest `MAX_HYDRATION_MAILBOXES` threads -- but both are suspended while
	* its own GET is outstanding (see `pending`), so an unsettled hydrate keeps
	* its mailbox past either, and settling is what reimposes them. A queue
	* holds `MAX_HYDRATION_EVENTS` frames throughout, evicting non-terminal
	* ones first so an `agent_message_done` -- the frame whose loss strands a
	* turn -- outlives the deltas around it.
	*
	* Only ever deletes its own registration: a superseded hydrate draining
	* late would otherwise unregister the buffer that replaced it, leaving the
	* live hydrate's frames with nowhere to be held.
	*/
	function drainHydration(buffer) {
		buffer.pending = false;
		if (buffer.retirement !== void 0) clearTimeout(buffer.retirement);
		if (buffer.mailboxRetirement !== void 0) clearTimeout(buffer.mailboxRetirement);
		if (hydrationBuffers.get(buffer.threadId) === buffer) hydrationBuffers.delete(buffer.threadId);
		if (hydrationMailboxes.get(buffer.threadId) === buffer) hydrationMailboxes.delete(buffer.threadId);
		const events = buffer.events.splice(0);
		if (stopped) {
			if (events.length === 0) return;
			buffer.events.push(...events);
			mailboxHydration(buffer);
			return;
		}
		for (const event of events) try {
			handleAgentEvent(event);
		} catch (error) {
			reportError(error, {
				surface: "agent",
				errorType: "agent_hydration_replay_failed"
			});
		}
	}
	/**
	* Turns whose liveness came from a transcript snapshot rather than from a
	* turn this client started. A snapshot is taken at one instant and the
	* stream carries no replay, so a terminal frame broadcast before this
	* session's socket attached reaches nobody: the row still read `streaming`
	* when the GET ran, and the frame that would have settled it is gone. Such a
	* turn has no in-flight local content to protect, which is what lets a 409
	* retire it outright.
	*/
	const snapshotTurns = /* @__PURE__ */ new Set();
	function rememberSnapshotTurn(turnId) {
		if (turnId !== null) snapshotTurns.add(turnId);
	}
	async function applyHydration(threadId, history, buffer, isCurrent) {
		if (conversationStore.threadId !== threadId || !isCurrent()) return false;
		conversationStore.hydrate(history);
		rememberSnapshotTurn(conversationStore.activeTurnId);
		reconcileLiveTurns();
		readyThreadId.value = threadId;
		drainHydration(buffer);
		return await workflow?.restored?.(conversationStore.latestWorkflowId, isCurrent) !== false && conversationStore.threadId === threadId && isCurrent();
	}
	async function hydrateFromServer(threadId, isCurrent = () => true, { stashedTurn = false, openThread, failureNotice = "error_overlay" } = {}) {
		const buffer = armHydration(threadId);
		try {
			const history = await rest.getMessages(threadId);
			if (openThread && isCurrent()) openThread();
			return await applyHydration(threadId, history, buffer, isCurrent);
		} catch (error) {
			return handleHistoryLoadError(error, threadId, isCurrent, stashedTurn, failureNotice);
		} finally {
			drainHydration(buffer);
		}
	}
	function handleHistoryLoadError(error, threadId, isCurrent, stashedTurn, failureNotice) {
		if (!isCurrent()) return false;
		if (error instanceof AgentApiError && error.status === 404) {
			if (conversationStore.threadId === threadId) conversationStore.setThreadId(null);
			if (localStorage.getItem(threadStorageKey) === threadId) localStorage.removeItem(threadStorageKey);
			return false;
		}
		reportError(error, {
			surface: "agent",
			errorType: "agent_history_load_failed"
		});
		if (failureNotice === "error_overlay") pushError(error instanceof Error ? error.message : String(error));
		trackAgentError("history_load_failed", "pre_acceptance", failureNotice, {
			retryable: isRetryableRequestFailure(error, false),
			turnAccepted: stashedTurn
		});
		return false;
	}
	function stop() {
		stopped = true;
		readyThreadId.value = null;
		unsubscribe?.();
		unsubscribeStatus?.();
		unsubscribe = null;
		unsubscribeStatus = null;
		for (const recovery of recoveringTurns.values()) recovery.abort();
		recoveringTurns.clear();
		const stoppedGeneration = ownedGeneration;
		queueMicrotask(() => {
			if (stoppedGeneration !== sessionGeneration) return;
			loadGeneration++;
			turnStartedAt.clear();
			skillTurnUsage.clear();
			conversationStore.abortActiveTurn();
			conversationStore.dropBackgroundTurns();
		});
	}
	async function prepareWorkflow() {
		if (!workflow?.prepare) return;
		await Promise.race([workflow.prepare().catch(() => void 0), new Promise((resolve) => setTimeout(resolve, PREPARE_TIMEOUT_MS))]);
	}
	function recordUnavailableTarget(text) {
		conversationStore.recordFailedSend(nextLocalErrorId(), text, i18n.global.t("agent.targetNavigationUnavailable"));
	}
	function postTurn(threadId, text, origin, wfContext, attachments, tags, workflowReferences, selectionWorkflowId, clientMessageId) {
		const input = buildPostInput(threadId, text, origin, wfContext, attachments, tags, workflowReferences, selectionWorkflowId, clientMessageId);
		if (wfContext?.id === void 0) return rest.postMessage(threadId, input);
		return rest.postMessage(threadId, {
			...input,
			workflowId: wfContext.id
		});
	}
	function buildPostInput(threadId, text, origin, wfContext, attachments, tags, workflowReferences, selectionWorkflowId, clientMessageId) {
		const draft = workflow?.draft?.(origin);
		const unboundTarget = isUnboundTarget(wfContext, boundWorkflowId.value);
		const selectedWorkflowId = selectionWorkflowId?.();
		return {
			content: serializeWorkflowReferences(text, workflowReferences ?? []),
			tabs: workflow?.tabs?.(origin),
			workflowReferences: serializeReferencedWorkflows(workflowReferences, wfContext?.id),
			selection: selectedNodes(tags, selectedWorkflowId),
			attachments: attachments?.map((attachment) => attachment.ref),
			clientMessageId,
			...buildTargetFields(threadId, wfContext, draft, unboundTarget)
		};
	}
	function serializeReferencedWorkflows(references, currentWorkflowId) {
		return (references ?? []).filter((reference) => reference.id !== currentWorkflowId).map((reference) => ({
			workflow_id: reference.id,
			name: reference.name
		}));
	}
	function selectedNodes(tags, selectedWorkflowId) {
		if (tags === void 0 || tags.length === 0) return void 0;
		return {
			node_ids: tags.map((tag) => tag.id),
			...selectedWorkflowId !== void 0 ? { workflow_id: selectedWorkflowId } : {}
		};
	}
	function canSendDraft(threadId, wfContext, draft, unboundTarget) {
		if (draft === void 0) return false;
		return threadId === "new" || wfContext?.id !== void 0 || unboundTarget;
	}
	function isUnboundTarget(wfContext, boundWorkflowId) {
		return wfContext !== void 0 && wfContext.id === void 0 && boundWorkflowId === null;
	}
	function buildTargetFields(threadId, wfContext, draft, unboundTarget) {
		return {
			...unboundTarget ? { currentTabUnbound: true } : {},
			...canSendDraft(threadId, wfContext, draft, unboundTarget) ? { draft } : {}
		};
	}
	function recordTurnStarted(turnId, startsThread) {
		turnStartedAt.set(turnId, Date.now());
		if (startsThread && pendingThreadSource.value !== null) {
			const source = pendingThreadSource.value;
			pendingThreadSource.value = null;
			runAcceptedTurnSideEffect(() => onThreadStarted?.(source), "agent_thread_started_callback_failed");
		}
	}
	function runAcceptedTurnSideEffect(effect, errorType) {
		try {
			effect();
		} catch (error) {
			reportError(error, {
				surface: "agent",
				errorType
			});
			trackAgentError("request_failed", "post_acceptance", "none");
		}
	}
	function acceptTurn(ack, text, wfContext, attachments, tags, workflowReferences, skillScope = skillPacks.scope) {
		const startsThread = conversationStore.threadId === null;
		conversationStore.setThreadId(ack.thread_id);
		let adoptWorkflow;
		const workflowId = ack.workflow_id;
		if (workflowId !== void 0) {
			const boundAtAck = boundWorkflowId.value;
			bindWorkflow(workflowId);
			if (wfContext?.id !== void 0 || workflowId !== boundAtAck && bindingStore.tabPathFor(workflowId) === void 0) adoptWorkflow = () => workflow?.adopted(workflowId, wfContext, boundAtAck);
		}
		const turnId = toTurnId(ack.message_id);
		conversationStore.recordUser(turnId, text, attachments?.map(({ name, previewUrl, mediaUrl, ref, mediaKind }) => ({
			name,
			previewUrl,
			mediaUrl,
			ref,
			...isAttachmentKind(mediaKind) ? { kind: mediaKind } : {}
		})), tags?.map((tag) => `${tag.title} #${tag.id}`), workflowReferences);
		conversationStore.startTurn(turnId);
		observeSkillTurn({
			threadId: ack.thread_id,
			messageId: turnId
		}, skillScope);
		readyThreadId.value = ack.thread_id;
		recordTurnStarted(turnId, startsThread);
		stopPendingActiveTurn();
		runAcceptedTurnSideEffect(() => onThreadActivated?.(ack.thread_id), "agent_thread_activated_callback_failed");
		runAcceptedTurnSideEffect(() => localStorage.setItem(threadStorageKey, ack.thread_id), "agent_thread_persistence_failed");
		if (adoptWorkflow) runAcceptedTurnSideEffect(adoptWorkflow, "agent_workflow_adoption_callback_failed");
	}
	function stopPendingActiveTurn() {
		const pendingStop = consumeStopPendingAck();
		if (pendingStop !== null) stopTurn(pendingStop.method);
	}
	function recordSendError(error, text, accepted, reattached) {
		const admission = parseAdmissionError(error);
		if (admission?.reason === "no_funds") {
			conversationStore.recordPaywall(nextLocalErrorId(), text, admission.message);
			return;
		}
		if (admission !== void 0) {
			conversationStore.recordFailedSend(nextLocalErrorId(), text, admission.message, admission.reason === "funds_unavailable" ? admission.retryAfterSeconds : void 0);
			return;
		}
		const message = error instanceof Error ? error.message : String(error);
		conversationStore.recordFailedSend(nextLocalErrorId(), text, reattached ? i18n.global.t("agent.sendTurnInProgress") : `${i18n.global.t("agent.sendFailed")}: ${message}`);
		const turnAccepted = accepted || isUnreadableAckFailure(error);
		reportSendFailure(error);
		trackAgentError("request_failed", turnAccepted ? "post_acceptance" : "pre_acceptance", "inline_notice", { retryable: isRetryableRequestFailure(error, turnAccepted) });
	}
	function recordCurrentSendError(error, text, accepted, reattached, threadAtSend) {
		if (threadAtSend !== "new" && conversationStore.threadId !== threadAtSend) return;
		recordSendError(error, text, accepted, reattached);
	}
	/**
	* The server will not serve the id this turn was posted under, and the
	* binding that produced it outlives the page. Left in place it poisons the
	* tab: every later turn re-posts the same dead id, and a reload re-affirms
	* the binding through the thread's own workflow pointer.
	*
	* Everything here is keyed by the refused id, never by its tab path: the tab
	* may already have been rebound to a healthy workflow while the POST was in
	* flight. `disowned` evicts the id from the resolver's cloud index, which
	* `cloudIdFor` consults ahead of the binding store.
	*/
	function releaseDisownedWorkflow(sent, error) {
		if (sent?.id === void 0 || !disownsWorkflow(error)) return;
		bindingStore.unbindWorkflow(sent.id);
		workflow?.disowned?.(sent.id);
		if (boundWorkflowId.value === sent.id) boundWorkflowId.value = null;
		if (rememberedWorkflowId === sent.id) rememberedWorkflowId = null;
	}
	async function reattachRefusedTurn(error, threadAtSend, generation) {
		const conflict = parseTurnInProgress(error);
		if (conflict === void 0 || threadAtSend === "new") return false;
		const reattachGeneration = ++refusedTurnReattachGeneration;
		const isCurrentReattachment = () => reattachGeneration === refusedTurnReattachGeneration && generation === loadGeneration && ownedGeneration === sessionGeneration && conversationStore.threadId === threadAtSend;
		await Promise.race([hydrateFromServer(threadAtSend, isCurrentReattachment), new Promise((resolve) => setTimeout(resolve, RECONCILE_TIMEOUT_MS))]);
		const activeTurnId = conversationStore.activeTurnId;
		const adoptedActiveTurn = isCurrentReattachment() && activeTurnId !== null && (conflict.active_message_id === void 0 || activeTurnId === conflict.active_message_id);
		if (reattachGeneration === refusedTurnReattachGeneration) refusedTurnReattachGeneration++;
		if (adoptedActiveTurn) stopPendingActiveTurn();
		return adoptedActiveTurn;
	}
	async function performSend(text, attachments, tags, workflowReferences, selectionWorkflowId, clientMessageId, onAccepted) {
		const generation = loadGeneration;
		const skillScopeAtSend = skillPacks.scope;
		const threadAtSend = conversationStore.threadId ?? "new";
		const originContext = workflow?.current();
		const origin = originContext === void 0 ? null : { tabPath: originContext.tabPath };
		let sentContext;
		let accepted = false;
		try {
			await prepareWorkflow();
			if (generation !== loadGeneration) return false;
			const wfContext = workflow?.current(origin);
			if (workflowTargetChanged(originContext, wfContext)) {
				recordUnavailableTarget(text);
				return false;
			}
			sentContext = wfContext;
			const ack = await postTurn(threadAtSend, text, origin, wfContext, attachments, tags, workflowReferences, selectionWorkflowId, clientMessageId);
			accepted = true;
			if (!observeAcceptedTurn(generation, onAccepted)) return false;
			acceptTurn(ack, text, wfContext, attachments, tags, workflowReferences, skillScopeAtSend);
			return true;
		} catch (error) {
			releaseDisownedWorkflow(sentContext, error);
			if (generation !== loadGeneration) return false;
			const reattached = await reattachRefusedTurn(error, threadAtSend, generation);
			if (generation !== loadGeneration) return false;
			recordCurrentSendError(error, text, accepted, reattached, threadAtSend);
			return false;
		}
	}
	function observeAcceptedTurn(generation, onAccepted) {
		runAcceptedTurnSideEffect(() => onAccepted?.(), "agent_turn_accepted_callback_failed");
		return generation === loadGeneration;
	}
	function workflowTargetChanged(origin, current) {
		if (origin?.id === void 0) return false;
		return current?.id !== origin.id;
	}
	async function sendMessage(text, attachments, tags, workflowReferences, selectionWorkflowId, clientMessageId, onAccepted) {
		if (sending.value) {
			conversationStore.recordFailedSend(nextLocalErrorId(), text, i18n.global.t("agent.sendBusy"));
			return false;
		}
		promptEditState.value = { phase: "idle" };
		sending.value = true;
		const releaseSendGate = sendGateStore.begin();
		sendInFlight = true;
		stopPendingAck = null;
		try {
			const sent = await performSend(text, attachments, tags, workflowReferences, selectionWorkflowId, clientMessageId, onAccepted);
			if (!sent) stopPendingAck = null;
			return sent;
		} finally {
			sending.value = false;
			releaseSendGate();
			sendInFlight = false;
		}
	}
	function captureStopMetadata(turnId, method) {
		if (method === void 0) return null;
		const startedAt = turnStartedAt.get(turnId);
		return {
			method,
			turn_id: turnId,
			turn_elapsed_ms: startedAt === void 0 ? null : Math.max(0, Date.now() - startedAt)
		};
	}
	function forgetActiveTurnStartedAt() {
		const activeTurnId = conversationStore.activeTurnId;
		if (activeTurnId !== null) turnStartedAt.delete(activeTurnId);
	}
	function isStoppingTurn(turnId) {
		return promptEditState.value.phase === "stopping" && promptEditState.value.turnId === turnId;
	}
	function trackCommittedStop(metadata) {
		if (metadata !== null) useTelemetry()?.trackAgentStopClicked(metadata);
	}
	function releaseStoppingPhase(turnId) {
		if (isStoppingTurn(turnId)) promptEditState.value = { phase: "idle" };
	}
	function abandonedStop(turnId) {
		return conversationStore.activeTurnId !== turnId;
	}
	/**
	* Re-reads the thread so a persisted terminal row can replace the stale
	* `streaming` snapshot this Stop was answered for, then retires the
	* snapshot's provenance.
	*
	* Bounded, because `stopTurn` awaits this and the composer sits in
	* `stopping` until it returns: an unbounded GET would cost the user the one
	* escape from the orphan this path exists to retire. The hydrate's own
	* currency check carries the turn as well as the thread, so a response that
	* arrives after the turn settled and a newer send took the active slot is
	* discarded instead of overwriting the newer transport.
	*/
	async function reconcileSnapshotTurn(turnId) {
		const threadId = conversationStore.threadId;
		if (threadId !== null) await Promise.race([hydrateFromServer(threadId, () => conversationStore.threadId === threadId && conversationStore.activeTurnId === turnId), new Promise((resolve) => setTimeout(resolve, RECONCILE_TIMEOUT_MS))]);
		if (conversationStore.activeTurnId === turnId) conversationStore.abortActiveTurn();
		snapshotTurns.delete(turnId);
	}
	function reportStopFailure(error, retryable) {
		reportError(error, {
			surface: "agent",
			errorType: "agent_cancel_turn_failed"
		});
		pushError(error instanceof Error ? error.message : String(error));
		trackAgentError("cancel_failed", "post_acceptance", "error_overlay", { retryable });
	}
	async function handleStopFailure(error, turnId) {
		if (abandonedStop(turnId)) {
			releaseStoppingPhase(turnId);
			return;
		}
		const status = error instanceof AgentApiError ? error.status : void 0;
		if ((status === 404 || status === 409) && snapshotTurns.has(turnId)) {
			try {
				await reconcileSnapshotTurn(turnId);
			} finally {
				releaseStoppingPhase(turnId);
			}
			return;
		}
		if (status === 409) return;
		releaseStoppingPhase(turnId);
		reportStopFailure(error, status === void 0 ? true : isRetryableRequestFailure(error, false));
	}
	async function stopTurn(method) {
		const threadId = conversationStore.threadId;
		const turnId = conversationStore.activeTurnId;
		if (threadId === null || turnId === null) {
			if (sendInFlight) stopPendingAck = { method };
			return;
		}
		if (isStoppingTurn(turnId)) return;
		promptEditState.value = {
			phase: "stopping",
			turnId
		};
		const stopMetadata = captureStopMetadata(conversationStore.activeMessageId ?? turnId, method);
		try {
			await rest.cancelMessage(threadId, turnId);
			trackCommittedStop(stopMetadata);
		} catch (error) {
			await handleStopFailure(error, turnId);
		}
	}
	async function answerAsk(askId, answer) {
		const currentThreadId = conversationStore.threadId;
		if (currentThreadId === null) {
			reportError(/* @__PURE__ */ new Error("agent ask answered with no thread to send on"), {
				surface: "agent",
				errorType: "agent_ask_answer_unroutable"
			});
			pushError(i18n.global.t("agent.runApproval.answerFailed"));
			conversationStore.retireAsk(askId, { status: "retired" });
			return false;
		}
		if (answeringAskIds.value.has(askId)) return false;
		conversationStore.recordAskAnswer(askId, answer);
		conversationStore.setAskAnswering(askId, true);
		try {
			const receipt = await sendAnswer(currentThreadId, askId, answer);
			const committed = toAskResolution(receipt);
			reportSupersededAnswer(askId, receipt);
			conversationStore.commitAsk(askId, currentThreadId, committed);
			return true;
		} catch (error) {
			if (answeringAskIds.value.has(askId)) handleAnswerFailure(error, askId, currentThreadId);
			return false;
		}
	}
	function handleAnswerFailure(error, askId, threadId) {
		if (error instanceof AgentApiError && error.status === 409) {
			const conflict = zAgentAskConflict.safeParse(error.body).data ?? {};
			reportSupersededAnswer(askId, conflict);
			conversationStore.retireAsk(askId, toAskResolution(conflict), threadId);
			return;
		}
		const failure = classifyAnswerFailure(error);
		reportError(error, {
			surface: "agent",
			errorType: ANSWER_FAILURE_ERROR_TYPES[failure]
		});
		trackAgentError("ask_answer_failed", "post_acceptance", "error_overlay", { retryable: isRetryableRequestFailure(error, false) });
		({
			rejected: () => {
				conversationStore.takeSubmittedAskAnswer(askId);
				conversationStore.setAskAnswering(askId, false);
				pushError(i18n.global.t("agent.askUser.answerRejected"));
			},
			refused: () => {
				pushError(i18n.global.t("agent.runApproval.answerFailed"));
				conversationStore.retireAsk(askId, { status: "retired" }, threadId);
			},
			unconfirmed: () => {
				conversationStore.retireAsk(askId, { status: "unconfirmed" }, threadId);
				pushError(i18n.global.t("agent.runApproval.answerUncertain"));
			}
		})[failure]();
	}
	function reportSupersededAnswer(askId, source) {
		if (!namesCommittedAnswer(source)) return;
		const committed = toAskResolution(source);
		if (committed.status !== "answered") return;
		const submitted = conversationStore.takeSubmittedAskAnswer(askId);
		if (submitted === void 0 || !isSupersededAnswer(submitted, committed, Array.isArray(source.selected))) return;
		reportError(/* @__PURE__ */ new Error(`agent ask resolved as ${committed.selected.join(",")}, not ${submitted.selected.join(",")}`), {
			surface: "agent",
			errorType: "agent_ask_answer_superseded"
		});
		pushError(i18n.global.t("agent.runApproval.answerSuperseded"));
	}
	async function sendAnswer(threadId, askId, answer) {
		for (let attempt = 0;; attempt++) try {
			return await rest.answerAsk(threadId, askId, answer);
		} catch (error) {
			if (attempt >= ANSWER_RETRY_BACKOFF_MS.length || !isRetryableAnswerFailure(error)) throw error;
			await new Promise((resolve) => setTimeout(resolve, ANSWER_RETRY_BACKOFF_MS[attempt]));
		}
	}
	let loadGeneration = 0;
	let refusedTurnReattachGeneration = 0;
	function newChat(source) {
		readyThreadId.value = null;
		loadGeneration++;
		promptEditState.value = { phase: "idle" };
		conversationStore.stashActiveTurn();
		conversationStore.reset();
		pruneSkillTurns();
		onThreadActivated?.(null);
		boundWorkflowId.value = null;
		rememberedWorkflowId = null;
		pendingWorkflowBind = null;
		malformedStreamReports.clear();
		localStorage.removeItem(threadStorageKey);
		pendingThreadSource.value = source ?? null;
	}
	async function loadThread(threadId, isNavigationCurrent = () => true, { keepOpenChatUntilLoaded = false } = {}) {
		const load = {
			generation: loadGeneration,
			stashedTurn: false,
			switched: false
		};
		const isLoadCurrent = () => load.generation === loadGeneration && ownedGeneration === sessionGeneration;
		const isCurrent = () => isLoadCurrent() && isNavigationCurrent();
		const outlivedItsNavigation = () => load.switched && isLoadCurrent() && !isNavigationCurrent() && readyThreadId.value === threadId;
		function openThread() {
			readyThreadId.value = null;
			load.generation = ++loadGeneration;
			promptEditState.value = { phase: "idle" };
			load.stashedTurn = conversationStore.activeTurnId !== null;
			conversationStore.stashActiveTurn();
			boundWorkflowId.value = null;
			rememberedWorkflowId = null;
			pendingWorkflowBind = null;
			malformedStreamReports.clear();
			conversationStore.setThreadId(threadId);
			load.switched = keepOpenChatUntilLoaded;
		}
		if (!keepOpenChatUntilLoaded) openThread();
		const opened = await hydrateFromServer(threadId, isCurrent, keepOpenChatUntilLoaded ? {
			openThread,
			failureNotice: "inline_notice"
		} : { stashedTurn: load.stashedTurn }) && isCurrent();
		if (opened || outlivedItsNavigation()) {
			localStorage.setItem(threadStorageKey, threadId);
			onThreadActivated?.(threadId);
			conversationStore.resumeBackgroundTurn();
		}
		return opened;
	}
	function malformedEventTurnId(raw) {
		if (!("data" in raw) || typeof raw.data !== "object" || raw.data === null) return void 0;
		if (!("message_id" in raw.data)) return void 0;
		const messageId = raw.data.message_id;
		return typeof messageId === "string" ? toTurnId(messageId) : void 0;
	}
	function finishSkillTurnsFor(messageId) {
		for (const turn of conversationStore.liveTurns()) if (turn.messageId === messageId) finishSkillTurn(turn);
	}
	function handleMalformedEvent(type, raw, error) {
		const turnId = malformedEventTurnId(raw);
		let reportedTurnId = turnId ?? conversationStore.activeTurnId;
		let uiTreatment = "none";
		if (type === "agent_message_done") {
			finishSkillTurnsFor(turnId ?? conversationStore.activeTurnId);
			if (turnId !== void 0) turnStartedAt.delete(turnId);
			if (turnId === void 0 || turnId === conversationStore.activeTurnId) {
				forgetActiveTurnStartedAt();
				conversationStore.abortActiveTurn();
				pushError(i18n.global.t("agent.malformedEvent"));
				uiTreatment = "error_overlay";
			} else reportedTurnId = conversationStore.settleBackgroundTurn(turnId) ?? reportedTurnId;
		}
		trackMalformedStreamEvent(error, type, reportedTurnId, uiTreatment);
	}
	function handleMessageDone(event) {
		turnStartedAt.delete(toTurnId(event.data.message_id));
		markStoppedTurnReady({
			threadId: event.data.thread_id,
			messageId: toTurnId(event.data.message_id)
		});
	}
	/**
	* Whether the store can place this frame right now. `liveTurns()` is the
	* whole answer and is asked without qualification: it carries the active
	* slot and every unsettled background turn, each keyed by its own thread, so
	* an off-screen stash, a stash on the thread being displayed, and the active
	* turn are all one lookup. Re-deriving any part of that here is what made
	* the check right for the case under test and wrong for its sibling three
	* times over -- active-slot-only missed background turns, and keying on the
	* selected thread then missed same-thread stashes (PM-1776).
	*/
	function hasRoutableLiveTurn(eventThreadId, eventMessageId) {
		if (eventThreadId === void 0 || eventMessageId === void 0) return false;
		return conversationStore.liveTurns().some((turn) => turn.threadId === eventThreadId && turn.messageId === eventMessageId);
	}
	/**
	* Holds a frame a hydrate has nowhere to put yet, and reports whether
	* delivery was taken over. A routable frame is never withheld -- its
	* transport is waiting, and deferring it onto a drain the mailbox bounds can
	* cancel is how a turn gets stranded.
	*
	* A terminal frame is nevertheless *retained* as well as delivered, because
	* this session's delivery dies with it: `stop()` before the hydrate installs
	* the transcript leaves a successor facing the server's still-`streaming`
	* row, and the buffer is the only thing that carries the frame across. Only
	* the terminal one -- a delta replayed onto the transport that already took
	* it would render twice, while settling an already-settled turn is inert.
	*/
	function heldForHydration(event) {
		const terminal = event.type === "agent_message_done";
		const buffer = bufferFor(event.data.thread_id, terminal);
		if (buffer === void 0) return false;
		const routable = hasRoutableLiveTurn(event.data.thread_id, event.data.message_id);
		if (routable && !terminal) return false;
		if (buffer.events.length >= MAX_HYDRATION_EVENTS) {
			const replace = buffer.events.findIndex((held) => held.type !== "agent_message_done");
			if (replace === -1 && !terminal) return true;
			buffer.events.splice(Math.max(0, replace), 1);
		}
		buffer.events.push(event);
		return !routable;
	}
	function handleActiveTab(event) {
		if (event.data.thread_id === void 0 || event.data.thread_id === conversationStore.threadId) workflow?.activeTab?.(event.data);
	}
	/**
	* A frame that reaches the active turn rather than a buffer proves this
	* session has a stream for it, which is exactly what a snapshot-restored
	* turn was missing. From here its liveness no longer rests on the snapshot,
	* so a stop failure must leave it alone and let the stream settle it.
	*/
	function observeLiveDelivery(event) {
		const messageId = event.data.message_id;
		if (messageId !== void 0) snapshotTurns.delete(toTurnId(messageId));
	}
	function handleAgentEvent(event) {
		if (heldForHydration(event)) return;
		observeLiveDelivery(event);
		if (event.type === "agent_ask_resolved") {
			const resolution = toAskResolution(event.data);
			reportSupersededAnswer(event.data.ask_id, event.data);
			conversationStore.retireAsk(event.data.ask_id, resolution, event.data.thread_id);
			onAskResolved?.(event.data.ask_id);
		}
		for (const turn of conversationStore.liveTurns()) observeSkillTurn(turn);
		if (event.type === "agent_message_done") finishSkillTurn({
			threadId: event.data.thread_id,
			messageId: toTurnId(event.data.message_id)
		});
		conversationStore.ingest(event);
		for (const turn of conversationStore.liveTurns()) observeSkillTurn(turn);
		if (event.type === "agent_active_tab") handleActiveTab(event);
		else if (event.type === "agent_message_done") handleMessageDone(event);
	}
	function onRaw(raw) {
		if (typeof raw !== "object" || raw === null) return;
		const type = raw.type;
		if (typeof type !== "string" || !isAgentEvent(type)) return;
		const parsed = parseAgentWsEvent(raw);
		if (!parsed.success) {
			handleMalformedEvent(type, raw, parsed.error);
			return;
		}
		onAgentEvent?.(parsed.data);
		handleAgentEvent(parsed.data);
	}
	function onStatus(live) {
		if (!live) {
			connection = "dropped";
			return;
		}
		const reconnected = connection === "dropped";
		connection = "live";
		if (!reconnected) return;
		reconcileLiveTurns();
	}
	function reconcileLiveTurns() {
		const turns = conversationStore.liveTurns().filter((turn) => !recoveringTurns.has(recoveryKey(turn)));
		for (const turn of turns) reconcileTurn(turn);
	}
	async function reconcileTurn(turn) {
		observeSkillTurn(turn);
		const key = recoveryKey(turn);
		const recovery = new AbortController();
		recoveringTurns.set(key, recovery);
		const deadline = setTimeout(() => recovery.abort(), TURN_RECOVERY_DEADLINE_MS);
		try {
			await recoverTurn(turn, ownedGeneration, recovery.signal);
		} catch (error) {
			if (!recovery.signal.aborted) reportError(error, {
				surface: "agent",
				errorType: "failure_recovering_agent_turn"
			});
		} finally {
			clearTimeout(deadline);
			if (recoveringTurns.get(key) === recovery) recoveringTurns.delete(key);
		}
	}
	async function recoverTurn(turn, generation, signal) {
		let consecutiveThreadMissing = 0;
		for (const ms of TURN_RECOVERY_DELAYS_MS) {
			await delay(ms, { signal });
			if (!isTurnLive(turn, generation)) return;
			const outcome = await fetchTurnOutcome(turn, signal);
			if (!isTurnLive(turn, generation)) return;
			consecutiveThreadMissing = outcome.kind === "thread-missing" ? consecutiveThreadMissing + 1 : 0;
			if (outcome.kind === "thread-missing" && consecutiveThreadMissing < 2) continue;
			if (settleFinishedTurn(turn, outcome)) return;
		}
	}
	function isTurnLive(turn, generation) {
		return generation === sessionGeneration && conversationStore.liveTurns().some((live) => live.threadId === turn.threadId && live.messageId === turn.messageId);
	}
	function settleFinishedTurn(turn, outcome) {
		switch (outcome.kind) {
			case "terminal":
				if (outcome.parts?.some((part) => part.type === "tool" && part.name === "load_skill")) {
					observeSkillTurn(turn);
					const usage = skillTurnUsage.get(recoveryKey(turn));
					if (usage) usage.used = true;
				}
				finishSkillTurn(turn);
				conversationStore.settleTurn(turn, outcome.parts, outcome.ending);
				markStoppedTurnReady(turn);
				return true;
			case "thread-missing":
				forgetDeletedThread(turn);
				return true;
			case "streaming":
			case "error": return false;
			default: return outcome;
		}
	}
	function markStoppedTurnReady(turn) {
		if (promptEditState.value.phase !== "stopping" || turn.messageId !== promptEditState.value.turnId || turn.threadId !== conversationStore.threadId) return;
		promptEditState.value = {
			phase: "ready",
			turnId: promptEditState.value.turnId
		};
	}
	async function fetchTurnOutcome(turn, signal) {
		try {
			const history = await rest.getMessages(turn.threadId, { signal });
			const anchor = history.find((entry) => entry.role === "assistant" && entry.id === turn.messageId);
			if (!anchor) return { kind: "streaming" };
			const rows = history.filter((entry) => entry.role === "assistant" && entry.turn_id === anchor.turn_id).sort((a, b) => a.seq - b.seq);
			if (rows.some((row) => !isTerminalTurnStatus(row.status))) return { kind: "streaming" };
			return {
				kind: "terminal",
				parts: terminalRecoveryParts(rows),
				ending: rows.at(-1)?.status === "complete" ? "completed" : "failed"
			};
		} catch (error) {
			if (signal.aborted) throw error;
			return turnOutcomeFromError(error);
		}
	}
	function forgetDeletedThread(turn) {
		skillTurnUsage.delete(recoveryKey(turn));
		if (conversationStore.threadId !== turn.threadId) {
			conversationStore.settleTurn(turn, void 0, "failed");
			return;
		}
		conversationStore.reset();
		pruneSkillTurns();
		onThreadActivated?.(null);
		boundWorkflowId.value = null;
		rememberedWorkflowId = null;
		localStorage.removeItem(threadStorageKey);
	}
	const isSending = computed(() => sending.value);
	const editableTurnId = computed(() => promptEditState.value.phase === "ready" ? promptEditState.value.turnId : null);
	function bindWorkflow(workflowId) {
		boundWorkflowId.value = workflowId;
		rememberedWorkflowId = workflowId;
	}
	return {
		boundWorkflowId: computed(() => boundWorkflowId.value),
		bindWorkflow,
		reportWorkflowBound,
		isSending,
		isTranscriptReady: computed(() => readyThreadId.value !== null && readyThreadId.value === conversationStore.threadId),
		editableTurnId,
		start,
		stop,
		sendMessage,
		stopTurn,
		answerAsk,
		answeringAskIds: computed(() => answeringAskIds.value),
		newChat,
		loadThread,
		entries: computed(() => conversationStore.entries),
		status: computed(() => conversationStore.status),
		isStreaming: computed(() => conversationStore.isStreaming),
		notices: computed(() => notices.value),
		threadId: computed(() => conversationStore.threadId)
	};
}
//#endregion
//#region src/workbench/extensions/agent/composables/agent/useAgentDraftSubmission.ts
function useAgentDraftSubmission(options) {
	const composer = useAgentComposerStore();
	const { selection } = options;
	function recoverFailedSubmission() {
		const snapshot = composer.takeFailedSubmission();
		if (!snapshot || selection.staged.value.length > 0) return;
		composer.restorePrompt({
			text: snapshot.prompt.text,
			references: snapshot.prompt.references.filter((reference) => {
				if (reference.kind === "workflow") return reference.id !== options.editableWorkflowId();
				if (reference.kind === "node") return options.target() === snapshot.target && snapshot.nodes.some((node) => selectedNodeKey(node) === selectedNodeKey(reference.node));
				return true;
			})
		}, snapshot.attachments);
		if (options.target() === snapshot.target) selection.replace(snapshot.nodes);
	}
	watch(() => composer.submission, recoverFailedSubmission, {
		immediate: true,
		flush: "sync"
	});
	async function submit(text, attachments, references = []) {
		const target = options.target();
		if (!options.canSubmit() || composer.submission?.phase === "pending" || target === null || !text.trim() && attachments.length === 0 || attachments.some((attachment) => attachment.uploading)) return;
		options.onSubmit();
		const prompt = composer.prompt;
		const inputMethod = composer.promptOrigin;
		const starterPrompt = composer.starterPrompt;
		const sentAttachments = [...attachments];
		const sentReferences = [...references];
		selection.exit();
		const nodes = selection.workflow() === target ? [...selection.staged.value] : [];
		selection.consume();
		const submissionId = composer.startSubmission({
			prompt,
			attachments: sentAttachments,
			nodes,
			target
		});
		const sent = await options.send(text, sentAttachments, nodes, sentReferences, {
			clientMessageId: v4(),
			inputMethod,
			starterPrompt
		});
		composer.settleSubmission(submissionId, sent);
	}
	return { submit };
}
//#endregion
//#region src/workbench/extensions/agent/composables/agent/useAgentChatHistoryRefresh.ts
function useAgentChatHistoryRefresh({ listThreads, history, untitledChat, onFailure }) {
	let latestStartedRefresh = 0;
	let latestAppliedRefresh = 0;
	let latestSurfacedRefresh = 0;
	const newestSighting = /* @__PURE__ */ new Map();
	const coveredAt = /* @__PURE__ */ new Map();
	const controller = new AbortController();
	onScopeDispose(() => controller.abort());
	function toChatSession(thread) {
		const lastActivityAt = [
			thread.last_message_at,
			thread.updated_at,
			thread.created_at
		].map((stamp) => Date.parse(stamp)).find((time) => !Number.isNaN(time));
		return {
			id: thread.id,
			title: thread.title || thread.preview || untitledChat(),
			updatedAt: lastActivityAt ?? Date.now(),
			lastActivityAt,
			titleSource: thread.title ? "server" : "fallback",
			workflowId: thread.workflow_id || void 0
		};
	}
	function ownsFailure(generation, uiTreatment) {
		return generation === (uiTreatment === "error_overlay" ? latestSurfacedRefresh : latestStartedRefresh) && generation > latestAppliedRefresh;
	}
	function coverage(workflowId) {
		const full = coveredAt.get(void 0) ?? 0;
		return workflowId ? Math.max(full, coveredAt.get(workflowId) ?? 0) : full;
	}
	function record(generation, sessions, workflowId) {
		for (const session of sessions) if (generation > (newestSighting.get(session.id)?.generation ?? 0)) newestSighting.set(session.id, {
			generation,
			session
		});
		coveredAt.set(workflowId, Math.max(coveredAt.get(workflowId) ?? 0, generation));
	}
	function visibleSessions(candidates) {
		const visible = /* @__PURE__ */ new Map();
		for (const cached of candidates) {
			const sighting = newestSighting.get(cached.id) ?? {
				generation: 0,
				session: cached
			};
			if (!visible.has(cached.id) && sighting.generation >= coverage(sighting.session.workflowId)) visible.set(cached.id, sighting);
		}
		return [...visible.values()].sort((a, b) => b.generation - a.generation).map(({ session }) => session);
	}
	function pruneCovered() {
		const full = coveredAt.get(void 0) ?? 0;
		for (const [id, { generation }] of newestSighting) if (generation < full) newestSighting.delete(id);
		for (const [key, covered] of coveredAt) if (key !== void 0 && covered <= full) coveredAt.delete(key);
	}
	function applyListing(generation, sessions, workflowId) {
		record(generation, sessions, workflowId);
		history.replaceAll(visibleSessions([...sessions, ...history.sessions]));
		pruneCovered();
	}
	function applyRefreshResult(result, generation, uiTreatment, workflowId) {
		if (controller.signal.aborted || result.status === "aborted") return "aborted";
		if (result.status !== "complete") {
			if (!ownsFailure(generation, uiTreatment)) return "superseded";
			onFailure(result, uiTreatment);
			return result.status;
		}
		if (generation < (coveredAt.get(void 0) ?? 0)) return "superseded";
		const superseded = generation < coverage(workflowId);
		applyListing(generation, result.threads.map(toChatSession), workflowId);
		latestAppliedRefresh = Math.max(latestAppliedRefresh, generation);
		return superseded ? "superseded" : "complete";
	}
	async function refreshHistory(uiTreatment = "error_overlay", workflowId) {
		if (controller.signal.aborted) return "aborted";
		const { signal } = controller;
		const generation = ++latestStartedRefresh;
		if (uiTreatment === "error_overlay") latestSurfacedRefresh = generation;
		return applyRefreshResult(await listThreads({
			signal,
			workflowId
		}), generation, uiTreatment, workflowId);
	}
	return { refreshHistory };
}
//#endregion
//#region src/workbench/extensions/agent/composables/agent/useAgentWorkflowChatFollow.ts
function requestedState(state, event) {
	const generation = state.generation + 1;
	return event.heldBack ? {
		status: "idle",
		generation
	} : {
		status: "loading",
		generation,
		workflow: event.workflow,
		chat: null
	};
}
function chatFoundState(state, event) {
	if (state.status !== "loading" || state.generation !== event.generation) return state;
	return {
		...state,
		chat: {
			threadId: event.threadId,
			workflowId: event.workflowId
		}
	};
}
function failedState(state, event) {
	if (state.status !== "loading" || state.generation !== event.generation) return state;
	return {
		status: "failed",
		generation: event.generation,
		workflow: event.workflow
	};
}
function finishedState(state, event) {
	return state.status === "loading" && state.generation === event.generation ? {
		status: "idle",
		generation: state.generation
	} : state;
}
function reduceFollow(state, event) {
	switch (event.type) {
		case "requested": return requestedState(state, event);
		case "chat_found": return chatFoundState(state, event);
		case "failed": return failedState(state, event);
		case "finished": return finishedState(state, event);
		case "retired": return {
			status: "idle",
			generation: state.generation + 1
		};
	}
}
function useAgentWorkflowChatFollow(deps) {
	const state = shallowRef({
		status: "idle",
		generation: 0
	});
	function dispatch(event) {
		state.value = reduceFollow(state.value, event);
	}
	function heldBack(workflow) {
		const target = deps.selectedTarget();
		const chatTargetsWorkflow = !deps.followsVisibleWorkflow() && target?.path === workflow.path;
		return workflow.isTemporary || deps.userEngaged() || chatTargetsWorkflow;
	}
	function latestChatFor(workflowId) {
		return maxBy(deps.sessions().filter((session) => session.workflowId === workflowId), ({ lastActivityAt }) => lastActivityAt ?? Number.NEGATIVE_INFINITY)?.id;
	}
	function isCurrent(operation) {
		return state.value.generation === operation.generation && deps.activeWorkflow()?.path === operation.workflow.path && !deps.userEngaged();
	}
	async function openFollowedChat(id, operation, workflowId) {
		dispatch({
			type: "chat_found",
			generation: operation.generation,
			threadId: id,
			workflowId
		});
		const opened = await deps.loadThread(id, () => isCurrent(operation), { keepOpenChatUntilLoaded: true });
		if (!isCurrent(operation)) return;
		if (!opened) {
			dispatch({
				type: "failed",
				generation: operation.generation,
				workflow: operation.workflow
			});
			return;
		}
		dispatch({
			type: "finished",
			generation: operation.generation
		});
		if (!deps.hasDraft()) deps.clearDraft();
		deps.trackThreadStarted();
	}
	async function resolveWorkflowId(workflow) {
		const existing = deps.cloudIdFor(workflow);
		if (existing !== void 0) return existing;
		await deps.refreshCloudWorkflowIds();
		return deps.cloudIdFor(workflow);
	}
	async function refreshForFollow(workflowId, operation) {
		const outcome = await deps.refreshHistory("none", workflowId);
		if (!isCurrent(operation)) return false;
		if (outcome === "failed" || outcome === "incomplete") {
			dispatch({
				type: "failed",
				generation: operation.generation,
				workflow: operation.workflow
			});
			return false;
		}
		return outcome === "complete";
	}
	async function openLatestChat(workflowId, operation) {
		const latest = latestChatFor(workflowId);
		if (latest !== void 0 && latest !== deps.currentThreadId()) await openFollowedChat(latest, operation, workflowId);
	}
	async function followTab(workflow) {
		dispatch({
			type: "requested",
			workflow,
			heldBack: heldBack(workflow)
		});
		const operation = state.value;
		if (operation.status !== "loading") return;
		try {
			const workflowId = await resolveWorkflowId(workflow);
			if (workflowId === void 0 || !isCurrent(operation)) return;
			if (!await refreshForFollow(workflowId, operation) || !isCurrent(operation)) return;
			await openLatestChat(workflowId, operation);
		} finally {
			dispatch({
				type: "finished",
				generation: operation.generation
			});
		}
	}
	function retireFollow() {
		dispatch({ type: "retired" });
	}
	function retryFollow() {
		const failed = state.value;
		if (failed.status === "failed") followTab(failed.workflow);
	}
	function activeWorkflowChanged(workflow) {
		const current = state.value;
		if (current.status !== "idle" && (current.status === "failed" || current.workflow.path !== workflow?.path)) retireFollow();
	}
	function userEngagementChanged(engaged) {
		if (engaged) retireFollow();
	}
	function isOpeningThread(id) {
		return state.value.status === "loading" && state.value.chat?.threadId === id;
	}
	function restoreChatWorkflow(workflowId, navigationCurrent) {
		const followed = state.value;
		if (followed.status !== "loading" || followed.chat?.threadId !== deps.currentThreadId()) return deps.restoreThreadWorkflow(workflowId, navigationCurrent);
		deps.adoptWorkflowTarget(followed.workflow, followed.chat.workflowId);
		deps.adoptRestoredWorkflowTab(followed.chat.workflowId);
		return true;
	}
	return {
		failure: computed(() => state.value.status === "failed" ? state.value.workflow : null),
		openingWorkflowName: computed(() => state.value.status === "loading" && state.value.workflow.path === deps.activeWorkflow()?.path ? state.value.workflow.filename : void 0),
		followTab,
		retireFollow,
		retryFollow,
		activeWorkflowChanged,
		userEngagementChanged,
		isOpeningThread,
		restoreChatWorkflow
	};
}
//#endregion
//#region src/workbench/extensions/agent/services/agent/agentEventSource.ts
function createAgentEventSource({ endpoint, getAuthParams, reconnectDelayMs = 1e3, maxReconnectDelayMs = 3e4, random = Math.random }) {
	const listeners = /* @__PURE__ */ new Set();
	const statusListeners = /* @__PURE__ */ new Set();
	let socket = null;
	let nextReconnectDelayMs = reconnectDelayMs;
	const reconnectTimer = useTimeoutFn(() => void connect(), () => nextReconnectDelayMs, { immediate: false });
	let connectGeneration = 0;
	let connecting = false;
	let failedConnects = 0;
	function eventUrl(authParams) {
		const url = new URL(endpoint, window.location.href);
		url.protocol = url.protocol === "https:" ? "wss:" : "ws:";
		for (const [name, value] of authParams) url.searchParams.set(name, value);
		return url.toString();
	}
	function notifyStatus(live) {
		statusListeners.forEach((listener) => listener(live));
	}
	function scheduleReconnect() {
		if (listeners.size === 0 || reconnectTimer.isPending.value) return;
		const ceiling = Math.min(maxReconnectDelayMs, reconnectDelayMs * 2 ** failedConnects);
		failedConnects += 1;
		nextReconnectDelayMs = ceiling * (.5 + .5 * random());
		reconnectTimer.start();
	}
	async function connect() {
		if (listeners.size === 0 || socket !== null || connecting) return;
		connecting = true;
		const generation = connectGeneration;
		let auth;
		try {
			auth = {
				ok: true,
				params: await getAuthParams()
			};
		} catch {
			auth = { ok: false };
		} finally {
			connecting = false;
		}
		if (generation !== connectGeneration) {
			connect();
			return;
		}
		if (listeners.size === 0) return;
		if (!auth.ok) {
			notifyStatus(false);
			scheduleReconnect();
			return;
		}
		if (auth.params === null) return;
		open(eventUrl(auth.params));
	}
	function open(url) {
		const current = new WebSocket(url);
		socket = current;
		let openedAt = null;
		current.addEventListener("open", () => {
			if (socket !== current) return;
			openedAt = Date.now();
			notifyStatus(true);
		});
		current.addEventListener("message", (event) => {
			if (socket !== current) return;
			failedConnects = 0;
			let frame = event.data;
			if (typeof event.data === "string") try {
				frame = JSON.parse(event.data);
			} catch {
				frame = event.data;
			}
			listeners.forEach((listener) => listener(frame));
		});
		current.addEventListener("error", () => {
			if (socket === current) current.close();
		});
		current.addEventListener("close", () => {
			if (socket !== current) return;
			if (openedAt !== null && Date.now() - openedAt >= maxReconnectDelayMs) failedConnects = 0;
			socket = null;
			notifyStatus(false);
			scheduleReconnect();
		});
	}
	function disconnect() {
		connectGeneration++;
		reconnectTimer.stop();
		const current = socket;
		socket = null;
		if (current === null) return;
		current.close();
		notifyStatus(false);
	}
	return {
		reconnect() {
			disconnect();
			failedConnects = 0;
			connect();
		},
		send(frame) {
			if (socket?.readyState !== WebSocket.OPEN) return false;
			socket.send(frame);
			return true;
		},
		subscribe(listener) {
			listeners.add(listener);
			connect();
			return () => {
				listeners.delete(listener);
				if (listeners.size === 0) disconnect();
			};
		},
		onStatus(listener) {
			statusListeners.add(listener);
			listener(socket?.readyState === WebSocket.OPEN);
			return () => statusListeners.delete(listener);
		}
	};
}
//#endregion
//#region src/workbench/extensions/agent/services/agent/agentIdentity.ts
var RETRY_BASE_MS = 1e3;
var RETRY_MAX_MS = 3e4;
/** Lookups tried before a transient failure is treated as a rejection. */
var MAX_ATTEMPTS = 8;
function resolveAgentIdentity(deps) {
	const state = ref({ status: "pending" });
	let inFlight = false;
	let stopped = false;
	let failures = 0;
	let retryTimer = null;
	let generation = 0;
	let exhausted = false;
	function cancelRetry() {
		if (retryTimer === null) return;
		clearTimeout(retryTimer);
		retryTimer = null;
	}
	function retryDelay() {
		return Math.min(RETRY_BASE_MS * 2 ** (failures - 1), RETRY_MAX_MS);
	}
	function scheduleRetry() {
		if (stopped) return;
		retryTimer = setTimeout(() => {
			retryTimer = null;
			attempt();
		}, retryDelay());
	}
	function settleFailure(error) {
		failures += 1;
		deps.onFailure(error);
		if (!deps.isRetryable(error)) {
			state.value = { status: "rejected" };
			return;
		}
		if (failures >= MAX_ATTEMPTS) {
			exhausted = true;
			state.value = { status: "rejected" };
			return;
		}
		scheduleRetry();
	}
	async function attempt() {
		if (stopped || inFlight || state.value.status !== "pending") return;
		cancelRetry();
		inFlight = true;
		const started = generation;
		try {
			const identity = await deps.getIdentity();
			if (started === generation) state.value = {
				status: "resolved",
				userId: identity.userId
			};
		} catch (error) {
			if (started === generation) settleFailure(error);
		} finally {
			if (started === generation) inFlight = false;
		}
	}
	function retryNow() {
		if (exhausted) {
			exhausted = false;
			failures = 0;
			state.value = { status: "pending" };
		} else if (retryTimer === null) return;
		attempt();
	}
	const stopListening = deps.onSocketOpen(retryNow);
	attempt();
	return {
		state: readonly(state),
		reset() {
			generation += 1;
			state.value = { status: "pending" };
			failures = 0;
			exhausted = false;
			inFlight = false;
			cancelRetry();
			attempt();
		},
		stop() {
			stopped = true;
			generation += 1;
			stopListening();
			cancelRetry();
		}
	};
}
//#endregion
//#region src/workbench/extensions/agent/stores/agent/agentChatHistoryStore.ts
function startOfLocalDay(now) {
	const date = new Date(now);
	date.setHours(0, 0, 0, 0);
	return date.getTime();
}
function groupSessionsByRecency(sessions, activeId, now) {
	const startToday = startOfLocalDay(now);
	const startYesterday = startOfLocalDay(startToday - 1);
	const groups = {
		current: [],
		today: [],
		yesterday: [],
		earlier: []
	};
	const ordered = [...sessions].sort((a, b) => b.updatedAt - a.updatedAt);
	for (const session of ordered) if (session.id === activeId) groups.current.push(session);
	else if (session.updatedAt >= startToday) groups.today.push(session);
	else if (session.updatedAt >= startYesterday) groups.yesterday.push(session);
	else groups.earlier.push(session);
	return groups;
}
var useAgentChatHistoryStore = defineStore("agentChatHistory", () => {
	const sessions = ref([]);
	const activeId = ref(null);
	const now = useTimestamp({ interval: 6e4 });
	const workspaceId = getWorkspaceId();
	clearLegacyAgentStorage();
	const customTitles = useLocalStorage(StorageKeys.agentChatTitles(workspaceId), {});
	const deletedIds = useLocalStorage(StorageKeys.agentDeletedThreads(workspaceId), []);
	const titled = computed(() => sessions.value.map((session) => {
		const custom = customTitles.value[session.id];
		return custom === void 0 ? session : {
			...session,
			title: custom
		};
	}));
	const grouped = computed(() => groupSessionsByRecency(titled.value, activeId.value, now.value));
	function titleFor(id) {
		return id === null ? void 0 : customTitles.value[id];
	}
	function rename(id, title) {
		const trimmed = title.trim();
		if (trimmed === "") return;
		customTitles.value = {
			...customTitles.value,
			[id]: trimmed
		};
	}
	function remove(id) {
		sessions.value = sessions.value.filter((item) => item.id !== id);
		const { [id]: _removed, ...rest } = customTitles.value;
		customTitles.value = rest;
		if (!deletedIds.value.includes(id)) deletedIds.value = [...deletedIds.value, id];
		if (activeId.value === id) activeId.value = null;
	}
	function replaceAll(next) {
		sessions.value = next.filter((session) => !deletedIds.value.includes(session.id));
	}
	function setActive(id) {
		activeId.value = id;
	}
	return {
		sessions,
		activeId,
		grouped,
		titleFor,
		rename,
		remove,
		replaceAll,
		setActive
	};
});
//#endregion
//#region src/workbench/extensions/agent/stores/agent/agentNodeDefinitionRefreshStore.ts
function isSuccessfulRestart(event) {
	return event.type === "agent_tool_call" && event.data.tool_name === "restart_comfyui" && event.data.status === "success";
}
function isSuccessfulCatalogRefresh(event) {
	return event.type === "agent_tool_call" && event.data.tool_name === "refresh_catalog" && event.data.status === "success";
}
async function refreshNodeDefinitions(errorType) {
	try {
		await useCommandStore().execute("Comfy.RefreshNodeDefinitions", { errorHandler: (error) => {
			throw error;
		} });
		return true;
	} catch (error) {
		reportError(error, {
			surface: "agent",
			errorType,
			level: "warning"
		});
		return false;
	}
}
async function reloadWorkflowWithoutRejecting() {
	await useWorkflowService().reloadCurrentWorkflow().catch(() => void 0);
}
/**
* How far apart a successful restart and a ComfyUI `/ws` reconnect may be for
* the reconnect to count as that restart. The turn can run on after the tool
* reports success, and the agent then allows ComfyUI five minutes to go down
* and come back.
*/
var RESTART_WINDOW_MS = 6e5;
/**
* Refreshes node definitions and the open workflow when ComfyUI reconnects
* after the agent restarts it. The agent reports the restart before ComfyUI
* goes down, but the report and the reconnect arrive on different sockets, so
* either may come first: every reconnect within the window refreshes,
* including one that came just before the report. An unrelated reconnect in
* the window refreshes too, which is harmless, and leaves the restart's own
* reconnect to refresh again.
*/
var useAgentNodeDefinitionRefreshStore = defineStore("agentNodeDefinitionRefresh", () => {
	let restartedAt = -Infinity;
	let reconnectedAt = -Infinity;
	let refreshQueued = false;
	let catalogRefreshQueued = false;
	let queue = Promise.resolve();
	async function refresh() {
		refreshQueued = false;
		if (await refreshNodeDefinitions("failure_refreshing_node_definitions_after_agent_restart")) await reloadWorkflowWithoutRejecting();
	}
	async function refreshCatalog() {
		catalogRefreshQueued = false;
		await refreshNodeDefinitions("failure_refreshing_node_definitions_after_agent_catalog_refresh");
	}
	function enqueueRefresh() {
		if (refreshQueued) return;
		refreshQueued = true;
		queue = queue.then(refresh).catch((error) => {
			reportError(error, {
				surface: "agent",
				errorType: "failure_running_agent_node_definition_refresh"
			});
		});
	}
	function enqueueCatalogRefresh() {
		if (catalogRefreshQueued) return;
		catalogRefreshQueued = true;
		queue = queue.then(refreshCatalog).catch((error) => {
			reportError(error, {
				surface: "agent",
				errorType: "failure_running_agent_node_definition_refresh"
			});
		});
	}
	function refreshIfRestartNearby() {
		if (Math.abs(reconnectedAt - restartedAt) <= RESTART_WINDOW_MS) enqueueRefresh();
	}
	function observeAgentEvent(event) {
		if (isSuccessfulCatalogRefresh(event)) {
			enqueueCatalogRefresh();
			return;
		}
		if (!isSuccessfulRestart(event)) return;
		restartedAt = Date.now();
		refreshIfRestartNearby();
	}
	useEventListener(api, "reconnected", () => {
		reconnectedAt = Date.now();
		refreshIfRestartNearby();
	});
	return { observeAgentEvent };
});
//#endregion
//#region src/workbench/extensions/agent/crdt/agentSubgraphDefinitions.ts
/**
* Root map the op layer mints `definitions.subgraphs` into, keyed by
* definition id. `@comfyorg/comfy-multi-player` reads it through its private
* `definitionsMap()`, which is not part of the package's public surface.
*/
var DEFINITIONS_ROOT = "definitions";
/** Mint-order registers kept beside the interior `nodes`/`links` maps. */
var NODE_ORDER = "node_order";
var LINK_ORDER = "link_order";
/**
* Per-node bookkeeping the op layer's applier stamps on every node record
* (`NODE_INCARNATION_KEY`, not exported by the package). Its own `project()`
* drops it; so does this reader.
*/
var NODE_INCARNATION = "__incarnation";
/** The op layer reserves double-underscore definition keys for bookkeeping. */
function isDefinitionBookkeeping(key) {
	return key.startsWith("__");
}
/**
* Own-key filter shared by both record readers. Assigning through
* `record['__proto__']` swaps the record's prototype, so a document carrying
* that key would hand LiteGraph an object whose inherited keys it never wrote.
*/
function isReadableKey(key) {
	return key !== "__proto__";
}
function withoutUnsafeKeys(value) {
	if (Array.isArray(value)) return value.map(withoutUnsafeKeys);
	if (typeof value !== "object" || value === null) return value;
	const prototype = Object.getPrototypeOf(value);
	if (prototype !== Object.prototype && prototype !== null) return value;
	return Object.fromEntries(Object.entries(value).flatMap(([key, nested]) => isReadableKey(key) ? [[key, withoutUnsafeKeys(nested)]] : []));
}
/**
* A value slot's JSON view. Every shared type, and a subdocument, answers
* `toJSON()`; `structuredClone` throws on all of them, and this reader runs
* as a bare argument inside the follower's frame reconcile, where one throw
* would stall every node on the canvas. The package only mints maps and
* arrays; the rest arrive through a doc host folding in a raw update.
*/
function plain$1(value) {
	if (value instanceof AbstractType || value instanceof Doc) return withoutUnsafeKeys(value.toJSON());
	return withoutUnsafeKeys(structuredClone(value));
}
__name(plain$1, "plain");
function withoutDefinitionBookkeeping(source) {
	if (typeof source !== "object" || source === null || Array.isArray(source)) return source;
	return Object.fromEntries(Object.entries(source).flatMap(([key, value]) => {
		if (isDefinitionBookkeeping(key)) return [];
		if (key !== "definitions") return [[key, value]];
		return [[key, withoutNestedDefinitionBookkeeping(value)]];
	}));
}
function withoutNestedDefinitionBookkeeping(source) {
	if (typeof source !== "object" || source === null || Array.isArray(source)) return source;
	return Object.fromEntries(Object.entries(source).map(([key, value]) => [key, key === "subgraphs" && Array.isArray(value) ? value.map(withoutDefinitionBookkeeping) : value]));
}
/**
* Register entries that name a record, first occurrence only, matching what
* LiteGraph keeps when it normalizes a definition.
*/
function orderedKeys(register, map) {
	const order = Array.isArray(register) ? register.filter((key) => typeof key === "string") : [...map.keys()].sort();
	return [...new Set(order)].filter((key) => map.has(key));
}
/**
* Interior node record → serialised node. Named widget values go to
* `widgets_values_named`, the only name-keyed slot `LGraphNode.configure()`
* reads; the opaque positional form stays `widgets_values`. A record whose
* `widgets` is not a map cannot be read and is skipped, as the package's
* `tryProjectNode()` skips it.
*/
function readInteriorNode(source) {
	if (!(source instanceof YMap)) return null;
	if (source.has("widgets") && !(source.get("widgets") instanceof YMap)) return null;
	const node = {};
	source.forEach((value, key) => {
		if (key === NODE_INCARNATION || key === "__widgets_form") return;
		if (!isReadableKey(key)) return;
		if (key === "widgets" && value instanceof YMap) node.widgets_values_named = Object.fromEntries([...value.entries()].flatMap(([name, widgetValue]) => isReadableKey(name) ? [[name, plain$1(widgetValue)]] : []));
		else if (key === "__widgets_opaque") node.widgets_values = plain$1(value);
		else node[key] = plain$1(value);
	});
	return node;
}
function isSkippedDefinitionKey(key) {
	return key === NODE_ORDER || key === LINK_ORDER || isDefinitionBookkeeping(key) || !isReadableKey(key);
}
function projectDefinitionNodes(source, nodes) {
	return orderedKeys(source.get(NODE_ORDER), nodes).flatMap((id) => {
		const node = readInteriorNode(nodes.get(id));
		return node ? [node] : [];
	});
}
function projectDefinitionLinks(source, links) {
	return orderedKeys(source.get(LINK_ORDER), links).map((id) => plain$1(links.get(id)));
}
function projectDefinitionEntry(source, key, value, excludedDefinitionIds) {
	if (isSkippedDefinitionKey(key)) return [];
	if (key === "nodes" && value instanceof YMap) return [[key, projectDefinitionNodes(source, value)]];
	if (key === "links" && value instanceof YMap) return [[key, projectDefinitionLinks(source, value)]];
	if (key === "definitions") {
		if (value instanceof YMap) return [[key, readNestedDefinitions(value, excludedDefinitionIds)]];
		return [[key, withoutNestedDefinitionBookkeeping(plain$1(value))]];
	}
	return [[key, plain$1(value)]];
}
function projectSubgraphDefinition(source, excludedDefinitionIds) {
	return Object.fromEntries([...source.entries()].flatMap(([key, value]) => projectDefinitionEntry(source, key, value, excludedDefinitionIds)));
}
function isRecord(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function hasSafeInputs(value) {
	return value === void 0 || Array.isArray(value) && value.every((input) => isRecord(input) && typeof input.name === "string" && (input.linkIds === void 0 || Array.isArray(input.linkIds)));
}
function hasSafeNodes(value) {
	return value === void 0 || Array.isArray(value) && value.every((node) => isRecord(node) && (node.inputs === void 0 || Array.isArray(node.inputs) && node.inputs.every(isRecord)));
}
function hasSafeLinks(value) {
	return value === void 0 || Array.isArray(value) && value.every(isRecord);
}
function hasSafeNestedDefinitions(value) {
	if (value === void 0) return true;
	if (!isRecord(value)) return false;
	const nested = value.subgraphs;
	return nested === void 0 || Array.isArray(nested) && nested.every(isSafeDefinition);
}
function isSafeDefinition(value) {
	return isRecord(value) && hasSafeInputs(value.inputs) && hasSafeNodes(value.nodes) && hasSafeLinks(value.links) && hasSafeNestedDefinitions(value.definitions);
}
function isExcludedDefinition(source, excludedDefinitionIds) {
	const id = plain$1(source.get("id"));
	return typeof id === "string" && excludedDefinitionIds.has(id);
}
function readNestedDefinitions(source, excludedDefinitionIds) {
	const definitions = {};
	source.forEach((value, key) => {
		if (key === "subgraph_order" || !isReadableKey(key)) return;
		if (key === "subgraphs" && value instanceof YMap) definitions.subgraphs = orderedKeys(source.get("subgraph_order"), value).flatMap((id) => {
			const definition = value.get(id);
			if (definition instanceof YMap && isExcludedDefinition(definition, excludedDefinitionIds)) return [];
			return [definition instanceof YMap ? readDefinition(definition, excludedDefinitionIds) : null];
		});
		else definitions[key] = plain$1(value);
	});
	return definitions;
}
function readDefinition(source, excludedDefinitionIds) {
	const definition = projectSubgraphDefinition(source, excludedDefinitionIds);
	return isSafeDefinition(definition) ? definition : null;
}
function readField(source, key) {
	if (source instanceof YMap) return source.get(key);
	if (typeof source !== "object" || source === null || !isReadableKey(key) || !Object.hasOwn(source, key)) return;
	return Reflect.get(source, key);
}
function readList(source) {
	if (source instanceof YArray) return source.toArray();
	return Array.isArray(source) ? source : [];
}
function collectDefinitionIds(source, ids) {
	const pending = [source];
	while (pending.length > 0) {
		const definition = pending.pop();
		const id = plain$1(readField(definition, "id"));
		if (typeof id === "string") ids.push(id);
		const container = readField(definition, "definitions");
		const nested = readField(container, "subgraphs");
		const definitions = nested instanceof YMap ? orderedKeys(readField(container, "subgraph_order"), nested).map((key) => nested.get(key)) : readList(nested);
		for (let index = definitions.length - 1; index >= 0; index--) pending.push(definitions[index]);
	}
}
function definitionsMap(doc) {
	const root = doc.share.get(DEFINITIONS_ROOT);
	if (!root) return null;
	if (root instanceof YMap) return root;
	if (root.constructor !== AbstractType) return null;
	return doc.getMap(DEFINITIONS_ROOT);
}
/** The definitions root a deep observer can attach to. */
function definitionsObserverRoot(doc) {
	return doc.getMap(DEFINITIONS_ROOT);
}
function readInteriorWidgets(source) {
	const widgets = source.get("widgets");
	if (widgets instanceof YMap) return Object.fromEntries([...widgets.entries()].flatMap(([name, value]) => isReadableKey(name) ? [[name, plain$1(value)]] : []));
	const opaque = source.get(OPAQUE_WIDGETS_KEY);
	if (opaque !== void 0) {
		const value = plain$1(opaque);
		return Array.isArray(value) ? value : void 0;
	}
}
function collectInteriorWidgets(source, into) {
	const id = plain$1(source.get("id"));
	const nodes = source.get("nodes");
	if (typeof id === "string" && nodes instanceof YMap) {
		const interiors = /* @__PURE__ */ new Map();
		for (const nodeId of orderedKeys(source.get(NODE_ORDER), nodes)) {
			const node = nodes.get(nodeId);
			if (node instanceof YMap) interiors.set(nodeId, readInteriorWidgets(node));
		}
		into.set(id, interiors);
	}
	const nested = source.get("definitions");
	if (nested instanceof YMap) {
		const subgraphs = nested.get("subgraphs");
		if (subgraphs instanceof YMap) subgraphs.forEach((value) => {
			if (value instanceof YMap) collectInteriorWidgets(value, into);
		});
	}
}
/** Every definition's interior widget values, in mint order. */
function readSubgraphInteriorWidgets(doc) {
	const result = /* @__PURE__ */ new Map();
	const root = definitionsMap(doc);
	if (!root) return result;
	root.forEach((value) => {
		if (value instanceof YMap) collectInteriorWidgets(value, result);
	});
	return result;
}
function allSubgraphDefinitions(definitions) {
	return [...definitions, ...definitions.flatMap((definition) => allSubgraphDefinitions(definition.definitions?.subgraphs ?? []))];
}
function readSubgraphDefinitionIds(doc) {
	const ids = [];
	const root = definitionsMap(doc);
	if (!root) return ids;
	root.forEach((value) => {
		if (value instanceof YMap) collectDefinitionIds(value, ids);
	});
	return ids;
}
/**
* Project the subgraph definitions the op layer minted into the follower doc
* back to the `ExportedSubgraph` shape `LGraph.createSubgraphs()` consumes,
* interior nodes and links in mint order.
*
* Mirrors the package's own `projectDefinition()` so that what the agent
* seeded and what the canvas instantiates agree byte-for-byte on structure.
* Excluded IDs are checked before projection so their bodies are not copied.
*/
function readSubgraphDefinitions(doc, excludedDefinitionIds = /* @__PURE__ */ new Set()) {
	const definitions = [];
	const root = definitionsMap(doc);
	if (!root) return definitions;
	root.forEach((value) => {
		if (!(value instanceof YMap)) return;
		if (isExcludedDefinition(value, excludedDefinitionIds)) return;
		const definition = readDefinition(value, excludedDefinitionIds);
		if (definition) definitions.push(definition);
	});
	return definitions;
}
/** Null when the document holds no such node. */
function readDocPromotedWidgets(doc, nodeId) {
	const node = nodesMap(doc).get(nodeId);
	if (!(node instanceof YMap)) return null;
	const stored = node.get(OPAQUE_WIDGETS_KEY);
	return {
		valueCount: stored === void 0 ? 0 : stored instanceof YArray || Array.isArray(stored) ? stored.length : null,
		declaredNames: declaredInputNames(doc, String(node.get("type") ?? "")),
		promotedNames: promotedInputNames(doc, node, String(node.get("type") ?? ""))
	};
}
function namedInputs(source) {
	const inputs = source instanceof YArray ? source.toArray() : Array.isArray(source) ? source : null;
	if (inputs === null) return null;
	const named = [];
	for (const input of inputs) {
		const name = readField(input, "name");
		if (typeof name !== "string") return null;
		named.push([name, input]);
	}
	return named;
}
function promotedInputNames(doc, node, definitionId) {
	const definition = definitionsMap(doc)?.get(definitionId);
	if (!(definition instanceof YMap)) return void 0;
	const declared = namedInputs(definition.get("inputs"));
	const instance = namedInputs(node.get("inputs"));
	if (declared === null || instance === null) return null;
	const instanceByName = new Map(instance);
	return declared.flatMap(([name]) => {
		const input = instanceByName.get(name);
		return input === void 0 || readField(input, "widget") !== void 0 ? [name] : [];
	});
}
function declaredInputNames(doc, definitionId) {
	const definition = definitionsMap(doc)?.get(definitionId);
	if (!(definition instanceof YMap)) return [];
	return namedInputs(definition.get("inputs"))?.map(([name]) => name) ?? [];
}
function toBounds(rect) {
	return {
		left: rect.x,
		top: rect.y,
		right: rect.x + rect.width,
		bottom: rect.y + rect.height
	};
}
function hull(rects) {
	return rects.map(toBounds).reduce((a, b) => ({
		left: Math.min(a.left, b.left),
		top: Math.min(a.top, b.top),
		right: Math.max(a.right, b.right),
		bottom: Math.max(a.bottom, b.bottom)
	}));
}
function intersects(a, b) {
	return a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom;
}
function collides(existing, incoming) {
	const existingBounds = existing.map(toBounds);
	return incoming.some((rect) => {
		const bounds = toBounds(rect);
		return existingBounds.some((other) => intersects(bounds, other));
	});
}
/** Returns a batch translation, or null when its coordinates stay unchanged. */
function placementOffset(input) {
	if (input.existing.length === 0 || input.incoming.length === 0) return null;
	const anchor = hull(input.existing);
	const batch = hull(input.incoming);
	const offset = {
		dx: anchor.right + 80 - batch.left,
		dy: anchor.top - batch.top
	};
	if (input.moveCollisions && collides(input.existing, input.incoming)) return offset;
	if (intersects({
		left: anchor.left - 600,
		top: anchor.top - 600,
		right: anchor.right + 600,
		bottom: anchor.bottom + 600
	}, batch)) return null;
	if (input.viewport && intersects(toBounds(input.viewport), batch)) return null;
	return offset;
}
//#endregion
//#region src/workbench/extensions/agent/crdt/liveGraphApplier.ts
/**
* Node-map keys mirrored onto a live node when the document edits them.
* Structural keys (`inputs`, `outputs`, `pos`, `size`, widget storage) are
* excluded: slots follow links, layout stays local.
*/
var SYNCED_NODE_FIELDS = /* @__PURE__ */ new Set([
	"title",
	"mode",
	"flags",
	"properties",
	"color",
	"bgcolor",
	"boxcolor",
	"shape",
	"showAdvanced"
]);
var SYNCED_APPEARANCE_FIELDS = [
	"color",
	"bgcolor",
	"boxcolor",
	"shape",
	"showAdvanced"
];
var AGENT_APPLY_TAGS = {
	subsystem: "agent-crdt",
	layer: "graph-api"
};
function plain(value) {
	if (value instanceof YMap || value instanceof YArray) return value.toJSON();
	return structuredClone(value);
}
/**
* `flags.ghost` marks a node the user is still placing; the snapshot minted
* while placement is live carries it, but the flag is local interaction
* state, never document state.
*/
function syncedFlags(flags) {
	const { ghost: _ghost, ...rest } = flags ?? {};
	return rest;
}
var zDocSlot = object({
	name: string(),
	type: union$1([
		string(),
		array(string()).nonempty(),
		number()
	])
}).passthrough();
var zWidgetRecord = record(string(), unknown()).refine((record) => !Object.hasOwn(record, "length"), "has a length key");
var zNodeProperty = union$1([
	string(),
	number(),
	boolean(),
	object({}).passthrough(),
	array(unknown()),
	_null()
]);
/**
* The shape a document node must have before it can configure a live node.
* Agent-minted nodes are sparse, so geometry and mode fall back to defaults;
* slot and property shapes are enforced because `LGraphNode.configure` maps
* over them without checking. Slot link references are not validated because
* `detachSerialisedLinks` discards them; links come from the links map.
* Widget values live in the node's `widgets` map, never in `widgets_values`.
*/
var zDocNodeFields = zComfyNode.partial({
	pos: true,
	size: true,
	flags: true,
	order: true,
	mode: true
}).omit({ widgets_values: true }).extend({
	id: string(),
	type: string().min(1),
	title: string().optional(),
	inputs: array(zDocSlot).optional(),
	outputs: array(zDocSlot).optional(),
	properties: record(string(), zNodeProperty.optional()).optional(),
	[OPAQUE_WIDGETS_KEY]: zWidgetRecord.optional()
});
var MAX_SHAPED_ELEMENTS = 16;
var MAX_DIAGNOSTIC_CHARS = 1024;
var OMISSION_MARKER_CHARS = 8;
function elementShape(value) {
	if (value === null) return "null";
	if (Array.isArray(value)) return "array";
	return typeof value;
}
function valueShape(value) {
	if (value === null) return "null";
	if (Array.isArray(value)) {
		const shaped = value.slice(0, MAX_SHAPED_ELEMENTS).map(elementShape);
		const omitted = value.length - shaped.length;
		if (omitted > 0) shaped.push(`+${omitted}`);
		return `array:${value.length}[${shaped.join(",")}]`;
	}
	if (typeof value === "object") return `object:${Object.keys(value).length}`;
	return typeof value;
}
function diagnosticStrings(value, path = []) {
	if (typeof value === "string") return [{
		path,
		value
	}];
	if (Array.isArray(value)) return value.flatMap((entry, index) => diagnosticStrings(entry, [...path, index]));
	if (!isPlainObject(value)) return [];
	return Object.entries(value).flatMap(([key, entry]) => diagnosticStrings(entry, [...path, key]));
}
function diagnosticPath(path) {
	return JSON.stringify(path);
}
function replaceDiagnosticValue(value, path, replacements) {
	if (typeof value === "string") return replacements.get(diagnosticPath(path)) ?? value;
	if (Array.isArray(value)) return value.map((entry, index) => replaceDiagnosticValue(entry, [...path, index], replacements));
	if (!isPlainObject(value)) return value;
	return Object.fromEntries(Object.entries(value).map(([key, entry]) => [key, replaceDiagnosticValue(entry, [...path, key], replacements)]));
}
function replaceDiagnosticStrings(context, replacements) {
	return Object.fromEntries(Object.entries(context).map(([key, value]) => [key, replaceDiagnosticValue(value, [key], replacements)]));
}
function boundedContext(context) {
	const shortestFirst = diagnosticStrings(context).sort((left, right) => left.value.length - right.value.length);
	let remaining = MAX_DIAGNOSTIC_CHARS;
	const truncated = /* @__PURE__ */ new Map();
	for (const { path, value } of shortestFirst) {
		if (value.length <= remaining) {
			remaining -= value.length;
			continue;
		}
		const kept = value.slice(0, Math.max(0, remaining - OMISSION_MARKER_CHARS));
		truncated.set(diagnosticPath(path), kept === "" ? "" : `${kept}+${value.length - kept.length}`);
		remaining = 0;
	}
	if (truncated.size === 0) return context;
	return replaceDiagnosticStrings(context, truncated);
}
/** `absent` when the path's own key is missing, so it is not read as `undefined`. */
function shapeAtPath(root, path) {
	let cursor = root;
	for (const [depth, key] of path.entries()) {
		if (cursor === null || typeof cursor !== "object") return "unreachable";
		if (!Object.hasOwn(cursor, key)) return depth === path.length - 1 ? "absent" : "unreachable";
		cursor = Reflect.get(cursor, key);
	}
	return valueShape(cursor);
}
function issueShapes(fields, error) {
	return error.issues.map((issue) => `${issue.path.join(".")} ${issue.code} ${shapeAtPath(fields, issue.path)}`).join("; ");
}
function actorKind(actor) {
	const kind = typeof actor === "string" ? actor.split(":", 1)[0] : "";
	return kind === "agent" || kind === "human" ? kind : "unknown";
}
function nodeProducer(doc, id) {
	let stamps;
	try {
		stamps = readStamps(doc);
	} catch {
		return { origin: "unreadable" };
	}
	const key = JSON.stringify(["node", id]);
	if (!Object.hasOwn(stamps, key)) return { origin: "unstamped" };
	const stamp = stamps[key];
	if (!Array.isArray(stamp)) return { origin: "unreadable" };
	const [version, actor, opId] = stamp;
	if (typeof version !== "number" || typeof opId !== "string") return { origin: "unreadable" };
	return {
		origin: "operation",
		actorKind: actorKind(actor),
		opId,
		version
	};
}
function readDocNode(doc, id) {
	const source = nodesMap(doc).get(id);
	if (!(source instanceof YMap)) return null;
	const fields = { id };
	let widgets;
	let record;
	source.forEach((value, key) => {
		if (key === "widgets" && value instanceof YMap) widgets = value.toJSON();
		else if (key === "__widgets_opaque") {
			const opaque = plain(value);
			if (Array.isArray(opaque)) widgets = opaque;
			else if (isPlainObject(opaque)) record = opaque;
		} else if (key !== "id" && key !== "__widgets_form") fields[key] = plain(value);
	});
	if (widgets === void 0 && record !== void 0) fields[OPAQUE_WIDGETS_KEY] = record;
	const parsed = zDocNodeFields.safeParse(fields);
	if (!parsed.success) {
		const { error } = parsed;
		return {
			malformed: error.issues.map((issue) => `${issue.path.join(".")} ${issue.message}`).join("; "),
			discriminate() {
				return {
					classType: typeof fields.type === "string" ? fields.type : void 0,
					valueShapes: issueShapes(fields, error),
					producer: nodeProducer(doc, id)
				};
			}
		};
	}
	const { pos = [0, 0], size = [0, 0], flags, order = 0, mode = 0, [OPAQUE_WIDGETS_KEY]: widgetRecord, ...rest } = parsed.data;
	const serialised = {
		...rest,
		pos,
		size,
		flags: syncedFlags(flags),
		order,
		mode
	};
	const node = {
		id,
		type: serialised.type,
		serialised
	};
	return widgetRecord === void 0 ? {
		...node,
		widgets
	} : {
		...node,
		widgetRecord
	};
}
function readDocLink(doc, key) {
	const raw = linksMap(doc).get(key);
	const tuple = raw instanceof YArray ? raw.toArray() : raw;
	const id = parseLinkId(key);
	if (id === void 0 || id < 0 || !isLinkTuple(tuple, id)) return null;
	return {
		id,
		origin: String(tuple[1]),
		originSlot: Number(tuple[2]),
		target: String(tuple[3]),
		targetSlot: Number(tuple[4])
	};
}
/** `[id, origin, originSlot, target, targetSlot, type]` with both endpoints present and integer slots. */
function isLinkTuple(tuple, id) {
	if (!Array.isArray(tuple) || tuple.length < 5) return false;
	const [tupleId, origin, originSlot, target, targetSlot] = tuple;
	return tupleId === id && origin != null && target != null && Number.isInteger(Number(originSlot)) && Number.isInteger(Number(targetSlot));
}
/**
* A document node's slot names in document order (an unnamed slot record is
* `undefined` at its position), or null when the document has no such node
* or no slot list for it.
*/
function readDocSlotNames(doc, nodeId, kind) {
	const slots = nodesMap(doc).get(nodeId)?.get(kind);
	const list = slots instanceof YArray ? slots.toJSON() : slots;
	if (!Array.isArray(list)) return null;
	return list.map((entry) => {
		const name = typeof entry === "object" && entry !== null && "name" in entry ? entry.name : void 0;
		return typeof name === "string" ? name : void 0;
	});
}
function readDocSlotName(doc, nodeId, kind, slot) {
	return readDocSlotNames(doc, nodeId, kind)?.[slot];
}
/** The document's value for a node's named widget, or undefined when it holds none. */
function readDocWidgetValue(doc, nodeId, widget) {
	const widgets = nodesMap(doc).get(nodeId)?.get("widgets");
	return widgets instanceof YMap ? plain(widgets.get(widget)) : void 0;
}
function docLinksIncident(doc, nodeId) {
	const links = [];
	linksMap(doc).forEach((_, key) => {
		const link = readDocLink(doc, key);
		if (link && (link.origin === nodeId || link.target === nodeId)) links.push(link);
	});
	return links;
}
/**
* Runs `fn` so that the first link it mints receives `id`. The live graph's
* link counter is monotonic; seeding it one below the document id lets
* `connect` mint the document's id through its normal path, and the counter
* is restored to the higher of the two afterwards so later local mints never
* collide with ids the document has already handed out.
*/
function withLinkId(graph, id, fn) {
	if (graph.links.has(id)) return fn();
	const { state } = graph;
	const previous = state.lastLinkId;
	state.lastLinkId = toLinkId(id - 1);
	try {
		return fn();
	} finally {
		state.lastLinkId = toLinkId(Math.max(previous, state.lastLinkId));
	}
}
function serializableWidgets(node) {
	return (node.widgets ?? []).filter((widget) => widget.serialize !== false);
}
function supportsDynamicWidgetOverflow(node) {
	const inputs = node.constructor.nodeData?.inputs;
	return inputs !== void 0 && Object.values(inputs).some((spec) => inputSpecTree(spec).some(({ type }) => type === "COMFY_DYNAMICCOMBO_V3"));
}
var OVERFLOW_WIDGET_NAME_RE = /^_extra_(0|[1-9]\d*)$/;
function overflowWidgetIndex(name) {
	const match = OVERFLOW_WIDGET_NAME_RE.exec(name);
	return match ? Number(match[1]) : null;
}
function documentWidget(node, name) {
	return node.widgets?.find((widget) => widget.name === name) ?? overflowWidget(node, name);
}
/** The live widget an overflow alias addresses, if the node has that position. */
function overflowWidget(node, name) {
	if (!supportsDynamicWidgetOverflow(node)) return void 0;
	const overflowIndex = overflowWidgetIndex(name);
	return overflowIndex === null ? void 0 : serializableWidgets(node).at(overflowIndex);
}
/**
* Whether `name` is an overflow alias for a position the document also
* addresses by the live widget's real name; the named entry wins. Judged
* against the node's whole document map so an alias-only partial frame cannot
* overwrite the named value.
*/
function supersededOverflowAlias(node, name, document) {
	if (document === void 0 || Array.isArray(document)) return false;
	if (node.widgets?.some((widget) => widget.name === name)) return false;
	const positional = overflowWidget(node, name);
	return positional !== void 0 && Object.hasOwn(document, positional.name);
}
/** Rows the document carries values for under the DynamicGroup `name`. */
function documentedRowCount(name, widgets) {
	if (widgets === void 0 || Array.isArray(widgets)) return 0;
	const prefix = `${name}.`;
	const rows = /* @__PURE__ */ new Set();
	for (const key of Object.keys(widgets)) if (key.startsWith(prefix)) rows.add(key.slice(prefix.length).split(".")[0]);
	return rows.size;
}
function deferredRowCounts(node, constructed, widgets) {
	if (widgets === void 0 || Array.isArray(widgets) || supportsDynamicWidgetOverflow(node)) return /* @__PURE__ */ new Set();
	return new Set(constructed.filter((widget) => isDynamicGroupController(widget) && Object.hasOwn(widgets, widget.name)).map((widget) => widget.name));
}
/**
* Document entries for widgets that only exist after `configure`: aliases past
* the constructed list, and names the constructor did not build but the node
* now serializes. `constructed` is the serializable list from before
* `configure`; a name that still matches nothing is dropped without a report.
*/
function mountedWidgetValues(node, widgets, constructed, constructedNames, deferred) {
	if (widgets === void 0 || Array.isArray(widgets)) return void 0;
	const mounted = Object.entries(widgets).filter(([name]) => {
		const index = overflowWidgetIndex(name);
		return index === null ? !constructedNames.has(name) || deferred.has(name) : overflowWidget(node, name) === void 0 || index >= constructed.length;
	});
	return mounted.length === 0 ? void 0 : Object.fromEntries(mounted);
}
/**
* The document stores an ordinary node's widget values by name; `configure`
* restores them positionally over the node's serializable widgets, so project
* the named map into that order, keeping the constructor default for any
* widget the document does not mention.
*/
function positionalWidgetValues(node, widgets, deferred) {
	if (widgets === void 0) return void 0;
	if (Array.isArray(widgets)) return widgets.map((value) => isWidgetValue(value) ? value : void 0);
	return serializableWidgets(node).map((widget, index) => {
		if (deferred.has(widget.name)) return widget.value;
		const alias = `_extra_${index}`;
		const name = Object.hasOwn(widgets, widget.name) ? widget.name : overflowWidget(node, alias) === widget && Object.hasOwn(widgets, alias) ? alias : widget.name;
		const value = widgets[name];
		return Object.hasOwn(widgets, name) && isWidgetValue(value) ? value : widget.value;
	});
}
function missingNode(docNode) {
	const node = new LGraphNode(docNode.serialised.title || docNode.type || "Missing Node", docNode.type);
	node.has_errors = true;
	return node;
}
/**
* A document may carry a size smaller than the node's widgets need (or none
* at all). Every human path — `loadGraphData`, which the undo stack restores
* through, and interactive resize — floors the size at `computeSize()`, so a
* node born below that floor snapshots at one size and restores at another,
* which the change tracker then records as a fresh edit.
*/
function floorSizeToContent(node) {
	const [minWidth, minHeight] = node.computeSize();
	const [width, height] = node.size;
	if (width >= minWidth && height >= minHeight) return;
	node.setSize([Math.max(width, minWidth), Math.max(height, minHeight)]);
}
var LiveGraphApplier = class {
	deps;
	reported = /* @__PURE__ */ new Set();
	interiorIds = /* @__PURE__ */ new Map();
	failureCounts = [];
	constructor(deps) {
		this.deps = deps;
	}
	/** Applies the collected changes of one delivered frame to the live graph. */
	applyChanges(doc, changes, context, mode = "merge") {
		const graph = this.deps.getGraph();
		if (!graph) return {
			createdNodeIds: [],
			failureCount: 0
		};
		this.failureCounts.push(0);
		try {
			return this.write(graph, context, () => {
				if (mode === "replace") this.removeAbsent(graph, doc, context);
				const created = [];
				const touchedNodes = /* @__PURE__ */ new Set();
				this.registerDefinitions(graph, doc);
				for (const [id, change] of changes.nodes) {
					if (change === "delete") {
						this.try(context, () => this.deleteNode(graph, id));
						continue;
					}
					touchedNodes.add(id);
					this.try(context, () => {
						const result = this.upsertNode(graph, doc, id, mode);
						if (result === "created") created.push(toNodeId(id));
						if (result === "created" || result === "recreated") for (const link of docLinksIncident(doc, id)) this.connectLink(graph, doc, link);
					});
				}
				this.deleteGroups(graph, changes.removedGroups, context);
				for (const [id, keys] of changes.resyncNodes) {
					if (touchedNodes.has(id)) continue;
					this.try(context, () => this.syncFields(graph, doc, id, keys));
				}
				for (const [id, names] of changes.widgets) {
					if (touchedNodes.has(id)) continue;
					this.try(context, () => this.syncWidgets(graph, doc, id, names, mode));
				}
				this.applyInteriors(graph, doc, changes, context, mode);
				this.applyLinks(graph, doc, [...changes.links], context);
				if (mode === "merge") this.placeBatch(graph, created, { moveCollisions: context.liveAgentTurn === true });
				return {
					createdNodeIds: created,
					failureCount: this.currentFailureCount()
				};
			});
		} finally {
			this.failureCounts.pop();
		}
	}
	removeAbsent(graph, doc, context) {
		const docNodes = nodesMap(doc);
		const absentNodes = graph._nodes.filter((node) => !docNodes.has(String(node.id)));
		for (const node of absentNodes) this.try(context, () => graph.remove(node));
		const docLinks = linksMap(doc);
		for (const id of graph.links.keys()) {
			if (docLinks.has(String(id))) continue;
			this.try(context, () => graph.removeLink(id));
		}
	}
	write(graph, context, fn) {
		return (this.deps.withRemoteActor ?? ((_, run) => run()))(context.actor, () => {
			this.deps.getCanvas?.()?.emitBeforeChange();
			try {
				return withGraphIntentSource("agent-remote", fn);
			} finally {
				graph.setDirtyCanvas(true, true);
				this.deps.getCanvas?.()?.emitAfterChange();
			}
		});
	}
	try(context, fn) {
		try {
			fn();
		} catch (error) {
			this.incrementFailureCount();
			reportError(error, {
				surface: "agent",
				errorType: "agent_graph_apply_failed",
				tags: {
					...AGENT_APPLY_TAGS,
					outcome: "degraded"
				},
				context: {
					actor: context.actor,
					opIds: [...context.opIds]
				}
			});
		}
	}
	reportOnce(key, message, errorType, context, cause) {
		this.incrementFailureCount();
		if (this.reported.has(key)) return;
		this.reported.add(key);
		reportError(cause === void 0 ? new Error(message) : new Error(message, { cause }), {
			surface: "agent",
			errorType,
			tags: {
				...AGENT_APPLY_TAGS,
				outcome: "degraded"
			},
			context: boundedContext(context)
		});
	}
	currentFailureCount() {
		return this.failureCounts.at(-1) ?? 0;
	}
	incrementFailureCount() {
		const index = this.failureCounts.length - 1;
		if (index >= 0) this.failureCounts[index] += 1;
	}
	registerDefinitions(graph, doc) {
		const rootGraph = graph.rootGraph;
		const missing = allSubgraphDefinitions(readSubgraphDefinitions(doc)).map((definition) => ({
			...definition,
			definitions: void 0
		})).filter((definition) => !rootGraph.subgraphs.has(definition.id));
		if (missing.length === 0) return;
		const reserved = docRootIds(doc);
		for (const definition of topologicalSortSubgraphs(missing)) {
			const failure = tryCreateSubgraph(rootGraph, definition, reserved);
			if (failure === void 0) {
				this.reported.delete(`definition:${definition.id}`);
				this.recordInteriorIds(rootGraph, definition);
				continue;
			}
			this.incrementFailureCount();
			if (this.reported.has(`definition:${definition.id}`)) continue;
			this.reported.add(`definition:${definition.id}`);
			reportError(failure, {
				surface: "agent",
				errorType: "agent_subgraph_definitions_failed",
				tags: {
					...AGENT_APPLY_TAGS,
					outcome: "degraded"
				},
				context: {
					graphId: graph.id,
					definitionId: definition.id
				}
			});
		}
	}
	recordInteriorIds(rootGraph, definition) {
		const live = rootGraph.subgraphs.get(definition.id);
		if (!live || !definition.nodes) return;
		this.recordInteriorMapping(definition.id, definition.nodes.map((node) => String(node.id)), live.nodes);
	}
	recordInteriorMapping(definitionId, orderedDocIds, liveNodes) {
		if (orderedDocIds.length !== liveNodes.length) return;
		const mapping = /* @__PURE__ */ new Map();
		for (const [index, docId] of orderedDocIds.entries()) mapping.set(docId, liveNodes[index].id);
		this.interiorIds.set(definitionId, mapping);
	}
	deleteNode(graph, id) {
		const node = graph.getNodeById(toNodeId(id));
		if (node) graph.remove(node);
	}
	deleteGroups(graph, ids, context) {
		for (const id of ids ?? []) this.try(context, () => {
			const group = graph.groups.find((group) => String(group.id) === id);
			if (group) graph.remove(group);
		});
	}
	upsertNode(graph, doc, id, mode) {
		const docNode = this.readDocNode(doc, id);
		if (!docNode) return "skipped";
		const live = graph.getNodeById(toNodeId(id));
		if (live && live.type === docNode.type) {
			this.applyFields(live, docNode);
			if (docNode.widgetRecord) restoreWidgetRecord(live, docNode.widgetRecord);
			else this.applyWidgets(live, docNode.widgets, mode);
			return "updated";
		}
		if (live) graph.remove(live);
		this.createNode(graph, docNode, mode);
		return live ? "recreated" : "created";
	}
	createNode(graph, docNode, mode) {
		const node = LiteGraph.createNode(docNode.type, docNode.serialised.title) ?? missingNode(docNode);
		node.id = toNodeId(docNode.id);
		const info = {
			...docNode.serialised,
			inputs: docNode.serialised.inputs?.map((input) => ({ ...input })),
			outputs: docNode.serialised.outputs?.map((output) => ({ ...output }))
		};
		if (docNode.widgetRecord) info.widgets_values = docNode.widgetRecord;
		detachSerialisedLinks(info);
		node.pos = [info.pos[0], info.pos[1]];
		graph.add(node);
		if (node.id !== toNodeId(docNode.id)) this.reportOnce(`node-id:${docNode.id}`, `Live graph reminted node ${docNode.id} as ${String(node.id)}`, "agent_graph_node_id_reminted", {
			nodeId: docNode.id,
			liveId: node.id
		});
		if (node.has_errors) {
			node.last_serialization = info;
			node.configure(info);
		} else if (node.isSubgraphNode()) {
			const beforeConfigurePromotedIds = promotedWidgetIds(node);
			node.configure(info);
			this.applyConfiguredHostWidgets(node, docNode.widgets, beforeConfigurePromotedIds, mode);
		} else {
			const constructed = serializableWidgets(node);
			const constructedNames = new Set(node.widgets?.map((widget) => widget.name));
			const deferred = deferredRowCounts(node, constructed, docNode.widgets);
			node.configure({
				...info,
				widgets_values: docNode.widgetRecord === void 0 ? positionalWidgetValues(node, docNode.widgets, deferred) : info.widgets_values
			});
			const mounted = mountedWidgetValues(node, docNode.widgets, constructed, constructedNames, deferred);
			if (mounted) this.applyWidgets(node, mounted, mode, {
				documentWidgets: docNode.widgets,
				reportMissing: false
			});
		}
		floorSizeToContent(node);
		return node;
	}
	applyFields(node, docNode, keys) {
		const source = docNode.serialised;
		const edited = (key) => !keys || keys.has(key);
		const flagsEdited = !keys || keys.has("flags") || [...keys].some((key) => key.startsWith("flags."));
		if (edited("title") && source.title !== void 0 && node.title !== source.title) node.title = source.title;
		if (edited("mode")) this.applyMode(node, docNode);
		if (flagsEdited) applyFlags(node, source.flags, keys);
		if (edited("properties")) applyProperties(node, source.properties);
		applyAppearance(node, source, edited);
	}
	applyMode(node, docNode) {
		const { mode } = docNode.serialised;
		if (node.mode === mode || node.changeMode(mode)) return;
		this.reportOnce(`node-mode:${docNode.id}:${mode}`, `Document node ${docNode.id} rejected mode ${mode}`, "agent_graph_node_mode_rejected", {
			nodeId: docNode.id,
			mode
		});
	}
	readDocNode(doc, id) {
		const read = readDocNode(doc, id);
		if (read === null) return null;
		const key = `node-shape:${id}`;
		if (!("malformed" in read)) {
			this.reported.delete(key);
			return read;
		}
		if (this.reported.has(key)) return null;
		const { classType, valueShapes, producer } = read.discriminate();
		this.reportOnce(key, `Document node ${id} (${classType ?? "unknown class"}) is malformed: ${read.malformed}`, "agent_graph_node_malformed", {
			nodeId: id,
			issues: read.malformed,
			classType,
			valueShapes,
			producer
		});
		return null;
	}
	syncFields(graph, doc, id, keys) {
		const docNode = this.readDocNode(doc, id);
		const node = graph.getNodeById(toNodeId(id));
		if (!docNode || !node || node.type !== docNode.type) return;
		this.applyFields(node, docNode, keys);
	}
	syncWidgets(graph, doc, id, names, mode) {
		const docNode = this.readDocNode(doc, id);
		const node = graph.getNodeById(toNodeId(id));
		if (!docNode || !node || node.type !== docNode.type) return;
		if (docNode.widgetRecord) {
			restoreWidgetRecord(node, docNode.widgetRecord);
			return;
		}
		const widgets = docNode.widgets;
		if (names === "all" || Array.isArray(widgets)) {
			this.applyWidgets(node, widgets, mode);
			return;
		}
		if (!widgets) return;
		this.applyWidgets(node, Object.fromEntries(Object.entries(widgets).filter(([name]) => changed(node, name, names))), mode, { documentWidgets: widgets });
	}
	applyInteriors(graph, doc, changes, context, mode) {
		const granular = changes.interiors;
		const full = changes.interiorDefinitions;
		const hasGranular = granular !== void 0 && granular.size > 0;
		const hasFull = full !== void 0 && full.size > 0;
		if (!hasGranular && !hasFull) return;
		const docInteriors = readSubgraphInteriorWidgets(doc);
		const targets = interiorSyncTargets(granular, full, docInteriors);
		for (const [definitionId, nodes] of targets) this.try(context, () => this.syncDefinitionInteriors(graph, definitionId, nodes, docInteriors, mode));
	}
	syncDefinitionInteriors(graph, definitionId, nodes, docInteriors, mode) {
		const subgraph = graph.rootGraph.subgraphs.get(definitionId);
		if (!subgraph) return;
		const docNodes = docInteriors.get(definitionId);
		if (!docNodes) return;
		if (!this.interiorIds.has(definitionId)) this.recordInteriorMapping(definitionId, [...docNodes.keys()], subgraph.nodes);
		for (const [nodeId, names] of nodes) {
			const widgets = docNodes.get(nodeId);
			if (widgets === void 0) continue;
			const mapped = this.interiorIds.get(definitionId)?.get(nodeId);
			const live = mapped ? subgraph.getNodeById(mapped) : subgraph.getNodeById(toNodeId(nodeId));
			if (!live) continue;
			this.applyInteriorWidgets(live, widgets, names, mode);
			this.propagateInteriorToHosts(graph, definitionId, live, widgets, names, mode);
		}
	}
	propagateInteriorToHosts(graph, definitionId, liveInterior, widgets, names, mode) {
		if (names === "all") return;
		if (widgets === void 0 || Array.isArray(widgets)) return;
		const record = widgets;
		for (const host of subgraphHostInstances(graph, definitionId)) this.propagateInteriorToHost(host, liveInterior, record, names, mode);
	}
	applyInteriorWidgets(live, widgets, names, mode) {
		if (names === "all" || Array.isArray(widgets)) {
			this.applyWidgets(live, widgets, mode);
			return;
		}
		const filtered = Object.fromEntries(Object.entries(widgets).filter(([name]) => names.has(name)));
		if (Object.keys(filtered).length === 0) return;
		this.applyWidgets(live, filtered, mode, { documentWidgets: widgets });
	}
	propagateInteriorToHost(host, liveInterior, record, names, mode) {
		for (const input of promotedInputs(host)) {
			const target = host.isSubgraphNode() ? host.resolvePromotedTarget(input.name) : void 0;
			if (!target || target.nodeId !== liveInterior.id) continue;
			if (!names.has(target.widgetName)) continue;
			if (!Object.hasOwn(record, target.widgetName)) continue;
			this.applyHostWidgets(host, { [input.name]: record[target.widgetName] }, mode);
		}
	}
	/**
	* `options.documentWidgets` is the node's whole document map. It differs
	* from `widgets` on partial frames, where alias precedence still depends on
	* every key. Creation can suppress reports for unmatched names while still
	* reporting unresolved overflow aliases.
	*/
	applyWidgets(node, widgets, mode, options = {}) {
		if (widgets === void 0) return;
		if (node.isSubgraphNode()) {
			this.applyHostWidgets(node, widgets, mode);
			return;
		}
		const { documentWidgets = widgets, reportMissing = true } = options;
		let pending = ordinaryWidgetEntries(node, widgets).filter(isWidgetEntry);
		while (pending.length > 0) {
			const { resolved, unresolved } = this.applyWidgetRound(node, pending, documentWidgets);
			if (!resolved) {
				this.reportMissingWidgets(node, unresolved, reportMissing);
				return;
			}
			pending = unresolved;
		}
	}
	applyWidgetRound(node, pending, documentWidgets) {
		const unresolved = [];
		let resolved = false;
		for (const [name, value] of pending) {
			if (supersededOverflowAlias(node, name, documentWidgets)) continue;
			if (this.holdsLocalWrite(node, name, value)) continue;
			const widget = documentWidget(node, name);
			if (widget === void 0) {
				unresolved.push([name, value]);
				continue;
			}
			if (widget.name !== name && this.holdsLocalWrite(node, widget.name, value)) continue;
			if (isDynamicGroupController(widget)) this.applyDynamicGroupRowCount(node, widget, value, documentWidgets);
			else this.setWidgetValue(node, widget, value);
			resolved = true;
		}
		return {
			resolved,
			unresolved
		};
	}
	reportMissingWidgets(node, unresolved, reportMissing) {
		for (const [name] of unresolved) if (reportMissing || overflowWidgetIndex(name) !== null) this.reportMissingWidget(node, name);
	}
	reportMissingWidget(node, name) {
		this.reportOnce(`widget:${String(node.id)}:${name}`, `Node ${String(node.id)} (${node.type}) has no widget '${name}'`, "agent_graph_widget_missing", {
			nodeId: node.id,
			type: node.type,
			name
		});
	}
	applyConfiguredHostWidgets(node, widgets, beforeConfigurePromotedIds, mode) {
		const afterConfigurePromotedIds = promotedWidgetIds(node);
		if (Array.isArray(widgets) && (widgets.length !== afterConfigurePromotedIds.length || !isEqual(beforeConfigurePromotedIds, afterConfigurePromotedIds))) {
			this.reportHostWidgetDrift(node, widgets.length, afterConfigurePromotedIds.length, mode, {
				beforeConfigurePromotedIds,
				afterConfigurePromotedIds
			});
			return;
		}
		this.applyHostWidgets(node, widgets, mode);
	}
	reportHostWidgetDrift(node, actual, expected, mode, identity) {
		this.reportOnce(`host-widgets:${mode}:${String(node.id)}`, `Subgraph host ${String(node.id)} (${node.type}) carries ${actual} opaque widget values for ${expected} promoted widgets`, "agent_graph_host_widgets_mismatch", {
			nodeId: node.id,
			type: node.type,
			expected,
			actual,
			mode,
			...identity
		});
	}
	applyHostWidgets(node, widgets, mode) {
		const promoted = promotedInputs(node);
		if (Array.isArray(widgets) && widgets.length !== promoted.length) {
			this.reportHostWidgetDrift(node, widgets.length, promoted.length, mode);
			return;
		}
		for (const [name, value] of hostWidgetEntries(promoted, widgets)) {
			if (!isWidgetValue(value)) continue;
			if (this.holdsLocalWrite(node, name, value)) continue;
			const input = promoted.find((candidate) => candidate.name === name);
			if (!input) {
				this.reportOnce(`widget:${String(node.id)}:${name}`, `Subgraph host ${String(node.id)} (${node.type}) promotes no widget '${name}'`, "agent_graph_widget_missing", {
					nodeId: node.id,
					type: node.type,
					name
				});
				continue;
			}
			const widget = node.getWidgetFromSlot(input);
			if (!widget) {
				this.reportOnce(`widget:${String(node.id)}:${name}:unresolved`, `Subgraph host ${String(node.id)} (${node.type}) could not resolve promoted widget '${name}'`, "agent_graph_widget_missing", {
					nodeId: node.id,
					type: node.type,
					name
				});
				continue;
			}
			try {
				this.setPromotedWidgetValue(node, widget, value);
			} catch (error) {
				const options = {
					surface: "agent",
					errorType: "agent_graph_apply_failed",
					tags: {
						...AGENT_APPLY_TAGS,
						outcome: "degraded"
					},
					context: {
						nodeId: String(node.id),
						widget: name
					}
				};
				reportError(error, options);
			}
		}
	}
	holdsLocalWrite(node, widget, docValue) {
		return this.deps.holdsLocalWrite?.(String(node.id), widget, docValue) ?? false;
	}
	applyDynamicGroupRowCount(node, widget, value, documentWidgets) {
		const { max } = widget.options;
		if (!(typeof value === "number" && max !== void 0 && Math.trunc(value) > Math.max(max, Number(widget.value), documentedRowCount(widget.name, documentWidgets)))) {
			applyRemoteDynamicGroupRowCount(node, () => this.setWidgetValue(node, widget, value));
			if (reachesDynamicGroupRowCount(widget, value)) return;
		}
		this.incrementFailureCount();
		reportRemoteDynamicGroupRowMismatch(node, value, Number(widget.value), {
			...AGENT_APPLY_TAGS,
			outcome: "degraded"
		});
	}
	setWidgetValue(node, widget, value) {
		if (widget.type === "button" || Object.is(widget.value, value)) return;
		const previous = widget.value;
		const rollback = writeWidgetValue(node, widget, value);
		try {
			widget.callback?.(value, this.deps.getCanvas?.() ?? void 0, node);
			node.onWidgetChanged?.(widget.name, value, previous, widget);
		} catch (error) {
			rollback();
			throw error;
		}
		node.graph?.incrementVersion();
	}
	setPromotedWidgetValue(node, widget, value) {
		if (widget.type === "button" || Object.is(widget.value, value)) return;
		const previous = widget.value;
		const callback = widget.callback;
		function writeWithoutCallback(write) {
			widget.callback = void 0;
			try {
				return write();
			} finally {
				widget.callback = callback;
			}
		}
		const rollback = writeWithoutCallback(() => writeWidgetValue(node, widget, value, false));
		try {
			callback?.call(widget, value, this.deps.getCanvas?.() ?? void 0, node);
			node.onWidgetChanged?.(widget.name, value, previous, widget);
			if (!Object.is(widget.value, value)) writeWithoutCallback(() => writeWidgetValue(node, widget, value, false));
		} catch (error) {
			writeWithoutCallback(rollback);
			throw error;
		}
		node.graph?.incrementVersion();
	}
	applyLinks(graph, doc, keys, context) {
		const retry = [];
		for (const key of keys) {
			const link = readDocLink(doc, key);
			if (!link) {
				const id = parseLinkId(key);
				if (id !== void 0) this.try(context, () => graph.removeLink(toLinkId(id)));
				continue;
			}
			this.try(context, () => {
				if (this.connectLink(graph, doc, link) === "unresolved") retry.push(link);
			});
		}
		for (const link of retry) this.try(context, () => {
			if (this.connectLink(graph, doc, link) !== "connected") this.reportOnce(`link:${link.id}`, `Link ${link.id} (node ${link.origin} slot ${link.originSlot} -> node ${link.target} slot ${link.targetSlot}) could not be connected on the live graph`, "agent_graph_link_unresolved", { ...link });
		});
	}
	connectLink(graph, doc, link) {
		const origin = graph.getNodeById(toNodeId(link.origin));
		const target = graph.getNodeById(toNodeId(link.target));
		if (!origin || !target) return "missing-node";
		const originSlot = resolveSlot(origin.outputs.map((output) => output.name), readDocSlotName(doc, link.origin, "outputs", link.originSlot), link.originSlot, "positional");
		const targetSlot = resolveTargetSlot(target, doc, link);
		if (originSlot < 0 || targetSlot < 0) {
			if (graph.links.has(link.id)) graph.removeLink(link.id);
			return "unresolved";
		}
		if (isLinkPresent(graph, origin, originSlot, target, targetSlot)) return "present";
		if (graph.links.has(link.id)) graph.removeLink(link.id);
		return withLinkId(graph, link.id, () => origin.connect(originSlot, target, targetSlot)) ? "connected" : "refused";
	}
	placeBatch(graph, created, { moveCollisions }) {
		if (created.length === 0) return;
		const createdSet = new Set(created);
		const rect = (node) => ({
			x: node.pos[0],
			y: node.pos[1],
			width: node.size[0],
			height: node.size[1]
		});
		const incoming = graph._nodes.filter((node) => createdSet.has(node.id));
		const offset = placementOffset({
			existing: graph._nodes.filter((node) => !createdSet.has(node.id)).map(rect),
			viewport: this.deps.viewportBounds?.() ?? null,
			incoming: incoming.map(rect),
			moveCollisions
		});
		if (!offset) return;
		for (const node of incoming) node.pos = [node.pos[0] + offset.dx, node.pos[1] + offset.dy];
	}
};
function isLinkPresent(graph, origin, originSlot, target, targetSlot) {
	const currentId = target.inputs[targetSlot]?.link;
	const current = currentId == null ? void 0 : graph.links.get(currentId);
	return current !== void 0 && current.origin_id === origin.id && current.origin_slot === originSlot;
}
/** Rank of a not-yet-mounted document name; past every live/overflow position. */
var MOUNTED_LAST = Number.MAX_SAFE_INTEGER;
/**
* Apply order for a document widget map: live widgets in their positional
* order, then overflow aliases by position, then names no widget carries yet.
* The live order keeps a selector ahead of children it may rebuild. Unresolved
* entries are retried after each round, so selectors can mount widgets at any
* depth.
*/
function widgetEntryRank(node, name) {
	const live = serializableWidgets(node);
	const liveIndex = live.findIndex((widget) => widget.name === name);
	if (liveIndex !== -1) return liveIndex;
	const index = overflowWidgetIndex(name);
	return index === null ? MOUNTED_LAST : live.length + index;
}
function isWidgetEntry(entry) {
	return entry[1] !== void 0 && isWidgetValue(entry[1]);
}
/**
* Ordinary node widget values by document name, ordered so Y.Map insertion
* order cannot decide the outcome (`widgetEntryRank`); a positional list is
* read in serializable-widget order.
*/
function ordinaryWidgetEntries(node, widgets) {
	if (!Array.isArray(widgets)) return Object.entries(widgets).sort(([a], [b]) => widgetEntryRank(node, a) - widgetEntryRank(node, b));
	return serializableWidgets(node).map((widget, index) => [widget.name, widgets[index]]);
}
function restoreWidgetRecord(node, record) {
	const widgets_values = record;
	if (node.has_errors) {
		const snapshot = node.last_serialization;
		if (snapshot) node.last_serialization = {
			...snapshot,
			widgets_values
		};
		return;
	}
	node.configure({
		...omit(node.serialize(), ["widgets_values_named"]),
		widgets_values
	});
}
/**
* Whether the changed-name set covers this document key, either directly or
* through the live widget an overflow alias resolves to (rejected-op name sets
* carry the widget's real name).
*/
function changed(node, name, names) {
	if (names.has(name)) return true;
	const positional = overflowWidget(node, name);
	return positional !== void 0 && names.has(positional.name);
}
function interiorSyncTargets(granular, full, docInteriors) {
	const targets = /* @__PURE__ */ new Map();
	if (granular) for (const [definitionId, nodes] of granular) targets.set(definitionId, new Map(nodes));
	if (full) for (const definitionId of full) {
		const nodes = targets.get(definitionId) ?? /* @__PURE__ */ new Map();
		for (const nodeId of docInteriors.get(definitionId)?.keys() ?? []) if (!nodes.has(nodeId)) nodes.set(nodeId, "all");
		targets.set(definitionId, nodes);
	}
	return targets;
}
function promotedInputs(node) {
	return node.inputs.filter((input) => input.widgetId);
}
function subgraphHostInstances(graph, definitionId) {
	const hosts = [];
	const seen = /* @__PURE__ */ new Set();
	const visit = (nodes) => {
		for (const node of nodes) {
			if (seen.has(node)) continue;
			seen.add(node);
			if (node.isSubgraphNode() && node.subgraph.id === definitionId) hosts.push(node);
		}
	};
	visit(graph.rootGraph.nodes);
	for (const subgraph of graph.rootGraph.subgraphs.values()) visit(subgraph.nodes);
	return hosts;
}
function promotedWidgetIds(node) {
	return promotedInputs(node).flatMap((input) => input.widgetId ? [input.widgetId] : []);
}
/** Host widget values by promoted-input name; a positional list is read in promoted-input order. */
function hostWidgetEntries(promoted, widgets) {
	if (Array.isArray(widgets)) return promoted.map((input, index) => [input.name, widgets[index]]);
	return Object.entries(widgets ?? {});
}
/** Writes a widget value and its mirrored node property; returns the undo. */
function writeWidgetValue(node, widget, value, mirrorProperty = true) {
	const previous = widget.value;
	const property = widget.options.property;
	if (!mirrorProperty || !property || node.properties[property] === void 0) {
		widget.value = value;
		return () => {
			widget.value = previous;
		};
	}
	const previousProperty = node.properties[property];
	widget.value = value;
	node.setProperty(property, value);
	return () => {
		widget.value = previous;
		node.setProperty(property, previousProperty);
	};
}
function applyFlags(node, flags, keys) {
	const edited = (key) => !keys || keys.has("flags") || keys.has(`flags.${key}`);
	if (edited("collapsed") && node.collapsed !== !!flags.collapsed) node.collapse(true);
	if (edited("pinned") && node.pinned !== !!flags.pinned) node.pin(!!flags.pinned);
	for (const [key, value] of Object.entries({
		...node.flags,
		...flags
	})) {
		if ([
			"ghost",
			"collapsed",
			"pinned"
		].includes(key) || !edited(key)) continue;
		if (key in flags) Object.assign(node.flags, { [key]: value });
		else Reflect.deleteProperty(node.flags, key);
	}
}
function applyProperties(node, properties) {
	for (const [key, value] of Object.entries(properties ?? {})) if (node.properties[key] !== value) node.setProperty(key, value);
}
function applyAppearance(node, source, edited) {
	const target = (key) => edited(key) ? source[key] ?? node[key] : node[key];
	const color = target("color");
	const bgcolor = target("bgcolor");
	if (node.color !== color || node.bgcolor !== bgcolor) {
		const option = Object.values(LGraphCanvas.node_colors).find((option) => option.color === color && option.bgcolor === bgcolor);
		if (option) node.setColorOption(option);
	}
	for (const key of SYNCED_APPEARANCE_FIELDS.filter(edited)) {
		const value = source[key];
		if (value !== void 0 && node[key] !== value) Object.assign(node, { [key]: value });
	}
}
/**
* The live input index a document link targets. A dynamic input slot the host
* grew has no live counterpart until the node's autogrow group is grown to it,
* so grow it rather than drop a link the document holds against a slot it
* legitimately owns. `growAutogrowInput` refuses a name outside the node's own
* groups, leaving a slot the live node really lacks unresolved as before.
*/
function resolveTargetSlot(target, doc, link) {
	const docName = readDocSlotName(doc, link.target, "inputs", link.targetSlot);
	const resolved = resolveSlot(target.inputs.map((input) => input.name), docName, link.targetSlot, "none");
	if (resolved >= 0 || docName === void 0) return resolved;
	return growAutogrowInput(target, docName) ?? resolved;
}
/**
* Resolves a document slot to a live slot index, by name first. `ComfyNode.configure`
* keeps every document input name live (definition or extra), so an input
* name the live node lacks is a real mismatch and never a positional guess.
* It matches outputs by index and lets the definition's names win over the
* document's, so an output resolves by position when its document name is
* stale.
*/
function resolveSlot(liveNames, docName, docIndex, fallback) {
	const byName = docName === void 0 ? -1 : liveNames.indexOf(docName);
	if (byName >= 0 || docName !== void 0 && fallback === "none") return byName;
	return docIndex < liveNames.length ? docIndex : -1;
}
/**
* Root ids the document owns. Definitions register before the frame's root
* nodes and links exist live, so id deduplication has to be told about them
* or it hands a definition interior an id the root graph is about to need.
*/
function docRootIds(doc) {
	const nodeIds = [];
	nodesMap(doc).forEach((_, id) => nodeIds.push(toNodeId(id)));
	const linkIds = [];
	linksMap(doc).forEach((_, key) => {
		const id = parseLinkId(key);
		if (id !== void 0) linkIds.push(id);
	});
	return {
		nodeIds,
		linkIds
	};
}
function tryCreateSubgraph(rootGraph, definition, reserved) {
	if (!isUuidShapedSubgraphId(definition.id)) return /* @__PURE__ */ new Error(`Agent subgraph definition id is not a UUID: ${definition.id}`);
	try {
		withNamedValuesRestore(() => rootGraph.createSubgraphs([definition], reserved));
		return;
	} catch (cause) {
		const halfBuilt = rootGraph.subgraphs.get(definition.id);
		if (halfBuilt) try {
			rootGraph.releaseSubgraphs([halfBuilt]);
		} catch (rollbackCause) {
			return new AggregateError([cause, rollbackCause], `Agent subgraph definition ${definition.id} failed to register and roll back`);
		}
		return cause;
	}
}
/**
* Definitions carry interior widget values by name
* (`widgets_values_named`); `configure` only reads them while the
* `namedValuesRestore` flag is set, so set it for the definition alone.
*/
function withNamedValuesRestore(fn) {
	const previous = LiteGraph.namedValuesRestore;
	LiteGraph.namedValuesRestore = true;
	try {
		return fn();
	} finally {
		LiteGraph.namedValuesRestore = previous;
	}
}
//#endregion
//#region src/workbench/extensions/agent/crdt/docChangeCollector.ts
/**
* Collects what the Y observers on one follower document report between two
* `take()` calls, in the shape the applier consumes. Observers fire
* synchronously inside `applyRemoteUpdate`, so the frame that delivered an
* update sees exactly that update's changes. Changes stay collected until a
* graph is there to take them, so a frame delivered before the graph loads is
* applied once it does.
*/
var DocChangeCollector = class {
	nodes = /* @__PURE__ */ new Map();
	widgets = /* @__PURE__ */ new Map();
	resyncNodes = /* @__PURE__ */ new Map();
	links = /* @__PURE__ */ new Set();
	interiors = /* @__PURE__ */ new Map();
	interiorDefinitions = /* @__PURE__ */ new Set();
	removedGroups = /* @__PURE__ */ new Set();
	nodesMap;
	linksMap;
	definitionsMap;
	metaMap;
	constructor(doc) {
		this.nodesMap = nodesMap(doc);
		this.linksMap = linksMap(doc);
		this.definitionsMap = definitionsObserverRoot(doc);
		this.metaMap = doc.getMap("meta");
		this.nodesMap.observeDeep(this.onNodesChanged);
		this.linksMap.observe(this.onLinksChanged);
		this.definitionsMap.observeDeep(this.onDefinitionsChanged);
		this.metaMap.observe(this.onMetaChanged);
	}
	/** Returns everything collected so far without clearing it. */
	peek() {
		return {
			nodes: new Map(this.nodes),
			widgets: new Map(this.widgets),
			resyncNodes: new Map([...this.resyncNodes].map(([id, keys]) => [id, new Set(keys)])),
			links: new Set(this.links),
			interiors: new Map([...this.interiors].map(([definitionId, nodes]) => [definitionId, new Map(nodes)])),
			interiorDefinitions: new Set(this.interiorDefinitions),
			removedGroups: new Set(this.removedGroups)
		};
	}
	/** Returns and clears everything collected so far. */
	take() {
		const changes = this.peek();
		this.discard();
		return changes;
	}
	discard() {
		this.nodes.clear();
		this.widgets.clear();
		this.resyncNodes.clear();
		this.links.clear();
		this.interiors.clear();
		this.interiorDefinitions.clear();
		this.removedGroups.clear();
	}
	destroy() {
		this.nodesMap.unobserveDeep(this.onNodesChanged);
		this.linksMap.unobserve(this.onLinksChanged);
		this.definitionsMap.unobserveDeep(this.onDefinitionsChanged);
		this.metaMap.unobserve(this.onMetaChanged);
		this.discard();
	}
	markInterior(definitionId, nodeId, names) {
		let nodes = this.interiors.get(definitionId);
		if (!nodes) {
			nodes = /* @__PURE__ */ new Map();
			this.interiors.set(definitionId, nodes);
		}
		if (names === "all") {
			if (nodes.get(nodeId) === void 0) nodes.set(nodeId, "all");
			return;
		}
		const current = nodes.get(nodeId);
		const merged = current === "all" || !current ? /* @__PURE__ */ new Set() : current;
		for (const name of names) merged.add(name);
		nodes.set(nodeId, merged);
	}
	onDefinitionsChanged = (events) => {
		for (const event of events) this.collectDefinitionEvent(event);
	};
	collectDefinitionEvent(event) {
		const path = event.path.map(String);
		const nodesIndex = path.lastIndexOf("nodes");
		if (nodesIndex >= 1 && path.length > nodesIndex + 1) {
			this.collectInteriorEvent(event, path, nodesIndex);
			return;
		}
		this.collectDefinitionResync(event, path);
	}
	collectInteriorEvent(event, path, nodesIndex) {
		const definitionId = path[nodesIndex - 1];
		const nodeId = path[nodesIndex + 1];
		if (path[nodesIndex + 2] === "widgets" && event instanceof YMapEvent) {
			this.markInterior(definitionId, nodeId, new Set(event.keysChanged));
			return;
		}
		this.markInterior(definitionId, nodeId, "all");
	}
	collectDefinitionResync(event, path) {
		const subgraphsIndex = path.lastIndexOf("subgraphs");
		const definitionId = subgraphsIndex >= 0 && path.length > subgraphsIndex + 1 ? path[subgraphsIndex + 1] : path[0];
		if (definitionId) this.interiorDefinitions.add(definitionId);
		if (event.target === this.definitionsMap && event instanceof YMapEvent) for (const id of event.keysChanged) this.interiorDefinitions.add(id);
	}
	onNodesChanged = (events) => {
		for (const event of events) if (event instanceof YArrayEvent) this.onOpaqueWidgetsChanged(event);
		else if (event instanceof YMapEvent) this.onNodeMapChanged(event);
	};
	onNodeMapChanged(event) {
		if (event.target === this.nodesMap) this.onNodeEntriesChanged(event);
		else if (event.path.length === 1) this.onNodeFieldsChanged(event);
		else if (event.path[1] === "widgets") this.onNamedWidgetsChanged(event);
		else if (event.path[1] === "flags") this.markFields(String(event.path[0]), [...event.keysChanged].map((key) => `flags.${key}`));
	}
	onOpaqueWidgetsChanged(event) {
		if (event.path.length === 2 && event.path[1] === "__widgets_opaque") this.widgets.set(String(event.path[0]), "all");
	}
	onNodeEntriesChanged(event) {
		for (const [id, change] of event.changes.keys) this.nodes.set(id, change.action);
	}
	onNamedWidgetsChanged(event) {
		const id = String(event.path[0]);
		const current = this.widgets.get(id);
		if (current === "all") return;
		const names = current ?? /* @__PURE__ */ new Set();
		for (const name of event.keysChanged) names.add(name);
		this.widgets.set(id, names);
	}
	onNodeFieldsChanged(event) {
		const id = String(event.path[0]);
		if (event.keysChanged.has("widgets") || event.keysChanged.has("__widgets_opaque")) this.widgets.set(id, "all");
		this.markFields(id, event.keysChanged);
	}
	markFields(id, keys) {
		const synced = [...keys].filter((key) => SYNCED_NODE_FIELDS.has(key) || key.startsWith("flags."));
		if (synced.length === 0) return;
		const current = this.resyncNodes.get(id) ?? /* @__PURE__ */ new Set();
		for (const key of synced) current.add(key);
		this.resyncNodes.set(id, current);
	}
	onLinksChanged = (event) => {
		for (const id of event.keysChanged) this.links.add(id);
	};
	onMetaChanged = (event) => {
		const change = event.changes.keys.get("groups");
		if (!change) return;
		const current = groupIds(this.metaMap.get("groups"));
		for (const id of groupIds(change.oldValue)) if (!current.has(id)) this.removedGroups.add(id);
		for (const id of current) this.removedGroups.delete(id);
	};
};
function groupIds(groups) {
	const ids = /* @__PURE__ */ new Set();
	if (!Array.isArray(groups)) return ids;
	for (const group of groups) {
		const id = typeof group === "object" && group !== null ? group.id : void 0;
		if (typeof id === "number" || typeof id === "string") ids.add(String(id));
	}
	return ids;
}
//#endregion
//#region src/workbench/extensions/agent/crdt/crdtLog.ts
/**
* Console tint per scope, so a busy log reads as layers rather than as one
* undifferentiated stream.
*/
var SCOPE_STYLE = {
	wire: "color:#7dd3fc",
	doc: "color:#a5b4fc"
};
var CONSOLE_METHOD = {
	warn: "warn",
	info: "info",
	debug: "debug",
	trace: "debug"
};
/**
* Emit one CRDT-internal event.
*
* The ring buffer records while the debug instrument is enabled even when the
* selected console level is quiet. Ordinary production sessions retain no
* frame or actor details; a tester must opt in before reproducing an issue.
*/
function crdtLog(entry) {
	const { scope, level, kind, message, detail } = entry;
	const optedOut = isCrdtDebugOptedOut();
	if (!optedOut) recordDevEvent(kind, detail ?? null, {
		scope,
		level
	});
	if (optedOut && level !== "warn") return;
	if (!isLevelEnabled(level)) return;
	const args = [
		`%c[crdt:${scope}]%c ${kind} — ${message}`,
		SCOPE_STYLE[scope],
		""
	];
	if (detail !== void 0 && isCrdtDebugEnabled()) args.push(sanitizeDevEventDetail(detail));
	console[CONSOLE_METHOD[level]](...args);
}
/**
* Bind a scope once so call sites read as `wire.trace('…')` rather than
* repeating the scope on every event.
*/
function scopedCrdtLog(scope) {
	const at = (level) => (kind, message, detail) => crdtLog({
		scope,
		level,
		kind,
		message,
		detail
	});
	return {
		warn: at("warn"),
		info: at("info"),
		debug: at("debug"),
		trace: at("trace")
	};
}
var wireLog = scopedCrdtLog("wire");
//#endregion
//#region src/workbench/extensions/agent/crdt/followerDoc.ts
var REMOTE_DOC_UPDATE_ORIGIN = Symbol("remote-doc-update");
var FollowerDoc = class extends EventTarget {
	doc = new Doc();
	updatesApplied = 0;
	/**
	* `Y.applyUpdate` integrates structs as it decodes them, so a malformed
	* frame would leave the doc holding its readable prefix. Decoding the whole
	* frame first makes the apply all-or-nothing.
	*/
	applyRemoteUpdate(update) {
		decodeUpdate(update);
		applyUpdate(this.doc, update, REMOTE_DOC_UPDATE_ORIGIN);
		this.updatesApplied++;
		this.dispatchEvent(new CustomEvent("update", { detail: {
			update,
			updatesApplied: this.updatesApplied
		} }));
	}
	stateVector() {
		return encodeStateVector(this.doc);
	}
	destroy() {
		this.doc.destroy();
	}
};
//#endregion
//#region src/workbench/extensions/agent/crdt/schemaGuard.ts
/**
* Read-time schema-version gate (CRDT keep-alive invariant KA-11).
*
* KA-11: "Schema-version discipline, ENFORCED ON READ. Bump `SCHEMA_VERSION`
* when an old reader would mis-project a new doc; fail-closed on an unreadable
* schema."
*
* Before this file the follower had no read-side gate at all: the only mention
* of the version anywhere was `expect(SCHEMA_VERSION).toBe(1)` in a test, which
* pins the BUILD-TIME constant of the package the frontend compiled against and
* says nothing about the version of the document that actually arrived over the
* socket. A doc-host advancing to schema v2 would have been read with a v1
* reader — whatever keys still parsed would render, silently and wrongly. That
* is fail-OPEN, the exact failure KA-11 names.
*
* The version is read through the shared package's PUBLIC api
* (`readSchemaVersion`, `SCHEMA_VERSION`) — never through a deep/internal
* import — so the key name and the expected value cannot drift from the
* writer: they are the same symbols the cloud doc-host uses. The package's own `migrate()` is deliberately
* NOT called: it is host-only (it mutates the doc), and a follower must never
* write the shared doc (KA-6 / FORECLOSE #5).
*/
/** Thrown by {@link assertReadableSchema}; carries the version actually found. */
var FollowerSchemaError = class extends Error {
	found;
	constructor(found, message) {
		super(message);
		this.found = found;
		this.name = "FollowerSchemaError";
	}
};
/**
* Fail closed unless the merged doc declares exactly the schema version this
* build was written against.
*
* A MISSING `meta.schema_version` fails too, and deliberately: every doc the
* host produces is seeded by the shared package (`initDoc`/`mint` both write
* the key), so an absent version means the bytes are not a document this
* reader understands — which is precisely "unreadable schema".
*
* @throws FollowerSchemaError when the doc is not readable at this version.
*/
function assertReadableSchema(doc) {
	const found = readSchemaVersion(doc);
	if (found === 5) return;
	const message = `CRDT follower: doc meta.schema_version=${String(found)} is not the v5 layout this build reads — refusing to project it (fail-closed, keep-alive invariant KA-11).`;
	try {
		assert(false, "CRDT follower: doc meta.schema_version is not the layout this build reads — refusing to project it (fail-closed, keep-alive invariant KA-11)", { found });
	} catch {}
	throw new FollowerSchemaError(found, message);
}
//#endregion
//#region src/workbench/extensions/agent/crdt/layoutFollowerBridge.ts
function isLiveAgentUpdate(update) {
	return update.catchUp === false && update.actor?.startsWith("agent:") === true;
}
function trySend(send) {
	try {
		return send();
	} catch (error) {
		reportError(error, {
			surface: "agent",
			errorType: "failure_sending_agent_doc_frame",
			logToConsole: false,
			tags: {
				failure_kind: "caught_unexpected",
				feature_area: "agent",
				operation: "sync",
				outcome: "recovered"
			},
			level: "error"
		});
		wireLog.warn("frame_send_failed", "outbound doc frame dropped", error);
		return false;
	}
}
/**
* Bridges server doc frames to the follower's semantic {@link FollowerDoc} and
* re-dispatches them. It does NOT touch the layout store: the semantic doc is
* applied to the domain stores by the ECS follower adapter. It never merges the
* semantic update into layoutStore: semantic and layout state remain separate
* Y.Docs.
*
* Subscription is modelled as INTENT reconciled against transport REALITY, and
* teardown is failure-tolerant; see the two id fields and {@link destroy}.
*/
var LayoutFollowerBridge = class extends EventTarget {
	client;
	/**
	* Reassigned only on a lineage break — an explicit `doc_reset`
	* ({@link onDocReset}) or a subscribe to a DIFFERENT workflow
	* ({@link subscribe}) — because folding one document's history into another
	* merges two unrelated lineages: the next subscribe would carry the old
	* doc's state vector, the host would compute a nonsense delta against it,
	* and both workflows' nodes would land on one canvas (FEB-5).
	*/
	followerDoc = new FollowerDoc();
	/**
	* The workflow whose lineage {@link followerDoc} holds — the id passed to
	* the most recent {@link subscribe}. Unlike {@link desiredWorkflowId} it
	* survives {@link unsubscribe}, because detaching does not empty the doc:
	* a later subscribe to a DIFFERENT workflow must still re-mint it.
	*/
	lineageWorkflowId = null;
	/**
	* Subscription INTENT — the workflow the app wants followed. Set
	* synchronously by the caller; independent of whether any frame has left the
	* transport yet.
	*/
	desiredWorkflowId = null;
	/**
	* Subscription REALITY — the workflow a `doc_subscribe` frame actually left
	* the transport for. Only this gates inbound updates.
	*
	* Splitting the two is the fix for the "panel mounted before the socket
	* opened" trap: the old single `workflowId` field was set BEFORE the send,
	* so a send that could not go out still latched the field and the
	* `if (this.workflowId === workflowId) return` guard blocked every retry —
	* permanently, because `api` only dispatches `reconnected` on a RE-connect,
	* never on the first successful open.
	*/
	sentWorkflowId = null;
	/**
	* The most recent KA-11 read-gate failure, while the merged doc is still
	* unreadable. Cleared by a lineage break ({@link dropDocForNewLineage}) or
	* by a later same-lineage frame that merges and leaves the doc readable
	* again — see {@link onDocUpdate}.
	*/
	schemaError = null;
	lastSeq = null;
	attemptFirstSeq = null;
	attemptLastSeq = null;
	integratedSeq = null;
	ackSeq = null;
	/**
	* Armed by the ack, disarmed by the first applied frame whose seq equals
	* {@link ackSeq}. The relay joins the fanout BEFORE it acks, so a live frame
	* N+1 can reach the follower ahead of `doc_subscribed(seq=N)` and the
	* catch-up `doc_update(seq=N)`. The catch-up is the only frame carrying what
	* this follower's state vector lacked; if the stale check judged it against
	* the already-applied N+1 it would be dropped and the hole would never show
	* up as a gap. While armed, exactly one frame at seq == ackSeq bypasses the
	* stale check (Yjs integration is idempotent, so a true duplicate is
	* harmless). It never moves {@link lastSeq} backwards.
	*/
	catchUpPending = false;
	pendingReseedWorkflowId = null;
	reseedToken = null;
	reseedBlockedUntilConfirmedWorkflowId = null;
	constructor(client) {
		super();
		this.client = client;
		client.addEventListener("doc_update", this.onDocUpdate);
		client.addEventListener("doc_reset", this.onDocReset);
		client.addEventListener("doc_subscribed", this.onDocSubscribed);
		client.addEventListener("doc_ops_result", this.forwardFrame);
		client.addEventListener("doc_reseed_result", this.onDocReseedResult);
	}
	/** The semantic doc this bridge currently follows. */
	get follower() {
		return this.followerDoc;
	}
	/** The workflow a subscribe frame actually went out for, if any. */
	get subscribedWorkflowId() {
		return this.sentWorkflowId;
	}
	/** The higher of the last applied doc seq and the current subscribe's ack. */
	get lastSequence() {
		return Math.max(this.lastSeq ?? 0, this.ackSeq ?? 0);
	}
	get isSubscribeBaselineIntegrated() {
		return this.ackSeq !== null && this.integratedSeq !== null && this.integratedSeq >= this.ackSeq && this.schemaError === null;
	}
	/** The KA-11 read-gate failure that closed this bridge's read path, if any. */
	get lastSchemaError() {
		return this.schemaError;
	}
	/** True while intent and reality disagree — i.e. a retry is still owed. */
	get hasPendingSubscribe() {
		return this.desiredWorkflowId !== null && this.sentWorkflowId !== this.desiredWorkflowId;
	}
	/**
	* Follow a workflow. Subscribing to a DIFFERENT workflow than the one this
	* bridge's doc holds is a lineage break (FEB-5): the doc is re-minted so
	* the subscribe carries an empty state vector, and `follower_replaced` is
	* dispatched — unconditionally, even when the send could not leave a closed
	* socket — so consumers rebind their observers to the new doc rather than
	* staying attached to the destroyed one. Re-subscribing to the SAME
	* workflow keeps the doc: that is the same-lineage catch-up path
	* (ADR-GRAPH-DOCUMENT-0024), where the state vector makes the delta cheap.
	*/
	subscribe(workflowId) {
		const lineage = this.lineageWorkflowId;
		if (this.desiredWorkflowId !== workflowId) {
			this.reseedBlockedUntilConfirmedWorkflowId = null;
			this.reseedToken = null;
		}
		this.lineageWorkflowId = workflowId;
		this.desiredWorkflowId = workflowId;
		if (lineage !== null && lineage !== workflowId) {
			this.dropDocForNewLineage();
			this.dispatchEvent(new CustomEvent("follower_replaced", { detail: { workflowId } }));
			this.reconcile();
			return;
		}
		this.reconcile();
	}
	/** Drive intent at the transport. Idempotent and safe to call at any time. */
	reconcile() {
		const desired = this.desiredWorkflowId;
		if (this.sentWorkflowId !== null && this.sentWorkflowId !== desired) {
			const sent = this.sentWorkflowId;
			this.sentWorkflowId = null;
			trySend(() => this.client.unsubscribe(sent));
		}
		if (desired === null || this.sentWorkflowId === desired) return false;
		if (trySend(() => this.client.subscribe(desired, this.follower.stateVector()))) {
			this.sentWorkflowId = desired;
			this.attemptFirstSeq = null;
			this.attemptLastSeq = null;
			this.ackSeq = null;
			this.catchUpPending = false;
			this.dispatchEvent(new CustomEvent("doc_subscribe_sent", { detail: { workflowId: desired } }));
			return true;
		}
		return false;
	}
	resubscribe() {
		this.sentWorkflowId = null;
		return this.reconcile();
	}
	reconnect() {
		this.reseedBlockedUntilConfirmedWorkflowId = null;
		this.reseedToken = null;
		this.resubscribe();
	}
	unsubscribe() {
		this.desiredWorkflowId = null;
		this.reconcile();
	}
	reseed(workflowId, workflow) {
		const expectedSeq = this.reseedSequenceFor(workflowId);
		if (expectedSeq === null) {
			assert(false, "followers send a whole canvas only to answer a current stale-schema refusal — see ADR-CRDT-FOLLOWER-0025", { workflowId });
			return false;
		}
		this.reseedToken = null;
		if (!trySend(() => this.client.reseed(workflowId, expectedSeq, workflow))) return false;
		this.pendingReseedWorkflowId = workflowId;
		return true;
	}
	canReseed(workflowId) {
		return this.reseedSequenceFor(workflowId) !== null;
	}
	reseedSequenceFor(workflowId) {
		const token = this.reseedToken;
		return token?.workflowId === workflowId && workflowId === this.desiredWorkflowId && workflowId !== this.reseedBlockedUntilConfirmedWorkflowId ? token.expectedSeq : null;
	}
	sendHumanOps(tab, ops) {
		const workflowId = this.sentWorkflowId;
		if (workflowId === null || ops.length === 0) return;
		trySend(() => this.client.sendOps(workflowId, tab, ops));
	}
	/**
	* Release everything this bridge owns. Teardown is failure-tolerant: the
	* unsubscribe is best-effort and can never prevent the listener detach or the
	* Y.Doc destroy, because a bridge that survives its composable keeps applying
	* remote updates through an adapter still wired to the live stores.
	*/
	destroy() {
		try {
			this.unsubscribe();
		} finally {
			this.client.removeEventListener("doc_update", this.onDocUpdate);
			this.client.removeEventListener("doc_reset", this.onDocReset);
			this.client.removeEventListener("doc_subscribed", this.onDocSubscribed);
			this.client.removeEventListener("doc_ops_result", this.forwardFrame);
			this.client.removeEventListener("doc_reseed_result", this.onDocReseedResult);
			this.desiredWorkflowId = null;
			this.sentWorkflowId = null;
			this.followerDoc.destroy();
		}
	}
	onDocUpdate = (event) => {
		if (!(event instanceof CustomEvent)) return;
		const update = event.detail;
		if (update.workflowId !== this.sentWorkflowId) return;
		const isCatchUp = this.catchUpPending && update.seq === this.ackSeq;
		if (this.rejectStaleUpdate(update, isCatchUp)) return;
		if (this.rejectSequenceGap(update)) return;
		this.recordAppliedSequence(update.seq);
		this.follower.applyRemoteUpdate(update.update);
		this.recordIntegratedSequence(update.seq, isCatchUp);
		if (!this.isReadableUpdate(update)) return;
		const classifiedUpdate = {
			...update,
			catchUp: isCatchUp
		};
		this.dispatchEvent(new CustomEvent("doc_update", { detail: classifiedUpdate }));
	};
	rejectStaleUpdate(update, isCatchUp) {
		if (isCatchUp || this.lastSeq === null || update.seq > this.lastSeq) return false;
		this.dispatchEvent(new CustomEvent("doc_stale", { detail: {
			workflowId: update.workflowId,
			seq: update.seq
		} }));
		return true;
	}
	recordAppliedSequence(seq) {
		this.lastSeq = Math.max(this.lastSeq ?? seq, seq);
		this.attemptFirstSeq ??= seq;
		this.attemptLastSeq = Math.max(this.attemptLastSeq ?? seq, seq);
	}
	rejectSequenceGap(update) {
		const baseline = this.ackSeq === null ? this.attemptLastSeq : Math.max(this.attemptLastSeq ?? 0, this.ackSeq);
		if (baseline === null || update.seq <= baseline + 1) return false;
		this.reportGap(update.workflowId, baseline + 1, update.seq);
		return true;
	}
	rejectPreAckGap(workflowId) {
		if (this.ackSeq === null || this.attemptFirstSeq === null || this.attemptFirstSeq <= this.ackSeq + 1) return;
		this.reportGap(workflowId, this.ackSeq + 1, this.attemptFirstSeq);
	}
	reportGap(workflowId, expected, received) {
		this.dispatchEvent(new CustomEvent("doc_gap", { detail: {
			workflowId,
			expected,
			received
		} }));
		this.resubscribe();
	}
	isReadableUpdate(update) {
		try {
			assertReadableSchema(this.follower.doc);
			this.schemaError = null;
			return true;
		} catch (error) {
			if (!(error instanceof FollowerSchemaError)) throw error;
			this.schemaError = error;
			this.dispatchEvent(new CustomEvent("schema_error", { detail: {
				workflowId: update.workflowId,
				found: error.found
			} }));
			return false;
		}
	}
	/**
	* Lineage break (`doc_reset`): dispatch while the old doc is still readable,
	* then replace it exactly once and pull the new lineage from an empty vector.
	* `follower_replaced` lets consumers rebind Yjs observers after replacement.
	*/
	onDocReset = (event) => {
		if (!(event instanceof CustomEvent)) return;
		const reset = event.detail;
		if (reset.workflowId !== this.sentWorkflowId) return;
		this.dispatchEvent(new CustomEvent("doc_reset", { detail: reset }));
		this.dropDocForNewLineage();
		this.resubscribe();
		this.dispatchEvent(new CustomEvent("follower_replaced", { detail: reset }));
	};
	dropDocForNewLineage() {
		this.followerDoc.destroy();
		this.followerDoc = new FollowerDoc();
		this.schemaError = null;
		this.lastSeq = null;
		this.attemptFirstSeq = null;
		this.attemptLastSeq = null;
		this.integratedSeq = null;
		this.ackSeq = null;
		this.catchUpPending = false;
	}
	onDocSubscribed = (event) => {
		if (!(event instanceof CustomEvent)) return;
		const subscribed = event.detail;
		if (subscribed.workflowId !== this.sentWorkflowId) return;
		this.reseedToken = subscribed.workflowId !== this.reseedBlockedUntilConfirmedWorkflowId && !subscribed.ok && subscribed.code === "stale_schema_reseed_required" && subscribed.expectedSeq ? {
			workflowId: subscribed.workflowId,
			expectedSeq: subscribed.expectedSeq
		} : null;
		if (!subscribed.ok) {
			this.ackSeq = null;
			this.catchUpPending = false;
			this.sentWorkflowId = null;
			this.dispatchEvent(new CustomEvent(event.type, { detail: event.detail }));
			return;
		}
		this.reseedBlockedUntilConfirmedWorkflowId = null;
		this.ackSeq = subscribed.seq ?? 0;
		this.catchUpPending = this.ackSeq > 0;
		this.dispatchEvent(new CustomEvent(event.type, { detail: event.detail }));
		this.rejectPreAckGap(subscribed.workflowId);
	};
	recordIntegratedSequence(seq, isCatchUp) {
		if (isCatchUp) {
			this.catchUpPending = false;
			this.integratedSeq = Math.max(this.integratedSeq ?? 0, this.lastSeq ?? seq);
		} else if (this.integratedSeq !== null && seq === this.integratedSeq + 1 || this.ackSeq === 0 && seq === 1) this.integratedSeq = seq;
	}
	onDocReseedResult = (event) => {
		if (!(event instanceof CustomEvent)) return;
		const result = event.detail;
		if (result.workflowId !== this.pendingReseedWorkflowId) return;
		this.pendingReseedWorkflowId = null;
		this.dispatchEvent(new CustomEvent(event.type, { detail: result }));
		if (result.workflowId !== this.desiredWorkflowId) return;
		if (!result.ok && result.code !== "conflict") return;
		this.reseedBlockedUntilConfirmedWorkflowId = result.workflowId;
		const reset = {
			workflowId: result.workflowId,
			seq: result.seq ?? 0,
			lineageSeq: result.seq ?? 0,
			actor: "system:client-seed"
		};
		this.dispatchEvent(new CustomEvent("doc_reset", { detail: reset }));
		this.dropDocForNewLineage();
		this.resubscribe();
		this.dispatchEvent(new CustomEvent("follower_replaced", { detail: reset }));
	};
	forwardFrame = (event) => {
		if (!(event instanceof CustomEvent)) return;
		this.dispatchEvent(new CustomEvent(event.type, { detail: event.detail }));
	};
};
//#endregion
//#region src/workbench/extensions/agent/crdt/localWidgetWrites.ts
/**
* Widget registers the live graph has written but the document has not yet
* caught up on. A register is one last-writer-wins value: a remote frame that
* writes it while a local write is still in flight holds the value the host
* built before that write reached it, so applying the frame would rewind the
* widget and lose what was typed since. Such a frame is held back until the
* document holds the local value, or the write settles without reaching the
* document (host skipped or refused it, lineage broke).
*
* Only the latest local value per register is kept: an older in-flight write
* settling (its echo, its ack) does not lift the hold while a newer one is
* still out. Interior (`path`) writes address subgraph definitions the applier
* never projects, so they are not tracked.
*/
var LocalWidgetWrites = class {
	pending = /* @__PURE__ */ new Map();
	note(operations) {
		for (const op of topLevelSetWidgetOps(operations)) this.pending.set(registerKey(op.node_id, op.widget), op.value);
	}
	/** Lifts the hold of every register whose settled op carried its latest value. */
	settle(operations) {
		for (const op of topLevelSetWidgetOps(operations)) this.holds(String(op.node_id), op.widget, op.value);
	}
	/** Lifts the hold of every register the document has caught up on. */
	settleAgainst(docValue) {
		for (const key of Array.from(this.pending.keys())) {
			const [nodeId, widget] = splitKey(key);
			this.holds(nodeId, widget, docValue(nodeId, widget));
		}
	}
	/**
	* True while a local write to the register is in flight and `docValue` is
	* not it. A matching value settles the write and lets the frame through.
	*/
	holds(nodeId, widget, docValue) {
		const key = registerKey(nodeId, widget);
		if (!this.pending.has(key)) return false;
		if (!isEqual(this.pending.get(key), docValue)) return true;
		this.pending.delete(key);
		return false;
	}
	clear() {
		this.pending.clear();
	}
};
function topLevelSetWidgetOps(operations) {
	return operations.filter((op) => op.op === "set_widget" && op.path == null);
}
var KEY_SEPARATOR = "\0";
function registerKey(nodeId, widget) {
	return `${String(nodeId)}${KEY_SEPARATOR}${widget}`;
}
function splitKey(key) {
	const at = key.indexOf(KEY_SEPARATOR);
	return [key.slice(0, at), key.slice(at + 1)];
}
//#endregion
//#region src/workbench/extensions/agent/crdt/rejectedOpChanges.ts
/**
* The live-graph changes that put a host-rejected human batch back the way
* the document has it. Each op names exactly the node, widget, link, or field
* register it claimed; replaying those registers from the document undoes the
* live edit without touching anything else. A node the document lacks is
* removed live along with its links; one it holds is restored with the
* document links incident to it. Interior (`path`) writes are skipped: a
* rejected op never reached the document, so the live interior already
* holds the document value and there is nothing to undo here.
*/
function changesForRejectedOps(doc, ops) {
	const nodes = /* @__PURE__ */ new Map();
	const widgets = /* @__PURE__ */ new Map();
	const resyncNodes = /* @__PURE__ */ new Map();
	const links = /* @__PURE__ */ new Set();
	const docNodes = nodesMap(doc);
	const settleNode = (id) => {
		if (!docNodes.has(id)) {
			nodes.set(id, "delete");
			return;
		}
		nodes.set(id, "add");
		for (const link of docLinksIncident(doc, id)) links.add(String(link.id));
	};
	for (const op of ops) {
		if ("path" in op && op.path != null) continue;
		switch (op.op) {
			case "add_node":
			case "delete_node":
				settleNode(String(op.node_id));
				break;
			case "clear":
				for (const id of op.removed_nodes) settleNode(String(id));
				break;
			case "set_widget": {
				const id = String(op.node_id);
				const names = widgets.get(id) ?? /* @__PURE__ */ new Set();
				names.add(op.widget);
				widgets.set(id, names);
				break;
			}
			case "set_node_field": {
				const id = String(op.node_id);
				const keys = resyncNodes.get(id) ?? /* @__PURE__ */ new Set();
				keys.add(op.field);
				resyncNodes.set(id, keys);
				break;
			}
			case "connect":
			case "disconnect": links.add(String(op.link_id));
		}
	}
	return {
		nodes,
		widgets,
		resyncNodes,
		links
	};
}
//#endregion
//#region src/workbench/extensions/agent/crdt/agentCrdtProjection.ts
var EMPTY_DELTA = {
	added: [],
	removed: []
};
function docNodeDelta(changes) {
	const added = [];
	const removed = [];
	for (const [id, change] of changes.nodes) if (change === "add") added.push(id);
	else if (change === "delete") removed.push(id);
	return {
		added,
		removed
	};
}
function changesAgainstDoc(doc, changes) {
	const docNodes = nodesMap(doc);
	const nodes = /* @__PURE__ */ new Map();
	for (const [id, change] of changes.nodes) if (!docNodes.has(id)) nodes.set(id, "delete");
	else nodes.set(id, change === "delete" ? "update" : change);
	const docGroups = groupIds(doc.getMap("meta").get("groups"));
	const removedGroups = new Set([...changes.removedGroups ?? []].filter((id) => !docGroups.has(id)));
	return {
		...changes,
		nodes,
		removedGroups
	};
}
function pendingNodeDelta(target, changes) {
	const frameNodes = new Map([...changes.nodes].filter(([id, change]) => target.reportedPendingNodes.get(id) !== change));
	target.reportedPendingNodes = new Map(changes.nodes);
	return docNodeDelta({
		...changes,
		nodes: frameNodes
	});
}
/**
* Projects a follower document onto the live graph through the graph API.
* One collector per bound workflow records what each delivered frame changed;
* the applier replays those changes as ordinary graph operations.
*/
var AgentCrdtProjection = class {
	getGraph;
	targets = /* @__PURE__ */ new Map();
	replacedLineages = /* @__PURE__ */ new Set();
	localWrites = new LocalWidgetWrites();
	applier;
	constructor(getGraph, deps = {}) {
		this.getGraph = getGraph;
		this.applier = new LiveGraphApplier({
			...deps,
			getGraph,
			holdsLocalWrite: (nodeId, widget, docValue) => {
				const held = this.localWrites.holds(nodeId, widget, docValue);
				if (held) recordDevEvent("local_widget_write_held", {
					node_id: nodeId,
					name: widget
				});
				return held;
			}
		});
	}
	/**
	* Local edits on their way to the host. A frame's value for one of these
	* registers is held back until the document holds the local value; see
	* `LocalWidgetWrites`.
	*/
	noteLocalWrites(operations) {
		this.localWrites.note(operations);
	}
	/** The host has answered for these ops, or they will never reach it. */
	settleLocalWrites(operations) {
		this.localWrites.settle(operations);
	}
	/** Binding the same follower again keeps its collected, unapplied changes. */
	bind(workflowId, follower) {
		if (this.targets.get(workflowId)?.follower === follower) return;
		this.unbind(workflowId);
		this.targets.set(workflowId, {
			follower,
			collector: new DocChangeCollector(follower.doc),
			reportedPendingNodes: /* @__PURE__ */ new Map(),
			failedProjections: []
		});
	}
	unbind(workflowId) {
		const target = this.targets.get(workflowId);
		if (!target) return;
		target.collector.destroy();
		this.targets.delete(workflowId);
	}
	/**
	* Applies one delivered frame's changes to the live graph. Without a graph
	* the changes stay collected for `applyCollected` once one appears.
	*/
	applyFrame(update) {
		const target = this.targets.get(update.workflowId);
		if (!target) return {
			applied: false,
			nodes: EMPTY_DELTA
		};
		if (!this.getGraph()) return {
			applied: false,
			nodes: pendingNodeDelta(target, target.collector.peek())
		};
		const changes = target.collector.take();
		target.reportedPendingNodes.clear();
		return this.apply(update.workflowId, target, changes, {
			actor: update.actor ?? "agent-remote",
			opIds: update.opIds?.filter((id) => id.length > 0) ?? [],
			liveAgentTurn: isLiveAgentUpdate(update)
		}, this.takeApplyMode(update.workflowId));
	}
	/**
	* Applies the changes collected while no graph could take them: frames
	* delivered before the graph loaded, or while its tab was inactive.
	* @returns the apply result for the whole collected batch.
	*/
	applyCollected(workflowId) {
		const target = this.targets.get(workflowId);
		if (!target || !this.getGraph()) return {
			applied: false,
			nodes: EMPTY_DELTA
		};
		target.reportedPendingNodes.clear();
		return this.apply(workflowId, target, target.collector.take(), {
			actor: "agent-collected",
			opIds: []
		}, this.takeApplyMode(workflowId));
	}
	/** Replays failed frames oldest first until one fails again. */
	retryFailed(workflowId) {
		const target = this.targets.get(workflowId);
		if (!target || target.failedProjections.length === 0 || !this.getGraph()) return null;
		const createdNodeIds = [];
		while (target.failedProjections.length > 0) {
			const failed = target.failedProjections[0];
			const outcome = this.project(workflowId, target, changesAgainstDoc(target.follower.doc, failed.changes), failed.context, failed.mode);
			createdNodeIds.push(...outcome.createdNodeIds);
			if (outcome.failureCount > 0) return {
				applied: true,
				createdNodeIds,
				failureCount: outcome.failureCount
			};
			target.failedProjections.shift();
		}
		return {
			applied: true,
			createdNodeIds,
			failureCount: 0
		};
	}
	hasPendingFailure(workflowId) {
		return (this.targets.get(workflowId)?.failedProjections.length ?? 0) > 0;
	}
	/**
	* Puts the registers a rejected human batch claimed back the way the
	* document has them. Only those registers are touched: the rejection says
	* nothing about the rest of the live graph.
	* @returns the apply result for the rejected operations.
	*/
	revertRejected(workflowId, ops) {
		const target = this.targets.get(workflowId);
		if (!target || ops.length === 0 || !this.getGraph()) return {
			applied: false,
			nodes: EMPTY_DELTA
		};
		return this.apply(workflowId, target, changesForRejectedOps(target.follower.doc, ops), {
			actor: "agent:revert",
			opIds: ops.map((op) => op.op_id)
		});
	}
	/**
	* Explicit lineage reset (`doc_reset`): the old lineage's undelivered
	* changes are dropped and the new lineage's first frame, which carries its
	* whole state, replaces the graph. Nothing is cleared before that frame
	* arrives, so a first mint of the canvas the user already sees changes
	* nothing visible.
	*/
	replaceOnNextFrame(workflowId) {
		const target = this.targets.get(workflowId);
		target?.collector.discard();
		target?.reportedPendingNodes.clear();
		if (target) target.failedProjections.length = 0;
		this.replacedLineages.add(workflowId);
		this.localWrites.clear();
	}
	takeApplyMode(workflowId) {
		return this.replacedLineages.delete(workflowId) ? "replace" : "merge";
	}
	/**
	* Drops a frame the graph already holds, reporting what it changed in the
	* document. Such a frame is where the document catches up on local writes,
	* so their holds are settled against it.
	*/
	discardPending(workflowId) {
		const target = this.targets.get(workflowId);
		if (!target) return EMPTY_DELTA;
		const changes = target.collector.take();
		target.reportedPendingNodes.clear();
		this.localWrites.settleAgainst((nodeId, widget) => readDocWidgetValue(target.follower.doc, nodeId, widget));
		return docNodeDelta(changes);
	}
	destroy() {
		for (const workflowId of Array.from(this.targets.keys())) this.unbind(workflowId);
		this.replacedLineages.clear();
		this.localWrites.clear();
	}
	apply(workflowId, target, changes, context, mode = "merge") {
		const outcome = this.project(workflowId, target, changes, context, mode);
		if (outcome.failureCount > 0) target.failedProjections.push({
			changes,
			context,
			mode
		});
		return outcome;
	}
	project(workflowId, target, changes, context, mode) {
		const { createdNodeIds, failureCount } = this.applier.applyChanges(target.follower.doc, changes, context, mode);
		if (createdNodeIds.length > 0) recordDevEvent("agent_node_adapters_materialized", {
			workflowId,
			nodeIds: createdNodeIds
		});
		return {
			applied: true,
			nodes: docNodeDelta(changes),
			createdNodeIds,
			failureCount
		};
	}
};
//#endregion
//#region src/workbench/extensions/agent/crdt/agentCrdtTransport.ts
/**
* Both of `wireLog.trace`'s sinks drop the detail unless the debug instrument
* is on, so an ungated parse costs every user edit a full `JSON.parse` of the
* `doc_ops` batch `DocFrameClient.send` just serialised, on the main thread,
* for a value nothing reads.
*/
function traceableFrame(frame) {
	if (!isCrdtDebugEnabled()) return null;
	try {
		const parsed = JSON.parse(frame);
		return parsed !== null && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : null;
	} catch {
		return null;
	}
}
function createLoggedTransport(base) {
	return {
		send(frame) {
			const delivered = base.send(frame);
			const parsed = traceableFrame(frame);
			wireLog.trace("ws_out", "outbound frame", {
				delivered,
				frame: parsed,
				...parsed === null ? { unparsed_chars: frame.length } : {}
			});
			return delivered;
		},
		addEventListener(type, listener) {
			base.addEventListener(type, listener);
		},
		removeEventListener(type, listener) {
			base.removeEventListener(type, listener);
		}
	};
}
//#endregion
//#region src/workbench/extensions/agent/crdt/crdtSnapshot.ts
/**
* The follower's read-only view of its own document.
*
* Split out of `crdtDebugReport.ts` so the composable — which every agent
* panel loads eagerly — does not pull the report collector, its redaction
* helpers and the extension store into that bundle. Only the debug panel,
* behind its async boundary, needs those.
*/
/**
* Read every CRDT-observable fact out of a follower doc.
*
* Uses the package's read-only snapshot surface rather than the live Y types:
* those accessors never materialize a root on an empty document and never hand
* back a writable handle, so building a report can never perturb the thing it
* is reporting on.
*/
function readCrdtSnapshot(doc, base) {
	if (doc === null) return {
		...base,
		meta: {},
		nodeIds: [],
		linkIds: [],
		appliedOpIds: [],
		stamps: {}
	};
	try {
		const graph = readGraph(doc);
		return {
			...base,
			meta: readMeta(doc),
			nodeIds: Object.keys(graph.nodes),
			linkIds: Object.keys(graph.links),
			appliedOpIds: appliedOpIds(doc),
			stamps: readStamps(doc)
		};
	} catch (error) {
		return {
			...base,
			schemaError: base.schemaError ?? String(error),
			meta: {},
			nodeIds: [],
			linkIds: [],
			appliedOpIds: [],
			stamps: {}
		};
	}
}
/** Keep this encoded-field cap aligned with cloud's `MaxDocFrameB64Len`. */
var MAX_DOC_UPDATE_B64_LENGTH = 8 << 20;
var MAX_WORKFLOW_ID_LENGTH = 128;
var MAX_ACTOR_LENGTH = 256;
var MAX_AWARENESS_STATE_BYTES = 8192;
var MAX_DOC_OPS_PER_FRAME = 256;
var MAX_OP_ID_LENGTH = 128;
var MAX_ERROR_CODE_LENGTH = 128;
var MAX_ERROR_MESSAGE_LENGTH = 8192;
var BASE64_SINGLE_PADDING_END = /[AEIMQUYcgkosw048]=$/;
var BASE64_DOUBLE_PADDING_END = /[AQgw]==$/;
var utf8 = new TextEncoder();
function decodeBase64(value) {
	if (value === "" || value.length % 4 !== 0) return null;
	const padding = value.endsWith("==") ? 2 : value.endsWith("=") ? 1 : 0;
	if (value.length > MAX_DOC_UPDATE_B64_LENGTH) return null;
	if (!/^[A-Za-z0-9+/]*={0,2}$/.test(value)) return null;
	if (padding === 2 && !BASE64_DOUBLE_PADDING_END.test(value)) return null;
	if (padding === 1 && !BASE64_SINGLE_PADDING_END.test(value)) return null;
	try {
		const binary = atob(value);
		return Uint8Array.from(binary, (character) => character.charCodeAt(0));
	} catch {
		return null;
	}
}
function encodeBase64(value) {
	let binary = "";
	for (const byte of value) binary += String.fromCharCode(byte);
	return btoa(binary);
}
function parseWireData(value) {
	return typeof value === "object" && value !== null ? value : null;
}
function parseRecord(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value) ? Object.fromEntries(Object.entries(value)) : null;
}
function isAbsent(value) {
	return value === null || value === void 0;
}
function hasBoundedUtf8Length(value, maxBytes) {
	return value.length <= maxBytes && utf8.encode(value).length <= maxBytes;
}
function isValidWorkflowId(value) {
	return value.length > 0 && hasBoundedUtf8Length(value, MAX_WORKFLOW_ID_LENGTH) && !/[\0\n\r\t :*?[\]]/.test(value);
}
function isValidActor(value) {
	if (value.length === 0 || !hasBoundedUtf8Length(value, MAX_ACTOR_LENGTH) || /[\0\n\r\t ]/.test(value)) return false;
	if (value === "system:mint") return true;
	return /^(?:agent|human):([^:]+):([^:]+)$/.exec(value) !== null;
}
/**
* Attribution on effect frames is advisory, unlike awareness's actor key.
* Preserve the load-bearing effect and omit attribution that fails grammar.
*/
function parseAdvisoryActor(value) {
	return typeof value === "string" && isValidActor(value) ? value : void 0;
}
function isSequence(value) {
	return typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
}
function parseSequence(value) {
	if (isSequence(value)) return value;
	if (typeof value === "bigint" && value >= 0n && value <= BigInt(Number.MAX_SAFE_INTEGER)) return Number(value);
	return null;
}
function isValidOpId(value) {
	return typeof value === "string" && value.length > 0 && hasBoundedUtf8Length(value, MAX_OP_ID_LENGTH) && !/[\0\n\r\t]/.test(value);
}
function isStringArray(value) {
	return Array.isArray(value) && value.length <= MAX_DOC_OPS_PER_FRAME && value.every(isValidOpId);
}
function parseBoundedString(value, maxBytes) {
	return typeof value === "string" && hasBoundedUtf8Length(value, maxBytes) ? value : void 0;
}
/**
* The relay serialises `applied`/`skipped` with `omitempty`, so an empty list
* arrives as an absent field. Absent means empty; present-but-malformed is a
* protocol violation.
*/
function parseOptionalStringArray(value) {
	if (isAbsent(value)) return [];
	return isStringArray(value) ? value : null;
}
function parseDocOpFailure(value) {
	const failure = parseWireData(value);
	if (failure === null || !isSequence(failure.index) || !isAbsent(failure.op_id) && !isValidOpId(failure.op_id) || typeof failure.code !== "string" || !hasBoundedUtf8Length(failure.code, MAX_ERROR_CODE_LENGTH) || typeof failure.message !== "string" || !hasBoundedUtf8Length(failure.message, MAX_ERROR_MESSAGE_LENGTH)) return null;
	return {
		index: failure.index,
		...!isAbsent(failure.op_id) && { op_id: failure.op_id },
		code: failure.code,
		message: failure.message
	};
}
function encodedJsonSize(value) {
	try {
		const encoded = JSON.stringify(value);
		if (encoded.length > MAX_AWARENESS_STATE_BYTES) return encoded.length;
		return utf8.encode(encoded).length;
	} catch {
		return null;
	}
}
function parseDocReseedResult(workflowId, ok, data) {
	const outcome = parseBoundedString(data.outcome, MAX_ERROR_CODE_LENGTH);
	const code = parseBoundedString(data.code, MAX_ERROR_CODE_LENGTH);
	const message = parseBoundedString(data.message, MAX_ERROR_MESSAGE_LENGTH);
	return {
		workflowId,
		ok,
		...isSequence(data.seq) && { seq: data.seq },
		...outcome !== void 0 && { outcome },
		...code !== void 0 && { code },
		...message !== void 0 && { message }
	};
}
function parseDocSubscribed(workflowId, ok, data) {
	const code = parseBoundedString(data.code, MAX_ERROR_CODE_LENGTH);
	const message = parseBoundedString(data.message, MAX_ERROR_MESSAGE_LENGTH);
	return {
		workflowId,
		ok,
		...isSequence(data.seq) && { seq: data.seq },
		...isSequence(data.expected_seq) && { expectedSeq: data.expected_seq },
		...code !== void 0 && { code },
		...message !== void 0 && { message }
	};
}
function parseResultMetadata(data) {
	const code = parseBoundedString(data.code, MAX_ERROR_CODE_LENGTH);
	const message = parseBoundedString(data.message, MAX_ERROR_MESSAGE_LENGTH);
	const seq = parseSequence(data.seq);
	return {
		...seq !== null && { seq },
		...code !== void 0 && { code },
		...message !== void 0 && { message }
	};
}
function fitsAwarenessBudget(state) {
	const stateSize = encodedJsonSize(state);
	return stateSize !== null && stateSize <= MAX_AWARENESS_STATE_BYTES;
}
function parseAwarenessState(value) {
	if (isAbsent(value)) return { kind: "absent" };
	const state = parseRecord(value);
	if (state === null || !fitsAwarenessBudget(state)) return { kind: "invalid" };
	return {
		kind: "present",
		state
	};
}
var serverFrameParsers = {
	doc_update: (workflowId, data) => {
		const seq = parseSequence(data.seq);
		if (seq === null || typeof data.update_b64 !== "string") return null;
		const update = decodeBase64(data.update_b64);
		if (update === null) return null;
		if (!isAbsent(data.op_ids) && !isStringArray(data.op_ids)) return null;
		const actor = parseAdvisoryActor(data.actor);
		return {
			type: "doc_update",
			data: {
				workflowId,
				seq,
				update,
				...actor !== void 0 && { actor },
				...isStringArray(data.op_ids) && { opIds: data.op_ids }
			}
		};
	},
	doc_subscribed: (workflowId, data) => typeof data.ok === "boolean" ? {
		type: "doc_subscribed",
		data: parseDocSubscribed(workflowId, data.ok, data)
	} : null,
	doc_ops_result: (workflowId, data) => {
		if (typeof data.ok !== "boolean") return null;
		const applied = parseOptionalStringArray(data.applied);
		const skipped = parseOptionalStringArray(data.skipped);
		if (applied === null || skipped === null) return null;
		const failed = parseDocOpFailure(data.failed) ?? void 0;
		return {
			type: "doc_ops_result",
			data: {
				workflowId,
				ok: data.ok,
				applied,
				skipped,
				...parseResultMetadata(data),
				...failed !== void 0 && { failed }
			}
		};
	},
	doc_reset: (workflowId, data) => {
		const reset = data;
		const seq = parseSequence(reset.seq);
		const lineageSeq = parseSequence(reset.lineage_seq);
		if (seq === null || lineageSeq === null) return null;
		const actor = parseAdvisoryActor(reset.actor);
		return {
			type: "doc_reset",
			data: {
				workflowId,
				seq,
				lineageSeq,
				...actor !== void 0 && { actor }
			}
		};
	},
	doc_reseed_result: (workflowId, data) => typeof data.ok === "boolean" ? {
		type: "doc_reseed_result",
		data: parseDocReseedResult(workflowId, data.ok, data)
	} : null,
	awareness: (workflowId, data) => {
		if (typeof data.actor !== "string" || !isValidActor(data.actor)) return null;
		const parsed = parseAwarenessState(data.state);
		if (parsed.kind === "invalid") return null;
		if (!isAbsent(data.expires_at) && !isSequence(data.expires_at)) return null;
		return {
			type: "awareness",
			data: {
				workflowId,
				actor: data.actor,
				...parsed.kind === "present" && { state: parsed.state },
				...isSequence(data.expires_at) && { expiresAt: data.expires_at }
			}
		};
	}
};
function parseServerDocFrame(value) {
	if (typeof value !== "object" || value === null) return null;
	const frame = value;
	const data = parseWireData(frame.data);
	if (data === null || data.v !== 1 || typeof data.workflow_id !== "string" || !isValidWorkflowId(data.workflow_id)) return null;
	if (typeof frame.type !== "string" || !isServerFrameType(frame.type)) return null;
	return serverFrameParsers[frame.type](data.workflow_id, data);
}
function isServerFrameType(type) {
	return Object.hasOwn(serverFrameParsers, type);
}
var DocFrameClient = class extends EventTarget {
	transport;
	listeners = /* @__PURE__ */ new Map();
	constructor(transport) {
		super();
		this.transport = transport;
		const reportedTypes = /* @__PURE__ */ new Set();
		for (const type of SERVER_DOC_FRAME_TYPES) {
			const listener = (event) => {
				if (!(event instanceof CustomEvent)) return;
				const parsed = parseServerDocFrame({
					type,
					data: event.detail
				});
				if (parsed) {
					this.dispatchEvent(new CustomEvent(type, { detail: parsed.data }));
					return;
				}
				if (reportedTypes.has(type)) return;
				reportedTypes.add(type);
				reportError(/* @__PURE__ */ new Error("Discarded invalid server document frame"), {
					surface: "agent",
					errorType: "agent_crdt_invalid_server_frame",
					tags: { frame_type: type },
					level: "warning"
				});
			};
			this.listeners.set(type, listener);
			transport.addEventListener(type, listener);
		}
	}
	/** @returns whether the subscribe frame actually left the transport. */
	subscribe(workflowId, stateVector) {
		return this.send("doc_subscribe", {
			v: 1,
			workflow_id: workflowId,
			state_vector_b64: encodeBase64(stateVector),
			supports_reseed: true,
			schema_version: 5
		});
	}
	reseed(workflowId, expectedSeq, workflow) {
		return this.send("doc_reseed", {
			v: 1,
			workflow_id: workflowId,
			expected_seq: expectedSeq,
			workflow
		});
	}
	/** @returns whether the unsubscribe frame actually left the transport. */
	unsubscribe(workflowId) {
		return this.send("doc_unsubscribe", {
			v: 1,
			workflow_id: workflowId
		});
	}
	/** @returns whether the ops frame actually left the transport. */
	sendOps(workflowId, tab, ops) {
		return this.send("doc_ops", {
			v: 1,
			workflow_id: workflowId,
			tab,
			ops
		});
	}
	destroy() {
		for (const [type, listener] of this.listeners) this.transport.removeEventListener(type, listener);
		this.listeners.clear();
	}
	send(type, data) {
		return this.transport.send(JSON.stringify({
			type,
			data
		}));
	}
};
//#endregion
//#region src/workbench/extensions/agent/crdt/opCoalescer.ts
function createOpCoalescer(admit, flush) {
	let flushScheduled = false;
	let detached = false;
	function flushAdmitted() {
		flushScheduled = false;
		if (!detached) flush();
	}
	return {
		enqueue(operations) {
			if (detached || operations.length === 0) return;
			admit(operations);
			if (flushScheduled) return;
			flushScheduled = true;
			Promise.resolve().then(flushAdmitted);
		},
		detach() {
			detached = true;
		}
	};
}
//#endregion
//#region src/workbench/extensions/agent/crdt/opSender.ts
var SEND_RETRY_LIMIT = 5;
var SEND_RETRY_INTERVAL_MS = 500;
var RESULT_TIMEOUT_MS = 1e4;
var FAILURE_REPORT_WINDOW_MS = 6e4;
var MAX_FAILURE_REPORTS_PER_WINDOW = 3;
/**
* Admits at most {@link MAX_FAILURE_REPORTS_PER_WINDOW} reports per
* {@link FAILURE_REPORT_WINDOW_MS}; the window re-arms by time, not by success.
*/
function createReportBudget() {
	let reports = 0;
	let windowStartedAt = null;
	return () => {
		const now = performance.now();
		if (windowStartedAt === null || now - windowStartedAt >= FAILURE_REPORT_WINDOW_MS) {
			reports = 0;
			windowStartedAt = now;
		}
		if (reports >= MAX_FAILURE_REPORTS_PER_WINDOW) return false;
		reports++;
		return true;
	};
}
function toWireBatch(workflowId, chunk) {
	return {
		workflowId,
		ops: chunk.map((sized) => sized.op),
		wire: chunk.map((sized) => sized.wire)
	};
}
function createOpSender(deps) {
	const queue = [];
	let queueHead = 0;
	let open = null;
	let inFlight = null;
	const lastMintedVersions = /* @__PURE__ */ new Map();
	let detached = false;
	let suspended = false;
	let pumping = false;
	let staleAnonymousBudget = 0;
	const retiredOpIds = /* @__PURE__ */ new Set();
	const mayReportLostEdit = createReportBudget();
	const mayReportSettlementFailure = createReportBudget();
	const mayReportSerializationFailure = createReportBudget();
	function mintBaseVersion(workflowId) {
		const observed = deps.baseVersion();
		if (workflowId === null) return observed;
		const lastMinted = lastMintedVersions.get(workflowId);
		return lastMinted === void 0 ? observed : Math.max(observed, lastMinted + 1);
	}
	function retire(batch, answered) {
		const outstanding = batch.sends - answered;
		if (outstanding <= 0) return;
		staleAnonymousBudget += outstanding;
		for (const opId of batch.opIds) retiredOpIds.add(opId);
	}
	function drainStaleCredit() {
		if (staleAnonymousBudget === 0) return;
		staleAnonymousBudget--;
		if (staleAnonymousBudget === 0) retiredOpIds.clear();
	}
	function reportDegraded(cause, errorType) {
		reportError(cause, {
			errorType,
			surface: "agent",
			tags: {
				feature_area: "agent",
				operation: "sync",
				outcome: "degraded"
			}
		});
	}
	function guardedSettlementNotifier(errorType, code) {
		let reportedFailure = false;
		return (outcome, workflowId) => {
			if (outcome.state !== "acknowledged") reportLostEdit(outcome.state, outcome.ops, {
				code,
				workflowId: workflowId ?? void 0
			}, { shouldReport: mayReportLostEdit() });
			try {
				deps.onBatchSettled(outcome);
			} catch (cause) {
				if (reportedFailure || !mayReportSettlementFailure()) return;
				reportedFailure = true;
				reportDegraded(cause, errorType);
			}
		};
	}
	const notifyDetachSettlement = guardedSettlementNotifier("failure_settling_agent_op_sender_detach", "detached");
	function settle(outcome, code) {
		const workflowId = inFlight?.workflowId ?? null;
		if (inFlight?.timer) clearTimeout(inFlight.timer);
		inFlight = null;
		guardedSettlementNotifier("failure_settling_agent_op_sender", code)(outcome, workflowId);
		pump();
	}
	function transmit(batch, attempt) {
		if (detached || inFlight !== batch) return;
		if (suspended) {
			batch.parked = true;
			return;
		}
		if (deps.workflowId() !== batch.workflowId) {
			settleUnbound(batch, "unbound");
			return;
		}
		if (!trySend(batch)) {
			if (attempt < SEND_RETRY_LIMIT) batch.timer = setTimeout(() => transmit(batch, attempt + 1), SEND_RETRY_INTERVAL_MS);
			else settleUnbound(batch, "transport_exhausted");
			return;
		}
		batch.sends++;
		armResultTimeout(batch);
	}
	function trySend(batch) {
		try {
			return deps.sendOps(batch.workflowId, deps.tab, batch.wire);
		} catch (error) {
			if (!batch.reportedThrow) {
				batch.reportedThrow = true;
				reportError(error, {
					surface: "agent",
					errorType: "failure_sending_agent_human_ops",
					tags: {
						failure_kind: "caught_unexpected",
						feature_area: "agent",
						operation: "sync",
						outcome: "recovered"
					},
					level: "error"
				});
			}
			return false;
		}
	}
	function settleUnbound(batch, code) {
		if (inFlight !== batch) return;
		retire(batch, 0);
		settle({
			state: batch.sends > 0 ? "unconfirmed" : "undeliverable",
			ops: batch.ops
		}, code);
	}
	function armResultTimeout(batch) {
		if (inFlight !== batch) return;
		batch.timer = setTimeout(() => {
			if (inFlight !== batch) return;
			if (batch.resent) {
				retire(batch, 0);
				settle({
					state: "unacknowledged",
					ops: batch.ops
				}, "result_timeout");
				return;
			}
			batch.resent = true;
			batch.reportedThrow = false;
			transmit(batch, 0);
		}, RESULT_TIMEOUT_MS);
	}
	function drainOutstanding(notify) {
		const unsealed = open;
		open = null;
		const queued = queue.slice(queueHead);
		queue.length = 0;
		queueHead = 0;
		const active = inFlight;
		inFlight = null;
		if (active) {
			const batch = active;
			if (batch.timer) clearTimeout(batch.timer);
			retire(batch, 0);
			notify({
				state: batch.sends > 0 ? "unconfirmed" : "undeliverable",
				ops: batch.ops
			}, batch.workflowId);
		}
		for (const batch of queued) notify({
			state: "undeliverable",
			ops: batch.ops
		}, batch.workflowId);
		if (unsealed) for (const chunk of chunkWireOps(unsealed.ops)) notify({
			state: "undeliverable",
			ops: chunk.map((sized) => sized.op)
		}, unsealed.workflowId);
	}
	function dequeue() {
		if (queueHead >= queue.length) return;
		const queued = queue[queueHead];
		queueHead++;
		if (queueHead >= 1024 && queueHead * 2 >= queue.length) {
			queue.splice(0, queueHead);
			queueHead = 0;
		}
		return queued;
	}
	function pump() {
		if (pumping) return;
		pumping = true;
		try {
			while (!detached && inFlight === null) {
				const queued = dequeue();
				if (!queued) return;
				inFlight = {
					...queued,
					opIds: new Set(queued.ops.map((op) => op.op_id)),
					sends: 0,
					reportedThrow: false,
					resent: false,
					parked: false,
					timer: null
				};
				transmit(inFlight, 0);
			}
		} finally {
			pumping = false;
		}
	}
	function settleUndeliverableInBoundedGroups(ops, notify, workflowId) {
		for (let index = 0; index < ops.length; index += 256) notify({
			state: "undeliverable",
			ops: ops.slice(index, index + 256)
		}, workflowId);
	}
	function measureMintedOps(minted) {
		const measured = minted.map(measureWireOp);
		const rejections = measured.filter((result) => !result.admitted);
		return {
			admitted: measured.flatMap((result) => result.admitted ? [result.sized] : []),
			rejected: rejections.map((rejection) => rejection.op),
			cause: rejections[0]?.cause
		};
	}
	function mintAdmission(operations, workflowId) {
		const baseVersion = mintBaseVersion(workflowId);
		const actor = deps.actor();
		const minted = operations.flatMap((operation, index) => mintWireOps([operation], {
			actor,
			baseVersion: baseVersion + index
		}));
		if (workflowId !== null) lastMintedVersions.set(workflowId, baseVersion + minted.length - 1);
		return minted;
	}
	function appendToOpenGroup(workflowId, admitted) {
		if (open?.workflowId !== workflowId) seal();
		if (admitted.length === 0) return;
		if (open) for (const sized of admitted) open.ops.push(sized);
		else open = {
			workflowId,
			ops: admitted
		};
	}
	const admitting = [];
	let flushDeferred = false;
	function admit(operations) {
		if (operations.length === 0) return;
		const workflowId = deps.workflowId();
		const minted = mintAdmission(operations, workflowId);
		const admission = {
			workflowId,
			minted,
			admitted: [],
			rejected: [],
			cause: void 0
		};
		const nested = admitting.length > 0;
		admitting.push(admission);
		Object.assign(admission, measureMintedOps(minted));
		if (nested) return;
		commitAdmissions();
	}
	function commitAdmissions() {
		try {
			for (const admission of admitting) commitAdmission(admission);
		} finally {
			admitting.length = 0;
		}
		if (!flushDeferred) return;
		flushDeferred = false;
		flush();
	}
	function commitAdmission({ workflowId, minted, admitted, rejected, cause }) {
		if (detached) {
			settleUndeliverableInBoundedGroups(minted, notifyDetachSettlement, workflowId);
			return;
		}
		const notifyFailure = guardedSettlementNotifier("failure_settling_agent_op_sender", workflowId === null ? "unbound" : "serialization_failed");
		if (workflowId === null) {
			settleUndeliverableInBoundedGroups(minted, notifyFailure, workflowId);
			return;
		}
		appendToOpenGroup(workflowId, admitted);
		if (rejected.length === 0) return;
		if (mayReportSerializationFailure()) reportDegraded(cause, "failure_serializing_agent_op_sender");
		settleUndeliverableInBoundedGroups(rejected, notifyFailure, workflowId);
	}
	function seal() {
		if (!open) return;
		const { workflowId, ops } = open;
		open = null;
		for (const chunk of chunkWireOps(ops)) queue.push(toWireBatch(workflowId, chunk));
	}
	function flush() {
		if (admitting.length > 0) {
			flushDeferred = true;
			return;
		}
		seal();
		pump();
	}
	function resultBatch(result) {
		if (inFlight === null) return null;
		if (result.workflowId && result.workflowId !== inFlight.workflowId) return null;
		return inFlight;
	}
	function resultOpIds(result) {
		return [
			...result.applied,
			...result.skipped,
			...result.failed?.op_id ? [result.failed.op_id] : []
		];
	}
	function settleResult(batch, result) {
		retire(batch, 1);
		settle({
			state: "acknowledged",
			ops: batch.ops,
			result
		}, "host_result");
	}
	function settleIdentifiedResult(batch, result, opIds) {
		if (batch && opIds.some((opId) => batch.opIds.has(opId))) {
			settleResult(batch, result);
			return;
		}
		if (opIds.some((opId) => retiredOpIds.has(opId))) drainStaleCredit();
	}
	function handleOpsResult(result) {
		if (detached) return;
		if (inFlight === null && staleAnonymousBudget === 0) return;
		const opIds = resultOpIds(result);
		const batch = resultBatch(result);
		if (opIds.length > 0) return settleIdentifiedResult(batch, result, opIds);
		if (batch === null || staleAnonymousBudget > 0) {
			drainStaleCredit();
			return;
		}
		if (batch.sends === 0) return;
		settleResult(batch, result);
	}
	const unsubscribe = deps.onOpsResult(handleOpsResult);
	return {
		enqueue(operations) {
			seal();
			admit(operations);
			flush();
		},
		admit,
		flush,
		pending() {
			return queue.length - queueHead + (inFlight ? 1 : 0) + (open ? 1 : 0);
		},
		pendingOps() {
			const batches = inFlight ? [{
				workflowId: inFlight.workflowId,
				ops: inFlight.ops
			}] : [];
			const unsealed = open ? [{
				workflowId: open.workflowId,
				ops: open.ops.map((s) => s.op)
			}] : [];
			const queued = queue.slice(queueHead).map(({ workflowId, ops }) => ({
				workflowId,
				ops
			}));
			return [
				...batches,
				...queued,
				...unsealed
			];
		},
		suspend() {
			suspended = true;
		},
		resume() {
			suspended = false;
			if (inFlight?.parked) {
				inFlight.parked = false;
				transmit(inFlight, 0);
			}
		},
		abortIfUnbound() {
			if (inFlight && deps.workflowId() !== inFlight.workflowId) settleUnbound(inFlight, "unbound");
		},
		abortAll() {
			const resetWorkflowId = deps.workflowId();
			if (resetWorkflowId !== null) lastMintedVersions.delete(resetWorkflowId);
			drainOutstanding(guardedSettlementNotifier("failure_settling_agent_op_sender_abort", "doc_reset"));
		},
		detach() {
			if (detached) return;
			detached = true;
			try {
				drainOutstanding(notifyDetachSettlement);
				staleAnonymousBudget = 0;
				retiredOpIds.clear();
			} finally {
				try {
					unsubscribe();
				} catch (cause) {
					reportDegraded(cause, "failure_unsubscribing_agent_op_sender");
				}
			}
		}
	};
}
//#endregion
//#region src/workbench/extensions/agent/crdt/rejectedOpNotice.ts
var NOTICE_LIFE_MS = 1e4;
var NOTICE_ID = createToastId();
function rejectedOp(ops, failed) {
	return ops.find((op) => op.op_id === failed.op_id) ?? ops[failed.index];
}
/**
* Doc-host codes for a refused widget write. Both halves are load-bearing: the
* applier raises `uncatalogued_widget_write` and `unknown_widget` for
* `add_node` too, so the op the host NAMED must also be a widget write; and a
* `set_widget` refused for an unrelated reason (`catalog_required`,
* `malformed_op`) is not a widget-addressing failure and gets the generic copy.
*/
var WIDGET_WRITE_REJECTION_CODES = /* @__PURE__ */ new Set([
	"opaque_widgets",
	"uncatalogued_widget_write",
	"unknown_widget",
	"widget_out_of_range"
]);
function isRejectedWidgetWrite(ops, failed) {
	if (failed === void 0) return false;
	return WIDGET_WRITE_REJECTION_CODES.has(failed.code) && rejectedOp(ops, failed)?.op === "set_widget";
}
function nodeFieldTarget(nodeId, field) {
	const t = i18n.global.t;
	return t("agent.editRejected.targets.nodeField", {
		id: String(nodeId),
		field
	}, { escapeParameter: false });
}
function rejectedTarget(op) {
	const t = i18n.global.t;
	const plain = { escapeParameter: false };
	switch (op?.op) {
		case "set_widget": return nodeFieldTarget(op.node_id, op.widget);
		case "add_node": return op.class_type;
		case "set_node_field": return nodeFieldTarget(op.node_id, op.field);
		case "delete_node": return t("agent.editRejected.targets.node", { id: String(op.node_id) }, plain);
		case "clear": return t("agent.editRejected.targets.clear");
		case "connect":
		case "disconnect": return t("agent.editRejected.targets.link", { id: String(op.link_id) }, plain);
		default: return;
	}
}
function rejectedOpContext(op) {
	switch (op?.op) {
		case "set_widget":
		case "set_node_field":
		case "delete_node": return { nodeId: op.node_id };
		case "add_node": return {
			nodeId: op.node_id,
			classType: op.class_type
		};
		default: return {};
	}
}
function withReason(notice, target, code) {
	const plain = { escapeParameter: false };
	if (target && code && code !== "unspecified") return i18n.global.t("agent.editRejected.withReason", {
		notice,
		target,
		code
	}, plain);
	if (target) return i18n.global.t("agent.editRejected.withReasonTarget", {
		notice,
		target
	}, plain);
	if (!code || code === "unspecified") return notice;
	return i18n.global.t("agent.editRejected.withReasonCode", {
		notice,
		code
	}, plain);
}
/**
* Schema §4 aborts the REMAINDER of a batch, so a rejected result can still
* carry an applied prefix — which is what `partial` distinguishes.
*/
function noticeKey(widgetWrite, partial) {
	if (widgetWrite) return partial ? "agent.editRejected.widgetWritePartial" : "agent.editRejected.widgetWrite";
	return partial ? "agent.editRejected.genericPartial" : "agent.editRejected.generic";
}
function createRejectedOpNotifier() {
	const throttledToasts = /* @__PURE__ */ new Map();
	function showToast(kind, description) {
		const toast = throttledToasts.get(kind);
		if (toast) return toast(description);
		const throttled = throttle((detail) => useToast().error(i18n.global.t("g.error"), {
			id: NOTICE_ID,
			description: detail,
			duration: NOTICE_LIFE_MS
		}), NOTICE_LIFE_MS, { edges: ["leading"] });
		throttledToasts.set(kind, throttled);
		throttled(description);
	}
	function reportRejectedEdit(ops, result, failed, code, widgetWrite) {
		const accepted = /* @__PURE__ */ new Set([...result.applied, ...result.skipped]);
		reportLostEdit("host_rejected", ops.filter((op) => !accepted.has(op.op_id)), {
			code,
			workflowId: result.workflowId,
			message: failed?.message,
			failedIndex: failed?.index,
			errorType: widgetWrite ? "error_applying_agent_widget_edit" : "error_applying_agent_graph_edit",
			...rejectedOpContext(failed && rejectedOp(ops, failed))
		});
	}
	function notifyRejected(ops, result) {
		const { failed } = result;
		const widgetWrite = isRejectedWidgetWrite(ops, failed);
		const code = failed?.code ?? result.code ?? "unspecified";
		reportRejectedEdit(ops, result, failed, code, widgetWrite);
		const kind = noticeKey(widgetWrite, result.applied.length > 0 && failed !== void 0);
		showToast(kind, withReason(i18n.global.t(kind), failed && rejectedTarget(rejectedOp(ops, failed)), code));
	}
	return {
		notify(ops, result) {
			if (result.ok) return;
			notifyRejected(ops, result);
		},
		notifyWidgetWriteRefused(nodeId, widgetName) {
			showToast("agent.editRejected.widgetWrite", withReason(i18n.global.t("agent.editRejected.widgetWrite"), nodeFieldTarget(nodeId, widgetName), "unspecified"));
		}
	};
}
//#endregion
//#region src/workbench/extensions/agent/crdt/useAgentCrdtFollower.ts
var NOTHING_APPLIED = {
	applied: false,
	nodes: {
		added: [],
		removed: []
	}
};
function isAgentFrame(actor) {
	return actor === void 0 || actor.startsWith("agent:");
}
function projectionAppliedCleanly(outcome) {
	return outcome.applied && outcome.failureCount === 0;
}
function reportAgentProjection(frame, stage, outcome) {
	const opIds = frame.opIds?.filter((id) => id.length > 0) ?? [];
	useTelemetry()?.trackAgentGraphProjection({
		op_id: opIds[0] ?? null,
		op_count: opIds.length,
		sequence: frame.seq,
		stage,
		added_count: outcome.nodes.added.length,
		removed_count: outcome.nodes.removed.length,
		apply_failure_count: outcome.applied ? outcome.failureCount : 0
	});
}
function liveAddedNodeIds(added, graph) {
	if (!graph) return [];
	return added.flatMap((id) => {
		const nodeId = parseNodeId(id);
		return nodeId && graph.getNodeById(nodeId) ? [nodeId] : [];
	});
}
function emitPendingMaterializations(workflowId, actor, available, pending, events) {
	const nodeIds = [...pending].filter((id) => available.has(id));
	for (const nodeId of nodeIds) pending.delete(nodeId);
	if (nodeIds.length === 0) return;
	events.onMaterialized?.({
		workflowId,
		actor,
		nodeIds
	});
}
function handleSubscribeRefusal(detail, lifecycle) {
	const code = typeof detail?.code === "string" ? detail.code : void 0;
	return {
		shouldNotify: lifecycle.onSubscribeRefused(code),
		message: typeof detail?.message === "string" ? detail.message : void 0,
		code
	};
}
function notifyAgentMaterialization(update, nodes, materialized, graph, pendingLiveNodeIds, events) {
	for (const id of nodes.removed) {
		const nodeId = parseNodeId(id);
		if (nodeId) pendingLiveNodeIds.delete(nodeId);
	}
	const liveAgentUpdate = isLiveAgentUpdate(update);
	if (liveAgentUpdate) {
		for (const nodeId of materialized) pendingLiveNodeIds.add(nodeId);
		for (const id of nodes.added) {
			const nodeId = parseNodeId(id);
			if (nodeId) pendingLiveNodeIds.add(nodeId);
		}
	}
	const available = /* @__PURE__ */ new Set([...materialized, ...liveAddedNodeIds(nodes.added, graph)]);
	emitPendingMaterializations(update.workflowId, liveAgentUpdate ? update.actor : void 0, available, pendingLiveNodeIds, events);
}
function hasNodes(canvas) {
	return Array.isArray(canvas?.nodes) && canvas.nodes.length > 0;
}
function opsResultDropReason(active, workflowId, subscribedWorkflowId) {
	if (!active) return "inactive_target";
	return workflowId === subscribedWorkflowId ? null : "workflow_mismatch";
}
function notifyAppliedUpdate(update, outcome, events) {
	if (!outcome.applied || outcome.failureCount > 0) return;
	events.onAppliedUpdate?.({
		workflowId: update.workflowId,
		opIds: update.opIds ?? [],
		isLive: !update.catchUp
	});
}
function runFollowerTeardown(cleanups) {
	for (const cleanup of cleanups) try {
		cleanup();
	} catch (error) {
		reportError(error, {
			surface: "agent",
			errorType: "failure_tearing_down_agent_crdt_follower"
		});
	}
}
function useAgentCrdtFollower(workflowId, { transport, userId = () => null, isTargetActive = ref(true), getGraph = () => null, events = {}, applierDeps = {}, canvasFor = () => null }) {
	const productGate = useAgentPanelStore();
	const follower = shallowRef();
	const disabledStatus = {
		enabled: false,
		connected: false,
		canvasMayBeStale: false,
		workflowId: null,
		updatesApplied: 0,
		lastFrameType: null,
		terminal: null,
		outcomes: {
			received: 0,
			applied: 0,
			appliedLive: 0,
			skipped: 0,
			errored: 0,
			gap: 0,
			reset: 0,
			dropped: 0
		}
	};
	const status = computed(() => follower.value?.status.value ?? disabledStatus);
	watch(() => productGate.enabled, (enabled, _previous, onCleanup) => {
		if (!enabled) return;
		const scope = effectScope();
		onCleanup(() => {
			follower.value = void 0;
			scope.stop();
		});
		follower.value = scope.run(() => startAgentCrdtFollower(workflowId, {
			transport,
			userId,
			isTargetActive,
			getGraph,
			events,
			applierDeps,
			canvasFor
		}));
	}, {
		immediate: true,
		flush: "sync"
	});
	return {
		status: readonly(status),
		debugSnapshot: () => follower.value?.debugSnapshot() ?? readCrdtSnapshot(null, {
			status: status.value,
			tabId: null,
			lastSeq: null,
			schemaError: null
		}),
		enqueueHumanOperations: (operations) => follower.value?.enqueueHumanOperations(operations),
		retrySubscription: () => follower.value?.retrySubscription(),
		docInputNames: (nodeId) => follower.value?.docInputNames(nodeId) ?? null,
		docWidgetValue: (nodeId, widgetName) => follower.value?.docWidgetValue(nodeId, widgetName),
		docPromotedWidgets: (nodeId) => follower.value?.docPromotedWidgets(nodeId) ?? null,
		mayWritePromotedHost: (nodeId) => follower.value?.mayWritePromotedHost(nodeId) ?? false,
		docHasSubgraphDefinition: (definitionId) => follower.value?.docHasSubgraphDefinition(definitionId) ?? false,
		notifyWidgetWriteRefused: (nodeId, widgetName) => follower.value?.notifyWidgetWriteRefused(nodeId, widgetName),
		subscriptionSent: () => follower.value?.subscriptionSent() ?? false
	};
}
function startAgentCrdtFollower(workflowId, { transport, userId, isTargetActive, getGraph, events, applierDeps, canvasFor }) {
	const connected = ref(false);
	let catchUpAwaitingProjectionFor = null;
	const syncCanvasMayBeStale = ref(false);
	const projectionFailureFor = ref(null);
	const canvasMayBeStale = computed(() => syncCanvasMayBeStale.value || projectionFailureFor.value !== null);
	const terminal = ref(null);
	const updatesApplied = ref(0);
	const lastFrameType = ref(null);
	const subscribedWorkflowId = ref(null);
	const outcomes = ref({
		received: 0,
		applied: 0,
		appliedLive: 0,
		skipped: 0,
		errored: 0,
		gap: 0,
		reset: 0,
		dropped: 0
	});
	const client = new DocFrameClient(createLoggedTransport(transport));
	const bridge = new LayoutFollowerBridge(client);
	const lifecycle = new AgentCrdtDocLifecycle(() => subscribedWorkflowId.value, () => bridge.resubscribe(), (reason) => {
		connected.value = false;
		terminal.value = reason;
	});
	const tabId = createUuidv4();
	const ownActor = () => `human:${userId() ?? "anonymous"}:${tabId}`;
	const confirmedDeletes = /* @__PURE__ */ new Set();
	const rejectedOpNotifier = createRejectedOpNotifier();
	const sentAddsByDoc = /* @__PURE__ */ new WeakMap();
	const sentAddsToCurrentDoc = () => {
		const doc = bridge.follower.doc;
		const sentAdds = sentAddsByDoc.get(doc) ?? /* @__PURE__ */ new Set();
		sentAddsByDoc.set(doc, sentAdds);
		return sentAdds;
	};
	const projection = new AgentCrdtProjection(getGraph, applierDeps);
	const pendingRejected = /* @__PURE__ */ new Map();
	function markCanvasStale() {
		syncCanvasMayBeStale.value = true;
		catchUpAwaitingProjectionFor = null;
	}
	function markProjectionStale(workflowId) {
		projectionFailureFor.value = workflowId;
	}
	function clearProjectionStaleness(workflowId) {
		if (projectionFailureFor.value === workflowId) projectionFailureFor.value = null;
	}
	function clearSyncStaleness() {
		syncCanvasMayBeStale.value = false;
		catchUpAwaitingProjectionFor = null;
	}
	function clearCanvasStaleness() {
		syncCanvasMayBeStale.value = false;
		projectionFailureFor.value = null;
		catchUpAwaitingProjectionFor = null;
	}
	const applyRejectedOps = (workflowId, rejected, seq = bridge.lastSequence) => {
		if (getGraph() === null) return false;
		const projectionOutcome = projection.revertRejected(workflowId, rejected);
		if (!projectionOutcome.applied) return true;
		reportMaterialized(workflowId, projectionOutcome.createdNodeIds);
		reportAgentProjection({
			opIds: rejected.map((op) => op.op_id),
			seq
		}, "reverted", projectionOutcome);
		return true;
	};
	const drainRejectedOps = (workflowId) => {
		const rejected = pendingRejected.get(workflowId);
		if (!rejected) return;
		if (applyRejectedOps(workflowId, rejected)) pendingRejected.delete(workflowId);
	};
	const trackAcknowledgedDeletes = (outcome) => {
		const applied = new Set(outcome.result.applied);
		for (const op of outcome.ops) if (op.op === "delete_node" && applied.has(op.op_id)) confirmedDeletes.add(String(op.node_id));
		rejectedOpNotifier.notify(outcome.ops, outcome.result);
	};
	const revertRejectedOps = (outcome) => {
		const workflowId = outcome.result.workflowId ?? bridge.subscribedWorkflowId;
		if (workflowId === null) return;
		const applied = new Set(outcome.result.applied);
		const rejected = outcome.ops.filter((op) => !applied.has(op.op_id));
		if (!isTargetActive.value) {
			pendingRejected.set(workflowId, [...pendingRejected.get(workflowId) ?? [], ...rejected]);
			return;
		}
		if (!applyRejectedOps(workflowId, rejected, outcome.result.seq)) pendingRejected.set(workflowId, [...pendingRejected.get(workflowId) ?? [], ...rejected]);
	};
	const workflowByUnsettledOpId = /* @__PURE__ */ new Map();
	const workflowsWithLostOps = /* @__PURE__ */ new Set();
	const recordUnsynced = () => {
		const unsynced = new Set(workflowsWithLostOps);
		for (const { workflowId, ops } of sender.pendingOps()) {
			unsynced.add(workflowId);
			for (const op of ops) workflowByUnsettledOpId.set(op.op_id, workflowId);
		}
		recordUnsyncedHumanOps(tabId, unsynced);
	};
	const noteSettledHumanOps = (outcome) => {
		const workflowId = workflowByUnsettledOpId.get(outcome.ops[0]?.op_id ?? "");
		for (const op of outcome.ops) workflowByUnsettledOpId.delete(op.op_id);
		if (workflowId !== void 0 && outcome.state !== "acknowledged") workflowsWithLostOps.add(workflowId);
		recordUnsynced();
	};
	const settleHumanOps = (outcome) => {
		if (outcome.state === "acknowledged") {
			trackAcknowledgedDeletes(outcome);
			recordDevEvent("human_ops_settled", outcome);
		}
		projection.settleLocalWrites(outcome.ops);
		if (outcome.state === "acknowledged" && !outcome.result.ok) revertRejectedOps(outcome);
		noteSettledHumanOps(outcome);
	};
	const sender = createOpSender({
		sendOps: (target, tab, ops) => client.sendOps(target, tab, ops),
		onOpsResult(listener) {
			const handler = (event) => {
				if (event instanceof CustomEvent) listener(event.detail);
			};
			bridge.addEventListener("doc_ops_result", handler);
			return () => bridge.removeEventListener("doc_ops_result", handler);
		},
		workflowId: () => bridge.subscribedWorkflowId,
		get tab() {
			return tabId;
		},
		actor: ownActor,
		baseVersion: () => bridge.lastSequence,
		onBatchSettled: settleHumanOps
	});
	const coalescer = createOpCoalescer((operations) => {
		sender.admit(operations);
		recordUnsynced();
	}, sender.flush);
	const pendingLiveNodeIds = /* @__PURE__ */ new Set();
	const pendingProjectionFrames = /* @__PURE__ */ new Map();
	const reportMaterialized = (workflowId, materialized) => {
		emitPendingMaterializations(workflowId, void 0, new Set(materialized), pendingLiveNodeIds, events);
	};
	const retainPendingFrame = (update) => {
		const frames = pendingProjectionFrames.get(update.workflowId);
		const frame = {
			opIds: update.opIds,
			seq: update.seq,
			isLive: !update.catchUp
		};
		if (frames) frames.push(frame);
		else pendingProjectionFrames.set(update.workflowId, [frame]);
	};
	const reportPendingFrames = (workflowId, stage, outcome) => {
		const frames = pendingProjectionFrames.get(workflowId);
		pendingProjectionFrames.delete(workflowId);
		for (const frame of frames ?? []) reportAgentProjection(frame, stage, outcome);
	};
	const notifyPendingFramesApplied = (workflowId, frames) => {
		for (const frame of frames) events.onAppliedUpdate?.({
			workflowId,
			opIds: frame.opIds ?? [],
			isLive: frame.isLive ?? true
		});
	};
	const flushPendingFrames = (workflowId, outcome) => {
		if (projectionAppliedCleanly(outcome)) notifyPendingFramesApplied(workflowId, pendingProjectionFrames.get(workflowId) ?? []);
		reportPendingFrames(workflowId, "applied_deferred", outcome);
	};
	const reportFrameProjection = (update, outcome) => {
		const stage = outcome.applied ? "applied" : getGraph() === null ? "received_no_graph" : "discarded";
		if (isAgentFrame(update.actor)) reportAgentProjection(update, stage, stage === "discarded" ? NOTHING_APPLIED : outcome);
		if (stage === "received_no_graph") {
			if (isAgentFrame(update.actor)) retainPendingFrame(update);
			return;
		}
		if (stage === "applied") flushPendingFrames(update.workflowId, outcome);
		else reportPendingFrames(update.workflowId, "discarded", NOTHING_APPLIED);
	};
	const settleCollectedProjection = (workflowId, outcome, pendingFrames) => {
		if (outcome.failureCount > 0) {
			markProjectionStale(workflowId);
			return;
		}
		notifyPendingFramesApplied(workflowId, pendingFrames);
		if (!projection.hasPendingFailure(workflowId)) clearProjectionStaleness(workflowId);
	};
	const applyCollected = (workflowId) => {
		const pendingFrames = pendingProjectionFrames.get(workflowId) ?? [];
		const outcome = projection.applyCollected(workflowId);
		if (!outcome.applied) return;
		const settlesCatchUp = catchUpAwaitingProjectionFor === workflowId;
		settleCollectedProjection(workflowId, outcome, pendingFrames);
		if (settlesCatchUp) clearSyncStaleness();
		reportMaterialized(workflowId, outcome.createdNodeIds);
		reportPendingFrames(workflowId, "applied_deferred", outcome);
	};
	const incrementOutcome = (key) => {
		outcomes.value = {
			...outcomes.value,
			[key]: outcomes.value[key] + 1
		};
	};
	const isCurrentWorkflow = (workflowId) => isTargetActive.value && workflowId === subscribedWorkflowId.value;
	/**
	* The host echoes this tab's own ops back as a `doc_update`. The graph
	* already holds that edit (the intent was minted from it), so the frame is
	* merged into the doc and never re-applied. Catch-up frames are exempt:
	* they can carry this actor as the last writer while replaying state the
	* graph has not seen.
	*/
	const isOwnEcho = (update) => !update.catchUp && update.actor === ownActor();
	const applyFrame = (update) => {
		if (isOwnEcho(update) && getGraph() !== null) {
			const nodes = projection.discardPending(update.workflowId);
			incrementOutcome("skipped");
			return {
				applied: false,
				nodes
			};
		}
		const outcome = projection.applyFrame(update);
		incrementOutcome(outcome.applied ? "applied" : "skipped");
		if (outcome.applied && !update.catchUp) incrementOutcome("appliedLive");
		return outcome;
	};
	function tryReseed() {
		const target = subscribedWorkflowId.value;
		if (target === null || !bridge.canReseed(target)) return false;
		const canvas = canvasFor(target);
		if (!hasNodes(canvas) || !bridge.reseed(target, canvas)) return false;
		recordDevEvent("doc_reseed_sent", { workflowId: target });
		lifecycle.onSubscribeSent(target);
		return true;
	}
	const onReseedResult = (event) => {
		if (!(event instanceof CustomEvent)) return;
		const detail = event.detail;
		if (!isCurrentWorkflow(detail?.workflowId)) return;
		lastFrameType.value = event.type;
		recordDevEvent("doc_reseed_result", detail);
		const code = typeof detail.code === "string" ? detail.code : void 0;
		if (detail.ok === true || code === "conflict") return;
		if (isRetryableReseedCode(code)) lifecycle.onSubscribeRefused(code);
		else {
			lifecycle.stopProbing();
			terminal.value = "refused";
		}
	};
	function handleRejectedSubscription(detail) {
		const reseeding = tryReseed();
		const refusal = reseeding ? { shouldNotify: false } : handleSubscribeRefusal(detail, lifecycle);
		if (!reseeding && refusal.code !== void 0 && isPermanentSubscribeRefusalCode(refusal.code) && lifecycle.refusalIsFinal()) terminal.value = "refused";
		releaseHeldOps();
		sender.abortIfUnbound();
		if (refusal.shouldNotify) events.onSyncError?.(refusal.message, refusal.code);
	}
	function subscribeBaselineIsIntegrated(seq) {
		return (seq ?? 0) === 0 || bridge.isSubscribeBaselineIntegrated;
	}
	function retryFailedProjection(workflowId) {
		const outcome = projection.retryFailed(workflowId);
		if (outcome === null) {
			const pending = projection.hasPendingFailure(workflowId) || getGraph() === null && projectionFailureFor.value === workflowId;
			if (!pending) clearProjectionStaleness(workflowId);
			return !pending;
		}
		reportMaterialized(workflowId, outcome.createdNodeIds);
		if (outcome.failureCount === 0) {
			clearProjectionStaleness(workflowId);
			return true;
		}
		markProjectionStale(workflowId);
		return false;
	}
	const onSubscribed = (event) => {
		if (!(event instanceof CustomEvent)) return;
		if (!isTargetActive.value) return;
		const detail = event.detail;
		const ok = detail?.ok === true;
		connected.value = ok;
		lastFrameType.value = event.type;
		recordDevEvent("doc_subscribed", event.detail ?? null);
		if (ok) {
			const workflowId = subscribedWorkflowId.value;
			if ((workflowId === null || retryFailedProjection(workflowId)) && subscribeBaselineIsIntegrated(detail.seq)) clearCanvasStaleness();
			terminal.value = null;
			lifecycle.onSubscribeConfirmed();
			forgetUnsyncedAtLoad(subscribedWorkflowId.value);
			resumeHeldOpsIfSubscribed();
		} else handleRejectedSubscription(detail);
	};
	function settleCatchUpProjection(update, outcome) {
		if (outcome.applied ? outcome.failureCount > 0 : getGraph() === null) markProjectionStale(update.workflowId);
		else if (projectionAppliedCleanly(outcome) && !projection.hasPendingFailure(update.workflowId)) clearProjectionStaleness(update.workflowId);
		if (!update.catchUp) return;
		if (outcome.applied) clearSyncStaleness();
		else catchUpAwaitingProjectionFor = update.workflowId;
	}
	const onUpdate = (event) => {
		if (!(event instanceof CustomEvent)) return;
		const update = event.detail;
		incrementOutcome("received");
		if (!isCurrentWorkflow(update.workflowId)) {
			incrementOutcome("skipped");
			return;
		}
		lifecycle.onDocumentUpdate();
		updatesApplied.value = bridge.follower.updatesApplied;
		lastFrameType.value = event.type;
		retryFailedProjection(update.workflowId);
		const outcome = applyFrame(update);
		settleCatchUpProjection(update, outcome);
		notifyAppliedUpdate(update, outcome, events);
		const nodes = outcome.nodes;
		const created = outcome.applied ? outcome.createdNodeIds : [];
		reportFrameProjection(update, outcome);
		recordDevEvent("doc_update", {
			workflowId: update.workflowId,
			seq: update.seq,
			actor: update.actor,
			echo: isOwnEcho(update),
			bytes: update.update instanceof Uint8Array ? update.update.length : null
		});
		if (nodes.added.length > 0 || nodes.removed.length > 0) recordDevEvent("doc_nodes_changed", nodes);
		notifyAgentMaterialization(update, nodes, created, getGraph(), pendingLiveNodeIds, events);
	};
	const onOpsResult = (event) => {
		if (!(event instanceof CustomEvent)) return;
		const detail = event.detail;
		const dropReason = opsResultDropReason(isTargetActive.value, detail?.workflowId, subscribedWorkflowId.value);
		if (dropReason !== null) {
			recordDevEvent("doc_ops_result_dropped", {
				reason: dropReason,
				subscribedWorkflowId: subscribedWorkflowId.value,
				frame: event.detail ?? null
			});
			return;
		}
		lifecycle.onDocumentResult();
		lastFrameType.value = event.type;
		recordDevEvent("doc_ops_result", event.detail ?? null);
	};
	const onDocReset = (event) => {
		const detail = event instanceof CustomEvent ? event.detail : void 0;
		incrementOutcome("reset");
		if (!isCurrentWorkflow(detail?.workflowId)) return;
		projection.replaceOnNextFrame(detail.workflowId);
		reportPendingFrames(detail.workflowId, "discarded", NOTHING_APPLIED);
		sender.abortAll();
		workflowsWithLostOps.delete(detail.workflowId);
		recordUnsynced();
		events.onReset?.(detail.workflowId);
		connected.value = false;
		markCanvasStale();
		updatesApplied.value = 0;
		lastFrameType.value = event.type;
		lifecycle.clearStaleProbe();
		lifecycle.resetNotifiedGiveUp();
		pendingLiveNodeIds.clear();
		recordDevEvent("doc_reset", event instanceof CustomEvent ? event.detail ?? null : null);
	};
	const onFollowerReplaced = (event) => {
		if (!(event instanceof CustomEvent)) return;
		const workflowId = event.detail?.workflowId;
		if (isTargetActive.value && typeof workflowId === "string" && workflowId === subscribedWorkflowId.value) {
			updatesApplied.value = 0;
			projection.discardPending(workflowId);
			reportPendingFrames(workflowId, "discarded", NOTHING_APPLIED);
			projection.bind(workflowId, bridge.follower);
		}
	};
	const staleClientNotified = /* @__PURE__ */ new Set();
	const onSchemaError = (event) => {
		connected.value = false;
		markCanvasStale();
		terminal.value = "schema_error";
		lastFrameType.value = event.type;
		lifecycle.clearStaleProbe();
		const detail = event instanceof CustomEvent ? event.detail : null;
		if (detail?.workflowId !== void 0) {
			projection.discardPending(detail.workflowId);
			reportPendingFrames(detail.workflowId, "discarded", NOTHING_APPLIED);
		}
		outcomes.value = {
			...outcomes.value,
			errored: outcomes.value.errored + 1
		};
		recordDevEvent("schema_error", event instanceof CustomEvent ? event.detail ?? null : null);
		notifyStaleClient(detail);
	};
	function notifyStaleClient(detail) {
		const found = detail?.found;
		const skew = docSchemaSkew(found);
		const workflowId = detail?.workflowId;
		if (skew === null || workflowId === void 0) return;
		const notificationKey = `${workflowId}:${skew}`;
		if (staleClientNotified.has(notificationKey)) return;
		staleClientNotified.add(notificationKey);
		if (skew === "newer") {
			events.onSyncError?.(`document schema v${found} is newer than this page reads (v5)`, "stale_client_schema");
			return;
		}
		events.onSyncError?.(`document schema v${found} is older than this page reads (v5)`, "stale_host_schema");
	}
	const onGap = (event) => {
		connected.value = false;
		markCanvasStale();
		outcomes.value = {
			...outcomes.value,
			gap: outcomes.value.gap + 1
		};
		recordDevEvent("doc_gap", event instanceof CustomEvent ? event.detail ?? null : null);
	};
	const onStale = (event) => {
		outcomes.value = {
			...outcomes.value,
			dropped: outcomes.value.dropped + 1
		};
		recordDevEvent("doc_stale", event instanceof CustomEvent ? event.detail ?? null : null);
	};
	const onSubscribeSent = (event) => {
		if (!(event instanceof CustomEvent)) return;
		const detail = event.detail;
		if (typeof detail?.workflowId !== "string") return;
		lifecycle.onSubscribeSent(detail.workflowId);
	};
	function onSocketStatus(live) {
		if (!live) {
			if (connected.value) markCanvasStale();
			connected.value = false;
			return;
		}
		connected.value = false;
		terminal.value = null;
		lifecycle.onReconnected();
		recordDevEvent("reconnected", null);
		bridge.reconnect();
	}
	bridge.addEventListener("doc_subscribed", onSubscribed);
	bridge.addEventListener("doc_update", onUpdate);
	bridge.addEventListener("doc_ops_result", onOpsResult);
	bridge.addEventListener("doc_reset", onDocReset);
	bridge.addEventListener("follower_replaced", onFollowerReplaced);
	bridge.addEventListener("schema_error", onSchemaError);
	bridge.addEventListener("doc_gap", onGap);
	bridge.addEventListener("doc_stale", onStale);
	bridge.addEventListener("doc_subscribe_sent", onSubscribeSent);
	bridge.addEventListener("doc_reseed_result", onReseedResult);
	const stopTransportStatus = transport.onSocketStatus(onSocketStatus);
	let initialBind = true;
	watch(getGraph, (graph) => {
		const bound = subscribedWorkflowId.value;
		if (graph && bound !== null && isTargetActive.value) {
			applyCollected(bound);
			drainRejectedOps(bound);
		}
	});
	const rebindProjection = (next) => {
		const current = subscribedWorkflowId.value;
		if (current === next) return;
		clearCanvasStaleness();
		if (current !== null) {
			projection.unbind(current);
			reportPendingFrames(current, "discarded", NOTHING_APPLIED);
		}
		if (next !== null) projection.bind(next, bridge.follower);
		subscribedWorkflowId.value = next;
	};
	let heldForWorkflowId = null;
	const releaseHeldOps = () => {
		heldForWorkflowId = null;
		sender.resume();
	};
	const resumeHeldOpsIfSubscribed = () => {
		if (heldForWorkflowId !== null && bridge.subscribedWorkflowId === heldForWorkflowId) releaseHeldOps();
	};
	const holdOpsForInactiveTab = (workflowId) => {
		heldForWorkflowId = workflowId;
		sender.suspend();
		bridge.unsubscribe();
	};
	const retarget = (next) => {
		sender.flush();
		if (next === null) bridge.unsubscribe();
		else bridge.subscribe(next);
		if (next !== null && next === heldForWorkflowId) {
			resumeHeldOpsIfSubscribed();
			return;
		}
		releaseHeldOps();
		sender.abortIfUnbound();
	};
	const deactivateTarget = (next, previousWorkflowId) => {
		if (next !== null) initialBind = false;
		if (next !== null && next === previousWorkflowId) {
			if (connected.value || canvasMayBeStale.value) markCanvasStale();
			connected.value = false;
			holdOpsForInactiveTab(next);
			return;
		}
		connected.value = false;
		rebindProjection(null);
		retarget(null);
	};
	const restorePersistedTarget = (justActivated) => {
		const persisted = initialBind ? lifecycle.readPersistedDocId() : null;
		initialBind = false;
		if (persisted === null) {
			lifecycle.clearPersistedDocId();
			rebindProjection(null);
			retarget(null);
			return;
		}
		recordDevEvent("rebind", { workflowId: persisted });
		rebindProjection(persisted);
		retarget(persisted);
		if (justActivated) applyCollected(persisted);
	};
	const isActivationEdge = (active, previous) => active && previous?.[1] === false;
	const acknowledgesFollowedDoc = (next, active, justActivated) => active && !justActivated && next !== null && next === subscribedWorkflowId.value;
	const activateTarget = (next, justActivated) => {
		initialBind = false;
		rebindProjection(next);
		retarget(next);
		drainRejectedOps(next);
		if (justActivated) applyCollected(next);
	};
	watch([workflowId, isTargetActive], ([next, active], previous) => {
		const justActivated = isActivationEdge(active, previous);
		if (acknowledgesFollowedDoc(next, active, justActivated)) return;
		lifecycle.clearForRetarget();
		terminal.value = null;
		pendingLiveNodeIds.clear();
		if (!active) {
			deactivateTarget(next, previous?.[0] ?? null);
			return;
		}
		connected.value = false;
		if (next === null) {
			restorePersistedTarget(justActivated);
			return;
		}
		activateTarget(next, justActivated);
	}, { immediate: true });
	onScopeDispose(() => {
		runFollowerTeardown([
			() => lifecycle.destroy(),
			() => stopTransportStatus(),
			() => bridge.removeEventListener("doc_subscribed", onSubscribed),
			() => bridge.removeEventListener("doc_update", onUpdate),
			() => bridge.removeEventListener("doc_ops_result", onOpsResult),
			() => bridge.removeEventListener("doc_reset", onDocReset),
			() => bridge.removeEventListener("follower_replaced", onFollowerReplaced),
			() => bridge.removeEventListener("schema_error", onSchemaError),
			() => bridge.removeEventListener("doc_gap", onGap),
			() => bridge.removeEventListener("doc_stale", onStale),
			() => bridge.removeEventListener("doc_subscribe_sent", onSubscribeSent),
			() => bridge.removeEventListener("doc_reseed_result", onReseedResult),
			() => sender.detach(),
			() => pendingRejected.clear(),
			() => coalescer.detach(),
			() => {
				for (const workflowId of pendingProjectionFrames.keys()) reportPendingFrames(workflowId, "discarded", NOTHING_APPLIED);
				projection.destroy();
			},
			() => bridge.destroy(),
			() => client.destroy()
		]);
	});
	const status = computed(() => ({
		enabled: true,
		connected: connected.value,
		canvasMayBeStale: canvasMayBeStale.value,
		workflowId: subscribedWorkflowId.value,
		terminal: terminal.value,
		updatesApplied: updatesApplied.value,
		lastFrameType: lastFrameType.value,
		outcomes: outcomes.value
	}));
	const debugSnapshot = () => readCrdtSnapshot(bridge.follower.doc, {
		status: status.value,
		tabId,
		lastSeq: bridge.lastSequence,
		schemaError: bridge.lastSchemaError?.message ?? null
	});
	return {
		status: readonly(status),
		debugSnapshot,
		retrySubscription: () => {
			if (!lifecycle.retry()) return;
			connected.value = false;
			terminal.value = null;
		},
		enqueueHumanOperations: (operations) => {
			const sentAdds = sentAddsToCurrentDoc();
			for (const operation of operations) if (operation.op === "add_node") sentAdds.add(String(operation.node_id));
			projection.noteLocalWrites(operations);
			coalescer.enqueue(operations);
		},
		docInputNames: (nodeId) => readDocSlotNames(bridge.follower.doc, String(nodeId), "inputs"),
		docWidgetValue: (nodeId, widgetName) => readDocWidgetValue(bridge.follower.doc, String(nodeId), widgetName),
		docPromotedWidgets: (nodeId) => readDocPromotedWidgets(bridge.follower.doc, String(nodeId)),
		mayWritePromotedHost: (nodeId) => bridge.isSubscribeBaselineIntegrated || sentAddsToCurrentDoc().has(String(nodeId)) && readDocPromotedWidgets(bridge.follower.doc, String(nodeId)) === null,
		docHasSubgraphDefinition: (definitionId) => readSubgraphDefinitionIds(bridge.follower.doc).includes(definitionId),
		notifyWidgetWriteRefused: (nodeId, widgetName) => rejectedOpNotifier.notifyWidgetWriteRefused(nodeId, widgetName),
		subscriptionSent: () => bridge.subscribedWorkflowId !== null && bridge.subscribedWorkflowId === subscribedWorkflowId.value
	};
}
function docSchemaSkew(found) {
	if (typeof found !== "number" || !Number.isInteger(found) || found <= 0) return null;
	if (found > 5) return "newer";
	if (found < 5) return "older";
	return null;
}
//#endregion
//#region src/workbench/extensions/agent/crdt/agentDocFrameTransport.ts
var INBOUND_DOC_FRAMES = new Set(SERVER_DOC_FRAME_TYPES);
function createAgentDocFrameTransport(source) {
	const target = new EventTarget();
	let unsubscribe = null;
	function tap() {
		if (unsubscribe !== null) return;
		unsubscribe = source.subscribe((raw) => {
			if (typeof raw !== "object" || raw === null || !("type" in raw)) return;
			const { type } = raw;
			if (typeof type !== "string" || !INBOUND_DOC_FRAMES.has(type)) return;
			const detail = "data" in raw ? raw.data : void 0;
			target.dispatchEvent(new CustomEvent(type, { detail }));
		});
	}
	return {
		send(frame) {
			return source.send(frame);
		},
		addEventListener(type, listener) {
			tap();
			target.addEventListener(type, listener);
		},
		removeEventListener(type, listener) {
			target.removeEventListener(type, listener);
		},
		onSocketOpen(listener) {
			return source.onStatus((live) => {
				if (live) listener();
			});
		},
		onSocketStatus(listener) {
			return source.onStatus(listener);
		},
		destroy() {
			unsubscribe?.();
			unsubscribe = null;
		}
	};
}
//#endregion
//#region src/workbench/extensions/agent/AgentPanelRoot.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = ["accept"];
var _hoisted_2 = {
	key: 0,
	role: "status",
	class: "pointer-events-none absolute inset-2 z-20 flex flex-col items-center justify-center gap-3 rounded-xl border-2 border-dashed bg-secondary/90 p-4 font-inter text-sm/5 text-foreground"
};
var CREATING_TAB_MIN_DURATION_MS = 500;
//#endregion
//#region src/workbench/extensions/agent/AgentPanelRoot.vue
var AgentPanelRoot_default = /* @__PURE__ */ defineComponent({
	__name: "AgentPanelRoot",
	setup(__props) {
		const CrdtDevPanel = defineAsyncComponent(() => __vitePreload(() => import("./CrdtDevPanel-BxGaWlQM.js"), __vite__mapDeps([116,1,51,43,44,16,6,45,19,46,10,11,47,20,21,27,2,28,29,30,31,32,33,7,8,9,12,13,34,39,40,37,48,49,50,52,53,54,36,55,17,18,22,23,24,25,26,56,57,15,5,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,41,73,74,75,76,77,78,117,110,84,85,86,79,80,118,119,120,121,122,94,123,124,125,82,126,127,83,128,129,130,87,131,132,81,133,134,135,136,137,138,139,140,141,142,143,144,145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,161,42,88,89,90,91,162,163,164,165,166,167,168,35,169,170,171,172]), import.meta.url));
		const { t } = useI18n();
		const toast = useToast();
		const { open: openAccountPrecondition } = useAccountPreconditionDialog();
		const { workspaceRole } = useWorkspaceUI();
		const { subscription, tier: subscriptionTier, type: billingType, billingStatus, canAccessSubscriptionFeatures, fetchStatus: refreshBillingStatus } = useBillingContext();
		const conversationStore = useAgentConversationStore();
		const history = useAgentChatHistoryStore();
		const { accepted: consentAccepted, identity: consentIdentity } = storeToRefs(useAgentConsentStore());
		watch(subscription, (currentSubscription) => {
			if (currentSubscription?.agentHasFunds) conversationStore.resolvePaywalls();
		}, { immediate: true });
		const { canTopUp, canSubscribeSelfServe, hasResolvedCapabilities, isReady: capabilityReadSettled, snapshotAuthoritative } = useBillingCapabilities();
		const paywallPresentation = computed(() => {
			return resolveAgentPaywallPresentation({
				distribution: "local",
				role: workspaceRole.value,
				tier: subscriptionTier.value,
				canTopUp: canTopUp.value,
				canSubscribeSelfServe: canSubscribeSelfServe.value
			});
		});
		const sidebarTabStore = useSidebarTabStore();
		const { isBuilderMode } = useAppMode();
		const { resolvedUserInfo, userDisplayName } = useCurrentUser();
		const userName = computed(() => userDisplayName.value?.trim().split(/\s+/)[0] || void 0);
		onBeforeUnmount(startCrdtDebugGate());
		const rest = createAgentRestClient();
		const events = createAgentEventSource({
			endpoint: api.apiURL("/agent/events"),
			getAuthParams: agentSocketAuthParams
		});
		const docTransport = createAgentDocFrameTransport(events);
		onBeforeUnmount(() => docTransport.destroy());
		const agentIdentity = resolveAgentIdentity({
			getIdentity: () => rest.getIdentity(),
			onSocketOpen: (listener) => docTransport.onSocketOpen(listener),
			isRetryable: (error) => isRetryableRequestFailure(error, false),
			onFailure: (error) => reportError(error, {
				surface: "agent",
				errorType: "failure_resolving_agent_identity",
				level: "warning"
			})
		});
		onBeforeUnmount(() => agentIdentity.stop());
		const authStore = useAuthStore();
		const apiKeyAuthStore = useApiKeyAuthStore();
		const agentAccountId = computed(() => authStore.userId ?? apiKeyAuthStore.currentUser?.id ?? null);
		watch(agentAccountId, () => {
			events.reconnect();
			agentIdentity.reset();
		});
		function onPaywallAction(action, surface) {
			useTelemetry()?.trackAgentPaywallCtaClicked({
				cta: toAgentPaywallCta(action),
				surface
			});
			if (action === "addCredits") {
				if (canTopUp.value) useTelemetry()?.trackAddApiCreditButtonClicked({ source: "agent_paywall" });
				openAccountPrecondition("credits", { source: "agent_paywall" });
				return;
			}
			useTelemetry()?.trackSubscription("subscribe_clicked", {
				current_tier: subscriptionTier.value?.toLowerCase(),
				reason: "agent_paywall"
			});
			openAccountPrecondition("subscription", { source: "agent_paywall" });
		}
		const { messages: conversationMessages, entries: conversationEntries } = storeToRefs(conversationStore);
		watch(() => capabilityReadSettled.value ? conversationMessages.value.filter((message) => message.parts.some((part) => part.type === "paywall")).map((message) => message.id) : [], (paywallMessageIds) => {
			const telemetry = useTelemetry();
			if (!telemetry) return;
			for (const id of paywallMessageIds) {
				if (!conversationStore.claimPaywallImpression(id)) continue;
				telemetry.trackAgentPaywallShown({
					reason: snapshotAuthoritative.value ? toAgentPaywallReason(paywallPresentation.value) : "unknown",
					surface: "refused_send"
				});
			}
		}, { immediate: true });
		/**
		* The standing credit-exhaustion surface.
		*
		* The inline card above is reachable from exactly one moment: a turn POST that
		* came back 402/`no_funds` (`recordSendError` -> `recordPaywall`). Every other
		* way a user meets the ceiling — including a refusal inside a server-side LLM
		* hop that the browser cannot observe — needs a durable upgrade path.
		*
		* So this reads the funds signal the client already holds rather than waiting
		* for a refusal to carry it. It is deliberately the symmetric half of the
		* `hasFunds` watch above, which already clears paywalls when funds return.
		*
		* Consolidated cloud billing only: legacy balance loading currently collapses
		* unknown into false, so it cannot safely drive this surface.
		*
		* Non-blocking by construction — it renders beside the composer and disables
		* nothing.
		*/
		const agentHasFunds = computed(() => subscription.value?.agentHasFunds);
		const agentScopedHasFunds = computed(() => subscription.value?.agentScopedHasFunds);
		const creditsExhausted = computed(() => {
			if (!consentAccepted.value) return false;
			if (billingType.value !== "workspace") return false;
			if (!capabilityReadSettled.value) return false;
			if (agentHasFunds.value !== false) return false;
			if (billingStatus.value === "paused" || billingStatus.value === "payment_failed") return false;
			return [
				"subscribed",
				"subscriptionRequired",
				"local"
			].includes(paywallPresentation.value.kind);
		});
		const unresolvedPaywallPending = computed(() => conversationEntries.value.some((entry) => entry.role === "assistant" && entry.parts.some((part) => part.type === "paywall")));
		/**
		* Suppressed while the latest transcript entry is an unresolved inline card:
		* the two render the same copy. An older card may be scrolled away and must not
		* hide the standing recovery path after a later server-side refusal.
		*/
		const latestEntryHasPaywall = computed(() => {
			const latestEntry = conversationEntries.value.at(-1);
			return latestEntry?.role === "assistant" && latestEntry.parts.some((part) => part.type === "paywall");
		});
		const threadHasUserMessage = computed(() => conversationEntries.value.some((entry) => entry.role === "user"));
		async function sendWithFundsRecheck(send) {
			if (billingType.value !== "workspace" || agentHasFunds.value !== false) return send(() => void 0);
			let recheckId;
			let stopAdoptionWatch;
			const settle = () => {
				if (recheckId !== void 0) agentPanelStore.finishFundsRecheck(recheckId);
			};
			let admitted = false;
			let sent;
			try {
				sent = await send(() => {
					admitted = true;
					recheckId = agentPanelStore.beginFundsRecheck(billingIdentity.value, () => stopAdoptionWatch?.());
					stopAdoptionWatch = watch([subscription, billingIdentity], settle, { flush: "sync" });
				});
			} finally {
				if (!admitted) settle();
			}
			if (!admitted) return sent;
			refreshBillingStatus().catch((error) => {
				reportError(error, {
					surface: "agent",
					errorType: "error_refreshing_agent_billing_status"
				});
			});
			return sent;
		}
		const showStandingPaywall = computed(() => {
			if (!creditsExhausted.value || !threadHasUserMessage.value) return false;
			if (agentPanelStore.hasPendingFundsRecheck(billingIdentity.value)) return false;
			return !latestEntryHasPaywall.value;
		});
		const agentPanelStore = useAgentPanelStore();
		const billingIdentity = useBillingIdentity();
		watch(billingIdentity, () => {
			agentPanelStore.cancelFundsRechecks();
			agentPanelStore.reportedExhaustionIdentity = null;
		});
		const showCreditTransitionNotice = computed(() => isCreditTransitionNoticeShown(agentPanelStore.creditTransitionNotice, billingIdentity.value) && consentAccepted.value && billingType.value === "workspace" && capabilityReadSettled.value && canAccessSubscriptionFeatures.value && agentScopedHasFunds.value === false && agentHasFunds.value === true);
		function onDismissCreditTransitionNotice() {
			useTelemetry()?.trackAgentCreditTransitionNotice({ action: "dismissed" });
			agentPanelStore.dismissCreditTransitionNotice(billingIdentity.value);
		}
		function onCreditTransitionNoticeShown() {
			const telemetry = useTelemetry();
			if (!telemetry) return;
			if (!agentPanelStore.claimCreditTransitionNoticeImpression(billingIdentity.value)) return;
			telemetry.trackAgentCreditTransitionNotice({ action: "shown" });
		}
		function onStandingPaywallShown() {
			if (!showStandingPaywall.value || agentPanelStore.reportedExhaustionIdentity === billingIdentity.value) return;
			const telemetry = useTelemetry();
			if (!telemetry) return;
			agentPanelStore.reportedExhaustionIdentity = billingIdentity.value;
			telemetry.trackAgentPaywallShown({
				reason: snapshotAuthoritative.value ? toAgentPaywallReason(paywallPresentation.value) : "unknown",
				surface: "credits_exhausted"
			});
		}
		const workflowStore = useWorkflowStore();
		const workflowService = useWorkflowService();
		const bindingStore = useAgentWorkflowTabBindingStore();
		const composerStore = useAgentComposerStore();
		const { selectedWorkflow: selectedTarget } = storeToRefs(agentPanelStore);
		const { dismissedSelectionSignature, enabled: agentEnabled } = storeToRefs(agentPanelStore);
		const workflowResolver = useAgentWorkflowResolver({
			workflows: workflowStore,
			bindings: bindingStore,
			listCloudWorkflows: () => rest.listCloudWorkflows(),
			getCloudWorkflow: (workflowId) => rest.getCloudWorkflow(workflowId)
		});
		const { refreshCloudWorkflowIds, forgetCloudWorkflowId, cloudIdFor, boundOrOpenWorkflowFor, storedWorkflowFor, openWorkflowFor, availableWorkflowReferences, openTabsSnapshot } = workflowResolver;
		const { isSelecting: workflowSelecting, selectingTarget, savingReference, onVisibleWorkflowChanged, selectTarget: onSelectWorkflowTarget, selectReference: onSelectWorkflowReference, restoreTarget: onWorkflowRestored, adoptTarget: adoptWorkflowTarget, requestReferences: onRequestWorkflowReferences, cancelSelection: cancelWorkflowSelection } = useAgentWorkflowSelection({
			resolver: workflowResolver,
			canSelectTarget: () => !isSending.value && status.value === "idle",
			warnWorkflowUnavailable,
			warnRestoreFailed,
			onTargetBound: (workflowId, previousWorkflowId, source) => reportWorkflowBound(workflowId, previousWorkflowId, source)
		});
		const tabActivity = useWorkflowTabActivityStore();
		const agentTabGraph = {
			...blankGraph,
			extra: { ds: {
				offset: [0, 0],
				scale: 1
			} }
		};
		const canvasStore = useCanvasStore();
		const graphActivity = useAgentGraphActivityStore();
		const settingStore = useSettingStore();
		const dialogStore = useDialogStore();
		watch(() => canvasStore.canvas?.graph, (graph, _previous, onCleanup) => {
			if (!graph?.events) return;
			const events = graph.events;
			const onNodeRemoved = (event) => {
				if (!(event instanceof CustomEvent)) return;
				const nodeId = parseNodeId(String(event.detail.node?.id));
				if (nodeId) graphActivity.removeNodes([nodeId]);
			};
			events.addEventListener("node:removed", onNodeRemoved);
			onCleanup(() => events.removeEventListener("node:removed", onNodeRemoved));
		}, { immediate: true });
		let agentMinimapLayer;
		function syncAgentMinimapLayer(activity) {
			if (activity.phase === "idle") {
				agentMinimapLayer?.replace([]);
				return;
			}
			const rootGraphId = toRootGraphId(activity.rootGraphId);
			agentMinimapLayer?.replace(activity.nodeIds.map((nodeId) => ({
				target: {
					rootGraphId,
					owningGraphId: toOwningGraphId(activity.rootGraphId),
					nodeId
				},
				enter: "pop"
			})));
			if (activity.phase === "running" && !settingStore.get("Comfy.Minimap.Visible")) settingStore.set("Comfy.Minimap.Visible", true);
		}
		watch(() => graphActivity.state, syncAgentMinimapLayer, { immediate: true });
		onMounted(() => {
			agentMinimapLayer = registerMinimapDecorationLayer("agent.graph-activity");
			syncAgentMinimapLayer(graphActivity.state);
		});
		function runPanelTeardown(steps) {
			for (const [step, release] of Object.entries(steps)) try {
				release();
			} catch (error) {
				try {
					reportError(error, {
						surface: "agent",
						errorType: "failure_tearing_down_agent_panel",
						tags: { step }
					});
				} catch {}
			}
		}
		onBeforeUnmount(() => runPanelTeardown({ disposeMinimapLayer: () => {
			agentMinimapLayer?.dispose();
		} }));
		const { withConsent } = useAgentConsent();
		const workspaceStore = useTeamWorkspaceStore();
		const onboardingKey = computed(() => scopedOnboardingKey(resolvedUserInfo.value?.id, workspaceStore.activeWorkspaceId));
		watch(onboardingKey, (key) => {
			if (key && consentAccepted.value) adoptSharedOnboardingFlag(key);
		}, { immediate: true });
		const { activeTour } = storeToRefs(useOnboardingTourStore());
		const coachDeferredBy = computed(() => canvasStore.linearMode ? "app_mode" : activeTour.value !== null ? "tour_active" : dialogStore.dialogStack.length > 0 ? "dialog_open" : null);
		const coachCompletionWaiters = /* @__PURE__ */ new Set();
		function releaseCoachCompletionWaiters(proceed = true) {
			for (const resolve of coachCompletionWaiters) resolve(proceed);
			coachCompletionWaiters.clear();
		}
		watch([
			consentAccepted,
			onboardingKey,
			coachDeferredBy,
			consentIdentity
		], ([accepted, key, reason, identity], previous) => {
			if (accepted && key && !hasSeenCoach(key)) trackCoachDeferral(key, reason);
			if (!accepted || reason !== null || identity !== previous[3]) releaseCoachCompletionWaiters();
		}, { immediate: true });
		const coachRef = ref();
		const sendHeldByCoach = ref(false);
		async function waitForCoachCompletion() {
			const key = onboardingKey.value;
			if (!key || hasSeenCoach(key)) return true;
			await nextTick();
			if (key !== onboardingKey.value || !consentAccepted.value || coachDeferredBy.value !== null || !coachRef.value) return true;
			sendHeldByCoach.value = true;
			try {
				return await new Promise((resolve) => coachCompletionWaiters.add(resolve));
			} finally {
				sendHeldByCoach.value = false;
			}
		}
		function restartCoach() {
			if (coachRef.value) coachRef.value.restart();
			else if (onboardingKey.value) resetCoach(onboardingKey.value);
		}
		function toSelectedNode(node) {
			return {
				id: String(node.id),
				locatorId: workflowStore.nodeToNodeLocatorId(node),
				title: node.title || node.type
			};
		}
		const canReferenceNodes = computed(() => selectedTarget.value !== null && workflowStore.activeWorkflow?.path === selectedTarget.value.path);
		const nodeReferenceDisabledReason = computed(() => {
			if (selectedTarget.value === null) return t("agent.selectWorkflowForNodes");
			if (!canReferenceNodes.value) return t("agent.switchWorkflowForNodes", { workflowName: selectedTarget.value.filename });
		});
		const selectedNodes = computed(() => canvasStore.selectedItems.filter(isLGraphNode).map(toSelectedNode));
		composerStore.setNodeScope(selectedTarget.value?.instanceId ?? null);
		const { staged: selectionTags, consume: consumeSelection, remove: removeSelectionTag, add: addSelectionTag, replace: replaceSelectionTags } = useCanvasSelection({
			staged: computed({
				get: () => composerStore.nodes,
				set: composerStore.setNodes
			}),
			onNodesAdded: agentPanelStore.retainWorkflowTarget,
			retainWhenNotLive: true,
			selection: selectedNodes,
			enabled: () => agentEnabled.value && selectedTarget.value !== null,
			isLive: () => agentPanelStore.isOpen,
			isTracking: () => canReferenceNodes.value && canvasStore.isPickingNodes,
			scope: () => selectedTarget.value?.instanceId ?? null,
			dismissedSignature: dismissedSelectionSignature,
			retainStagedNode: (node) => {
				const locator = parseNodeLocatorId(selectedNodeKey(node));
				if (!locator) return false;
				const viewedSubgraphUuid = canvasStore.currentGraph?.isRootGraph === false ? canvasStore.currentGraph.id : null;
				return locator.subgraphUuid !== viewedSubgraphUuid;
			}
		});
		let nodeReferenceWorkflow = selectionTags.value.length ? selectedTarget.value : null;
		function viewedGraphNodes() {
			return (canvasStore.currentGraph ?? app.canvas?.graph ?? app.graph)?.nodes ?? [];
		}
		function mentionableNodes() {
			return canReferenceNodes.value ? viewedGraphNodes().map(toSelectedNode) : [];
		}
		watch(selectionTags, (tags) => {
			nodeReferenceWorkflow = tags.length ? selectedTarget.value : null;
		}, {
			deep: true,
			flush: "sync"
		});
		const workflowDetached = computed(() => selectedTarget.value === null);
		function originWorkflow(origin) {
			if (origin === null) return void 0;
			return (origin === void 0 ? selectedTarget.value : workflowStore.openWorkflows.find((workflow) => workflow.path === origin.tabPath)) ?? void 0;
		}
		function targetWorkflowTurnContext(origin) {
			if (workflowDetached.value) return void 0;
			const target = originWorkflow(origin);
			if (!target) return void 0;
			const id = cloudIdFor(target);
			if (id === void 0 && !target.isTemporary && origin !== void 0) return void 0;
			return id === void 0 ? { tabPath: target.path } : {
				id,
				tabPath: target.path
			};
		}
		function serializedCanvas(target) {
			if (target.path === workflowStore.activeWorkflow?.path) target.changeTracker?.prepareForSave();
			return target.activeState;
		}
		function targetWorkflowDraft(origin) {
			if (workflowDetached.value) return void 0;
			const target = originWorkflow(origin);
			if (!target) return void 0;
			if (canvasMissedDocumentFrames(cloudIdFor(target))) return void 0;
			const content = serializedCanvas(target);
			if (!content) return void 0;
			return { content };
		}
		function canvasMissedDocumentFrames(documentId) {
			return documentId !== void 0 && boundWorkflowId.value === documentId && crdtStatus.value.canvasMayBeStale;
		}
		function canvasForWorkflow(workflowId) {
			const target = boundOrOpenWorkflowFor(workflowId);
			return target ? serializedCanvas(target) : null;
		}
		const selectedTargetTab = computed(() => {
			const target = selectedTarget.value;
			return target ? {
				path: target.path,
				name: target.filename,
				isPersisted: target.isPersisted,
				modified: target.isModified
			} : null;
		});
		const editableWorkflowId = computed(() => {
			const target = selectedTarget.value;
			return target ? cloudIdFor(target) : void 0;
		});
		const workflowTabs = computed(() => workflowStore.openWorkflows.map((tab) => ({
			path: tab.path,
			name: tab.filename,
			isPersisted: tab.isPersisted,
			modified: tab.isModified
		})));
		function onWorkflowAdopted(workflowId, sent, previousWorkflowId) {
			if (sent === void 0) return;
			if (sent.id === void 0 ? bindingStore.tabPathFor(workflowId) === void 0 && storedWorkflowFor(workflowId) === null : sent.id === workflowId) {
				bindingStore.bind(workflowId, sent.tabPath);
				reportWorkflowBound(workflowId, previousWorkflowId, sent.id === void 0 ? "minted" : "active_tab");
			}
		}
		async function onWorkflowRestoredAndBound(workflowId, isCurrent) {
			const { ready, committedWorkflowId } = await onWorkflowRestored(workflowId, isCurrent);
			if (committedWorkflowId === null || !isCurrent()) return ready;
			if (hasUnsyncedHumanOps(committedWorkflowId)) return ready;
			if (boundWorkflowId.value !== committedWorkflowId) bindWorkflow(committedWorkflowId);
			return ready;
		}
		function warnWorkflowUnavailable() {
			toast.warning(t("agent.targetNavigationUnavailable"), { duration: 5e3 });
		}
		function warnRestoreFailed() {
			const { view } = agentPanelStore;
			if (view.screen === "history" && view.selection.status === "loading") return;
			toast.warning(t("agent.targetWorkflowOpenFailed"), { duration: 5e3 });
		}
		function trackWorkflowOpenFailure(uiTreatment) {
			trackAgentError("workflow_open_failed", "post_acceptance", uiTreatment, { retryable: false });
		}
		/**
		* The sent message, held from the moment the user sends until the cloud ids
		* are refreshed, alongside the turn's origin. Scoped to one `sendMessage`
		* call, so a send never hands these fields to the next one.
		*/
		let pendingSend = null;
		/**
		* A freshly opened tab has no cloud id until `refreshCloudWorkflowIds()` lands,
		* and the turn is posted with the id resolved by that refresh (QAF-19).
		* Reporting before it would file the first send of a session — the one the
		* activation funnel is measuring — against no workflow at all.
		*
		* Resolved through the turn's own origin rather than the live selection,
		* because `performSend` posts the origin tab's id: switching target or
		* starting a new chat while the refresh is in flight must not retarget the
		* report at a workflow the turn was never sent against.
		*/
		function reportPendingSend() {
			const sent = pendingSend;
			if (!sent) return;
			pendingSend = null;
			useTelemetry()?.trackAgentMessageSent({
				...sent.metadata,
				workflow_id: targetWorkflowTurnContext(sent.origin)?.id ?? null
			});
		}
		function registerAgentRunJobOwner(event) {
			if (event.type !== "agent_tool_call") return;
			const { job_id: jobId, job_workflow_id: workflowId } = event.data;
			if (!jobId || !workflowId) return;
			const workflow = boundOrOpenWorkflowFor(workflowId);
			if (workflow) useExecutionStore().registerJobOwner(jobId, workflow);
		}
		const agentNodeDefinitionRefresh = useAgentNodeDefinitionRefreshStore();
		function observeAgentEvent(event) {
			agentNodeDefinitionRefresh.observeAgentEvent(event);
			registerAgentRunJobOwner(event);
		}
		const { sendMessage, stopTurn, isSending: sessionIsSending, isTranscriptReady, newChat, start, stop, entries, editableTurnId, isStreaming, status, notices, threadId, loadThread, boundWorkflowId, bindWorkflow, reportWorkflowBound, answerAsk, answeringAskIds } = useAgentSession({
			rest,
			events,
			onThreadStarted: (source) => useTelemetry()?.trackAgentThreadStarted({ source }),
			onAgentEvent: observeAgentEvent,
			onThreadActivated: (id) => history.setActive(id),
			onAskResolved: forgetApproval,
			refreshCredentialDuringTurns: true,
			workflow: {
				initialize: agentPanelStore.initializeTargetTracking,
				current: targetWorkflowTurnContext,
				adopted: onWorkflowAdopted,
				restored: restoreChatWorkflow,
				prepare: async () => {
					try {
						await refreshCloudWorkflowIds();
					} finally {
						reportPendingSend();
					}
				},
				disowned: forgetCloudWorkflowId,
				tabs: openTabsSnapshot,
				activeTab: enqueueActiveTab,
				draft: targetWorkflowDraft
			}
		});
		provide(agentBoundWorkflowIdKey, computed(() => boundWorkflowId.value ?? void 0));
		const isSending = computed(() => sessionIsSending.value || composerStore.submission?.phase === "pending");
		const isBoundWorkflowActive = computed(() => {
			const bound = boundWorkflowId.value;
			const active = workflowStore.activeWorkflow;
			return bound !== null && active !== null && boundOrOpenWorkflowFor(bound)?.path === active.path;
		});
		const agentUserId = computed(() => {
			const identity = agentIdentity.state.value;
			return identity.status === "resolved" ? identity.userId : null;
		});
		const isFollowerActive = computed(() => isBoundWorkflowActive.value && agentUserId.value !== null);
		const { status: crdtStatus, debugSnapshot: crdtDebugSnapshot, enqueueHumanOperations, retrySubscription, docInputNames, docWidgetValue, docPromotedWidgets, mayWritePromotedHost, docHasSubgraphDefinition, notifyWidgetWriteRefused, subscriptionSent } = useAgentCrdtFollower(boundWorkflowId, {
			transport: docTransport,
			userId: () => agentUserId.value,
			isTargetActive: isFollowerActive,
			getGraph: () => canvasStore.canvas && app.isGraphReady ? app.rootGraph : null,
			events: {
				onAppliedUpdate({ workflowId, opIds, isLive }) {
					conversationStore.notifyCanvasCaughtUp({
						workflowId,
						opIds,
						isLive
					});
				},
				onMaterialized({ workflowId, nodeIds }) {
					if (app.isGraphReady) {
						graphActivity.recordMaterialized({
							workflowId,
							rootGraphId: toRootGraphId(app.rootGraph.id)
						}, nodeIds, conversationTurnId.value);
						if (status.value === "idle") graphActivity.finishTurn();
					}
				},
				onReset: graphActivity.resetWorkflow,
				onSyncError: (message, code) => toast.error(t("agent.workflowSyncFailedTitle"), { description: formatWorkflowSyncErrorDetail(t, message, code) })
			},
			applierDeps: {
				getCanvas: () => app.canvas,
				withRemoteActor: (actor, fn) => layoutStore.withActor(actor, fn),
				viewportBounds() {
					const canvas = canvasStore.canvas;
					if (!canvas || canvas.graph?.isRootGraph === false) return null;
					const [x, y, width, height] = canvas.ds.visible_area;
					return {
						x,
						y,
						width,
						height
					};
				}
			},
			canvasFor: canvasForWorkflow
		});
		function boundRootGraphId() {
			const bound = boundWorkflowId.value;
			if (bound === null) return null;
			const id = boundOrOpenWorkflowFor(bound)?.activeState?.id;
			return id === void 0 ? null : toRootGraphId(id);
		}
		function followerCanDeliver() {
			return isFollowerActive.value && subscriptionSent();
		}
		const docOpMinter = attachDocOpMinter({
			isEnabled: () => agentPanelStore.enabled,
			isDocBound: followerCanDeliver,
			enqueue: enqueueHumanOperations,
			getGraph: () => app.isGraphReady ? app.rootGraph : null,
			boundRootGraphId,
			docInputNames,
			docWidgetValue,
			docPromotedWidgets,
			mayWritePromotedHost,
			docHasSubgraphDefinition,
			onWidgetWriteRefused: notifyWidgetWriteRefused
		});
		const restoreOpMinter = attachRestoreOpMinter({
			isEnabled: () => agentPanelStore.enabled,
			isDocBound: followerCanDeliver,
			enqueue: enqueueHumanOperations,
			getGraph: () => app.isGraphReady ? app.rootGraph : null,
			docInputNames: (nodeId) => {
				const parsed = parseNodeId(nodeId);
				return parsed === null ? null : docInputNames(parsed);
			},
			isRestoringState: () => workflowStore.activeWorkflow?.changeTracker?._restoringState === true
		});
		const isCrdtDevPanelEnabled = resolveDebugPanelEnabled(agentPanelStore.enabled, isCrdtDebugEnabled());
		const { activeTurnId: conversationTurnId } = storeToRefs(conversationStore);
		function canvasConfirmationState(workflowId) {
			const bound = boundWorkflowId.value ?? void 0;
			if (bound === void 0) return "none";
			if (workflowId !== void 0 && !areAgentWorkflowIdsEquivalent(bound, workflowId)) return "unavailable";
			if (!isBoundWorkflowActive.value) return "unavailable";
			const status = crdtStatus.value;
			if (!status.enabled) return "none";
			if (status.connected) return "awaiting";
			return status.terminal === null ? "none" : "unavailable";
		}
		conversationStore.setCanvasSyncGate(canvasConfirmationState, () => crdtStatus.value.outcomes.appliedLive);
		function tabAt(path, status) {
			const workflow = path === void 0 ? void 0 : workflowStore.getWorkflowByPath(path);
			return workflow ? {
				status,
				workflowInstanceId: workflow.instanceId
			} : { status: "unknown" };
		}
		function turnTab() {
			if (workflowDetached.value) return { status: agentPanelStore.canRestoreWorkflow ? "unknown" : "none" };
			const bound = boundWorkflowId.value;
			const context = targetWorkflowTurnContext();
			if (bound === null) return tabAt(context?.id === void 0 ? void 0 : context.tabPath, "guessed");
			return tabAt(bindingStore.tabPathFor(bound) ?? (context?.id === bound ? context.tabPath : void 0), "known");
		}
		function adoptRestoredWorkflowTab(workflowId) {
			const restored = selectedTarget.value;
			const threadId = conversationStore.threadId;
			if (restored !== null && threadId !== null && bindingStore.tabPathFor(workflowId) === restored.path) conversationStore.adoptThreadTab(threadId, restored.instanceId);
		}
		async function restoreThreadWorkflow(workflowId, isCurrent) {
			const restoring = agentPanelStore.canRestoreWorkflow;
			const ready = await onWorkflowRestoredAndBound(workflowId, isCurrent);
			if (ready && restoring && workflowId !== void 0) adoptRestoredWorkflowTab(workflowId);
			return ready;
		}
		conversationStore.setTurnTabResolver(turnTab);
		conversationStore.onTurnCompleted((path) => tabActivity.markModified(path));
		watch(() => conversationStore.turnTabs, (tabs) => tabActivity.setAgentTurnTabs(tabs), {
			immediate: true,
			flush: "sync"
		});
		const boundCanvasNodeCount = ref(0);
		function readBoundCanvasNodeCount() {
			boundCanvasNodeCount.value = isBoundWorkflowActive.value ? workflowStore.activeWorkflow?.activeState?.nodes?.length ?? 0 : 0;
		}
		watch([boundWorkflowId, isBoundWorkflowActive], readBoundCanvasNodeCount, { immediate: true });
		useEventListener(api, "graphChanged", (event) => {
			if (isBoundWorkflowActive.value) boundCanvasNodeCount.value = event.detail.nodes?.length ?? 0;
		});
		const completedTurnClaimedCanvasContent = ref(false);
		function completedTurnCanClaimCanvasContent() {
			const lastCanvasTool = conversationMessages.value.at(-1)?.parts.findLast((part) => part.type === "tool" && (part.name === "clear_canvas" ? part.ok === true : part.ok !== false && toolCanClaimCanvasContent(part.name)));
			return lastCanvasTool?.type === "tool" && lastCanvasTool.name !== "clear_canvas";
		}
		const canvasEmptyAfterTurn = computed(() => completedTurnClaimedCanvasContent.value && isBoundWorkflowActive.value && boundCanvasNodeCount.value === 0);
		function refreshBillingAfterTurn() {
			if (billingType.value !== "workspace") return;
			refreshBillingStatus().catch((error) => {
				reportError(error, {
					surface: "agent",
					errorType: "error_refreshing_agent_billing_status"
				});
			});
		}
		let wasTurnActive = false;
		watch([status, conversationTurnId], ([value, turnId]) => {
			const active = value !== "idle";
			const completedTurn = wasTurnActive && !active;
			if (completedTurn) completedTurnClaimedCanvasContent.value = completedTurnCanClaimCanvasContent();
			else if (active) completedTurnClaimedCanvasContent.value = false;
			wasTurnActive = active;
			if (active) {
				graphActivity.startTurn(turnId);
				return;
			}
			if (completedTurn) {
				graphActivity.finishTurn();
				refreshBillingAfterTurn();
			}
		}, {
			immediate: true,
			flush: "sync"
		});
		watch([threadId, boundWorkflowId], () => {
			completedTurnClaimedCanvasContent.value = false;
		});
		const executionErrorStore = useExecutionErrorStore();
		function surfaceAgentError(type, details) {
			executionErrorStore.recordPromptError({
				type,
				message: t(`errorCatalog.promptErrors.${type}.desc`),
				details
			});
			executionErrorStore.showErrorOverlay();
		}
		let noticesSeen = 0;
		watch(() => notices.value.length, (length) => {
			for (const notice of notices.value.slice(noticesSeen)) surfaceAgentError("agent_api_failed", notice.text);
			noticesSeen = length;
		});
		let activeTabGeneration = 0;
		let activeTabChain = Promise.resolve();
		function enqueueActiveTab(data) {
			const generation = ++activeTabGeneration;
			const turnId = data.message_id === void 0 ? conversationTurnId.value : toTurnId(data.message_id);
			const result = activeTabChain.then(() => onAgentActiveTab(data, generation, turnId));
			activeTabChain = result.then(() => void 0);
			return result;
		}
		async function onOpenApprovalWorkflow(askId, workflowId, workflowName) {
			const decidedAt = Date.now();
			if (await enqueueActiveTab({
				workflow_id: workflowId,
				name: workflowName
			})) trackApprovalResolved(askId, "open_workflow", decidedAt);
		}
		async function onNavigateToReferenceWorkflow(workflowId) {
			try {
				let target = openWorkflowFor(workflowId);
				if (target === null) {
					await Promise.all([refreshCloudWorkflowIds(), workflowStore.syncWorkflows()]);
					target = storedWorkflowFor(workflowId);
				}
				if (target === null || !await workflowService.openWorkflow(target)) {
					warnWorkflowUnavailable();
					return;
				}
				bindingStore.bind(workflowId, target.path);
			} catch {
				warnWorkflowUnavailable();
			}
		}
		async function onShowTarget(isNavigationCurrent = () => true, warnOpenFailed = warnWorkflowUnavailable) {
			const target = selectedTarget.value;
			if (target === null) return false;
			const isCurrent = () => isNavigationCurrent() && selectedTarget.value === target;
			try {
				const opened = await workflowService.openWorkflow(target, { isCurrent });
				if (!isCurrent()) return false;
				if (!opened) warnOpenFailed();
				return opened;
			} catch {
				if (isCurrent()) warnOpenFailed();
				return false;
			}
		}
		function agentTabFilename(name) {
			const cleaned = [...(name ?? "").replace(/[/\\\p{Cc}]/gu, "-").replace(/\.json$/i, "").trim().replace(/^\.+/, "")].slice(0, 80).join("").replace(/^[\s.]+/u, "").trim();
			return cleaned.length === 0 ? void 0 : `${cleaned}.json`;
		}
		async function onAgentActiveTab(data, generation, turnId) {
			const previousWorkflowId = boundWorkflowId.value;
			const stale = () => generation !== activeTabGeneration;
			if (stale()) return false;
			const activation = {
				stale,
				showTurnOn: (tab) => {
					if (turnId !== null) conversationStore.moveTurnToTab(turnId, tab.instanceId);
				}
			};
			try {
				const bound = boundOrOpenWorkflowFor(data.workflow_id);
				return bound ? await activateExistingAgentTab(data, bound, previousWorkflowId, activation) : await createAndActivateAgentTab(data, previousWorkflowId, activation);
			} catch (error) {
				if (stale()) return false;
				bindWorkflow(data.workflow_id);
				reportError(error, {
					surface: "agent",
					errorType: "agent_workflow_open_failed"
				});
				surfaceAgentError("agent_api_failed", error instanceof Error ? error.message : String(error));
				trackWorkflowOpenFailure("error_overlay");
				return false;
			} finally {
				tabActivity.setCreating(false);
			}
		}
		async function activateExistingAgentTab(data, bound, previousWorkflowId, { stale, showTurnOn }) {
			const opened = await workflowService.openWorkflow(bound);
			if (stale()) return false;
			if (!opened) {
				warnWorkflowUnavailable();
				trackWorkflowOpenFailure("toast");
				return false;
			}
			bindingStore.bind(data.workflow_id, bound.path);
			showTurnOn(bound);
			bindWorkflow(data.workflow_id);
			reportWorkflowBound(data.workflow_id, previousWorkflowId, "active_tab");
			useTelemetry()?.trackAgentWorkflowApplied({
				workflow_id: data.workflow_id,
				target: "active_tab_switch"
			});
			return true;
		}
		async function createAndActivateAgentTab(data, previousWorkflowId, { stale, showTurnOn }) {
			const creatingStartedAt = Date.now();
			tabActivity.setCreating(true);
			const remainingCreatingTime = CREATING_TAB_MIN_DURATION_MS - (Date.now() - creatingStartedAt);
			if (remainingCreatingTime > 0) await new Promise((resolve) => setTimeout(resolve, remainingCreatingTime));
			if (stale()) return false;
			const tab = workflowStore.createNewTemporary(agentTabFilename(data.name), agentTabGraph);
			tabActivity.setCreating(false);
			let opened;
			try {
				opened = await workflowService.openWorkflow(tab);
			} catch (error) {
				await workflowService.closeWorkflow(tab, { warnIfUnsaved: false });
				throw error;
			}
			if (stale() || !opened) {
				await workflowService.closeWorkflow(tab, { warnIfUnsaved: false });
				if (!stale()) {
					warnWorkflowUnavailable();
					trackWorkflowOpenFailure("toast");
				}
				return false;
			}
			showTurnOn(tab);
			bindingStore.bind(data.workflow_id, tab.path);
			bindWorkflow(data.workflow_id);
			reportWorkflowBound(data.workflow_id, previousWorkflowId, "active_tab");
			useTelemetry()?.trackAgentWorkflowApplied({
				workflow_id: data.workflow_id,
				target: "active_tab_open"
			});
			return true;
		}
		function onApprovalShown(askId, turnId, workflowId) {
			if (!conversationStore.recordApprovalShown(askId, Date.now())) return;
			useTelemetry()?.trackAgentRunApprovalShown({
				turn_id: turnId,
				workflow_id: workflowId
			});
		}
		function trackApprovalResolved(askId, decision, decidedAt = Date.now(), shownAt = conversationStore.approvalShownAt(askId)) {
			if (shownAt === void 0) return;
			if (decision !== "open_workflow") conversationStore.forgetApprovalTiming(askId);
			useTelemetry()?.trackAgentRunApprovalResolved({
				decision,
				time_to_decide_ms: Math.max(0, decidedAt - shownAt)
			});
		}
		function forgetApproval(askId) {
			conversationStore.forgetApproval(askId);
		}
		async function onAnswerAsk(askId, answer) {
			const shownAt = conversationStore.approvalShownAt(askId);
			const decidedAt = Date.now();
			const decision = runApprovalDecision(answer);
			if (await answerAsk(askId, answer) && decision) trackApprovalResolved(askId, decision, decidedAt, shownAt);
		}
		function runApprovalDecision(answer) {
			if (answer.selected.length !== 1 || answer.other_text) return void 0;
			const [choice] = answer.selected;
			return choice === "run" || choice === "cancel" ? choice : void 0;
		}
		refreshCloudWorkflowIds();
		onBeforeUnmount(() => {
			runPanelTeardown({
				releaseCoachCompletionWaiters: () => {
					releaseCoachCompletionWaiters(coachDeferredBy.value !== null && agentPanelStore.isVisible);
				},
				invalidateConsentHeldSubmission: () => {
					if (!sendHeldByCoach.value && (coachDeferredBy.value === null || !agentPanelStore.isVisible) && composerStore.submission?.id === consentHeldSubmissionId) composerStore.invalidateSubmission();
				},
				detachDocOpMinter: () => {
					docOpMinter.detach();
				},
				detachRestoreOpMinter: () => {
					restoreOpMinter.detach();
				},
				exitNodeSelectionMode: canvasStore.stopNodePicking,
				stopSession: () => {
					stop();
				},
				invalidateActiveTabGeneration: () => {
					++activeTabGeneration;
				},
				clearAgentTurnTabs: () => {
					tabActivity.setAgentTurnTabs([]);
				},
				resetTurnTabResolver: () => {
					conversationStore.setTurnTabResolver(() => ({ status: "unknown" }));
				},
				clearCreatingTab: () => {
					tabActivity.setCreating(false);
				},
				resetCanvasSyncGate: () => {
					conversationStore.setCanvasSyncGate(() => "none");
				}
			});
		});
		const { copy } = useClipboard({ legacy: true });
		const { variant: freeUseVariant, reportNotice: onFreeUseNotice } = useFreeUsePlacement();
		const { assignment: starterPromptAssignment, attributeExperiment: attributeStarterPromptExperiment, expose: exposeStarterPromptSet } = useStarterPromptSet();
		/**
		* `Try your first chat for free!` is a claim about the Agent's own granted
		* allowance, so it renders on `scoped_has_funds.agent` as received. `=== true`
		* is the whole gate: an absent field, an unsettled read and a rail that reports
		* no scoped balance all fail closed without a separate branch.
		*/
		const freeUseGrantActive = computed(() => subscription.value?.agentScopedHasFunds === true);
		const freeUsePlacement = computed(() => !freeUseGrantActive.value || unresolvedPaywallPending.value ? "control" : freeUseVariant.value);
		function onFeedback(turnId, vote) {
			const message = entries.value.find((entry) => entry.role === "assistant" && entry.id === turnId);
			const workflowId = message?.role === "assistant" ? message.parts.flatMap((part) => part.type === "tabLink" ? [part.workflowId] : []).at(-1) ?? null : null;
			useTelemetry()?.trackAgentMessageFeedback({
				message_id: turnId,
				turn_id: turnId,
				vote,
				workflow_id: workflowId
			});
		}
		const { refreshHistory } = useAgentChatHistoryRefresh({
			listThreads: rest.listThreads,
			history,
			untitledChat: () => t("agent.untitledChat"),
			onFailure: (failure, uiTreatment) => {
				const error = failure.status === "failed" ? failure.cause : /* @__PURE__ */ new Error("Agent thread list ended before its last page");
				reportError(error, {
					surface: "agent",
					errorType: "agent_thread_list_load_failed",
					tags: failure.status === "incomplete" ? { reason: failure.reason } : void 0
				});
				if (uiTreatment === "error_overlay") surfaceAgentError("agent_api_failed", error instanceof Error ? error.message : String(error));
				trackAgentError("thread_list_load_failed", "pre_acceptance", uiTreatment, { retryable: failure.status === "failed" && isRetryableRequestFailure(error, false) });
			}
		});
		const provisionalTitle = ref();
		refreshHistory();
		const currentChatReady = computed(() => isTranscriptReady.value && threadId.value === history.activeId && selectedTarget.value !== null);
		const historyGroups = computed(() => {
			const id = threadId.value;
			if (id === null || !isTranscriptReady.value || id !== history.activeId) return history.grouped;
			return withCurrentSessionTitle(history.grouped, history.titleFor(id) || deriveSessionTitle(entries.value));
		});
		const workflowChatFollow = useAgentWorkflowChatFollow({
			activeWorkflow: () => workflowStore.activeWorkflow,
			selectedTarget: () => selectedTarget.value,
			currentThreadId: () => threadId.value,
			sessions: () => history.sessions,
			followsVisibleWorkflow: () => agentPanelStore.followsVisibleWorkflow,
			hasDraft: () => composerStore.hasDraft,
			userEngaged,
			cloudIdFor,
			refreshCloudWorkflowIds,
			refreshHistory,
			loadThread,
			clearDraft: () => composerStore.setText(""),
			trackThreadStarted: () => useTelemetry()?.trackAgentThreadStarted({ source: "history_select" }),
			restoreThreadWorkflow,
			adoptWorkflowTarget,
			adoptRestoredWorkflowTab
		});
		const { failure: followFailure, openingWorkflowName, followTab, retireFollow, retryFollow: onRetryFollow } = workflowChatFollow;
		watch(threadId, (id, previousId) => {
			if (id === null || previousId !== null || provisionalTitle.value === void 0) return;
			if (!workflowChatFollow.isOpeningThread(id)) history.rename(id, provisionalTitle.value);
			provisionalTitle.value = void 0;
		}, {
			immediate: true,
			flush: "sync"
		});
		function onOpenHistory() {
			retireFollow();
			refreshHistory();
		}
		async function onSelectHistory(id, isCurrent) {
			retireFollow();
			provisionalTitle.value = void 0;
			if (currentChatReady.value && id === threadId.value) return onShowTarget(isCurrent, warnRestoreFailed);
			composerStore.invalidateSubmission();
			cancelWorkflowSelection();
			agentPanelStore.beginWorkflowRestoration();
			canvasStore.stopNodePicking();
			const opened = await loadThread(id, isCurrent);
			if (opened) useTelemetry()?.trackAgentThreadStarted({ source: "history_select" });
			refreshHistory();
			return opened;
		}
		function userEngaged() {
			return composerStore.hasDraft || isSending.value || workflowSelecting.value;
		}
		function restoreChatWorkflow(workflowId, isCurrent) {
			return workflowChatFollow.restoreChatWorkflow(workflowId, isCurrent);
		}
		onBeforeUnmount(retireFollow);
		watch(() => workflowStore.activeWorkflow, workflowChatFollow.activeWorkflowChanged);
		workflowStore.onUserActivation((workflow) => void followTab(workflow));
		watch(userEngaged, workflowChatFollow.userEngagementChanged);
		const mountedOn = workflowStore.activeWorkflow;
		if (mountedOn !== null && selectedTarget.value !== null && selectedTarget.value.path !== mountedOn.path) followTab(mountedOn);
		function buildTranscriptMarkdown(entries) {
			return entries.map((entry) => {
				if (entry.role === "user") return `**You:** ${agentMessageText(entry)}`;
				return `**Agent:** ${entry.parts.filter((part) => part.type === "text").map((part) => part.text).join("")}`;
			}).join("\n\n");
		}
		function onCopyMarkdown(id) {
			if (id === history.activeId && id === threadId.value) copy(buildTranscriptMarkdown(entries.value));
			else toast.info(t("agent.copyUnavailable"));
		}
		const coachSteps = computed(() => [
			{
				target: "#agent-panel-root",
				placement: "left-center",
				title: t("agent.coachTitle"),
				body: t("agent.coachBody")
			},
			{
				target: "#agent-composer",
				placement: "left-end",
				title: t("agent.coachWorkflowTitle"),
				body: t("agent.coachWorkflowBody")
			},
			{
				target: ".graph-canvas-panel",
				placement: "graph-bottom",
				toolbarTarget: ".graph-canvas-panel [role=\"toolbar\"]",
				title: t("agent.coachGraphTitle"),
				body: t("agent.coachGraphBody")
			},
			{
				target: "#agent-chat-history",
				placement: "left-start",
				tooltip: t("agent.showChatHistory"),
				title: t("agent.coachHistoryTitle"),
				body: t("agent.coachHistoryBody")
			}
		]);
		let consentHeldSubmissionId;
		async function consentAllowsSubmission(submissionId) {
			let hasConsent = false;
			let coachReleased = false;
			let acceptedIdentity = null;
			consentHeldSubmissionId = submissionId;
			try {
				await withConsent("first_message", () => {
					hasConsent = true;
					acceptedIdentity = consentIdentity.value;
				});
				if (hasConsent) coachReleased = await waitForCoachCompletion();
			} finally {
				if (consentHeldSubmissionId === submissionId) consentHeldSubmissionId = void 0;
			}
			return composerStore.submission?.id === submissionId && hasConsent && coachReleased && consentAccepted.value && consentIdentity.value === acceptedIdentity;
		}
		const { submit: onSend } = useAgentDraftSubmission({
			canSubmit: () => !workflowSelecting.value && !isSending.value,
			onSubmit: agentPanelStore.retainWorkflowTarget,
			target: () => selectedTarget.value,
			editableWorkflowId: () => editableWorkflowId.value,
			selection: {
				staged: selectionTags,
				workflow: () => nodeReferenceWorkflow,
				consume: consumeSelection,
				replace: replaceSelectionTags,
				exit: canvasStore.stopNodePicking
			},
			send: async (text, attachments, nodes, references, meta) => {
				if (!agentPanelStore.onboarding.introduceBeforeSignIn && !hasAgentCredential() && !await ensureSignedIn()) return false;
				const submissionId = composerStore.submission?.id;
				if (!consentAccepted.value && !await consentAllowsSubmission(submissionId)) return false;
				if (!hasAgentCredential()) {
					const identityBeforeSignIn = consentIdentity.value;
					if (!await ensureSignedIn()) return false;
					if (composerStore.submission?.id !== submissionId || !consentAccepted.value || consentIdentity.value !== identityBeforeSignIn) return false;
				}
				const originContext = targetWorkflowTurnContext();
				pendingSend = {
					metadata: {
						attachment_count: attachments.length,
						node_tag_count: nodes.length,
						thread_id: threadId.value,
						workflow_id: originContext?.id ?? null,
						client_message_id: meta.clientMessageId,
						input_method: meta.inputMethod,
						starter_prompt_id: meta.starterPrompt?.id ?? null,
						starter_prompt_click_id: meta.starterPrompt?.clickId ?? null,
						...meta.starterPrompt?.assignment ? { "$feature/agent-starter-prompt-set": meta.starterPrompt.assignment } : {}
					},
					origin: originContext === void 0 ? null : { tabPath: originContext.tabPath }
				};
				const selectionWorkflow = selectedTarget.value;
				try {
					return await sendWithFundsRecheck((onAccepted) => sendMessage(text, attachments, nodes, references, () => selectionWorkflow ? cloudIdFor(selectionWorkflow) : void 0, meta.clientMessageId, onAccepted));
				} finally {
					reportPendingSend();
				}
			}
		});
		function onStop(method) {
			stopTurn(method);
		}
		function onRenameChat(title) {
			if (threadId.value === null) provisionalTitle.value = title;
			else history.rename(threadId.value, title);
		}
		function onRenameHistory(id, title) {
			history.rename(id, title);
		}
		function onDeleteHistory(id) {
			const isCurrent = id === history.activeId || history.activeId === null && id === threadId.value;
			history.remove(id);
			if (isCurrent) onNewChat("history_delete");
		}
		function onNewChat(source) {
			retireFollow();
			provisionalTitle.value = void 0;
			composerStore.invalidateSubmission();
			cancelWorkflowSelection();
			canvasStore.stopNodePicking();
			composerStore.setWorkflowReferences([]);
			composerStore.resetPromptHistory();
			newChat(source);
			if (selectionTags.value.length) agentPanelStore.retainWorkflowTarget();
			else agentPanelStore.startFollowingVisibleWorkflow();
		}
		const fileInput = ref();
		const assetDragActive = ref(false);
		let assetDragDepth = 0;
		watch(selectedTarget, (target) => {
			canvasStore.stopNodePicking();
			composerStore.setNodeScope(target?.instanceId ?? null);
			nodeReferenceWorkflow = null;
		}, { flush: "sync" });
		watch(() => workflowStore.activeWorkflow, () => {
			canvasStore.stopNodePicking();
			onVisibleWorkflowChanged();
		}, { flush: "sync" });
		start({ restore: agentPanelStore.view.screen === "chat" || agentPanelStore.view.selection.status === "idle" && threadId.value === agentPanelStore.view.previousThreadId });
		watch(() => canvasStore.currentGraph, canvasStore.stopNodePicking, { flush: "sync" });
		function onSelectNodes() {
			if (!canReferenceNodes.value || canvasStore.isPickingNodes) return;
			const canvas = app.canvas;
			if (!canvas) return;
			const merged = new Map([...canvas.selectedItems].filter(isLGraphNode).map((node) => [workflowStore.nodeToNodeLocatorId(node), node]));
			for (const tag of selectionTags.value) {
				const key = selectedNodeKey(tag);
				const node = getNodeByLocatorId(app.rootGraph, key);
				if (node) merged.set(key, node);
			}
			if (merged.size) canvas.selectItems([...merged.values()]);
			canvasStore.startNodePicking();
			nextTick(() => {
				if (canvasStore.isPickingNodes) canvas.canvas.focus();
			});
		}
		const assetsStore = useAssetsStore();
		let inputAssetRefresh = Promise.resolve();
		const { flags } = useFeatureFlags();
		const attachment = useAttachment({
			validate: isValidAgentAttachment,
			upload: async (file, signal) => {
				const filename = (await rest.uploadImage(file, file.name, signal)).name ?? file.name;
				return {
					ref: filename,
					url: isHdrImageFilename(file.name) ? void 0 : api.apiURL(`/view?filename=${encodeURIComponent(filename)}&type=input`)
				};
			},
			resolveStoredPreview: async (file, ref) => isHdrImageFilename(file.name) ? await findServerPreviewUrl(ref) ?? void 0 : void 0,
			onUploaded: () => {
				inputAssetRefresh = inputAssetRefresh.then(() => assetsStore.inputAssets.loadNew()).catch(() => void 0);
			},
			maxBytes: () => flags.maxUploadSize ?? 20971520,
			onError: warnAttachment,
			onDuplicate: notifyDuplicateAttachments,
			staged: () => composerStore.attachments,
			stage: composerStore.addAttachment,
			update: composerStore.updateAttachment,
			remove: composerStore.removeAttachment
		});
		watch([
			() => resolvedUserInfo.value?.id,
			() => workspaceStore.activeWorkspaceId,
			() => assetsStore.deletingAssetIds.size
		], attachment.forgetUploads);
		function notifyDuplicateAttachments(names) {
			toast.info(t("agent.attachmentsAlreadyAdded", {
				name: names[0],
				count: names.length
			}, names.length), { duration: 3500 });
		}
		onBeforeUnmount(() => runPanelTeardown({ cancelAllUploads: () => {
			attachment.cancelAllUploads();
		} }));
		function onAttach() {
			canvasStore.stopNodePicking();
			useTelemetry()?.trackAgentAttachButtonClicked({ method: "menu" });
			fileInput.value?.click();
		}
		async function onAttachFiles(files) {
			if (await attachment.addFiles(files)) useTelemetry()?.trackAgentAttachButtonClicked({ method: "paste" });
		}
		function onOpenAssets() {
			canvasStore.stopNodePicking();
			sidebarTabStore.activeSidebarTabId = "assets";
		}
		function onMentionPick(node) {
			if (!canReferenceNodes.value) return;
			const stagedBefore = selectionTags.value.length;
			addSelectionTag(node);
			if (selectionTags.value.length > stagedBefore) useTelemetry()?.trackAgentNodeTagged({ source: "mention_picker" });
		}
		function onRemoveSelectionTag(id) {
			const node = canvasStore.selectedItems.filter(isLGraphNode).find((item) => selectedNodeKey(toSelectedNode(item)) === id);
			removeSelectionTag(id);
			if (node) {
				canvasStore.canvas?.deselect(node);
				canvasStore.canvas?.setDirty(true);
			}
		}
		function onClosePanel() {
			canvasStore.stopNodePicking();
			useTelemetry()?.trackAgentCloseButtonClicked();
			agentPanelStore.close("close_button");
		}
		async function onFilesPicked(event) {
			const input = event.target;
			const files = input.files;
			if (files && files.length > 0) await attachment.addFiles(Array.from(files));
			input.value = "";
		}
		function isAssetDrag(event) {
			return (event.dataTransfer?.types ?? []).includes(MIME_ASSET_INFO);
		}
		function isAttachableDrag(event) {
			return (event.dataTransfer?.types ?? []).includes("Files") || isAssetDrag(event);
		}
		function clearAssetDrag() {
			assetDragDepth = 0;
			assetDragActive.value = false;
		}
		function onPanelDragEnter(event) {
			if (!isAttachableDrag(event)) return;
			assetDragDepth += 1;
			assetDragActive.value = true;
		}
		function onPanelDragLeave() {
			if (assetDragDepth === 0) return;
			assetDragDepth -= 1;
			if (assetDragDepth === 0) assetDragActive.value = false;
		}
		function warnAttachment(message) {
			toast.warning(message, { duration: 5e3 });
		}
		function droppedAssetVerdict(asset) {
			const fromRef = asset.ref ? agentAttachRefVerdict(asset.ref) : "unknown";
			return fromRef === "unknown" ? agentAttachVerdict(asset.name) : fromRef;
		}
		function stageAcceptedAssetCard(asset, ref, sourceKey) {
			if (composerStore.attachments.some((item) => item.ref === ref)) {
				notifyDuplicateAttachments([asset.name]);
				return false;
			}
			if (composerStore.attachments.length >= 25) {
				warnAttachment(t("agent.attachmentCountExceeded", { count: 25 }));
				return false;
			}
			const added = composerStore.addAttachment({
				id: `asset:${crypto.randomUUID()}`,
				name: asset.name,
				ref,
				sourceKey,
				previewUrl: asset.previewUrl,
				mediaUrl: asset.mediaUrl,
				mediaKind: asset.kind
			});
			if (!added) notifyDuplicateAttachments([asset.name]);
			return added;
		}
		async function attachDroppedAsset(event) {
			const asset = event.dataTransfer && getDroppedAsset(event.dataTransfer);
			if (!asset) {
				warnAttachment(t("agent.assetNotAttachable"));
				return false;
			}
			const sourceKey = asset.ref ? `asset:${asset.ref}` : `uri:${asset.uri}`;
			if (droppedAssetVerdict(asset) === "rejected") {
				attachment.addUnsupportedAsset(asset.name, sourceKey);
				return false;
			}
			if (asset.ref && asset.kind !== "other") return stageAcceptedAssetCard(asset, asset.ref, sourceKey);
			const result = await attachment.addDeferredFile(asset.name, (signal) => fetchDroppedAsset(asset, {
				signal,
				nameFromSource: true
			}), sourceKey);
			if (result === "fetch_failed") warnAttachment(t("agent.assetFetchFailed", { name: asset.name }));
			return result === "uploaded";
		}
		function onPanelDragOver(event) {
			if (isAttachableDrag(event)) event.preventDefault();
		}
		async function onPanelDrop(event) {
			clearAssetDrag();
			if ((event.dataTransfer?.files.length ?? 0) === 0 && isAssetDrag(event)) {
				event.preventDefault();
				attachDroppedAsset(event).then((attached) => {
					if (attached) useTelemetry()?.trackAgentAttachButtonClicked({ method: "drag_drop" });
				});
				return;
			}
			const files = Array.from(event.dataTransfer?.files ?? []);
			if (files.length === 0) return;
			event.preventDefault();
			if (await attachment.addFiles(files)) useTelemetry()?.trackAgentAttachButtonClicked({ method: "drag_drop" });
		}
		const agentPanelRenderStore = useAgentPanelRenderStore();
		onMounted(() => agentPanelRenderStore.reach("drawn"));
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock(Fragment, null, [createVNode(AgentGraphActivityBar_default, { canvas: unref(canvasStore).canvas }, null, 8, ["canvas"]), createBaseVNode("div", {
				id: "agent-panel-root",
				class: "relative size-full",
				onDragenter: onPanelDragEnter,
				onDragleave: onPanelDragLeave,
				onDragover: onPanelDragOver,
				onDrop: onPanelDrop
			}, [
				createBaseVNode("input", {
					ref_key: "fileInput",
					ref: fileInput,
					type: "file",
					accept: unref(AGENT_ATTACH_ACCEPT),
					multiple: "",
					class: "hidden",
					"data-testid": "agent-file-input",
					onChange: onFilesPicked
				}, null, 40, _hoisted_1),
				createVNode(AgentPanel_default, {
					entries: unref(entries),
					"editable-turn-id": unref(editableTurnId),
					"answering-ask-ids": unref(answeringAskIds),
					"user-name": userName.value,
					streaming: unref(isStreaming),
					submitting: isSending.value || unref(status) === "thinking",
					"can-attach": true,
					"can-open-assets": !unref(isBuilderMode),
					"is-maximized": unref(agentPanelStore).isMaximized,
					"history-groups": historyGroups.value,
					"select-history": onSelectHistory,
					"current-chat-ready": currentChatReady.value,
					"opening-workflow-name": unref(openingWorkflowName),
					"session-id": unref(threadId),
					"custom-title": unref(history).titleFor(unref(threadId)) ?? historyGroups.value.current.find((session) => session.id === unref(threadId))?.title ?? provisionalTitle.value,
					"selection-tags": unref(selectionTags),
					"node-reference-disabled-reason": nodeReferenceDisabledReason.value,
					"select-workflow-reference": unref(onSelectWorkflowReference),
					"saving-reference": unref(savingReference),
					"available-workflows": unref(availableWorkflowReferences),
					"editable-workflow-id": editableWorkflowId.value,
					"active-tab": selectedTargetTab.value,
					"workflow-tabs": workflowTabs.value,
					"visible-tab-path": unref(workflowStore).activeWorkflow?.path ?? null,
					"follows-visible-workflow": unref(agentPanelStore).followsVisibleWorkflow,
					"selecting-tab-path": unref(selectingTarget)?.path ?? null,
					"select-tab": unref(onSelectWorkflowTarget),
					"workflow-detached": workflowDetached.value,
					"target-unavailable": unref(agentPanelStore).targetUnavailable,
					"canvas-empty-after-turn": canvasEmptyAfterTurn.value,
					"get-mention-nodes": mentionableNodes,
					"paywall-presentation": paywallPresentation.value,
					"credits-exhausted": showStandingPaywall.value,
					"sync-retry-available": unref(crdtStatus).terminal === "retry_exhausted" || unref(crdtStatus).terminal === "timeout",
					"free-use-placement": freeUsePlacement.value,
					"starter-prompt-assignment": unref(starterPromptAssignment),
					"attribute-starter-prompt-experiment": unref(attributeStarterPromptExperiment),
					onStarterPromptRendered: unref(exposeStarterPromptSet),
					onFreeUseNotice: unref(onFreeUseNotice),
					onSend: unref(onSend),
					onStop,
					onAttach,
					onAttachFiles,
					onRemoveAttachment: unref(attachment).cancelUpload,
					onOpenAssets,
					onSelectNodes,
					onRemoveTag: onRemoveSelectionTag,
					onMentionPick,
					onRequestWorkflowReferences: unref(onRequestWorkflowReferences),
					onRemoveWorkflowReference: unref(composerStore).removeWorkflowReference,
					onFeedback,
					onAnswerAsk,
					onApprovalShown,
					onOpenWorkflow: onOpenApprovalWorkflow,
					onOpenReferenceWorkflow: onNavigateToReferenceWorkflow,
					onShowTarget,
					onPaywallAction,
					onStandingPaywallShown,
					onRetrySync: unref(retrySubscription),
					onNewChat: _cache[0] || (_cache[0] = ($event) => onNewChat("new_chat_button")),
					onStartTour: restartCoach,
					onToggleSize: _cache[1] || (_cache[1] = ($event) => unref(agentPanelStore).toggleMaximize()),
					onClose: onClosePanel,
					onOpenHistory,
					onDeleteHistory,
					onRenameHistory,
					onRenameChat,
					onCopyHistory: onCopyMarkdown
				}, createSlots({
					composerNotice: withCtx(() => [unref(followFailure) ? (openBlock(), createBlock(RunNoticeBanner_default, {
						key: 0,
						context: "followFailed",
						"workflow-name": unref(followFailure).filename,
						onRetry: unref(onRetryFollow)
					}, null, 8, ["workflow-name", "onRetry"])) : createCommentVNode("", true), showCreditTransitionNotice.value ? (openBlock(), createBlock(AgentCreditTransitionNotice_default, {
						key: 1,
						"data-testid": "agent-credit-transition-notice",
						onShown: onCreditTransitionNoticeShown,
						onDismiss: onDismissCreditTransitionNotice
					})) : createCommentVNode("", true)]),
					_: 2
				}, [unref(isCrdtDevPanelEnabled) ? {
					name: "instrument",
					fn: withCtx(() => [createVNode(unref(CrdtDevPanel), {
						status: unref(crdtStatus),
						snapshot: unref(crdtDebugSnapshot)
					}, null, 8, ["status", "snapshot"])]),
					key: "0"
				} : void 0]), 1032, [
					"entries",
					"editable-turn-id",
					"answering-ask-ids",
					"user-name",
					"streaming",
					"submitting",
					"can-open-assets",
					"is-maximized",
					"history-groups",
					"current-chat-ready",
					"opening-workflow-name",
					"session-id",
					"custom-title",
					"selection-tags",
					"node-reference-disabled-reason",
					"select-workflow-reference",
					"saving-reference",
					"available-workflows",
					"editable-workflow-id",
					"active-tab",
					"workflow-tabs",
					"visible-tab-path",
					"follows-visible-workflow",
					"selecting-tab-path",
					"select-tab",
					"workflow-detached",
					"target-unavailable",
					"canvas-empty-after-turn",
					"paywall-presentation",
					"credits-exhausted",
					"sync-retry-available",
					"free-use-placement",
					"starter-prompt-assignment",
					"attribute-starter-prompt-experiment",
					"onStarterPromptRendered",
					"onFreeUseNotice",
					"onSend",
					"onRemoveAttachment",
					"onRequestWorkflowReferences",
					"onRemoveWorkflowReference",
					"onRetrySync"
				]),
				assetDragActive.value ? (openBlock(), createElementBlock("div", _hoisted_2, [_cache[2] || (_cache[2] = createBaseVNode("span", {
					"aria-hidden": "true",
					class: "icon-[lucide--upload] size-8 shrink-0 text-muted-foreground"
				}, null, -1)), createBaseVNode("span", null, toDisplayString(unref(t)("agent.dragAndDropAssets")), 1)])) : createCommentVNode("", true),
				unref(consentAccepted) && onboardingKey.value && coachDeferredBy.value === null ? (openBlock(), createBlock(OnboardingCoach_default, {
					key: onboardingKey.value,
					ref_key: "coachRef",
					ref: coachRef,
					steps: coachSteps.value,
					"storage-key": onboardingKey.value,
					"hold-notice": sendHeldByCoach.value ? unref(t)("agent.coachHoldNotice") : void 0,
					onFinished: releaseCoachCompletionWaiters,
					onStalled: releaseCoachCompletionWaiters
				}, null, 8, [
					"steps",
					"storage-key",
					"hold-notice"
				])) : createCommentVNode("", true)
			], 32)], 64);
		};
	}
});
//#endregion
export { AgentPanelRoot_default as default };
